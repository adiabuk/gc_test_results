-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','1.297777777777778','1.355964631071980','4394.777439139105','4394.777439139104899','test','test','0.0'),('2019-01-07 15:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000350440000000','0.001133500000000','1.310708189620934','4.239492446453968','3740.1786029589484','3740.178602958948431','test','test','0.0'),('2019-01-28 15:59:59','2019-01-29 03:59:59','DLTETH','4h','0.001159220000000','0.001147627800000','1.961549135583830','1.941933644227992','1692.1284446298632','1692.128444629863225','test','test','1.0'),('2019-01-29 07:59:59','2019-01-29 11:59:59','DLTETH','4h','0.001187050000000','0.001175179500000','1.957190137504755','1.937618236129708','1648.7849184994357','1648.784918499435662','test','test','1.0'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','1.952840826088078','1.939957687323237','1786.8431019197349','1786.843101919734863','test','test','0.7'),('2019-02-02 07:59:59','2019-02-02 15:59:59','DLTETH','4h','0.001231970000000','0.001219650300000','1.949977906362558','1.930478127298932','1582.8128171648318','1582.812817164831813','test','test','1.0'),('2019-02-03 11:59:59','2019-02-03 15:59:59','DLTETH','4h','0.001164100000000','0.001152459000000','1.945644622126196','1.926188175904934','1671.3724096952124','1671.372409695212355','test','test','1.0'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000814215600000','1.941320967410361','1.921907757736258','2360.4408435999717','2360.440843599971686','test','test','1.0'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','1.937006920816115','1.953056444817647','2666.033887297661','2666.033887297660840','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','1.940573481705345','1.971279180792580','2670.0607901943404','2670.060790194340370','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','DLTETH','4h','0.000734000000000','0.000726660000000','1.947396970391397','1.927923000687483','2653.12938745422','2653.129387454219795','test','test','1.0'),('2019-03-05 15:59:59','2019-03-05 19:59:59','DLTETH','4h','0.000737110000000','0.000729738900000','1.943069421568305','1.923638727352622','2636.064388718515','2636.064388718515147','test','test','1.0'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DLTETH','4h','0.000780780000000','0.000772972200000','1.938751489520375','1.919363974625171','2483.0957369814487','2483.095736981448681','test','test','1.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','1.934443152876997','1.916025154567895','2634.9067681118518','2634.906768111851761','test','test','1.0'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','1.930350264363863','1.950955962134667','2655.373424072663','2655.373424072663056','test','test','0.0'),('2019-03-09 15:59:59','2019-03-10 15:59:59','DLTETH','4h','0.000729000000000','0.000728780000000','1.934929308312931','1.934345379029215','2654.224016890166','2654.224016890165785','test','test','0.0'),('2019-03-10 19:59:59','2019-03-11 11:59:59','DLTETH','4h','0.000738650000000','0.000731263500000','1.934799546249883','1.915451550787384','2619.3725665063057','2619.372566506305702','test','test','1.0'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','1.930499991702661','1.926679924623455','2529.8457478182922','2529.845747818292239','test','test','0.3'),('2019-03-20 15:59:59','2019-03-20 23:59:59','DLTETH','4h','0.000782480000000','0.000774655200000','1.929651087907281','1.910354577028208','2466.070810637053','2466.070810637053000','test','test','1.0'),('2019-03-21 07:59:59','2019-03-21 11:59:59','DLTETH','4h','0.000778600000000','0.000783820000000','1.925362974378598','1.938271264548463','2472.8525229624947','2472.852522962494731','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','DLTETH','4h','0.000830370000000','0.000822066300000','1.928231483305235','1.908949168472183','2322.135293068434','2322.135293068433839','test','test','1.0'),('2019-03-27 07:59:59','2019-03-27 15:59:59','DLTETH','4h','0.000822280000000','0.000814057200000','1.923946524453446','1.904707059208911','2339.770545864482','2339.770545864481846','test','test','1.0'),('2019-03-28 11:59:59','2019-03-28 15:59:59','DLTETH','4h','0.000892810000000','0.000883881900000','1.919671087732438','1.900474376855114','2150.1451459240357','2150.145145924035660','test','test','1.0'),('2019-03-29 07:59:59','2019-03-29 11:59:59','DLTETH','4h','0.000876230000000','0.000867467700000','1.915405151981922','1.896251100462103','2185.9616219279433','2185.961621927943270','test','test','1.0'),('2019-03-30 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000857810000000','0.000861450000000','1.911148696088629','1.919258395501975','2227.9393992709674','2227.939399270967442','test','test','0.9'),('2019-05-05 23:59:59','2019-05-06 19:59:59','DLTETH','4h','0.000587770000000','0.000581892300000','1.912950851513816','1.893821342998678','3254.590828919163','3254.590828919162959','test','test','1.0'),('2019-05-10 07:59:59','2019-05-10 11:59:59','DLTETH','4h','0.000624000000000','0.000617760000000','1.908699849621564','1.889612851125348','3058.8138615730186','3058.813861573018585','test','test','1.0'),('2019-05-11 07:59:59','2019-05-11 11:59:59','DLTETH','4h','0.000546280000000','0.000540817200000','1.904458294400182','1.885413711456180','3486.23104342129','3486.231043421289996','test','test','1.0'),('2019-05-12 15:59:59','2019-05-12 19:59:59','DLTETH','4h','0.000554000000000','0.000548460000000','1.900226164857070','1.881223903208499','3430.011127900849','3430.011127900848805','test','test','1.0'),('2019-05-21 19:59:59','2019-05-21 23:59:59','DLTETH','4h','0.000495470000000','0.000490960000000','1.896003440046277','1.878745128716411','3826.676569815079','3826.676569815078892','test','test','0.9'),('2019-05-22 03:59:59','2019-05-22 11:59:59','DLTETH','4h','0.000512030000000','0.000506909700000','1.892168259750751','1.873246577153243','3695.4246035403226','3695.424603540322551','test','test','1.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','DLTETH','4h','0.000540350000000','0.000534946500000','1.887963441395750','1.869083806981793','3493.96398888822','3493.963988888219774','test','test','1.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','DLTETH','4h','0.000460610000000','0.000456003900000','1.883767967081537','1.864930287410722','4089.724424310233','4089.724424310233189','test','test','1.0'),('2019-06-07 23:59:59','2019-06-14 11:59:59','DLTETH','4h','0.000445120000000','0.000456810000000','1.879581816043578','1.928944485502486','4222.640672276191','4222.640672276191253','test','test','0.0'),('2019-07-15 23:59:59','2019-07-17 15:59:59','DLTETH','4h','0.000293110000000','0.000290178900000','1.890551298145558','1.871645785164102','6449.972017827974','6449.972017827974014','test','test','1.0'),('2019-07-22 15:59:59','2019-07-22 19:59:59','DLTETH','4h','0.000288340000000','0.000285456600000','1.886350073038567','1.867486572308181','6542.103326068417','6542.103326068417118','test','test','1.0'),('2019-07-22 23:59:59','2019-07-23 07:59:59','DLTETH','4h','0.000289800000000','0.000286902000000','1.882158183987371','1.863336602147497','6494.679723903971','6494.679723903970626','test','test','1.0'),('2019-07-23 11:59:59','2019-07-23 15:59:59','DLTETH','4h','0.000285730000000','0.000297270000000','1.877975610245176','1.953822873543497','6572.5531454351185','6572.553145435118495','test','test','0.0'),('2019-07-23 19:59:59','2019-07-23 23:59:59','DLTETH','4h','0.000299110000000','0.000296118900000','1.894830557644803','1.875882252068355','6334.895381781964','6334.895381781963806','test','test','1.0'),('2019-07-27 03:59:59','2019-07-27 11:59:59','DLTETH','4h','0.000285730000000','0.000285730000000','1.890619823072259','1.890619823072259','6616.805456452803','6616.805456452802900','test','test','0.0'),('2019-07-28 19:59:59','2019-07-30 11:59:59','DLTETH','4h','0.000303050000000','0.000300019500000','1.890619823072259','1.871713624841536','6238.63990454466','6238.639904544659657','test','test','1.0'),('2019-08-02 03:59:59','2019-08-02 07:59:59','DLTETH','4h','0.000303730000000','0.000300692700000','1.886418445687654','1.867554261230777','6210.840041114326','6210.840041114325686','test','test','1.0'),('2019-08-02 15:59:59','2019-08-02 19:59:59','DLTETH','4h','0.000293950000000','0.000291130000000','1.882226404697237','1.864169325393797','6403.21961114896','6403.219611148960212','test','test','1.0'),('2019-08-21 15:59:59','2019-08-21 19:59:59','DLTETH','4h','0.000247660000000','0.000260270000000','1.878213720407583','1.973845938021810','7583.8396204780065','7583.839620478006509','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 03:59:59','DLTETH','4h','0.000258860000000','0.000256271400000','1.899465324321856','1.880470671078637','7337.809334473676','7337.809334473676245','test','test','1.0'),('2019-08-22 15:59:59','2019-08-23 11:59:59','DLTETH','4h','0.000255080000000','0.000252529200000','1.895244290267808','1.876291847365130','7429.999569812639','7429.999569812638583','test','test','1.0'),('2019-08-24 11:59:59','2019-08-24 23:59:59','DLTETH','4h','0.000269160000000','0.000266468400000','1.891032636289435','1.872122309926540','7025.682256982593','7025.682256982592662','test','test','1.0'),('2019-08-25 07:59:59','2019-08-25 11:59:59','DLTETH','4h','0.000286000000000','0.000283140000000','1.886830341542125','1.867962038126704','6597.308886510926','6597.308886510925731','test','test','1.0'),('2019-08-25 19:59:59','2019-08-25 23:59:59','DLTETH','4h','0.000287920000000','0.000285040800000','1.882637385227587','1.863811011375311','6538.751685286145','6538.751685286145403','test','test','1.0'),('2019-09-10 11:59:59','2019-09-10 15:59:59','DLTETH','4h','0.000226730000000','0.000224462700000','1.878453746593748','1.859669209127811','8284.981019687504','8284.981019687504158','test','test','1.0'),('2019-09-14 19:59:59','2019-09-14 23:59:59','DLTETH','4h','0.000331540000000','0.000328224600000','1.874279404934651','1.855536610885304','5653.252714407464','5653.252714407463827','test','test','1.0'),('2019-09-19 11:59:59','2019-09-19 15:59:59','DLTETH','4h','0.000217850000000','0.000215671500000','1.870114339590351','1.851413196194448','8584.412851000006','8584.412851000006413','test','test','1.0'),('2019-09-20 07:59:59','2019-09-21 23:59:59','DLTETH','4h','0.000217550000000','0.000218220000000','1.865958529946817','1.871705219053066','8577.147919773925','8577.147919773924514','test','test','0.0'),('2019-09-22 11:59:59','2019-09-22 19:59:59','DLTETH','4h','0.000221190000000','0.000218978100000','1.867235571970428','1.848563216250724','8441.772105296028','8441.772105296027803','test','test','1.0'),('2019-09-25 15:59:59','2019-09-25 19:59:59','DLTETH','4h','0.000250200000000','0.000247698000000','1.863086159588272','1.844455297992389','7446.387528330422','7446.387528330422356','test','test','1.0'),('2019-09-26 03:59:59','2019-09-26 15:59:59','DLTETH','4h','0.000241250000000','0.000238837500000','1.858945968122520','1.840356508441295','7705.4755155337625','7705.475515533762518','test','test','1.0'),('2019-09-26 23:59:59','2019-09-30 07:59:59','DLTETH','4h','0.000238890000000','0.000240780000000','1.854814977082248','1.869489514763547','7764.305651480799','7764.305651480798588','test','test','0.0'),('2019-10-01 11:59:59','2019-10-01 15:59:59','DLTETH','4h','0.000265230000000','0.000262577700000','1.858075985455870','1.839495225601311','7005.527223375449','7005.527223375448557','test','test','1.0'),('2019-10-01 19:59:59','2019-10-02 07:59:59','DLTETH','4h','0.000262830000000','0.000260201700000','1.853946927710412','1.835407458433308','7053.787344330603','7053.787344330603446','test','test','1.0'),('2019-10-02 19:59:59','2019-10-03 03:59:59','DLTETH','4h','0.000268650000000','0.000265963500000','1.849827045648834','1.831328775192345','6885.6394775687095','6885.639477568709481','test','test','1.0'),('2019-10-04 11:59:59','2019-10-05 15:59:59','DLTETH','4h','0.000265610000000','0.000262953900000','1.845716318880725','1.827259155691918','6948.971495353055','6948.971495353054706','test','test','1.0'),('2019-10-08 15:59:59','2019-10-09 15:59:59','DLTETH','4h','0.000270590000000','0.000267884100000','1.841614727060990','1.823198579790380','6805.923083118334','6805.923083118334034','test','test','1.0'),('2019-10-15 07:59:59','2019-10-15 11:59:59','DLTETH','4h','0.000247680000000','0.000247750000000','1.837522249889743','1.838041575461013','7418.936732435979','7418.936732435979138','test','test','0.0'),('2019-10-21 19:59:59','2019-10-22 03:59:59','DLTETH','4h','0.000236780000000','0.000241620000000','1.837637655572248','1.875200651826026','7760.94963921044','7760.949639210440182','test','test','0.5'),('2019-10-22 11:59:59','2019-10-22 19:59:59','DLTETH','4h','0.000247300000000','0.000244827000000','1.845984988073088','1.827525138192357','7464.5571697253845','7464.557169725384483','test','test','1.0'),('2019-10-23 03:59:59','2019-10-23 15:59:59','DLTETH','4h','0.000238460000000','0.000237110000000','1.841882799210703','1.831455298670007','7724.07447458988','7724.074474589880083','test','test','0.6'),('2019-10-24 19:59:59','2019-10-24 23:59:59','DLTETH','4h','0.000240820000000','0.000238580000000','1.839565576868326','1.822454760108152','7638.75748222044','7638.757482220439670','test','test','0.9'),('2019-10-29 07:59:59','2019-10-29 11:59:59','DLTETH','4h','0.000231500000000','0.000229185000000','1.835763173143843','1.817405541412405','7929.862518979882','7929.862518979882225','test','test','1.0'),('2019-11-03 11:59:59','2019-11-03 23:59:59','DLTETH','4h','0.000234850000000','0.000232501500000','1.831683699425746','1.813366862431488','7799.377046735132','7799.377046735132353','test','test','1.0'),('2019-11-04 07:59:59','2019-11-04 11:59:59','DLTETH','4h','0.000231580000000','0.000229264200000','1.827613291204799','1.809337158292751','7891.930612336123','7891.930612336122977','test','test','1.0'),('2019-11-05 23:59:59','2019-11-06 03:59:59','DLTETH','4h','0.000232700000000','0.000230430000000','1.823551928335455','1.805763089154873','7836.493031093491','7836.493031093490572','test','test','1.0'),('2019-11-07 15:59:59','2019-11-08 11:59:59','DLTETH','4h','0.000231270000000','0.000228957300000','1.819598852961993','1.801402864432373','7867.855117230911','7867.855117230910764','test','test','1.0'),('2019-11-11 15:59:59','2019-11-20 19:59:59','DLTETH','4h','0.000227740000000','0.000240740000000','1.815555299955410','1.919191986086175','7972.052779289584','7972.052779289583668','test','test','0.0'),('2019-11-23 11:59:59','2019-12-02 19:59:59','DLTETH','4h','0.000248580000000','0.000276990000000','1.838585674651136','2.048716091486114','7396.353989263562','7396.353989263561743','test','test','0.0'),('2019-12-06 15:59:59','2019-12-06 19:59:59','DLTETH','4h','0.000278520000000','0.000281940000000','1.885281322836686','1.908431050411372','6768.926191428574','6768.926191428574384','test','test','0.0'),('2019-12-06 23:59:59','2019-12-08 03:59:59','DLTETH','4h','0.000290060000000','0.000287159400000','1.890425706742172','1.871521449674750','6517.360914094229','6517.360914094228974','test','test','1.0'),('2019-12-08 23:59:59','2019-12-09 23:59:59','DLTETH','4h','0.000292730000000','0.000289802700000','1.886224760727190','1.867362513119918','6443.564925792333','6443.564925792333270','test','test','1.0'),('2019-12-16 11:59:59','2019-12-17 11:59:59','DLTETH','4h','0.000277130000000','0.000279830000000','1.882033150147796','1.900369272203868','6791.156317063456','6791.156317063456299','test','test','0.0'),('2019-12-19 11:59:59','2019-12-19 15:59:59','DLTETH','4h','0.000280070000000','0.000277269300000','1.886107843938034','1.867246765498654','6734.415838676167','6734.415838676167368','test','test','1.0'),('2019-12-20 11:59:59','2019-12-21 03:59:59','DLTETH','4h','0.000283350000000','0.000280516500000','1.881916493173727','1.863097328241990','6641.667524876399','6641.667524876398602','test','test','1.0'),('2019-12-21 19:59:59','2019-12-21 23:59:59','DLTETH','4h','0.000284740000000','0.000281892600000','1.877734456522230','1.858957111957007','6594.558040746752','6594.558040746752340','test','test','1.0'),('2019-12-23 11:59:59','2019-12-23 15:59:59','DLTETH','4h','0.000278560000000','0.000277340000000','1.873561713285514','1.865356137143181','6725.882083879646','6725.882083879646416','test','test','0.4'),('2019-12-23 19:59:59','2019-12-23 23:59:59','DLTETH','4h','0.000286790000000','0.000283922100000','1.871738251920551','1.853020869401345','6526.511565677154','6526.511565677154067','test','test','1.0'),('2019-12-27 03:59:59','2019-12-29 15:59:59','DLTETH','4h','0.000299520000000','0.000296524800000','1.867578833582950','1.848903045247120','6235.239161267862','6235.239161267862073','test','test','1.0'),('2019-12-30 07:59:59','2019-12-30 11:59:59','DLTETH','4h','0.000291510000000','0.000291530000000','1.863428658397210','1.863556505034266','6392.331852757057','6392.331852757057277','test','test','0.0'),('2019-12-30 19:59:59','2019-12-31 19:59:59','DLTETH','4h','0.000293150000000','0.000296670000000','1.863457068761000','1.885832538254566','6356.66746976292','6356.667469762919609','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:41:37
