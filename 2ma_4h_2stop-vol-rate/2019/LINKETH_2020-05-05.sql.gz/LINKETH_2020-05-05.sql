-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.297777777777778','2.287238963017428','561.3104291766085','561.310429176608523','test','test','0.0'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','1.517658041164367','1.550536022699582','377.3006832133887','377.300683213388709','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 03:59:59','LINKETH','4h','0.004291500000000','0.004248585000000','1.524964259283303','1.509714616690470','355.34527770786514','355.345277707865137','test','test','1.0'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','1.521575449818229','1.537744008326113','390.73365171301293','390.733651713012932','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003930240600000','1.525168462819981','1.509916778191781','384.1792225625529','384.179222562552923','test','test','1.0'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003906619200000','1.521779199569270','1.506561407573577','385.64327118793085','385.643271187930850','test','test','1.0'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.004007708100000','1.518397468014672','1.503213493334525','375.0805836718809','375.080583671880902','test','test','1.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003939853500000','1.515023251419083','1.499873018904892','380.69258638801983','380.692586388019834','test','test','1.0'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003314807100000','1.511656533082597','1.496539967751771','451.4712086117382','451.471208611738177','test','test','1.0'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKETH','4h','0.003429610000000','0.003395313900000','1.508297296342413','1.493214323378989','439.78682600715905','439.786826007159050','test','test','1.0'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','1.504945524572763','1.522284950690465','470.41307969891324','470.413079698913236','test','test','0.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003230000000000','0.003198670000000','1.508798730376697','1.494163849812393','467.12034996182564','467.120349961825639','test','test','1.0'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','1.505546534695741','1.519011038064755','467.5174780907805','467.517478090780514','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003231429300000','1.508538646555522','1.493453260089967','462.1649188147073','462.164918814707278','test','test','1.0'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003242121300000','1.505186338452065','1.490134475067544','459.61712631404146','459.617126314041457','test','test','1.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','LINKETH','4h','0.003401970000000','0.003367950300000','1.501841479922171','1.486823065122949','441.4622938833004','441.462293883300390','test','test','1.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','LINKETH','4h','0.003609580000000','0.003573484200000','1.498504054411233','1.483519013867121','415.1463755925158','415.146375592515824','test','test','1.0'),('2019-03-08 15:59:59','2019-03-08 19:59:59','LINKETH','4h','0.003562430000000','0.003526805700000','1.495174045401430','1.480222304947416','419.7062245156902','419.706224515690224','test','test','1.0'),('2019-03-10 15:59:59','2019-03-10 19:59:59','LINKETH','4h','0.003902250000000','0.003863227500000','1.491851436411650','1.476932922047533','382.30544850064695','382.305448500646946','test','test','1.0'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKETH','4h','0.003700000000000','0.003663000000000','1.488536210997401','1.473650848887427','402.30708405335173','402.307084053351730','test','test','1.0'),('2019-03-12 01:59:59','2019-03-16 03:59:59','LINKETH','4h','0.003540000000000','0.003504600000000','1.485228352750740','1.470376069223233','419.55603185049154','419.556031850491536','test','test','1.0'),('2019-03-25 19:59:59','2019-03-26 15:59:59','LINKETH','4h','0.003439950000000','0.003412920000000','1.481927845300183','1.470283341845637','430.79923990179606','430.799239901796057','test','test','0.8'),('2019-03-27 19:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003515940000000','0.003480780600000','1.479340177865840','1.464546776087182','420.75239562274663','420.752395622746633','test','test','1.0'),('2019-03-31 03:59:59','2019-04-02 23:59:59','LINKETH','4h','0.003501720000000','0.003570170000000','1.476052755248360','1.504905950562877','421.5222105846156','421.522210584615607','test','test','0.0'),('2019-04-13 19:59:59','2019-04-14 07:59:59','LINKETH','4h','0.003268570000000','0.003235884300000','1.482464576429364','1.467639930665070','453.5514235367038','453.551423536703794','test','test','1.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','LINKETH','4h','0.002925320000000','0.002952000000000','1.479170210703965','1.492660789930026','505.6438990277868','505.643899027786802','test','test','0.0'),('2019-05-01 07:59:59','2019-05-01 15:59:59','LINKETH','4h','0.002981150000000','0.002953940000000','1.482168117198645','1.468639849761926','497.17998664899295','497.179986648992951','test','test','0.9'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LINKETH','4h','0.002958000000000','0.002928420000000','1.479161835546041','1.464370217190581','500.054711137945','500.054711137944992','test','test','1.0'),('2019-05-03 19:59:59','2019-05-12 07:59:59','LINKETH','4h','0.002985500000000','0.003419910000000','1.475874809244828','1.690624357355378','494.34761656165733','494.347616561657333','test','test','0.0'),('2019-05-14 15:59:59','2019-05-14 19:59:59','LINKETH','4h','0.004178870000000','0.004137081300000','1.523596931047172','1.508360961736700','364.59543633737644','364.595436337376441','test','test','1.0'),('2019-05-17 03:59:59','2019-05-25 15:59:59','LINKETH','4h','0.003537770000000','0.004581860000000','1.520211160089290','1.968865897434461','429.70887312891733','429.708873128917332','test','test','0.0'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKETH','4h','0.004651490000000','0.004604975100000','1.619912212832661','1.603713090704334','348.2566259053897','348.256625905389683','test','test','1.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','LINKETH','4h','0.004490750000000','0.004445842500000','1.616312407915255','1.600149283836102','359.920371411291','359.920371411291001','test','test','1.0'),('2019-05-28 19:59:59','2019-05-28 23:59:59','LINKETH','4h','0.004887510000000','0.004838634900000','1.612720602564332','1.596593396538688','329.96773460603293','329.967734606032934','test','test','1.0'),('2019-06-05 07:59:59','2019-06-12 07:59:59','LINKETH','4h','0.004069090000000','0.004446760000000','1.609136779003078','1.758487785573612','395.4537203657521','395.453720365752076','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 19:59:59','LINKETH','4h','0.004525500000000','0.004480245000000','1.642325891574308','1.625902632658565','362.90484843095965','362.904848430959646','test','test','1.0'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKETH','4h','0.006918550000000','0.006849364500000','1.638676278481920','1.622289515697101','236.8525599268518','236.852559926851796','test','test','1.0'),('2019-06-14 15:59:59','2019-06-16 15:59:59','LINKETH','4h','0.006179120000000','0.006117328800000','1.635034775640849','1.618684427884441','264.60641250547803','264.606412505478033','test','test','1.0'),('2019-06-17 11:59:59','2019-06-18 11:59:59','LINKETH','4h','0.006962830000000','0.006893201700000','1.631401365028315','1.615087351378032','234.30147871315467','234.301478713154665','test','test','1.0'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKETH','4h','0.006425000000000','0.006360750000000','1.627776028661585','1.611498268374969','253.35035465549961','253.350354655499615','test','test','1.0'),('2019-06-26 07:59:59','2019-06-26 11:59:59','LINKETH','4h','0.006490600000000','0.006425694000000','1.624158748597893','1.607917161111914','250.23245132929046','250.232451329290456','test','test','1.0'),('2019-06-26 19:59:59','2019-07-07 19:59:59','LINKETH','4h','0.006632350000000','0.010966680000000','1.620549506934342','2.679600423184348','244.34016705004134','244.340167050041345','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKETH','4h','0.011201500000000','0.011089485000000','1.855894154989898','1.837335213439999','165.6826456269159','165.682645626915900','test','test','1.0'),('2019-07-10 19:59:59','2019-07-10 23:59:59','LINKETH','4h','0.011111730000000','0.011000612700000','1.851769945756588','1.833252246299022','166.6500127123848','166.650012712384807','test','test','1.0'),('2019-07-11 07:59:59','2019-07-11 11:59:59','LINKETH','4h','0.010840590000000','0.010732184100000','1.847654901432684','1.829178352418357','170.43859249659698','170.438592496596982','test','test','1.0'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKETH','4h','0.012013940000000','0.011893800600000','1.843549001651723','1.825113511635206','153.45082476287735','153.450824762877346','test','test','1.0'),('2019-07-14 11:59:59','2019-07-15 19:59:59','LINKETH','4h','0.012193870000000','0.012071931300000','1.839452226092496','1.821057703831571','150.85056885898376','150.850568858983763','test','test','1.0'),('2019-07-17 15:59:59','2019-07-17 19:59:59','LINKETH','4h','0.011569380000000','0.011453686200000','1.835364554478957','1.817010908934167','158.63983674829225','158.639836748292254','test','test','1.0'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKETH','4h','0.012472020000000','0.012347299800000','1.831285966580115','1.812973106914314','146.83154505686448','146.831545056864485','test','test','1.0'),('2019-07-24 07:59:59','2019-07-24 11:59:59','LINKETH','4h','0.011574670000000','0.011458923300000','1.827216442209937','1.808944277787838','157.86337253761334','157.863372537613344','test','test','1.0'),('2019-07-24 19:59:59','2019-07-24 23:59:59','LINKETH','4h','0.011424470000000','0.011310225300000','1.823155961227249','1.804924401614977','159.58341710619823','159.583417106198226','test','test','1.0'),('2019-08-02 19:59:59','2019-08-05 19:59:59','LINKETH','4h','0.010892850000000','0.010835450000000','1.819104503535633','1.809518711157794','166.9998672097415','166.999867209741495','test','test','0.5'),('2019-08-06 23:59:59','2019-08-07 03:59:59','LINKETH','4h','0.010970120000000','0.010860418800000','1.816974327451669','1.798804584177152','165.6293939766993','165.629393976699305','test','test','1.0'),('2019-08-10 07:59:59','2019-08-10 11:59:59','LINKETH','4h','0.011107090000000','0.011089990000000','1.812936606723998','1.810145487180087','163.22336514100436','163.223365141004365','test','test','0.2'),('2019-08-10 15:59:59','2019-08-11 11:59:59','LINKETH','4h','0.011200650000000','0.011088643500000','1.812316357936463','1.794193194357099','161.80457008624165','161.804570086241654','test','test','1.0'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKETH','4h','0.011320920000000','0.011207710800000','1.808288988252159','1.790206098369637','159.72986190629024','159.729861906290239','test','test','1.0'),('2019-08-13 15:59:59','2019-08-20 15:59:59','LINKETH','4h','0.011335270000000','0.012089680000000','1.804270568278266','1.924352380128783','159.17314437841057','159.173144378410569','test','test','0.0'),('2019-09-23 11:59:59','2019-09-23 15:59:59','LINKETH','4h','0.008806250000000','0.008836640000000','1.830955415356158','1.837273965825730','207.91544815967728','207.915448159677283','test','test','0.0'),('2019-09-23 23:59:59','2019-10-15 19:59:59','LINKETH','4h','0.008960940000000','0.013548630000000','1.832359537682730','2.770463969520426','204.48296023438718','204.482960234387178','test','test','0.0'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKETH','4h','0.013595980000000','0.013620690000000','2.040827189202218','2.044536288498126','150.10519206428793','150.105192064287934','test','test','0.0'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKETH','4h','0.013575230000000','0.013638600000000','2.041651433490197','2.051181986662429','150.39534751825175','150.395347518251754','test','test','0.2'),('2019-10-20 19:59:59','2019-10-26 03:59:59','LINKETH','4h','0.013871250000000','0.015358970000000','2.043769334195138','2.262967785226501','147.3385119722547','147.338511972254707','test','test','0.0'),('2019-10-26 11:59:59','2019-10-26 15:59:59','LINKETH','4h','0.015554070000000','0.015398529300000','2.092480101090996','2.071555300080086','134.52942548741237','134.529425487412368','test','test','1.0'),('2019-10-31 19:59:59','2019-11-01 11:59:59','LINKETH','4h','0.014931840000000','0.014782521600000','2.087830145310794','2.066951843857686','139.82403677716837','139.824036777168374','test','test','1.0'),('2019-11-08 23:59:59','2019-11-10 19:59:59','LINKETH','4h','0.014775770000000','0.014727770000000','2.083190522765659','2.076423149891504','140.98693487822692','140.986934878226918','test','test','0.7'),('2019-11-12 15:59:59','2019-11-17 19:59:59','LINKETH','4h','0.015029520000000','0.015580500000000','2.081686662126958','2.158000990002946','138.50652995750747','138.506529957507468','test','test','0.2'),('2019-11-17 23:59:59','2019-11-18 15:59:59','LINKETH','4h','0.015844380000000','0.015739180000000','2.098645401654955','2.084711281401963','132.45361457216723','132.453614572167226','test','test','0.7'),('2019-11-18 23:59:59','2019-11-19 03:59:59','LINKETH','4h','0.015673730000000','0.015516992700000','2.095548930487623','2.074593441182746','133.69816441189323','133.698164411893231','test','test','1.0'),('2019-11-20 11:59:59','2019-11-20 15:59:59','LINKETH','4h','0.015812590000000','0.015654464100000','2.090892155086540','2.069983233535674','132.22958130746068','132.229581307460677','test','test','1.0'),('2019-11-21 15:59:59','2019-11-21 23:59:59','LINKETH','4h','0.016019970000000','0.015859770300000','2.086245728075236','2.065383270794484','130.22781741009726','130.227817410097259','test','test','1.0'),('2019-11-22 15:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015711740000000','0.015699910000000','2.081609626457291','2.080042298975995','132.4875301180704','132.487530118070396','test','test','0.1'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKETH','4h','0.014754620000000','0.014607073800000','2.081261331461448','2.060448718146834','141.05828082739154','141.058280827391542','test','test','1.0'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKETH','4h','0.014574440000000','0.014580070000000','2.076636306280423','2.077438495757642','142.4848094527421','142.484809452742098','test','test','0.0'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKETH','4h','0.014614260000000','0.014468117400000','2.076814570608693','2.056046424902606','142.1087739378315','142.108773937831501','test','test','1.0'),('2019-12-16 19:59:59','2019-12-16 23:59:59','LINKETH','4h','0.015055820000000','0.014905261800000','2.072199427118452','2.051477432847268','137.63444482721312','137.634444827213116','test','test','1.0'),('2019-12-17 03:59:59','2019-12-17 07:59:59','LINKETH','4h','0.014969890000000','0.014820191100000','2.067594539502633','2.046918594107606','138.1168825891595','138.116882589159502','test','test','1.0'),('2019-12-18 03:59:59','2019-12-18 07:59:59','LINKETH','4h','0.014609280000000','0.014476310000000','2.062999884970405','2.044222977778229','141.21160556648954','141.211605566489538','test','test','0.9'),('2019-12-23 19:59:59','2019-12-23 23:59:59','LINKETH','4h','0.014749900000000','0.014602401000000','2.058827238927699','2.038238966538422','139.58245404563414','139.582454045634137','test','test','1.0'),('2019-12-24 03:59:59','2019-12-24 07:59:59','LINKETH','4h','0.014613800000000','0.014554850000000','2.054252067285637','2.045965505312263','140.56932948895138','140.569329488951382','test','test','0.4'),('2019-12-25 11:59:59','2019-12-25 15:59:59','LINKETH','4h','0.014645470000000','0.014499015300000','2.052410609069332','2.031886502978638','140.1396205836571','140.139620583657091','test','test','1.0'),('2019-12-26 19:59:59','2019-12-28 07:59:59','LINKETH','4h','0.014805500000000','0.014657445000000','2.047849696604734','2.027371199638687','138.31682122216296','138.316821222162957','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:05:47
