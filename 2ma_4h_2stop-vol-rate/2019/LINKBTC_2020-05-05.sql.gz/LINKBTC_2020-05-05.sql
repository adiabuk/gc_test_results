-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079280000000','0.000092190000000','0.033333333333333','0.038761352169525','420.45072317524387','420.450723175243866','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000094931100000','0.034539559741376','0.034194164143962','360.19980958781935','360.199809587819345','test','test','1.0'),('2019-01-10 19:59:59','2019-01-10 23:59:59','LINKBTC','4h','0.000099400000000','0.000098406000000','0.034462805164173','0.034118177112531','346.70830145043146','346.708301450431463','test','test','1.0'),('2019-01-11 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000109220000000','0.000137160000000','0.034386221152697','0.043182696331294','314.8344731065454','314.834473106545374','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.036340993414607','0.036340993414607','275.03968375544787','275.039683755447868','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120443400000','0.036340993414607','0.035977583480461','298.7094642002904','298.709464200290427','test','test','1.0'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.036260235651464','0.036022073184131','297.7030841663693','297.703084166369308','test','test','0.7'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000130581000000','0.036207310658723','0.035845237552136','274.50576693497425','274.505766934974247','test','test','1.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKBTC','4h','0.000127920000000','0.000126640800000','0.036126849968370','0.035765581468686','282.4175263318515','282.417526331851491','test','test','1.0'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000121275000000','0.036046568079552','0.035686102398756','294.25769860858594','294.257698608585940','test','test','1.0'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.035966464594930','0.035900919347988','297.93294064720374','297.932940647203736','test','test','0.4'),('2019-02-17 11:59:59','2019-02-17 15:59:59','LINKBTC','4h','0.000123660000000','0.000122423400000','0.035951898984499','0.035592379994654','290.73183717045845','290.731837170458448','test','test','1.0'),('2019-02-17 19:59:59','2019-02-18 03:59:59','LINKBTC','4h','0.000124140000000','0.000122898600000','0.035872005875644','0.035513285816888','288.9641201518','288.964120151799989','test','test','1.0'),('2019-02-18 07:59:59','2019-02-18 11:59:59','LINKBTC','4h','0.000126440000000','0.000125175600000','0.035792290307032','0.035434367403962','283.07727227959504','283.077272279595036','test','test','1.0'),('2019-02-18 15:59:59','2019-02-18 19:59:59','LINKBTC','4h','0.000124740000000','0.000123492600000','0.035712751884128','0.035355624365287','286.2975139019365','286.297513901936497','test','test','1.0'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120611700000','0.035633390213274','0.035277056311141','292.48452937104156','292.484529371041560','test','test','1.0'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000118899000000','0.035554204901689','0.035198662852672','296.0383422288833','296.038342228883323','test','test','1.0'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000122047200000','0.035475195557463','0.035120443601888','287.7611579936964','287.761157993696372','test','test','1.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.035396361789557','0.037832497662322','314.74623679136874','314.746236791368744','test','test','0.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','LINKBTC','4h','0.000125860000000','0.000124601400000','0.035937725316838','0.035578348063670','285.53730587031976','285.537305870319756','test','test','1.0'),('2019-03-10 11:59:59','2019-03-11 11:59:59','LINKBTC','4h','0.000125340000000','0.000124086600000','0.035857863705023','0.035499285067973','286.08475909544705','286.084759095447055','test','test','1.0'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000126530000000','0.000125264700000','0.035778179563457','0.035420397767822','282.7644002486104','282.764400248610400','test','test','1.0'),('2019-03-12 01:59:59','2019-03-16 03:59:59','LINKBTC','4h','0.000120940000000','0.000121660000000','0.035698672497760','0.035911199736047','295.17671984256657','295.176719842566570','test','test','0.0'),('2019-03-25 23:59:59','2019-03-26 03:59:59','LINKBTC','4h','0.000120260000000','0.000119057400000','0.035745900772935','0.035388441765206','297.23848971341164','297.238489713411639','test','test','1.0'),('2019-03-26 07:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000119010000000','0.000117819900000','0.035666465437884','0.035309800783505','299.6930126702294','299.693012670229393','test','test','1.0'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.035587206625800','0.035876411047715','301.2546061610072','301.254606161007189','test','test','0.0'),('2019-03-31 07:59:59','2019-04-02 07:59:59','LINKBTC','4h','0.000122840000000','0.000127310000000','0.035651474275114','0.036948788586493','290.22691529725023','290.226915297250230','test','test','0.0'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.035939766344310','0.036246460959420','403.54554619705317','403.545546197053170','test','test','0.0'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.036007920703223','0.035767541961258','407.4215965515149','407.421596551514881','test','test','0.7'),('2019-05-06 11:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000092640000000','0.000095480000000','0.035954503205008','0.037056735384436','388.10992233385633','388.109922333856332','test','test','0.1'),('2019-05-14 15:59:59','2019-05-14 23:59:59','LINKBTC','4h','0.000107050000000','0.000105979500000','0.036199443689326','0.035837449252433','338.1545417031834','338.154541703183384','test','test','1.0'),('2019-05-15 19:59:59','2019-05-16 11:59:59','LINKBTC','4h','0.000102180000000','0.000101158200000','0.036119000481127','0.035757810476316','353.4840524674823','353.484052467482286','test','test','1.0'),('2019-05-16 19:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000106970000000','0.000142980000000','0.036038736035614','0.048170687841190','336.9050765225183','336.905076522518300','test','test','0.0'),('2019-05-28 19:59:59','2019-05-28 23:59:59','LINKBTC','4h','0.000151910000000','0.000150390900000','0.038734725325742','0.038347378072485','254.98469702943703','254.984697029437029','test','test','1.0'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.038648648158351','0.041526156513286','304.1763588725904','304.176358872590413','test','test','0.0'),('2019-06-10 23:59:59','2019-06-11 03:59:59','LINKBTC','4h','0.000151270000000','0.000149757300000','0.039288094459448','0.038895213514854','259.7216530670192','259.721653067019190','test','test','1.0'),('2019-06-11 07:59:59','2019-06-11 11:59:59','LINKBTC','4h','0.000148010000000','0.000146529900000','0.039200787582872','0.038808779707043','264.8522909456899','264.852290945689901','test','test','1.0'),('2019-06-12 15:59:59','2019-06-12 23:59:59','LINKBTC','4h','0.000140670000000','0.000140860000000','0.039113674721576','0.039166504736484','278.0527100417731','278.052710041773082','test','test','0.8'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKBTC','4h','0.000217740000000','0.000215562600000','0.039125414724889','0.038734160577640','179.68868708041293','179.688687080412933','test','test','1.0'),('2019-06-14 19:59:59','2019-06-14 23:59:59','LINKBTC','4h','0.000195800000000','0.000193842000000','0.039038469358834','0.038648084665246','199.3793123535944','199.379312353594401','test','test','1.0'),('2019-06-17 11:59:59','2019-06-18 11:59:59','LINKBTC','4h','0.000204000000000','0.000201960000000','0.038951717204703','0.038562200032656','190.93979021913287','190.939790219132874','test','test','1.0'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000177457500000','0.038865157833137','0.038476506254806','216.82096420160175','216.820964201601754','test','test','1.0'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.038778790815730','0.060467944450999','210.69704328025114','210.697043280251137','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKBTC','4h','0.000300720000000','0.000297712800000','0.043598602734679','0.043162616707332','144.98072204934454','144.980722049344536','test','test','1.0'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000281348100000','0.043501716950824','0.043066699781316','153.07265192590873','153.072651925908730','test','test','1.0'),('2019-07-13 19:59:59','2019-07-13 23:59:59','LINKBTC','4h','0.000288010000000','0.000285129900000','0.043405046468711','0.042970996004024','150.70673403253744','150.706734032537440','test','test','1.0'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000273477600000','0.043308590809892','0.042875504901793','156.77885465498034','156.778854654980336','test','test','1.0'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.043212349496981','0.043085042716088','184.50258100414538','184.502581004145384','test','test','0.3'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229472100000','0.043184059101227','0.042752218510215','186.3068255801669','186.306825580166901','test','test','1.0'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000211543200000','0.043088094525446','0.042657213580192','201.64776546914283','201.647765469142826','test','test','1.0'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.042992343204279','0.045420241009999','201.65264167110172','201.652641671101719','test','test','0.0'),('2019-09-18 07:59:59','2019-09-18 11:59:59','LINKBTC','4h','0.000170760000000','0.000169052400000','0.043531876049994','0.043096557289494','254.93017129301032','254.930171293010318','test','test','1.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','LINKBTC','4h','0.000174860000000','0.000173111400000','0.043435138547661','0.043000787162184','248.39951130996866','248.399511309968659','test','test','1.0'),('2019-09-18 23:59:59','2019-09-20 19:59:59','LINKBTC','4h','0.000177150000000','0.000175378500000','0.043338616017555','0.042905229857379','244.64361285664756','244.643612856647565','test','test','1.0'),('2019-09-23 19:59:59','2019-09-23 23:59:59','LINKBTC','4h','0.000188940000000','0.000187050600000','0.043242307981960','0.042809884902140','228.86793681571106','228.867936815711062','test','test','1.0'),('2019-09-24 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000193020000000','0.000297510000000','0.043146213964223','0.066503109089711','223.53234879402478','223.532348794024784','test','test','0.2'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.048336635103220','0.048209711772533','162.72221882922068','162.722218829220679','test','test','0.3'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKBTC','4h','0.000296020000000','0.000296150000000','0.048308429918623','0.048329645025337','163.19312856774164','163.193128567741638','test','test','0.0'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.048313144386782','0.048628660133632','163.47966158014938','163.479661580149383','test','test','0.0'),('2019-10-21 03:59:59','2019-10-26 03:59:59','LINKBTC','4h','0.000302500000000','0.000299475000000','0.048383258997193','0.047899426407221','159.94465784195918','159.944657841959184','test','test','1.0'),('2019-11-08 11:59:59','2019-11-19 07:59:59','LINKBTC','4h','0.000296720000000','0.000330580000000','0.048275740643866','0.053784693792293','162.69796658083564','162.697966580835640','test','test','0.0'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000329937300000','0.049499952454627','0.049004952930081','148.52807769864404','148.528077698644040','test','test','1.0'),('2019-11-20 11:59:59','2019-11-20 15:59:59','LINKBTC','4h','0.000341150000000','0.000337738500000','0.049389952560284','0.048896053034681','144.77488659030791','144.774886590307915','test','test','1.0'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334867500000','0.049280197110150','0.048787395139048','145.69163964567494','145.691639645674940','test','test','1.0'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.049170685561016','0.049098800738613','146.70371919030873','146.703719190308732','test','test','0.1'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000291228300000','0.049154711156037','0.048663164044477','167.09627479361362','167.096274793613617','test','test','1.0'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.049045478464580','0.048669170445670','167.24800840436333','167.248008404363333','test','test','0.8'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000288317700000','0.048961854460377','0.048472235915773','168.12091632172965','168.120916321729652','test','test','1.0'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000263429100000','0.048853050339354','0.048364519835960','183.5959650469924','183.595965046992404','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:20:59
