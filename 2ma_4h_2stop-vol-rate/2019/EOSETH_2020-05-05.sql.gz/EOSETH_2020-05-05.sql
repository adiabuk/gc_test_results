-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.019131750000000','1.297777777777778','1.284800000000000','67.15538306741412','67.155383067414121','test','test','1.0'),('2019-01-11 11:59:59','2019-01-11 15:59:59','EOSETH','4h','0.019239000000000','0.019046610000000','1.294893827160494','1.281944888888889','67.30567218465065','67.305672184650646','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','EOSETH','4h','0.019395000000000','0.019201050000000','1.292016285322359','1.279096122469135','66.6159466523516','66.615946652351596','test','test','1.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','EOSETH','4h','0.019130000000000','0.018938700000000','1.289145138021643','1.276253686641426','67.38866377530803','67.388663775308032','test','test','1.0'),('2019-01-15 23:59:59','2019-01-20 11:59:59','EOSETH','4h','0.019693000000000','0.019506000000000','1.286280371048261','1.274066161461808','65.31662880456311','65.316628804563109','test','test','0.9'),('2019-01-20 19:59:59','2019-02-10 23:59:59','EOSETH','4h','0.019799000000000','0.022686000000000','1.283566102251272','1.470729864926126','64.82984505537004','64.829845055370043','test','test','0.0'),('2019-02-12 03:59:59','2019-02-14 07:59:59','EOSETH','4h','0.023099000000000','0.022868010000000','1.325158049512350','1.311906469017227','57.36863282013725','57.368632820137250','test','test','1.0'),('2019-02-16 19:59:59','2019-02-16 23:59:59','EOSETH','4h','0.023017000000000','0.022786830000000','1.322213253846767','1.308991121308299','57.44507337388745','57.445073373887453','test','test','1.0'),('2019-02-18 19:59:59','2019-02-25 11:59:59','EOSETH','4h','0.023667000000000','0.024841000000000','1.319275002171552','1.384717553088415','55.74322906036051','55.743229060360513','test','test','0.0'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSETH','4h','0.025964000000000','0.025704360000000','1.333817791264188','1.320479613351546','51.3718144840621','51.371814484062099','test','test','1.0'),('2019-03-03 19:59:59','2019-03-04 07:59:59','EOSETH','4h','0.026890000000000','0.026621100000000','1.330853751728046','1.317545214210766','49.49251586939553','49.492515869395532','test','test','1.0'),('2019-03-05 15:59:59','2019-03-11 07:59:59','EOSETH','4h','0.027063000000000','0.026933000000000','1.327896298946428','1.321517607786429','49.06685507691048','49.066855076910478','test','test','0.8'),('2019-03-12 11:59:59','2019-03-13 11:59:59','EOSETH','4h','0.027344000000000','0.027070560000000','1.326478812021984','1.313214023901764','48.51078159822937','48.510781598229372','test','test','1.0'),('2019-03-13 15:59:59','2019-03-13 19:59:59','EOSETH','4h','0.027086000000000','0.027101000000000','1.323531081328602','1.324264041759080','48.864028698538064','48.864028698538064','test','test','0.0'),('2019-03-14 15:59:59','2019-03-15 03:59:59','EOSETH','4h','0.027081000000000','0.026976000000000','1.323693961424264','1.318561659590892','48.87906507973352','48.879065079733522','test','test','0.4'),('2019-03-15 11:59:59','2019-03-15 15:59:59','EOSETH','4h','0.027350000000000','0.027076500000000','1.322553449905736','1.309327915406679','48.356616084304804','48.356616084304804','test','test','1.0'),('2019-03-16 03:59:59','2019-03-16 07:59:59','EOSETH','4h','0.027202000000000','0.026929980000000','1.319614442239279','1.306418297816886','48.51166981248729','48.511669812487291','test','test','1.0'),('2019-03-17 03:59:59','2019-03-17 15:59:59','EOSETH','4h','0.027119000000000','0.026911000000000','1.316681965700970','1.306583147571032','48.552010240088855','48.552010240088855','test','test','0.8'),('2019-03-25 19:59:59','2019-03-30 19:59:59','EOSETH','4h','0.027283000000000','0.029271000000000','1.314437783894317','1.410215459163969','48.177905065217054','48.177905065217054','test','test','0.9'),('2019-03-31 11:59:59','2019-03-31 15:59:59','EOSETH','4h','0.029740000000000','0.029442600000000','1.335721711732017','1.322364494614697','44.91330570719627','44.913305707196272','test','test','1.0'),('2019-04-01 23:59:59','2019-04-08 03:59:59','EOSETH','4h','0.029765000000000','0.030330000000000','1.332753441261502','1.358051801560939','44.775858937057','44.775858937057002','test','test','0.7'),('2019-04-09 19:59:59','2019-04-18 03:59:59','EOSETH','4h','0.031698000000000','0.032035000000000','1.338375299105821','1.352604350648463','42.2227048743082','42.222704874308199','test','test','0.2'),('2019-05-03 23:59:59','2019-05-04 07:59:59','EOSETH','4h','0.030281000000000','0.029978190000000','1.341537310559741','1.328121937454144','44.30293948547741','44.302939485477410','test','test','1.0'),('2019-05-04 23:59:59','2019-05-05 07:59:59','EOSETH','4h','0.030252000000000','0.030131000000000','1.338556116536275','1.333202246045038','44.24686356393876','44.246863563938760','test','test','0.5'),('2019-05-26 23:59:59','2019-06-02 19:59:59','EOSETH','4h','0.025934000000000','0.028200000000000','1.337366367538223','1.454219617667074','51.568071548477796','51.568071548477796','test','test','0.0'),('2019-06-16 15:59:59','2019-06-16 19:59:59','EOSETH','4h','0.026052000000000','0.025901000000000','1.363333756455745','1.355431737523424','52.331251207421516','52.331251207421516','test','test','0.6'),('2019-06-17 03:59:59','2019-06-17 11:59:59','EOSETH','4h','0.026185000000000','0.026072000000000','1.361577752248563','1.355701934566528','51.998386566681795','51.998386566681795','test','test','0.4'),('2019-06-17 23:59:59','2019-06-18 07:59:59','EOSETH','4h','0.026076000000000','0.025815240000000','1.360272014985888','1.346669294836029','52.16567015592454','52.165670155924538','test','test','1.0'),('2019-07-15 07:59:59','2019-07-15 11:59:59','EOSETH','4h','0.018830000000000','0.018889000000000','1.357249188285920','1.361501854356492','72.07908594189696','72.079085941896963','test','test','0.0'),('2019-07-16 11:59:59','2019-07-16 15:59:59','EOSETH','4h','0.018866000000000','0.018935000000000','1.358194225190491','1.363161648149154','71.99163708207841','71.991637082078412','test','test','0.0'),('2019-07-20 19:59:59','2019-07-21 07:59:59','EOSETH','4h','0.018980000000000','0.018790200000000','1.359298096959083','1.345705115989492','71.61739183135316','71.617391831353160','test','test','1.0'),('2019-07-22 19:59:59','2019-07-23 03:59:59','EOSETH','4h','0.019049000000000','0.018858510000000','1.356277434521396','1.342714660176182','71.19940335563001','71.199403355630011','test','test','1.0'),('2019-07-23 11:59:59','2019-07-28 23:59:59','EOSETH','4h','0.019500000000000','0.020195000000000','1.353263484666904','1.401495183222981','69.39812741881559','69.398127418815591','test','test','0.7'),('2019-07-31 15:59:59','2019-07-31 19:59:59','EOSETH','4h','0.020002000000000','0.020040000000000','1.363981639901588','1.366572945886803','68.19226276880252','68.192262768802522','test','test','0.0'),('2019-08-10 19:59:59','2019-08-11 03:59:59','EOSETH','4h','0.019753000000000','0.019555470000000','1.364557485676080','1.350911910819319','69.08102494183568','69.081024941835679','test','test','1.0'),('2019-08-11 07:59:59','2019-08-11 23:59:59','EOSETH','4h','0.019699000000000','0.019502010000000','1.361525135707911','1.347909884350832','69.11645950088385','69.116459500883849','test','test','1.0'),('2019-08-13 15:59:59','2019-08-14 19:59:59','EOSETH','4h','0.019565000000000','0.019492000000000','1.358499524295227','1.353430755306034','69.43519163277419','69.435191632774192','test','test','0.6'),('2019-08-15 19:59:59','2019-08-15 23:59:59','EOSETH','4h','0.019593000000000','0.019397070000000','1.357373131186517','1.343799399874652','69.27847349494805','69.278473494948045','test','test','1.0'),('2019-08-22 19:59:59','2019-08-22 23:59:59','EOSETH','4h','0.019086000000000','0.019087000000000','1.354356746450547','1.354427707193838','70.96074329092252','70.960743290922522','test','test','0.0'),('2019-08-26 19:59:59','2019-08-26 23:59:59','EOSETH','4h','0.019105000000000','0.019006000000000','1.354372515504612','1.347354306709273','70.89099793271981','70.890997932719813','test','test','0.5'),('2019-08-31 19:59:59','2019-09-01 03:59:59','EOSETH','4h','0.019453000000000','0.019258470000000','1.352812913550092','1.339284784414591','69.54263679381546','69.542636793815461','test','test','1.0'),('2019-09-06 19:59:59','2019-09-06 23:59:59','EOSETH','4h','0.019002000000000','0.019003000000000','1.349806662631092','1.349877697609654','71.03497856178781','71.034978561787810','test','test','0.0'),('2019-09-07 15:59:59','2019-09-16 23:59:59','EOSETH','4h','0.019671000000000','0.020706000000000','1.349822448181883','1.420844065479847','68.61992009465118','68.619920094651178','test','test','0.0'),('2019-10-04 19:59:59','2019-10-04 23:59:59','EOSETH','4h','0.017227000000000','0.017116000000000','1.365605029803653','1.356805926169346','79.27120391267506','79.271203912675062','test','test','0.6'),('2019-10-07 03:59:59','2019-10-07 15:59:59','EOSETH','4h','0.017254000000000','0.017631000000000','1.363649673440474','1.393445426708531','79.03382829723392','79.033828297233924','test','test','0.3'),('2019-10-07 19:59:59','2019-10-09 03:59:59','EOSETH','4h','0.017581000000000','0.017405190000000','1.370270951944486','1.356568242425041','77.9404443401676','77.940444340167602','test','test','1.0'),('2019-10-12 19:59:59','2019-10-13 03:59:59','EOSETH','4h','0.017073000000000','0.017051000000000','1.367225905384610','1.365464119528670','80.08117526999412','80.081175269994120','test','test','0.1'),('2019-10-13 23:59:59','2019-10-14 19:59:59','EOSETH','4h','0.017127000000000','0.017010000000000','1.366834397416623','1.357497115668638','79.80582690585761','79.805826905857614','test','test','0.7'),('2019-10-21 15:59:59','2019-10-21 19:59:59','EOSETH','4h','0.016822000000000','0.016772000000000','1.364759445917071','1.360702973898533','81.12944037076869','81.129440370768691','test','test','0.3'),('2019-10-22 03:59:59','2019-10-22 23:59:59','EOSETH','4h','0.016893000000000','0.016901000000000','1.363858007690729','1.364503888473392','80.73509783287334','80.735097832873336','test','test','0.0'),('2019-10-23 03:59:59','2019-10-23 19:59:59','EOSETH','4h','0.017198000000000','0.017026020000000','1.364001536753543','1.350361521386008','79.3116372109282','79.311637210928197','test','test','1.0'),('2019-10-24 15:59:59','2019-11-03 19:59:59','EOSETH','4h','0.017009000000000','0.017893000000000','1.360970422227424','1.431703437292921','80.01472292477068','80.014722924770680','test','test','0.6'),('2019-11-04 11:59:59','2019-11-11 11:59:59','EOSETH','4h','0.018242000000000','0.018555000000000','1.376688870019757','1.400310381713441','75.4680884782237','75.468088478223706','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSETH','4h','0.018710000000000','0.018657000000000','1.381938094840576','1.378023465282770','73.86093505294363','73.860935052943631','test','test','0.3'),('2019-11-12 15:59:59','2019-11-13 01:59:59','EOSETH','4h','0.018729000000000','0.018541710000000','1.381068177161063','1.367257495389452','73.73955775327371','73.739557753273715','test','test','1.0'),('2019-11-15 07:59:59','2019-11-15 15:59:59','EOSETH','4h','0.018734000000000','0.018546660000000','1.377999136767372','1.364219145399698','73.55605512796903','73.556055127969032','test','test','1.0'),('2019-11-15 19:59:59','2019-11-15 23:59:59','EOSETH','4h','0.018559000000000','0.018519000000000','1.374936916463444','1.371973530685194','74.08464445624465','74.084644456244646','test','test','0.2'),('2019-11-18 11:59:59','2019-11-18 15:59:59','EOSETH','4h','0.018542000000000','0.018540000000000','1.374278386290500','1.374130152185626','74.11705243719662','74.117052437196620','test','test','0.0'),('2019-11-26 15:59:59','2019-11-26 23:59:59','EOSETH','4h','0.017888000000000','0.017709120000000','1.374245445378306','1.360502990924523','76.82499135612174','76.824991356121743','test','test','1.0'),('2019-11-29 15:59:59','2019-12-04 03:59:59','EOSETH','4h','0.017979000000000','0.017966000000000','1.371191566610799','1.370200104885122','76.26628659051107','76.266286590511072','test','test','0.1'),('2019-12-04 11:59:59','2019-12-04 15:59:59','EOSETH','4h','0.018042000000000','0.018078000000000','1.370971241782870','1.373706801294243','75.98776420479271','75.987764204792711','test','test','0.0'),('2019-12-04 23:59:59','2019-12-05 23:59:59','EOSETH','4h','0.018059000000000','0.018127000000000','1.371579143896509','1.376743736719199','75.94989445132668','75.949894451326685','test','test','0.0'),('2019-12-06 11:59:59','2019-12-08 15:59:59','EOSETH','4h','0.018307000000000','0.018206000000000','1.372726831190439','1.365153476192338','74.98371285248481','74.983712852484814','test','test','0.6'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSETH','4h','0.018233000000000','0.018137000000000','1.371043863413084','1.363825072710092','75.19573648950166','75.195736489501655','test','test','0.5'),('2019-12-18 15:59:59','2019-12-29 23:59:59','EOSETH','4h','0.018261000000000','0.019976000000000','1.369439687701308','1.498051979712027','74.99259009371382','74.992590093713815','test','test','0.0'),('2019-12-31 15:59:59','2020-01-01 15:59:59','EOSETH','4h','0.020025000000000','0.019923000000000','1.398020197037023','1.390899195284325','69.81374267350927','69.813742673509267','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:29:57
