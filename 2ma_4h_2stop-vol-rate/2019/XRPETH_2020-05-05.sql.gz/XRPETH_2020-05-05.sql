-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.297777777777778','1.307882586235599','503.7292351854871','503.729235185487084','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 19:59:59','XRPETH','4h','0.002702650000000','0.002675623500000','1.300023290768405','1.287023057860721','481.0179974352597','481.017997435259701','test','test','1.0'),('2019-01-18 11:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002681860000000','0.002655041400000','1.297134350122253','1.284163006621031','483.6696733320355','483.669673332035472','test','test','1.0'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.294251829344203','1.298158731321589','482.9297870687326','482.929787068732594','test','test','0.0'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.295120029783622','1.305663935618468','477.3157915276458','477.315791527645786','test','test','0.3'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.297463119969144','1.324714612733211','471.071612170565','471.071612170565004','test','test','0.9'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.303519007250048','1.293748645925827','463.05029972613386','463.050299726133858','test','test','0.7'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002801056500000','1.301347815844665','1.288334337686218','459.9458588879655','459.945858887965528','test','test','1.0'),('2019-02-25 19:59:59','2019-02-26 03:59:59','XRPETH','4h','0.002380130000000','0.002356328700000','1.298455931809455','1.285471372491360','545.539920848632','545.539920848632050','test','test','1.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.295570474183211','1.288175806980689','563.1886673664858','563.188667366485788','test','test','0.6'),('2019-03-04 03:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002392200000000','0.002368278000000','1.293927214804873','1.280987942656824','540.8942458008833','540.894245800883255','test','test','1.0'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.291051820994195','1.285747485752134','556.593414696837','556.593414696837044','test','test','0.4'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.289873079829293','1.291593430233589','556.7477036555996','556.747703655599594','test','test','0.0'),('2019-03-12 19:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002341610000000','0.002332830000000','1.290255379919137','1.285417493919466','551.0120728554868','551.012072855486849','test','test','0.8'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002228757300000','1.289180294141432','1.276288491200018','572.6457928819874','572.645792881987404','test','test','1.0'),('2019-04-26 19:59:59','2019-04-26 23:59:59','XRPETH','4h','0.001921600000000','0.001921710000000','1.286315449043340','1.286389082837780','669.3981312673501','669.398131267350095','test','test','0.0'),('2019-04-30 11:59:59','2019-04-30 23:59:59','XRPETH','4h','0.001933450000000','0.001914115500000','1.286331812108771','1.273468493987683','665.3038930971948','665.303893097194759','test','test','1.0'),('2019-05-14 07:59:59','2019-05-15 15:59:59','XRPETH','4h','0.001834520000000','0.001816174800000','1.283473296970752','1.270638564001044','699.623496593524','699.623496593524010','test','test','1.0'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XRPETH','4h','0.001842670000000','0.001824243300000','1.280621134088594','1.267814922747708','694.9812685334834','694.981268533483444','test','test','1.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XRPETH','4h','0.001600790000000','0.001589290000000','1.277775309346175','1.268595831677348','798.2154494631869','798.215449463186928','test','test','0.7'),('2019-05-28 15:59:59','2019-05-30 03:59:59','XRPETH','4h','0.001638620000000','0.001622233800000','1.275735425419769','1.262978071165571','778.5425696133143','778.542569613314299','test','test','1.0'),('2019-05-30 07:59:59','2019-06-01 03:59:59','XRPETH','4h','0.001638090000000','0.001621709100000','1.272900457807725','1.260171453229648','777.0638107843434','777.063810784343445','test','test','1.0'),('2019-06-02 15:59:59','2019-06-04 19:59:59','XRPETH','4h','0.001635040000000','0.001650030000000','1.270071790123708','1.281715772004246','776.7833142453445','776.783314245344513','test','test','0.0'),('2019-06-06 15:59:59','2019-06-09 19:59:59','XRPETH','4h','0.001675050000000','0.001658299500000','1.272659341652716','1.259932748236189','759.7739420630527','759.773942063052687','test','test','1.0'),('2019-06-17 07:59:59','2019-06-17 11:59:59','XRPETH','4h','0.001598430000000','0.001591290000000','1.269831209782377','1.264159022174633','794.424034698033','794.424034698032983','test','test','0.4'),('2019-06-17 23:59:59','2019-06-18 15:59:59','XRPETH','4h','0.001638130000000','0.001621748700000','1.268570723647323','1.255885016410850','774.4017407942731','774.401740794273110','test','test','1.0'),('2019-07-14 15:59:59','2019-07-25 03:59:59','XRPETH','4h','0.001300820000000','0.001435720000000','1.265751677594773','1.397014958684804','973.0413720536071','973.041372053607120','test','test','0.0'),('2019-07-26 19:59:59','2019-07-27 03:59:59','XRPETH','4h','0.001472340000000','0.001457616600000','1.294921295614780','1.281972082658632','879.4988220212587','879.498822021258661','test','test','1.0'),('2019-07-27 11:59:59','2019-07-29 03:59:59','XRPETH','4h','0.001490000000000','0.001475100000000','1.292043692735636','1.279123255808280','867.14341794338','867.143417943379973','test','test','1.0'),('2019-07-29 11:59:59','2019-07-31 19:59:59','XRPETH','4h','0.001474900000000','0.001465690000000','1.289172484529557','1.281122258356584','874.0745030371938','874.074503037193836','test','test','0.6'),('2019-08-01 03:59:59','2019-08-01 11:59:59','XRPETH','4h','0.001477350000000','0.001462576500000','1.287383545380007','1.274509709926207','871.4140490608232','871.414049060823231','test','test','1.0'),('2019-08-10 11:59:59','2019-08-11 03:59:59','XRPETH','4h','0.001438460000000','0.001424075400000','1.284522693056941','1.271677466126371','892.9846454242321','892.984645424232099','test','test','1.0'),('2019-08-13 15:59:59','2019-08-13 19:59:59','XRPETH','4h','0.001433330000000','0.001418996700000','1.281668198183481','1.268851516201646','894.1891945214854','894.189194521485433','test','test','1.0'),('2019-08-15 11:59:59','2019-08-15 15:59:59','XRPETH','4h','0.001435060000000','0.001420810000000','1.278820046631962','1.266121493495155','891.1265359162418','891.126535916241778','test','test','1.0'),('2019-08-18 11:59:59','2019-08-18 15:59:59','XRPETH','4h','0.001484760000000','0.001469912400000','1.275998145934894','1.263238164475545','859.3969031593616','859.396903159361614','test','test','1.0'),('2019-08-21 15:59:59','2019-08-21 23:59:59','XRPETH','4h','0.001432120000000','0.001418480000000','1.273162594499483','1.261036559119087','889.0055264220057','889.005526422005687','test','test','1.0'),('2019-08-25 07:59:59','2019-08-26 07:59:59','XRPETH','4h','0.001448830000000','0.001434341700000','1.270467919970506','1.257763240770801','876.8923337938242','876.892333793824150','test','test','1.0'),('2019-08-26 19:59:59','2019-08-27 15:59:59','XRPETH','4h','0.001434360000000','0.001427240000000','1.267644657926127','1.261352213934079','883.7702236022527','883.770223602252713','test','test','0.5'),('2019-08-28 19:59:59','2019-09-02 19:59:59','XRPETH','4h','0.001481320000000','0.001466506800000','1.266246337039005','1.253583873668615','854.8094517315674','854.809451731567378','test','test','1.0'),('2019-09-05 11:59:59','2019-09-05 23:59:59','XRPETH','4h','0.001490250000000','0.001475347500000','1.263432456290030','1.250798131727130','847.7989976782619','847.798997678261912','test','test','1.0'),('2019-09-06 19:59:59','2019-09-07 11:59:59','XRPETH','4h','0.001477450000000','0.001468380000000','1.260624828609385','1.252885908716673','853.2436485900608','853.243648590060843','test','test','0.6'),('2019-09-07 15:59:59','2019-09-07 19:59:59','XRPETH','4h','0.001487280000000','0.001472407200000','1.258905068633227','1.246316017946895','846.4479241522962','846.447924152296196','test','test','1.0'),('2019-09-18 03:59:59','2019-09-18 07:59:59','XRPETH','4h','0.001441180000000','0.001426768200000','1.256107501814042','1.243546426795902','871.5826626889369','871.582662688936921','test','test','1.0'),('2019-09-18 11:59:59','2019-09-19 03:59:59','XRPETH','4h','0.001443930000000','0.001429490700000','1.253316151810011','1.240782990291911','867.9895506084167','867.989550608416721','test','test','1.0'),('2019-09-24 19:59:59','2019-09-27 23:59:59','XRPETH','4h','0.001417480000000','0.001403305200000','1.250531004805989','1.238025694757929','882.2212692990298','882.221269299029814','test','test','1.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','XRPETH','4h','0.001499870000000','0.001484871300000','1.247752047017531','1.235274526547356','831.906796600726','831.906796600726011','test','test','1.0'),('2019-10-02 15:59:59','2019-10-02 23:59:59','XRPETH','4h','0.001419830000000','0.001405631700000','1.244979264690825','1.232529472043917','876.8509361619527','876.850936161952745','test','test','1.0'),('2019-10-03 15:59:59','2019-10-03 23:59:59','XRPETH','4h','0.001414710000000','0.001413020000000','1.242212644102624','1.240728707911791','878.0687519722231','878.068751972223140','test','test','0.1'),('2019-10-04 11:59:59','2019-10-04 19:59:59','XRPETH','4h','0.001442560000000','0.001428134400000','1.241882880504661','1.229464051699614','860.8881991076009','860.888199107600940','test','test','1.0'),('2019-10-05 15:59:59','2019-10-09 15:59:59','XRPETH','4h','0.001450000000000','0.001472330000000','1.239123140770206','1.258205637138067','854.5676832897974','854.567683289797401','test','test','0.9'),('2019-10-13 07:59:59','2019-10-23 19:59:59','XRPETH','4h','0.001531070000000','0.001662010000000','1.243363695518620','1.349698508617438','812.0880792639263','812.088079263926261','test','test','0.5'),('2019-10-24 03:59:59','2019-10-25 15:59:59','XRPETH','4h','0.001683660000000','0.001666823400000','1.266993653985024','1.254323717445174','752.5234631606284','752.523463160628353','test','test','1.0'),('2019-11-05 07:59:59','2019-11-05 11:59:59','XRPETH','4h','0.001620680000000','0.001607000000000','1.264178112531724','1.253507309794951','780.0294398226198','780.029439822619793','test','test','0.8'),('2019-11-06 23:59:59','2019-11-07 03:59:59','XRPETH','4h','0.001625170000000','0.001608918300000','1.261806823034663','1.249188754804317','776.4152814995741','776.415281499574121','test','test','1.0'),('2019-11-21 15:59:59','2019-11-25 03:59:59','XRPETH','4h','0.001497950000000','0.001529670000000','1.259002807872364','1.285662956118775','840.4838665325036','840.483866532503612','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XRPETH','4h','0.001551880000000','0.001536361200000','1.264927285260455','1.252278012407850','815.0934899995199','815.093489999519875','test','test','1.0'),('2019-11-27 03:59:59','2019-11-27 07:59:59','XRPETH','4h','0.001509540000000','0.001494444600000','1.262116335737654','1.249495172380277','836.0933368692808','836.093336869280847','test','test','1.0'),('2019-12-05 19:59:59','2019-12-10 15:59:59','XRPETH','4h','0.001492250000000','0.001519640000000','1.259311632769348','1.282426087868395','843.901244945115','843.901244945114968','test','test','0.0'),('2019-12-10 19:59:59','2019-12-12 23:59:59','XRPETH','4h','0.001519510000000','0.001509510000000','1.264448178346914','1.256126757768261','832.1420578653078','832.142057865307834','test','test','0.7'),('2019-12-13 03:59:59','2019-12-13 07:59:59','XRPETH','4h','0.001516890000000','0.001513760000000','1.262598973773880','1.259993686120911','832.3602725140782','832.360272514078247','test','test','0.2'),('2019-12-15 19:59:59','2019-12-16 03:59:59','XRPETH','4h','0.001526590000000','0.001511324100000','1.262020020962109','1.249399820752488','826.692183862143','826.692183862142997','test','test','1.0'),('2019-12-16 19:59:59','2019-12-16 23:59:59','XRPETH','4h','0.001570440000000','0.001554735600000','1.259215532026638','1.246623376706372','801.823394734366','801.823394734366047','test','test','1.0'),('2019-12-20 19:59:59','2019-12-20 23:59:59','XRPETH','4h','0.001510890000000','0.001522910000000','1.256417275288801','1.266412798224932','831.5742875317202','831.574287531720188','test','test','0.0'),('2019-12-25 03:59:59','2019-12-25 07:59:59','XRPETH','4h','0.001505980000000','0.001503020000000','1.258638502607941','1.256164651715021','835.7604367972622','835.760436797262173','test','test','0.2');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:31:50
