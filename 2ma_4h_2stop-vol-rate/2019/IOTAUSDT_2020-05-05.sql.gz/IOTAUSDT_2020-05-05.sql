-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-06 07:59:59','IOTAUSDT','4h','0.361200000000000','0.357588000000000','222.222222222222200','219.999999999999972','615.2331733727082','615.233173372708166','test','test','1.0'),('2019-01-06 19:59:59','2019-01-07 03:59:59','IOTAUSDT','4h','0.373600000000000','0.369864000000000','221.728395061728406','219.511111111111120','593.4914214714358','593.491421471435842','test','test','1.0'),('2019-01-08 11:59:59','2019-01-08 15:59:59','IOTAUSDT','4h','0.366400000000000','0.362736000000000','221.235665294924530','219.023308641975291','603.8091301717373','603.809130171737252','test','test','1.0'),('2019-01-09 19:59:59','2019-01-10 07:59:59','IOTAUSDT','4h','0.363200000000000','0.359568000000000','220.744030483158070','218.536590178326463','607.7754143258757','607.775414325875659','test','test','1.0'),('2019-01-19 11:59:59','2019-01-19 23:59:59','IOTAUSDT','4h','0.314700000000000','0.311553000000000','220.253488193195494','218.050953311263527','699.8839790060232','699.883979006023196','test','test','1.0'),('2019-02-08 15:59:59','2019-02-12 03:59:59','IOTAUSDT','4h','0.265000000000000','0.265800000000000','219.764035997210584','220.427474596447439','829.2982490460777','829.298249046077672','test','test','0.0'),('2019-02-12 19:59:59','2019-02-13 11:59:59','IOTAUSDT','4h','0.274100000000000','0.271359000000000','219.911466797041015','217.712352129070609','802.3037825503138','802.303782550313827','test','test','1.0'),('2019-02-15 11:59:59','2019-02-15 15:59:59','IOTAUSDT','4h','0.272600000000000','0.269874000000000','219.422774648603109','217.228546902117074','804.92580575423','804.925805754230055','test','test','1.0'),('2019-02-15 19:59:59','2019-02-24 15:59:59','IOTAUSDT','4h','0.270400000000000','0.282100000000000','218.935168482717359','228.408324811296495','809.6714810751382','809.671481075138217','test','test','0.0'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTAUSDT','4h','0.292700000000000','0.289773000000000','221.040314333512725','218.829911190177597','755.1770219798863','755.177021979886263','test','test','1.0'),('2019-03-12 23:59:59','2019-03-13 11:59:59','IOTAUSDT','4h','0.282700000000000','0.279873000000000','220.549113634993802','218.343622498643839','780.1525066678238','780.152506667823786','test','test','1.0'),('2019-03-13 15:59:59','2019-03-13 23:59:59','IOTAUSDT','4h','0.283400000000000','0.283800000000000','220.059004493582705','220.369602947349250','776.4961344163116','776.496134416311634','test','test','0.0'),('2019-03-14 07:59:59','2019-03-14 19:59:59','IOTAUSDT','4h','0.286500000000000','0.294500000000000','220.128026372197496','226.274707736866191','768.3351705835864','768.335170583586432','test','test','0.0'),('2019-03-14 23:59:59','2019-03-18 07:59:59','IOTAUSDT','4h','0.297000000000000','0.294030000000000','221.493955564346066','219.279016008702570','745.7708941560473','745.770894156047348','test','test','1.0'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTAUSDT','4h','0.302200000000000','0.299178000000000','221.001746774203070','218.791729306461008','731.309552528799','731.309552528799031','test','test','1.0'),('2019-03-21 19:59:59','2019-03-25 07:59:59','IOTAUSDT','4h','0.305000000000000','0.301950000000000','220.510631781371529','218.305525463557814','722.98567797171','722.985677971709947','test','test','1.0'),('2019-03-27 11:59:59','2019-03-27 19:59:59','IOTAUSDT','4h','0.303300000000000','0.300700000000000','220.020608155190672','218.134509964608782','725.4223809930454','725.422380993045408','test','test','0.9'),('2019-03-27 23:59:59','2019-03-28 11:59:59','IOTAUSDT','4h','0.305700000000000','0.302643000000000','219.601475223950274','217.405460471710796','718.3561505526668','718.356150552666804','test','test','1.0'),('2019-03-29 11:59:59','2019-03-30 07:59:59','IOTAUSDT','4h','0.306600000000000','0.306400000000000','219.113471945674831','218.970540783283667','714.6558119558866','714.655811955886634','test','test','0.1'),('2019-04-01 03:59:59','2019-04-03 23:59:59','IOTAUSDT','4h','0.310500000000000','0.335900000000000','219.081709465143462','237.003369434272742','705.5771641389483','705.577164138948319','test','test','0.0'),('2019-04-07 11:59:59','2019-04-08 07:59:59','IOTAUSDT','4h','0.357400000000000','0.353826000000000','223.064300569394419','220.833657563700484','624.1306675136946','624.130667513694561','test','test','1.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','IOTAUSDT','4h','0.350800000000000','0.347292000000000','222.568602123684627','220.342916102447788','634.4600972739014','634.460097273901397','test','test','1.0'),('2019-04-10 19:59:59','2019-04-10 23:59:59','IOTAUSDT','4h','0.354700000000000','0.351153000000000','222.074005230076438','219.853265177775683','626.0896679731503','626.089667973150313','test','test','1.0'),('2019-04-29 03:59:59','2019-04-30 03:59:59','IOTAUSDT','4h','0.308300000000000','0.305217000000000','221.580507440676257','219.364702366269483','718.7171827462739','718.717182746273920','test','test','1.0'),('2019-05-11 11:59:59','2019-05-23 03:59:59','IOTAUSDT','4h','0.292800000000000','0.383000000000000','221.088106313030352','289.196532506457061','755.0823303040654','755.082330304065408','test','test','0.0'),('2019-05-23 15:59:59','2019-05-23 19:59:59','IOTAUSDT','4h','0.381100000000000','0.378300000000000','236.223312133791865','234.487743322522874','619.8460040246441','619.846004024644117','test','test','0.7'),('2019-05-23 23:59:59','2019-05-24 23:59:59','IOTAUSDT','4h','0.385900000000000','0.382041000000000','235.837630175732073','233.479253873974756','611.1366420723816','611.136642072381619','test','test','1.0'),('2019-05-25 11:59:59','2019-05-25 15:59:59','IOTAUSDT','4h','0.389600000000000','0.385704000000000','235.313546553119323','232.960411087588142','603.9875424874726','603.987542487472638','test','test','1.0'),('2019-05-26 19:59:59','2019-06-03 23:59:59','IOTAUSDT','4h','0.398300000000000','0.444200000000000','234.790627560779086','261.847845248551550','589.4818668360008','589.481866836000790','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 23:59:59','IOTAUSDT','4h','0.438200000000000','0.434200000000000','240.803342602506291','238.605229023295834','549.5283948026159','549.528394802615935','test','test','0.9'),('2019-06-13 15:59:59','2019-06-13 23:59:59','IOTAUSDT','4h','0.444300000000000','0.439857000000000','240.314872918237285','237.911724189054894','540.8842514477544','540.884251447754423','test','test','1.0'),('2019-06-15 19:59:59','2019-06-16 03:59:59','IOTAUSDT','4h','0.437500000000000','0.440600000000000','239.780839867307833','241.479858389796192','548.070491125275','548.070491125274998','test','test','0.9'),('2019-06-16 07:59:59','2019-06-16 11:59:59','IOTAUSDT','4h','0.456100000000000','0.451539000000000','240.158399538971935','237.756815543582206','526.5476858999604','526.547685899960356','test','test','1.0'),('2019-06-16 15:59:59','2019-06-16 19:59:59','IOTAUSDT','4h','0.450500000000000','0.445995000000000','239.624714206663128','237.228467064596487','531.908355619674','531.908355619674012','test','test','1.0'),('2019-06-17 11:59:59','2019-06-17 15:59:59','IOTAUSDT','4h','0.440100000000000','0.435699000000000','239.092214841759414','236.701292693341827','543.2679273841386','543.267927384138602','test','test','1.0'),('2019-06-17 23:59:59','2019-06-18 03:59:59','IOTAUSDT','4h','0.435300000000000','0.430947000000000','238.560898808777750','236.175289820689983','548.0379021566224','548.037902156622408','test','test','1.0'),('2019-06-22 07:59:59','2019-06-22 15:59:59','IOTAUSDT','4h','0.442100000000000','0.451200000000000','238.030763478091558','242.930288354026004','538.409327025767','538.409327025766970','test','test','0.2'),('2019-06-22 19:59:59','2019-06-24 03:59:59','IOTAUSDT','4h','0.452700000000000','0.448173000000000','239.119546783854759','236.728351316016216','528.2075254779209','528.207525477920854','test','test','1.0'),('2019-06-26 03:59:59','2019-06-26 07:59:59','IOTAUSDT','4h','0.473000000000000','0.468270000000000','238.588170013224016','236.202288313091771','504.41473575734466','504.414735757344658','test','test','1.0'),('2019-06-26 11:59:59','2019-06-26 19:59:59','IOTAUSDT','4h','0.479200000000000','0.474408000000000','238.057974079861225','235.677394339062602','496.78208280438486','496.782082804384856','test','test','1.0'),('2019-07-08 19:59:59','2019-07-08 23:59:59','IOTAUSDT','4h','0.410300000000000','0.406197000000000','237.528956359683775','235.153666796086924','578.9153213738332','578.915321373833194','test','test','1.0'),('2019-07-20 15:59:59','2019-07-20 23:59:59','IOTAUSDT','4h','0.331000000000000','0.327690000000000','237.001114234440024','234.631103092095657','716.0154508593354','716.015450859335374','test','test','1.0'),('2019-08-05 11:59:59','2019-08-05 15:59:59','IOTAUSDT','4h','0.294200000000000','0.292700000000000','236.474445091696879','235.268763012711332','803.7880526570253','803.788052657025332','test','test','0.5'),('2019-08-22 19:59:59','2019-08-23 07:59:59','IOTAUSDT','4h','0.261200000000000','0.258588000000000','236.206515740811170','233.844450583403045','904.3128473997365','904.312847399736484','test','test','1.0'),('2019-08-23 15:59:59','2019-08-23 23:59:59','IOTAUSDT','4h','0.262500000000000','0.259875000000000','235.681612372498279','233.324796248773282','897.8347137999934','897.834713799993438','test','test','1.0'),('2019-08-25 11:59:59','2019-08-25 15:59:59','IOTAUSDT','4h','0.272100000000000','0.269379000000000','235.157875456114908','232.806296701553720','864.2332798828185','864.233279882818465','test','test','1.0'),('2019-08-26 03:59:59','2019-08-26 11:59:59','IOTAUSDT','4h','0.271200000000000','0.268488000000000','234.635302399545736','232.288949375550288','865.1744188773811','865.174418877381072','test','test','1.0'),('2019-09-08 15:59:59','2019-09-08 19:59:59','IOTAUSDT','4h','0.246600000000000','0.244134000000000','234.113890616435697','231.772751710271336','949.3669530269087','949.366953026908732','test','test','1.0'),('2019-09-14 15:59:59','2019-09-16 15:59:59','IOTAUSDT','4h','0.246000000000000','0.243540000000000','233.593637526176934','231.257701150915153','949.5676322202314','949.567632220231417','test','test','1.0'),('2019-09-17 11:59:59','2019-09-24 15:59:59','IOTAUSDT','4h','0.249500000000000','0.272600000000000','233.074540553896554','254.653786593155132','934.1664952059982','934.166495205998217','test','test','0.0'),('2019-09-30 19:59:59','2019-09-30 23:59:59','IOTAUSDT','4h','0.264900000000000','0.265400000000000','237.869928562620657','238.318909175234154','897.961225226956','897.961225226956003','test','test','0.0'),('2019-10-01 03:59:59','2019-10-01 15:59:59','IOTAUSDT','4h','0.271900000000000','0.269181000000000','237.969702032090339','235.590005011769421','875.2103789337638','875.210378933763764','test','test','1.0'),('2019-10-01 19:59:59','2019-10-01 23:59:59','IOTAUSDT','4h','0.272300000000000','0.269577000000000','237.440880472019018','235.066471667298856','871.9826679104629','871.982667910462851','test','test','1.0'),('2019-10-02 15:59:59','2019-10-03 11:59:59','IOTAUSDT','4h','0.278000000000000','0.275220000000000','236.913234070970105','234.544101730260394','852.2058779531297','852.205877953129743','test','test','1.0'),('2019-10-04 19:59:59','2019-10-05 03:59:59','IOTAUSDT','4h','0.270400000000000','0.270500000000000','236.386760217479036','236.474181356612775','874.2113913368308','874.211391336830843','test','test','0.3'),('2019-10-05 15:59:59','2019-10-06 07:59:59','IOTAUSDT','4h','0.274200000000000','0.271458000000000','236.406187137286565','234.042125265913683','862.1669844539991','862.166984453999135','test','test','1.0'),('2019-10-06 15:59:59','2019-10-06 19:59:59','IOTAUSDT','4h','0.271300000000000','0.268587000000000','235.880840054759233','233.522031654211617','869.4465169729423','869.446516972942277','test','test','1.0'),('2019-10-07 11:59:59','2019-10-08 11:59:59','IOTAUSDT','4h','0.279700000000000','0.276903000000000','235.356660410193086','233.003093806091158','841.4610668937901','841.461066893790075','test','test','1.0'),('2019-10-09 11:59:59','2019-10-10 11:59:59','IOTAUSDT','4h','0.274600000000000','0.271854000000000','234.833645609281547','232.485309153188695','855.1844341197434','855.184434119743401','test','test','1.0'),('2019-10-13 11:59:59','2019-10-15 19:59:59','IOTAUSDT','4h','0.280700000000000','0.278800000000000','234.311793063483151','232.725785201635546','834.7409799197832','834.740979919783172','test','test','1.0'),('2019-10-17 11:59:59','2019-10-17 15:59:59','IOTAUSDT','4h','0.278400000000000','0.276500000000000','233.959346871961458','232.362641559257725','840.3712172125053','840.371217212505258','test','test','0.7'),('2019-10-25 19:59:59','2019-10-26 03:59:59','IOTAUSDT','4h','0.270600000000000','0.269500000000000','233.604523469138400','232.654911585117532','863.2835309280798','863.283530928079813','test','test','0.4'),('2019-10-26 07:59:59','2019-10-26 11:59:59','IOTAUSDT','4h','0.277100000000000','0.274329000000000','233.393498606022632','231.059563619962375','842.2717380224562','842.271738022456248','test','test','1.0'),('2019-10-27 15:59:59','2019-10-31 07:59:59','IOTAUSDT','4h','0.271500000000000','0.273200000000000','232.874846386898156','234.332994596318883','857.7342408357206','857.734240835720584','test','test','0.7'),('2019-11-04 23:59:59','2019-11-05 07:59:59','IOTAUSDT','4h','0.274000000000000','0.271260000000000','233.198879322324956','230.866890529101681','851.0908004464413','851.090800446441335','test','test','1.0'),('2019-11-05 11:59:59','2019-11-05 15:59:59','IOTAUSDT','4h','0.274100000000000','0.274500000000000','232.680659590497584','233.020215460020410','848.8896738069959','848.889673806995916','test','test','0.0'),('2019-11-05 19:59:59','2019-11-07 11:59:59','IOTAUSDT','4h','0.276900000000000','0.274131000000000','232.756116450391545','230.428555285887597','840.5782464802874','840.578246480287362','test','test','1.0'),('2019-12-29 19:59:59','2019-12-30 03:59:59','IOTAUSDT','4h','0.168300000000000','0.166617000000000','232.238880636057303','229.916491829696753','1379.9101642071141','1379.910164207114121','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:55:46
