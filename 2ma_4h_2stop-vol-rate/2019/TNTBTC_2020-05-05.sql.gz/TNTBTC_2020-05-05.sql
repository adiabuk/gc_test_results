-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003207600000','0.033333333333333','0.033000000000000','10288.0658436214','10288.065843621399836','test','test','1.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','TNTBTC','4h','0.000003410000000','0.000003375900000','0.033259259259259','0.032926666666666','9753.448463125906','9753.448463125905619','test','test','1.0'),('2019-01-12 15:59:59','2019-01-12 19:59:59','TNTBTC','4h','0.000003280000000','0.000003247200000','0.033185349794239','0.032853496296297','10117.484693365448','10117.484693365448038','test','test','1.0'),('2019-01-12 23:59:59','2019-01-13 03:59:59','TNTBTC','4h','0.000003410000000','0.000003375900000','0.033111604572474','0.032780488526749','9710.147968467381','9710.147968467381361','test','test','1.0'),('2019-01-14 19:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003300000000','0.000004210000000','0.033038023228979','0.042148508422425','10011.522190599795','10011.522190599795067','test','test','0.0'),('2019-01-21 15:59:59','2019-01-22 11:59:59','TNTBTC','4h','0.000004500000000','0.000004455000000','0.035062575494190','0.034711949739248','7791.6834431532325','7791.683443153232474','test','test','1.0'),('2019-01-24 15:59:59','2019-01-24 23:59:59','TNTBTC','4h','0.000004500000000','0.000004455000000','0.034984658659758','0.034634812073160','7774.368591057331','7774.368591057331287','test','test','1.0'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004494600000','0.034906914973847','0.034557845824109','7688.747791596329','7688.747791596329080','test','test','1.0'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004187700000','0.034829344051683','0.034481050611166','8233.887482667453','8233.887482667452787','test','test','1.0'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004019400000','0.034751945509346','0.034404426054253','8559.592489986753','8559.592489986753208','test','test','1.0'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.034674718963770','0.034590963603954','8375.535981586954','8375.535981586954222','test','test','0.2'),('2019-02-10 11:59:59','2019-02-10 15:59:59','TNTBTC','4h','0.000004150000000','0.000004108500000','0.034656106661589','0.034309545594973','8350.869075081604','8350.869075081604024','test','test','1.0'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003979800000','0.034579093091230','0.034233302160318','8601.764450554616','8601.764450554615905','test','test','1.0'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003910500000','0.034502250662138','0.034157228155517','8734.747003072911','8734.747003072910957','test','test','1.0'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003920400000','0.034425578994000','0.034081323204060','8693.328028787877','8693.328028787876974','test','test','1.0'),('2019-02-20 23:59:59','2019-02-21 07:59:59','TNTBTC','4h','0.000004070000000','0.000004029300000','0.034349077707347','0.034005586930274','8439.576832271909','8439.576832271908643','test','test','1.0'),('2019-02-21 23:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004020000000','0.000004040000000','0.034272746423553','0.034443257599790','8525.558811829022','8525.558811829021579','test','test','0.2'),('2019-02-26 11:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004160000000','0.000004118400000','0.034310637796050','0.033967531418090','8247.749470204273','8247.749470204273166','test','test','1.0'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004059000000','0.034234391934281','0.033892048014938','8349.85169128802','8349.851691288020447','test','test','1.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.034158315507760','0.033990047943682','8413.378203881828','8413.378203881828085','test','test','0.5'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.034120922715743','0.035387788658159','8445.772949441309','8445.772949441308810','test','test','0.0'),('2019-03-04 23:59:59','2019-03-05 03:59:59','TNTBTC','4h','0.000004290000000','0.000004247100000','0.034402448480724','0.034058423995917','8019.218760075576','8019.218760075576029','test','test','1.0'),('2019-03-05 19:59:59','2019-03-06 03:59:59','TNTBTC','4h','0.000004210000000','0.000004167900000','0.034325998595212','0.033982738609260','8153.443846843599','8153.443846843599204','test','test','1.0'),('2019-03-08 11:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004250000000','0.000004270000000','0.034249718598333','0.034410893744678','8058.757317254902','8058.757317254901864','test','test','0.5'),('2019-03-11 23:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004710000000','0.000004662900000','0.034285535297521','0.033942679944546','7279.306857223166','7279.306857223165935','test','test','1.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.034209345219082','0.033912517928678','7420.682260104603','7420.682260104603301','test','test','0.9'),('2019-03-26 03:59:59','2019-03-26 07:59:59','TNTBTC','4h','0.000004740000000','0.000004692600000','0.034143383598992','0.033801949763002','7203.245485019503','7203.245485019502667','test','test','1.0'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.034067509413217','0.034491586293879','7067.9480110408485','7067.948011040848542','test','test','0.2'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.034161748720031','0.033826006717869','8393.55005406159','8393.550054061590345','test','test','1.0'),('2019-05-21 19:59:59','2019-05-26 23:59:59','TNTBTC','4h','0.000003550000000','0.000003520000000','0.034087139386217','0.033799079053376','9602.011094708985','9602.011094708985183','test','test','0.8'),('2019-05-28 03:59:59','2019-05-28 07:59:59','TNTBTC','4h','0.000003570000000','0.000003640000000','0.034023125978919','0.034690246096153','9530.28738905291','9530.287389052909930','test','test','0.0'),('2019-05-28 11:59:59','2019-05-28 23:59:59','TNTBTC','4h','0.000003950000000','0.000003910500000','0.034171374893860','0.033829661144921','8650.980985787284','8650.980985787284226','test','test','1.0'),('2019-05-31 11:59:59','2019-05-31 15:59:59','TNTBTC','4h','0.000003770000000','0.000003732300000','0.034095438505207','0.033754484120155','9043.882892627764','9043.882892627763795','test','test','1.0'),('2019-06-01 15:59:59','2019-06-01 23:59:59','TNTBTC','4h','0.000003640000000','0.000003670000000','0.034019670864084','0.034300052766810','9346.063424198903','9346.063424198902794','test','test','0.0'),('2019-06-02 15:59:59','2019-06-02 19:59:59','TNTBTC','4h','0.000004180000000','0.000004138200000','0.034081977953579','0.033741158174043','8153.583242482935','8153.583242482935020','test','test','1.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTBTC','4h','0.000003690000000','0.000003653100000','0.034006240224793','0.033666177822545','9215.783258751462','9215.783258751462199','test','test','1.0'),('2019-06-05 11:59:59','2019-06-05 15:59:59','TNTBTC','4h','0.000003810000000','0.000003771900000','0.033930670802071','0.033591364094050','8905.687874559348','8905.687874559347620','test','test','1.0'),('2019-06-05 19:59:59','2019-06-05 23:59:59','TNTBTC','4h','0.000003820000000','0.000003781800000','0.033855269311400','0.033516716618286','8862.635945392612','8862.635945392612484','test','test','1.0'),('2019-06-07 11:59:59','2019-06-13 23:59:59','TNTBTC','4h','0.000003850000000','0.000004100000000','0.033780035379597','0.035973544170480','8774.0351635316','8774.035163531600119','test','test','0.0'),('2019-06-20 15:59:59','2019-06-20 19:59:59','TNTBTC','4h','0.000003990000000','0.000004100000000','0.034267481777571','0.035212199320311','8588.34129763676','8588.341297636759919','test','test','0.0'),('2019-06-20 23:59:59','2019-06-22 03:59:59','TNTBTC','4h','0.000004870000000','0.000004821300000','0.034477419009291','0.034132644819198','7079.5521579652295','7079.552157965229526','test','test','1.0'),('2019-06-25 11:59:59','2019-06-25 15:59:59','TNTBTC','4h','0.000004280000000','0.000004237200000','0.034400802522603','0.034056794497377','8037.5706828512475','8037.570682851247511','test','test','1.0'),('2019-06-25 19:59:59','2019-06-25 23:59:59','TNTBTC','4h','0.000004500000000','0.000004455000000','0.034324356294775','0.033981112731827','7627.634732172297','7627.634732172296935','test','test','1.0'),('2019-06-26 03:59:59','2019-06-26 07:59:59','TNTBTC','4h','0.000004930000000','0.000004880700000','0.034248079947454','0.033905599147979','6946.87220029484','6946.872200294839786','test','test','1.0'),('2019-06-26 11:59:59','2019-06-26 15:59:59','TNTBTC','4h','0.000004800000000','0.000004752000000','0.034171973103126','0.033830253372095','7119.161063151206','7119.161063151205781','test','test','1.0'),('2019-06-26 23:59:59','2019-07-04 07:59:59','TNTBTC','4h','0.000004500000000','0.000005480000000','0.034096035385119','0.041521394202323','7576.896752248643','7576.896752248642770','test','test','0.4'),('2019-07-22 03:59:59','2019-07-23 07:59:59','TNTBTC','4h','0.000004470000000','0.000004425300000','0.035746115122275','0.035388653971052','7996.893763372558','7996.893763372558169','test','test','1.0'),('2019-07-23 15:59:59','2019-07-23 19:59:59','TNTBTC','4h','0.000004420000000','0.000004375800000','0.035666679310892','0.035310012517783','8069.38445947793','8069.384459477930250','test','test','1.0'),('2019-07-29 07:59:59','2019-07-29 11:59:59','TNTBTC','4h','0.000004350000000','0.000004330000000','0.035587420023535','0.035423799701588','8181.016097364343','8181.016097364343295','test','test','0.5'),('2019-07-29 19:59:59','2019-07-30 03:59:59','TNTBTC','4h','0.000004320000000','0.000004290000000','0.035551059951991','0.035304177591213','8229.412025923868','8229.412025923867986','test','test','0.7'),('2019-08-19 03:59:59','2019-08-19 07:59:59','TNTBTC','4h','0.000003080000000','0.000003049200000','0.035496197205152','0.035141235233100','11524.739352321933','11524.739352321932529','test','test','1.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','TNTBTC','4h','0.000003160000000','0.000003128400000','0.035417316766918','0.035063143599249','11208.011635100564','11208.011635100563581','test','test','1.0'),('2019-08-21 11:59:59','2019-08-23 15:59:59','TNTBTC','4h','0.000003130000000','0.000003110000000','0.035338611618547','0.035112805793508','11290.291251931914','11290.291251931914303','test','test','0.6'),('2019-08-24 07:59:59','2019-08-25 15:59:59','TNTBTC','4h','0.000003300000000','0.000003400000000','0.035288432546316','0.036357778987113','10693.464407974547','10693.464407974546702','test','test','0.0'),('2019-08-26 15:59:59','2019-08-26 19:59:59','TNTBTC','4h','0.000003290000000','0.000003257100000','0.035526065088715','0.035170804437828','10798.196075597369','10798.196075597368690','test','test','1.0'),('2019-08-31 07:59:59','2019-08-31 23:59:59','TNTBTC','4h','0.000003260000000','0.000003227400000','0.035447118277407','0.035092647094633','10873.349164848809','10873.349164848808869','test','test','1.0'),('2019-09-10 15:59:59','2019-09-10 19:59:59','TNTBTC','4h','0.000002920000000','0.000002890800000','0.035368346903457','0.035014663434422','12112.447569677171','12112.447569677171487','test','test','1.0'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.035289750577005','0.035036777454589','12648.656120790365','12648.656120790365094','test','test','0.7'),('2019-09-17 11:59:59','2019-09-17 15:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.035233534327579','0.034980964189030','12628.506927447794','12628.506927447793714','test','test','0.7'),('2019-09-17 19:59:59','2019-09-18 03:59:59','TNTBTC','4h','0.000002810000000','0.000002830000000','0.035177407630124','0.035427780638168','12518.650402179359','12518.650402179358935','test','test','0.0'),('2019-09-18 07:59:59','2019-10-10 11:59:59','TNTBTC','4h','0.000002940000000','0.000006620000000','0.035233046076356','0.079334273818189','11984.02927767211','11984.029277672110766','test','test','0.0'),('2019-10-11 15:59:59','2019-10-12 19:59:59','TNTBTC','4h','0.000007120000000','0.000007048800000','0.045033318907874','0.044582985718795','6324.904340993603','6324.904340993603000','test','test','1.0'),('2019-10-14 23:59:59','2019-10-23 15:59:59','TNTBTC','4h','0.000007370000000','0.000009090000000','0.044933244865857','0.055419700926817','6096.776779627802','6096.776779627802171','test','test','0.0'),('2019-10-24 03:59:59','2019-10-25 07:59:59','TNTBTC','4h','0.000009960000000','0.000009860400000','0.047263568434959','0.046790932750609','4745.338196281035','4745.338196281035380','test','test','1.0'),('2019-11-07 11:59:59','2019-11-07 15:59:59','TNTBTC','4h','0.000007720000000','0.000007700000000','0.047158538282881','0.047036365903910','6108.618948559758','6108.618948559757882','test','test','0.3'),('2019-11-08 07:59:59','2019-11-08 15:59:59','TNTBTC','4h','0.000007650000000','0.000007573500000','0.047131388865332','0.046660074976679','6160.965864749311','6160.965864749310640','test','test','1.0'),('2019-11-11 07:59:59','2019-11-11 11:59:59','TNTBTC','4h','0.000007570000000','0.000007530000000','0.047026652445632','0.046778162868641','6212.239424786203','6212.239424786203017','test','test','0.5'),('2019-11-11 15:59:59','2019-11-11 23:59:59','TNTBTC','4h','0.000007750000000','0.000007672500000','0.046971432539634','0.046501718214238','6060.830005114008','6060.830005114007690','test','test','1.0'),('2019-11-13 11:59:59','2019-11-18 19:59:59','TNTBTC','4h','0.000007860000000','0.000008490000000','0.046867051578434','0.050623570979759','5962.729208452221','5962.729208452221428','test','test','0.0'),('2019-11-23 11:59:59','2019-11-24 11:59:59','TNTBTC','4h','0.000008470000000','0.000008385300000','0.047701833667618','0.047224815330942','5631.857575869868','5631.857575869868015','test','test','1.0'),('2019-11-25 07:59:59','2019-12-04 07:59:59','TNTBTC','4h','0.000008420000000','0.000009260000000','0.047595829592801','0.052344107129375','5652.711353064238','5652.711353064238210','test','test','0.0'),('2019-12-04 15:59:59','2019-12-05 11:59:59','TNTBTC','4h','0.000009240000000','0.000009147600000','0.048651002378706','0.048164492354919','5265.259997695479','5265.259997695478887','test','test','1.0'),('2020-01-01 03:59:59','2020-01-01 15:59:59','TNTBTC','4h','0.000006190000000','0.000006640000000','0.048542889040087','0.052071855125392','7842.146856233747','7842.146856233746803','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:13:39
