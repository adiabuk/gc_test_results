-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.033333333333333','0.033979491501615','1404.6916701783957','1404.691670178395725','test','test','0.0'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.033476924037396','0.055598115655726','1405.412428102267','1405.412428102267086','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000041639400000','0.038392744397025','0.038008816953055','912.8089490495693','912.808949049569264','test','test','1.0'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000039600000000','0.038307427187254','0.037924352915381','957.6856796813443','957.685679681344254','test','test','1.0'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035818200000','0.038222299571282','0.037840076575569','1056.4483021360418','1056.448302136041775','test','test','1.0'),('2019-02-11 15:59:59','2019-02-11 19:59:59','OAXBTC','4h','0.000037480000000','0.000037105200000','0.038137361127790','0.037755987516512','1017.538984199312','1017.538984199312040','test','test','1.0'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000036966600000','0.038052611436395','0.037672085322031','1019.0843984037255','1019.084398403725459','test','test','1.0'),('2019-02-13 15:59:59','2019-02-14 15:59:59','OAXBTC','4h','0.000036040000000','0.000035880000000','0.037968050077648','0.037799490476859','1053.4975049291772','1053.497504929177239','test','test','0.4'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033521400000','0.037930592388583','0.037551286464697','1120.2183221672574','1120.218322167257384','test','test','1.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.037846302183275','0.037971847817779','1141.3239500384598','1141.323950038459770','test','test','0.0'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033382800000','0.037874201213165','0.037495459201033','1123.1969517545997','1123.196951754599695','test','test','1.0'),('2019-03-06 19:59:59','2019-03-07 11:59:59','OAXBTC','4h','0.000033860000000','0.000033521400000','0.037790036321580','0.037412135958364','1116.067227453639','1116.067227453638907','test','test','1.0'),('2019-03-08 11:59:59','2019-03-09 19:59:59','OAXBTC','4h','0.000034730000000','0.000034382700000','0.037706058463088','0.037328997878457','1085.6912888882168','1085.691288888216832','test','test','1.0'),('2019-03-10 07:59:59','2019-03-10 19:59:59','OAXBTC','4h','0.000035410000000','0.000035055900000','0.037622267222059','0.037246044549838','1062.4757758276944','1062.475775827694406','test','test','1.0'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.037538662183787','0.040212356071521','1069.4775550936563','1069.477555093656292','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','OAXBTC','4h','0.000040500000000','0.000040095000000','0.038132816381062','0.037751488217251','941.5510217546062','941.551021754606154','test','test','1.0'),('2019-03-19 07:59:59','2019-03-19 11:59:59','OAXBTC','4h','0.000040490000000','0.000040085100000','0.038048076789104','0.037667596021213','939.6907085478773','939.690708547877307','test','test','1.0'),('2019-03-19 19:59:59','2019-03-20 03:59:59','OAXBTC','4h','0.000039730000000','0.000039332700000','0.037963525507350','0.037583890252277','955.5380193141203','955.538019314120334','test','test','1.0'),('2019-03-21 11:59:59','2019-03-21 15:59:59','OAXBTC','4h','0.000039480000000','0.000039085200000','0.037879162117334','0.037500370496161','959.4519279973093','959.451927997309326','test','test','1.0'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.037794986201518','0.087334791552239','988.6211405052984','988.621140505298399','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','OAXBTC','4h','0.000091990000000','0.000091070100000','0.048803831835011','0.048315793516661','530.5340997392228','530.534099739222825','test','test','1.0'),('2019-03-27 07:59:59','2019-03-27 11:59:59','OAXBTC','4h','0.000109800000000','0.000108702000000','0.048695378875378','0.048208425086624','443.49161088686503','443.491610886865033','test','test','1.0'),('2019-04-01 03:59:59','2019-04-02 03:59:59','OAXBTC','4h','0.000054970000000','0.000054420300000','0.048587166922321','0.048101295253098','883.8851541262751','883.885154126275097','test','test','1.0'),('2019-04-09 19:59:59','2019-04-09 23:59:59','OAXBTC','4h','0.000054850000000','0.000054301500000','0.048479195440272','0.047994403485869','883.8504182364957','883.850418236495670','test','test','1.0'),('2019-04-10 03:59:59','2019-04-10 07:59:59','OAXBTC','4h','0.000057000000000','0.000056430000000','0.048371463894849','0.047887749255901','848.6221735938402','848.622173593840216','test','test','1.0'),('2019-04-10 15:59:59','2019-04-10 19:59:59','OAXBTC','4h','0.000053010000000','0.000052479900000','0.048263971752860','0.047781332035331','910.4691898294745','910.469189829474544','test','test','1.0'),('2019-04-11 23:59:59','2019-04-12 03:59:59','OAXBTC','4h','0.000052690000000','0.000052420000000','0.048156718482298','0.047909948431240','913.9631520648785','913.963152064878500','test','test','0.5'),('2019-04-12 11:59:59','2019-04-12 15:59:59','OAXBTC','4h','0.000057250000000','0.000056677500000','0.048101880693174','0.047620861886242','840.2075230248812','840.207523024881198','test','test','1.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','OAXBTC','4h','0.000047010000000','0.000046539900000','0.047994987624967','0.047515037748717','1020.9527254832448','1020.952725483244762','test','test','1.0'),('2019-04-20 23:59:59','2019-04-21 03:59:59','OAXBTC','4h','0.000047450000000','0.000046975500000','0.047888332096912','0.047409448775943','1009.2377681119448','1009.237768111944774','test','test','1.0'),('2019-05-15 23:59:59','2019-05-16 03:59:59','OAXBTC','4h','0.000028040000000','0.000027759600000','0.047781913581141','0.047304094445330','1704.0625385570931','1704.062538557093148','test','test','1.0'),('2019-05-20 11:59:59','2019-05-20 15:59:59','OAXBTC','4h','0.000027360000000','0.000027086400000','0.047675731550961','0.047198974235451','1742.534047915229','1742.534047915228939','test','test','1.0'),('2019-05-21 03:59:59','2019-05-21 07:59:59','OAXBTC','4h','0.000027770000000','0.000027492300000','0.047569785480847','0.047094087626039','1712.991915046717','1712.991915046716940','test','test','1.0'),('2019-05-21 19:59:59','2019-05-21 23:59:59','OAXBTC','4h','0.000027740000000','0.000027462600000','0.047464074846446','0.046989434097982','1711.033700304454','1711.033700304453987','test','test','1.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','OAXBTC','4h','0.000030580000000','0.000030274200000','0.047358599124565','0.046885013133319','1548.6788464540439','1548.678846454043878','test','test','1.0'),('2019-06-07 07:59:59','2019-06-07 11:59:59','OAXBTC','4h','0.000025900000000','0.000025641000000','0.047253357793177','0.046780824215245','1824.45396884852','1824.453968848519935','test','test','1.0'),('2019-06-07 15:59:59','2019-06-07 19:59:59','OAXBTC','4h','0.000026830000000','0.000026561700000','0.047148350331414','0.046676866828100','1757.29967690697','1757.299676906970035','test','test','1.0'),('2019-06-07 23:59:59','2019-06-08 07:59:59','OAXBTC','4h','0.000026640000000','0.000026373600000','0.047043576219566','0.046573140457370','1765.9000082419836','1765.900008241983642','test','test','1.0'),('2019-06-08 11:59:59','2019-06-08 15:59:59','OAXBTC','4h','0.000027410000000','0.000027135900000','0.046939034939078','0.046469644589687','1712.4784727865174','1712.478472786517386','test','test','1.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','OAXBTC','4h','0.000026520000000','0.000026254800000','0.046834725972547','0.046366378712822','1766.0153081654266','1766.015308165426632','test','test','1.0'),('2019-06-11 11:59:59','2019-06-12 15:59:59','OAXBTC','4h','0.000027690000000','0.000027413100000','0.046730648803719','0.046263342315682','1687.6362876027204','1687.636287602720358','test','test','1.0'),('2019-06-14 07:59:59','2019-06-14 11:59:59','OAXBTC','4h','0.000027370000000','0.000027096300000','0.046626802917489','0.046160534888314','1703.5733619835178','1703.573361983517771','test','test','1.0'),('2019-06-15 07:59:59','2019-06-15 15:59:59','OAXBTC','4h','0.000027880000000','0.000027601200000','0.046523187799894','0.046057955921895','1668.6939669976487','1668.693966997648658','test','test','1.0'),('2019-07-26 11:59:59','2019-07-26 19:59:59','OAXBTC','4h','0.000010620000000','0.000010513800000','0.046419802938117','0.045955604908736','4370.979561027956','4370.979561027956152','test','test','1.0'),('2019-07-27 15:59:59','2019-07-30 15:59:59','OAXBTC','4h','0.000010560000000','0.000010840000000','0.046316647820477','0.047544740755111','4386.046195120896','4386.046195120896300','test','test','0.6'),('2019-08-14 03:59:59','2019-08-14 07:59:59','OAXBTC','4h','0.000008240000000','0.000008157600000','0.046589557361506','0.046123661787891','5654.072495328452','5654.072495328451623','test','test','1.0'),('2019-08-21 15:59:59','2019-08-22 07:59:59','OAXBTC','4h','0.000007590000000','0.000007514100000','0.046486025011814','0.046021164761696','6124.640976523613','6124.640976523613062','test','test','1.0'),('2019-08-22 15:59:59','2019-08-22 23:59:59','OAXBTC','4h','0.000007680000000','0.000007603200000','0.046382722734010','0.045918895506670','6039.417022657582','6039.417022657581583','test','test','1.0'),('2019-08-24 11:59:59','2019-08-25 23:59:59','OAXBTC','4h','0.000007900000000','0.000007821000000','0.046279650016824','0.045816853516656','5858.183546433361','5858.183546433360789','test','test','1.0'),('2019-08-26 07:59:59','2019-08-26 11:59:59','OAXBTC','4h','0.000008200000000','0.000008118000000','0.046176806350120','0.045715038286619','5631.317847575556','5631.317847575555788','test','test','1.0'),('2019-08-26 15:59:59','2019-08-26 19:59:59','OAXBTC','4h','0.000008220000000','0.000008137800000','0.046074191224897','0.045613449312648','5605.132752420574','5605.132752420574434','test','test','1.0'),('2019-08-27 15:59:59','2019-08-29 07:59:59','OAXBTC','4h','0.000008290000000','0.000008207100000','0.045971804133286','0.045512086091953','5545.452850818603','5545.452850818603110','test','test','1.0'),('2019-08-31 07:59:59','2019-08-31 11:59:59','OAXBTC','4h','0.000008880000000','0.000008791200000','0.045869644568546','0.045410948122861','5165.500514475852','5165.500514475851560','test','test','1.0'),('2019-09-10 07:59:59','2019-09-10 11:59:59','OAXBTC','4h','0.000007380000000','0.000007306200000','0.045767712025060','0.045310034904809','6201.586995265583','6201.586995265583028','test','test','1.0'),('2019-09-10 15:59:59','2019-09-11 03:59:59','OAXBTC','4h','0.000007210000000','0.000007137900000','0.045666005998338','0.045209345938355','6333.704021960826','6333.704021960826140','test','test','1.0'),('2019-09-11 15:59:59','2019-09-11 19:59:59','OAXBTC','4h','0.000007340000000','0.000007266600000','0.045564525985008','0.045108880725158','6207.701087875748','6207.701087875748271','test','test','1.0'),('2019-09-15 23:59:59','2019-09-16 03:59:59','OAXBTC','4h','0.000007390000000','0.000007316100000','0.045463271482819','0.045008638767991','6151.9988474721395','6151.998847472139460','test','test','1.0'),('2019-09-16 15:59:59','2019-09-16 23:59:59','OAXBTC','4h','0.000007100000000','0.000007150000000','0.045362241990635','0.045681694399020','6389.048167695086','6389.048167695085795','test','test','0.0'),('2019-09-17 15:59:59','2019-09-17 19:59:59','OAXBTC','4h','0.000007640000000','0.000007563600000','0.045433231414721','0.044978899100574','5946.758038576004','5946.758038576003855','test','test','1.0'),('2019-09-17 23:59:59','2019-09-23 23:59:59','OAXBTC','4h','0.000007580000000','0.000007504200000','0.045332268678244','0.044878945991462','5980.510379715508','5980.510379715507952','test','test','1.0'),('2019-09-27 11:59:59','2019-09-27 15:59:59','OAXBTC','4h','0.000007500000000','0.000007425000000','0.045231530303403','0.044779215000369','6030.870707120414','6030.870707120414409','test','test','1.0'),('2019-09-27 19:59:59','2019-09-27 23:59:59','OAXBTC','4h','0.000007580000000','0.000007560000000','0.045131015791618','0.045011936594279','5953.959866968044','5953.959866968043571','test','test','0.3'),('2019-09-30 23:59:59','2019-10-01 03:59:59','OAXBTC','4h','0.000008150000000','0.000008068500000','0.045104553747765','0.044653508210287','5534.301073345358','5534.301073345358418','test','test','1.0'),('2019-10-01 19:59:59','2019-10-01 23:59:59','OAXBTC','4h','0.000009170000000','0.000009078300000','0.045004321406103','0.044554278192042','4907.7776887789405','4907.777688778940501','test','test','1.0'),('2019-10-02 03:59:59','2019-10-02 15:59:59','OAXBTC','4h','0.000009210000000','0.000009117900000','0.044904311802978','0.044455268684948','4875.60388740263','4875.603887402629880','test','test','1.0'),('2019-10-05 07:59:59','2019-10-05 15:59:59','OAXBTC','4h','0.000009140000000','0.000009048600000','0.044804524443416','0.044356479198982','4902.026744356236','4902.026744356236122','test','test','1.0'),('2019-10-06 03:59:59','2019-10-09 15:59:59','OAXBTC','4h','0.000009250000000','0.000009157500000','0.044704958833542','0.044257909245207','4832.968522545058','4832.968522545057567','test','test','1.0'),('2019-10-16 19:59:59','2019-10-17 03:59:59','OAXBTC','4h','0.000009010000000','0.000008919900000','0.044605614480578','0.044159558335772','4950.678632694611','4950.678632694611224','test','test','1.0'),('2019-10-17 15:59:59','2019-10-17 19:59:59','OAXBTC','4h','0.000009260000000','0.000009167400000','0.044506490892844','0.044061425983916','4806.31651110624','4806.316511106239886','test','test','1.0'),('2019-10-24 15:59:59','2019-10-25 07:59:59','OAXBTC','4h','0.000008540000000','0.000008570000000','0.044407587579749','0.044563586130966','5199.951707230523','5199.951707230523425','test','test','0.0'),('2019-10-28 15:59:59','2019-10-28 19:59:59','OAXBTC','4h','0.000008040000000','0.000007959600000','0.044442253924464','0.043997831385219','5527.643522943229','5527.643522943229073','test','test','1.0'),('2019-11-01 19:59:59','2019-11-01 23:59:59','OAXBTC','4h','0.000008400000000','0.000008316000000','0.044343493360187','0.043900058426585','5278.987304784154','5278.987304784153821','test','test','1.0'),('2019-11-02 19:59:59','2019-11-04 07:59:59','OAXBTC','4h','0.000008470000000','0.000008385300000','0.044244952263831','0.043802502741193','5223.725178728558','5223.725178728557694','test','test','1.0'),('2019-11-07 23:59:59','2019-11-08 03:59:59','OAXBTC','4h','0.000008220000000','0.000008220000000','0.044146630147689','0.044146630147689','5370.636271008408','5370.636271008407675','test','test','0.0'),('2019-11-13 15:59:59','2019-11-13 23:59:59','OAXBTC','4h','0.000008220000000','0.000008170000000','0.044146630147689','0.043878098334139','5370.636271008408','5370.636271008407675','test','test','0.6'),('2019-11-17 11:59:59','2019-11-17 23:59:59','OAXBTC','4h','0.000008310000000','0.000008300000000','0.044086956411345','0.044033903515543','5305.28958018588','5305.289580185880368','test','test','0.7'),('2019-11-18 11:59:59','2019-11-18 15:59:59','OAXBTC','4h','0.000008400000000','0.000008316000000','0.044075166878944','0.043634415210155','5247.043676064789','5247.043676064788997','test','test','1.0'),('2019-11-20 03:59:59','2019-11-20 07:59:59','OAXBTC','4h','0.000008190000000','0.000008110000000','0.043977222063658','0.043547652128970','5369.6241835967985','5369.624183596798503','test','test','1.0'),('2019-11-20 15:59:59','2019-11-20 19:59:59','OAXBTC','4h','0.000008310000000','0.000008240000000','0.043881762078172','0.043512120279680','5280.597121320283','5280.597121320282895','test','test','0.8'),('2019-11-21 07:59:59','2019-11-21 11:59:59','OAXBTC','4h','0.000008560000000','0.000008474400000','0.043799619456284','0.043361623261721','5116.777973865006','5116.777973865006061','test','test','1.0'),('2019-11-26 03:59:59','2019-11-26 07:59:59','OAXBTC','4h','0.000008060000000','0.000007980000000','0.043702286968604','0.043268517370901','5422.119971290791','5422.119971290791000','test','test','1.0'),('2019-11-26 11:59:59','2019-11-27 11:59:59','OAXBTC','4h','0.000008310000000','0.000008226900000','0.043605893724670','0.043169834787423','5247.399966867602','5247.399966867602416','test','test','1.0'),('2019-11-29 19:59:59','2019-11-30 03:59:59','OAXBTC','4h','0.000008200000000','0.000008118000000','0.043508991738615','0.043073901821229','5305.974602270108','5305.974602270108335','test','test','1.0'),('2019-11-30 23:59:59','2019-12-01 03:59:59','OAXBTC','4h','0.000008440000000','0.000008355600000','0.043412305090307','0.042978182039404','5143.638043875223','5143.638043875223048','test','test','1.0'),('2019-12-01 11:59:59','2019-12-01 23:59:59','OAXBTC','4h','0.000008510000000','0.000008424900000','0.043315833301217','0.042882674968205','5089.992162305209','5089.992162305208694','test','test','1.0'),('2019-12-02 15:59:59','2019-12-04 15:59:59','OAXBTC','4h','0.000008470000000','0.000008385300000','0.043219575893881','0.042787380134942','5102.665394791185','5102.665394791184553','test','test','1.0'),('2019-12-06 15:59:59','2019-12-06 19:59:59','OAXBTC','4h','0.000008520000000','0.000008434800000','0.043123532391895','0.042692297067976','5061.447463837429','5061.447463837428586','test','test','1.0'),('2019-12-09 11:59:59','2019-12-09 15:59:59','OAXBTC','4h','0.000008680000000','0.000008593200000','0.043027702319913','0.042597425296714','4957.108562201945','4957.108562201944551','test','test','1.0'),('2019-12-21 19:59:59','2019-12-21 23:59:59','OAXBTC','4h','0.000007670000000','0.000007593300000','0.042932085203646','0.042502764351610','5597.40354675964','5597.403546759640449','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:05:09
