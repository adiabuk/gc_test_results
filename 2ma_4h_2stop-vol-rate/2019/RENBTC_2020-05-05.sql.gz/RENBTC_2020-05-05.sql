-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-24 11:59:59','2019-05-24 15:59:59','RENBTC','4h','0.000004500000000','0.000004455000000','0.033333333333333','0.033000000000000','7407.407407407407','7407.407407407406936','test','test','1.0'),('2019-05-29 23:59:59','2019-05-30 03:59:59','RENBTC','4h','0.000004040000000','0.000004020000000','0.033259259259259','0.033094609460946','8232.48991565825','8232.489915658250538','test','test','0.5'),('2019-05-30 23:59:59','2019-06-14 03:59:59','RENBTC','4h','0.000004260000000','0.000005810000000','0.033222670415190','0.045310731247008','7798.748923753468','7798.748923753468262','test','test','0.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBTC','4h','0.000005820000000','0.000005761800000','0.035908906155594','0.035549817094038','6169.915147009239','6169.915147009239263','test','test','1.0'),('2019-06-16 19:59:59','2019-06-17 11:59:59','RENBTC','4h','0.000005610000000','0.000005553900000','0.035829108586359','0.035470817500495','6386.650371900019','6386.650371900019309','test','test','1.0'),('2019-06-20 23:59:59','2019-06-21 03:59:59','RENBTC','4h','0.000005450000000','0.000005395500000','0.035749488345056','0.035391993461605','6559.539145881835','6559.539145881834884','test','test','1.0'),('2019-06-22 15:59:59','2019-06-23 11:59:59','RENBTC','4h','0.000005430000000','0.000005400000000','0.035670045037622','0.035472972965591','6569.069067702107','6569.069067702106622','test','test','0.6'),('2019-06-26 15:59:59','2019-06-26 19:59:59','RENBTC','4h','0.000005510000000','0.000005454900000','0.035626251243838','0.035269988731400','6465.744327375277','6465.744327375276953','test','test','1.0'),('2019-06-26 23:59:59','2019-06-27 03:59:59','RENBTC','4h','0.000005420000000','0.000005365800000','0.035547081796629','0.035191610978663','6558.502176499877','6558.502176499877351','test','test','1.0'),('2019-06-27 07:59:59','2019-06-27 11:59:59','RENBTC','4h','0.000005640000000','0.000005583600000','0.035468088281526','0.035113407398711','6288.668135022301','6288.668135022300703','test','test','1.0'),('2019-06-27 19:59:59','2019-07-04 11:59:59','RENBTC','4h','0.000005710000000','0.000008320000000','0.035389270307567','0.051565451656560','6197.770631798054','6197.770631798053728','test','test','0.0'),('2019-07-04 19:59:59','2019-07-04 23:59:59','RENBTC','4h','0.000009380000000','0.000009286200000','0.038983977274010','0.038594137501270','4156.074336248377','4156.074336248377222','test','test','1.0'),('2019-07-09 19:59:59','2019-07-10 03:59:59','RENBTC','4h','0.000008000000000','0.000008400000000','0.038897346213401','0.040842213524071','4862.168276675111','4862.168276675110974','test','test','0.0'),('2019-07-10 15:59:59','2019-07-13 03:59:59','RENBTC','4h','0.000007900000000','0.000008150000000','0.039329538949105','0.040574144612051','4978.422651785484','4978.422651785484049','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBTC','4h','0.000007760000000','0.000007682400000','0.039606117985316','0.039210056805463','5103.8811836746845','5103.881183674684507','test','test','1.0'),('2019-07-19 23:59:59','2019-07-30 11:59:59','RENBTC','4h','0.000007810000000','0.000010690000000','0.039518104389793','0.054090721629563','5059.936541586769','5059.936541586768726','test','test','0.0'),('2019-08-02 11:59:59','2019-08-03 03:59:59','RENBTC','4h','0.000011380000000','0.000011266200000','0.042756463776408','0.042328899138644','3757.158504078051','3757.158504078051010','test','test','1.0'),('2019-08-04 19:59:59','2019-08-04 23:59:59','RENBTC','4h','0.000011550000000','0.000011434500000','0.042661449412461','0.042234834918336','3693.6319837628284','3693.631983762828440','test','test','1.0'),('2019-08-05 03:59:59','2019-08-05 11:59:59','RENBTC','4h','0.000012200000000','0.000012078000000','0.042566646191544','0.042140979729629','3489.0693599626225','3489.069359962622457','test','test','1.0'),('2019-08-05 23:59:59','2019-08-06 07:59:59','RENBTC','4h','0.000012070000000','0.000011949300000','0.042472053644452','0.042047333108007','3518.8114038485314','3518.811403848531427','test','test','1.0'),('2019-08-09 19:59:59','2019-08-09 23:59:59','RENBTC','4h','0.000010980000000','0.000010870200000','0.042377671303020','0.041953894589990','3859.5329055573366','3859.532905557336562','test','test','1.0'),('2019-08-15 23:59:59','2019-08-16 03:59:59','RENBTC','4h','0.000010240000000','0.000010137600000','0.042283498700124','0.041860663713123','4129.247919933984','4129.247919933984122','test','test','1.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','RENBTC','4h','0.000004570000000','0.000004524300000','0.042189535369679','0.041767640015982','9231.84581393421','9231.845813934209218','test','test','1.0'),('2019-09-19 15:59:59','2019-09-22 19:59:59','RENBTC','4h','0.000004960000000','0.000004910400000','0.042095780846636','0.041674823038170','8487.052590047491','8487.052590047491321','test','test','1.0'),('2019-09-27 11:59:59','2019-09-27 23:59:59','RENBTC','4h','0.000004800000000','0.000004752000000','0.042002234666976','0.041582212320306','8750.465555620092','8750.465555620092346','test','test','1.0'),('2019-09-29 19:59:59','2019-09-30 03:59:59','RENBTC','4h','0.000005100000000','0.000005049000000','0.041908896367716','0.041489807404039','8217.430660336557','8217.430660336556684','test','test','1.0'),('2019-09-30 19:59:59','2019-09-30 23:59:59','RENBTC','4h','0.000004800000000','0.000004752000000','0.041815765486899','0.041397607832030','8711.617809770694','8711.617809770694294','test','test','1.0'),('2019-10-02 07:59:59','2019-10-02 11:59:59','RENBTC','4h','0.000005140000000','0.000005088600000','0.041722841563595','0.041305613147959','8117.2843508939895','8117.284350893989540','test','test','1.0'),('2019-10-04 15:59:59','2019-10-16 15:59:59','RENBTC','4h','0.000005070000000','0.000006740000000','0.041630124137898','0.055342610786870','8211.069849684067','8211.069849684066867','test','test','0.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','RENBTC','4h','0.000006970000000','0.000006900300000','0.044677343393225','0.044230569959293','6409.9488369046385','6409.948836904638483','test','test','1.0'),('2019-10-21 07:59:59','2019-10-21 11:59:59','RENBTC','4h','0.000006830000000','0.000006820000000','0.044578060407907','0.044512792383884','6526.8024023290045','6526.802402329004508','test','test','0.1'),('2019-10-22 11:59:59','2019-10-23 15:59:59','RENBTC','4h','0.000006970000000','0.000006900300000','0.044563556402569','0.044117920838543','6393.623587169104','6393.623587169104212','test','test','1.0'),('2019-10-24 07:59:59','2019-10-25 15:59:59','RENBTC','4h','0.000007030000000','0.000006959700000','0.044464526277230','0.044019881014458','6324.9681759928235','6324.968175992823490','test','test','1.0'),('2019-11-06 15:59:59','2019-11-06 19:59:59','RENBTC','4h','0.000006360000000','0.000006296400000','0.044365716218836','0.043922059056648','6975.741543842103','6975.741543842103056','test','test','1.0'),('2019-11-06 23:59:59','2019-11-07 07:59:59','RENBTC','4h','0.000006460000000','0.000006395400000','0.044267125738350','0.043824454480966','6852.496244326555','6852.496244326554915','test','test','1.0'),('2019-11-09 19:59:59','2019-11-10 19:59:59','RENBTC','4h','0.000006450000000','0.000006385500000','0.044168754347820','0.043727066804342','6847.868891134849','6847.868891134849036','test','test','1.0'),('2019-11-11 11:59:59','2019-11-17 07:59:59','RENBTC','4h','0.000006360000000','0.000006610000000','0.044070601560380','0.045802936527376','6929.339867984311','6929.339867984311240','test','test','0.0'),('2019-11-17 15:59:59','2019-11-17 23:59:59','RENBTC','4h','0.000006570000000','0.000006580000000','0.044455564886379','0.044523229368702','6766.448232325621','6766.448232325620666','test','test','0.5'),('2019-11-23 19:59:59','2019-11-23 23:59:59','RENBTC','4h','0.000006410000000','0.000006420000000','0.044470601438007','0.044539978351327','6937.691331982318','6937.691331982317934','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','RENBTC','4h','0.000005310000000','0.000005256900000','0.044486018529856','0.044041158344557','8377.78126739276','8377.781267392760128','test','test','1.0'),('2019-12-15 07:59:59','2019-12-15 11:59:59','RENBTC','4h','0.000005010000000','0.000004970000000','0.044387160710900','0.044032772202230','8859.71271674655','8859.712716746549631','test','test','0.8'),('2019-12-15 23:59:59','2019-12-16 07:59:59','RENBTC','4h','0.000005050000000','0.000004999500000','0.044308407708974','0.043865323631884','8773.942120588821','8773.942120588821126','test','test','1.0'),('2019-12-24 15:59:59','2019-12-25 03:59:59','RENBTC','4h','0.000004810000000','0.000004761900000','0.044209944580731','0.043767845134924','9191.256669590713','9191.256669590713500','test','test','1.0'),('2019-12-25 07:59:59','2019-12-25 11:59:59','RENBTC','4h','0.000004940000000','0.000004890600000','0.044111700259441','0.043670583256847','8929.493979643903','8929.493979643903003','test','test','1.0'),('2019-12-31 11:59:59','2019-12-31 15:59:59','RENBTC','4h','0.000004500000000','0.000004480000000','0.044013674258864','0.043818057928825','9780.816501969875','9780.816501969875389','test','test','0.4'),('2020-01-02 03:59:59','2020-01-05 03:59:59','RENBTC','4h','0.000004540000000','0.000004670000000','0.043970203963300','0.045229262667095','9685.06695226877','9685.066952268769455','test','test','0.7'),('2020-01-06 07:59:59','2020-01-06 19:59:59','RENBTC','4h','0.000005100000000','0.000005049000000','0.044249994786366','0.043807494838502','8676.469565954072','8676.469565954072095','test','test','1.0'),('2020-01-06 23:59:59','2020-01-07 15:59:59','RENBTC','4h','0.000005160000000','0.000005108400000','0.044151661464618','0.043710144849972','8556.523539654692','8556.523539654692286','test','test','1.0'),('2020-01-08 19:59:59','2020-01-08 23:59:59','RENBTC','4h','0.000005090000000','0.000005039100000','0.044053546661364','0.043613011194750','8654.920758617593','8654.920758617592583','test','test','1.0'),('2020-01-09 03:59:59','2020-01-09 07:59:59','RENBTC','4h','0.000005090000000','0.000005039100000','0.043955649891005','0.043516093392095','8635.687601376205','8635.687601376204839','test','test','1.0'),('2020-01-09 15:59:59','2020-01-09 23:59:59','RENBTC','4h','0.000005420000000','0.000005365800000','0.043857970669025','0.043419390962335','8091.876507200164','8091.876507200164269','test','test','1.0'),('2020-01-10 07:59:59','2020-01-10 11:59:59','RENBTC','4h','0.000005720000000','0.000005662800000','0.043760508511983','0.043322903426863','7650.43855104592','7650.438551045919667','test','test','1.0'),('2020-01-11 15:59:59','2020-01-12 23:59:59','RENBTC','4h','0.000005580000000','0.000005524200000','0.043663262937512','0.043226630308137','7824.957515683073','7824.957515683073325','test','test','1.0'),('2020-01-26 07:59:59','2020-01-26 11:59:59','RENBTC','4h','0.000004930000000','0.000004890000000','0.043566233464317','0.043212754896655','8836.96419154505','8836.964191545050198','test','test','0.8'),('2020-02-02 15:59:59','2020-02-02 19:59:59','RENBTC','4h','0.000004770000000','0.000004890000000','0.043487682671503','0.044581712424245','9116.914606185184','9116.914606185184311','test','test','0.0'),('2020-02-02 23:59:59','2020-02-03 03:59:59','RENBTC','4h','0.000004950000000','0.000004900500000','0.043730800394335','0.043293492390392','8834.505130168664','8834.505130168663527','test','test','1.0'),('2020-02-03 11:59:59','2020-02-10 11:59:59','RENBTC','4h','0.000005090000000','0.000005710000000','0.043633620837903','0.048948521607942','8572.420596837546','8572.420596837546327','test','test','0.0'),('2020-02-11 19:59:59','2020-02-11 23:59:59','RENBTC','4h','0.000006050000000','0.000005989500000','0.044814709897912','0.044366562798933','7407.390065770542','7407.390065770541696','test','test','1.0'),('2020-02-12 03:59:59','2020-02-12 15:59:59','RENBTC','4h','0.000005920000000','0.000005860800000','0.044715121653694','0.044267970437157','7553.230009069968','7553.230009069968219','test','test','1.0'),('2020-02-12 19:59:59','2020-02-12 23:59:59','RENBTC','4h','0.000005990000000','0.000005930100000','0.044615754716686','0.044169597169519','7448.373074571952','7448.373074571952202','test','test','1.0'),('2020-02-13 07:59:59','2020-02-13 11:59:59','RENBTC','4h','0.000006100000000','0.000006039000000','0.044516608595093','0.044071442509142','7297.804687720218','7297.804687720217771','test','test','1.0'),('2020-02-13 15:59:59','2020-02-14 07:59:59','RENBTC','4h','0.000006240000000','0.000006177600000','0.044417682798215','0.043973505970233','7118.218397149893','7118.218397149892553','test','test','1.0'),('2020-02-14 11:59:59','2020-02-15 19:59:59','RENBTC','4h','0.000006430000000','0.000006365700000','0.044318976836442','0.043875787068078','6892.531389804283','6892.531389804283208','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:45:24
