-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.618400000000000','2.616900000000000','222.222222222222200','222.094918016091242','84.86947075398038','84.869470753980380','test','test','0.9'),('2019-01-05 03:59:59','2019-01-05 07:59:59','EOSUSDT','4h','2.713900000000000','2.686761000000000','222.193932398637571','219.971993074651181','81.87255698391155','81.872556983911551','test','test','1.0'),('2019-01-06 19:59:59','2019-01-07 03:59:59','EOSUSDT','4h','2.835900000000000','2.807541000000000','221.700168104418367','219.483166423374172','78.17629962425275','78.176299624252749','test','test','1.0'),('2019-01-08 11:59:59','2019-01-08 19:59:59','EOSUSDT','4h','2.768000000000000','2.740320000000000','221.207501064186317','218.995426053544463','79.91600471972049','79.916004719720490','test','test','1.0'),('2019-01-09 15:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.783200000000000','2.755368000000000','220.715928839599229','218.508769551203244','79.3029350530322','79.302935053032201','test','test','1.0'),('2019-01-19 11:59:59','2019-01-19 19:59:59','EOSUSDT','4h','2.479700000000000','2.454903000000000','220.225448997733452','218.023194507756102','88.81132757903515','88.811327579035151','test','test','1.0'),('2019-01-22 19:59:59','2019-01-22 23:59:59','EOSUSDT','4h','2.461900000000000','2.437281000000000','219.736059111071853','217.538698519961144','89.25466473498999','89.254664734989987','test','test','1.0'),('2019-02-02 23:59:59','2019-02-03 07:59:59','EOSUSDT','4h','2.438900000000000','2.414511000000000','219.247756757491658','217.055279189916718','89.89616497498531','89.896164974985311','test','test','1.0'),('2019-02-03 23:59:59','2019-02-04 03:59:59','EOSUSDT','4h','2.370700000000000','2.386200000000000','218.760539520252792','220.190829461014573','92.27677037172684','92.276770371726840','test','test','0.0'),('2019-02-07 03:59:59','2019-02-07 07:59:59','EOSUSDT','4h','2.366300000000000','2.358000000000000','219.078381729310991','218.309945534258276','92.58267410273888','92.582674102738878','test','test','0.4'),('2019-02-08 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.428500000000000','3.570400000000000','218.907618130410384','321.839719898215833','90.14108220317496','90.141082203174960','test','test','0.0'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSUSDT','4h','3.563800000000000','3.546100000000000','241.781418523256008','240.580584832290867','67.84371135396374','67.843711353963741','test','test','0.5'),('2019-02-27 23:59:59','2019-02-28 15:59:59','EOSUSDT','4h','3.502100000000000','3.550100000000000','241.514566591930475','244.824780234148761','68.96278421288098','68.962784212880976','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','EOSUSDT','4h','3.622300000000000','3.586077000000000','242.250169623534504','239.827667927299160','66.87744516565014','66.877445165650144','test','test','1.0'),('2019-03-03 11:59:59','2019-03-03 15:59:59','EOSUSDT','4h','3.537900000000000','3.502521000000000','241.711835913259961','239.294717554127374','68.32070887058988','68.320708870589883','test','test','1.0'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.627600000000000','3.591324000000000','241.174698500119433','238.762951515118232','66.48326676042547','66.483266760425465','test','test','1.0'),('2019-03-09 15:59:59','2019-03-10 03:59:59','EOSUSDT','4h','3.757400000000000','3.719826000000000','240.638754725674715','238.232367178417974','64.04395452325403','64.043954523254030','test','test','1.0'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSUSDT','4h','3.662000000000000','3.625380000000000','240.104001937395424','237.702961918021458','65.56635771092175','65.566357710921750','test','test','1.0'),('2019-03-15 11:59:59','2019-03-20 11:59:59','EOSUSDT','4h','3.688400000000000','3.711600000000000','239.570437488645638','241.077333202162748','64.95240144470384','64.952401444703838','test','test','0.1'),('2019-03-23 07:59:59','2019-03-23 11:59:59','EOSUSDT','4h','3.684600000000000','3.658400000000000','239.905303202760592','238.199414111973965','65.11027064071014','65.110270640710141','test','test','0.7'),('2019-03-26 23:59:59','2019-04-11 11:59:59','EOSUSDT','4h','3.743900000000000','5.246600000000000','239.526216738141301','335.665548956524503','63.97772823476623','63.977728234766232','test','test','0.0'),('2019-04-12 03:59:59','2019-04-13 11:59:59','EOSUSDT','4h','5.280400000000000','5.239100000000000','260.890512786670911','258.849989686510014','49.407338986946236','49.407338986946236','test','test','0.8'),('2019-04-14 23:59:59','2019-04-15 11:59:59','EOSUSDT','4h','5.542200000000000','5.486778000000000','260.437063208857410','257.832692576768807','46.991639278419655','46.991639278419655','test','test','1.0'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.484400000000000','5.429556000000000','259.858314179504362','257.259731037709344','47.38135697241346','47.381356972413457','test','test','1.0'),('2019-04-16 11:59:59','2019-04-21 07:59:59','EOSUSDT','4h','5.383300000000000','5.337300000000000','259.280851259105475','257.065310762027707','48.16392384951711','48.163923849517111','test','test','0.9'),('2019-05-03 11:59:59','2019-05-04 07:59:59','EOSUSDT','4h','5.034500000000000','4.984155000000000','258.788508926421514','256.200623837157309','51.40302094079283','51.403020940792828','test','test','1.0'),('2019-05-04 23:59:59','2019-05-05 11:59:59','EOSUSDT','4h','4.947200000000000','4.897728000000000','258.213423351029462','255.631289117519202','52.19385174462918','52.193851744629178','test','test','1.0'),('2019-05-06 19:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.933100000000000','4.883768999999999','257.639615743582738','255.063219586146886','52.226716617052716','52.226716617052716','test','test','1.0'),('2019-05-09 03:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.944800000000000','4.895352000000000','257.067083264152529','254.496412431511004','51.98735707493782','51.987357074937819','test','test','1.0'),('2019-05-11 03:59:59','2019-05-11 07:59:59','EOSUSDT','4h','4.898300000000000','4.923700000000000','256.495823079121067','257.825875118851116','52.3642535326789','52.364253532678902','test','test','0.0'),('2019-05-11 11:59:59','2019-05-22 23:59:59','EOSUSDT','4h','5.276000000000000','5.928500000000000','256.791390199061141','288.549612735999631','48.67160542059536','48.671605420595363','test','test','0.4'),('2019-05-24 07:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.224100000000000','7.300000000000000','263.848772985047447','309.457759803159718','42.39147394563832','42.391473945638317','test','test','0.0'),('2019-05-31 11:59:59','2019-06-02 19:59:59','EOSUSDT','4h','7.656600000000000','7.580034000000000','273.984103389072402','271.244262355181661','35.78404296803704','35.784042968037042','test','test','1.0'),('2019-06-15 03:59:59','2019-06-18 19:59:59','EOSUSDT','4h','6.668300000000000','6.758900000000000','273.375249825985577','277.089509477506112','40.99624339426624','40.996243394266237','test','test','0.2'),('2019-06-21 03:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.992600000000000','6.922674000000001','274.200640859656801','271.458634451060220','39.212973838008296','39.212973838008296','test','test','1.0'),('2019-06-21 19:59:59','2019-06-25 15:59:59','EOSUSDT','4h','6.974600000000000','7.079900000000000','273.591306102190913','277.721889151048288','39.226809580791866','39.226809580791866','test','test','0.0'),('2019-06-26 03:59:59','2019-06-26 07:59:59','EOSUSDT','4h','7.316600000000000','7.243434000000000','274.509213446381466','271.764121311917620','37.51868537932666','37.518685379326662','test','test','1.0'),('2019-06-26 11:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.380200000000000','7.306398000000001','273.899192972056142','271.160201042335586','37.112706020440655','37.112706020440655','test','test','1.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','EOSUSDT','4h','4.640900000000000','4.594491000000001','273.290528098784932','270.557622817797096','58.88739858621925','58.887398586219248','test','test','1.0'),('2019-07-25 03:59:59','2019-07-26 03:59:59','EOSUSDT','4h','4.570000000000000','4.524300000000000','272.683215814120899','269.956383655979664','59.66809974050785','59.668099740507849','test','test','1.0'),('2019-08-05 03:59:59','2019-08-05 11:59:59','EOSUSDT','4h','4.357100000000000','4.422800000000000','272.077253112311780','276.179861620144663','62.4445739396185','62.444573939618500','test','test','0.6'),('2019-08-05 15:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.419000000000000','4.374809999999999','272.988943891830161','270.259054452911812','61.77618101195524','61.776181011955238','test','test','1.0'),('2019-09-07 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.427400000000000','3.887800000000000','272.382301794292800','308.971206429320034','79.47199095357787','79.471990953577873','test','test','0.0'),('2019-09-19 19:59:59','2019-09-20 03:59:59','EOSUSDT','4h','3.945200000000000','3.922000000000000','280.513169490965481','278.863593922631765','71.10239518680054','71.102395186800535','test','test','0.6'),('2019-10-07 15:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.127300000000000','3.110000000000000','280.146597142446922','278.596846197361913','89.58097948468229','89.580979484682288','test','test','0.6'),('2019-10-10 19:59:59','2019-10-10 23:59:59','EOSUSDT','4h','3.153900000000000','3.122361000000000','279.802208043539110','277.004185963103737','88.71625861426776','88.716258614267758','test','test','1.0'),('2019-10-11 03:59:59','2019-10-11 07:59:59','EOSUSDT','4h','3.138600000000000','3.107214000000000','279.180425358997923','276.388621105407935','88.95062300356781','88.950623003567813','test','test','1.0'),('2019-10-14 19:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.158800000000000','3.127212000000000','278.560024413755684','275.774424169618101','88.18539458457506','88.185394584575064','test','test','1.0'),('2019-10-22 15:59:59','2019-10-22 19:59:59','EOSUSDT','4h','2.992200000000000','2.969600000000000','277.941002137280691','275.841721792282840','92.8885108406125','92.888510840612497','test','test','0.8'),('2019-10-25 15:59:59','2019-11-03 19:59:59','EOSUSDT','4h','3.056300000000000','3.225400000000000','277.474495393947848','292.826698113287136','90.78771566729309','90.787715667293085','test','test','0.0'),('2019-11-04 11:59:59','2019-11-08 15:59:59','EOSUSDT','4h','3.369100000000000','3.403000000000000','280.886095998245480','283.712381550571195','83.37125523084666','83.371255230846657','test','test','0.0'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.509055000000000','281.514159454317792','278.699017859774585','79.42281265462485','79.422812654624849','test','test','1.0'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSUSDT','4h','3.469200000000000','3.467900000000000','280.888572433308241','280.783316136708663','80.9663819996853','80.966381999685296','test','test','0.0'),('2019-11-13 11:59:59','2019-11-13 15:59:59','EOSUSDT','4h','3.477800000000000','3.450400000000000','280.865182145174970','278.652373475677678','80.75944049260308','80.759440492603076','test','test','0.8'),('2019-12-08 19:59:59','2019-12-09 03:59:59','EOSUSDT','4h','2.750700000000000','2.735000000000000','280.373446885286683','278.773176730017440','101.92803536746526','101.928035367465256','test','test','0.6'),('2019-12-22 19:59:59','2019-12-23 19:59:59','EOSUSDT','4h','2.515500000000000','2.516600000000000','280.017831295226813','280.140279959279553','111.31696732070237','111.316967320702375','test','test','0.0'),('2019-12-24 11:59:59','2019-12-25 15:59:59','EOSUSDT','4h','2.515000000000000','2.489850000000000','280.045042109460780','277.244591688366143','111.34991733974583','111.349917339745829','test','test','1.0'),('2019-12-26 19:59:59','2019-12-26 23:59:59','EOSUSDT','4h','2.574200000000000','2.548458000000000','279.422719793661997','276.628492595725390','108.54740105417685','108.547401054176845','test','test','1.0'),('2019-12-27 07:59:59','2019-12-27 15:59:59','EOSUSDT','4h','2.548100000000000','2.576100000000000','278.801780416342751','281.865416008218119','109.41555685269132','109.415556852691324','test','test','0.8'),('2019-12-28 03:59:59','2019-12-31 19:59:59','EOSUSDT','4h','2.620700000000000','2.594493000000000','279.482588325648351','276.687762442391886','106.64425089695439','106.644250896954389','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:47:52
