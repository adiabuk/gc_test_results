-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 15:59:59','2019-01-14 19:59:59','ADAETH','4h','0.000308000000000','0.000339920000000','1.297777777777778','1.432274747474748','4213.564213564213','4213.564213564212878','test','test','0.0'),('2019-01-14 23:59:59','2019-01-27 07:59:59','ADAETH','4h','0.000341380000000','0.000360010000000','1.327665993265993','1.400120201053636','3889.1147497392735','3889.114749739273520','test','test','0.8'),('2019-01-27 15:59:59','2019-01-27 19:59:59','ADAETH','4h','0.000363000000000','0.000362290000000','1.343766928329914','1.341138623869544','3701.8372681264846','3701.837268126484560','test','test','0.2'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ADAETH','4h','0.000364960000000','0.000365140000000','1.343182860672054','1.343845324818593','3680.3563696625765','3680.356369662576526','test','test','0.0'),('2019-01-28 19:59:59','2019-01-28 23:59:59','ADAETH','4h','0.000366700000000','0.000365480000000','1.343330074926840','1.338860855697468','3663.294450304991','3663.294450304991187','test','test','0.3'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.342336915098091','1.338763851565591','4203.604155882915','4203.604155882914711','test','test','0.3'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ADAETH','4h','0.000320580000000','0.000318970000000','1.341542900979758','1.334805474844075','4184.736730238187','4184.736730238187192','test','test','0.5'),('2019-03-05 11:59:59','2019-03-05 15:59:59','ADAETH','4h','0.000319660000000','0.000317350000000','1.340045695171828','1.330361951331976','4192.096900368605','4192.096900368605020','test','test','0.7'),('2019-03-08 23:59:59','2019-04-07 23:59:59','ADAETH','4h','0.000317500000000','0.000515610000000','1.337893752096305','2.172697315018506','4213.838589279702','4213.838589279702319','test','test','0.0'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ADAETH','4h','0.000504110000000','0.000499068900000','1.523405654967906','1.508171598418227','3021.9707106939077','3021.970710693907677','test','test','1.0'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAETH','4h','0.000507480000000','0.000505450000000','1.520020309067977','1.513939988213149','2995.231948191016','2995.231948191015817','test','test','0.4'),('2019-04-13 11:59:59','2019-04-14 07:59:59','ADAETH','4h','0.000510560000000','0.000505454400000','1.518669126655793','1.503482435389235','2974.51646555898','2974.516465558980144','test','test','1.0'),('2019-04-15 19:59:59','2019-04-16 07:59:59','ADAETH','4h','0.000511810000000','0.000506691900000','1.515294306374336','1.500141363310593','2960.6578737702184','2960.657873770218430','test','test','1.0'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ADAETH','4h','0.000390490000000','0.000386585100000','1.511926985693504','1.496807715836569','3871.8712020628027','3871.871202062802695','test','test','1.0'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADAETH','4h','0.000336780000000','0.000334780000000','1.508567147947518','1.499608378733506','4479.384607006112','4479.384607006111764','test','test','0.6'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ADAETH','4h','0.000338610000000','0.000343520000000','1.506576310344405','1.528422356485367','4449.296566387303','4449.296566387302846','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','ADAETH','4h','0.000335800000000','0.000337820000000','1.511430987264618','1.520522978313679','4500.985667851753','4500.985667851752623','test','test','0.0'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADAETH','4h','0.000342000000000','0.000344290000000','1.513451429719965','1.523585358883879','4425.296578128553','4425.296578128552937','test','test','0.0'),('2019-06-07 11:59:59','2019-06-07 23:59:59','ADAETH','4h','0.000340650000000','0.000341740000000','1.515703413978613','1.520553308947750','4449.444925814216','4449.444925814215821','test','test','0.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADAETH','4h','0.000345530000000','0.000342800000000','1.516781168416198','1.504797223202248','4389.72352159349','4389.723521593489750','test','test','0.8'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADAETH','4h','0.000345430000000','0.000348810000000','1.514118069479766','1.528933572113705','4383.284802940583','4383.284802940583177','test','test','0.0'),('2019-07-14 23:59:59','2019-07-15 03:59:59','ADAETH','4h','0.000261070000000','0.000261540000000','1.517410403398419','1.520142172232821','5812.274115748338','5812.274115748337863','test','test','0.0'),('2019-07-16 15:59:59','2019-07-16 19:59:59','ADAETH','4h','0.000261410000000','0.000259470000000','1.518017463139397','1.506751811945906','5807.036697675669','5807.036697675668620','test','test','0.7'),('2019-07-17 11:59:59','2019-07-17 15:59:59','ADAETH','4h','0.000260840000000','0.000264460000000','1.515513985096399','1.536546651198412','5810.128757462041','5810.128757462040994','test','test','0.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAETH','4h','0.000279990000000','0.000277190100000','1.520187910896846','1.504986031787878','5429.436447361857','5429.436447361857063','test','test','1.0'),('2019-07-22 15:59:59','2019-07-23 07:59:59','ADAETH','4h','0.000273160000000','0.000270428400000','1.516809715539298','1.501641618383905','5552.825141086901','5552.825141086900658','test','test','1.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','ADAETH','4h','0.000272020000000','0.000269299800000','1.513439027282544','1.498304637009719','5563.704974937665','5563.704974937664701','test','test','1.0'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADAETH','4h','0.000272230000000','0.000269507700000','1.510075829444138','1.494975071149697','5547.058845256357','5547.058845256357017','test','test','1.0'),('2019-07-25 15:59:59','2019-07-25 23:59:59','ADAETH','4h','0.000267090000000','0.000267300000000','1.506720105378706','1.507904766811667','5641.244918861457','5641.244918861457336','test','test','0.0'),('2019-07-26 07:59:59','2019-07-31 15:59:59','ADAETH','4h','0.000273540000000','0.000276670000000','1.506983363474920','1.524227122806924','5509.188284985451','5509.188284985450991','test','test','0.0'),('2019-08-11 19:59:59','2019-08-11 23:59:59','ADAETH','4h','0.000256730000000','0.000254162700000','1.510815309993143','1.495707156893211','5884.8413118573735','5884.841311857373512','test','test','1.0'),('2019-08-13 23:59:59','2019-08-14 03:59:59','ADAETH','4h','0.000251540000000','0.000254700000000','1.507457942637603','1.526395555338306','5992.915411614864','5992.915411614863842','test','test','0.0'),('2019-08-14 15:59:59','2019-08-16 03:59:59','ADAETH','4h','0.000253500000000','0.000250965000000','1.511666301015537','1.496549638005382','5963.1806746175025','5963.180674617502518','test','test','1.0'),('2019-08-17 19:59:59','2019-08-17 23:59:59','ADAETH','4h','0.000258550000000','0.000255964500000','1.508307042568836','1.493223972143148','5833.71511339716','5833.715113397160167','test','test','1.0'),('2019-08-18 23:59:59','2019-08-19 03:59:59','ADAETH','4h','0.000260100000000','0.000257499000000','1.504955249140905','1.489905696649496','5786.06401053789','5786.064010537889772','test','test','1.0'),('2019-08-21 07:59:59','2019-08-21 11:59:59','ADAETH','4h','0.000252390000000','0.000249866100000','1.501610904142814','1.486594795101386','5949.565767830794','5949.565767830794357','test','test','1.0'),('2019-08-21 15:59:59','2019-08-22 03:59:59','ADAETH','4h','0.000253760000000','0.000257100000000','1.498273991022497','1.517994337531068','5904.295361847797','5904.295361847796812','test','test','0.6'),('2019-08-22 15:59:59','2019-08-22 23:59:59','ADAETH','4h','0.000260890000000','0.000258281100000','1.502656290246624','1.487629727344158','5759.731266996143','5759.731266996142949','test','test','1.0'),('2019-08-24 19:59:59','2019-08-26 03:59:59','ADAETH','4h','0.000265630000000','0.000262973700000','1.499317054046076','1.484323883505615','5644.381485698437','5644.381485698437245','test','test','1.0'),('2019-08-26 15:59:59','2019-08-27 11:59:59','ADAETH','4h','0.000264590000000','0.000261944100000','1.495985238370418','1.481025385986714','5653.974973999085','5653.974973999084796','test','test','1.0'),('2019-08-28 03:59:59','2019-08-28 11:59:59','ADAETH','4h','0.000265240000000','0.000262587600000','1.492660826729595','1.477734218462299','5627.585683643474','5627.585683643474113','test','test','1.0'),('2019-08-28 19:59:59','2019-08-28 23:59:59','ADAETH','4h','0.000267440000000','0.000264765600000','1.489343802670195','1.474450364643493','5568.889480519726','5568.889480519726021','test','test','1.0'),('2019-08-29 15:59:59','2019-08-31 23:59:59','ADAETH','4h','0.000262730000000','0.000260950000000','1.486034149775373','1.475966244372107','5656.1266310485025','5656.126631048502531','test','test','0.7'),('2019-09-06 23:59:59','2019-09-07 03:59:59','ADAETH','4h','0.000262030000000','0.000259409700000','1.483796837463536','1.468958869088901','5662.698307306552','5662.698307306552124','test','test','1.0'),('2019-09-08 15:59:59','2019-09-08 23:59:59','ADAETH','4h','0.000260280000000','0.000257677200000','1.480499511158062','1.465694516046481','5688.103239427008','5688.103239427007793','test','test','1.0'),('2019-09-10 03:59:59','2019-09-10 15:59:59','ADAETH','4h','0.000259610000000','0.000261780000000','1.477209512244377','1.489557051405312','5690.110212412375','5690.110212412375404','test','test','0.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','ADAETH','4h','0.000259050000000','0.000256459500000','1.479953409835696','1.465153875737339','5713.002933162308','5713.002933162308182','test','test','1.0'),('2019-10-05 11:59:59','2019-10-05 15:59:59','ADAETH','4h','0.000225520000000','0.000224750000000','1.476664624480505','1.471622802199333','6547.821144379679','6547.821144379679026','test','test','0.3'),('2019-10-05 19:59:59','2019-10-05 23:59:59','ADAETH','4h','0.000226590000000','0.000224800000000','1.475544219529134','1.463887817424199','6511.956483203732','6511.956483203732205','test','test','0.8'),('2019-10-06 11:59:59','2019-10-06 19:59:59','ADAETH','4h','0.000226500000000','0.000227720000000','1.472953907950259','1.480887699419130','6503.107761369799','6503.107761369798936','test','test','0.0'),('2019-10-07 11:59:59','2019-10-08 03:59:59','ADAETH','4h','0.000230450000000','0.000228145500000','1.474716972721120','1.459969802993909','6399.292569846472','6399.292569846472361','test','test','1.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','ADAETH','4h','0.000234280000000','0.000231937200000','1.471439823892850','1.456725425653921','6280.689021226098','6280.689021226097793','test','test','1.0'),('2019-10-14 07:59:59','2019-10-14 15:59:59','ADAETH','4h','0.000229320000000','0.000227026800000','1.468169957617533','1.453488258041358','6402.276110315424','6402.276110315424376','test','test','1.0'),('2019-10-19 15:59:59','2019-10-20 11:59:59','ADAETH','4h','0.000225570000000','0.000224020000000','1.464907357711716','1.454841274436222','6494.247274512197','6494.247274512196782','test','test','0.7'),('2019-10-20 15:59:59','2019-10-20 19:59:59','ADAETH','4h','0.000225560000000','0.000223460000000','1.462670450317162','1.449052752384612','6484.618063119179','6484.618063119179169','test','test','0.9'),('2019-10-21 15:59:59','2019-10-23 23:59:59','ADAETH','4h','0.000223720000000','0.000224240000000','1.459644295221040','1.463036996068148','6524.4247059763975','6524.424705976397490','test','test','0.0'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ADAETH','4h','0.000225920000000','0.000228340000000','1.460398228742619','1.476041658777840','6464.227287281424','6464.227287281423742','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 15:59:59','ADAETH','4h','0.000231510000000','0.000229194900000','1.463874546528224','1.449235801062942','6323.159027809701','6323.159027809701001','test','test','1.0'),('2019-10-27 15:59:59','2019-10-27 19:59:59','ADAETH','4h','0.000231690000000','0.000229373100000','1.460621491980383','1.446015277060579','6304.206016575526','6304.206016575525609','test','test','1.0'),('2019-10-28 03:59:59','2019-10-28 07:59:59','ADAETH','4h','0.000234770000000','0.000232422300000','1.457375666442649','1.442801909778223','6207.6741766096575','6207.674176609657479','test','test','1.0'),('2019-10-30 03:59:59','2019-10-30 11:59:59','ADAETH','4h','0.000228710000000','0.000226930000000','1.454137053850554','1.442819822615129','6357.995076081302','6357.995076081301704','test','test','0.8'),('2019-11-01 03:59:59','2019-11-01 23:59:59','ADAETH','4h','0.000232290000000','0.000230710000000','1.451622113576016','1.441748408554491','6249.180393370424','6249.180393370424099','test','test','0.9'),('2019-11-04 11:59:59','2019-11-04 15:59:59','ADAETH','4h','0.000229630000000','0.000230010000000','1.449427956904566','1.451826522525886','6312.014792947635','6312.014792947635215','test','test','0.0'),('2019-11-04 23:59:59','2019-11-06 07:59:59','ADAETH','4h','0.000232600000000','0.000232270000000','1.449960971487081','1.447903847150921','6233.710109574726','6233.710109574725720','test','test','0.7'),('2019-11-06 11:59:59','2019-11-06 23:59:59','ADAETH','4h','0.000236880000000','0.000234511200000','1.449503832745712','1.435008794418255','6119.148230098414','6119.148230098414388','test','test','1.0'),('2019-11-10 23:59:59','2019-11-11 03:59:59','ADAETH','4h','0.000231930000000','0.000230440000000','1.446282713117389','1.436991283623382','6235.858720809678','6235.858720809677834','test','test','0.6'),('2019-11-11 15:59:59','2019-11-13 11:59:59','ADAETH','4h','0.000232500000000','0.000232430000000','1.444217951007609','1.443783132699779','6211.690111860686','6211.690111860685647','test','test','0.0'),('2019-11-15 11:59:59','2019-11-19 11:59:59','ADAETH','4h','0.000236520000000','0.000236920000000','1.444121324716980','1.446563606679972','6105.7049074792','6105.704907479200301','test','test','0.4'),('2019-11-19 19:59:59','2019-11-20 03:59:59','ADAETH','4h','0.000240930000000','0.000238520700000','1.444664054042090','1.430217413501669','5996.198290134435','5996.198290134435410','test','test','1.0'),('2019-11-21 19:59:59','2019-11-22 03:59:59','ADAETH','4h','0.000239990000000','0.000237590100000','1.441453689477552','1.427039152582777','6006.307302294062','6006.307302294061628','test','test','1.0'),('2019-11-22 07:59:59','2019-11-22 11:59:59','ADAETH','4h','0.000239680000000','0.000240510000000','1.438250459056491','1.443231049347783','6000.711194327814','6000.711194327814155','test','test','0.0'),('2019-11-22 15:59:59','2019-12-02 07:59:59','ADAETH','4h','0.000245800000000','0.000255180000000','1.439357256899000','1.494284722601655','5855.806578108218','5855.806578108217764','test','test','0.1'),('2019-12-03 11:59:59','2019-12-04 03:59:59','ADAETH','4h','0.000257070000000','0.000254499300000','1.451563360388479','1.437047726784594','5646.568484803669','5646.568484803668980','test','test','1.0'),('2019-12-06 19:59:59','2019-12-06 23:59:59','ADAETH','4h','0.000254850000000','0.000257390000000','1.448337664032060','1.462772734334753','5683.098544367511','5683.098544367510840','test','test','0.0'),('2019-12-07 03:59:59','2019-12-08 19:59:59','ADAETH','4h','0.000259160000000','0.000256568400000','1.451545457432658','1.437030002858331','5600.962561478077','5600.962561478077077','test','test','1.0'),('2019-12-13 11:59:59','2019-12-14 11:59:59','ADAETH','4h','0.000257010000000','0.000254439900000','1.448319800860586','1.433836602851980','5635.266335397788','5635.266335397787770','test','test','1.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADAETH','4h','0.000255280000000','0.000255440000000','1.445101312414229','1.446007048116150','5660.848137003403','5660.848137003403281','test','test','0.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','ADAETH','4h','0.000256510000000','0.000256000000000','1.445302587014656','1.442428997995213','5634.488273418797','5634.488273418796780','test','test','0.5'),('2019-12-17 11:59:59','2019-12-17 15:59:59','ADAETH','4h','0.000256290000000','0.000257320000000','1.444664011677002','1.450469949996981','5636.833320367559','5636.833320367559281','test','test','0.0'),('2019-12-17 23:59:59','2019-12-18 15:59:59','ADAETH','4h','0.000259740000000','0.000257510000000','1.445954220192553','1.433539967820838','5566.929314670642','5566.929314670642270','test','test','0.9'),('2019-12-23 19:59:59','2019-12-23 23:59:59','ADAETH','4h','0.000259170000000','0.000258460000000','1.443195497443283','1.439241842301157','5568.528369191198','5568.528369191198180','test','test','0.3'),('2019-12-24 11:59:59','2019-12-27 11:59:59','ADAETH','4h','0.000263370000000','0.000260736300000','1.442316907411699','1.427893738337582','5476.390277600711','5476.390277600710760','test','test','1.0'),('2019-12-28 07:59:59','2019-12-28 11:59:59','ADAETH','4h','0.000262520000000','0.000262440000000','1.439111758728562','1.438673205701371','5481.912839892436','5481.912839892435841','test','test','0.0'),('2019-12-28 15:59:59','2019-12-28 19:59:59','ADAETH','4h','0.000265720000000','0.000263062800000','1.439014302500297','1.424624159475294','5415.528761479367','5415.528761479366949','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:14:56
