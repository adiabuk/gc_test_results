-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','XVGETH','4h','0.000057520000000','0.000056944800000','1.297777777777778','1.284800000000000','22562.20058723536','22562.200587235358398','test','test','1.0'),('2019-01-10 23:59:59','2019-01-11 23:59:59','XVGETH','4h','0.000059140000000','0.000058548600000','1.294893827160494','1.281944888888889','21895.397821448998','21895.397821448998002','test','test','1.0'),('2019-01-15 15:59:59','2019-01-17 19:59:59','XVGETH','4h','0.000055350000000','0.000054796500000','1.292016285322359','1.279096122469135','23342.66098143377','23342.660981433771667','test','test','1.0'),('2019-01-18 11:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000054790000000','0.000056570000000','1.289145138021643','1.331026473040415','23528.83989818658','23528.839898186579376','test','test','0.0'),('2019-01-28 03:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000057070000000','0.000056520000000','1.298452101359148','1.285938545099335','22751.920472387377','22751.920472387377231','test','test','1.0'),('2019-01-28 11:59:59','2019-01-29 07:59:59','XVGETH','4h','0.000057450000000','0.000056875500000','1.295671311079189','1.282714597968397','22553.025432187802','22553.025432187801925','test','test','1.0'),('2019-01-29 11:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057470000000','0.000057030000000','1.292792041499013','1.282894207876957','22495.076413763934','22495.076413763934397','test','test','1.0'),('2019-03-02 15:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000045280000000','0.000045260000000','1.290592522916334','1.290022473215399','28502.485046738828','28502.485046738827805','test','test','0.0'),('2019-03-03 11:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000045220000000','0.000046020000000','1.290465845205015','1.313295846889314','28537.502105374067','28537.502105374067469','test','test','0.0'),('2019-03-08 11:59:59','2019-03-08 19:59:59','XVGETH','4h','0.000047270000000','0.000046797300000','1.295539178912637','1.282583787123511','27407.21766263248','27407.217662632479914','test','test','1.0'),('2019-03-09 07:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000046840000000','0.000046371600000','1.292660202959498','1.279733600929903','27597.357023046505','27597.357023046504764','test','test','1.0'),('2019-03-12 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000049210000000','0.000049580000000','1.289787624730699','1.299485276044464','26209.868415580153','26209.868415580152941','test','test','0.2'),('2019-03-19 15:59:59','2019-03-20 03:59:59','XVGETH','4h','0.000049680000000','0.000049920000000','1.291942658355981','1.298183927236928','26005.287003944857','26005.287003944857133','test','test','0.6'),('2019-03-21 11:59:59','2019-03-24 15:59:59','XVGETH','4h','0.000050240000000','0.000050230000000','1.293329606996191','1.293072176740021','25743.025616962397','25743.025616962397180','test','test','0.3'),('2019-03-27 11:59:59','2019-03-27 15:59:59','XVGETH','4h','0.000051650000000','0.000051133500000','1.293272400272597','1.280339676269871','25039.15586200576','25039.155862005758536','test','test','1.0'),('2019-03-28 15:59:59','2019-03-29 11:59:59','XVGETH','4h','0.000051280000000','0.000050767200000','1.290398461605325','1.277494476989272','25163.776552365933','25163.776552365932730','test','test','1.0'),('2019-03-31 11:59:59','2019-03-31 15:59:59','XVGETH','4h','0.000053700000000','0.000053163000000','1.287530909468424','1.274655600373740','23976.36702920716','23976.367029207158339','test','test','1.0'),('2019-04-02 07:59:59','2019-04-02 11:59:59','XVGETH','4h','0.000053600000000','0.000053064000000','1.284669729669606','1.271823032372910','23967.718837119508','23967.718837119507953','test','test','1.0'),('2019-04-03 07:59:59','2019-04-03 19:59:59','XVGETH','4h','0.000051610000000','0.000051810000000','1.281814908048118','1.286782220228115','24836.560899982906','24836.560899982905539','test','test','0.0'),('2019-04-03 23:59:59','2019-04-08 03:59:59','XVGETH','4h','0.000053460000000','0.000059300000000','1.282918755199228','1.423065510350060','23997.73204637539','23997.732046375389473','test','test','1.0'),('2019-04-08 07:59:59','2019-04-08 11:59:59','XVGETH','4h','0.000059600000000','0.000059004000000','1.314062478566080','1.300921853780419','22048.0281638604','22048.028163860399218','test','test','1.0'),('2019-04-08 19:59:59','2019-04-09 03:59:59','XVGETH','4h','0.000059300000000','0.000058707000000','1.311142339724822','1.298030916327574','22110.32613363949','22110.326133639489854','test','test','1.0'),('2019-04-23 11:59:59','2019-04-24 03:59:59','XVGETH','4h','0.000051250000000','0.000050737500000','1.308228690080989','1.295146403180179','25526.413464994905','25526.413464994904643','test','test','1.0'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XVGETH','4h','0.000042100000000','0.000041679000000','1.305321515214142','1.292268300062001','31005.26164404138','31005.261644041380350','test','test','1.0'),('2019-05-16 07:59:59','2019-05-16 11:59:59','XVGETH','4h','0.000041860000000','0.000041441400000','1.302420800735889','1.289396592728530','31113.731503485153','31113.731503485152643','test','test','1.0'),('2019-05-16 19:59:59','2019-05-16 23:59:59','XVGETH','4h','0.000040480000000','0.000041050000000','1.299526532289809','1.317825201346262','32102.928169214647','32102.928169214646914','test','test','0.0'),('2019-05-19 15:59:59','2019-05-19 23:59:59','XVGETH','4h','0.000043720000000','0.000043282800000','1.303592903191243','1.290556974159330','29816.85505926905','29816.855059269051708','test','test','1.0'),('2019-05-20 03:59:59','2019-05-20 07:59:59','XVGETH','4h','0.000044330000000','0.000043886700000','1.300696030073040','1.287689069772309','29341.21430347485','29341.214303474851476','test','test','1.0'),('2019-05-22 15:59:59','2019-05-22 19:59:59','XVGETH','4h','0.000046620000000','0.000046153800000','1.297805594450655','1.284827538506149','27837.9578389244','27837.957838924401585','test','test','1.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','XVGETH','4h','0.000046260000000','0.000045797400000','1.294921582018543','1.281972366198358','27992.252097244767','27992.252097244767356','test','test','1.0'),('2019-06-10 19:59:59','2019-06-10 23:59:59','XVGETH','4h','0.000038030000000','0.000037649700000','1.292043978502946','1.279123538717917','33974.33548522078','33974.335485220777628','test','test','1.0'),('2019-06-11 03:59:59','2019-06-11 07:59:59','XVGETH','4h','0.000037550000000','0.000037210000000','1.289172769661829','1.277499833798047','34332.16430524178','34332.164305241778493','test','test','0.9'),('2019-07-07 03:59:59','2019-07-07 07:59:59','XVGETH','4h','0.000027880000000','0.000027601200000','1.286578783914322','1.273712996075179','46147.015204961324','46147.015204961324343','test','test','1.0'),('2019-07-14 11:59:59','2019-07-15 03:59:59','XVGETH','4h','0.000025770000000','0.000025900000000','1.283719719950068','1.290195605227271','49814.502132327034','49814.502132327033905','test','test','0.2'),('2019-07-15 19:59:59','2019-07-23 23:59:59','XVGETH','4h','0.000026200000000','0.000026850000000','1.285158805567224','1.317042516392365','49051.86280790931','49051.862807909310504','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 07:59:59','XVGETH','4h','0.000027020000000','0.000027080000000','1.292244074639477','1.295113602562437','47825.46538266015','47825.465382660149771','test','test','0.0'),('2019-07-24 19:59:59','2019-07-24 23:59:59','XVGETH','4h','0.000027200000000','0.000026928000000','1.292881747511246','1.279952930036133','47532.41718791345','47532.417187913451926','test','test','1.0'),('2019-07-25 23:59:59','2019-07-29 03:59:59','XVGETH','4h','0.000027040000000','0.000027220000000','1.290008676961221','1.298596012828566','47707.42148525226','47707.421485252256389','test','test','0.0'),('2019-08-04 19:59:59','2019-08-05 03:59:59','XVGETH','4h','0.000026860000000','0.000026591400000','1.291916973820631','1.278997804082425','48098.17475132655','48098.174751326550904','test','test','1.0'),('2019-08-16 11:59:59','2019-08-20 11:59:59','XVGETH','4h','0.000024360000000','0.000025580000000','1.289046047212141','1.353604182581550','52916.5044011552','52916.504401155201776','test','test','0.0'),('2019-08-22 23:59:59','2019-08-27 11:59:59','XVGETH','4h','0.000026600000000','0.000026890000000','1.303392299516454','1.317602215563814','48999.71050813736','48999.710508137359284','test','test','0.6'),('2019-08-30 19:59:59','2019-08-30 23:59:59','XVGETH','4h','0.000026760000000','0.000026770000000','1.306550058638089','1.307038306044157','48824.74060680453','48824.740606804531126','test','test','0.0'),('2019-09-09 23:59:59','2019-09-10 03:59:59','XVGETH','4h','0.000025720000000','0.000025462800000','1.306658558061660','1.293591972481043','50803.20987798057','50803.209877980567398','test','test','1.0'),('2019-09-10 11:59:59','2019-09-10 15:59:59','XVGETH','4h','0.000025610000000','0.000025610000000','1.303754872377079','1.303754872377079','50908.03874959308','50908.038749593077227','test','test','0.0'),('2019-10-07 15:59:59','2019-10-09 15:59:59','XVGETH','4h','0.000019360000000','0.000019260000000','1.303754872377079','1.297020601342073','67342.71035005571','67342.710350055713207','test','test','0.5'),('2019-10-11 19:59:59','2019-10-12 03:59:59','XVGETH','4h','0.000020710000000','0.000020502900000','1.302258367702633','1.289235784025607','62880.65512808463','62880.655128084632452','test','test','1.0'),('2019-10-13 19:59:59','2019-10-16 03:59:59','XVGETH','4h','0.000020230000000','0.000020027700000','1.299364460218849','1.286370815616660','64229.58280864306','64229.582808643062890','test','test','1.0'),('2019-10-17 07:59:59','2019-10-17 15:59:59','XVGETH','4h','0.000020340000000','0.000020440000000','1.296476983640585','1.302851010108828','63740.26468242798','63740.264682427980006','test','test','0.7'),('2019-10-22 11:59:59','2019-10-22 15:59:59','XVGETH','4h','0.000020030000000','0.000020000000000','1.297893433966861','1.295949509702308','64797.47548511539','64797.475485115392075','test','test','0.1'),('2019-10-27 15:59:59','2019-10-29 23:59:59','XVGETH','4h','0.000019930000000','0.000019780000000','1.297461450796961','1.287696311929949','65100.9257800783','65100.925780078301614','test','test','0.8'),('2019-10-30 07:59:59','2019-10-30 15:59:59','XVGETH','4h','0.000021010000000','0.000020799900000','1.295291419937625','1.282338505738249','61651.18609888742','61651.186098887417756','test','test','1.0'),('2019-11-03 07:59:59','2019-11-03 23:59:59','XVGETH','4h','0.000021240000000','0.000021027600000','1.292412994559986','1.279488864614386','60848.069423728135','60848.069423728135007','test','test','1.0'),('2019-11-04 11:59:59','2019-11-04 15:59:59','XVGETH','4h','0.000021100000000','0.000020889000000','1.289540965683185','1.276645556026353','61115.685577402146','61115.685577402146009','test','test','1.0'),('2019-11-04 19:59:59','2019-11-04 23:59:59','XVGETH','4h','0.000021070000000','0.000020859300000','1.286675319092778','1.273808565901850','61066.6976313611','61066.697631361101230','test','test','1.0'),('2019-11-05 11:59:59','2019-11-05 15:59:59','XVGETH','4h','0.000020820000000','0.000020720000000','1.283816040605905','1.277649777202418','61662.63403486577','61662.634034865768626','test','test','0.5'),('2019-11-05 23:59:59','2019-11-06 15:59:59','XVGETH','4h','0.000020960000000','0.000020750400000','1.282445759849575','1.269621302251079','61185.38930580034','61185.389305800337752','test','test','1.0'),('2019-11-06 19:59:59','2019-11-08 15:59:59','XVGETH','4h','0.000020900000000','0.000020691000000','1.279595880383243','1.266799921579411','61224.68327192548','61224.683271925481677','test','test','1.0'),('2019-11-13 11:59:59','2019-11-13 15:59:59','XVGETH','4h','0.000021060000000','0.000020849400000','1.276752333982391','1.263984810642567','60624.517283114474','60624.517283114473685','test','test','1.0'),('2019-11-13 19:59:59','2019-11-13 23:59:59','XVGETH','4h','0.000021050000000','0.000020839500000','1.273915106573541','1.261175955507805','60518.53237879056','60518.532378790558141','test','test','1.0'),('2019-11-14 03:59:59','2019-11-14 07:59:59','XVGETH','4h','0.000020750000000','0.000020542500000','1.271084184114489','1.258373342273344','61257.069113951264','61257.069113951263716','test','test','1.0'),('2019-11-14 15:59:59','2019-11-21 11:59:59','XVGETH','4h','0.000021250000000','0.000022990000000','1.268259552594234','1.372107628900773','59682.80247502279','59682.802475022792351','test','test','0.0'),('2019-11-21 23:59:59','2019-11-22 19:59:59','XVGETH','4h','0.000024800000000','0.000024552000000','1.291336902884576','1.278423533855730','52070.03640663615','52070.036406636150787','test','test','1.0'),('2019-11-22 23:59:59','2019-11-23 03:59:59','XVGETH','4h','0.000024930000000','0.000024680700000','1.288467265322611','1.275582592669385','51683.40414450905','51683.404144509047910','test','test','1.0'),('2019-11-23 19:59:59','2019-11-23 23:59:59','XVGETH','4h','0.000025570000000','0.000025314300000','1.285604004733005','1.272747964685675','50277.82576194778','50277.825761947780848','test','test','1.0'),('2019-11-25 11:59:59','2019-11-25 19:59:59','XVGETH','4h','0.000024690000000','0.000024910000000','1.282747106944709','1.294177012312382','51954.11530760264','51954.115307602638495','test','test','0.0'),('2019-11-25 23:59:59','2019-11-26 03:59:59','XVGETH','4h','0.000025240000000','0.000024987600000','1.285287085915303','1.272434215056150','50922.626224853535','50922.626224853534950','test','test','1.0'),('2019-11-26 11:59:59','2019-11-26 15:59:59','XVGETH','4h','0.000026820000000','0.000026551800000','1.282430892391047','1.269606583467136','47816.21522710838','47816.215227108383260','test','test','1.0'),('2019-11-26 19:59:59','2019-11-26 23:59:59','XVGETH','4h','0.000027510000000','0.000027234900000','1.279581045963511','1.266785235503876','46513.30592379176','46513.305923791762325','test','test','1.0'),('2019-11-27 07:59:59','2019-11-27 11:59:59','XVGETH','4h','0.000027140000000','0.000026868600000','1.276737532528037','1.263970157202757','47042.65042476186','47042.650424761857721','test','test','1.0'),('2019-11-27 19:59:59','2019-11-30 07:59:59','XVGETH','4h','0.000026340000000','0.000026076600000','1.273900338011308','1.261161334631195','48363.71822366393','48363.718223663927347','test','test','1.0'),('2019-12-02 07:59:59','2019-12-02 11:59:59','XVGETH','4h','0.000026530000000','0.000026264700000','1.271069448371283','1.258358753887570','47910.646376603196','47910.646376603195677','test','test','1.0'),('2019-12-03 23:59:59','2019-12-04 03:59:59','XVGETH','4h','0.000026790000000','0.000026522100000','1.268244849597124','1.255562401101153','47340.23328096769','47340.233280967688188','test','test','1.0'),('2019-12-04 15:59:59','2019-12-10 03:59:59','XVGETH','4h','0.000026580000000','0.000029200000000','1.265426527709131','1.390160068062702','47608.22150899664','47608.221508996641205','test','test','0.0'),('2019-12-11 11:59:59','2019-12-12 03:59:59','XVGETH','4h','0.000029950000000','0.000029650500000','1.293145092232147','1.280213641309826','43176.79773730039','43176.797737300388690','test','test','1.0'),('2019-12-14 15:59:59','2019-12-14 19:59:59','XVGETH','4h','0.000031340000000','0.000031026600000','1.290271436471631','1.277368722106915','41170.11603291737','41170.116032917372650','test','test','1.0'),('2019-12-16 03:59:59','2019-12-16 15:59:59','XVGETH','4h','0.000031560000000','0.000031244400000','1.287404166612805','1.274530124946677','40792.273973789765','40792.273973789764568','test','test','1.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','XVGETH','4h','0.000030350000000','0.000030046500000','1.284543268464776','1.271697835780128','42324.325155346836','42324.325155346836254','test','test','1.0'),('2019-12-18 15:59:59','2019-12-19 03:59:59','XVGETH','4h','0.000030760000000','0.000030452400000','1.281688727868188','1.268871840589506','41667.383870877384','41667.383870877383742','test','test','1.0'),('2019-12-19 15:59:59','2019-12-21 23:59:59','XVGETH','4h','0.000030740000000','0.000030432600000','1.278840530695148','1.266052125388196','41601.838994637204','41601.838994637204451','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:11:35
