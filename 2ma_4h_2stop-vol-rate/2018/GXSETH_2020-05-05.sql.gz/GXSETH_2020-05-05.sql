-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 19:59:59','2018-05-10 19:59:59','GXSETH','4h','0.005591000000000','0.005535090000000','1.297777777777778','1.284800000000000','232.11908026789087','232.119080267890865','test','test','1.0'),('2018-05-12 11:59:59','2018-05-12 15:59:59','GXSETH','4h','0.005687000000000','0.005630130000000','1.294893827160494','1.281944888888889','227.69365696509473','227.693656965094732','test','test','1.0'),('2018-05-28 07:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005186000000000','0.005830000000000','1.292016285322359','1.452459495454947','249.13541946053977','249.135419460539765','test','test','0.4'),('2018-06-03 11:59:59','2018-06-04 11:59:59','GXSETH','4h','0.005840000000000','0.005781600000000','1.327670332018490','1.314393628698305','227.3408102771387','227.340810277138701','test','test','1.0'),('2018-06-05 03:59:59','2018-06-14 19:59:59','GXSETH','4h','0.005843000000000','0.006392000000000','1.324719953502893','1.449188763099519','226.71914316325402','226.719143163254017','test','test','0.0'),('2018-07-02 19:59:59','2018-07-02 23:59:59','GXSETH','4h','0.005767000000000','0.005730000000000','1.352379688968810','1.343703072271767','234.5031539741304','234.503153974130413','test','test','0.6'),('2018-07-03 03:59:59','2018-07-03 07:59:59','GXSETH','4h','0.005772000000000','0.005714280000000','1.350451551925023','1.336947036405773','233.96596533697553','233.965965336975529','test','test','1.0'),('2018-07-11 15:59:59','2018-07-11 19:59:59','GXSETH','4h','0.005619000000000','0.005562810000000','1.347450548476301','1.333976042991538','239.8025535640329','239.802553564032905','test','test','1.0'),('2018-07-12 11:59:59','2018-07-12 15:59:59','GXSETH','4h','0.005704000000000','0.005646960000000','1.344456213924131','1.331011651784890','235.7041048254087','235.704104825408706','test','test','1.0'),('2018-07-14 23:59:59','2018-07-15 11:59:59','GXSETH','4h','0.005947000000000','0.005887530000000','1.341468533448744','1.328053848114257','225.57062946842845','225.570629468428450','test','test','1.0'),('2018-07-16 03:59:59','2018-07-16 07:59:59','GXSETH','4h','0.005886000000000','0.005827140000000','1.338487492263303','1.325102617340670','227.4018845163613','227.401884516361292','test','test','1.0'),('2018-07-16 11:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005893000000000','0.006489000000000','1.335513075613829','1.470582784262368','226.6270279337907','226.627027933790714','test','test','0.3'),('2018-08-17 19:59:59','2018-08-17 23:59:59','GXSETH','4h','0.005360000000000','0.005307000000000','1.365528566424615','1.352026138435715','254.76279224339834','254.762792243398337','test','test','1.0'),('2018-08-19 07:59:59','2018-08-19 11:59:59','GXSETH','4h','0.005217000000000','0.005215000000000','1.362528026871526','1.362005685285606','261.17079295984786','261.170792959847859','test','test','0.0'),('2018-08-20 23:59:59','2018-08-21 03:59:59','GXSETH','4h','0.005258000000000','0.005205420000000','1.362411950963544','1.348787831453909','259.1122006397003','259.112200639700291','test','test','1.0'),('2018-08-25 15:59:59','2018-08-25 19:59:59','GXSETH','4h','0.005110000000000','0.005067000000000','1.359384368850292','1.347945322302237','266.0243383268673','266.024338326867280','test','test','0.8'),('2018-08-26 15:59:59','2018-08-26 19:59:59','GXSETH','4h','0.005086000000000','0.005081000000000','1.356842358506279','1.355508459215573','266.7798581412268','266.779858141226782','test','test','0.1'),('2018-08-27 15:59:59','2018-08-27 19:59:59','GXSETH','4h','0.005066000000000','0.005113000000000','1.356545936441678','1.369131340905310','267.7745630559965','267.774563055996509','test','test','0.0'),('2018-08-28 15:59:59','2018-08-29 03:59:59','GXSETH','4h','0.005188000000000','0.005136120000000','1.359342692989152','1.345749266059260','262.01671029089283','262.016710290892831','test','test','1.0'),('2018-09-01 11:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005156000000000','0.005104440000000','1.356321931449176','1.342758712134684','263.0570076511202','263.057007651120216','test','test','1.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005138100000000','1.353307882712622','1.339774803885496','260.75296391380004','260.752963913800045','test','test','1.0'),('2018-09-04 15:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005235000000000','0.005182650000000','1.350300531862150','1.336797526543529','257.93706434807063','257.937064348070635','test','test','1.0'),('2018-09-05 19:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005258000000000','0.005205420000000','1.347299864013568','1.333826865373432','256.2380874883164','256.238087488316410','test','test','1.0'),('2018-09-06 19:59:59','2018-09-06 23:59:59','GXSETH','4h','0.005149000000000','0.005215000000000','1.344305864315759','1.361537207692112','261.0809602477684','261.080960247768417','test','test','0.0'),('2018-09-07 03:59:59','2018-09-07 11:59:59','GXSETH','4h','0.005273000000000','0.005220270000000','1.348135051732727','1.334653701215400','255.6675614892332','255.667561489233208','test','test','1.0'),('2018-09-07 15:59:59','2018-09-13 03:59:59','GXSETH','4h','0.005223000000000','0.005515000000000','1.345139196062210','1.420341310795154','257.5414888114512','257.541488811451188','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','GXSETH','4h','0.005202000000000','0.005149980000000','1.361850777113975','1.348232269342835','261.79369033332847','261.793690333328470','test','test','1.0'),('2018-09-22 11:59:59','2018-09-22 15:59:59','GXSETH','4h','0.005267000000000','0.005214330000000','1.358824442053722','1.345236197633185','257.988312522066','257.988312522065996','test','test','1.0'),('2018-09-24 07:59:59','2018-09-24 11:59:59','GXSETH','4h','0.005320000000000','0.005266800000000','1.355804832182491','1.342246783860666','254.8505323651299','254.850532365129908','test','test','1.0'),('2018-09-24 15:59:59','2018-09-30 23:59:59','GXSETH','4h','0.005323000000000','0.005894000000000','1.352791932555419','1.497906378072824','254.14088531944745','254.140885319447449','test','test','0.4'),('2018-10-02 23:59:59','2018-10-03 07:59:59','GXSETH','4h','0.005830000000000','0.005889000000000','1.385039587114842','1.399056282764889','237.57111271266587','237.571112712665865','test','test','0.5'),('2018-10-04 07:59:59','2018-10-04 15:59:59','GXSETH','4h','0.006218000000000','0.006155820000000','1.388154408370408','1.374272864286704','223.2477337359936','223.247733735993592','test','test','1.0'),('2018-10-05 03:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006078000000000','0.006017220000000','1.385069620796252','1.371218924588290','227.8824647575274','227.882464757527401','test','test','1.0'),('2018-10-07 23:59:59','2018-10-18 03:59:59','GXSETH','4h','0.006081000000000','0.006814000000000','1.381991688305593','1.548576116447017','227.2638855953944','227.263885595394413','test','test','0.6'),('2018-10-23 11:59:59','2018-10-23 15:59:59','GXSETH','4h','0.007089000000000','0.007028000000000','1.419010450114799','1.406800034335845','200.1707504746507','200.170750474650703','test','test','0.9'),('2018-11-03 11:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006745000000000','0.006720000000000','1.416297024386142','1.411047591382487','209.97732014620345','209.977320146203454','test','test','0.4'),('2018-11-16 11:59:59','2018-11-16 15:59:59','GXSETH','4h','0.006514000000000','0.006448860000000','1.415130483718664','1.400979178881477','217.24447094238005','217.244470942380048','test','test','1.0'),('2018-11-17 15:59:59','2018-11-17 19:59:59','GXSETH','4h','0.006315000000000','0.006251850000000','1.411985749310400','1.397865891817296','223.592359352399','223.592359352399001','test','test','1.0'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006298380000000','1.408848003200821','1.394759523168813','221.44734410575623','221.447344105756230','test','test','1.0'),('2018-11-20 07:59:59','2018-11-20 11:59:59','GXSETH','4h','0.006252000000000','0.006303000000000','1.405717229860375','1.417184213021424','224.84280707939462','224.842807079394618','test','test','0.0'),('2018-11-22 15:59:59','2018-11-22 19:59:59','GXSETH','4h','0.006463000000000','0.006398370000000','1.408265448340608','1.394182793857202','217.8965570695664','217.896557069566398','test','test','1.0'),('2018-11-23 03:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006560000000000','0.006494400000000','1.405135969566518','1.391084609870853','214.19755633635938','214.197556336359384','test','test','1.0'),('2018-11-30 23:59:59','2018-12-01 11:59:59','GXSETH','4h','0.006356000000000','0.006292440000000','1.402013445189703','1.387993310737806','220.5810958448243','220.581095844824290','test','test','1.0'),('2018-12-03 15:59:59','2018-12-03 19:59:59','GXSETH','4h','0.006374000000000','0.006310260000000','1.398897859755948','1.384908881158389','219.46938496328022','219.469384963280220','test','test','1.0'),('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.395789197845380','1.445903500271181','352.9176227169101','352.917622716910103','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.406925709495558','1.421236893752960','340.7424823190985','340.742482319098485','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.410105972663869','1.648916902303317','329.84935033072964','329.849350330729635','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 15:59:59','GXSETH','4h','0.005179000000000','0.005127210000000','1.463175068139302','1.448543317457909','282.5207700597224','282.520770059722395','test','test','1.0'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.459923567987881','1.450601707924519','300.70516333427014','300.705163334270139','test','test','0.6'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004518360000000','1.457852043529357','1.443273523094063','319.42419884517017','319.424198845170167','test','test','1.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.454612372321513','1.570022277026582','319.6950268838491','319.695026883849096','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.480259017811529','1.484281460794713','309.41869101411555','309.418691014115552','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.481152894030014','2.205838429428910','299.8285210587073','299.828521058707281','test','test','0.2'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSETH','4h','0.007801000000000','0.007722990000000','1.642194124118658','1.625772182877471','210.5107196665373','210.510719666537312','test','test','1.0'),('2019-03-28 11:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007755000000000','0.008025000000000','1.638544803842838','1.695592785407966','211.28882061158458','211.288820611584583','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','GXSETH','4h','0.008023000000000','0.007942770000000','1.651222133079534','1.634709911748738','205.8110598379077','205.811059837907692','test','test','1.0'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007833870000000','1.647552750561579','1.631077223055963','208.20835973228594','208.208359732285942','test','test','1.0'),('2019-04-12 19:59:59','2019-04-13 03:59:59','GXSETH','4h','0.007573000000000','0.007497270000000','1.643891522226997','1.627452607004727','217.07269539508746','217.072695395087464','test','test','1.0'),('2019-04-13 07:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007798000000000','0.007720020000000','1.640238429955382','1.623836045655828','210.34091176652754','210.340911766527540','test','test','1.0'),('2019-04-21 19:59:59','2019-04-22 03:59:59','GXSETH','4h','0.007866000000000','0.007787340000000','1.636593455666592','1.620227521109926','208.059173107881','208.059173107881008','test','test','1.0'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007744770000000','1.632956581320666','1.616627015507459','208.73789867322847','208.737898673228472','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:30:56
