-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 15:59:59','2018-05-09 19:59:59','GXSBTC','4h','0.000438600000000','0.000450100000000','0.033333333333333','0.034207326341389','75.99939200486396','75.999392004863964','test','test','0.0'),('2018-05-09 23:59:59','2018-05-10 19:59:59','GXSBTC','4h','0.000456900000000','0.000452331000000','0.033527554001790','0.033192278461772','73.38050777367086','73.380507773670857','test','test','1.0'),('2018-05-12 11:59:59','2018-05-12 15:59:59','GXSBTC','4h','0.000448700000000','0.000444213000000','0.033453048326231','0.033118517842969','74.55548991805362','74.555489918053624','test','test','1.0'),('2018-05-16 15:59:59','2018-05-16 19:59:59','GXSBTC','4h','0.000437900000000','0.000433521000000','0.033378708218839','0.033044921136651','76.22449924375225','76.224499243752248','test','test','1.0'),('2018-05-17 03:59:59','2018-05-17 07:59:59','GXSBTC','4h','0.000439400000000','0.000435006000000','0.033304533311686','0.032971487978569','75.79547863378748','75.795478633787482','test','test','1.0'),('2018-05-17 15:59:59','2018-05-17 19:59:59','GXSBTC','4h','0.000445300000000','0.000440847000000','0.033230523237660','0.032898218005283','74.62502411331735','74.625024113317352','test','test','1.0'),('2018-05-18 03:59:59','2018-05-18 07:59:59','GXSBTC','4h','0.000439000000000','0.000434610000000','0.033156677630465','0.032825110854160','75.52773947714199','75.527739477141992','test','test','1.0'),('2018-05-29 03:59:59','2018-06-13 11:59:59','GXSBTC','4h','0.000419200000000','0.000506300000000','0.033082996124620','0.039956872466353','78.91936098430288','78.919360984302884','test','test','0.0'),('2018-07-11 23:59:59','2018-07-12 03:59:59','GXSBTC','4h','0.000413800000000','0.000409662000000','0.034610524200560','0.034264418958554','83.64070613958542','83.640706139585419','test','test','1.0'),('2018-07-13 03:59:59','2018-07-19 11:59:59','GXSBTC','4h','0.000399300000000','0.000420000000000','0.034533611924559','0.036323859274517','86.4853792250416','86.485379225041598','test','test','0.0'),('2018-07-20 03:59:59','2018-07-20 19:59:59','GXSBTC','4h','0.000427700000000','0.000424300000000','0.034931444668994','0.034653757243522','81.67277219778869','81.672772197788689','test','test','0.8'),('2018-07-23 07:59:59','2018-07-23 11:59:59','GXSBTC','4h','0.000457600000000','0.000453024000000','0.034869736352223','0.034521038988701','76.20134692356352','76.201346923563520','test','test','1.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','GXSBTC','4h','0.000170200000000','0.000169500000000','0.034792248049218','0.034649154197077','204.41978877331246','204.419788773312462','test','test','0.4'),('2018-09-21 03:59:59','2018-10-02 15:59:59','GXSBTC','4h','0.000171700000000','0.000200000000000','0.034760449415409','0.040489748882247','202.44874441123275','202.448744411232752','test','test','0.0'),('2018-10-04 07:59:59','2018-10-04 15:59:59','GXSBTC','4h','0.000209200000000','0.000207108000000','0.036033627074706','0.035673290803959','172.24487129400572','172.244871294005719','test','test','1.0'),('2018-10-05 07:59:59','2018-10-06 15:59:59','GXSBTC','4h','0.000207900000000','0.000205821000000','0.035953552347873','0.035594016824394','172.93675973003042','172.936759730030417','test','test','1.0'),('2018-10-08 03:59:59','2018-10-11 03:59:59','GXSBTC','4h','0.000208600000000','0.000215200000000','0.035873655564878','0.037008680141715','171.9734207328763','171.973420732876292','test','test','0.8'),('2018-10-12 19:59:59','2018-10-16 19:59:59','GXSBTC','4h','0.000220700000000','0.000225700000000','0.036125883248620','0.036944321926659','163.68773560770074','163.687735607700745','test','test','0.6'),('2018-11-03 11:59:59','2018-11-04 15:59:59','GXSBTC','4h','0.000211400000000','0.000209300000000','0.036307758510406','0.035947085412621','171.74909418356668','171.749094183566683','test','test','1.0'),('2018-11-07 03:59:59','2018-11-07 11:59:59','GXSBTC','4h','0.000211000000000','0.000211300000000','0.036227608933120','0.036279117381840','171.69482906692153','171.694829066921528','test','test','0.0'),('2018-11-16 03:59:59','2018-11-16 07:59:59','GXSBTC','4h','0.000201700000000','0.000204400000000','0.036239055255058','0.036724159118165','179.66809744699165','179.668097446991652','test','test','0.0'),('2018-11-16 11:59:59','2018-11-16 15:59:59','GXSBTC','4h','0.000207200000000','0.000205128000000','0.036346856113526','0.035983387552391','175.41918973709673','175.419189737096730','test','test','1.0'),('2018-12-01 03:59:59','2018-12-01 07:59:59','GXSBTC','4h','0.000185600000000','0.000183744000000','0.036266085322163','0.035903424468941','195.39916660648228','195.399166606482282','test','test','1.0'),('2018-12-22 11:59:59','2018-12-22 15:59:59','GXSBTC','4h','0.000145500000000','0.000146600000000','0.036185494021447','0.036459061330200','248.69755341200758','248.697553412007579','test','test','0.0'),('2018-12-23 11:59:59','2018-12-23 15:59:59','GXSBTC','4h','0.000149900000000','0.000148401000000','0.036246286756726','0.035883823889159','241.8031137873619','241.803113787361895','test','test','1.0'),('2018-12-24 07:59:59','2018-12-24 11:59:59','GXSBTC','4h','0.000148400000000','0.000146916000000','0.036165739452822','0.035804082058294','243.7044437521683','243.704443752168288','test','test','1.0'),('2018-12-24 15:59:59','2018-12-25 03:59:59','GXSBTC','4h','0.000147400000000','0.000145926000000','0.036085371142927','0.035724517431498','244.81255863586614','244.812558635866139','test','test','1.0'),('2018-12-25 11:59:59','2018-12-25 15:59:59','GXSBTC','4h','0.000145800000000','0.000144342000000','0.036005181429276','0.035645129614983','246.94911817061578','246.949118170615776','test','test','1.0'),('2018-12-31 11:59:59','2018-12-31 19:59:59','GXSBTC','4h','0.000144400000000','0.000142956000000','0.035925169914988','0.035565918215838','248.78926533925508','248.789265339255081','test','test','1.0'),('2018-12-31 23:59:59','2019-01-01 11:59:59','GXSBTC','4h','0.000143700000000','0.000142400000000','0.035845336204066','0.035521056892547','249.4456242454156','249.445624245415587','test','test','0.9'),('2019-01-01 15:59:59','2019-01-02 03:59:59','GXSBTC','4h','0.000145200000000','0.000143748000000','0.035773274134840','0.035415541393492','246.37241139696812','246.372411396968118','test','test','1.0'),('2019-01-02 11:59:59','2019-01-02 23:59:59','GXSBTC','4h','0.000144300000000','0.000142857000000','0.035693777970096','0.035336840190395','247.3581286908924','247.358128690892414','test','test','1.0'),('2019-01-04 15:59:59','2019-01-04 23:59:59','GXSBTC','4h','0.000148500000000','0.000147015000000','0.035614458463496','0.035258313878861','239.82800312118218','239.828003121182178','test','test','1.0'),('2019-01-12 03:59:59','2019-01-13 11:59:59','GXSBTC','4h','0.000146900000000','0.000145431000000','0.035535315222466','0.035179962070241','241.90139702154903','241.901397021549030','test','test','1.0'),('2019-01-14 15:59:59','2019-01-15 03:59:59','GXSBTC','4h','0.000147600000000','0.000146124000000','0.035456347855304','0.035101784376751','240.2191589112767','240.219158911276708','test','test','1.0'),('2019-01-16 03:59:59','2019-01-16 07:59:59','GXSBTC','4h','0.000144200000000','0.000144900000000','0.035377555971182','0.035549291679780','245.33672656852667','245.336726568526672','test','test','0.0'),('2019-01-16 11:59:59','2019-01-16 15:59:59','GXSBTC','4h','0.000144800000000','0.000146200000000','0.035415719461981','0.035758136639100','244.5836979418585','244.583697941858503','test','test','0.0'),('2019-01-17 07:59:59','2019-01-25 19:59:59','GXSBTC','4h','0.000147100000000','0.000156200000000','0.035491812168008','0.037687430731766','241.27676524818185','241.276765248181846','test','test','0.0'),('2019-01-30 15:59:59','2019-01-30 23:59:59','GXSBTC','4h','0.000163200000000','0.000161568000000','0.035979727404398','0.035619930130354','220.46401595832242','220.464015958322420','test','test','1.0'),('2019-02-03 23:59:59','2019-02-04 19:59:59','GXSBTC','4h','0.000158400000000','0.000157000000000','0.035899772454611','0.035582476485947','226.63997761749152','226.639977617491525','test','test','0.9'),('2019-02-07 11:59:59','2019-02-09 19:59:59','GXSBTC','4h','0.000159400000000','0.000158400000000','0.035829262239352','0.035604486441113','224.77579823934755','224.775798239347552','test','test','0.6'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GXSBTC','4h','0.000161800000000','0.000164200000000','0.035779312061966','0.036310031153120','221.13295464750033','221.132954647500327','test','test','0.0'),('2019-02-15 15:59:59','2019-02-15 19:59:59','GXSBTC','4h','0.000159100000000','0.000158600000000','0.035897249637778','0.035784436156830','225.6269618967791','225.626961896779108','test','test','0.3'),('2019-02-16 03:59:59','2019-02-16 11:59:59','GXSBTC','4h','0.000159500000000','0.000158400000000','0.035872179975345','0.035624785630687','224.90394968868128','224.903949688681280','test','test','0.7'),('2019-02-16 15:59:59','2019-02-16 19:59:59','GXSBTC','4h','0.000159700000000','0.000159100000000','0.035817203454310','0.035682636628558','224.27804291990952','224.278042919909524','test','test','0.4'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSBTC','4h','0.000165700000000','0.000164043000000','0.035787299715254','0.035429426718101','215.97646176978608','215.976461769786084','test','test','1.0'),('2019-02-17 15:59:59','2019-02-18 11:59:59','GXSBTC','4h','0.000164000000000','0.000162360000000','0.035707772382553','0.035350694658727','217.73031940581026','217.730319405810263','test','test','1.0'),('2019-02-19 03:59:59','2019-02-19 15:59:59','GXSBTC','4h','0.000161600000000','0.000160300000000','0.035628421777258','0.035341806998109','220.47290703748897','220.472907037488966','test','test','0.8'),('2019-02-20 15:59:59','2019-02-21 11:59:59','GXSBTC','4h','0.000162300000000','0.000160677000000','0.035564729604114','0.035209082308073','219.12957242214418','219.129572422144179','test','test','1.0'),('2019-02-23 07:59:59','2019-02-24 15:59:59','GXSBTC','4h','0.000162100000000','0.000161300000000','0.035485696871660','0.035310566967296','218.91238045441358','218.912380454413579','test','test','0.5'),('2019-02-26 19:59:59','2019-02-27 03:59:59','GXSBTC','4h','0.000168900000000','0.000167211000000','0.035446779115135','0.035092311323984','209.868437626614','209.868437626613996','test','test','1.0'),('2019-02-27 19:59:59','2019-02-27 23:59:59','GXSBTC','4h','0.000168800000000','0.000167112000000','0.035368008494879','0.035014328409930','209.52611667582542','209.526116675825421','test','test','1.0'),('2019-02-28 07:59:59','2019-03-04 07:59:59','GXSBTC','4h','0.000169700000000','0.000169000000000','0.035289412920446','0.035143846691546','207.95175557128002','207.951755571280017','test','test','0.7'),('2019-03-05 15:59:59','2019-03-05 19:59:59','GXSBTC','4h','0.000171900000000','0.000170181000000','0.035257064869580','0.034904494220884','205.10218074217312','205.102180742173118','test','test','1.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSBTC','4h','0.000173900000000','0.000248400000000','0.035178715836536','0.050249528543965','202.29278801918343','202.292788019183433','test','test','0.1'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSBTC','4h','0.000268000000000','0.000265320000000','0.038527785327076','0.038142507473805','143.76039301147676','143.760393011476765','test','test','1.0'),('2019-03-28 11:59:59','2019-04-02 07:59:59','GXSBTC','4h','0.000266400000000','0.000263736000000','0.038442168026349','0.038057746346086','144.30243253133966','144.302432531339662','test','test','1.0'),('2019-04-12 19:59:59','2019-04-13 03:59:59','GXSBTC','4h','0.000245400000000','0.000242946000000','0.038356740986290','0.037973173576427','156.30293800444352','156.302938004443519','test','test','1.0'),('2019-04-13 07:59:59','2019-04-18 19:59:59','GXSBTC','4h','0.000253200000000','0.000251900000000','0.038271503784099','0.038075007121700','151.1512787681622','151.151278768162200','test','test','0.5'),('2019-04-22 07:59:59','2019-04-22 11:59:59','GXSBTC','4h','0.000250000000000','0.000249900000000','0.038227837859121','0.038212546723977','152.91135143648444','152.911351436484438','test','test','0.0'),('2019-04-22 23:59:59','2019-04-23 03:59:59','GXSBTC','4h','0.000250100000000','0.000248500000000','0.038224439829089','0.037979901229623','152.83662466648983','152.836624666489826','test','test','0.6');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:15:02
