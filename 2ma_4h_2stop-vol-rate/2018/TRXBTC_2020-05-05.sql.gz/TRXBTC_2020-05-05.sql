-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-17 15:59:59','2018-04-17 19:59:59','TRXBTC','4h','0.000005340000000','0.000005286600000','0.033333333333333','0.033000000000000','6242.197253433209','6242.197253433208971','test','test','1.0'),('2018-04-17 23:59:59','2018-05-04 11:59:59','TRXBTC','4h','0.000005310000000','0.000008530000000','0.033259259259259','0.053427774290297','6263.513984794602','6263.513984794602038','test','test','0.0'),('2018-05-04 19:59:59','2018-05-05 15:59:59','TRXBTC','4h','0.000008870000000','0.000008781300000','0.037741151488379','0.037363739973495','4254.921250099085','4254.921250099085228','test','test','1.0'),('2018-05-08 03:59:59','2018-05-08 07:59:59','TRXBTC','4h','0.000009090000000','0.000008999100000','0.037657282262849','0.037280709440221','4142.715320445447','4142.715320445447105','test','test','1.0'),('2018-05-08 23:59:59','2018-05-09 03:59:59','TRXBTC','4h','0.000008970000000','0.000008880300000','0.037573599413376','0.037197863419242','4188.807069495677','4188.807069495676842','test','test','1.0'),('2018-05-13 15:59:59','2018-05-14 03:59:59','TRXBTC','4h','0.000008530000000','0.000008444700000','0.037490102525791','0.037115201500533','4395.088221077478','4395.088221077478011','test','test','1.0'),('2018-05-16 19:59:59','2018-05-17 15:59:59','TRXBTC','4h','0.000008410000000','0.000008325900000','0.037406791186845','0.037032723274977','4447.8943147258815','4447.894314725881486','test','test','1.0'),('2018-05-19 15:59:59','2018-05-19 19:59:59','TRXBTC','4h','0.000008340000000','0.000008320000000','0.037323664984207','0.037234159792398','4475.259590432535','4475.259590432535333','test','test','0.2'),('2018-05-20 03:59:59','2018-05-23 19:59:59','TRXBTC','4h','0.000008440000000','0.000009190000000','0.037303774941583','0.040618683852269','4419.878547580937','4419.878547580937266','test','test','0.0'),('2018-05-24 15:59:59','2018-05-25 03:59:59','TRXBTC','4h','0.000009620000000','0.000009523800000','0.038040421366180','0.037660017152518','3954.3057553201666','3954.305755320166554','test','test','1.0'),('2018-05-26 15:59:59','2018-05-27 15:59:59','TRXBTC','4h','0.000009800000000','0.000009702000000','0.037955887096477','0.037576328225512','3873.049703722177','3873.049703722177128','test','test','1.0'),('2018-06-19 11:59:59','2018-06-20 03:59:59','TRXBTC','4h','0.000007130000000','0.000007058700000','0.037871540680707','0.037492825273900','5311.576533058531','5311.576533058530913','test','test','1.0'),('2018-06-20 07:59:59','2018-06-20 11:59:59','TRXBTC','4h','0.000007300000000','0.000007227000000','0.037787381701417','0.037409507884403','5176.353657728341','5176.353657728341204','test','test','1.0'),('2018-06-20 15:59:59','2018-06-21 15:59:59','TRXBTC','4h','0.000007290000000','0.000007217100000','0.037703409742080','0.037326375644659','5171.935492740801','5171.935492740801237','test','test','1.0'),('2018-07-16 11:59:59','2018-07-16 15:59:59','TRXBTC','4h','0.000005510000000','0.000005470000000','0.037619624387098','0.037346523665595','6827.518037585844','6827.518037585843558','test','test','0.7'),('2018-07-29 19:59:59','2018-07-29 23:59:59','TRXBTC','4h','0.000004820000000','0.000004771800000','0.037558935337875','0.037183345984496','7792.310236073675','7792.310236073674787','test','test','1.0'),('2018-08-18 03:59:59','2018-08-18 07:59:59','TRXBTC','4h','0.000003550000000','0.000003514500000','0.037475471037124','0.037100716326753','10556.470714682879','10556.470714682878679','test','test','1.0'),('2018-08-25 23:59:59','2018-08-26 03:59:59','TRXBTC','4h','0.000003330000000','0.000003296700000','0.037392192212597','0.037018270290471','11228.88655032953','11228.886550329529200','test','test','1.0'),('2018-08-26 15:59:59','2018-08-30 11:59:59','TRXBTC','4h','0.000003370000000','0.000003440000000','0.037309098452125','0.038084064888816','11070.94909558602','11070.949095586020121','test','test','0.0'),('2018-09-01 15:59:59','2018-09-02 03:59:59','TRXBTC','4h','0.000003710000000','0.000003672900000','0.037481313215834','0.037106500083676','10102.779842542857','10102.779842542857295','test','test','1.0'),('2018-09-19 07:59:59','2018-09-19 11:59:59','TRXBTC','4h','0.000003150000000','0.000003118500000','0.037398021408688','0.037024041194601','11872.38774878977','11872.387748789769830','test','test','1.0'),('2018-09-20 11:59:59','2018-09-25 03:59:59','TRXBTC','4h','0.000003210000000','0.000003270000000','0.037314914694446','0.038012389735464','11624.584016961438','11624.584016961438465','test','test','0.9'),('2018-09-26 15:59:59','2018-09-26 19:59:59','TRXBTC','4h','0.000003350000000','0.000003316500000','0.037469909148006','0.037095210056526','11185.047506867395','11185.047506867394986','test','test','1.0'),('2018-09-27 15:59:59','2018-09-28 11:59:59','TRXBTC','4h','0.000003380000000','0.000003346200000','0.037386642683232','0.037012776256400','11061.13688853031','11061.136888530310898','test','test','1.0'),('2018-09-28 15:59:59','2018-09-28 19:59:59','TRXBTC','4h','0.000003300000000','0.000003330000000','0.037303561255048','0.037642684539185','11304.109471226533','11304.109471226533060','test','test','0.0'),('2018-10-01 19:59:59','2018-10-03 03:59:59','TRXBTC','4h','0.000003350000000','0.000003316500000','0.037378921984856','0.037005132765007','11157.887159658443','11157.887159658443124','test','test','1.0'),('2018-10-03 11:59:59','2018-10-03 15:59:59','TRXBTC','4h','0.000003320000000','0.000003320000000','0.037295857713778','0.037295857713778','11233.692082463322','11233.692082463321640','test','test','0.0'),('2018-10-04 11:59:59','2018-10-11 03:59:59','TRXBTC','4h','0.000003370000000','0.000003630000000','0.037295857713778','0.040173282937986','11067.020093109266','11067.020093109265872','test','test','0.0'),('2018-10-12 15:59:59','2018-10-12 23:59:59','TRXBTC','4h','0.000003670000000','0.000003633300000','0.037935285541380','0.037555932685966','10336.590065771117','10336.590065771117224','test','test','1.0'),('2018-10-15 11:59:59','2018-10-16 03:59:59','TRXBTC','4h','0.000003760000000','0.000003722400000','0.037850984906844','0.037472475057776','10066.751305011583','10066.751305011583099','test','test','1.0'),('2018-10-18 07:59:59','2018-10-18 19:59:59','TRXBTC','4h','0.000003760000000','0.000003722400000','0.037766871607051','0.037389202890980','10044.38074655603','10044.380746556029408','test','test','1.0'),('2018-11-04 11:59:59','2018-11-08 03:59:59','TRXBTC','4h','0.000003620000000','0.000003610000000','0.037682945225702','0.037578848691929','10409.653377265624','10409.653377265623931','test','test','0.3'),('2018-11-28 15:59:59','2019-01-01 03:59:59','TRXBTC','4h','0.000003470000000','0.000005050000000','0.037659812662641','0.054807508341884','10852.971948887864','10852.971948887863618','test','test','0.9'),('2019-01-01 11:59:59','2019-01-02 03:59:59','TRXBTC','4h','0.000005120000000','0.000005068800000','0.041470411702473','0.041055707585448','8099.6897856391915','8099.689785639191541','test','test','1.0'),('2019-01-02 11:59:59','2019-01-03 07:59:59','TRXBTC','4h','0.000005140000000','0.000005110000000','0.041378255232023','0.041136747905766','8050.244208564722','8050.244208564721703','test','test','0.6'),('2019-01-03 15:59:59','2019-01-03 19:59:59','TRXBTC','4h','0.000005360000000','0.000005306400000','0.041324586937299','0.040911341067926','7709.8109957647175','7709.810995764717518','test','test','1.0'),('2019-01-04 07:59:59','2019-01-13 03:59:59','TRXBTC','4h','0.000005320000000','0.000006210000000','0.041232754521883','0.048130715334754','7750.517767271178','7750.517767271177945','test','test','0.8'),('2019-01-14 03:59:59','2019-01-19 03:59:59','TRXBTC','4h','0.000006470000000','0.000006620000000','0.042765634702521','0.043757110004743','6609.835348148481','6609.835348148480989','test','test','0.0'),('2019-01-20 15:59:59','2019-01-20 19:59:59','TRXBTC','4h','0.000006590000000','0.000006680000000','0.042985962547459','0.043573024251446','6522.90782207267','6522.907822072669660','test','test','0.0'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXBTC','4h','0.000007100000000','0.000007590000000','0.043116420703900','0.046092061006000','6072.735310408512','6072.735310408512305','test','test','0.0'),('2019-02-04 11:59:59','2019-02-04 23:59:59','TRXBTC','4h','0.000007880000000','0.000007801200000','0.043777674104367','0.043339897363323','5555.542399031358','5555.542399031358400','test','test','1.0'),('2019-02-05 07:59:59','2019-02-05 15:59:59','TRXBTC','4h','0.000007800000000','0.000007722000000','0.043680390384135','0.043243586480294','5600.0500492480905','5600.050049248090545','test','test','1.0'),('2019-02-08 15:59:59','2019-02-08 19:59:59','TRXBTC','4h','0.000007590000000','0.000007514100000','0.043583322849948','0.043147489621449','5742.203274037974','5742.203274037973642','test','test','1.0'),('2019-03-23 11:59:59','2019-03-24 15:59:59','TRXBTC','4h','0.000005980000000','0.000005920200000','0.043486471021393','0.043051606311179','7271.985120634262','7271.985120634261875','test','test','1.0'),('2019-03-29 03:59:59','2019-03-29 07:59:59','TRXBTC','4h','0.000005750000000','0.000005800000000','0.043389834419123','0.043767137327115','7546.058159847498','7546.058159847498246','test','test','0.0'),('2019-04-01 15:59:59','2019-04-02 07:59:59','TRXBTC','4h','0.000005810000000','0.000005751900000','0.043473679509788','0.043038942714690','7482.561017175214','7482.561017175214147','test','test','1.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','TRXBTC','4h','0.000005590000000','0.000005534100000','0.043377071333100','0.042943300619769','7759.762313613514','7759.762313613514380','test','test','1.0'),('2019-04-08 15:59:59','2019-04-08 23:59:59','TRXBTC','4h','0.000005960000000','0.000005900400000','0.043280677841248','0.042847871062836','7261.858698196011','7261.858698196010664','test','test','1.0'),('2019-04-09 11:59:59','2019-04-09 15:59:59','TRXBTC','4h','0.000005860000000','0.000005801400000','0.043184498557157','0.042752653571585','7369.368354463594','7369.368354463594187','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:37:13
