-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','ETHBTC','4h','0.061941000000000','0.061321590000000','0.033333333333333','0.033000000000000','0.5381465157703836','0.538146515770384','test','test','1.0'),('2018-01-03 11:59:59','2018-01-05 19:59:59','ETHBTC','4h','0.058693000000000','0.058499000000000','0.033259259259259','0.033149326280943','0.5666648366800016','0.566664836680002','test','test','0.6'),('2018-01-06 03:59:59','2018-01-16 11:59:59','ETHBTC','4h','0.058299000000000','0.093500000000000','0.033234829708522','0.053302056257342','0.5700754679929749','0.570075467992975','test','test','0.0'),('2018-01-17 19:59:59','2018-02-02 15:59:59','ETHBTC','4h','0.088038000000000','0.107076000000000','0.037694213386038','0.045845493906306','0.4281584473299938','0.428158447329994','test','test','0.0'),('2018-02-25 19:59:59','2018-02-26 15:59:59','ETHBTC','4h','0.087994000000000','0.087114060000000','0.039505609057209','0.039110552966637','0.44895798642189993','0.448957986421900','test','test','1.0'),('2018-04-09 03:59:59','2018-04-25 11:59:59','ETHBTC','4h','0.057799000000000','0.068881000000000','0.039417818814859','0.046975532064332','0.6819809826270234','0.681980982627023','test','test','0.0'),('2018-04-26 07:59:59','2018-05-01 03:59:59','ETHBTC','4h','0.071468000000000','0.071767000000000','0.041097310648076','0.041269249080434','0.5750449242748581','0.575044924274858','test','test','0.7'),('2018-05-01 07:59:59','2018-05-01 15:59:59','ETHBTC','4h','0.073734000000000','0.072996660000000','0.041135519188600','0.040724163996714','0.557890785642981','0.557890785642981','test','test','1.0'),('2018-05-02 07:59:59','2018-05-07 11:59:59','ETHBTC','4h','0.074719000000000','0.078480000000000','0.041044106923736','0.043110072556844','0.5493128511320547','0.549312851132055','test','test','0.7'),('2018-05-07 19:59:59','2018-05-08 11:59:59','ETHBTC','4h','0.080325000000000','0.079521750000000','0.041503210397760','0.041088178293782','0.5166910724900093','0.516691072490009','test','test','1.0'),('2018-05-08 15:59:59','2018-05-11 07:59:59','ETHBTC','4h','0.080149000000000','0.079512000000000','0.041410981041320','0.041081859094405','0.516674955911121','0.516674955911121','test','test','0.8'),('2018-05-11 15:59:59','2018-05-11 19:59:59','ETHBTC','4h','0.079438000000000','0.080113000000000','0.041337842830895','0.041689098450508','0.5203786957236447','0.520378695723645','test','test','0.0'),('2018-05-12 11:59:59','2018-05-12 15:59:59','ETHBTC','4h','0.079422000000000','0.079269000000000','0.041415899635253','0.041336115285272','0.5214663397453266','0.521466339745327','test','test','0.2'),('2018-05-13 15:59:59','2018-05-14 03:59:59','ETHBTC','4h','0.084224000000000','0.083381760000000','0.041398169779702','0.040984188081905','0.4915246221944101','0.491524622194410','test','test','1.0'),('2018-05-15 15:59:59','2018-05-15 23:59:59','ETHBTC','4h','0.084251000000000','0.083408490000000','0.041306173846858','0.040893112108389','0.49027517592501235','0.490275175925012','test','test','1.0'),('2018-05-16 03:59:59','2018-05-21 19:59:59','ETHBTC','4h','0.083410000000000','0.083041000000000','0.041214382349421','0.041032052807556','0.4941179996333853','0.494117999633385','test','test','0.5'),('2018-05-22 07:59:59','2018-05-22 11:59:59','ETHBTC','4h','0.083412000000000','0.083332000000000','0.041173864673451','0.041134375041577','0.49362039842529454','0.493620398425295','test','test','0.1'),('2018-06-02 19:59:59','2018-06-02 23:59:59','ETHBTC','4h','0.078069000000000','0.077350000000000','0.041165089199701','0.040785966895911','0.5272911040195326','0.527291104019533','test','test','0.9'),('2018-06-03 11:59:59','2018-06-04 11:59:59','ETHBTC','4h','0.080321000000000','0.079517790000000','0.041080839798859','0.040670031400870','0.511458271172653','0.511458271172653','test','test','1.0'),('2018-06-05 07:59:59','2018-06-05 11:59:59','ETHBTC','4h','0.079096000000000','0.079060000000000','0.040989549043750','0.040970892932625','0.5182253090390159','0.518225309039016','test','test','0.0'),('2018-06-05 19:59:59','2018-06-07 07:59:59','ETHBTC','4h','0.079773000000000','0.079030000000000','0.040985403241278','0.040603668135311','0.513775378151477','0.513775378151477','test','test','0.9'),('2018-06-19 07:59:59','2018-06-21 19:59:59','ETHBTC','4h','0.077526000000000','0.078102000000000','0.040900573217730','0.041204454885473','0.5275723398308897','0.527572339830890','test','test','0.0'),('2018-07-08 15:59:59','2018-07-09 03:59:59','ETHBTC','4h','0.072687000000000','0.071960130000000','0.040968102477228','0.040558421452456','0.5636235155836394','0.563623515583639','test','test','1.0'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHBTC','4h','0.070867000000000','0.070747000000000','0.040877062249501','0.040807844595728','0.5768137814427151','0.576813781442715','test','test','0.2'),('2018-07-16 07:59:59','2018-07-17 07:59:59','ETHBTC','4h','0.071090000000000','0.070809000000000','0.040861680548662','0.040700165114224','0.574788022909867','0.574788022909867','test','test','0.4'),('2018-08-04 19:59:59','2018-08-07 15:59:59','ETHBTC','4h','0.058032000000000','0.057458000000000','0.040825788229898','0.040421976497682','0.703504759958272','0.703504759958272','test','test','1.0'),('2018-09-20 23:59:59','2018-09-21 03:59:59','ETHBTC','4h','0.034522000000000','0.034176780000000','0.040736052289406','0.040328691766512','1.1800026733505014','1.180002673350501','test','test','1.0'),('2018-09-21 07:59:59','2018-09-24 23:59:59','ETHBTC','4h','0.034040000000000','0.034631000000000','0.040645527728763','0.041351212419941','1.1940519309272293','1.194051930927229','test','test','0.7'),('2018-09-27 19:59:59','2018-09-28 07:59:59','ETHBTC','4h','0.034297000000000','0.033977000000000','0.040802346549025','0.040421649960528','1.1896768390536974','1.189676839053697','test','test','0.9'),('2018-09-29 11:59:59','2018-10-01 07:59:59','ETHBTC','4h','0.035291000000000','0.034938090000000','0.040717747307136','0.040310569834065','1.153771423511276','1.153771423511276','test','test','1.0'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHBTC','4h','0.034409000000000','0.034179000000000','0.040627263424232','0.040355698700248','1.1807161912357746','1.180716191235775','test','test','0.7'),('2018-10-08 15:59:59','2018-10-09 15:59:59','ETHBTC','4h','0.034402000000000','0.034397000000000','0.040566915707791','0.040561019696555','1.179202247188852','1.179202247188852','test','test','0.3'),('2018-10-10 07:59:59','2018-10-10 15:59:59','ETHBTC','4h','0.034358000000000','0.034179000000000','0.040565605483072','0.040354264794398','1.1806742384036257','1.180674238403626','test','test','0.5'),('2018-10-28 19:59:59','2018-10-28 23:59:59','ETHBTC','4h','0.031562000000000','0.031616000000000','0.040518640885589','0.040587964965426','1.2837792562444923','1.283779256244492','test','test','0.0'),('2018-10-29 07:59:59','2018-10-29 15:59:59','ETHBTC','4h','0.031591000000000','0.031275090000000','0.040534046236664','0.040128705774297','1.2830884187478568','1.283088418747857','test','test','1.0'),('2018-11-02 15:59:59','2018-11-03 03:59:59','ETHBTC','4h','0.031463000000000','0.031384000000000','0.040443970578360','0.040342420386843','1.2854454622369063','1.285445462236906','test','test','0.3'),('2018-11-04 07:59:59','2018-11-13 11:59:59','ETHBTC','4h','0.031534000000000','0.032804000000000','0.040421403869134','0.042049335083499','1.2818356018625539','1.281835601862554','test','test','0.0'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ETHBTC','4h','0.032843000000000','0.032514570000000','0.040783166361215','0.040375334697603','1.2417612995528695','1.241761299552870','test','test','1.0'),('2018-12-17 19:59:59','2018-12-18 07:59:59','ETHBTC','4h','0.026991000000000','0.026721090000000','0.040692537102634','0.040285611731608','1.5076335483173815','1.507633548317381','test','test','1.0'),('2018-12-18 11:59:59','2018-12-18 19:59:59','ETHBTC','4h','0.026757000000000','0.026509000000000','0.040602109242406','0.040225784426765','1.5174387727475593','1.517438772747559','test','test','0.9'),('2018-12-18 23:59:59','2018-12-19 07:59:59','ETHBTC','4h','0.027493000000000','0.027218070000000','0.040518481505597','0.040113296690541','1.4737744700686477','1.473774470068648','test','test','1.0'),('2018-12-19 19:59:59','2018-12-19 23:59:59','ETHBTC','4h','0.027344000000000','0.027070560000000','0.040428440435585','0.040024156031229','1.4785123038174697','1.478512303817470','test','test','1.0'),('2018-12-20 15:59:59','2019-01-02 07:59:59','ETHBTC','4h','0.027009000000000','0.038058000000000','0.040338599456839','0.056840550117679','1.4935243606516015','1.493524360651602','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 23:58:01
