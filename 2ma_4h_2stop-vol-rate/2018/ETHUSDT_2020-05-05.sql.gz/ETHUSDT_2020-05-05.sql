-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-01 03:59:59','2018-02-01 11:59:59','ETHUSDT','4h','1140.000000000000000','1128.599999999999909','222.222222222222200','219.999999999999943','0.1949317738791423','0.194931773879142','test','test','1.0'),('2018-02-14 15:59:59','2018-02-18 11:59:59','ETHUSDT','4h','903.059999999999945','929.179999999999950','221.728395061728378','228.141640780741909','0.24553008112609173','0.245530081126092','test','test','0.1'),('2018-02-27 11:59:59','2018-02-27 15:59:59','ETHUSDT','4h','885.169999999999959','876.318299999999908','223.153560777064740','220.922025169294102','0.2521024896653352','0.252102489665335','test','test','1.0'),('2018-03-05 07:59:59','2018-03-05 11:59:59','ETHUSDT','4h','867.799999999999955','869.139999999999986','222.657663975337954','223.001477376728786','0.2565771652170292','0.256577165217029','test','test','0.0'),('2018-04-09 07:59:59','2018-04-09 11:59:59','ETHUSDT','4h','418.810000000000002','414.621899999999982','222.734066953424758','220.506726283890515','0.53182604749988','0.531826047499880','test','test','1.0'),('2018-04-10 23:59:59','2018-05-01 03:59:59','ETHUSDT','4h','416.069999999999993','641.860000000000014','222.239102360194948','342.842286732796765','0.5341387323291632','0.534138732329163','test','test','0.7'),('2018-05-03 03:59:59','2018-05-07 11:59:59','ETHUSDT','4h','717.990000000000009','733.000000000000000','249.039809998550908','254.246132576968762','0.34685693393856587','0.346856933938566','test','test','0.0'),('2018-05-07 19:59:59','2018-05-08 11:59:59','ETHUSDT','4h','758.000000000000000','750.419999999999959','250.196770571532653','247.694802865817337','0.3300748952131038','0.330074895213104','test','test','1.0'),('2018-05-13 15:59:59','2018-05-14 03:59:59','ETHUSDT','4h','727.009999999999991','719.739900000000034','249.640777748040364','247.144369970559978','0.34338011547026914','0.343380115470269','test','test','1.0'),('2018-05-14 15:59:59','2018-05-15 15:59:59','ETHUSDT','4h','733.250000000000000','725.917500000000018','249.086020464155808','246.595160259514245','0.3397013576053949','0.339701357605395','test','test','1.0'),('2018-05-19 15:59:59','2018-05-19 19:59:59','ETHUSDT','4h','706.919999999999959','703.659999999999968','248.532495974235502','247.386374861696595','0.3515708934168442','0.351570893416844','test','test','0.5'),('2018-05-20 11:59:59','2018-05-21 03:59:59','ETHUSDT','4h','712.500000000000000','712.720000000000027','248.277802393671237','248.354463609848978','0.34846007353497715','0.348460073534977','test','test','0.0'),('2018-06-03 11:59:59','2018-06-04 07:59:59','ETHUSDT','4h','619.929999999999950','613.730699999999956','248.294838219488582','245.811889837293705','0.4005207656017431','0.400520765601743','test','test','1.0'),('2018-06-05 19:59:59','2018-06-06 19:59:59','ETHUSDT','4h','607.240000000000009','601.167599999999993','247.743071912334131','245.265641193210797','0.4079821354198243','0.407982135419824','test','test','1.0'),('2018-06-19 11:59:59','2018-06-20 03:59:59','ETHUSDT','4h','534.000000000000000','528.659999999999968','247.192531752528936','244.720606435003646','0.4629073628324512','0.462907362832451','test','test','1.0'),('2018-06-20 15:59:59','2018-06-21 15:59:59','ETHUSDT','4h','535.289999999999964','529.937099999999987','246.643215015301081','244.176782865148056','0.4607655943793105','0.460765594379310','test','test','1.0'),('2018-07-02 15:59:59','2018-07-03 15:59:59','ETHUSDT','4h','474.430000000000007','469.685699999999997','246.095118981933751','243.634167792114425','0.5187174482683088','0.518717448268309','test','test','1.0'),('2018-07-04 15:59:59','2018-07-04 23:59:59','ETHUSDT','4h','473.449999999999989','468.715499999999963','245.548240939751707','243.092758530354189','0.5186360564785124','0.518636056478512','test','test','1.0'),('2018-07-05 03:59:59','2018-07-05 19:59:59','ETHUSDT','4h','470.569999999999993','465.864300000000014','245.002578182107783','242.552552400286714','0.5206506538498157','0.520650653849816','test','test','1.0'),('2018-07-07 23:59:59','2018-07-09 15:59:59','ETHUSDT','4h','485.569999999999993','480.714299999999980','244.458128008369812','242.013546728286116','0.5034456988866071','0.503445698886607','test','test','1.0'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHUSDT','4h','452.959999999999980','450.189999999999998','243.914887723906759','242.423267627220042','0.5384910096341989','0.538491009634199','test','test','0.6'),('2018-07-16 07:59:59','2018-07-19 19:59:59','ETHUSDT','4h','452.819999999999993','467.850000000000023','243.583416591309714','251.668436580195788','0.5379254816291457','0.537925481629146','test','test','0.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','ETHUSDT','4h','463.490000000000009','458.855099999999993','245.380087699951019','242.926286822951511','0.5294182996395845','0.529418299639585','test','test','1.0'),('2018-07-24 07:59:59','2018-07-25 15:59:59','ETHUSDT','4h','472.329999999999984','467.800000000000011','244.834798616173401','242.486648725776320','0.5183553841936218','0.518355384193622','test','test','1.0'),('2018-07-25 19:59:59','2018-07-26 23:59:59','ETHUSDT','4h','474.230000000000018','469.487700000000018','244.312987529418479','241.869857654124303','0.5151782627193945','0.515178262719394','test','test','1.0'),('2018-07-27 19:59:59','2018-07-27 23:59:59','ETHUSDT','4h','467.360000000000014','470.089999999999975','243.770069779353094','245.194009120541097','0.5215895022666747','0.521589502266675','test','test','0.0'),('2018-08-28 15:59:59','2018-08-28 19:59:59','ETHUSDT','4h','288.589999999999975','293.139999999999986','244.086500744061567','247.934844686628793','0.8457898774873058','0.845789877487306','test','test','0.0'),('2018-08-28 23:59:59','2018-08-29 03:59:59','ETHUSDT','4h','295.439999999999998','292.485599999999977','244.941688286854259','242.492271403985683','0.8290742224710745','0.829074222471075','test','test','1.0'),('2018-08-29 07:59:59','2018-08-29 15:59:59','ETHUSDT','4h','292.560000000000002','289.634400000000028','244.397373423994594','241.953399689754661','0.8353752167896998','0.835375216789700','test','test','1.0'),('2018-09-01 15:59:59','2018-09-02 11:59:59','ETHUSDT','4h','295.540000000000020','292.584600000000023','243.854268149719047','241.415725468221865','0.8251142591517867','0.825114259151787','test','test','1.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ETHUSDT','4h','289.689999999999998','292.540000000000020','243.312369776052975','245.706101882310548','0.8399060021956332','0.839906002195633','test','test','0.0'),('2018-09-04 11:59:59','2018-09-04 15:59:59','ETHUSDT','4h','288.769999999999982','289.329999999999984','243.844310244110261','244.317187668138729','0.8444239714794136','0.844423971479414','test','test','0.0'),('2018-09-15 15:59:59','2018-09-15 23:59:59','ETHUSDT','4h','224.039999999999992','221.799599999999998','243.949394116116565','241.509900174955391','1.0888653549192848','1.088865354919285','test','test','1.0'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHUSDT','4h','224.000000000000000','228.060000000000002','243.407284351414091','247.819041380283466','1.0866396622830987','1.086639662283099','test','test','0.6'),('2018-09-27 19:59:59','2018-09-28 11:59:59','ETHUSDT','4h','228.599999999999994','226.313999999999993','244.387674802273949','241.943798054251204','1.0690624444543917','1.069062444454392','test','test','1.0'),('2018-09-29 11:59:59','2018-10-01 07:59:59','ETHUSDT','4h','232.389999999999986','230.066099999999977','243.844591080491114','241.406145169686198','1.0492903785898322','1.049290378589832','test','test','1.0'),('2018-10-01 19:59:59','2018-10-02 15:59:59','ETHUSDT','4h','229.860000000000014','227.750000000000000','243.302714211423336','241.069316808716877','1.0584821813774616','1.058482181377462','test','test','0.9'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHUSDT','4h','228.370000000000005','226.086299999999994','242.806403677488561','240.378339640713676','1.0632149742851011','1.063214974285101','test','test','1.0'),('2018-10-07 23:59:59','2018-10-08 07:59:59','ETHUSDT','4h','226.139999999999986','224.979999999999990','242.266833891538568','241.024110236660249','1.0713134955847643','1.071313495584764','test','test','0.5'),('2018-10-08 11:59:59','2018-10-10 03:59:59','ETHUSDT','4h','226.330000000000013','226.500000000000000','241.990673079343395','242.172436055632403','1.0691939781705624','1.069193978170562','test','test','0.0'),('2018-10-15 11:59:59','2018-10-15 15:59:59','ETHUSDT','4h','221.750000000000000','219.532499999999999','242.031064851852079','239.610754203333556','1.0914591425111706','1.091459142511171','test','test','1.0'),('2018-11-04 15:59:59','2018-11-09 23:59:59','ETHUSDT','4h','205.840000000000003','210.770000000000010','241.493218041070151','247.277135476663204','1.1732084047856108','1.173208404785611','test','test','0.0'),('2018-11-10 15:59:59','2018-11-10 23:59:59','ETHUSDT','4h','213.969999999999999','213.250000000000000','242.778533026757515','241.961593531598083','1.1346381877214446','1.134638187721445','test','test','0.3'),('2018-11-11 19:59:59','2018-11-13 03:59:59','ETHUSDT','4h','211.379999999999995','211.699999999999989','242.596990916722120','242.964249110937970','1.1476818569246008','1.147681856924601','test','test','0.0'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ETHUSDT','4h','95.409999999999997','94.455900000000000','242.678603848770052','240.251817810282347','2.5435342610708527','2.543534261070853','test','test','1.0'),('2018-12-18 03:59:59','2018-12-18 07:59:59','ETHUSDT','4h','94.829999999999998','93.881699999999995','242.139318062439514','239.717924881815122','2.553404176552141','2.553404176552141','test','test','1.0'),('2018-12-18 15:59:59','2018-12-27 19:59:59','ETHUSDT','4h','93.819999999999993','114.099999999999994','241.601230688967433','293.825414854094902','2.575157010114767','2.575157010114767','test','test','0.1'),('2018-12-28 15:59:59','2019-01-10 07:59:59','ETHUSDT','4h','126.620000000000005','135.449999999999989','253.206604947884585','270.864276103229884','1.9997362576834985','1.999736257683498','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:34:40
