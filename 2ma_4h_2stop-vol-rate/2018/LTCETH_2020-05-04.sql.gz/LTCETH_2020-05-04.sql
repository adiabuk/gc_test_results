-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-05-31 11:59:59','LTCETH','4h','0.209700000000000','0.207603000000000','1.297777777777778','1.284800000000000','6.188735230223069','6.188735230223069','test','test','1.0'),('2018-06-01 19:59:59','2018-06-01 23:59:59','LTCETH','4h','0.207230000000000','0.207420000000000','1.294893827160494','1.296081057904886','6.248582865224599','6.248582865224599','test','test','0.0'),('2018-06-11 03:59:59','2018-06-11 07:59:59','LTCETH','4h','0.202240000000000','0.201430000000000','1.295157656214803','1.289970365364655','6.404062777960854','6.404062777960854','test','test','0.4'),('2018-06-11 19:59:59','2018-06-11 23:59:59','LTCETH','4h','0.203090000000000','0.201590000000000','1.294004924914770','1.284447549429162','6.371583657072088','6.371583657072088','test','test','0.7'),('2018-06-12 19:59:59','2018-06-12 23:59:59','LTCETH','4h','0.202240000000000','0.202100000000000','1.291881063695746','1.290986763117634','6.387861272229758','6.387861272229758','test','test','0.1'),('2018-06-14 15:59:59','2018-06-14 19:59:59','LTCETH','4h','0.203520000000000','0.201484800000000','1.291682330233944','1.278765506931604','6.346709562863323','6.346709562863323','test','test','1.0'),('2018-06-27 19:59:59','2018-06-27 23:59:59','LTCETH','4h','0.184770000000000','0.182922300000000','1.288811925055646','1.275923805805089','6.975222844918796','6.975222844918796','test','test','1.0'),('2018-07-03 03:59:59','2018-07-05 03:59:59','LTCETH','4h','0.182600000000000','0.180830000000000','1.285947898555522','1.273482795705340','7.042430988803515','7.042430988803515','test','test','1.0'),('2018-07-11 11:59:59','2018-07-11 15:59:59','LTCETH','4h','0.179540000000000','0.177744600000000','1.283177875699926','1.270346096942927','7.147030609891533','7.147030609891533','test','test','1.0'),('2018-07-13 23:59:59','2018-07-14 03:59:59','LTCETH','4h','0.177240000000000','0.176370000000000','1.280326369309482','1.274041761200143','7.223687481998881','7.223687481998881','test','test','0.5'),('2018-07-15 03:59:59','2018-07-15 07:59:59','LTCETH','4h','0.177350000000000','0.176580000000000','1.278929789729629','1.273377063831169','7.211332335661846','7.211332335661846','test','test','0.4'),('2018-07-17 19:59:59','2018-07-21 03:59:59','LTCETH','4h','0.178010000000000','0.177600000000000','1.277695850641082','1.274753008672862','7.177663337121969','7.177663337121969','test','test','0.2'),('2018-07-23 03:59:59','2018-07-26 07:59:59','LTCETH','4h','0.182220000000000','0.180880000000000','1.277041885759255','1.267650841269532','7.0082421565100175','7.008242156510017','test','test','0.8'),('2018-07-31 11:59:59','2018-07-31 15:59:59','LTCETH','4h','0.180830000000000','0.180100000000000','1.274954986983761','1.269808069212937','7.050572288800317','7.050572288800317','test','test','0.4'),('2018-07-31 23:59:59','2018-08-01 03:59:59','LTCETH','4h','0.182380000000000','0.184150000000000','1.273811227479134','1.286173580109017','6.984380016883067','6.984380016883067','test','test','0.0'),('2018-08-01 19:59:59','2018-08-04 19:59:59','LTCETH','4h','0.185150000000000','0.183298500000000','1.276558416952441','1.263792832782917','6.894725449378562','6.894725449378562','test','test','1.0'),('2018-08-06 03:59:59','2018-08-06 11:59:59','LTCETH','4h','0.184350000000000','0.182506500000000','1.273721620470325','1.260984404265622','6.909257501873201','6.909257501873201','test','test','1.0'),('2018-08-07 19:59:59','2018-08-07 23:59:59','LTCETH','4h','0.183210000000000','0.181377900000000','1.270891127980391','1.258182216700587','6.936799999892968','6.936799999892968','test','test','1.0'),('2018-08-11 15:59:59','2018-08-18 15:59:59','LTCETH','4h','0.180270000000000','0.195540000000000','1.268066925473768','1.375480149814947','7.034264855349018','7.034264855349018','test','test','0.0'),('2018-08-19 15:59:59','2018-08-20 07:59:59','LTCETH','4h','0.193950000000000','0.192010500000000','1.291936530882918','1.279017165574089','6.661183453894913','6.661183453894913','test','test','1.0'),('2018-08-20 11:59:59','2018-09-13 23:59:59','LTCETH','4h','0.193620000000000','0.258530000000000','1.289065560814290','1.721217433309154','6.657708711983729','6.657708711983729','test','test','0.0'),('2018-09-14 19:59:59','2018-09-15 15:59:59','LTCETH','4h','0.264460000000000','0.261815400000000','1.385099310257593','1.371248317155017','5.237462414949683','5.237462414949683','test','test','1.0'),('2018-09-17 19:59:59','2018-09-18 03:59:59','LTCETH','4h','0.264870000000000','0.262221300000000','1.382021311790354','1.368201098672450','5.217734404765937','5.217734404765937','test','test','1.0'),('2018-09-25 07:59:59','2018-09-25 23:59:59','LTCETH','4h','0.264830000000000','0.262181700000000','1.378950153319708','1.365160651786511','5.206925776232709','5.206925776232709','test','test','1.0'),('2018-09-27 15:59:59','2018-09-27 19:59:59','LTCETH','4h','0.287610000000000','0.284733900000000','1.375885819645664','1.362126961449207','4.783859461234535','4.783859461234535','test','test','1.0'),('2018-09-29 23:59:59','2018-09-30 03:59:59','LTCETH','4h','0.266250000000000','0.264200000000000','1.372828295602008','1.362258162246199','5.156162612589701','5.156162612589701','test','test','0.8'),('2018-10-11 11:59:59','2018-10-11 15:59:59','LTCETH','4h','0.261990000000000','0.262340000000000','1.370479377078494','1.372310240019742','5.231036974993299','5.231036974993299','test','test','0.0'),('2018-10-11 23:59:59','2018-10-15 07:59:59','LTCETH','4h','0.267890000000000','0.265211100000000','1.370886235509883','1.357177373154784','5.117347551270607','5.117347551270607','test','test','1.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','LTCETH','4h','0.268080000000000','0.265399200000000','1.367839821653194','1.354161423436662','5.102356839947755','5.102356839947755','test','test','1.0'),('2018-10-23 15:59:59','2018-10-23 19:59:59','LTCETH','4h','0.261240000000000','0.258627600000000','1.364800177605076','1.351152175829025','5.22431548616244','5.224315486162440','test','test','1.0'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCETH','4h','0.257180000000000','0.255880000000000','1.361767288321509','1.354883792424402','5.294996843928412','5.294996843928412','test','test','0.6'),('2018-11-03 11:59:59','2018-11-03 15:59:59','LTCETH','4h','0.255890000000000','0.255230000000000','1.360237622566596','1.356729252443129','5.315712308283231','5.315712308283231','test','test','0.3'),('2018-11-04 07:59:59','2018-11-04 19:59:59','LTCETH','4h','0.257430000000000','0.255040000000000','1.359457984761382','1.346836671846882','5.280884064644298','5.280884064644298','test','test','0.9'),('2018-11-20 03:59:59','2018-11-20 11:59:59','LTCETH','4h','0.251000000000000','0.248490000000000','1.356653248558159','1.343086716072577','5.404993022144061','5.404993022144061','test','test','1.0'),('2018-11-20 23:59:59','2018-11-21 03:59:59','LTCETH','4h','0.252840000000000','0.250311600000000','1.353638463561363','1.340102078925749','5.353735419875666','5.353735419875666','test','test','1.0'),('2018-11-21 07:59:59','2018-12-07 19:59:59','LTCETH','4h','0.249890000000000','0.263770000000000','1.350630378086782','1.425650385481414','5.404899668201137','5.404899668201137','test','test','0.6'),('2018-12-14 23:59:59','2018-12-19 19:59:59','LTCETH','4h','0.278400000000000','0.289990000000000','1.367301490841145','1.424223273451953','4.911284090665033','4.911284090665033','test','test','0.0'),('2018-12-19 23:59:59','2018-12-20 03:59:59','LTCETH','4h','0.292510000000000','0.290620000000000','1.379950775865769','1.371034475683258','4.717619144185734','4.717619144185734','test','test','0.6'),('2018-12-20 11:59:59','2018-12-20 15:59:59','LTCETH','4h','0.289960000000000','0.287880000000000','1.377969375825211','1.368084645856538','4.752274023400507','4.752274023400507','test','test','0.7'),('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.375772769165506','1.487083733937849','5.914503973025691','5.914503973025691','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LTCETH','4h','0.258350000000000','0.256340000000000','1.400508539114916','1.389612382104577','5.4209736369843835','5.420973636984384','test','test','0.8'),('2019-01-16 19:59:59','2019-01-17 07:59:59','LTCETH','4h','0.257580000000000','0.255004200000000','1.398087170890396','1.384106299181492','5.427778441223682','5.427778441223682','test','test','1.0'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.394980310510640','1.852899662753233','5.469653036820262','5.469653036820262','test','test','0.0'),('2019-02-15 11:59:59','2019-02-17 11:59:59','LTCETH','4h','0.346280000000000','0.342817200000000','1.496740166564549','1.481772764898903','4.322340783656431','4.322340783656431','test','test','1.0'),('2019-02-20 11:59:59','2019-02-21 07:59:59','LTCETH','4h','0.346600000000000','0.343134000000000','1.493414077305516','1.478479936532461','4.308753829502355','4.308753829502355','test','test','1.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.490095379355949','1.486937926527159','4.4471166602678505','4.447116660267850','test','test','0.2'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.489393723171773','1.914555336456213','4.426922254107041','4.426922254107041','test','test','0.0'),('2019-03-20 19:59:59','2019-03-21 11:59:59','LTCETH','4h','0.435300000000000','0.430947000000000','1.583874081679427','1.568035340862633','3.638580477094938','3.638580477094938','test','test','1.0'),('2019-03-21 15:59:59','2019-03-22 07:59:59','LTCETH','4h','0.434120000000000','0.429778800000000','1.580354361497917','1.564550817882938','3.6403629445727375','3.640362944572737','test','test','1.0'),('2019-03-22 11:59:59','2019-03-29 07:59:59','LTCETH','4h','0.432450000000000','0.433750000000000','1.576842462916810','1.581582653000732','3.6463000645550006','3.646300064555001','test','test','0.0'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.577895838491015','1.566556840478165','3.6226830711980327','3.622683071198033','test','test','0.7'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.575376061154826','1.735244718955415','3.515915060492392','3.515915060492392','test','test','0.4'),('2019-04-10 23:59:59','2019-04-11 07:59:59','LTCETH','4h','0.498150000000000','0.493730000000000','1.610902429554957','1.596609167006261','3.2337698073972847','3.233769807397285','test','test','0.9'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.494069400000000','1.607726148988580','1.591648887498694','3.2215087343978284','3.221508734397828','test','test','1.0'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.604153424213050','1.595283982963536','3.284978240560789','3.284978240560789','test','test','0.6'),('2019-04-26 03:59:59','2019-04-26 15:59:59','LTCETH','4h','0.471700000000000','0.466983000000000','1.602182437268714','1.586160612896027','3.3966131805569506','3.396613180556951','test','test','1.0'),('2019-04-26 19:59:59','2019-04-27 07:59:59','LTCETH','4h','0.467870000000000','0.464160000000000','1.598622031852561','1.585945673594556','3.416808155796612','3.416808155796612','test','test','0.8'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCETH','4h','0.459000000000000','0.454640000000000','1.595805063350782','1.580646653598692','3.4766994844243615','3.476699484424361','test','test','0.9'),('2019-05-03 11:59:59','2019-05-05 11:59:59','LTCETH','4h','0.470640000000000','0.465933600000000','1.592436527850318','1.576512162571815','3.3835554305845608','3.383555430584561','test','test','1.0'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.588897780010650','1.587543901631353','3.4714830238379943','3.471483023837994','test','test','0.7'),('2019-05-12 11:59:59','2019-05-12 15:59:59','LTCETH','4h','0.460670000000000','0.456063300000000','1.588596918148584','1.572710948967098','3.44844882051921','3.448448820519210','test','test','1.0'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCETH','4h','0.395420000000000','0.421150000000000','1.585066702774921','1.688207075700921','4.008564824174095','4.008564824174095','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:31:26
