-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-21 07:59:59','2018-05-21 11:59:59','NEOUSDT','4h','65.659999999999997','65.003399999999999','222.222222222222200','219.999999999999972','3.38443835245541','3.384438352455410','test','test','1.0'),('2018-06-02 07:59:59','2018-06-02 15:59:59','NEOUSDT','4h','56.817000000000000','56.248829999999998','221.728395061728406','219.511111111111120','3.902500925105662','3.902500925105662','test','test','1.0'),('2018-06-03 11:59:59','2018-06-03 19:59:59','NEOUSDT','4h','57.430000000000000','56.855699999999999','221.235665294924530','219.023308641975291','3.8522665034811863','3.852266503481186','test','test','1.0'),('2018-07-02 11:59:59','2018-07-09 19:59:59','NEOUSDT','4h','32.973999999999997','37.619999999999997','220.744030483158070','251.846619359992928','6.694487489632986','6.694487489632986','test','test','0.0'),('2018-07-16 11:59:59','2018-07-19 19:59:59','NEOUSDT','4h','35.218000000000004','35.810000000000002','227.655716900232477','231.482515253487549','6.4641864075254825','6.464186407525482','test','test','0.0'),('2018-07-25 07:59:59','2018-07-25 11:59:59','NEOUSDT','4h','34.871000000000002','34.522290000000005','228.506116534289163','226.221055368946281','6.552898297562133','6.552898297562133','test','test','1.0'),('2018-07-26 07:59:59','2018-07-26 11:59:59','NEOUSDT','4h','35.174999999999997','34.823249999999994','227.998325164212957','225.718341912570793','6.481828718243439','6.481828718243439','test','test','1.0'),('2018-08-17 23:59:59','2018-08-18 03:59:59','NEOUSDT','4h','20.670000000000002','20.463300000000000','227.491662219403565','225.216745597209496','11.005885932240133','11.005885932240133','test','test','1.0'),('2018-08-27 19:59:59','2018-08-29 15:59:59','NEOUSDT','4h','19.946999999999999','19.747529999999998','226.986125192249347','224.716263940326826','11.379461833471167','11.379461833471167','test','test','1.0'),('2018-08-31 19:59:59','2018-09-05 11:59:59','NEOUSDT','4h','20.180000000000000','21.524999999999999','226.481711580711021','241.576751326799041','11.22307787813236','11.223077878132360','test','test','0.7'),('2018-09-20 23:59:59','2018-09-21 03:59:59','NEOUSDT','4h','18.186000000000000','18.265000000000001','229.836164857619480','230.834573359970307','12.638082308238177','12.638082308238177','test','test','0.0'),('2018-09-21 07:59:59','2018-09-21 15:59:59','NEOUSDT','4h','19.149999999999999','18.958499999999997','230.058033413697416','227.757453079560406','12.013474329696994','12.013474329696994','test','test','1.0'),('2018-09-21 19:59:59','2018-09-22 03:59:59','NEOUSDT','4h','19.960000000000001','19.760400000000001','229.546793339444775','227.251325406050313','11.500340347667574','11.500340347667574','test','test','1.0'),('2018-09-23 11:59:59','2018-09-23 15:59:59','NEOUSDT','4h','20.109000000000002','19.907910000000001','229.036689354245965','226.746322460703510','11.38976027421781','11.389760274217810','test','test','1.0'),('2018-09-26 15:59:59','2018-09-26 19:59:59','NEOUSDT','4h','18.559999999999999','18.374399999999998','228.527718933458772','226.242441744124193','12.312915890811357','12.312915890811357','test','test','1.0'),('2018-09-27 15:59:59','2018-09-29 03:59:59','NEOUSDT','4h','18.472999999999999','18.638999999999999','228.019879558051088','230.068886216776576','12.343413606780226','12.343413606780226','test','test','0.0'),('2018-10-08 11:59:59','2018-10-09 11:59:59','NEOUSDT','4h','18.408000000000001','18.297000000000001','228.475214371101174','227.097511807259792','12.411734809381853','12.411734809381853','test','test','0.6'),('2018-10-18 11:59:59','2018-10-18 15:59:59','NEOUSDT','4h','17.748999999999999','17.571510000000000','228.169058245803143','225.887367663345145','12.85531907407759','12.855319074077590','test','test','1.0'),('2018-10-22 15:59:59','2018-10-23 03:59:59','NEOUSDT','4h','17.143999999999998','16.972559999999998','227.662015894145753','225.385395735204298','13.279398967227355','13.279398967227355','test','test','1.0'),('2018-11-02 15:59:59','2018-11-02 19:59:59','NEOUSDT','4h','16.138000000000002','16.180000000000000','227.156100303269909','227.747286089162628','14.075852045065677','14.075852045065677','test','test','0.0'),('2018-11-04 07:59:59','2018-11-04 11:59:59','NEOUSDT','4h','16.152000000000001','16.559999999999999','227.287474922357177','233.028763293352796','14.071785223028552','14.071785223028552','test','test','0.0'),('2018-11-04 15:59:59','2018-11-05 19:59:59','NEOUSDT','4h','16.651000000000000','16.484490000000001','228.563316782578426','226.277683614752675','13.726702106935225','13.726702106935225','test','test','1.0'),('2018-11-06 11:59:59','2018-11-07 15:59:59','NEOUSDT','4h','16.911000000000001','16.741890000000001','228.055398300839329','225.774844317830940','13.485624640815995','13.485624640815995','test','test','1.0'),('2018-12-17 19:59:59','2018-12-17 23:59:59','NEOUSDT','4h','6.592000000000000','6.526079999999999','227.548608526837484','225.273122441569114','34.518902992542095','34.518902992542095','test','test','1.0'),('2018-12-18 03:59:59','2018-12-18 11:59:59','NEOUSDT','4h','6.535000000000000','6.469650000000000','227.042944952333414','224.772515502810052','34.742608255904116','34.742608255904116','test','test','1.0'),('2018-12-18 15:59:59','2018-12-27 19:59:59','NEOUSDT','4h','6.447000000000000','6.814000000000000','226.538405074661569','239.434262785596985','35.138576869033905','35.138576869033905','test','test','0.0'),('2018-12-28 15:59:59','2018-12-31 19:59:59','NEOUSDT','4h','7.372000000000000','7.418000000000000','229.404151232647223','230.835593304907377','31.118305918698756','31.118305918698756','test','test','0.0'),('2019-01-01 23:59:59','2019-01-02 07:59:59','NEOUSDT','4h','7.756000000000000','7.678440000000000','229.722249470927210','227.425026976217936','29.61865000914482','29.618650009144819','test','test','1.0'),('2019-01-02 11:59:59','2019-01-03 11:59:59','NEOUSDT','4h','7.789000000000000','7.711110000000000','229.211755583214057','226.919638027381922','29.427623004649387','29.427623004649387','test','test','1.0'),('2019-01-05 15:59:59','2019-01-06 07:59:59','NEOUSDT','4h','7.737000000000000','7.659630000000000','228.702396126362487','226.415372165098859','29.559570392447007','29.559570392447007','test','test','1.0'),('2019-01-06 11:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.763000000000000','8.327999999999999','228.194168579414992','244.802400609219092','29.395100937706427','29.395100937706427','test','test','0.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.821000000000001','231.884886808260376','229.566037940177779','29.352517317501313','29.352517317501313','test','test','1.0'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.164630000000000','231.369587059797567','229.055891189199599','31.970372676495447','31.970372676495447','test','test','1.0'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','230.855432421886889','293.045948885735243','31.141971188707256','31.141971188707256','test','test','0.0'),('2019-02-25 19:59:59','2019-02-25 23:59:59','NEOUSDT','4h','9.308999999999999','9.215909999999999','244.675547191630955','242.228791719714650','26.283762723346328','26.283762723346328','test','test','1.0'),('2019-03-01 23:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.946999999999999','8.857529999999999','244.131823753427369','241.690505515893079','27.286445037825796','27.286445037825796','test','test','1.0'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','243.589308589530873','243.171917724915545','27.826057641024775','27.826057641024775','test','test','0.2'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','243.496555064060772','242.186534678528375','27.872774160263365','27.872774160263365','test','test','0.5'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.692200000000000','243.205439422831347','240.773385028603030','27.69993615294207','27.699936152942069','test','test','1.0'),('2019-03-07 19:59:59','2019-03-08 03:59:59','NEOUSDT','4h','9.144000000000000','9.052560000000000','242.664982890780607','240.238333061872794','26.538165233025','26.538165233025001','test','test','1.0'),('2019-03-09 15:59:59','2019-03-10 07:59:59','NEOUSDT','4h','9.010999999999999','8.920890000000000','242.125727373245553','239.704470099513117','26.870017464570587','26.870017464570587','test','test','1.0'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','241.587670201305031','242.164842109635828','27.484376587179188','27.484376587179188','test','test','0.0'),('2019-03-13 03:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.907000000000000','8.817930000000000','241.715930625378519','239.298771319124768','27.137749031702988','27.137749031702988','test','test','1.0'),('2019-03-13 15:59:59','2019-03-14 03:59:59','NEOUSDT','4h','8.981999999999999','8.892180000000000','241.178784112877679','238.766996271748894','26.85134536994853','26.851345369948529','test','test','1.0'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','240.642831259293530','239.636954283399490','26.47044673405495','26.470446734054949','test','test','0.4'),('2019-03-19 15:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.125000000000000','9.033750000000000','240.419303042428169','238.015110012003873','26.34732088136199','26.347320881361991','test','test','1.0'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.183999999999999','9.092160000000000','239.885037924556087','237.486187545310543','26.119886533597136','26.119886533597136','test','test','1.0'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','239.351960062501547','239.063994235017390','26.178711589467518','26.178711589467518','test','test','0.1'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','239.287967656393931','238.265145348349279','26.22621302678583','26.226213026785832','test','test','0.4'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','9.175320000000001','239.060673810161802','236.670067072060192','25.7942030438241','25.794203043824101','test','test','1.0'),('2019-03-27 11:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.236000000000001','12.166000000000000','238.529427868361410','314.199763907155102','25.826053255561','25.826053255561000','test','test','1.0'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.961380000000000','255.345058099204493','252.791607518212487','25.377167372212732','25.377167372212732','test','test','1.0'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','254.777624636761828','253.047904341703969','25.437063162615996','25.437063162615996','test','test','0.7'),('2019-05-04 03:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.968999999999999','9.869309999999999','254.393242348971199','251.849309925481464','25.51843137215079','25.518431372150790','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:39:05
