-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-22 03:59:59','2018-04-25 03:59:59','ENJBTC','4h','0.000015270000000','0.000015200000000','0.033333333333333','0.033180528268937','2182.9294913774283','2182.929491377428349','test','test','0.5'),('2018-04-26 15:59:59','2018-05-05 15:59:59','ENJBTC','4h','0.000015850000000','0.000016850000000','0.033299376652356','0.035400283696669','2100.90704431271','2100.907044312709786','test','test','0.5'),('2018-05-07 23:59:59','2018-05-08 07:59:59','ENJBTC','4h','0.000016750000000','0.000016930000000','0.033766244884426','0.034129106023483','2015.8952169806566','2015.895216980656642','test','test','0.0'),('2018-05-10 19:59:59','2018-05-10 23:59:59','ENJBTC','4h','0.000017130000000','0.000016970000000','0.033846880693105','0.033530739367308','1975.8832862291497','1975.883286229149689','test','test','0.9'),('2018-05-14 15:59:59','2018-05-14 19:59:59','ENJBTC','4h','0.000016910000000','0.000016740900000','0.033776627065150','0.033438860794498','1997.4350718598726','1997.435071859872551','test','test','1.0'),('2018-05-15 11:59:59','2018-05-15 15:59:59','ENJBTC','4h','0.000016700000000','0.000016630000000','0.033701567893894','0.033560303836854','2018.0579577182305','2018.057957718230455','test','test','0.4'),('2018-05-19 03:59:59','2018-05-19 11:59:59','ENJBTC','4h','0.000016620000000','0.000016453800000','0.033670175881219','0.033333474122407','2025.8830253440967','2025.883025344096723','test','test','1.0'),('2018-05-19 15:59:59','2018-05-19 19:59:59','ENJBTC','4h','0.000017080000000','0.000016909200000','0.033595353268150','0.033259399735468','1966.9410578541895','1966.941057854189467','test','test','1.0'),('2018-05-20 03:59:59','2018-05-20 15:59:59','ENJBTC','4h','0.000016850000000','0.000016681500000','0.033520696927554','0.033185489958278','1989.3588681040687','1989.358868104068733','test','test','1.0'),('2018-05-21 11:59:59','2018-05-21 15:59:59','ENJBTC','4h','0.000017060000000','0.000016889400000','0.033446206489937','0.033111744425038','1960.5044835836266','1960.504483583626552','test','test','1.0'),('2018-05-22 07:59:59','2018-05-22 19:59:59','ENJBTC','4h','0.000016970000000','0.000016800300000','0.033371881586626','0.033038162770760','1966.5221913156026','1966.522191315602640','test','test','1.0'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJBTC','4h','0.000014400000000','0.000014256000000','0.033297721849767','0.032964744631269','2312.3417951226857','2312.341795122685653','test','test','1.0'),('2018-06-07 23:59:59','2018-06-08 07:59:59','ENJBTC','4h','0.000014780000000','0.000014632200000','0.033223726912323','0.032891489643200','2247.8840942031575','2247.884094203157474','test','test','1.0'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJBTC','4h','0.000009520000000','0.000009530000000','0.033149896408073','0.033184717727829','3482.131975637931','3482.131975637931191','test','test','0.0'),('2018-07-04 11:59:59','2018-07-05 19:59:59','ENJBTC','4h','0.000009490000000','0.000009560000000','0.033157634479130','0.033402211340409','3493.9551611306642','3493.955161130664237','test','test','0.0'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJBTC','4h','0.000009800000000','0.000009702000000','0.033211984892748','0.032879865043821','3388.9780502803633','3388.978050280363277','test','test','1.0'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJBTC','4h','0.000009700000000','0.000009880000000','0.033138180481875','0.033753115789786','3416.307266172669','3416.307266172669188','test','test','0.0'),('2018-07-09 11:59:59','2018-07-09 15:59:59','ENJBTC','4h','0.000009630000000','0.000009870000000','0.033274832772522','0.034104112093956','3455.330505973186','3455.330505973186064','test','test','0.0'),('2018-07-09 19:59:59','2018-07-09 23:59:59','ENJBTC','4h','0.000010260000000','0.000010157400000','0.033459117066174','0.033124525895512','3261.1225210695698','3261.122521069569757','test','test','1.0'),('2018-07-10 15:59:59','2018-07-10 19:59:59','ENJBTC','4h','0.000010040000000','0.000009939600000','0.033384763472693','0.033050915837966','3325.175644690571','3325.175644690571062','test','test','1.0'),('2018-07-11 03:59:59','2018-07-11 07:59:59','ENJBTC','4h','0.000010150000000','0.000010048500000','0.033310575109421','0.032977469358327','3281.8300600414454','3281.830060041445449','test','test','1.0'),('2018-07-11 11:59:59','2018-07-11 15:59:59','ENJBTC','4h','0.000010060000000','0.000009959400000','0.033236551609178','0.032904186093086','3303.832167910294','3303.832167910294174','test','test','1.0'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJBTC','4h','0.000007310000000','0.000007236900000','0.033162692605602','0.032831065679546','4536.620055485849','4536.620055485848752','test','test','1.0'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJBTC','4h','0.000007190000000','0.000007210000000','0.033088997733145','0.033181039451457','4602.085915597312','4602.085915597312123','test','test','0.0'),('2018-08-17 23:59:59','2018-08-18 03:59:59','ENJBTC','4h','0.000006520000000','0.000006454800000','0.033109451448325','0.032778356933842','5078.136725203238','5078.136725203237802','test','test','1.0'),('2018-08-28 11:59:59','2018-08-29 15:59:59','ENJBTC','4h','0.000005830000000','0.000005910000000','0.033035874889551','0.033489197358018','5666.530855840671','5666.530855840671393','test','test','0.0'),('2018-08-30 07:59:59','2018-08-30 11:59:59','ENJBTC','4h','0.000006130000000','0.000006068700000','0.033136613215877','0.032805247083718','5405.646527875549','5405.646527875548600','test','test','1.0'),('2018-08-30 15:59:59','2018-08-30 19:59:59','ENJBTC','4h','0.000006150000000','0.000006088500000','0.033062976297620','0.032732346534644','5376.09370693001','5376.093706930009830','test','test','1.0'),('2018-08-30 23:59:59','2018-08-31 07:59:59','ENJBTC','4h','0.000006140000000','0.000006078600000','0.032989503016958','0.032659607986788','5372.883227517626','5372.883227517626437','test','test','1.0'),('2018-09-01 07:59:59','2018-09-02 11:59:59','ENJBTC','4h','0.000006320000000','0.000006256800000','0.032916193010254','0.032587031080151','5208.258387698384','5208.258387698383558','test','test','1.0'),('2018-09-03 11:59:59','2018-09-03 15:59:59','ENJBTC','4h','0.000006490000000','0.000006425100000','0.032843045914675','0.032514615455528','5060.56177421808','5060.561774218080245','test','test','1.0'),('2018-09-04 07:59:59','2018-09-05 11:59:59','ENJBTC','4h','0.000006750000000','0.000006682500000','0.032770061368198','0.032442360754516','4854.823906399737','4854.823906399737098','test','test','1.0'),('2018-09-05 15:59:59','2018-09-05 19:59:59','ENJBTC','4h','0.000006740000000','0.000006672600000','0.032697239009602','0.032370266619506','4851.222404985492','4851.222404985492176','test','test','1.0'),('2018-09-06 11:59:59','2018-09-08 19:59:59','ENJBTC','4h','0.000006710000000','0.000006650000000','0.032624578478470','0.032332853484624','4862.083230770459','4862.083230770458613','test','test','0.9'),('2018-09-15 03:59:59','2018-09-15 23:59:59','ENJBTC','4h','0.000006500000000','0.000006500000000','0.032559750702060','0.032559750702060','5009.19241570147','5009.192415701470054','test','test','0.0'),('2018-09-17 03:59:59','2018-09-17 07:59:59','ENJBTC','4h','0.000006790000000','0.000006722100000','0.032559750702060','0.032234153195039','4795.250471584618','4795.250471584618026','test','test','1.0'),('2018-09-18 15:59:59','2018-09-18 19:59:59','ENJBTC','4h','0.000006420000000','0.000006355800000','0.032487395700499','0.032162521743494','5060.342009423572','5060.342009423571653','test','test','1.0'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJBTC','4h','0.000006490000000','0.000006480000000','0.032415201487832','0.032365255106495','4994.638133718268','4994.638133718268364','test','test','0.9'),('2018-09-21 11:59:59','2018-09-21 15:59:59','ENJBTC','4h','0.000006520000000','0.000006454800000','0.032404102291979','0.032080061269059','4969.954339260566','4969.954339260565575','test','test','1.0'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ENJBTC','4h','0.000006520000000','0.000006454800000','0.032332093175774','0.032008772244016','4958.909996284424','4958.909996284423869','test','test','1.0'),('2018-09-22 03:59:59','2018-09-22 07:59:59','ENJBTC','4h','0.000006460000000','0.000006395400000','0.032260244079828','0.031937641639030','4993.845832790747','4993.845832790747409','test','test','1.0'),('2018-09-22 19:59:59','2018-09-22 23:59:59','ENJBTC','4h','0.000006630000000','0.000006563700000','0.032188554648540','0.031866669102055','4854.985618180962','4854.985618180961865','test','test','1.0'),('2018-09-27 07:59:59','2018-09-27 11:59:59','ENJBTC','4h','0.000006460000000','0.000006530000000','0.032117024527099','0.032465041820736','4971.675623389887','4971.675623389886823','test','test','0.0'),('2018-09-27 15:59:59','2018-10-07 07:59:59','ENJBTC','4h','0.000006520000000','0.000008180000000','0.032194361703462','0.040391085695448','4937.785537340866','4937.785537340865631','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','ENJBTC','4h','0.000008310000000','0.000008226900000','0.034015855923904','0.033675697364665','4093.3641304336675','4093.364130433667469','test','test','1.0'),('2018-10-14 15:59:59','2018-10-14 19:59:59','ENJBTC','4h','0.000008030000000','0.000007970000000','0.033940265132962','0.033686664148158','4226.68308006996','4226.683080069959942','test','test','0.7'),('2018-10-20 15:59:59','2018-10-21 03:59:59','ENJBTC','4h','0.000008040000000','0.000007959600000','0.033883909358561','0.033545070264975','4214.416586885683','4214.416586885682591','test','test','1.0'),('2018-10-21 11:59:59','2018-10-21 15:59:59','ENJBTC','4h','0.000008050000000','0.000007969500000','0.033808611782208','0.033470525664386','4199.827550584901','4199.827550584900564','test','test','1.0'),('2018-10-24 15:59:59','2018-10-24 19:59:59','ENJBTC','4h','0.000007860000000','0.000008020000000','0.033733481533804','0.034420168180803','4291.79154374091','4291.791543740910129','test','test','0.0'),('2018-10-24 23:59:59','2018-10-25 03:59:59','ENJBTC','4h','0.000008200000000','0.000008118000000','0.033886078566470','0.033547217780805','4132.448605667074','4132.448605667073934','test','test','1.0'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJBTC','4h','0.000007730000000','0.000007810000000','0.033810776169656','0.034160693646185','4373.968456617795','4373.968456617794800','test','test','0.0'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJBTC','4h','0.000007920000000','0.000007840800000','0.033888535608884','0.033549650252795','4278.85550617225','4278.855506172249989','test','test','1.0'),('2018-11-08 19:59:59','2018-11-09 11:59:59','ENJBTC','4h','0.000007710000000','0.000007800000000','0.033813227751976','0.034207934690715','4385.632652655714','4385.632652655714082','test','test','0.0'),('2018-11-09 15:59:59','2018-11-09 23:59:59','ENJBTC','4h','0.000007930000000','0.000007850700000','0.033900940405029','0.033561931000979','4275.0240107224045','4275.024010722404455','test','test','1.0'),('2018-11-10 03:59:59','2018-11-11 03:59:59','ENJBTC','4h','0.000007990000000','0.000007910100000','0.033825604981906','0.033487348932087','4233.492488348741','4233.492488348741063','test','test','1.0'),('2018-11-12 07:59:59','2018-11-12 19:59:59','ENJBTC','4h','0.000008040000000','0.000007959600000','0.033750436970836','0.033412932601128','4197.815543636263','4197.815543636263101','test','test','1.0'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJBTC','4h','0.000007870000000','0.000007800000000','0.033675435999789','0.033375908614785','4278.962642921136','4278.962642921135739','test','test','0.9'),('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJBTC','4h','0.000006960000000','0.000006890400000','0.033608874358677','0.033272785615090','4828.861258430651','4828.861258430651105','test','test','1.0'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJBTC','4h','0.000006480000000','0.000006415200000','0.033534187971214','0.033198846091502','5175.029007903327','5175.029007903326601','test','test','1.0'),('2018-12-01 23:59:59','2018-12-02 07:59:59','ENJBTC','4h','0.000007160000000','0.000007088400000','0.033459667553500','0.033125070877965','4673.137926466449','4673.137926466449244','test','test','1.0'),('2018-12-04 07:59:59','2018-12-04 11:59:59','ENJBTC','4h','0.000007220000000','0.000007147800000','0.033385312736714','0.033051459609347','4624.004534170945','4624.004534170944680','test','test','1.0'),('2018-12-05 03:59:59','2018-12-05 07:59:59','ENJBTC','4h','0.000007490000000','0.000007415100000','0.033311123152855','0.032978011921326','4447.412971008663','4447.412971008662680','test','test','1.0'),('2018-12-07 03:59:59','2018-12-30 23:59:59','ENJBTC','4h','0.000006810000000','0.000010470000000','0.033237098434737','0.051100208606710','4880.631194528243','4880.631194528243213','test','test','0.0'),('2018-12-31 03:59:59','2018-12-31 07:59:59','ENJBTC','4h','0.000010710000000','0.000010650000000','0.037206678472954','0.036998237697195','3474.0129293140576','3474.012929314057601','test','test','0.6'),('2019-01-02 03:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010600000000','0.000010494000000','0.037160358300563','0.036788754717557','3505.694179298365','3505.694179298364816','test','test','1.0'),('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJBTC','4h','0.000010340000000','0.000010236600000','0.037077779726561','0.036707001929295','3585.858774328949','3585.858774328949039','test','test','1.0'),('2019-01-22 15:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009650000000','0.000009553500000','0.036995384660502','0.036625430813897','3833.7186176686237','3833.718617668623665','test','test','1.0'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009256500000','0.036913172694590','0.036544040967644','3947.932908512299','3947.932908512299036','test','test','1.0'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008157600000','0.036831143421935','0.036462831987716','4469.798958972734','4469.798958972733999','test','test','1.0'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.036749296436553','0.037278063291755','4406.390460018386','4406.390460018385966','test','test','0.0'),('2019-02-17 11:59:59','2019-03-16 07:59:59','ENJBTC','4h','0.000008580000000','0.000041040000000','0.036866800182154','0.176341897374779','4296.829858059881','4296.829858059881190','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','ENJBTC','4h','0.000050800000000','0.000050292000000','0.067861266224959','0.067182653562709','1335.851697341719','1335.851697341719046','test','test','1.0'),('2019-03-19 19:59:59','2019-03-19 23:59:59','ENJBTC','4h','0.000048000000000','0.000047520000000','0.067710463411126','0.067033358777015','1410.6346543984585','1410.634654398458451','test','test','1.0'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ENJBTC','4h','0.000047960000000','0.000047480400000','0.067559995714657','0.066884395757510','1408.6738055599853','1408.673805559985340','test','test','1.0'),('2019-03-22 07:59:59','2019-03-22 11:59:59','ENJBTC','4h','0.000047730000000','0.000047252700000','0.067409862390846','0.066735763766938','1412.3164129655654','1412.316412965565405','test','test','1.0'),('2019-04-13 19:59:59','2019-04-14 15:59:59','ENJBTC','4h','0.000033070000000','0.000032739300000','0.067260062696645','0.066587462069679','2033.8694495507914','2033.869449550791387','test','test','1.0'),('2019-04-17 11:59:59','2019-04-20 11:59:59','ENJBTC','4h','0.000031460000000','0.000037730000000','0.067110595890652','0.080485784582146','2133.2039380372607','2133.203938037260741','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 23:52:10
