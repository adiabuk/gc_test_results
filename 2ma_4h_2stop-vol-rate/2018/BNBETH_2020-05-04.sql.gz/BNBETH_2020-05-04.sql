-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 15:59:59','2018-02-10 07:59:59','BNBETH','4h','0.011279000000000','0.011166210000000','1.297777777777778','1.284800000000000','115.06142191486636','115.061421914866358','test','test','1.0'),('2018-02-14 15:59:59','2018-02-20 07:59:59','BNBETH','4h','0.010883000000000','0.011438000000000','1.294893827160494','1.360929485901105','118.98316890200255','118.983168902002546','test','test','0.0'),('2018-02-23 23:59:59','2018-02-24 03:59:59','BNBETH','4h','0.011455000000000','0.011340450000000','1.309568417991741','1.296472733811824','114.32286494908256','114.322864949082557','test','test','1.0'),('2018-02-26 15:59:59','2018-02-26 19:59:59','BNBETH','4h','0.011426000000000','0.011364000000000','1.306658265951759','1.299568049560283','114.35832889478024','114.358328894780243','test','test','0.5'),('2018-02-27 03:59:59','2018-03-06 07:59:59','BNBETH','4h','0.011464000000000','0.011729000000000','1.305082662309209','1.335250745483663','113.84182329982632','113.841823299826316','test','test','0.0'),('2018-03-07 07:59:59','2018-03-07 19:59:59','BNBETH','4h','0.011924000000000','0.011885000000000','1.311786680792421','1.307496201041423','110.01230130765018','110.012301307650176','test','test','0.3'),('2018-03-07 23:59:59','2018-03-08 03:59:59','BNBETH','4h','0.012088000000000','0.011967120000000','1.310833240847755','1.297724908439277','108.44087035471166','108.440870354711663','test','test','1.0'),('2018-03-08 23:59:59','2018-03-09 03:59:59','BNBETH','4h','0.011859000000000','0.011740410000000','1.307920278090315','1.294841075309412','110.2892552567936','110.289255256793595','test','test','1.0'),('2018-03-13 07:59:59','2018-03-13 11:59:59','BNBETH','4h','0.011558000000000','0.011523000000000','1.305013788583448','1.301061938557456','112.91000074264124','112.910000742641245','test','test','0.3'),('2018-03-13 15:59:59','2018-04-07 19:59:59','BNBETH','4h','0.014000000000000','0.031920000000000','1.304135599688783','2.973429167290425','93.15254283491306','93.152542834913064','test','test','0.0'),('2018-04-10 03:59:59','2018-04-10 07:59:59','BNBETH','4h','0.030897000000000','0.030588030000000','1.675089725822481','1.658338828564256','54.2152871095084','54.215287109508402','test','test','1.0'),('2018-05-09 23:59:59','2018-05-10 03:59:59','BNBETH','4h','0.019473000000000','0.019278270000000','1.671367304209542','1.654653631167447','85.82998532375812','85.829985323758123','test','test','1.0'),('2018-05-17 23:59:59','2018-05-18 03:59:59','BNBETH','4h','0.018527000000000','0.018341730000000','1.667653154644632','1.650976623098185','90.01204483427604','90.012044834276040','test','test','1.0'),('2018-05-18 11:59:59','2018-05-18 15:59:59','BNBETH','4h','0.021839000000000','0.021620610000000','1.663947258745422','1.647307786157968','76.19154992194797','76.191549921947967','test','test','1.0'),('2018-05-18 19:59:59','2018-05-19 11:59:59','BNBETH','4h','0.021751000000000','0.021533490000000','1.660249598170432','1.643647102188728','76.3298054420685','76.329805442068505','test','test','1.0'),('2018-05-22 11:59:59','2018-06-19 15:59:59','BNBETH','4h','0.021001000000000','0.030597000000000','1.656560154618942','2.413493217031368','78.88006069324994','78.880060693249945','test','test','0.9'),('2018-06-21 15:59:59','2018-06-24 07:59:59','BNBETH','4h','0.031393000000000','0.032042000000000','1.824767501821704','1.862491647608417','58.126572860883115','58.126572860883115','test','test','0.0'),('2018-06-24 15:59:59','2018-06-25 03:59:59','BNBETH','4h','0.031994000000000','0.031674060000000','1.833150645329862','1.814819138876564','57.296700797957804','57.296700797957804','test','test','1.0'),('2018-06-25 07:59:59','2018-06-25 15:59:59','BNBETH','4h','0.032496000000000','0.032171040000000','1.829076977229129','1.810786207456838','56.28621914171374','56.286219141713737','test','test','1.0'),('2018-06-26 23:59:59','2018-06-27 11:59:59','BNBETH','4h','0.032743000000000','0.032415570000000','1.825012361724175','1.806762238106933','55.73748165177825','55.737481651778253','test','test','1.0'),('2018-06-28 11:59:59','2018-06-30 03:59:59','BNBETH','4h','0.033437000000000','0.033102630000000','1.820956778698122','1.802747210911141','54.45933482962352','54.459334829623522','test','test','1.0'),('2018-07-25 11:59:59','2018-07-25 19:59:59','BNBETH','4h','0.027613000000000','0.027336870000000','1.816910208078793','1.798741105998005','65.79908767894806','65.799087678948055','test','test','1.0'),('2018-07-26 15:59:59','2018-07-26 19:59:59','BNBETH','4h','0.028440000000000','0.028155600000000','1.812872629838618','1.794743903540232','63.74376335578824','63.743763355788239','test','test','1.0'),('2018-07-27 07:59:59','2018-07-30 23:59:59','BNBETH','4h','0.029350000000000','0.029056500000000','1.808844023994531','1.790755583754586','61.630120067956774','61.630120067956774','test','test','1.0'),('2018-07-31 15:59:59','2018-07-31 19:59:59','BNBETH','4h','0.031963000000000','0.031643370000000','1.804824370607877','1.786776126901798','56.466050452331686','56.466050452331686','test','test','1.0'),('2018-07-31 23:59:59','2018-08-14 03:59:59','BNBETH','4h','0.032038000000000','0.034927000000000','1.800813649784304','1.963200522692315','56.20867874974419','56.208678749744188','test','test','0.8'),('2018-08-14 19:59:59','2018-08-14 23:59:59','BNBETH','4h','0.035204000000000','0.034851960000000','1.836899621541640','1.818530625326224','52.17871893937167','52.178718939371670','test','test','1.0'),('2018-08-15 03:59:59','2018-08-15 07:59:59','BNBETH','4h','0.035546000000000','0.035527000000000','1.832817622382659','1.831837947177987','51.56185287747309','51.561852877473093','test','test','0.1'),('2018-08-20 23:59:59','2018-08-21 03:59:59','BNBETH','4h','0.035610000000000','0.035253900000000','1.832599916781620','1.814273917613804','51.46306983380006','51.463069833800063','test','test','1.0'),('2018-08-22 03:59:59','2018-09-13 19:59:59','BNBETH','4h','0.034990000000000','0.046713000000000','1.828527472522106','2.441154724890687','52.25857309294387','52.258573092943870','test','test','0.5'),('2018-09-14 23:59:59','2018-09-15 11:59:59','BNBETH','4h','0.047351000000000','0.046877490000000','1.964666861937346','1.945020193317972','41.49156009244464','41.491560092444637','test','test','1.0'),('2018-09-17 19:59:59','2018-09-18 15:59:59','BNBETH','4h','0.047336000000000','0.046862640000000','1.960300935577485','1.940697926221710','41.41247540091019','41.412475400910189','test','test','1.0'),('2018-09-25 07:59:59','2018-09-25 19:59:59','BNBETH','4h','0.045787000000000','0.045329130000000','1.955944711276202','1.936385264163440','42.71834169690528','42.718341696905277','test','test','1.0'),('2018-09-26 03:59:59','2018-09-26 15:59:59','BNBETH','4h','0.045700000000000','0.045243000000000','1.951598167473366','1.932082185798632','42.70455508694455','42.704555086944552','test','test','1.0'),('2018-09-28 19:59:59','2018-09-29 11:59:59','BNBETH','4h','0.045185000000000','0.044733150000000','1.947261282656758','1.927788669830190','43.09530336741746','43.095303367417458','test','test','1.0'),('2018-10-02 23:59:59','2018-10-09 03:59:59','BNBETH','4h','0.045773000000000','0.046164000000000','1.942934035361965','1.959530876465378','42.44716394734811','42.447163947348109','test','test','0.0'),('2018-10-09 11:59:59','2018-10-09 15:59:59','BNBETH','4h','0.046130000000000','0.045668700000000','1.946622222273835','1.927156000051097','42.19861743494114','42.198617434941141','test','test','1.0'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBETH','4h','0.045916000000000','0.045873000000000','1.942296395113226','1.940477448667763','42.30108012704125','42.301080127041253','test','test','0.1'),('2018-10-11 03:59:59','2018-10-11 19:59:59','BNBETH','4h','0.047947000000000','0.047467530000000','1.941892184792012','1.922473262944092','40.50080682403513','40.500806824035131','test','test','1.0'),('2018-10-11 23:59:59','2018-10-12 07:59:59','BNBETH','4h','0.048854000000000','0.048365460000000','1.937576868825808','1.918201100137550','39.660557351001096','39.660557351001096','test','test','1.0'),('2018-10-14 19:59:59','2018-10-15 07:59:59','BNBETH','4h','0.048057000000000','0.047632000000000','1.933271142450639','1.916173940470875','40.228710540621336','40.228710540621336','test','test','0.9'),('2018-10-15 15:59:59','2018-10-16 07:59:59','BNBETH','4h','0.049001000000000','0.048510990000000','1.929471764232914','1.910177046590585','39.37617118493324','39.376171184933241','test','test','1.0'),('2018-10-17 07:59:59','2018-10-20 11:59:59','BNBETH','4h','0.047571000000000','0.047631000000000','1.925184049201285','1.927612231138854','40.46969895947711','40.469698959477107','test','test','0.0'),('2018-10-20 15:59:59','2018-10-20 19:59:59','BNBETH','4h','0.047724000000000','0.047598000000000','1.925723645187412','1.920639386129210','40.351262366679485','40.351262366679485','test','test','0.3'),('2018-10-21 19:59:59','2018-10-21 23:59:59','BNBETH','4h','0.047684000000000','0.047843000000000','1.924593809841145','1.931011275149524','40.3614170338299','40.361417033829902','test','test','0.0'),('2018-10-22 15:59:59','2018-10-24 11:59:59','BNBETH','4h','0.047876000000000','0.047965000000000','1.926019913243007','1.929600324561384','40.22934065592377','40.229340655923771','test','test','0.1'),('2018-10-24 19:59:59','2018-10-24 23:59:59','BNBETH','4h','0.048033000000000','0.048150000000000','1.926815560202646','1.931508946427610','40.11441217918193','40.114412179181933','test','test','0.0'),('2018-10-25 07:59:59','2018-10-25 15:59:59','BNBETH','4h','0.048252000000000','0.047888000000000','1.927858534919305','1.913315293049317','39.95396118128377','39.953961181283773','test','test','0.8'),('2018-10-29 19:59:59','2018-10-30 11:59:59','BNBETH','4h','0.047938000000000','0.047815000000000','1.924626703392641','1.919688468912327','40.14824780743128','40.148247807431282','test','test','0.3'),('2018-11-01 15:59:59','2018-11-02 11:59:59','BNBETH','4h','0.047897000000000','0.047836000000000','1.923529317952571','1.921079576039818','40.159703487746015','40.159703487746015','test','test','0.1'),('2018-11-14 15:59:59','2018-11-14 19:59:59','BNBETH','4h','0.046758000000000','0.046472000000000','1.922984930860848','1.911222800525372','41.12632984432286','41.126329844322861','test','test','0.6'),('2018-11-19 07:59:59','2018-11-19 15:59:59','BNBETH','4h','0.045891000000000','0.045432090000000','1.920371124119631','1.901167412878435','41.84635602012663','41.846356020126628','test','test','1.0'),('2018-11-26 23:59:59','2018-11-27 19:59:59','BNBETH','4h','0.045665000000000','0.045208350000000','1.916103632732699','1.896942596405372','41.96000509652248','41.960005096522480','test','test','1.0'),('2018-11-29 11:59:59','2018-11-29 15:59:59','BNBETH','4h','0.045600000000000','0.045144000000000','1.911845624659960','1.892727168413360','41.926439137279814','41.926439137279814','test','test','1.0'),('2018-11-29 23:59:59','2018-11-30 03:59:59','BNBETH','4h','0.045568000000000','0.045112320000000','1.907597078827382','1.888521108039108','41.86264656836775','41.862646568367751','test','test','1.0'),('2018-12-03 11:59:59','2018-12-07 19:59:59','BNBETH','4h','0.045260000000000','0.048342000000000','1.903357974207765','2.032967989154922','42.05386597896078','42.053865978960779','test','test','0.0'),('2018-12-10 23:59:59','2018-12-17 19:59:59','BNBETH','4h','0.051521000000000','0.053070000000000','1.932160199751578','1.990251388769943','37.502381548331314','37.502381548331314','test','test','0.0'),('2018-12-17 23:59:59','2018-12-18 03:59:59','BNBETH','4h','0.053834000000000','0.053295660000000','1.945069352866770','1.925618659338102','36.13087180716221','36.130871807162208','test','test','1.0'),('2018-12-18 07:59:59','2018-12-19 07:59:59','BNBETH','4h','0.053584000000000','0.053048160000000','1.940746976527066','1.921339506761795','36.21877755537224','36.218777555372242','test','test','1.0'),('2018-12-19 11:59:59','2018-12-20 03:59:59','BNBETH','4h','0.053425000000000','0.054186000000000','1.936434205468117','1.964017292606371','36.24584380848137','36.245843808481368','test','test','0.0'),('2018-12-31 23:59:59','2019-01-01 03:59:59','BNBETH','4h','0.046469000000000','0.046004310000000','1.942563780387729','1.923138142583851','41.803434125712386','41.803434125712386','test','test','1.0'),('2019-01-08 11:59:59','2019-01-24 19:59:59','BNBETH','4h','0.043388000000000','0.055440000000000','1.938246971986867','2.476638981445374','44.67242030024124','44.672420300241242','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 23:36:38
