-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-03-19 19:59:59','SALTETH','4h','0.004479000000000','0.004431000000000','0.072144500000000','0.071371350636303','16.107278410359456','16.107278410359456','test'),('2018-03-20 11:59:59','2018-03-26 11:59:59','SALTETH','4h','0.004504000000000','0.005501000000000','0.072144500000000','0.088114319382771','16.0178730017762','16.017873001776199','test'),('2018-04-02 15:59:59','2018-04-02 19:59:59','SALTETH','4h','0.005374000000000','0.005300000000000','0.075943667504768','0.074897922920594','14.131683569923426','14.131683569923426','test'),('2018-04-03 07:59:59','2018-04-03 19:59:59','SALTETH','4h','0.005439000000000','0.005387000000000','0.075943667504768','0.075217601920975','13.962799688319175','13.962799688319175','test'),('2018-04-10 07:59:59','2018-04-10 23:59:59','SALTETH','4h','0.005301000000000','0.005247000000000','0.075943667504768','0.075170047801833','14.326290795089228','14.326290795089228','test'),('2018-04-13 03:59:59','2018-04-13 07:59:59','SALTETH','4h','0.005346000000000','0.005325000000000','0.075943667504768','0.075645347823212','14.205699121729891','14.205699121729891','test'),('2018-04-16 15:59:59','2018-04-16 19:59:59','SALTETH','4h','0.005392000000000','0.005414000000000','0.075943667504768','0.076253526682273','14.08450806839169','14.084508068391690','test'),('2018-04-17 07:59:59','2018-04-17 11:59:59','SALTETH','4h','0.005393000000000','0.005388000000000','0.075943667504768','0.075873258022564','14.081896440713516','14.081896440713516','test'),('2018-04-22 07:59:59','2018-04-22 11:59:59','SALTETH','4h','0.005666000000000','0.005585000000000','0.075943667504768','0.074857992060383','13.4034005479647','13.403400547964701','test'),('2018-04-22 23:59:59','2018-04-23 03:59:59','SALTETH','4h','0.005813000000000','0.005587000000000','0.075943667504768','0.072991101040623','13.064453381174609','13.064453381174609','test'),('2018-04-24 11:59:59','2018-04-24 15:59:59','SALTETH','4h','0.005661000000000','0.005667000000000','0.075943667504768','0.076024158938265','13.415238916228228','13.415238916228228','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','SALTETH','4h','0.005686000000000','0.005500000000000','0.075943667504768','0.073459404023254','13.356255276955329','13.356255276955329','test'),('2018-04-27 19:59:59','2018-04-28 03:59:59','SALTETH','4h','0.005738000000000','0.005734000000000','0.075943667504768','0.075890726642095','13.235215668310909','13.235215668310909','test'),('2018-05-15 03:59:59','2018-05-15 07:59:59','SALTETH','4h','0.004825000000000','0.004885000000000','0.075943667504768','0.076888044717263','15.739620208242071','15.739620208242071','test'),('2018-06-21 19:59:59','2018-06-21 23:59:59','SALTETH','4h','0.002683000000000','0.002629000000000','0.075943667504768','0.074415170283278','28.3055041016653','28.305504101665299','test'),('2018-06-28 03:59:59','2018-06-28 07:59:59','SALTETH','4h','0.002411000000000','0.002400000000000','0.075943667504768','0.075597180427807','31.498825178253007','31.498825178253007','test'),('2018-06-28 11:59:59','2018-06-28 15:59:59','SALTETH','4h','0.002410000000000','0.002403000000000','0.075943667504768','0.075723084238157','31.51189523019419','31.511895230194192','test'),('2018-06-30 03:59:59','2018-07-05 15:59:59','SALTETH','4h','0.002441000000000','0.002572000000000','0.075943667504768','0.080019300623623','31.111703197365014','31.111703197365014','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','SALTETH','4h','0.002560000000000','0.002608000000000','0.075943667504768','0.077367611270482','29.665495119049996','29.665495119049996','test'),('2018-07-15 15:59:59','2018-07-15 19:59:59','SALTETH','4h','0.002410000000000','0.002293000000000','0.075943667504768','0.072256775762835','31.51189523019419','31.511895230194192','test'),('2018-07-17 15:59:59','2018-07-17 19:59:59','SALTETH','4h','0.002395000000000','0.002458000000000','0.075943667504768','0.077941350616584','31.709255743118163','31.709255743118163','test'),('2018-07-21 23:59:59','2018-07-22 07:59:59','SALTETH','4h','0.002670000000000','0.002655000000000','0.075943667504768','0.075517017687325','28.443321162834454','28.443321162834454','test'),('2018-08-11 19:59:59','2018-08-11 23:59:59','SALTETH','4h','0.001910000000000','0.001848000000000','0.075943667504768','0.073478480392048','39.761082463229314','39.761082463229314','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','SALTETH','4h','0.001649000000000','0.001660000000000','0.075943667504768','0.076450265650646','46.05437689797938','46.054376897979381','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','SALTETH','4h','0.001635000000000','0.001633000000000','0.075943667504768','0.075850770052163','46.448726302610396','46.448726302610396','test'),('2018-09-03 23:59:59','2018-09-05 15:59:59','SALTETH','4h','0.001950000000000','0.001940000000000','0.075943667504768','0.075554212799615','38.94547051526564','38.945470515265640','test'),('2018-09-06 11:59:59','2018-09-09 11:59:59','SALTETH','4h','0.001953000000000','0.002105000000000','0.075943667504768','0.081854285764228','38.88564644381362','38.885646443813620','test'),('2018-09-16 19:59:59','2018-09-16 23:59:59','SALTETH','4h','0.002090000000000','0.002075000000000','0.075943667504768','0.075398617259518','36.336683016635405','36.336683016635405','test'),('2018-09-22 19:59:59','2018-09-24 11:59:59','SALTETH','4h','0.002138000000000','0.001987000000000','0.075943667504768','0.070580012783898','35.52089219119176','35.520892191191763','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','SALTETH','4h','0.002051000000000','0.002097000000000','0.075943667504768','0.077646938448317','37.027629207590444','37.027629207590444','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','SALTETH','4h','0.002113000000000','0.002080000000000','0.075943667504768','0.074757609280605','35.94115830798297','35.941158307982967','test'),('2018-10-01 03:59:59','2018-10-15 07:59:59','SALTETH','4h','0.002137000000000','0.002672000000000','0.075943667504768','0.094956237516490','35.537514040602716','35.537514040602716','test'),('2018-10-28 03:59:59','2018-10-28 15:59:59','SALTETH','4h','0.003526000000000','0.003509000000000','0.078499674581747','0.078121201958976','22.26309545710345','22.263095457103450','test'),('2018-10-30 19:59:59','2018-10-31 11:59:59','SALTETH','4h','0.003413000000000','0.003411000000000','0.078499674581747','0.078453674186446','23.000197650673016','23.000197650673016','test'),('2018-11-28 23:59:59','2018-11-29 23:59:59','SALTETH','4h','0.002256000000000','0.002192000000000','0.078499674581747','0.076272733458861','34.79595504510062','34.795955045100619','test'),('2018-12-01 11:59:59','2018-12-01 19:59:59','SALTETH','4h','0.002185000000000','0.002145000000000','0.078499674581747','0.077062609600845','35.926624522538674','35.926624522538674','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','SALTETH','4h','0.002181000000000','0.002119000000000','0.078499674581747','0.076268138669749','35.99251470965016','35.992514709650159','test'),('2018-12-02 15:59:59','2018-12-02 19:59:59','SALTETH','4h','0.002141000000000','0.002146000000000','0.078499674581747','0.078682999370588','36.664957768214386','36.664957768214386','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','SALTETH','4h','0.002170000000000','0.002170000000000','0.078499674581747','0.078499674581747','36.1749652450447','36.174965245044703','test'),('2018-12-08 07:59:59','2018-12-09 03:59:59','SALTETH','4h','0.002345000000000','0.002273000000000','0.078499674581747','0.076089450031689','33.47534097302644','33.475340973026441','test'),('2018-12-09 19:59:59','2018-12-13 03:59:59','SALTETH','4h','0.002274000000000','0.002296000000000','0.078499674581747','0.079259126138826','34.52052532178848','34.520525321788483','test'),('2018-12-15 03:59:59','2018-12-15 11:59:59','SALTETH','4h','0.002365000000000','0.002315000000000','0.078499674581747','0.076840062011308','33.19225140877252','33.192251408772520','test'),('2018-12-22 03:59:59','2018-12-22 11:59:59','SALTETH','4h','0.002306000000000','0.002183000000000','0.078499674581747','0.074312571384195','34.041489410991765','34.041489410991765','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','SALTETH','4h','0.001677000000000','0.001656000000000','0.078499674581747','0.077516673290026','46.8095853200638','46.809585320063803','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','SALTETH','4h','0.001670000000000','0.001670000000000','0.078499674581747','0.078499674581747','47.00579316272275','47.005793162722753','test'),('2019-01-11 11:59:59','2019-01-12 07:59:59','SALTETH','4h','0.001725000000000','0.001688000000000','0.078499674581747','0.076815913445791','45.507057728548986','45.507057728548986','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','SALTETH','4h','0.001708000000000','0.001714000000000','0.078499674581747','0.078775434562713','45.95999682772072','45.959996827720722','test'),('2019-01-31 19:59:59','2019-02-01 03:59:59','SALTETH','4h','0.001961000000000','0.001955000000000','0.078499674581747','0.078259491997611','40.030430689315146','40.030430689315146','test'),('2019-02-01 19:59:59','2019-02-01 23:59:59','SALTETH','4h','0.001954000000000','0.001935000000000','0.078499674581747','0.077736371707104','40.17383550754708','40.173835507547082','test'),('2019-02-02 03:59:59','2019-02-02 07:59:59','SALTETH','4h','0.001957000000000','0.001968000000000','0.078499674581747','0.078940909339233','40.112250680504346','40.112250680504346','test'),('2019-02-03 07:59:59','2019-02-03 15:59:59','SALTETH','4h','0.001963000000000','0.001942000000000','0.078499674581747','0.077659892021270','39.98964573700815','39.989645737008154','test'),('2019-02-03 19:59:59','2019-02-03 23:59:59','SALTETH','4h','0.001969000000000','0.001946000000000','0.078499674581747','0.077582715457633','39.867788004950235','39.867788004950235','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','SALTETH','4h','0.001962000000000','0.001928000000000','0.078499674581747','0.077139333635886','40.01002781944291','40.010027819442911','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','SALTETH','4h','0.001975000000000','0.001922000000000','0.078499674581747','0.076393101036009','39.74667067430228','39.746670674302280','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  7:13:03
