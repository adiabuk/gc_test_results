-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-06 11:59:59','2018-11-06 15:59:59','REPBTC','4h','0.002264000000000','0.002261000000000','0.001467500000000','0.001465555432862','0.6481890459363958','0.648189045936396','test'),('2018-11-22 03:59:59','2018-11-25 03:59:59','REPBTC','4h','0.002013000000000','0.002139000000000','0.001467500000000','0.001559355439642','0.7290114257327373','0.729011425732737','test'),('2018-11-26 07:59:59','2018-11-26 15:59:59','REPBTC','4h','0.002127000000000','0.002038000000000','0.001489977718126','0.001427632623197','0.7005066845914434','0.700506684591443','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','REPBTC','4h','0.002073000000000','0.002054000000000','0.001489977718126','0.001476321385929','0.7187543261582248','0.718754326158225','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','REPBTC','4h','0.002068000000000','0.002057000000000','0.001489977718126','0.001482052304732','0.7204921267533849','0.720492126753385','test'),('2018-12-04 23:59:59','2018-12-05 07:59:59','REPBTC','4h','0.002060000000000','0.002048000000000','0.001489977718126','0.001481298236273','0.723290154430097','0.723290154430097','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','REPBTC','4h','0.002085000000000','0.001991000000000','0.001489977718126','0.001422803662728','0.7146176106119904','0.714617610611990','test'),('2018-12-12 07:59:59','2018-12-12 11:59:59','REPBTC','4h','0.001935000000000','0.001916000000000','0.001489977718126','0.001475347445958','0.7700143246129199','0.770014324612920','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','REPBTC','4h','0.001944000000000','0.001887000000000','0.001489977718126','0.001446290099848','0.7664494434804527','0.766449443480453','test'),('2018-12-19 07:59:59','2018-12-19 15:59:59','REPBTC','4h','0.001939000000000','0.001851000000000','0.001489977718126','0.001422356243554','0.7684258474089737','0.768425847408974','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','REPBTC','4h','0.001847000000000','0.001849000000000','0.001489977718126','0.001491591121178','0.8067015257855983','0.806701525785598','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','REPBTC','4h','0.001999000000000','0.001992000000000','0.001489977718126','0.001484760187347','0.7453615398329165','0.745361539832917','test'),('2019-01-14 15:59:59','2019-01-24 03:59:59','REPBTC','4h','0.002432000000000','0.003918000000000','0.001489977718126','0.002400383511356','0.6126553117294408','0.612655311729441','test'),('2019-02-01 15:59:59','2019-02-05 07:59:59','REPBTC','4h','0.003678000000000','0.003846000000000','0.001645248198804','0.001720398198097','0.4473214243622892','0.447321424362289','test'),('2019-02-07 15:59:59','2019-02-07 23:59:59','REPBTC','4h','0.003860000000000','0.003854000000000','0.001664035698628','0.001661449114640','0.43109733125071237','0.431097331250712','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','REPBTC','4h','0.003766000000000','0.003712000000000','0.001664035698628','0.001640175388557','0.44185759390015933','0.441857593900159','test'),('2019-03-08 07:59:59','2019-03-08 11:59:59','REPBTC','4h','0.003347000000000','0.003335000000000','0.001664035698628','0.001658069630990','0.4971723031455034','0.497172303145503','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','REPBTC','4h','0.003341000000000','0.003343000000000','0.001664035698628','0.001665031828947','0.49806515972104165','0.498065159721042','test'),('2019-03-10 03:59:59','2019-03-10 11:59:59','REPBTC','4h','0.003454000000000','0.003383000000000','0.001664035698628','0.001629829985078','0.4817706133839027','0.481770613383903','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','REPBTC','4h','0.003607000000000','0.003592000000000','0.001664035698628','0.001657115672157','0.4613350980393679','0.461335098039368','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','REPBTC','4h','0.003605000000000','0.003598000000000','0.001664035698628','0.001660804561349','0.4615910398413315','0.461591039841331','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','REPBTC','4h','0.003606000000000','0.003602000000000','0.001664035698628','0.001662189846494','0.46146303345202444','0.461463033452024','test'),('2019-03-26 03:59:59','2019-03-26 07:59:59','REPBTC','4h','0.003602000000000','0.003578000000000','0.001664035698628','0.001652948286977','0.4619754854602998','0.461975485460300','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','REPBTC','4h','0.003598000000000','0.003603000000000','0.001664035698628','0.001666348144012','0.46248907688382435','0.462489076883824','test'),('2019-03-29 23:59:59','2019-04-02 07:59:59','REPBTC','4h','0.003643000000000','0.003573000000000','0.001664035698628','0.001632061364589','0.45677620055668405','0.456776200556684','test'),('2019-04-03 03:59:59','2019-04-04 03:59:59','REPBTC','4h','0.004487000000000','0.003805000000000','0.001664035698628','0.001411111173006','0.3708570756915534','0.370857075691553','test'),('2019-04-09 15:59:59','2019-04-09 19:59:59','REPBTC','4h','0.004029000000000','0.003940000000000','0.001664035698628','0.001627277401984','0.4130145690315215','0.413014569031522','test'),('2019-04-12 19:59:59','2019-04-12 23:59:59','REPBTC','4h','0.003914000000000','0.003823000000000','0.001664035698628','0.001625347081210','0.4251496419591211','0.425149641959121','test'),('2019-04-14 23:59:59','2019-04-15 19:59:59','REPBTC','4h','0.003909000000000','0.003816000000000','0.001664035698628','0.001624446207717','0.4256934506595037','0.425693450659504','test'),('2019-04-17 23:59:59','2019-04-21 11:59:59','REPBTC','4h','0.003855000000000','0.003899000000000','0.001664035698628','0.001683028583385','0.43165647175823607','0.431656471758236','test'),('2019-04-21 23:59:59','2019-04-23 07:59:59','REPBTC','4h','0.003947000000000','0.004000000000000','0.001664035698628','0.001686380236765','0.42159505919128454','0.421595059191285','test'),('2019-04-25 03:59:59','2019-04-29 07:59:59','REPBTC','4h','0.003988000000000','0.003978000000000','0.001664035698628','0.001659863091560','0.41726070677733196','0.417260706777332','test'),('2019-06-08 07:59:59','2019-06-09 19:59:59','REPBTC','4h','0.002361000000000','0.002313000000000','0.001664035698628','0.001630205239698','0.7048012277119865','0.704801227711986','test'),('2019-06-10 03:59:59','2019-06-10 15:59:59','REPBTC','4h','0.002364000000000','0.002349000000000','0.001664035698628','0.001653477096479','0.7039068099103214','0.703906809910321','test'),('2019-07-13 07:59:59','2019-07-13 11:59:59','REPBTC','4h','0.001349000000000','0.001311000000000','0.001664035698628','0.001617161453596','1.2335327639940696','1.233532763994070','test'),('2019-07-30 11:59:59','2019-07-31 11:59:59','REPBTC','4h','0.001201000000000','0.001168000000000','0.001664035698628','0.001618312819315','1.3855417973588675','1.385541797358868','test'),('2019-08-14 07:59:59','2019-08-14 15:59:59','REPBTC','4h','0.000995000000000','0.000996000000000','0.001664035698628','0.001665708096315','1.6723976870633166','1.672397687063317','test'),('2019-08-20 11:59:59','2019-08-20 15:59:59','REPBTC','4h','0.000964000000000','0.000948000000000','0.001664035698628','0.001636416848858','1.7261781106099585','1.726178110609959','test'),('2019-08-21 19:59:59','2019-08-22 07:59:59','REPBTC','4h','0.000974000000000','0.000966000000000','0.001664035698628','0.001650368054286','1.7084555427392196','1.708455542739220','test'),('2019-08-24 11:59:59','2019-08-24 15:59:59','REPBTC','4h','0.000966000000000','0.000965000000000','0.001664035698628','0.001662313094385','1.7226042428861283','1.722604242886128','test'),('2019-09-05 23:59:59','2019-09-24 19:59:59','REPBTC','4h','0.000862000000000','0.001030000000000','0.001664035698628','0.001988348920634','1.930435845276102','1.930435845276102','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','REPBTC','4h','0.001047000000000','0.001036000000000','0.001664035698628','0.001646552993103','1.5893368659293219','1.589336865929322','test'),('2019-10-06 11:59:59','2019-10-06 15:59:59','REPBTC','4h','0.001010000000000','0.001009000000000','0.001664035698628','0.001662388138530','1.647560097651485','1.647560097651485','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','REPBTC','4h','0.001015000000000','0.001015000000000','0.001664035698628','0.001664035698628','1.6394440380571427','1.639444038057143','test'),('2019-10-07 23:59:59','2019-10-08 15:59:59','REPBTC','4h','0.001022000000000','0.001010000000000','0.001664035698628','0.001644497118996','1.628214969303327','1.628214969303327','test'),('2019-10-15 11:59:59','2019-10-15 23:59:59','REPBTC','4h','0.001009000000000','0.000997000000000','0.001664035698628','0.001644245383084','1.6491929619702677','1.649192961970268','test'),('2019-10-24 11:59:59','2019-10-25 03:59:59','REPBTC','4h','0.001010000000000','0.001002000000000','0.001664035698628','0.001650855217847','1.647560097651485','1.647560097651485','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  3:46:22
