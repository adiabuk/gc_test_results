-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','LTCBTC','4h','0.017919000000000','0.016817000000000','0.001467500000000','0.001377250265082','0.08189631117807913','0.081896311178079','test'),('2018-01-06 03:59:59','2018-01-06 07:59:59','LTCBTC','4h','0.017776000000000','0.016902000000000','0.001467500000000','0.001395346815932','0.08255513051305131','0.082555130513051','test'),('2018-01-07 07:59:59','2018-01-07 19:59:59','LTCBTC','4h','0.016833000000000','0.016720000000000','0.001467500000000','0.001457648666310','0.08717994415731005','0.087179944157310','test'),('2018-01-09 15:59:59','2018-01-09 19:59:59','LTCBTC','4h','0.017102000000000','0.016992000000000','0.001467500000000','0.001458061045492','0.08580867734767864','0.085808677347679','test'),('2018-01-11 03:59:59','2018-01-11 15:59:59','LTCBTC','4h','0.017066000000000','0.016900000000000','0.001467500000000','0.001453225711942','0.08598968709715223','0.085989687097152','test'),('2018-01-16 03:59:59','2018-01-16 07:59:59','LTCBTC','4h','0.017167000000000','0.017010000000000','0.001467500000000','0.001454079047009','0.08548377701403856','0.085483777014039','test'),('2018-01-18 15:59:59','2018-01-18 23:59:59','LTCBTC','4h','0.017300000000000','0.017020000000000','0.001467500000000','0.001443748554913','0.08482658959537573','0.084826589595376','test'),('2018-01-28 23:59:59','2018-01-29 03:59:59','LTCBTC','4h','0.016570000000000','0.016240000000000','0.001467500000000','0.001438273989137','0.08856366928183464','0.088563669281835','test'),('2018-01-30 15:59:59','2018-01-30 19:59:59','LTCBTC','4h','0.016344000000000','0.016545000000000','0.001467500000000','0.001485547448605','0.0897883015173764','0.089788301517376','test'),('2018-02-03 19:59:59','2018-02-19 23:59:59','LTCBTC','4h','0.017014000000000','0.019848000000000','0.001467500000000','0.001711939579170','0.08625249794287057','0.086252497942871','test'),('2018-02-20 07:59:59','2018-02-20 23:59:59','LTCBTC','4h','0.020902000000000','0.020367000000000','0.001467530280898','0.001429967908863','0.07021004118735048','0.070210041187350','test'),('2018-02-22 03:59:59','2018-02-22 07:59:59','LTCBTC','4h','0.020142000000000','0.020074000000000','0.001467530280898','0.001462575854371','0.07285921362814021','0.072859213628140','test'),('2018-02-23 11:59:59','2018-02-24 07:59:59','LTCBTC','4h','0.020582000000000','0.020547000000000','0.001467530280898','0.001465034723623','0.07130163642493441','0.071301636424934','test'),('2018-03-09 11:59:59','2018-03-12 11:59:59','LTCBTC','4h','0.019226000000000','0.019395000000000','0.001467530280898','0.001480430136171','0.07633050457182981','0.076330504571830','test'),('2018-03-12 15:59:59','2018-03-12 19:59:59','LTCBTC','4h','0.019489000000000','0.019733000000000','0.001467530280898','0.001485903588330','0.0753004402944225','0.075300440294422','test'),('2018-03-14 19:59:59','2018-03-15 03:59:59','LTCBTC','4h','0.019760000000000','0.019522000000000','0.001467530280898','0.001449854561928','0.07426772676609313','0.074267726766093','test'),('2018-04-03 19:59:59','2018-04-04 11:59:59','LTCBTC','4h','0.017799000000000','0.017146000000000','0.001467530280898','0.001413690330708','0.08245015342985562','0.082450153429856','test'),('2018-04-05 03:59:59','2018-04-05 07:59:59','LTCBTC','4h','0.017568000000000','0.017456000000000','0.001467530280898','0.001458174441220','0.0835342828380009','0.083534282838001','test'),('2018-04-17 07:59:59','2018-04-21 11:59:59','LTCBTC','4h','0.016551000000000','0.016466000000000','0.001467530280898','0.001459993571704','0.0886671669928101','0.088667166992810','test'),('2018-04-23 07:59:59','2018-04-23 11:59:59','LTCBTC','4h','0.017049000000000','0.016989000000000','0.001467530280898','0.001462365648553','0.08607720575388585','0.086077205753886','test'),('2018-05-03 03:59:59','2018-05-03 07:59:59','LTCBTC','4h','0.016635000000000','0.016461000000000','0.001467530280898','0.001452180099421','0.08821943377805831','0.088219433778058','test'),('2018-05-04 11:59:59','2018-05-09 03:59:59','LTCBTC','4h','0.016770000000000','0.016874000000000','0.001467530280898','0.001476631243880','0.08750925944531902','0.087509259445319','test'),('2018-05-14 19:59:59','2018-05-15 03:59:59','LTCBTC','4h','0.017163000000000','0.016829000000000','0.001467530280898','0.001438971455878','0.0855054641320282','0.085505464132028','test'),('2018-05-29 15:59:59','2018-05-29 19:59:59','LTCBTC','4h','0.016151000000000','0.016045000000000','0.001467530280898','0.001457898789983','0.09086312184372486','0.090863121843725','test'),('2018-05-30 11:59:59','2018-05-30 15:59:59','LTCBTC','4h','0.016171000000000','0.015850000000000','0.001467530280898','0.001438399292080','0.09075074397984045','0.090750743979840','test'),('2018-06-02 07:59:59','2018-06-02 15:59:59','LTCBTC','4h','0.016096000000000','0.016084000000000','0.001467530280898','0.001466436197687','0.09117360095042247','0.091173600950422','test'),('2018-07-03 07:59:59','2018-07-03 11:59:59','LTCBTC','4h','0.013304000000000','0.013126000000000','0.001467530280898','0.001447895555252','0.11030744745174384','0.110307447451744','test'),('2018-07-03 19:59:59','2018-07-03 23:59:59','LTCBTC','4h','0.013199000000000','0.013033000000000','0.001467530280898','0.001449073577615','0.11118495953466172','0.111184959534662','test'),('2018-07-16 11:59:59','2018-07-16 15:59:59','LTCBTC','4h','0.012438000000000','0.012542000000000','0.001467530280898','0.001479800995580','0.11798764117205339','0.117987641172053','test'),('2018-08-04 15:59:59','2018-08-04 19:59:59','LTCBTC','4h','0.010655000000000','0.010433000000000','0.001467530280898','0.001436953863971','0.1377316077801971','0.137731607780197','test'),('2018-08-05 03:59:59','2018-08-05 11:59:59','LTCBTC','4h','0.010477000000000','0.010518000000000','0.001467530280898','0.001473273216998','0.14007161218841271','0.140071612188413','test'),('2018-08-28 19:59:59','2018-08-29 03:59:59','LTCBTC','4h','0.008869000000000','0.008710000000000','0.001467530280898','0.001441220965906','0.16546738988589468','0.165467389885895','test'),('2018-08-31 19:59:59','2018-09-05 11:59:59','LTCBTC','4h','0.008798000000000','0.008911000000000','0.001467530280898','0.001486378987620','0.16680271435530802','0.166802714355308','test'),('2018-09-07 03:59:59','2018-09-07 07:59:59','LTCBTC','4h','0.008933000000000','0.008779000000000','0.001467530280898','0.001442230867122','0.16428190763438935','0.164281907634389','test'),('2018-09-14 19:59:59','2018-09-15 23:59:59','LTCBTC','4h','0.008889000000000','0.008655000000000','0.001467530280898','0.001428898029157','0.1650950929123636','0.165095092912364','test'),('2018-09-19 03:59:59','2018-09-19 07:59:59','LTCBTC','4h','0.008600000000000','0.008502000000000','0.001467530280898','0.001450807261418','0.1706430559183721','0.170643055918372','test'),('2018-09-20 23:59:59','2018-09-21 15:59:59','LTCBTC','4h','0.008708000000000','0.008560000000000','0.001467530280898','0.001442588333083','0.16852667442558567','0.168526674425586','test'),('2018-09-25 19:59:59','2018-09-26 15:59:59','LTCBTC','4h','0.008842000000000','0.008930000000000','0.001467530280898','0.001482135875189','0.16597266239515948','0.165972662395159','test'),('2018-10-08 19:59:59','2018-10-09 03:59:59','LTCBTC','4h','0.008965000000000','0.008930000000000','0.001467530280898','0.001461800937916','0.16369551376441718','0.163695513764417','test'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCBTC','4h','0.008083000000000','0.008050000000000','0.001467530280898','0.001461538879281','0.1815576247554126','0.181557624755413','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','LTCBTC','4h','0.007586000000000','0.007615000000000','0.001467530280898','0.001473140401930','0.19345244936699182','0.193452449366992','test'),('2018-11-25 23:59:59','2018-11-26 15:59:59','LTCBTC','4h','0.007710000000000','0.007660000000000','0.001467530280898','0.001458013223305','0.19034115186744488','0.190341151867445','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','LTCBTC','4h','0.007358000000000','0.007336000000000','0.001467530280898','0.001463142449126','0.19944689873579777','0.199446898735798','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','LTCBTC','4h','0.008015000000000','0.007918000000000','0.001467530280898','0.001449769777187','0.18309797640648784','0.183097976406488','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','LTCBTC','4h','0.008060000000000','0.008178000000000','0.001467530280898','0.001489015215531','0.1820757172330025','0.182075717233003','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:18:49
