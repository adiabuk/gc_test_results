-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-12 11:59:59','2018-09-12 15:59:59','WANETH','4h','0.004532000000000','0.004591000000000','0.072144500000000','0.073083715688438','15.918909973521625','15.918909973521625','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','WANETH','4h','0.004417000000000','0.004436000000000','0.072379303922110','0.072690647996033','16.386530206499774','16.386530206499774','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','WANETH','4h','0.004476000000000','0.004370000000000','0.072457139940590','0.070741220183284','16.18792223873777','16.187922238737769','test'),('2018-09-20 03:59:59','2018-09-20 07:59:59','WANETH','4h','0.004392000000000','0.004390000000000','0.072457139940590','0.072424144885972','16.497527308877505','16.497527308877505','test'),('2018-09-21 03:59:59','2018-09-21 07:59:59','WANETH','4h','0.004408000000000','0.004467000000000','0.072457139940590','0.073426961006038','16.437645177084846','16.437645177084846','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','WANETH','4h','0.004286000000000','0.004263000000000','0.072457139940590','0.072068312544735','16.905538950207653','16.905538950207653','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','WANETH','4h','0.004766000000000','0.004714000000000','0.072457139940590','0.071666587847239','15.202924872133863','15.202924872133863','test'),('2018-10-22 19:59:59','2018-10-23 11:59:59','WANETH','4h','0.004894000000000','0.004813000000000','0.072457139940590','0.071257910611782','14.805300355657948','14.805300355657948','test'),('2018-10-23 15:59:59','2018-10-23 19:59:59','WANETH','4h','0.004852000000000','0.004818000000000','0.072457139940590','0.071949402356505','14.933458355438992','14.933458355438992','test'),('2018-10-24 07:59:59','2018-10-27 23:59:59','WANETH','4h','0.004868000000000','0.004956000000000','0.072457139940590','0.073766964984709','14.88437550135374','14.884375501353739','test'),('2018-10-28 03:59:59','2018-10-28 15:59:59','WANETH','4h','0.005016000000000','0.005057000000000','0.072457139940590','0.073049393277425','14.4452033374382','14.445203337438199','test'),('2018-11-03 15:59:59','2018-11-04 07:59:59','WANETH','4h','0.005377000000000','0.005173000000000','0.072457139940590','0.069708161598042','13.475384032097825','13.475384032097825','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','WANETH','4h','0.003797000000000','0.003578000000000','0.072457139940590','0.068278021255578','19.08273372151435','19.082733721514352','test'),('2018-11-29 07:59:59','2018-11-29 23:59:59','WANETH','4h','0.003691000000000','0.003790000000000','0.072457139940590','0.074400585308815','19.630761295201843','19.630761295201843','test'),('2018-12-01 15:59:59','2018-12-02 03:59:59','WANETH','4h','0.003733000000000','0.003784000000000','0.072457139940590','0.073447044611624','19.40989551047147','19.409895510471468','test'),('2018-12-04 07:59:59','2018-12-06 23:59:59','WANETH','4h','0.003735000000000','0.003692000000000','0.072457139940590','0.071622961354929','19.399501992125835','19.399501992125835','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','WANETH','4h','0.003752000000000','0.003647000000000','0.072457139940590','0.070429421472103','19.31160446177772','19.311604461777719','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','WANETH','4h','0.003600000000000','0.003494000000000','0.072457139940590','0.070323679709006','20.126983316830557','20.126983316830557','test'),('2018-12-22 03:59:59','2018-12-22 15:59:59','WANETH','4h','0.003575000000000','0.003414000000000','0.072457139940590','0.069194035176832','20.267731451913285','20.267731451913285','test'),('2019-01-13 03:59:59','2019-01-13 07:59:59','WANETH','4h','0.002495000000000','0.002481000000000','0.072457139940590','0.072050566810663','29.04093785193988','29.040937851939880','test'),('2019-01-16 11:59:59','2019-01-20 15:59:59','WANETH','4h','0.002579000000000','0.002626000000000','0.072457139940590','0.073777607399763','28.09505232283443','28.095052322834430','test'),('2019-02-06 15:59:59','2019-02-07 03:59:59','WANETH','4h','0.002660000000000','0.002614000000000','0.072457139940590','0.071204121731091','27.239526293454887','27.239526293454887','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','WANETH','4h','0.002610000000000','0.002587000000000','0.072457139940590','0.071818628745711','27.761356299076628','27.761356299076628','test'),('2019-02-26 07:59:59','2019-03-05 15:59:59','WANETH','4h','0.002183000000000','0.002272000000000','0.072457139940590','0.075411187331663','33.19154371992212','33.191543719922123','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','WANETH','4h','0.002269000000000','0.002268000000000','0.072457139940590','0.072425206428056','31.93351253441604','31.933512534416039','test'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANETH','4h','0.002292000000000','0.002912000000000','0.072457139940590','0.092057238877399','31.613062801304533','31.613062801304533','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','WANETH','4h','0.003000000000000','0.003001000000000','0.074339141674291','0.074363921388182','24.77971389143042','24.779713891430418','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WANETH','4h','0.002993000000000','0.002811000000000','0.074345336602764','0.069824504240017','24.839738256853998','24.839738256853998','test'),('2019-03-23 03:59:59','2019-03-23 11:59:59','WANETH','4h','0.002963000000000','0.002930000000000','0.074345336602764','0.073517325766486','25.091237462964564','25.091237462964564','test'),('2019-03-26 23:59:59','2019-03-27 15:59:59','WANETH','4h','0.002973000000000','0.002911000000000','0.074345336602764','0.072794912496013','25.006840431471243','25.006840431471243','test'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANETH','4h','0.002974000000000','0.002955000000000','0.074345336602764','0.073870366395820','24.99843194443981','24.998431944439812','test'),('2019-03-31 07:59:59','2019-03-31 11:59:59','WANETH','4h','0.002955000000000','0.003002000000000','0.074345336602764','0.075527817421827','25.159166363033503','25.159166363033503','test'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANETH','4h','0.002591000000000','0.002594000000000','0.074345336602764','0.074431417656337','28.693684524416827','28.693684524416827','test'),('2019-04-22 23:59:59','2019-04-23 03:59:59','WANETH','4h','0.002534000000000','0.002497000000000','0.074345336602764','0.073259789067522','29.33912257409787','29.339122574097871','test'),('2019-05-01 07:59:59','2019-05-01 15:59:59','WANETH','4h','0.002363000000000','0.002311000000000','0.074345336602764','0.072709298725767','31.462266865325436','31.462266865325436','test'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANETH','4h','0.001722000000000','0.001713000000000','0.074345336602764','0.073956772125746','43.173830779770036','43.173830779770036','test'),('2019-06-02 11:59:59','2019-06-11 19:59:59','WANETH','4h','0.001771000000000','0.001830000000000','0.074345336602764','0.076822115179592','41.97929791234557','41.979297912345572','test'),('2019-06-12 11:59:59','2019-06-12 19:59:59','WANETH','4h','0.001837000000000','0.001816000000000','0.074345336602764','0.073495444349820','40.47105966399782','40.471059663997821','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','WANETH','4h','0.001831000000000','0.001801000000000','0.074345336602764','0.073127226226968','40.60367919320809','40.603679193208087','test'),('2019-07-07 07:59:59','2019-07-07 19:59:59','WANETH','4h','0.001336000000000','0.001207000000000','0.074345336602764','0.067166782394862','55.64770703799701','55.647707037997009','test'),('2019-07-14 15:59:59','2019-07-14 19:59:59','WANETH','4h','0.001165000000000','0.001163000000000','0.074345336602764','0.074217705123618','63.81573957318798','63.815739573187983','test'),('2019-07-20 19:59:59','2019-07-21 15:59:59','WANETH','4h','0.001148000000000','0.001144000000000','0.074345336602764','0.074086293618085','64.76074616965506','64.760746169655064','test'),('2019-08-10 03:59:59','2019-08-10 07:59:59','WANETH','4h','0.001158000000000','0.001146000000000','0.074345336602764','0.073574918606880','64.20149965696373','64.201499656963733','test'),('2019-08-10 11:59:59','2019-08-10 15:59:59','WANETH','4h','0.001182000000000','0.001167000000000','0.074345336602764','0.073401867864150','62.89791590758375','62.897915907583752','test'),('2019-08-11 03:59:59','2019-08-11 07:59:59','WANETH','4h','0.001175000000000','0.001159000000000','0.074345336602764','0.073332974572429','63.27262689596936','63.272626895969360','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','WANETH','4h','0.001163000000000','0.001147000000000','0.074345336602764','0.073322528876501','63.92548289145658','63.925482891456582','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','WANETH','4h','0.001179000000000','0.001151000000000','0.074345336602764','0.072579713680900','63.05796149513487','63.057961495134869','test'),('2019-08-15 15:59:59','2019-08-15 23:59:59','WANETH','4h','0.001172000000000','0.001152000000000','0.074345336602764','0.073076644851864','63.43458754502048','63.434587545020477','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','WANETH','4h','0.001154000000000','0.001192000000000','0.074345336602764','0.076793449939770','64.42403518437088','64.424035184370879','test'),('2019-08-30 15:59:59','2019-09-03 15:59:59','WANETH','4h','0.002236000000000','0.002043000000000','0.074345336602764','0.067928230178643','33.249256083525935','33.249256083525935','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 12:57:58
