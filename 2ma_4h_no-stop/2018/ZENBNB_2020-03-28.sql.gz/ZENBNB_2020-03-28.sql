-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-16 03:59:59','2018-11-17 03:59:59','ZENBNB','4h','1.527000000000000','1.501000000000000','0.711908500000000','0.699786940733464','0.4662138179436805','0.466213817943680','test'),('2018-11-24 11:59:59','2018-11-24 15:59:59','ZENBNB','4h','1.457000000000000','1.434000000000000','0.711908500000000','0.700670411118737','0.48861256005490733','0.488612560054907','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','ZENBNB','4h','0.986000000000000','0.959000000000000','0.711908500000000','0.692414048174442','0.722016734279919','0.722016734279919','test'),('2018-12-24 07:59:59','2018-12-24 11:59:59','ZENBNB','4h','0.972000000000000','0.946000000000000','0.711908500000000','0.692865680041152','0.7324161522633745','0.732416152263375','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','ZENBNB','4h','0.962000000000000','0.954000000000000','0.711908500000000','0.705988262993763','0.7400296257796258','0.740029625779626','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','ZENBNB','4h','0.965000000000000','0.945000000000000','0.711908500000000','0.697153919689119','0.7377290155440416','0.737729015544042','test'),('2018-12-25 15:59:59','2018-12-26 15:59:59','ZENBNB','4h','0.977000000000000','0.959000000000000','0.711908500000000','0.698792478505630','0.7286678607983624','0.728667860798362','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','ZENBNB','4h','0.988000000000000','0.989000000000000','0.711908500000000','0.712629055161943','0.7205551619433199','0.720555161943320','test'),('2018-12-30 19:59:59','2018-12-30 23:59:59','ZENBNB','4h','0.983000000000000','0.969000000000000','0.711908500000000','0.701769416581892','0.7242202441505596','0.724220244150560','test'),('2019-01-30 19:59:59','2019-01-31 03:59:59','ZENBNB','4h','0.702000000000000','0.695000000000000','0.711908500000000','0.704809697293447','1.0141146723646726','1.014114672364673','test'),('2019-02-14 03:59:59','2019-02-14 11:59:59','ZENBNB','4h','0.539000000000000','0.520000000000000','0.711908500000000','0.686813395176252','1.320794990723562','1.320794990723562','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','ZENBNB','4h','0.534000000000000','0.511000000000000','0.711908500000000','0.681245774344569','1.3331619850187266','1.333161985018727','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','ZENBNB','4h','0.518000000000000','0.499000000000000','0.711908500000000','0.685796026061776','1.3743407335907336','1.374340733590734','test'),('2019-03-14 23:59:59','2019-03-15 07:59:59','ZENBNB','4h','0.415000000000000','0.402000000000000','0.711908500000000','0.689607751807229','1.715442168674699','1.715442168674699','test'),('2019-03-16 23:59:59','2019-03-17 03:59:59','ZENBNB','4h','0.408000000000000','0.411000000000000','0.711908500000000','0.717143121323529','1.7448737745098042','1.744873774509804','test'),('2019-03-23 23:59:59','2019-03-24 11:59:59','ZENBNB','4h','0.433000000000000','0.377000000000000','0.711908500000000','0.619837192840647','1.6441304849884528','1.644130484988453','test'),('2019-03-29 15:59:59','2019-03-29 23:59:59','ZENBNB','4h','0.415000000000000','0.420000000000000','0.711908500000000','0.720485710843374','1.715442168674699','1.715442168674699','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','ZENBNB','4h','0.415000000000000','0.403000000000000','0.711908500000000','0.691323193975904','1.715442168674699','1.715442168674699','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','ZENBNB','4h','0.415000000000000','0.397000000000000','0.711908500000000','0.681030540963856','1.715442168674699','1.715442168674699','test'),('2019-04-07 15:59:59','2019-04-12 19:59:59','ZENBNB','4h','0.402000000000000','0.425000000000000','0.711908500000000','0.752639583333333','1.7709166666666667','1.770916666666667','test'),('2019-04-24 07:59:59','2019-04-24 11:59:59','ZENBNB','4h','0.341000000000000','0.323000000000000','0.711908500000000','0.674329752199413','2.087708211143695','2.087708211143695','test'),('2019-04-27 03:59:59','2019-04-27 15:59:59','ZENBNB','4h','0.339000000000000','0.337000000000000','0.711908500000000','0.707708449852507','2.1000250737463126','2.100025073746313','test'),('2019-04-28 23:59:59','2019-04-29 03:59:59','ZENBNB','4h','0.331000000000000','0.327000000000000','0.711908500000000','0.703305376132931','2.1507809667673716','2.150780966767372','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','ZENBNB','4h','0.334000000000000','0.327000000000000','0.711908500000000','0.696988261976048','2.1314625748502993','2.131462574850299','test'),('2019-04-30 15:59:59','2019-05-02 15:59:59','ZENBNB','4h','0.331000000000000','0.337000000000000','0.711908500000000','0.724813185800604','2.1507809667673716','2.150780966767372','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','ZENBNB','4h','0.331000000000000','0.331000000000000','0.711908500000000','0.711908500000000','2.1507809667673716','2.150780966767372','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','ZENBNB','4h','0.318000000000000','0.323000000000000','0.711908500000000','0.723102029874214','2.2387059748427673','2.238705974842767','test'),('2019-06-27 07:59:59','2019-06-27 15:59:59','ZENBNB','4h','0.303000000000000','0.286000000000000','0.711908500000000','0.671966438943894','2.3495330033003303','2.349533003300330','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','ZENBNB','4h','0.333000000000000','0.290000000000000','0.711908500000000','0.619980375375375','2.1378633633633632','2.137863363363363','test'),('2019-07-01 03:59:59','2019-07-01 07:59:59','ZENBNB','4h','0.293000000000000','0.292000000000000','0.711908500000000','0.709478778156997','2.429721843003413','2.429721843003413','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','ZENBNB','4h','0.293000000000000','0.283000000000000','0.711908500000000','0.687611281569966','2.429721843003413','2.429721843003413','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','ZENBNB','4h','0.288000000000000','0.281000000000000','0.711908500000000','0.694605168402778','2.471904513888889','2.471904513888889','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','ZENBNB','4h','0.297000000000000','0.267000000000000','0.711908500000000','0.639998550505051','2.396998316498317','2.396998316498317','test'),('2019-07-08 23:59:59','2019-07-09 07:59:59','ZENBNB','4h','0.286000000000000','0.291000000000000','0.711908500000000','0.724354452797203','2.48919055944056','2.489190559440560','test'),('2019-07-10 03:59:59','2019-07-10 15:59:59','ZENBNB','4h','0.303000000000000','0.286000000000000','0.711908500000000','0.671966438943894','2.3495330033003303','2.349533003300330','test'),('2019-07-11 15:59:59','2019-07-11 19:59:59','ZENBNB','4h','0.286600000000000','0.277800000000000','0.711908500000000','0.690049481158409','2.483979413817167','2.483979413817167','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ZENBNB','4h','0.227200000000000','0.234000000000000','0.711908500000000','0.733215620598592','3.133400088028169','3.133400088028169','test'),('2019-08-03 11:59:59','2019-08-06 03:59:59','ZENBNB','4h','0.260300000000000','0.259300000000000','0.711908500000000','0.709173546100653','2.734953899346908','2.734953899346908','test'),('2019-08-24 19:59:59','2019-08-26 07:59:59','ZENBNB','4h','0.197500000000000','0.190300000000000','0.711908500000000','0.685955380000000','3.6046','3.604600000000000','test'),('2019-08-26 19:59:59','2019-08-27 03:59:59','ZENBNB','4h','0.196400000000000','0.200500000000000','0.711908500000000','0.726770133655805','3.6247886965376788','3.624788696537679','test'),('2019-08-28 11:59:59','2019-08-28 19:59:59','ZENBNB','4h','0.196900000000000','0.205500000000000','0.711908500000000','0.743002522854241','3.61558405281869','3.615584052818690','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','ZENBNB','4h','0.196900000000000','0.196300000000000','0.711908500000000','0.709739149568309','3.61558405281869','3.615584052818690','test'),('2019-09-11 23:59:59','2019-09-12 03:59:59','ZENBNB','4h','0.194300000000000','0.196100000000000','0.711908500000000','0.718503637931035','3.6639655172413796','3.663965517241380','test'),('2019-09-14 03:59:59','2019-09-14 07:59:59','ZENBNB','4h','0.193100000000000','0.193000000000000','0.711908500000000','0.711539826514759','3.686734852408079','3.686734852408079','test'),('2019-09-15 15:59:59','2019-09-17 11:59:59','ZENBNB','4h','0.196000000000000','0.195000000000000','0.711908500000000','0.708276313775510','3.632186224489796','3.632186224489796','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','ZENBNB','4h','0.195000000000000','0.185100000000000','0.711908500000000','0.675765453076923','3.6508128205128205','3.650812820512821','test'),('2019-09-20 11:59:59','2019-09-21 07:59:59','ZENBNB','4h','0.193500000000000','0.191100000000000','0.711908500000000','0.703078627131783','3.6791136950904395','3.679113695090440','test'),('2019-09-21 15:59:59','2019-09-30 07:59:59','ZENBNB','4h','0.197500000000000','0.213300000000000','0.711908500000000','0.768861180000000','3.6046','3.604600000000000','test'),('2019-10-19 11:59:59','2019-10-29 07:59:59','ZENBNB','4h','0.202700000000000','0.227700000000000','0.711908500000000','0.799711719042921','3.5121287617168235','3.512128761716824','test'),('2019-10-29 23:59:59','2019-11-03 07:59:59','ZENBNB','4h','0.245200000000000','0.239700000000000','0.711908500000000','0.695939916190865','2.9033788743882547','2.903378874388255','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','ZENBNB','4h','0.238400000000000','0.236400000000000','0.711908500000000','0.705936113255034','2.9861933724832217','2.986193372483222','test'),('2019-11-05 11:59:59','2019-11-05 23:59:59','ZENBNB','4h','0.237300000000000','0.235700000000000','0.711908500000000','0.707108442688580','3.00003581963759','3.000035819637590','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:15:19
