-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-05 19:59:59','2018-04-05 23:59:59','ETCETH','4h','0.035984000000000','0.035767000000000','0.072144500000000','0.071709435624166','2.004904957759004','2.004904957759004','test'),('2018-04-18 15:59:59','2018-04-18 19:59:59','ETCETH','4h','0.032992000000000','0.033800000000000','0.072144500000000','0.073911375484966','2.186727085354025','2.186727085354025','test'),('2018-04-26 23:59:59','2018-04-27 03:59:59','ETCETH','4h','0.031773000000000','0.031417000000000','0.072477452777283','0.071665380477257','2.281101966363988','2.281101966363988','test'),('2018-04-27 23:59:59','2018-04-28 11:59:59','ETCETH','4h','0.032217000000000','0.031311000000000','0.072477452777283','0.070439256414611','2.2496648594618676','2.249664859461868','test'),('2018-04-28 15:59:59','2018-04-28 23:59:59','ETCETH','4h','0.031909000000000','0.031738000000000','0.072477452777283','0.072089046859676','2.2713796351274875','2.271379635127488','test'),('2018-04-30 03:59:59','2018-05-01 07:59:59','ETCETH','4h','0.032419000000000','0.031964000000000','0.072477452777283','0.071460233214259','2.235647391260773','2.235647391260773','test'),('2018-05-06 11:59:59','2018-05-08 03:59:59','ETCETH','4h','0.031377000000000','0.030581000000000','0.072477452777283','0.070638779468467','2.3098910914772923','2.309891091477292','test'),('2018-05-08 11:59:59','2018-05-08 15:59:59','ETCETH','4h','0.030781000000000','0.030194000000000','0.072477452777283','0.071095292848097','2.354616574421981','2.354616574421981','test'),('2018-05-24 11:59:59','2018-05-24 15:59:59','ETCETH','4h','0.026247000000000','0.026080000000000','0.072477452777283','0.072016305422774','2.761361404247457','2.761361404247457','test'),('2018-05-26 07:59:59','2018-05-26 15:59:59','ETCETH','4h','0.026020000000000','0.026085000000000','0.072477452777283','0.072658507136642','2.785451682447463','2.785451682447463','test'),('2018-06-01 19:59:59','2018-06-02 03:59:59','ETCETH','4h','0.026618000000000','0.026600000000000','0.072477452777283','0.072428441050257','2.722873723693854','2.722873723693854','test'),('2018-06-12 03:59:59','2018-06-14 19:59:59','ETCETH','4h','0.029089000000000','0.027286000000000','0.072477452777283','0.067985141341433','2.491575948890749','2.491575948890749','test'),('2018-07-19 15:59:59','2018-07-19 23:59:59','ETCETH','4h','0.037051000000000','0.037093000000000','0.072477452777283','0.072559611234994','1.956153755020998','1.956153755020998','test'),('2018-07-26 15:59:59','2018-07-26 19:59:59','ETCETH','4h','0.036142000000000','0.036129000000000','0.072477452777283','0.072451383193804','2.005352575321869','2.005352575321869','test'),('2018-07-27 15:59:59','2018-07-28 15:59:59','ETCETH','4h','0.036292000000000','0.036231000000000','0.072477452777283','0.072355631863048','1.9970641677858207','1.997064167785821','test'),('2018-08-03 23:59:59','2018-08-08 23:59:59','ETCETH','4h','0.039660000000000','0.042519000000000','0.072477452777283','0.077702188972196','1.8274698128412254','1.827469812841225','test'),('2018-08-14 19:59:59','2018-08-14 23:59:59','ETCETH','4h','0.041448000000000','0.042301000000000','0.072477452777283','0.073969039035221','1.748635706844311','1.748635706844311','test'),('2018-08-28 11:59:59','2018-08-28 15:59:59','ETCETH','4h','0.044977000000000','0.044607000000000','0.072477452777283','0.071881222314433','1.611433683377793','1.611433683377793','test'),('2018-08-28 19:59:59','2018-08-28 23:59:59','ETCETH','4h','0.045300000000000','0.044603000000000','0.072477452777283','0.071362291969650','1.599943769917947','1.599943769917947','test'),('2018-08-29 15:59:59','2018-08-30 23:59:59','ETCETH','4h','0.045104000000000','0.045130000000000','0.072477452777283','0.072519232082272','1.6068963457184064','1.606896345718406','test'),('2018-09-02 15:59:59','2018-09-02 19:59:59','ETCETH','4h','0.045127000000000','0.045165000000000','0.072477452777283','0.072538483716755','1.6060773545168745','1.606077354516875','test'),('2018-09-25 11:59:59','2018-09-25 19:59:59','ETCETH','4h','0.051047000000000','0.050730000000000','0.072477452777283','0.072027370450596','1.4198180652591337','1.419818065259134','test'),('2018-09-28 15:59:59','2018-09-28 19:59:59','ETCETH','4h','0.050369000000000','0.050900000000000','0.072477452777283','0.073241524476637','1.4389297539614248','1.438929753961425','test'),('2018-10-03 03:59:59','2018-10-03 07:59:59','ETCETH','4h','0.049968000000000','0.049865000000000','0.072477452777283','0.072328053609094','1.4504773610567363','1.450477361056736','test'),('2018-10-05 03:59:59','2018-10-05 11:59:59','ETCETH','4h','0.049952000000000','0.049477000000000','0.072477452777283','0.071788255346365','1.4509419598270938','1.450941959827094','test'),('2018-10-11 07:59:59','2018-10-11 15:59:59','ETCETH','4h','0.049814000000000','0.048645000000000','0.072477452777283','0.070776602769321','1.4549615123716828','1.454961512371683','test'),('2018-10-22 11:59:59','2018-10-23 23:59:59','ETCETH','4h','0.049300000000000','0.048125000000000','0.072477452777283','0.070750048983910','1.470130887977343','1.470130887977343','test'),('2018-10-25 23:59:59','2018-10-26 03:59:59','ETCETH','4h','0.047921000000000','0.047714000000000','0.072477452777283','0.072164378494090','1.5124361506914088','1.512436150691409','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','ETCETH','4h','0.045451000000000','0.042657000000000','0.072477452777283','0.068022061189425','1.5946283421109106','1.594628342110911','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','ETCETH','4h','0.043119000000000','0.041900000000000','0.072477452777283','0.070428471703151','1.6808704463759132','1.680870446375913','test'),('2018-11-30 03:59:59','2018-11-30 07:59:59','ETCETH','4h','0.041781000000000','0.042216000000000','0.072477452777283','0.073232046778339','1.734698853002154','1.734698853002154','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','ETCETH','4h','0.041776000000000','0.041000000000000','0.072477452777283','0.071131165354955','1.7349064720720748','1.734906472072075','test'),('2018-12-02 11:59:59','2018-12-03 23:59:59','ETCETH','4h','0.041697000000000','0.041551000000000','0.072477452777283','0.072223676531858','1.7381934618145911','1.738193461814591','test'),('2018-12-08 11:59:59','2018-12-08 19:59:59','ETCETH','4h','0.041655000000000','0.041952000000000','0.072477452777283','0.072994216754593','1.7399460515492258','1.739946051549226','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','ETCETH','4h','0.043000000000000','0.042313000000000','0.072477452777283','0.071319499055004','1.6855221576112327','1.685522157611233','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','ETCETH','4h','0.043629000000000','0.041324000000000','0.072477452777283','0.068648336165588','1.6612219573513718','1.661221957351372','test'),('2018-12-19 15:59:59','2018-12-20 11:59:59','ETCETH','4h','0.043464000000000','0.042923000000000','0.072477452777283','0.071575319932802','1.6675283631806321','1.667528363180632','test'),('2018-12-26 23:59:59','2018-12-28 19:59:59','ETCETH','4h','0.041910000000000','0.039051000000000','0.072477452777283','0.067533214230629','1.7293594077137435','1.729359407713744','test'),('2019-01-11 07:59:59','2019-01-11 15:59:59','ETCETH','4h','0.035193000000000','0.035487000000000','0.072477452777283','0.073082924635792','2.059428090168016','2.059428090168016','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ETCETH','4h','0.035154000000000','0.035032000000000','0.072477452777283','0.072225923812191','2.061712828619304','2.061712828619304','test'),('2019-01-17 03:59:59','2019-01-17 11:59:59','ETCETH','4h','0.035141000000000','0.035560000000000','0.072477452777283','0.073341630026470','2.062475535052588','2.062475535052588','test'),('2019-01-31 19:59:59','2019-02-01 15:59:59','ETCETH','4h','0.036879000000000','0.036593000000000','0.072477452777283','0.071915383537491','1.9652770622110955','1.965277062211096','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','ETCETH','4h','0.036930000000000','0.036032000000000','0.072477452777283','0.070715071174413','1.9625630321495533','1.962563032149553','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','ETCETH','4h','0.031730000000000','0.031591000000000','0.072477452777283','0.072159949911350','2.2841932800908604','2.284193280090860','test'),('2019-03-02 07:59:59','2019-03-05 15:59:59','ETCETH','4h','0.031841000000000','0.031803000000000','0.072477452777283','0.072390956021354','2.276230419185421','2.276230419185421','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','ETCETH','4h','0.031729000000000','0.031694000000000','0.072477452777283','0.072397503492805','2.2842652708021998','2.284265270802200','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','ETCETH','4h','0.031846000000000','0.031653000000000','0.072477452777283','0.072038209280894','2.275873038286849','2.275873038286849','test'),('2019-03-16 15:59:59','2019-03-16 19:59:59','ETCETH','4h','0.032003000000000','0.031840000000000','0.072477452777283','0.072108305359769','2.2647080829073216','2.264708082907322','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','ETCETH','4h','0.032078000000000','0.031773000000000','0.072477452777283','0.071788331787911','2.2594130799078185','2.259413079907818','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','ETCETH','4h','0.031909000000000','0.031873000000000','0.072477452777283','0.072395683110418','2.2713796351274875','2.271379635127488','test'),('2019-03-19 15:59:59','2019-03-28 11:59:59','ETCETH','4h','0.032903000000000','0.034118000000000','0.072477452777283','0.075153807672715','2.202761230808224','2.202761230808224','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','ETCETH','4h','0.034912000000000','0.034777000000000','0.072477452777283','0.072197192232916','2.076004032346557','2.076004032346557','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:36:11
