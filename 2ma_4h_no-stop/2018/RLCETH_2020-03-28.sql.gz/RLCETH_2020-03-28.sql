-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-04 11:59:59','RLCETH','4h','0.001714000000000','0.001648000000000','0.072144500000000','0.069366473745624','42.091306884480744','42.091306884480744','test'),('2018-07-04 15:59:59','2018-07-05 15:59:59','RLCETH','4h','0.001744000000000','0.001718000000000','0.072144500000000','0.071068951261468','41.367259174311926','41.367259174311926','test'),('2018-07-07 07:59:59','2018-07-08 03:59:59','RLCETH','4h','0.001739000000000','0.001715000000000','0.072144500000000','0.071148831224842','41.486198964922366','41.486198964922366','test'),('2018-07-09 11:59:59','2018-07-09 15:59:59','RLCETH','4h','0.001694000000000','0.001705000000000','0.072144500000000','0.072612970779221','42.58825265643448','42.588252656434477','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','RLCETH','4h','0.001637000000000','0.001614000000000','0.072144500000000','0.071130863164325','44.071166768478925','44.071166768478925','test'),('2018-07-18 03:59:59','2018-07-20 15:59:59','RLCETH','4h','0.001684000000000','0.001612000000000','0.072144500000000','0.069059937054632','42.84115201900238','42.841152019002379','test'),('2018-07-30 23:59:59','2018-07-31 03:59:59','RLCETH','4h','0.001458000000000','0.001464000000000','0.072144500000000','0.072441390946502','49.4818244170096','49.481824417009598','test'),('2018-08-13 07:59:59','2018-08-13 19:59:59','RLCETH','4h','0.001152000000000','0.001114000000000','0.072144500000000','0.069764733506944','62.62543402777778','62.625434027777779','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','RLCETH','4h','0.001147000000000','0.001088000000000','0.072144500000000','0.068433492589364','62.898430688753265','62.898430688753265','test'),('2018-08-17 15:59:59','2018-08-18 03:59:59','RLCETH','4h','0.001166000000000','0.001127000000000','0.072144500000000','0.069731433533448','61.87349914236707','61.873499142367073','test'),('2018-08-19 15:59:59','2018-08-28 23:59:59','RLCETH','4h','0.001138000000000','0.001446000000000','0.072144500000000','0.091670427943761','63.395869947275926','63.395869947275926','test'),('2018-08-30 19:59:59','2018-08-30 23:59:59','RLCETH','4h','0.001437000000000','0.001457000000000','0.072854501437533','0.073868481972502','50.69902674845703','50.699026748457030','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','RLCETH','4h','0.001469000000000','0.001438000000000','0.073107996571275','0.071565213798158','49.76718622959497','49.767186229594969','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','RLCETH','4h','0.001534000000000','0.001465000000000','0.073107996571275','0.069819566477782','47.65840715206975','47.658407152069749','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','RLCETH','4h','0.001689000000000','0.001680000000000','0.073107996571275','0.072718433534483','43.28478186576376','43.284781865763762','test'),('2018-09-17 15:59:59','2018-09-17 19:59:59','RLCETH','4h','0.001671000000000','0.001826000000000','0.073107996571275','0.079889408581178','43.75104522517953','43.751045225179531','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','RLCETH','4h','0.001692000000000','0.001678000000000','0.073498155597900','0.072890014830541','43.43862623989377','43.438626239893772','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','RLCETH','4h','0.001667000000000','0.001694000000000','0.073498155597900','0.074688587632179','44.090075343671266','44.090075343671266','test'),('2018-09-30 03:59:59','2018-09-30 11:59:59','RLCETH','4h','0.001694000000000','0.001689000000000','0.073643728414630','0.073426362037963','43.47327533331184','43.473275333311840','test'),('2018-10-06 19:59:59','2018-10-08 03:59:59','RLCETH','4h','0.001785000000000','0.001752000000000','0.073643728414630','0.072282247721250','41.256990708476195','41.256990708476195','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','RLCETH','4h','0.002291000000000','0.002274000000000','0.073643728414630','0.073097266876852','32.14479633986469','32.144796339864691','test'),('2018-11-01 07:59:59','2018-11-03 07:59:59','RLCETH','4h','0.002315000000000','0.002245000000000','0.073643728414630','0.071416920212028','31.81154575146005','31.811545751460049','test'),('2018-11-03 11:59:59','2018-11-03 15:59:59','RLCETH','4h','0.002312000000000','0.002232000000000','0.073643728414630','0.071095502517930','31.852823708750005','31.852823708750005','test'),('2018-11-16 07:59:59','2018-11-16 11:59:59','RLCETH','4h','0.002073000000000','0.002093000000000','0.073643728414630','0.074354232306715','35.525194604259525','35.525194604259525','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','RLCETH','4h','0.002034000000000','0.002003000000000','0.073643728414630','0.072521331373896','36.20635615271878','36.206356152718783','test'),('2018-11-21 07:59:59','2018-11-21 23:59:59','RLCETH','4h','0.002066000000000','0.002009000000000','0.073643728414630','0.071611931454497','35.645560704080346','35.645560704080346','test'),('2018-11-27 07:59:59','2018-11-29 23:59:59','RLCETH','4h','0.001994000000000','0.002129000000000','0.073643728414630','0.078629637810806','36.93266219389669','36.932662193896689','test'),('2018-12-01 07:59:59','2018-12-01 15:59:59','RLCETH','4h','0.002028000000000','0.002030000000000','0.073643728414630','0.073716355365729','36.31347554962032','36.313475549620321','test'),('2018-12-05 03:59:59','2018-12-05 07:59:59','RLCETH','4h','0.002044000000000','0.002001000000000','0.073643728414630','0.072094471897101','36.02922133788161','36.029221337881609','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','RLCETH','4h','0.002043000000000','0.001981000000000','0.073643728414630','0.071408823293873','36.04685678640725','36.046856786407247','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','RLCETH','4h','0.002017000000000','0.002059000000000','0.073643728414630','0.075177212100011','36.51151631860684','36.511516318606837','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','RLCETH','4h','0.002021000000000','0.001969000000000','0.073643728414630','0.071748887307475','36.43925206067789','36.439252060677887','test'),('2018-12-13 07:59:59','2018-12-13 23:59:59','RLCETH','4h','0.001993000000000','0.001953000000000','0.073643728414630','0.072165680679264','36.95119338415956','36.951193384159559','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','RLCETH','4h','0.001391000000000','0.001396000000000','0.073643728414630','0.073908443470038','52.94301108168943','52.943011081689427','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','RLCETH','4h','0.001387000000000','0.001406000000000','0.073643728414630','0.074652546612091','53.09569460319395','53.095694603193948','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','RLCETH','4h','0.001989000000000','0.002034000000000','0.073643728414630','0.075309876116318','37.02550448196582','37.025504481965818','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','RLCETH','4h','0.002047000000000','0.001978000000000','0.073643728414630','0.071161355546721','35.97641837549096','35.976418375490958','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','RLCETH','4h','0.002423000000000','0.002391000000000','0.073643728414630','0.072671132744276','30.393614698567895','30.393614698567895','test'),('2019-03-12 15:59:59','2019-03-19 19:59:59','RLCETH','4h','0.002598000000000','0.002887000000000','0.073643728414630','0.081835813677073','28.34631578700154','28.346315787001540','test'),('2019-03-22 07:59:59','2019-03-23 19:59:59','RLCETH','4h','0.002933000000000','0.002877000000000','0.073643728414630','0.072237642907907','25.108669762915106','25.108669762915106','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','RLCETH','4h','0.002873000000000','0.002861000000000','0.073643728414630','0.073336131915857','25.63304156443787','25.633041564437871','test'),('2019-03-24 19:59:59','2019-03-24 23:59:59','RLCETH','4h','0.002879000000000','0.002871000000000','0.073643728414630','0.073439091447865','25.579620845651267','25.579620845651267','test'),('2019-03-25 19:59:59','2019-03-30 03:59:59','RLCETH','4h','0.002896000000000','0.002953000000000','0.073643728414630','0.075093207875830','25.42946423157113','25.429464231571131','test'),('2019-03-30 15:59:59','2019-04-03 03:59:59','RLCETH','4h','0.003011000000000','0.002959000000000','0.073643728414630','0.072371900491162','24.458229297452675','24.458229297452675','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','RLCETH','4h','0.003133000000000','0.003123000000000','0.073643728414630','0.073408670232649','23.50581819809448','23.505818198094481','test'),('2019-04-04 11:59:59','2019-04-07 15:59:59','RLCETH','4h','0.003191000000000','0.003243000000000','0.073643728414630','0.074843814242759','23.07857361787214','23.078573617872141','test'),('2019-04-15 19:59:59','2019-04-16 03:59:59','RLCETH','4h','0.003174000000000','0.003009000000000','0.073643728414630','0.069815368241847','23.202182865352867','23.202182865352867','test'),('2019-04-17 15:59:59','2019-04-18 03:59:59','RLCETH','4h','0.003121000000000','0.002978000000000','0.073643728414630','0.070269472354620','23.596196223848125','23.596196223848125','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','RLCETH','4h','0.003037000000000','0.003027000000000','0.073643728414630','0.073401240010235','24.2488404394567','24.248840439456700','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','RLCETH','4h','0.003119000000000','0.003020000000000','0.073643728414630','0.071306207057449','23.611326840214815','23.611326840214815','test'),('2019-04-30 19:59:59','2019-04-30 23:59:59','RLCETH','4h','0.003098000000000','0.002946000000000','0.073643728414630','0.070030478989509','23.77137779684635','23.771377796846352','test'),('2019-05-13 07:59:59','2019-05-13 19:59:59','RLCETH','4h','0.003717000000000','0.003444000000000','0.073643728414630','0.068234867005646','19.812679153788004','19.812679153788004','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','RLCETH','4h','0.003534000000000','0.003403000000000','0.073643728414630','0.070913867514144','20.83863282813526','20.838632828135260','test'),('2019-05-15 15:59:59','2019-05-15 19:59:59','RLCETH','4h','0.003511000000000','0.002993000000000','0.073643728414630','0.062778604142691','20.975143382121903','20.975143382121903','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','RLCETH','4h','0.001786000000000','0.001784000000000','0.073643728414630','0.073561260633651','41.23389048971445','41.233890489714447','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','RLCETH','4h','0.001392000000000','0.001268000000000','0.073643728414630','0.067083511228269','52.90497730936063','52.904977309360632','test'),('2019-06-27 15:59:59','2019-06-27 19:59:59','RLCETH','4h','0.001277000000000','0.001257000000000','0.073643728414630','0.072490341908528','57.66932530511355','57.669325305113553','test'),('2019-06-28 19:59:59','2019-06-28 23:59:59','RLCETH','4h','0.001350000000000','0.001243000000000','0.073643728414630','0.067806781051396','54.55090993676296','54.550909936762963','test'),('2019-06-29 07:59:59','2019-06-29 11:59:59','RLCETH','4h','0.001283000000000','0.001274000000000','0.073643728414630','0.073127131722711','57.399632435409195','57.399632435409195','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:32:18
