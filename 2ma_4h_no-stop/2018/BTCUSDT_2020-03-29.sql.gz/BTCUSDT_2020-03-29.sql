-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-12 19:59:59','2018-02-12 23:59:59','BTCUSDT','4h','8792.760000000000218','8903.000000000000000','15.000000000000000','15.188063816139643','0.0017059489853015436','0.001705948985302','test'),('2018-02-14 07:59:59','2018-02-22 11:59:59','BTCUSDT','4h','8870.170000000000073','10259.870000000000800','15.047015954034912','17.404449697843919','0.0016963616203561952','0.001696361620356','test'),('2018-02-23 15:59:59','2018-02-23 19:59:59','BTCUSDT','4h','10292.000000000000000','10033.000000000000000','15.636374389987163','15.242882263383327','0.001519274620092029','0.001519274620092','test'),('2018-02-24 03:59:59','2018-02-24 07:59:59','BTCUSDT','4h','10400.000000000000000','10119.159999999999854','15.636374389987163','15.214132141556009','0.0015034975374987657','0.001503497537499','test'),('2018-02-26 15:59:59','2018-03-06 15:59:59','BTCUSDT','4h','10260.920000000000073','10966.000000000000000','15.636374389987163','16.710829200558940','0.0015238764545466841','0.001523876454547','test'),('2018-03-20 19:59:59','2018-03-22 11:59:59','BTCUSDT','4h','8950.000000000000000','8642.010000000000218','15.701054498871359','15.160745250256008','0.0017543077652370234','0.001754307765237','test'),('2018-03-23 23:59:59','2018-03-24 11:59:59','BTCUSDT','4h','8898.030000000000655','8723.000000000000000','15.701054498871359','15.392204610869468','0.0017645540078951587','0.001764554007895','test'),('2018-04-12 11:59:59','2018-05-01 03:59:59','BTCUSDT','4h','7690.000000000000000','8938.010000000000218','15.701054498871359','18.249178429318235','0.0020417496097361976','0.002041749609736','test'),('2018-05-01 19:59:59','2018-05-07 03:59:59','BTCUSDT','4h','8979.520000000000437','9350.020000000000437','16.125795697328769','16.791155015628668','0.0017958416148445317','0.001795841614845','test'),('2018-05-10 03:59:59','2018-05-10 07:59:59','BTCUSDT','4h','9344.889999999999418','9369.000000000000000','16.292135526903742','16.334169557005076','0.001743427212830086','0.001743427212830','test'),('2018-05-21 07:59:59','2018-05-21 11:59:59','BTCUSDT','4h','8540.000000000000000','8469.979999999999563','16.302644034429076','16.168977625144446','0.0019089747112914608','0.001908974711291','test'),('2018-06-02 11:59:59','2018-06-02 15:59:59','BTCUSDT','4h','7652.279999999999745','7623.100000000000364','16.302644034429076','16.240478097881454','0.002130429628088501','0.002130429628089','test'),('2018-06-05 23:59:59','2018-06-06 03:59:59','BTCUSDT','4h','7625.000000000000000','7595.000000000000000','16.302644034429076','16.238502484129683','0.002138051676646436','0.002138051676646','test'),('2018-06-06 23:59:59','2018-06-08 07:59:59','BTCUSDT','4h','7658.840000000000146','7627.880000000000109','16.302644034429076','16.236742428010096','0.002128604858494116','0.002128604858494','test'),('2018-06-08 19:59:59','2018-06-08 23:59:59','BTCUSDT','4h','7641.130000000000109','7603.439999999999600','16.302644034429076','16.222230973316695','0.002133538368595885','0.002133538368596','test'),('2018-06-09 03:59:59','2018-06-09 11:59:59','BTCUSDT','4h','7661.149999999999636','7635.010000000000218','16.302644034429076','16.247019080595777','0.002127963038764295','0.002127963038764','test'),('2018-06-21 03:59:59','2018-06-21 07:59:59','BTCUSDT','4h','6772.409999999999854','6758.720000000000255','16.302644034429076','16.269689266948763','0.002407214571242597','0.002407214571243','test'),('2018-06-30 03:59:59','2018-07-01 15:59:59','BTCUSDT','4h','6366.000000000000000','6316.579999999999927','16.302644034429076','16.176084708607291','0.002560892873771454','0.002560892873771','test'),('2018-07-16 11:59:59','2018-07-31 15:59:59','BTCUSDT','4h','6635.569999999999709','7758.439999999999600','16.302644034429076','19.061374619283033','0.00245685661283493','0.002456856612835','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','BTCUSDT','4h','6584.489999999999782','6524.989999999999782','16.836969777942965','16.684824402706976','0.0025570651300165946','0.002557065130017','test'),('2018-08-22 03:59:59','2018-08-22 15:59:59','BTCUSDT','4h','6726.010000000000218','6459.359999999999673','16.836969777942965','16.169474785921171','0.002503262673998844','0.002503262673999','test'),('2018-08-23 23:59:59','2018-08-24 03:59:59','BTCUSDT','4h','6525.010000000000218','6495.000000000000000','16.836969777942965','16.759532737534435','0.002580374555432553','0.002580374555433','test'),('2018-09-14 03:59:59','2018-09-14 11:59:59','BTCUSDT','4h','6542.369999999999891','6459.279999999999745','16.836969777942965','16.623135369487116','0.0025735276020682056','0.002573527602068','test'),('2018-09-15 11:59:59','2018-09-15 15:59:59','BTCUSDT','4h','6523.510000000000218','6542.220000000000255','16.836969777942965','16.885259686986611','0.0025809678804727767','0.002580967880473','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','BTCUSDT','4h','6517.159999999999854','6480.010000000000218','16.836969777942965','16.740993397548657','0.0025834826485682362','0.002583482648568','test'),('2018-09-20 23:59:59','2018-09-24 23:59:59','BTCUSDT','4h','6492.000000000000000','6581.390000000000327','16.836969777942965','17.068802299269265','0.0025934950366517198','0.002593495036652','test'),('2018-09-27 19:59:59','2018-09-28 19:59:59','BTCUSDT','4h','6669.359999999999673','6684.000000000000000','16.836969777942965','16.873928832117443','0.002524525558365865','0.002524525558366','test'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BTCUSDT','4h','6584.960000000000036','6589.010000000000218','16.836969777942965','16.847325152554301','0.0025568826200831844','0.002556882620083','test'),('2018-10-04 03:59:59','2018-10-04 23:59:59','BTCUSDT','4h','6598.510000000000218','6593.789999999999964','16.836969777942965','16.824926074538425','0.0025516320772330367','0.002551632077233','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','BTCUSDT','4h','6582.069999999999709','6584.000000000000000','16.836969777942965','16.841906728122989','0.0025580052746237833','0.002558005274624','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','BTCUSDT','4h','6635.960000000000036','6340.520000000000437','16.836969777942965','16.087369968541545','0.0025372319570857818','0.002537231957086','test'),('2018-10-15 07:59:59','2018-10-18 23:59:59','BTCUSDT','4h','6860.250000000000000','6618.960000000000036','16.836969777942965','16.244776718255657','0.002454279330628325','0.002454279330628','test'),('2018-10-21 03:59:59','2018-10-21 23:59:59','BTCUSDT','4h','6616.619999999999891','6590.109999999999673','16.836969777942965','16.769511155744127','0.0025446481402805307','0.002544648140281','test'),('2018-10-24 07:59:59','2018-10-24 15:59:59','BTCUSDT','4h','6610.939999999999600','6581.000000000000000','16.836969777942965','16.760717554333070','0.002546834455908383','0.002546834455908','test'),('2018-11-04 15:59:59','2018-11-05 11:59:59','BTCUSDT','4h','6479.989999999999782','6452.840000000000146','16.836969777942965','16.766425883666717','0.002598301814963135','0.002598301814963','test'),('2018-11-13 19:59:59','2018-11-13 23:59:59','BTCUSDT','4h','6461.300000000000182','6457.659999999999854','16.836969777942965','16.827484601586548','0.002605817680334138','0.002605817680334','test'),('2018-11-14 01:59:59','2018-11-14 11:59:59','BTCUSDT','4h','6472.000000000000000','6381.880000000000109','16.836969777942965','16.602521737709928','0.00260150954541764','0.002601509545418','test'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BTCUSDT','4h','3535.610000000000127','3490.849999999999909','16.836969777942965','16.623817657867296','0.0047621117085716366','0.004762111708572','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','BTCUSDT','4h','3795.230000000000018','3743.449999999999818','16.836969777942965','16.607255559015023','0.004436350307607962','0.004436350307608','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BTCUSDT','4h','3777.739999999999782','3711.590000000000146','16.836969777942965','16.542146536848840','0.004456889510115298','0.004456889510115','test'),('2018-12-28 19:59:59','2018-12-29 23:59:59','BTCUSDT','4h','3819.539999999999964','3695.320000000000164','16.836969777942965','16.289393790830360','0.0044081145315778775','0.004408114531578','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','BTCUSDT','4h','3785.929999999999836','3768.000000000000000','16.836969777942965','16.757230620557987','0.0044472480415493594','0.004447248041549','test'),('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','16.836969777942965','16.654550131402523','0.00443411877832868','0.004434118778329','test'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','16.836969777942965','16.743505305585114','0.0044401174516794425','0.004440117451679','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','16.836969777942965','16.311272942169900','0.0045562214922262294','0.004556221492226','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','16.836969777942965','16.694436503248316','0.0046503515397927865','0.004650351539793','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 21:27:28
