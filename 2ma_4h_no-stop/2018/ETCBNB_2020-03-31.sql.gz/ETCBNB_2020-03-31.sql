-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 23:59:59','2018-11-29 03:59:59','ETCBNB','4h','0.935300000000000','0.931200000000000','0.711908500000000','0.708787763498343','0.7611552443066396','0.761155244306640','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','ETCBNB','4h','0.933400000000000','0.905000000000000','0.711908500000000','0.690247688557960','0.76270462824084','0.762704628240840','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','ETCBNB','4h','0.940100000000000','0.924000000000000','0.711908500000000','0.699716470588235','0.7572689075630252','0.757268907563025','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','ETCBNB','4h','0.928800000000000','0.927100000000000','0.711908500000000','0.710605480566322','0.7664820198105082','0.766482019810508','test'),('2018-12-11 03:59:59','2018-12-11 15:59:59','ETCBNB','4h','0.839900000000000','0.821300000000000','0.711908500000000','0.696142934932730','0.8476110251220385','0.847611025122038','test'),('2018-12-13 23:59:59','2018-12-14 03:59:59','ETCBNB','4h','0.833300000000000','0.829400000000000','0.711908500000000','0.708576634945398','0.854324372974919','0.854324372974919','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','ETCBNB','4h','0.810000000000000','0.810400000000000','0.711908500000000','0.712260059753086','0.8788993827160494','0.878899382716049','test'),('2018-12-23 03:59:59','2018-12-23 07:59:59','ETCBNB','4h','0.834800000000000','0.806000000000000','0.711908500000000','0.687348168423575','0.8527892908481074','0.852789290848107','test'),('2018-12-23 23:59:59','2018-12-24 07:59:59','ETCBNB','4h','0.812300000000000','0.805800000000000','0.711908500000000','0.706211829742706','0.8764108088144774','0.876410808814477','test'),('2019-01-01 23:59:59','2019-01-03 15:59:59','ETCBNB','4h','0.873500000000000','0.866400000000000','0.711908500000000','0.706121951230681','0.8150068689181454','0.815006868918145','test'),('2019-01-04 07:59:59','2019-01-04 11:59:59','ETCBNB','4h','0.866500000000000','0.850900000000000','0.711908500000000','0.699091682227351','0.8215908828620889','0.821590882862089','test'),('2019-01-04 23:59:59','2019-01-05 03:59:59','ETCBNB','4h','0.873200000000000','0.863600000000000','0.711908500000000','0.704081745991755','0.8152868758589098','0.815286875858910','test'),('2019-02-19 07:59:59','2019-02-19 15:59:59','ETCBNB','4h','0.486300000000000','0.447500000000000','0.711908500000000','0.655108068579067','1.4639286448694222','1.463928644869422','test'),('2019-02-24 03:59:59','2019-02-24 11:59:59','ETCBNB','4h','0.453100000000000','0.447200000000000','0.711908500000000','0.702638448907526','1.5711951004193336','1.571195100419334','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','ETCBNB','4h','0.447500000000000','0.445200000000000','0.711908500000000','0.708249528938547','1.5908569832402235','1.590856983240224','test'),('2019-03-20 03:59:59','2019-03-20 11:59:59','ETCBNB','4h','0.300500000000000','0.299500000000000','0.711908500000000','0.709539420133112','2.3690798668885193','2.369079866888519','test'),('2019-03-29 19:59:59','2019-03-30 07:59:59','ETCBNB','4h','0.298900000000000','0.295100000000000','0.711908500000000','0.702857806457009','2.3817614586818334','2.381761458681833','test'),('2019-04-03 03:59:59','2019-04-03 23:59:59','ETCBNB','4h','0.299000000000000','0.290600000000000','0.711908500000000','0.691908394983278','2.380964882943144','2.380964882943144','test'),('2019-04-05 07:59:59','2019-04-13 03:59:59','ETCBNB','4h','0.301000000000000','0.349000000000000','0.711908500000000','0.825435436877076','2.3651445182724253','2.365144518272425','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','ETCBNB','4h','0.343900000000000','0.341000000000000','0.711908500000000','0.705905200639721','2.0701032276824662','2.070103227682466','test'),('2019-04-29 19:59:59','2019-04-29 23:59:59','ETCBNB','4h','0.261500000000000','0.257600000000000','0.711908500000000','0.701291126577438','2.7224034416826006','2.722403441682601','test'),('2019-04-30 03:59:59','2019-05-02 11:59:59','ETCBNB','4h','0.261600000000000','0.254100000000000','0.711908500000000','0.691498279243119','2.721362767584098','2.721362767584098','test'),('2019-05-07 03:59:59','2019-05-13 03:59:59','ETCBNB','4h','0.265400000000000','0.270200000000000','0.711908500000000','0.724784011680482','2.682398266767144','2.682398266767144','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','ETCBNB','4h','0.274400000000000','0.272900000000000','0.711908500000000','0.708016871902332','2.594418731778426','2.594418731778426','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','ETCBNB','4h','0.283000000000000','0.296400000000000','0.711908500000000','0.745617241696113','2.5155777385159013','2.515577738515901','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','ETCBNB','4h','0.244100000000000','0.242400000000000','0.711908500000000','0.706950513723884','2.9164625153625563','2.916462515362556','test'),('2019-06-08 03:59:59','2019-06-08 15:59:59','ETCBNB','4h','0.271700000000000','0.262700000000000','0.711908500000000','0.688326694700037','2.6202005888847997','2.620200588884800','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','ETCBNB','4h','0.265700000000000','0.265300000000000','0.711908500000000','0.710836752164095','2.679369589762891','2.679369589762891','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ETCBNB','4h','0.263800000000000','0.268000000000000','0.711908500000000','0.723242903714936','2.698667551175133','2.698667551175133','test'),('2019-06-15 15:59:59','2019-06-17 07:59:59','ETCBNB','4h','0.262600000000000','0.258700000000000','0.711908500000000','0.701335601485149','2.710999619192689','2.710999619192689','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','ETCBNB','4h','0.250400000000000','0.244400000000000','0.711908500000000','0.694849989616613','2.843085063897764','2.843085063897764','test'),('2019-06-23 19:59:59','2019-06-23 23:59:59','ETCBNB','4h','0.250100000000000','0.250100000000000','0.711908500000000','0.711908500000000','2.8464954018392645','2.846495401839265','test'),('2019-06-24 19:59:59','2019-06-26 11:59:59','ETCBNB','4h','0.249500000000000','0.253700000000000','0.711908500000000','0.723892530861723','2.8533406813627256','2.853340681362726','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','ETCBNB','4h','0.243600000000000','0.235500000000000','0.711908500000000','0.688236665640394','2.9224486863711','2.922448686371100','test'),('2019-07-02 19:59:59','2019-07-03 07:59:59','ETCBNB','4h','0.243700000000000','0.239000000000000','0.711908500000000','0.698178627410751','2.921249487074272','2.921249487074272','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','ETCBNB','4h','0.241100000000000','0.238400000000000','0.711908500000000','0.703936069680630','2.9527519701368727','2.952751970136873','test'),('2019-07-05 23:59:59','2019-07-06 03:59:59','ETCBNB','4h','0.240800000000000','0.241500000000000','0.711908500000000','0.713978001453488','2.956430647840532','2.956430647840532','test'),('2019-07-06 15:59:59','2019-07-06 19:59:59','ETCBNB','4h','0.240100000000000','0.237200000000000','0.711908500000000','0.703309855060391','2.9650499791753435','2.965049979175344','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','ETCBNB','4h','0.239600000000000','0.236200000000000','0.711908500000000','0.701806292570952','2.9712374791318865','2.971237479131887','test'),('2019-07-07 19:59:59','2019-07-07 23:59:59','ETCBNB','4h','0.240400000000000','0.241900000000000','0.711908500000000','0.716350524750416','2.961349833610649','2.961349833610649','test'),('2019-07-08 23:59:59','2019-07-09 03:59:59','ETCBNB','4h','0.240200000000000','0.241200000000000','0.711908500000000','0.714872315570358','2.9638155703580353','2.963815570358035','test'),('2019-07-09 19:59:59','2019-07-10 03:59:59','ETCBNB','4h','0.241800000000000','0.243300000000000','0.711908500000000','0.716324805831266','2.9442038875103393','2.944203887510339','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','ETCBNB','4h','0.212200000000000','0.208400000000000','0.711908500000000','0.699159902921772','3.35489396795476','3.354893967954760','test'),('2019-07-26 03:59:59','2019-07-28 23:59:59','ETCBNB','4h','0.209800000000000','0.212400000000000','0.711908500000000','0.720731007626311','3.393272163965682','3.393272163965682','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','ETCBNB','4h','0.214000000000000','0.214400000000000','0.711908500000000','0.713239170093458','3.32667523364486','3.326675233644860','test'),('2019-08-14 03:59:59','2019-08-15 15:59:59','ETCBNB','4h','0.208900000000000','0.202800000000000','0.711908500000000','0.691120362853040','3.4078913355672573','3.407891335567257','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','ETCBNB','4h','0.205100000000000','0.202700000000000','0.711908500000000','0.703578025109703','3.47103120429059','3.471031204290590','test'),('2019-08-18 19:59:59','2019-08-18 23:59:59','ETCBNB','4h','0.202100000000000','0.200000000000000','0.711908500000000','0.704511133102425','3.522555665512123','3.522555665512123','test'),('2019-08-20 07:59:59','2019-09-07 03:59:59','ETCBNB','4h','0.208200000000000','0.293600000000000','0.711908500000000','1.003920920268972','3.4193491834774257','3.419349183477426','test'),('2019-09-13 19:59:59','2019-09-13 23:59:59','ETCBNB','4h','0.298000000000000','0.296500000000000','0.730189228320931','0.726513779185087','2.450299423895742','2.450299423895742','test'),('2019-09-14 15:59:59','2019-09-14 23:59:59','ETCBNB','4h','0.298400000000000','0.298200000000000','0.730189228320931','0.729699825352888','2.447014840217597','2.447014840217597','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','ETCBNB','4h','0.297400000000000','0.294100000000000','0.730189228320931','0.722086926863436','2.4552428659076364','2.455242865907636','test'),('2019-09-23 03:59:59','2019-09-24 15:59:59','ETCBNB','4h','0.296300000000000','0.297800000000000','0.730189228320931','0.733885765082596','2.4643578411101283','2.464357841110128','test'),('2019-09-25 07:59:59','2019-09-25 11:59:59','ETCBNB','4h','0.301600000000000','0.294000000000000','0.730189228320931','0.711789234503825','2.4210518180402225','2.421051818040223','test'),('2019-09-25 15:59:59','2019-09-26 03:59:59','ETCBNB','4h','0.310100000000000','0.296800000000000','0.730189228320931','0.698871857354571','2.3546895463428927','2.354689546342893','test'),('2019-09-29 07:59:59','2019-09-29 11:59:59','ETCBNB','4h','0.299800000000000','0.299600000000000','0.730189228320931','0.729702110757008','2.4355878196161806','2.435587819616181','test'),('2019-09-30 07:59:59','2019-09-30 15:59:59','ETCBNB','4h','0.301900000000000','0.295100000000000','0.730189228320931','0.713742435500188','2.4186460030504504','2.418646003050450','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','ETCBNB','4h','0.299900000000000','0.297200000000000','0.730189228320931','0.723615333967925','2.4347756862985364','2.434775686298536','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','ETCBNB','4h','0.297200000000000','0.294400000000000','0.730189228320931','0.723309921997584','2.456895115480925','2.456895115480925','test'),('2019-10-05 15:59:59','2019-10-05 19:59:59','ETCBNB','4h','0.296800000000000','0.295600000000000','0.730189228320931','0.727236980767073','2.460206294881843','2.460206294881843','test'),('2019-10-06 07:59:59','2019-10-06 19:59:59','ETCBNB','4h','0.298200000000000','0.297700000000000','0.730189228320931','0.728964900305638','2.448656030586623','2.448656030586623','test'),('2019-10-23 23:59:59','2019-10-24 15:59:59','ETCBNB','4h','0.254600000000000','0.255300000000000','0.730189228320931','0.732196818500918','2.867985971409784','2.867985971409784','test'),('2019-10-25 19:59:59','2019-10-25 23:59:59','ETCBNB','4h','0.256000000000000','0.256400000000000','0.730189228320931','0.731330148990183','2.8523016731286366','2.852301673128637','test'),('2019-11-06 03:59:59','2019-11-06 11:59:59','ETCBNB','4h','0.245300000000000','0.243000000000000','0.730189228320931','0.723342774080661','2.976719234899841','2.976719234899841','test'),('2019-11-19 11:59:59','2019-11-19 15:59:59','ETCBNB','4h','0.236800000000000','0.235300000000000','0.730189228320931','0.725563874256398','3.0835693763552827','3.083569376355283','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:28:05
