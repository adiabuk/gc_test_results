-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-28 11:59:59','2018-07-28 15:59:59','BLZETH','4h','0.000669270000000','0.000638800000000','0.072144500000000','0.068859961749369','107.79580737221151','107.795807372211513','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','BLZETH','4h','0.000472300000000','0.000446370000000','0.072144500000000','0.068183655441457','152.75142917637095','152.751429176370948','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','BLZETH','4h','0.000429650000000','0.000439160000000','0.072144500000000','0.073741367671360','167.91458163621553','167.914581636215530','test'),('2018-08-30 23:59:59','2018-09-06 11:59:59','BLZETH','4h','0.000480110000000','0.000525970000000','0.072144500000000','0.079035726531420','150.266605569557','150.266605569556987','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','BLZETH','4h','0.000552930000000','0.000535590000000','0.072455177848401','0.070182968375427','131.0386085913253','131.038608591325300','test'),('2018-09-19 19:59:59','2018-09-20 19:59:59','BLZETH','4h','0.000537840000000','0.000532220000000','0.072455177848401','0.071698078897955','134.71511573776772','134.715115737767718','test'),('2018-09-21 03:59:59','2018-09-21 19:59:59','BLZETH','4h','0.000533930000000','0.000529050000000','0.072455177848401','0.071792953834204','135.7016422534808','135.701642253480799','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','BLZETH','4h','0.000532720000000','0.000524890000000','0.072455177848401','0.071390220567741','136.00986981604032','136.009869816040322','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','BLZETH','4h','0.000532400000000','0.000530340000000','0.072455177848401','0.072174829113676','136.0916187986495','136.091618798649506','test'),('2018-09-30 15:59:59','2018-10-11 07:59:59','BLZETH','4h','0.000546040000000','0.000573190000000','0.072455177848401','0.076057767546196','132.69206990037543','132.692069900375429','test'),('2018-10-12 15:59:59','2018-10-12 19:59:59','BLZETH','4h','0.000582170000000','0.000580720000000','0.072455177848401','0.072274715083435','124.45707928680797','124.457079286807968','test'),('2018-10-13 03:59:59','2018-10-13 11:59:59','BLZETH','4h','0.000592950000000','0.000586680000000','0.072455177848401','0.071689018871911','122.19441411316468','122.194414113164683','test'),('2018-10-15 15:59:59','2018-10-23 03:59:59','BLZETH','4h','0.000601800000000','0.000642380000000','0.072455177848401','0.077340905859515','120.39743743502991','120.397437435029914','test'),('2018-10-24 19:59:59','2018-10-25 03:59:59','BLZETH','4h','0.000633680000000','0.000624850000000','0.073081392227014','0.072063041177013','115.3285447339576','115.328544733957600','test'),('2018-10-26 15:59:59','2018-10-27 11:59:59','BLZETH','4h','0.000634500000000','0.000631390000000','0.073081392227014','0.072723183984577','115.17949917575099','115.179499175750991','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','BLZETH','4h','0.000639800000000','0.000638760000000','0.073081392227014','0.072962597841400','114.22537078307907','114.225370783079072','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BLZETH','4h','0.000510540000000','0.000509100000000','0.073081392227014','0.072875263021062','143.14528191133704','143.145281911337037','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','BLZETH','4h','0.000520280000000','0.000515720000000','0.073081392227014','0.072440869530475','140.4655036269201','140.465503626920110','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','BLZETH','4h','0.000523970000000','0.000511160000000','0.073081392227014','0.071294700938528','139.4762910605836','139.476291060583605','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','BLZETH','4h','0.000518200000000','0.000517990000000','0.073081392227014','0.073051776070380','141.02931730415668','141.029317304156677','test'),('2018-12-08 11:59:59','2018-12-08 19:59:59','BLZETH','4h','0.000545780000000','0.000506700000000','0.073081392227014','0.067848476385042','133.90265716408442','133.902657164084417','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','BLZETH','4h','0.000517040000000','0.000509270000000','0.073081392227014','0.071983135965209','141.34572224008588','141.345722240085877','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','BLZETH','4h','0.000310650000000','0.000310920000000','0.073081392227014','0.073144910578539','235.2531537969226','235.253153796922589','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BLZETH','4h','0.000315580000000','0.000309640000000','0.073081392227014','0.071705818775501','231.5780221402307','231.578022140230701','test'),('2019-01-15 15:59:59','2019-01-27 11:59:59','BLZETH','4h','0.000328390000000','0.000353070000000','0.073081392227014','0.078573790778013','222.54451179090105','222.544511790901055','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZETH','4h','0.000362750000000','0.000350780000000','0.073081392227014','0.070669857382197','201.46489931637214','201.464899316372140','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','BLZETH','4h','0.000360000000000','0.000354110000000','0.073081392227014','0.071885699448633','203.0038672972611','203.003867297261110','test'),('2019-02-01 19:59:59','2019-02-02 03:59:59','BLZETH','4h','0.000353990000000','0.000357390000000','0.073081392227014','0.073783323732344','206.45044274418487','206.450442744184869','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','BLZETH','4h','0.000355350000000','0.000350980000000','0.073081392227014','0.072182656659174','205.66031300693402','205.660313006934018','test'),('2019-02-16 15:59:59','2019-02-17 03:59:59','BLZETH','4h','0.000334800000000','0.000351890000000','0.073081392227014','0.076811861143262','218.28372827662486','218.283728276624856','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BLZETH','4h','0.000312820000000','0.000318980000000','0.073081392227014','0.074520498985272','233.62122699000702','233.621226990007017','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','BLZETH','4h','0.000410490000000','0.000399480000000','0.073081392227014','0.071121232105161','178.03452514559186','178.034525145591857','test'),('2019-03-22 07:59:59','2019-03-22 15:59:59','BLZETH','4h','0.000413020000000','0.000409950000000','0.073081392227014','0.072538174285663','176.94395483757202','176.943954837572022','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','BLZETH','4h','0.000413220000000','0.000464780000000','0.073081392227014','0.082200206861409','176.85831331255505','176.858313312555055','test'),('2019-04-03 23:59:59','2019-04-04 03:59:59','BLZETH','4h','0.000446020000000','0.000430610000000','0.073499351947404','0.070959947854517','164.78936358774104','164.789363587741036','test'),('2019-04-04 07:59:59','2019-04-08 07:59:59','BLZETH','4h','0.000454200000000','0.000481650000000','0.073499351947404','0.077941353732865','161.82155866887717','161.821558668877174','test'),('2019-05-15 23:59:59','2019-05-16 03:59:59','BLZETH','4h','0.000277670000000','0.000253330000000','0.073975001370548','0.067490499863871','266.41337332282114','266.413373322821144','test'),('2019-05-22 15:59:59','2019-05-23 03:59:59','BLZETH','4h','0.000259040000000','0.000253290000000','0.073975001370548','0.072332952814801','285.5736618690086','285.573661869008617','test'),('2019-06-03 07:59:59','2019-06-03 11:59:59','BLZETH','4h','0.000246610000000','0.000247470000000','0.073975001370548','0.074232973477027','299.96756567271393','299.967565672713931','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BLZETH','4h','0.000243000000000','0.000243740000000','0.073975001370548','0.074200275037273','304.4238739528724','304.423873952872384','test'),('2019-06-06 23:59:59','2019-06-12 03:59:59','BLZETH','4h','0.000245390000000','0.000259640000000','0.073975001370548','0.078270790805856','301.4589077409348','301.458907740934819','test'),('2019-06-13 15:59:59','2019-06-13 23:59:59','BLZETH','4h','0.000256870000000','0.000257960000000','0.073975001370548','0.074288906269890','287.9861461850274','287.986146185027394','test'),('2019-06-24 11:59:59','2019-06-24 15:59:59','BLZETH','4h','0.000236220000000','0.000250780000000','0.073975001370548','0.078534632307620','313.16146545825075','313.161465458250746','test'),('2019-07-18 07:59:59','2019-07-18 15:59:59','BLZETH','4h','0.000174850000000','0.000166960000000','0.074356506616173','0.071001214438869','425.2588310904962','425.258831090496187','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','BLZETH','4h','0.000171890000000','0.000171570000000','0.074356506616173','0.074218080401052','432.5819222536099','432.581922253609889','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','BLZETH','4h','0.000168730000000','0.000166310000000','0.074356506616173','0.073290052837881','440.68337945933155','440.683379459331547','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','BLZETH','4h','0.000169640000000','0.000166960000000','0.074356506616173','0.073181810567297','438.31942122242987','438.319421222429867','test'),('2019-07-23 23:59:59','2019-07-24 19:59:59','BLZETH','4h','0.000169580000000','0.000169640000000','0.074356506616173','0.074382815086494','438.47450534363134','438.474505343631336','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:12:06
