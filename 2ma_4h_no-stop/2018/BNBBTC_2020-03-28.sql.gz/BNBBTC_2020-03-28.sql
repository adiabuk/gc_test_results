-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-18 03:59:59','2018-01-18 07:59:59','BNBBTC','4h','0.001324000000000','0.001279500000000','0.001467500000000','0.001418176925982','1.1083836858006042','1.108383685800604','test'),('2018-01-20 19:59:59','2018-01-20 23:59:59','BNBBTC','4h','0.001278900000000','0.001266600000000','0.001467500000000','0.001453386113066','1.147470482445852','1.147470482445852','test'),('2018-02-07 11:59:59','2018-02-07 15:59:59','BNBBTC','4h','0.001086800000000','0.001072900000000','0.001467500000000','0.001448730907251','1.3502944423997056','1.350294442399706','test'),('2018-02-09 15:59:59','2018-02-10 19:59:59','BNBBTC','4h','0.001144200000000','0.001086100000000','0.001467500000000','0.001392983525607','1.2825554972906836','1.282555497290684','test'),('2018-02-11 15:59:59','2018-02-11 19:59:59','BNBBTC','4h','0.001097400000000','0.001072500000000','0.001467500000000','0.001434202433024','1.3372516858028067','1.337251685802807','test'),('2018-02-14 23:59:59','2018-02-15 19:59:59','BNBBTC','4h','0.001101000000000','0.001083500000000','0.001467500000000','0.001444174613987','1.3328792007266121','1.332879200726612','test'),('2018-02-16 11:59:59','2018-02-16 19:59:59','BNBBTC','4h','0.001082600000000','0.001080800000000','0.001467500000000','0.001465060040643','1.3555329761684833','1.355532976168483','test'),('2018-02-26 07:59:59','2018-02-26 11:59:59','BNBBTC','4h','0.000978300000000','0.000962900000000','0.001467500000000','0.001444399212920','1.5000511090667483','1.500051109066748','test'),('2018-02-27 07:59:59','2018-02-27 15:59:59','BNBBTC','4h','0.001012800000000','0.000988200000000','0.001467500000000','0.001431855746445','1.4489533965244867','1.448953396524487','test'),('2018-03-13 15:59:59','2018-03-19 15:59:59','BNBBTC','4h','0.001063000000000','0.001043300000000','0.001467500000000','0.001440303621825','1.380526810912512','1.380526810912512','test'),('2018-03-21 03:59:59','2018-03-21 07:59:59','BNBBTC','4h','0.001038700000000','0.001028700000000','0.001467500000000','0.001453371762780','1.4128237219601425','1.412823721960142','test'),('2018-04-14 03:59:59','2018-04-14 07:59:59','BNBBTC','4h','0.001711700000000','0.001690500000000','0.001467500000000','0.001449324501957','0.8573348133434597','0.857334813343460','test'),('2018-04-24 11:59:59','2018-04-25 03:59:59','BNBBTC','4h','0.001562500000000','0.001537000000000','0.001467500000000','0.001443550400000','0.9392','0.939200000000000','test'),('2018-04-26 07:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001613700000000','0.001587900000000','0.001467500000000','0.001444037460495','0.9094007560265229','0.909400756026523','test'),('2018-05-09 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001513800000000','0.001506700000000','0.001467500000000','0.001460617155503','0.9694147179283922','0.969414717928392','test'),('2018-05-11 23:59:59','2018-05-12 03:59:59','BNBBTC','4h','0.001547500000000','0.001499700000000','0.001467500000000','0.001422171082391','0.9483037156704361','0.948303715670436','test'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BNBBTC','4h','0.001524200000000','0.001508000000000','0.001467500000000','0.001451902637449','0.962800157459651','0.962800157459651','test'),('2018-05-17 15:59:59','2018-05-17 19:59:59','BNBBTC','4h','0.001509500000000','0.001546200000000','0.001467500000000','0.001503178867175','0.9721762172904935','0.972176217290494','test'),('2018-05-29 23:59:59','2018-05-30 03:59:59','BNBBTC','4h','0.001688800000000','0.001671100000000','0.001467500000000','0.001452119404311','0.8689602084320227','0.868960208432023','test'),('2018-05-30 11:59:59','2018-05-30 15:59:59','BNBBTC','4h','0.001686000000000','0.001678700000000','0.001467500000000','0.001461146055753','0.8704033214709371','0.870403321470937','test'),('2018-05-30 19:59:59','2018-06-20 15:59:59','BNBBTC','4h','0.001693700000000','0.002362600000000','0.001467500000000','0.002047065891244','0.8664462419554821','0.866446241955482','test'),('2018-06-28 23:59:59','2018-06-29 03:59:59','BNBBTC','4h','0.002419900000000','0.002416800000000','0.001503564589952','0.001501638456546','0.6213333567304433','0.621333356730443','test'),('2018-06-29 19:59:59','2018-06-29 23:59:59','BNBBTC','4h','0.002394300000000','0.002338500000000','0.001503564589952','0.001468523490625','0.6279766904531596','0.627976690453160','test'),('2018-07-27 07:59:59','2018-07-27 15:59:59','BNBBTC','4h','0.001709500000000','0.001684300000000','0.001503564589952','0.001481400315213','0.8795347118759871','0.879534711875987','test'),('2018-07-27 23:59:59','2018-07-28 03:59:59','BNBBTC','4h','0.001709400000000','0.001711700000000','0.001503564589952','0.001505587638131','0.8795861647080847','0.879586164708085','test'),('2018-07-31 15:59:59','2018-08-11 15:59:59','BNBBTC','4h','0.001775000000000','0.001899000000000','0.001503564589952','0.001608602341588','0.8470786422264788','0.847078642226479','test'),('2018-08-27 11:59:59','2018-08-28 19:59:59','BNBBTC','4h','0.001588900000000','0.001613800000000','0.001515546913038','0.001539297380742','0.9538340443311408','0.953834044331141','test'),('2018-08-29 19:59:59','2018-08-30 07:59:59','BNBBTC','4h','0.001570400000000','0.001559600000000','0.001521484529964','0.001511020932840','0.9688515855602075','0.968851585560207','test'),('2018-08-31 23:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001566600000000','0.001583100000000','0.001521484529964','0.001537509357453','0.971201666005362','0.971201666005362','test'),('2018-09-06 23:59:59','2018-09-07 07:59:59','BNBBTC','4h','0.001578800000000','0.001548900000000','0.001522874837555','0.001494033972567','0.9645774243444387','0.964577424344439','test'),('2018-09-07 23:59:59','2018-09-08 03:59:59','BNBBTC','4h','0.001556600000000','0.001554600000000','0.001522874837555','0.001520918169384','0.9783340855422074','0.978334085542207','test'),('2018-09-14 19:59:59','2018-09-16 07:59:59','BNBBTC','4h','0.001535400000000','0.001527000000000','0.001522874837555','0.001514543361304','0.9918424108082585','0.991842410808259','test'),('2018-09-19 03:59:59','2018-09-19 07:59:59','BNBBTC','4h','0.001522400000000','0.001519300000000','0.001522874837555','0.001519773870663','1.0003119006535734','1.000311900653573','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','BNBBTC','4h','0.001517400000000','0.001546200000000','0.001522874837555','0.001551778749063','1.0036080384572295','1.003608038457229','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','BNBBTC','4h','0.001531900000000','0.001523400000000','0.001522874837555','0.001514424915158','0.9941085172367647','0.994108517236765','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BNBBTC','4h','0.001525400000000','0.001526100000000','0.001522874837555','0.001523573678768','0.9983445899796773','0.998344589979677','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','BNBBTC','4h','0.001514400000000','0.001518400000000','0.001522874837555','0.001526897222229','1.005596168485869','1.005596168485869','test'),('2018-10-02 15:59:59','2018-10-02 19:59:59','BNBBTC','4h','0.001512000000000','0.001527500000000','0.001522874837555','0.001538486319025','1.0071923528802909','1.007192352880291','test'),('2018-10-10 07:59:59','2018-10-10 19:59:59','BNBBTC','4h','0.001572000000000','0.001566300000000','0.001522874837555','0.001517352963144','0.968749896663486','0.968749896663486','test'),('2018-10-15 23:59:59','2018-10-16 07:59:59','BNBBTC','4h','0.001563900000000','0.001528100000000','0.001522874837555','0.001488013964619','0.9737674004444018','0.973767400444402','test'),('2018-11-01 23:59:59','2018-11-02 03:59:59','BNBBTC','4h','0.001499400000000','0.001507100000000','0.001522874837555','0.001530695389942','1.0156561541649993','1.015656154164999','test'),('2018-11-02 23:59:59','2018-11-03 03:59:59','BNBBTC','4h','0.001501600000000','0.001494800000000','0.001522874837555','0.001515978494391','1.0141681123834576','1.014168112383458','test'),('2018-11-03 23:59:59','2018-11-04 03:59:59','BNBBTC','4h','0.001501900000000','0.001497600000000','0.001522874837555','0.001518514785753','1.0139655353585457','1.013965535358546','test'),('2018-11-08 15:59:59','2018-11-08 19:59:59','BNBBTC','4h','0.001507000000000','0.001500800000000','0.001522874837555','0.001516609526345','1.010534066061712','1.010534066061712','test'),('2018-12-03 15:59:59','2018-12-06 19:59:59','BNBBTC','4h','0.001294800000000','0.001389200000000','0.001522874837555','0.001633903092625','1.1761467698138708','1.176146769813871','test'),('2018-12-11 15:59:59','2018-12-11 19:59:59','BNBBTC','4h','0.001362400000000','0.001393000000000','0.001537750106080','0.001572288533301','1.1287067719318848','1.128706771931885','test'),('2018-12-21 23:59:59','2018-12-22 03:59:59','BNBBTC','4h','0.001427600000000','0.001428100000000','0.001546384712885','0.001546926315825','1.0832058790174066','1.083205879017407','test'),('2018-12-28 07:59:59','2019-01-02 19:59:59','BNBBTC','4h','0.001462400000000','0.001559500000000','0.001546520113620','0.001649205495891','1.0575219595324465','1.057521959532447','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:46:19
