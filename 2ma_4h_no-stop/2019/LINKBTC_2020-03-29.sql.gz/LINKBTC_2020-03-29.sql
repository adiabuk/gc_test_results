-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-26 07:59:59','2019-01-26 11:59:59','LINKBTC','4h','0.000134290000000','0.000133370000000','0.001467500000000','0.001457446384690','10.927842728423562','10.927842728423562','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.001467500000000','0.001467500000000','11.106486036479225','11.106486036479225','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.001467500000000','0.001450130281111','12.062304783823771','12.062304783823771','test'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.001467500000000','0.001457861247947','12.048440065681445','12.048440065681445','test'),('2019-02-09 11:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000121430000000','0.000122400000000','0.001467500000000','0.001479222597381','12.085151939388949','12.085151939388949','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000119920000000','0.001467500000000','0.001436592653061','11.979591836734695','11.979591836734695','test'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.001467500000000','0.001464825629556','12.156229290921141','12.156229290921141','test'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121060000000','0.001467500000000','0.001436645236940','11.867216561539706','11.867216561539706','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LINKBTC','4h','0.000121500000000','0.000117220000000','0.001467500000000','0.001415805349794','12.078189300411523','12.078189300411523','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000116640000000','0.001467500000000','0.001425222314738','12.218984179850125','12.218984179850125','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.001467500000000','0.001568499911079','13.049084118797795','13.049084118797795','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','LINKBTC','4h','0.000121190000000','0.000119350000000','0.001467500000000','0.001445219283769','12.10908490799571','12.109084907995710','test'),('2019-03-25 23:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000120260000000','0.000115800000000','0.001467500000000','0.001413075835689','12.202727423914851','12.202727423914851','test'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.001467500000000','0.001479425844409','12.422754592398206','12.422754592398206','test'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.001467500000000','0.001480023018190','16.47765551313721','16.477655513137211','test'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.001467500000000','0.001457703383118','16.604435392622765','16.604435392622765','test'),('2019-05-06 03:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000089280000000','0.000095480000000','0.001467500000000','0.001569409722222','16.437051971326166','16.437051971326166','test'),('2019-05-14 15:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000107050000000','0.000142980000000','0.001467500000000','0.001960048108361','13.708547407753386','13.708547407753386','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKBTC','4h','0.000142750000000','0.000137430000000','0.001579914200514','0.001521034035563','11.067700178730297','11.067700178730297','test'),('2019-05-28 07:59:59','2019-05-28 11:59:59','LINKBTC','4h','0.000137920000000','0.000142490000000','0.001579914200514','0.001632264895818','11.455294377276681','11.455294377276681','test'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.001579914200514','0.001697543575115','12.434394778167794','12.434394778167794','test'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000168300000000','0.001607689176752','0.001509478875578','8.96897727616318','8.968977276163180','test'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.001607689176752','0.002506877027091','8.735067518348275','8.735067518348275','test'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000269670000000','0.001807933564043','0.001715561575761','6.3617071819680495','6.361707181968050','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','LINKBTC','4h','0.000274630000000','0.000268510000000','0.001807933564043','0.001767644617417','6.5831612134253366','6.583161213425337','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000261840000000','0.001807933564043','0.001713688547672','6.544792803515059','6.544792803515059','test'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.001807933564043','0.001802607257911','7.719284249361684','7.719284249361684','test'),('2019-08-04 11:59:59','2019-08-04 15:59:59','LINKBTC','4h','0.000230940000000','0.000229690000000','0.001807933564043','0.001798147832013','7.82858562415779','7.828585624157790','test'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229380000000','0.001807933564043','0.001789135859701','7.799877320173433','7.799877320173433','test'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000210030000000','0.001807933564043','0.001777051134668','8.460939554675216','8.460939554675216','test'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.001807933564043','0.001910032626478','8.479988574310507','8.479988574310507','test'),('2019-09-18 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000170760000000','0.000297510000000','0.001807933564043','0.003149908143818','10.587570649115719','10.587570649115719','test'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.002096027443806','0.002090523651831','7.056143557672108','7.056143557672108','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','LINKBTC','4h','0.000295540000000','0.000294470000000','0.002096027443806','0.002088438794673','7.0921954517358055','7.092195451735805','test'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.002096027443806','0.002109715844194','7.092435433986397','7.092435433986397','test'),('2019-11-08 03:59:59','2019-11-08 07:59:59','LINKBTC','4h','0.000294010000000','0.000294670000000','0.002096176433626','0.002100881975771','7.129609311338049','7.129609311338049','test'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000328490000000','0.002097352819163','0.002067271064203','6.293254175781647','6.293254175781647','test'),('2019-11-19 23:59:59','2019-11-20 19:59:59','LINKBTC','4h','0.000335370000000','0.000326670000000','0.002097352819163','0.002042944346352','6.253847449572114','6.253847449572114','test'),('2019-11-20 23:59:59','2019-11-21 03:59:59','LINKBTC','4h','0.000333450000000','0.000330130000000','0.002097352819163','0.002076470493898','6.289857007536361','6.289857007536361','test'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334850000000','0.002097352819163','0.002076270780478','6.200599613194382','6.200599613194382','test'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.002097352819163','0.002094286605357','6.257579196118388','6.257579196118388','test'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000288270000000','0.002097352819163','0.002055287409254','7.129730493126423','7.129730493126423','test'),('2019-12-12 19:59:59','2019-12-13 03:59:59','LINKBTC','4h','0.000292770000000','0.000291850000000','0.002097352819163','0.002090762100873','7.163824227765823','7.163824227765823','test'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.002097352819163','0.002081260598044','7.152098275065643','7.152098275065643','test'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000287630000000','0.002097352819163','0.002071426677801','7.201705934014352','7.201705934014352','test'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000261920000000','0.002097352819163','0.002064484386468','7.88211815236574','7.882118152365740','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:17:36
