-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 07:59:59','2019-01-30 15:59:59','BNBETH','4h','0.042864000000000','0.056441000000000','0.072144500000000','0.094995980881392','1.6831023702874208','1.683102370287421','test'),('2019-01-31 15:59:59','2019-02-13 23:59:59','BNBETH','4h','0.057396000000000','0.073157000000000','0.077857370220348','0.099237083302146','1.3564947073027387','1.356494707302739','test'),('2019-02-14 23:59:59','2019-02-17 03:59:59','BNBETH','4h','0.072699000000000','0.072892000000000','0.083202298490797','0.083423182459060','1.1444765194954194','1.144476519495419','test'),('2019-02-19 19:59:59','2019-02-21 07:59:59','BNBETH','4h','0.074288000000000','0.070161000000000','0.083257519482863','0.078632226260461','1.1207398164288074','1.120739816428807','test'),('2019-02-21 15:59:59','2019-02-21 19:59:59','BNBETH','4h','0.072631000000000','0.071411000000000','0.083257519482863','0.081859023334261','1.146308318526015','1.146308318526015','test'),('2019-02-22 03:59:59','2019-02-22 19:59:59','BNBETH','4h','0.072188000000000','0.072177000000000','0.083257519482863','0.083244832710625','1.15334293072066','1.153342930720660','test'),('2019-02-24 23:59:59','2019-02-25 15:59:59','BNBETH','4h','0.075142000000000','0.071733000000000','0.083257519482863','0.079480339158716','1.1080024418150036','1.108002441815004','test'),('2019-02-27 15:59:59','2019-03-16 07:59:59','BNBETH','4h','0.071800000000000','0.108480000000000','0.083257519482863','0.125790748098899','1.1595754802627158','1.159575480262716','test'),('2019-03-22 11:59:59','2019-03-24 03:59:59','BNBETH','4h','0.109640000000000','0.107750000000000','0.091437412520025','0.089861192986435','0.8339785892012495','0.833978589201249','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','BNBETH','4h','0.109428000000000','0.124743000000000','0.091437412520025','0.104234539148897','0.8355942950618216','0.835594295061822','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','BNBETH','4h','0.116674000000000','0.117111000000000','0.094242639293845','0.094595623106617','0.8077432786554459','0.807743278655446','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','BNBETH','4h','0.119503000000000','0.119179000000000','0.094330885247038','0.094075132614719','0.7893599762938043','0.789359976293804','test'),('2019-04-04 19:59:59','2019-04-05 07:59:59','BNBETH','4h','0.122672000000000','0.116617000000000','0.094330885247038','0.089674781896878','0.7689683484987446','0.768968348498745','test'),('2019-04-12 19:59:59','2019-04-13 03:59:59','BNBETH','4h','0.111895000000000','0.110279000000000','0.094330885247038','0.092968548140293','0.843030387837151','0.843030387837151','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BNBETH','4h','0.138448000000000','0.139236000000000','0.094330885247038','0.094867785293082','0.6813452360961373','0.681345236096137','test'),('2019-05-02 11:59:59','2019-05-03 11:59:59','BNBETH','4h','0.141443000000000','0.140481000000000','0.094330885247038','0.093689310113538','0.6669180181913421','0.666918018191342','test'),('2019-05-18 19:59:59','2019-05-19 03:59:59','BNBETH','4h','0.116093000000000','0.114000000000000','0.094330885247038','0.092630226785098','0.8125458489920839','0.812545848992084','test'),('2019-05-20 15:59:59','2019-05-20 23:59:59','BNBETH','4h','0.115190000000000','0.116999000000000','0.094330885247038','0.095812303524770','0.818915576413213','0.818915576413213','test'),('2019-05-21 15:59:59','2019-05-26 23:59:59','BNBETH','4h','0.124170000000000','0.125118000000000','0.094330885247038','0.095051072725609','0.7596914330920351','0.759691433092035','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','BNBETH','4h','0.126168000000000','0.124682000000000','0.094330885247038','0.093219861092917','0.7476609381700431','0.747660938170043','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','BNBETH','4h','0.124978000000000','0.125969000000000','0.094330885247038','0.095078872150972','0.7547799232427947','0.754779923242795','test'),('2019-06-02 19:59:59','2019-06-02 23:59:59','BNBETH','4h','0.124190000000000','0.123128000000000','0.094330885247038','0.093524222873801','0.7595690896774137','0.759569089677414','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','BNBETH','4h','0.124561000000000','0.123617000000000','0.094330885247038','0.093615987681402','0.7573067432586283','0.757306743258628','test'),('2019-06-05 15:59:59','2019-06-05 19:59:59','BNBETH','4h','0.124462000000000','0.123341000000000','0.094330885247038','0.093481269120333','0.7579091228410118','0.757909122841012','test'),('2019-06-18 03:59:59','2019-06-21 03:59:59','BNBETH','4h','0.128230000000000','0.130000000000000','0.094330885247038','0.095632964845317','0.7356381911178195','0.735638191117819','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','BNBETH','4h','0.116810000000000','0.115648000000000','0.094330885247038','0.093392502500209','0.8075583019179694','0.807558301917969','test'),('2019-07-12 03:59:59','2019-07-25 03:59:59','BNBETH','4h','0.114090000000000','0.132219000000000','0.094330885247038','0.109320144767097','0.8268111600231222','0.826811160023122','test'),('2019-08-01 11:59:59','2019-08-02 03:59:59','BNBETH','4h','0.131630000000000','0.130976000000000','0.096016090790395','0.095539037509403','0.729439267571186','0.729439267571186','test'),('2019-08-07 19:59:59','2019-08-18 15:59:59','BNBETH','4h','0.133648000000000','0.144352000000000','0.096016090790395','0.103706114104028','0.7184251974619523','0.718425197461952','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','BNBETH','4h','0.143154000000000','0.142557000000000','0.097819333298555','0.097411394002557','0.683315403681039','0.683315403681039','test'),('2019-09-05 19:59:59','2019-09-06 03:59:59','BNBETH','4h','0.133079000000000','0.128751000000000','0.097819333298555','0.094638049440725','0.7350471020863922','0.735047102086392','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','BNBETH','4h','0.130289000000000','0.130426000000000','0.097819333298555','0.097922191165773','0.7507873519526207','0.750787351952621','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','BNBETH','4h','0.093589000000000','0.090726000000000','0.097819333298555','0.094826922318271','1.0452011806788724','1.045201180678872','test'),('2019-10-11 11:59:59','2019-10-11 15:59:59','BNBETH','4h','0.091645000000000','0.091498000000000','0.097819333298555','0.097662429572275','1.0673722876158545','1.067372287615854','test'),('2019-10-26 03:59:59','2019-10-26 07:59:59','BNBETH','4h','0.103708000000000','0.102166000000000','0.097819333298555','0.096364889938868','0.9432187806008697','0.943218780600870','test'),('2019-10-26 23:59:59','2019-10-27 11:59:59','BNBETH','4h','0.105444000000000','0.104917000000000','0.097819333298555','0.097330440723839','0.9276898950964967','0.927689895096497','test'),('2019-11-07 19:59:59','2019-11-07 23:59:59','BNBETH','4h','0.109167000000000','0.109399000000000','0.097819333298555','0.098027217414865','0.8960522254761512','0.896052225476151','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','BNBETH','4h','0.108600000000000','0.109105000000000','0.097819333298555','0.098274202205698','0.9007305091947974','0.900730509194797','test'),('2019-11-24 07:59:59','2019-11-24 11:59:59','BNBETH','4h','0.107656000000000','0.106797000000000','0.097819333298555','0.097038821229525','0.9086287183116128','0.908628718311613','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','BNBETH','4h','0.107259000000000','0.106366000000000','0.097819333298555','0.097004924581006','0.9119918449599101','0.911991844959910','test'),('2019-12-04 11:59:59','2019-12-04 15:59:59','BNBETH','4h','0.104297000000000','0.104092000000000','0.097819333298555','0.097627065416198','0.937892109059273','0.937892109059273','test'),('2019-12-05 03:59:59','2019-12-06 11:59:59','BNBETH','4h','0.105446000000000','0.104906000000000','0.097819333298555','0.097318390256797','0.9276722995519507','0.927672299551951','test'),('2019-12-18 11:59:59','2019-12-18 19:59:59','BNBETH','4h','0.103794000000000','0.102347000000000','0.097819333298555','0.096455626578677','0.9424372632190203','0.942437263219020','test'),('2019-12-31 11:59:59','2020-01-01 11:59:59','BNBETH','4h','0.105380000000000','0.104850000000000','0.097819333298555','0.097327359046816','0.9282533051675365','0.928253305167536','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 22:36:53
