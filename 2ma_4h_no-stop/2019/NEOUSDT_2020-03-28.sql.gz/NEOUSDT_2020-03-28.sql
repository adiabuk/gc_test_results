-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 03:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.579000000000000','8.327999999999999','15.000000000000000','16.482385538989309','1.979152922549149','1.979152922549149','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.522000000000000','15.370596384747326','14.635142532413846','1.9456451119933325','1.945645111993332','test'),('2019-01-24 23:59:59','2019-01-25 07:59:59','NEOUSDT','4h','7.642000000000000','7.579000000000000','15.370596384747326','15.243882491494370','2.0113316389357925','2.011331638935792','test'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','15.370596384747326','15.119977292112230','2.123890615551655','2.123890615551655','test'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','15.370596384747326','19.511306081272405','2.0734650458312864','2.073465045831286','test'),('2019-03-01 07:59:59','2019-03-01 11:59:59','NEOUSDT','4h','8.869999999999999','8.851000000000001','16.127577099323215','16.093030992797047','1.8182161329563942','1.818216132956394','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.971000000000000','8.746000000000000','16.127577099323215','15.723084306173318','1.7977457473328742','1.797745747332874','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','16.127577099323215','16.099942457275027','1.84230946987928','1.842309469879280','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','16.127577099323215','16.040810143775115','1.8461054371935914','1.846105437193591','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','NEOUSDT','4h','8.705000000000000','8.763999999999999','16.127577099323215','16.236885203729884','1.8526797357062854','1.852679735706285','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','NEOUSDT','4h','8.821000000000000','8.622000000000000','16.127577099323215','15.763742177798976','1.8283161885640193','1.828316188564019','test'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','16.127577099323215','16.166107147000780','1.834764175122095','1.834764175122095','test'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','16.127577099323215','16.060164501174029','1.774015740768146','1.774015740768146','test'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','16.127577099323215','16.108173911300405','1.7639261838918532','1.763926183891853','test'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','16.127577099323215','16.058640721980645','1.767599419040247','1.767599419040247','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','8.932000000000000','16.127577099323215','15.542891524725395','1.7401356386839895','1.740135638683989','test'),('2019-03-27 07:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.125999999999999','12.166000000000000','16.127577099323215','21.499901708346069','1.7672120424417286','1.767212042441729','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.853000000000000','17.093189500372741','16.738143127327831','1.6987864738990999','1.698786473899100','test'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','17.093189500372741','16.977141488589062','1.7065884085835406','1.706588408583541','test'),('2019-05-11 11:59:59','2019-05-12 11:59:59','NEOUSDT','4h','9.516000000000000','9.371000000000000','17.093189500372741','16.832732115173702','1.7962578289588842','1.796257828958884','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','NEOUSDT','4h','9.401000000000000','9.323000000000000','17.093189500372741','16.951367483456554','1.8182309861049613','1.818230986104961','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','NEOUSDT','4h','11.292000000000000','11.202999999999999','17.093189500372741','16.958466345437106','1.513743313883523','1.513743313883523','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NEOUSDT','4h','12.329000000000001','11.983000000000001','17.093189500372741','16.613487694295284','1.3864214048481418','1.386421404848142','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','NEOUSDT','4h','12.257999999999999','12.272000000000000','17.093189500372741','17.112711824814351','1.3944517458290702','1.394451745829070','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','NEOUSDT','4h','12.268000000000001','12.300000000000001','17.093189500372741','17.137775583190798','1.3933150880642924','1.393315088064292','test'),('2019-07-01 03:59:59','2019-07-01 07:59:59','NEOUSDT','4h','17.222999999999999','16.763999999999999','17.093189500372741','16.637649003323965','0.9924629565332835','0.992462956533284','test'),('2019-07-02 15:59:59','2019-07-04 23:59:59','NEOUSDT','4h','17.689000000000000','17.010999999999999','17.093189500372741','16.438026264392597','0.9663174571978485','0.966317457197848','test'),('2019-07-05 11:59:59','2019-07-05 15:59:59','NEOUSDT','4h','17.335999999999999','17.050999999999998','17.093189500372741','16.812181251203022','0.9859938567358527','0.985993856735853','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','NEOUSDT','4h','17.295999999999999','17.085999999999999','17.093189500372741','16.885651931277096','0.9882741385506905','0.988274138550690','test'),('2019-07-06 15:59:59','2019-07-06 19:59:59','NEOUSDT','4h','17.225000000000001','17.045000000000002','17.093189500372741','16.914566910528499','0.992347721356908','0.992347721356908','test'),('2019-07-07 23:59:59','2019-07-08 03:59:59','NEOUSDT','4h','17.187999999999999','16.998000000000001','17.093189500372741','16.904237556861524','0.9944839132169387','0.994483913216939','test'),('2019-07-08 11:59:59','2019-07-09 11:59:59','NEOUSDT','4h','17.427000000000000','17.366000000000000','17.093189500372741','17.033357942472772','0.9808452114748805','0.980845211474880','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','NEOUSDT','4h','13.582000000000001','13.321999999999999','17.093189500372741','16.765974858192138','1.2585178545407703','1.258517854540770','test'),('2019-08-02 07:59:59','2019-08-02 11:59:59','NEOUSDT','4h','11.919000000000000','11.699999999999999','17.093189500372741','16.779118814863750','1.434112719219124','1.434112719219124','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','NEOUSDT','4h','11.884000000000000','11.570000000000000','17.093189500372741','16.641551878097662','1.4383363766722266','1.438336376672227','test'),('2019-08-03 03:59:59','2019-08-03 15:59:59','NEOUSDT','4h','11.928000000000001','11.836000000000000','17.093189500372741','16.961350681288714','1.4330306422177013','1.433030642217701','test'),('2019-08-24 23:59:59','2019-08-25 03:59:59','NEOUSDT','4h','10.102000000000000','9.999000000000001','17.093189500372741','16.918907326690462','1.6920599386629123','1.692059938662912','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','NEOUSDT','4h','10.000999999999999','9.804000000000000','17.093189500372741','16.756487337431693','1.709148035233751','1.709148035233751','test'),('2019-09-03 15:59:59','2019-09-03 19:59:59','NEOUSDT','4h','9.340000000000000','9.282999999999999','17.093189500372741','16.988873461665968','1.8301059422240622','1.830105942224062','test'),('2019-09-06 11:59:59','2019-09-06 15:59:59','NEOUSDT','4h','9.206000000000000','9.127000000000001','17.093189500372741','16.946506688018903','1.856744460175184','1.856744460175184','test'),('2019-09-08 03:59:59','2019-09-08 11:59:59','NEOUSDT','4h','9.236000000000001','9.164000000000000','17.093189500372741','16.959938131378927','1.8507134582473732','1.850713458247373','test'),('2019-09-10 03:59:59','2019-09-10 07:59:59','NEOUSDT','4h','9.154999999999999','9.085000000000001','17.093189500372741','16.962493349086440','1.8670878755185956','1.867087875518596','test'),('2019-09-14 15:59:59','2019-09-16 15:59:59','NEOUSDT','4h','9.050000000000001','8.903000000000000','17.093189500372741','16.815543217880499','1.888750221035662','1.888750221035662','test'),('2019-09-16 23:59:59','2019-09-22 03:59:59','NEOUSDT','4h','9.082000000000001','9.090000000000000','17.093189500372741','17.108246262760208','1.8820952984334662','1.882095298433466','test'),('2019-10-09 07:59:59','2019-10-10 11:59:59','NEOUSDT','4h','7.609000000000000','7.514000000000000','17.093189500372741','16.879777356525270','2.246443619447068','2.246443619447068','test'),('2019-10-14 23:59:59','2019-10-15 11:59:59','NEOUSDT','4h','7.529000000000000','7.499000000000000','17.093189500372741','17.025080098724288','2.2703133882816764','2.270313388281676','test'),('2019-10-20 19:59:59','2019-10-21 03:59:59','NEOUSDT','4h','7.298000000000000','7.300000000000000','17.093189500372741','17.097873849372569','2.3421744999140506','2.342174499914051','test'),('2019-10-25 15:59:59','2019-11-08 15:59:59','NEOUSDT','4h','7.474000000000000','10.574999999999999','17.093189500372741','24.185239358635499','2.287020270320142','2.287020270320142','test'),('2019-11-09 23:59:59','2019-11-10 03:59:59','NEOUSDT','4h','10.680000000000000','10.609999999999999','17.306085670723284','17.192656270259739','1.6204200066220305','1.620420006622030','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','NEOUSDT','4h','11.815000000000000','11.785000000000000','17.306085670723284','17.262143007149717','1.464755452452246','1.464755452452246','test'),('2019-12-13 15:59:59','2019-12-13 23:59:59','NEOUSDT','4h','9.034000000000001','8.894000000000000','17.306085670723284','17.037893065686614','1.9156614645476293','1.915661464547629','test'),('2019-12-15 19:59:59','2019-12-16 03:59:59','NEOUSDT','4h','8.952000000000000','8.789999999999999','17.306085670723284','16.992905836199469','1.9332088550852642','1.933208855085264','test'),('2019-12-20 19:59:59','2019-12-20 23:59:59','NEOUSDT','4h','8.638999999999999','8.601000000000001','17.306085670723284','17.229962131484083','2.003251032610636','2.003251032610636','test'),('2019-12-22 07:59:59','2019-12-23 19:59:59','NEOUSDT','4h','8.699000000000000','8.686000000000000','17.306085670723284','17.280223029762325','1.9894339200739493','1.989433920073949','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','NEOUSDT','4h','8.726000000000001','8.648999999999999','17.306085670723284','17.153373248462717','1.9832782111761726','1.983278211176173','test'),('2019-12-26 19:59:59','2019-12-26 23:59:59','NEOUSDT','4h','8.725000000000000','8.525000000000000','17.306085670723284','16.909384566523325','1.9835055209998034','1.983505520999803','test'),('2019-12-27 19:59:59','2019-12-31 15:59:59','NEOUSDT','4h','8.736000000000001','8.776999999999999','17.306085670723284','17.387306997703554','1.981007975128581','1.981007975128581','test'),('2020-01-01 15:59:59','2020-01-01 15:59:59','NEOUSDT','4h','8.964000000000000','8.964000000000000','17.306085670723284','17.306085670723284','1.930620891423838','1.930620891423838','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:39:26
