-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-15 03:59:59','BRDETH','4h','0.001493300000000','0.001506600000000','0.072144500000000','0.072787051295788','48.312127502846046','48.312127502846046','test'),('2019-02-01 15:59:59','2019-02-01 23:59:59','BRDETH','4h','0.001800000000000','0.001773800000000','0.072305137823947','0.071252696373398','40.16952101330389','40.169521013303893','test'),('2019-02-06 03:59:59','2019-02-06 07:59:59','BRDETH','4h','0.001797000000000','0.001762300000000','0.072305137823947','0.070908928429127','40.23658198327602','40.236581983276018','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','BRDETH','4h','0.001782500000000','0.001777700000000','0.072305137823947','0.072110431141448','40.56389218734755','40.563892187347548','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','BRDETH','4h','0.001560700000000','0.001548100000000','0.072305137823947','0.071721396722786','46.328658822289356','46.328658822289356','test'),('2019-02-26 15:59:59','2019-02-27 11:59:59','BRDETH','4h','0.001550300000000','0.001538300000000','0.072305137823947','0.071745464435643','46.63944902531575','46.639449025315749','test'),('2019-03-07 23:59:59','2019-03-08 15:59:59','BRDETH','4h','0.001637000000000','0.001633500000000','0.072305137823947','0.072150545287366','44.16929616612523','44.169296166125228','test'),('2019-03-20 15:59:59','2019-03-21 11:59:59','BRDETH','4h','0.001828200000000','0.001841600000000','0.072305137823947','0.072835106561963','39.54990582209113','39.549905822091127','test'),('2019-03-25 15:59:59','2019-03-30 07:59:59','BRDETH','4h','0.001963400000000','0.001960200000000','0.072305137823947','0.072187293043955','36.826493747553734','36.826493747553734','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BRDETH','4h','0.002041400000000','0.001994700000000','0.072305137823947','0.070651052423546','35.41938758888361','35.419387588883609','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDETH','4h','0.002100300000000','0.001908100000000','0.072305137823947','0.065688441404501','34.42609999711804','34.426099997118037','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','BRDETH','4h','0.001894900000000','0.001869900000000','0.072305137823947','0.071351193845057','38.157759155600296','38.157759155600296','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','BRDETH','4h','0.001942700000000','0.001891500000000','0.072305137823947','0.070399530650124','37.21889011373192','37.218890113731923','test'),('2019-04-21 15:59:59','2019-04-21 23:59:59','BRDETH','4h','0.001885400000000','0.001882500000000','0.072305137823947','0.072193922750387','38.35002536541158','38.350025365411582','test'),('2019-04-22 15:59:59','2019-04-22 19:59:59','BRDETH','4h','0.001915400000000','0.001873300000000','0.072305137823947','0.070715889467265','37.749367142083635','37.749367142083635','test'),('2019-04-23 19:59:59','2019-04-23 23:59:59','BRDETH','4h','0.001889600000000','0.001854000000000','0.072305137823947','0.070942911476290','38.264785046542656','38.264785046542656','test'),('2019-04-24 03:59:59','2019-04-24 11:59:59','BRDETH','4h','0.001896300000000','0.001799300000000','0.072305137823947','0.068606567782855','38.129588052495386','38.129588052495386','test'),('2019-04-27 11:59:59','2019-04-28 07:59:59','BRDETH','4h','0.001858100000000','0.001863800000000','0.072305137823947','0.072526944661898','38.913480342256605','38.913480342256605','test'),('2019-05-08 07:59:59','2019-05-14 03:59:59','BRDETH','4h','0.002180900000000','0.002265100000000','0.072305137823947','0.075096688378661','33.15380706311477','33.153807063114769','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','BRDETH','4h','0.001975000000000','0.001918500000000','0.072305137823947','0.070236661729237','36.61019636655544','36.610196366555442','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','BRDETH','4h','0.001800700000000','0.001788000000000','0.072305137823947','0.071795183222756','40.15390560556839','40.153905605568390','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','BRDETH','4h','0.002000700000000','0.001774500000000','0.072305137823947','0.064130287933520','36.139919939994506','36.139919939994506','test'),('2019-07-02 07:59:59','2019-07-02 15:59:59','BRDETH','4h','0.001326000000000','0.001260300000000','0.072305137823947','0.068722598189684','54.52876155652112','54.528761556521118','test'),('2019-07-04 11:59:59','2019-07-04 23:59:59','BRDETH','4h','0.001311600000000','0.001291500000000','0.072305137823947','0.071197076471201','55.127430484863524','55.127430484863524','test'),('2019-07-08 15:59:59','2019-07-09 03:59:59','BRDETH','4h','0.001279700000000','0.001205300000000','0.072305137823947','0.068101416440731','56.5016314948402','56.501631494840197','test'),('2019-07-10 15:59:59','2019-07-10 23:59:59','BRDETH','4h','0.001249800000000','0.001228800000000','0.072305137823947','0.071090217121192','57.85336679784526','57.853366797845261','test'),('2019-07-11 19:59:59','2019-07-12 03:59:59','BRDETH','4h','0.001254800000000','0.001238000000000','0.072305137823947','0.071337074136154','57.622838559090695','57.622838559090695','test'),('2019-07-14 11:59:59','2019-07-17 03:59:59','BRDETH','4h','0.001288700000000','0.001281000000000','0.072305137823947','0.071873113643576','56.10703641184682','56.107036411846821','test'),('2019-07-17 19:59:59','2019-07-19 11:59:59','BRDETH','4h','0.001296900000000','0.001276700000000','0.072305137823947','0.071178941676176','55.75228454310047','55.752284543100473','test'),('2019-07-22 23:59:59','2019-07-23 07:59:59','BRDETH','4h','0.001278800000000','0.001267800000000','0.072305137823947','0.071683182462621','56.54139648416249','56.541396484162490','test'),('2019-07-29 07:59:59','2019-07-29 19:59:59','BRDETH','4h','0.001235000000000','0.001227100000000','0.072305137823947','0.071842619128555','58.54667030279109','58.546670302791092','test'),('2019-07-30 15:59:59','2019-07-31 15:59:59','BRDETH','4h','0.001232900000000','0.001210500000000','0.072305137823947','0.070991458622668','58.64639291422418','58.646392914224180','test'),('2019-08-01 03:59:59','2019-08-02 15:59:59','BRDETH','4h','0.001243000000000','0.001225900000000','0.072305137823947','0.071310433192580','58.169861483465006','58.169861483465006','test'),('2019-08-06 07:59:59','2019-08-06 19:59:59','BRDETH','4h','0.001270500000000','0.001211600000000','0.072305137823947','0.068953093260523','56.91077357256749','56.910773572567493','test'),('2019-08-10 15:59:59','2019-08-11 03:59:59','BRDETH','4h','0.001195000000000','0.001138300000000','0.072305137823947','0.068874425426777','60.50639148447447','60.506391484474470','test'),('2019-08-12 03:59:59','2019-08-28 03:59:59','BRDETH','4h','0.001185900000000','0.001543900000000','0.072305137823947','0.094132643803349','60.97068709330214','60.970687093302139','test'),('2019-09-03 23:59:59','2019-09-04 07:59:59','BRDETH','4h','0.001494900000000','0.001476500000000','0.072305137823947','0.071415168905651','48.36787599434544','48.367875994345439','test'),('2019-09-04 19:59:59','2019-09-07 19:59:59','BRDETH','4h','0.001487600000000','0.001662300000000','0.072305137823947','0.080796471232016','48.605228437716455','48.605228437716455','test'),('2019-09-26 07:59:59','2019-09-28 11:59:59','BRDETH','4h','0.001139600000000','0.001131100000000','0.072305137823947','0.071765831337896','63.44782188833538','63.447821888335383','test'),('2019-10-28 03:59:59','2019-10-28 07:59:59','BRDETH','4h','0.001848200000000','0.001824900000000','0.072305137823947','0.071393597021383','39.121922856805','39.121922856805000','test'),('2019-10-28 15:59:59','2019-10-28 23:59:59','BRDETH','4h','0.001854100000000','0.001819500000000','0.072305137823947','0.070955826692558','38.99743154303813','38.997431543038132','test'),('2019-11-01 19:59:59','2019-11-05 19:59:59','BRDETH','4h','0.001838500000000','0.001901700000000','0.072305137823947','0.074790688387163','39.328331696462875','39.328331696462875','test'),('2019-11-17 19:59:59','2019-11-18 03:59:59','BRDETH','4h','0.001840000000000','0.001795300000000','0.072305137823947','0.070548594530072','39.296270556492935','39.296270556492935','test'),('2019-11-26 11:59:59','2019-11-26 23:59:59','BRDETH','4h','0.001754700000000','0.001756900000000','0.072305137823947','0.072395792239638','41.20655258673676','41.206552586736763','test'),('2019-11-30 03:59:59','2019-12-02 07:59:59','BRDETH','4h','0.001758500000000','0.001733900000000','0.072305137823947','0.071293647127064','41.11750800338186','41.117508003381857','test'),('2019-12-02 15:59:59','2019-12-03 03:59:59','BRDETH','4h','0.002308700000000','0.001808400000000','0.072305137823947','0.056636466947124','31.318550623271538','31.318550623271538','test'),('2019-12-07 19:59:59','2019-12-07 23:59:59','BRDETH','4h','0.001750100000000','0.001732700000000','0.072305137823947','0.071586259246645','41.31486076449745','41.314860764497453','test'),('2019-12-09 11:59:59','2019-12-10 03:59:59','BRDETH','4h','0.001785000000000','0.001671300000000','0.072305137823947','0.067699482826422','40.50708001341569','40.507080013415688','test'),('2019-12-11 15:59:59','2019-12-11 19:59:59','BRDETH','4h','0.001734600000000','0.001734600000000','0.072305137823947','0.072305137823947','41.68404117603309','41.684041176033091','test'),('2019-12-15 15:59:59','2019-12-15 19:59:59','BRDETH','4h','0.001758900000000','0.001763500000000','0.072305137823947','0.072494235347394','41.108157270991526','41.108157270991526','test'),('2019-12-16 11:59:59','2019-12-17 03:59:59','BRDETH','4h','0.001821500000000','0.001753000000000','0.072305137823947','0.069586004175339','39.69538173151084','39.695381731510842','test'),('2019-12-27 07:59:59','2019-12-29 19:59:59','BRDETH','4h','0.001978200000000','0.001922600000000','0.072305137823947','0.070272903639834','36.55097453439845','36.550974534398449','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','BRDETH','4h','0.002012300000000','0.001903500000000','0.072305137823947','0.068395780871581','35.93158963571386','35.931589635713863','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:22:18
