-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 23:59:59','2019-01-09 03:59:59','EOSBTC','4h','0.000693400000000','0.000695200000000','0.001467500000000','0.001471309489472','2.1163830400922987','2.116383040092299','test'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.001468452372368','0.001469762710594','2.183897043973825','2.183897043973825','test'),('2019-01-18 23:59:59','2019-01-19 03:59:59','EOSBTC','4h','0.000675700000000','0.000672700000000','0.001468779956925','0.001462258808678','2.173716082469291','2.173716082469291','test'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.001468779956925','0.001440168746832','2.135164932293938','2.135164932293938','test'),('2019-01-30 19:59:59','2019-01-31 11:59:59','EOSBTC','4h','0.000671900000000','0.000667900000000','0.001468779956925','0.001460035917890','2.1860097587810685','2.186009758781069','test'),('2019-02-27 07:59:59','2019-02-27 11:59:59','EOSBTC','4h','0.000915600000000','0.000914500000000','0.001468779956925','0.001467015367636','1.6041720805209698','1.604172080520970','test'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.001468779956925','0.001452453065512','1.6006756287325634','1.600675628732563','test'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.001468779956925','0.001440996842449','1.5521293003540104','1.552129300354010','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.001468779956925','0.001458649365117','1.55855258587118','1.558552585871180','test'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.001468779956925','0.001459576684043','1.5598767596909517','1.559876759690952','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.001468779956925','0.001459434759313','1.5839317986897445','1.583931798689745','test'),('2019-04-02 19:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001019500000000','0.001056400000000','0.001468779956925','0.001521941291315','1.4406865688327612','1.440686568832761','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','EOSBTC','4h','0.001059600000000','0.001055400000000','0.001468779956925','0.001462958065816','1.3861645497593433','1.386164549759343','test'),('2019-04-14 23:59:59','2019-04-15 15:59:59','EOSBTC','4h','0.001080600000000','0.001068400000000','0.001468779956925','0.001452197395871','1.3592263158661857','1.359226315866186','test'),('2019-05-16 03:59:59','2019-05-19 03:59:59','EOSBTC','4h','0.000818900000000','0.000790200000000','0.001468779956925','0.001417303604790','1.7936011197032606','1.793601119703261','test'),('2019-05-24 11:59:59','2019-05-25 15:59:59','EOSBTC','4h','0.000798600000000','0.000792100000000','0.001468779956925','0.001456825198949','1.839193534842224','1.839193534842224','test'),('2019-05-26 03:59:59','2019-05-26 07:59:59','EOSBTC','4h','0.000793200000000','0.000794100000000','0.001468779956925','0.001470446499993','1.8517145195726175','1.851714519572617','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','EOSBTC','4h','0.000798400000000','0.000794200000000','0.001468779956925','0.001461053409055','1.8396542546655812','1.839654254665581','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','EOSBTC','4h','0.000884800000000','0.000874600000000','0.001468779956925','0.001451847819085','1.6600135137036618','1.660013513703662','test'),('2019-07-23 19:59:59','2019-07-28 23:59:59','EOSBTC','4h','0.000419500000000','0.000448200000000','0.001468779956925','0.001569266213811','3.50126330613826','3.501263306138260','test'),('2019-07-29 23:59:59','2019-07-30 03:59:59','EOSBTC','4h','0.000443000000000','0.000441800000000','0.001468779956925','0.001464801320473','3.3155303768058695','3.315530376805869','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','EOSBTC','4h','0.000374500000000','0.000386600000000','0.001468779956925','0.001516235864746','3.92197585293725','3.921975852937250','test'),('2019-08-22 15:59:59','2019-08-23 15:59:59','EOSBTC','4h','0.000359600000000','0.000356600000000','0.001468779956925','0.001456526509008','4.0844826388348165','4.084482638834817','test'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSBTC','4h','0.000360700000000','0.000361200000000','0.001468779956925','0.001470815970173','4.072026495494872','4.072026495494872','test'),('2019-09-07 19:59:59','2019-09-22 19:59:59','EOSBTC','4h','0.000338900000000','0.000376700000000','0.001468779956925','0.001632603746750','4.333962693788728','4.333962693788728','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','EOSBTC','4h','0.000387300000000','0.000380700000000','0.001499648321432','0.001474092734235','3.872058666232893','3.872058666232893','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','EOSBTC','4h','0.000362600000000','0.000354200000000','0.001499648321432','0.001464907433677','4.135819970854937','4.135819970854937','test'),('2019-10-01 03:59:59','2019-10-01 15:59:59','EOSBTC','4h','0.000360800000000','0.000352500000000','0.001499648321432','0.001465149759714','4.156453219046564','4.156453219046564','test'),('2019-10-02 11:59:59','2019-10-02 15:59:59','EOSBTC','4h','0.000359100000000','0.000359300000000','0.001499648321432','0.001500483547453','4.176130107023114','4.176130107023114','test'),('2019-10-04 07:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000361600000000','0.000369100000000','0.001499648321432','0.001530752752878','4.147257526084071','4.147257526084071','test'),('2019-10-11 19:59:59','2019-10-11 23:59:59','EOSBTC','4h','0.000371300000000','0.000370200000000','0.001499648321432','0.001495205517356','4.038912796746566','4.038912796746566','test'),('2019-10-13 03:59:59','2019-10-13 07:59:59','EOSBTC','4h','0.000372200000000','0.000371800000000','0.001499648321432','0.001498036662838','4.029146484234283','4.029146484234283','test'),('2019-10-13 23:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000374700000000','0.000374700000000','0.001499648321432','0.001499648321432','4.002264001686683','4.002264001686683','test'),('2019-10-24 03:59:59','2019-10-24 07:59:59','EOSBTC','4h','0.000363300000000','0.000363300000000','0.001499648321432','0.001499648321432','4.12785114624828','4.127851146248280','test'),('2019-10-24 15:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000369700000000','0.000344500000000','0.001499648321432','0.001397427229465','4.056392538360833','4.056392538360833','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','EOSBTC','4h','0.000361100000000','0.000357300000000','0.001499648321432','0.001483866921206','4.153000059351981','4.153000059351981','test'),('2019-10-29 03:59:59','2019-10-29 15:59:59','EOSBTC','4h','0.000360000000000','0.000359700000000','0.001499648321432','0.001498398614497','4.165689781755556','4.165689781755556','test'),('2019-11-01 19:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000361100000000','0.000358800000000','0.001499648321432','0.001490096421295','4.153000059351981','4.153000059351981','test'),('2019-11-04 11:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000363900000000','0.000391800000000','0.001499648321432','0.001614625480454','4.12104512622149','4.121045126221490','test'),('2019-12-01 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000368700000000','0.000368400000000','0.001499648321432','0.001498428103107','4.067394416685652','4.067394416685652','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','EOSBTC','4h','0.000368500000000','0.000367100000000','0.001499648321432','0.001493950878691','4.069601957753053','4.069601957753053','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSBTC','4h','0.000363500000000','0.000360900000000','0.001499648321432','0.001488921813493','4.125579976429161','4.125579976429161','test'),('2019-12-14 15:59:59','2019-12-14 19:59:59','EOSBTC','4h','0.000362700000000','0.000363200000000','0.001499648321432','0.001501715661274','4.134679684124621','4.134679684124621','test'),('2019-12-24 19:59:59','2019-12-25 15:59:59','EOSBTC','4h','0.000350900000000','0.000344300000000','0.001499648321432','0.001471441769932','4.273719924286121','4.273719924286121','test'),('2019-12-26 15:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000348400000000','0.000363100000000','0.001499648321432','0.001562922805717','4.30438668608496','4.304386686084960','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:09:33
