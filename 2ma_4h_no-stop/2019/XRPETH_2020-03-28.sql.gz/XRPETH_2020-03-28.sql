-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','0.072144500000000','0.072706234347951','28.002709269739245','28.002709269739245','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','XRPETH','4h','0.002607890000000','0.002590000000000','0.072284933586988','0.071789062418391','27.717784717525568','27.717784717525568','test'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','0.072284933586988','0.071743131039028','25.67784587487629','25.677845874876290','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','XRPETH','4h','0.002805900000000','0.002789410000000','0.072284933586988','0.071860122098749','25.76176399265405','25.761763992654050','test'),('2019-02-25 19:59:59','2019-02-27 03:59:59','XRPETH','4h','0.002380130000000','0.002309270000000','0.072284933586988','0.070132903910469','30.370161960476107','30.370161960476107','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002304900000000','0.002287290000000','0.072284933586988','0.071732659006543','31.36141853745846','31.361418537458459','test'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','0.072284933586988','0.073032739946611','31.18458547219679','31.184585472196790','test'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','0.072284933586988','0.071987948203086','31.163209223726913','31.163209223726913','test'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','0.072284933586988','0.072381342618749','31.20033390322341','31.200333903223409','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002201400000000','0.072284933586988','0.070683682009886','32.108513677607746','32.108513677607746','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','XRPETH','4h','0.002215810000000','0.002199970000000','0.072284933586988','0.071768195532724','32.62235191058259','32.622351910582587','test'),('2019-04-26 19:59:59','2019-04-26 23:59:59','XRPETH','4h','0.001921600000000','0.001921710000000','0.072284933586988','0.072289071463078','37.61705536375312','37.617055363753117','test'),('2019-04-30 11:59:59','2019-05-01 03:59:59','XRPETH','4h','0.001933450000000','0.001894390000000','0.072284933586988','0.070824616792704','37.38650266983268','37.386502669832680','test'),('2019-05-14 07:59:59','2019-05-15 19:59:59','XRPETH','4h','0.001834520000000','0.001787590000000','0.072284933586988','0.070435767629006','39.402641337782086','39.402641337782086','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XRPETH','4h','0.001600790000000','0.001589290000000','0.072284933586988','0.071765642027039','45.15578782163057','45.155787821630568','test'),('2019-06-06 03:59:59','2019-06-06 07:59:59','XRPETH','4h','0.001635110000000','0.001631280000000','0.072284933586988','0.072115616968755','44.20799431658298','44.207994316582983','test'),('2019-06-09 23:59:59','2019-06-10 03:59:59','XRPETH','4h','0.001666300000000','0.001656150000000','0.072284933586988','0.071844621472778','43.38050386304267','43.380503863042669','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','XRPETH','4h','0.001595970000000','0.001598430000000','0.072284933586988','0.072396352308282','45.29216312774551','45.292163127745511','test'),('2019-06-17 23:59:59','2019-06-18 19:59:59','XRPETH','4h','0.001638130000000','0.001613210000000','0.072284933586988','0.071185301356953','44.12649398215526','44.126493982155260','test'),('2019-07-14 15:59:59','2019-07-25 03:59:59','XRPETH','4h','0.001300820000000','0.001435720000000','0.072284933586988','0.079781157154341','55.568744012997946','55.568744012997946','test'),('2019-08-04 19:59:59','2019-08-04 23:59:59','XRPETH','4h','0.001460720000000','0.001434430000000','0.072284933586988','0.070983951260463','49.48582451598389','49.485824515983893','test'),('2019-08-10 03:59:59','2019-08-10 11:59:59','XRPETH','4h','0.001426130000000','0.001438460000000','0.072284933586988','0.072909892904250','50.68607601480089','50.686076014800889','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','XRPETH','4h','0.001421570000000','0.001413000000000','0.072284933586988','0.071849160546729','50.84866280731022','50.848662807310220','test'),('2019-08-12 23:59:59','2019-08-13 03:59:59','XRPETH','4h','0.001421300000000','0.001422700000000','0.072284933586988','0.072356135238308','50.858322371763876','50.858322371763876','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','XRPETH','4h','0.001433330000000','0.001415350000000','0.072284933586988','0.071378175822974','50.43146629665743','50.431466296657433','test'),('2019-08-15 11:59:59','2019-08-15 15:59:59','XRPETH','4h','0.001435060000000','0.001420810000000','0.072284933586988','0.071567151540513','50.370669928078264','50.370669928078264','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','XRPETH','4h','0.001429310000000','0.001415190000000','0.072284933586988','0.071570838490579','50.57330711111515','50.573307111115149','test'),('2019-08-17 07:59:59','2019-08-19 11:59:59','XRPETH','4h','0.001436850000000','0.001426240000000','0.072284933586988','0.071751166565129','50.307919119593556','50.307919119593556','test'),('2019-08-21 15:59:59','2019-08-21 23:59:59','XRPETH','4h','0.001432120000000','0.001418480000000','0.072284933586988','0.071596467191626','50.474075906340246','50.474075906340246','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','XRPETH','4h','0.001421450000000','0.001417240000000','0.072284933586988','0.072070842644358','50.85295549402933','50.852955494029331','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','XRPETH','4h','0.001431300000000','0.001421050000000','0.072284933586988','0.071767277910843','50.502992794653814','50.502992794653814','test'),('2019-08-24 15:59:59','2019-08-24 23:59:59','XRPETH','4h','0.001426760000000','0.001424150000000','0.072284933586988','0.072152701342839','50.66369507624828','50.663695076248281','test'),('2019-08-26 15:59:59','2019-08-26 19:59:59','XRPETH','4h','0.001435120000000','0.001434360000000','0.072284933586988','0.072246653478338','50.36856401345393','50.368564013453927','test'),('2019-08-28 19:59:59','2019-09-02 19:59:59','XRPETH','4h','0.001481320000000','0.001465270000000','0.072284933586988','0.071501731318693','48.79764911497043','48.797649114970433','test'),('2019-09-04 23:59:59','2019-09-05 23:59:59','XRPETH','4h','0.001478980000000','0.001473790000000','0.072284933586988','0.072031273087646','48.87485536449986','48.874855364499858','test'),('2019-09-06 19:59:59','2019-09-07 11:59:59','XRPETH','4h','0.001477450000000','0.001468380000000','0.072284933586988','0.071841179586762','48.92546860265187','48.925468602651868','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','XRPETH','4h','0.001441180000000','0.001424280000000','0.072284933586988','0.071437284176352','50.1567698601063','50.156769860106301','test'),('2019-09-24 19:59:59','2019-09-27 23:59:59','XRPETH','4h','0.001417480000000','0.001392240000000','0.072284933586988','0.070997810154040','50.995381654053666','50.995381654053666','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','XRPETH','4h','0.001413550000000','0.001392750000000','0.072284933586988','0.071221280643258','51.137160756243496','51.137160756243496','test'),('2019-09-29 07:59:59','2019-09-29 11:59:59','XRPETH','4h','0.001405800000000','0.001398310000000','0.072284933586988','0.071899804726150','51.41907354316972','51.419073543169723','test'),('2019-09-29 15:59:59','2019-09-29 19:59:59','XRPETH','4h','0.001413410000000','0.001424450000000','0.072284933586988','0.072849543761531','51.1422259549515','51.142225954951499','test'),('2019-10-02 15:59:59','2019-10-02 23:59:59','XRPETH','4h','0.001419830000000','0.001401270000000','0.072284933586988','0.071340025839318','50.9109777839516','50.910977783951601','test'),('2019-10-03 15:59:59','2019-10-03 23:59:59','XRPETH','4h','0.001414710000000','0.001413020000000','0.072284933586988','0.072198582647388','51.095230532750875','51.095230532750875','test'),('2019-10-11 15:59:59','2019-10-23 19:59:59','XRPETH','4h','0.001467700000000','0.001662010000000','0.072284933586988','0.081854794897397','49.250482787346186','49.250482787346186','test'),('2019-11-05 07:59:59','2019-11-05 11:59:59','XRPETH','4h','0.001620680000000','0.001607000000000','0.072284933586988','0.071674783593485','44.60160771218747','44.601607712187473','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','XRPETH','4h','0.001625170000000','0.001596750000000','0.072284933586988','0.071020857944106','44.47838293039374','44.478382930393742','test'),('2019-11-21 15:59:59','2019-11-25 03:59:59','XRPETH','4h','0.001497950000000','0.001529670000000','0.072284933586988','0.073815610908247','48.255905462123565','48.255905462123565','test'),('2019-11-26 19:59:59','2019-11-26 23:59:59','XRPETH','4h','0.001503500000000','0.001497010000000','0.072284933586988','0.071972908832096','48.07777425140538','48.077774251405380','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','XRPETH','4h','0.001492440000000','0.001488480000000','0.072284933586988','0.072093134695907','48.43406340421591','48.434063404215912','test'),('2019-12-01 07:59:59','2019-12-01 15:59:59','XRPETH','4h','0.001493130000000','0.001480000000000','0.072284933586988','0.071649288212508','48.41168122466764','48.411681224667639','test'),('2019-12-03 19:59:59','2019-12-03 23:59:59','XRPETH','4h','0.001491090000000','0.001490310000000','0.072284933586988','0.072247120813649','48.477914537008495','48.477914537008495','test'),('2019-12-05 19:59:59','2019-12-10 15:59:59','XRPETH','4h','0.001492250000000','0.001519640000000','0.072284933586988','0.073611711493470','48.44023024760462','48.440230247604617','test'),('2019-12-16 19:59:59','2019-12-17 03:59:59','XRPETH','4h','0.001570440000000','0.001506220000000','0.072284933586988','0.069328985932218','46.02845927701026','46.028459277010263','test'),('2019-12-20 19:59:59','2019-12-20 23:59:59','XRPETH','4h','0.001510890000000','0.001522910000000','0.072284933586988','0.072860001859143','47.84261831568678','47.842618315686778','test'),('2019-12-25 03:59:59','2019-12-25 07:59:59','XRPETH','4h','0.001505980000000','0.001503020000000','0.072284933586988','0.072142857727138','47.998601300806115','47.998601300806115','test'),('2019-12-27 03:59:59','2019-12-27 07:59:59','XRPETH','4h','0.001502200000000','0.001510620000000','0.072284933586988','0.072690098771918','48.11938063306351','48.119380633063507','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:42:19
