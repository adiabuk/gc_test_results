-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-15 03:59:59','QTUMETH','4h','0.016036000000000','0.016590000000000','0.072144500000000','0.074636895422799','4.498908705412821','4.498908705412821','test'),('2019-01-28 07:59:59','2019-01-28 11:59:59','QTUMETH','4h','0.017527000000000','0.017706000000000','0.072767598855700','0.073510760845497','4.151742959759214','4.151742959759214','test'),('2019-01-29 11:59:59','2019-01-30 03:59:59','QTUMETH','4h','0.017616000000000','0.017422000000000','0.072953389353149','0.072149974415904','4.141314109511184','4.141314109511184','test'),('2019-02-23 07:59:59','2019-02-23 19:59:59','QTUMETH','4h','0.015280000000000','0.015263000000000','0.072953389353149','0.072872223933057','4.774436475991427','4.774436475991427','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','QTUMETH','4h','0.015150000000000','0.015128000000000','0.072953389353149','0.072847450437917','4.815405237831618','4.815405237831618','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','QTUMETH','4h','0.015218000000000','0.015179000000000','0.072953389353149','0.072766427716615','4.793888116253712','4.793888116253712','test'),('2019-03-08 15:59:59','2019-03-11 11:59:59','QTUMETH','4h','0.015332000000000','0.015570000000000','0.072953389353149','0.074085851306322','4.758243500727172','4.758243500727172','test'),('2019-05-02 15:59:59','2019-05-03 11:59:59','QTUMETH','4h','0.016255000000000','0.015850000000000','0.072953389353149','0.071135725699625','4.488058403761858','4.488058403761858','test'),('2019-05-29 15:59:59','2019-05-30 11:59:59','QTUMETH','4h','0.012172000000000','0.012196000000000','0.072953389353149','0.073097234353517','5.993541681987266','5.993541681987266','test'),('2019-06-07 15:59:59','2019-06-08 15:59:59','QTUMETH','4h','0.012619000000000','0.012417000000000','0.072953389353149','0.071785580125054','5.781233802452572','5.781233802452572','test'),('2019-06-09 07:59:59','2019-06-09 11:59:59','QTUMETH','4h','0.012522000000000','0.012493000000000','0.072953389353149','0.072784434849776','5.826017357702364','5.826017357702364','test'),('2019-06-09 19:59:59','2019-06-10 03:59:59','QTUMETH','4h','0.012539000000000','0.012796000000000','0.072953389353149','0.074448645838017','5.818118618163251','5.818118618163251','test'),('2019-06-13 15:59:59','2019-06-14 19:59:59','QTUMETH','4h','0.013292000000000','0.012849000000000','0.072953389353149','0.070521975609285','5.4885186091746165','5.488518609174617','test'),('2019-06-24 19:59:59','2019-07-07 11:59:59','QTUMETH','4h','0.013676000000000','0.016283000000000','0.072953389353149','0.086860195878716','5.334409867881617','5.334409867881617','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','QTUMETH','4h','0.014362000000000','0.014087000000000','0.075432151334653','0.073987795282778','5.252203825000225','5.252203825000225','test'),('2019-07-20 15:59:59','2019-07-20 19:59:59','QTUMETH','4h','0.014151000000000','0.014514000000000','0.075432151334653','0.077367129140778','5.33051737224599','5.330517372245990','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','QTUMETH','4h','0.014109000000000','0.013921000000000','0.075554806773216','0.074548051959029','5.355078798867088','5.355078798867088','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','QTUMETH','4h','0.014237000000000','0.014065000000000','0.075554806773216','0.074642014277255','5.306933116050853','5.306933116050853','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','QTUMETH','4h','0.014250000000000','0.014002000000000','0.075554806773216','0.074239888030777','5.302091703383578','5.302091703383578','test'),('2019-07-31 11:59:59','2019-07-31 19:59:59','QTUMETH','4h','0.014202000000000','0.013939000000000','0.075554806773216','0.074155643684823','5.320011742938741','5.320011742938741','test'),('2019-08-01 23:59:59','2019-08-02 03:59:59','QTUMETH','4h','0.013943000000000','0.013908000000000','0.075554806773216','0.075365147572394','5.4188343092028965','5.418834309202897','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','QTUMETH','4h','0.013938000000000','0.013818000000000','0.075554806773216','0.074904313387308','5.420778215900128','5.420778215900128','test'),('2019-08-17 19:59:59','2019-08-17 23:59:59','QTUMETH','4h','0.012881000000000','0.013228000000000','0.075554806773216','0.077590170328088','5.865601022685816','5.865601022685816','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','QTUMETH','4h','0.009755000000000','0.009722000000000','0.075554806773216','0.075299213885106','7.745239033645925','7.745239033645925','test'),('2019-10-05 15:59:59','2019-10-06 07:59:59','QTUMETH','4h','0.009808000000000','0.009779000000000','0.075554806773216','0.075331408588426','7.703385682424142','7.703385682424142','test'),('2019-10-11 19:59:59','2019-10-12 11:59:59','QTUMETH','4h','0.009810000000000','0.009747000000000','0.075554806773216','0.075069592417792','7.701815165465443','7.701815165465443','test'),('2019-10-15 15:59:59','2019-10-15 19:59:59','QTUMETH','4h','0.009830000000000','0.009746000000000','0.075554806773216','0.074909170581054','7.686145144782909','7.686145144782909','test'),('2019-10-17 11:59:59','2019-10-17 15:59:59','QTUMETH','4h','0.009778000000000','0.009878000000000','0.075554806773216','0.076327508826532','7.7270205331577','7.727020533157700','test'),('2019-10-18 15:59:59','2019-10-18 19:59:59','QTUMETH','4h','0.009760000000000','0.009694000000000','0.075554806773216','0.075043882874954','7.741271185780327','7.741271185780327','test'),('2019-10-18 23:59:59','2019-10-19 03:59:59','QTUMETH','4h','0.009799000000000','0.009771000000000','0.075554806773216','0.075338913866833','7.710460942261046','7.710460942261046','test'),('2019-10-19 19:59:59','2019-10-20 07:59:59','QTUMETH','4h','0.009809000000000','0.009783000000000','0.075554806773216','0.075354539164275','7.7026003438898965','7.702600343889896','test'),('2019-10-21 15:59:59','2019-10-22 11:59:59','QTUMETH','4h','0.009781000000000','0.009801000000000','0.075554806773216','0.075709299783692','7.724650523792659','7.724650523792659','test'),('2019-10-24 15:59:59','2019-10-25 07:59:59','QTUMETH','4h','0.009820000000000','0.009734000000000','0.075554806773216','0.074893125166037','7.693972176498574','7.693972176498574','test'),('2019-10-26 03:59:59','2019-11-07 15:59:59','QTUMETH','4h','0.009813000000000','0.011708000000000','0.075554806773216','0.090145284591951','7.699460590361356','7.699460590361356','test'),('2019-11-08 23:59:59','2019-11-09 03:59:59','QTUMETH','4h','0.011763000000000','0.011578000000000','0.077774968540325','0.076551779797661','6.611831041428655','6.611831041428655','test'),('2019-11-12 11:59:59','2019-11-15 15:59:59','QTUMETH','4h','0.011976000000000','0.012026000000000','0.077774968540325','0.078099680332828','6.494235850060538','6.494235850060538','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','QTUMETH','4h','0.011422000000000','0.011366000000000','0.077774968540325','0.077393651937431','6.809225051683156','6.809225051683156','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','QTUMETH','4h','0.011445000000000','0.011362000000000','0.077774968540325','0.077210938624305','6.795541156865444','6.795541156865444','test'),('2019-11-28 03:59:59','2019-11-30 15:59:59','QTUMETH','4h','0.011470000000000','0.011755000000000','0.077774968540325','0.079707476477029','6.780729602469487','6.780729602469487','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','QTUMETH','4h','0.011749000000000','0.011550000000000','0.077797139657233','0.076479441913443','6.62159670246255','6.621596702462550','test'),('2019-12-06 03:59:59','2019-12-06 07:59:59','QTUMETH','4h','0.011692000000000','0.011609000000000','0.077797139657233','0.077244867796854','6.65387783589061','6.653877835890610','test'),('2019-12-06 23:59:59','2019-12-08 03:59:59','QTUMETH','4h','0.011753000000000','0.011753000000000','0.077797139657233','0.077797139657233','6.619343117266486','6.619343117266486','test'),('2019-12-09 11:59:59','2019-12-09 15:59:59','QTUMETH','4h','0.011812000000000','0.011712000000000','0.077797139657233','0.077138511654717','6.5862800251636475','6.586280025163648','test'),('2019-12-10 11:59:59','2019-12-10 19:59:59','QTUMETH','4h','0.011717000000000','0.011845000000000','0.077797139657233','0.078647018796614','6.639680776413161','6.639680776413161','test'),('2019-12-17 19:59:59','2019-12-23 03:59:59','QTUMETH','4h','0.012309000000000','0.012635000000000','0.077797139657233','0.079857572472917','6.320346060381266','6.320346060381266','test'),('2019-12-24 19:59:59','2019-12-24 23:59:59','QTUMETH','4h','0.012655000000000','0.012552000000000','0.077892568244327','0.077258594753283','6.15508243732339','6.155082437323390','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','QTUMETH','4h','0.012629000000000','0.012549000000000','0.077892568244327','0.077399147905460','6.16775423583237','6.167754235832370','test'),('2019-12-26 23:59:59','2019-12-27 03:59:59','QTUMETH','4h','0.012668000000000','0.012585000000000','0.077892568244327','0.077382220662682','6.14876604391593','6.148766043915930','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 16:18:31
