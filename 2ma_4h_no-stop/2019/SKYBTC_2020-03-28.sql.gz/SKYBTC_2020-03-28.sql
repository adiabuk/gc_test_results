-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 07:59:59','2019-01-03 11:59:59','SKYBTC','4h','0.000271000000000','0.000277000000000','0.001467500000000','0.001499990774908','5.415129151291514','5.415129151291514','test'),('2019-01-04 23:59:59','2019-01-05 03:59:59','SKYBTC','4h','0.000277000000000','0.000273000000000','0.001475622693727','0.001454314062771','5.327157739086643','5.327157739086643','test'),('2019-01-12 03:59:59','2019-01-12 15:59:59','SKYBTC','4h','0.000274000000000','0.000271000000000','0.001475622693727','0.001459466240876','5.385484283675182','5.385484283675182','test'),('2019-01-14 15:59:59','2019-01-15 03:59:59','SKYBTC','4h','0.000276000000000','0.000272000000000','0.001475622693727','0.001454236857586','5.346459035242754','5.346459035242754','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','SKYBTC','4h','0.000271000000000','0.000273000000000','0.001475622693727','0.001486512898109','5.445102190874539','5.445102190874539','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','SKYBTC','4h','0.000282000000000','0.000283000000000','0.001475622693727','0.001480855398315','5.232704587684396','5.232704587684396','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','SKYBTC','4h','0.000284000000000','0.000281000000000','0.001475622693727','0.001460035130061','5.195854555376759','5.195854555376759','test'),('2019-01-22 15:59:59','2019-01-22 23:59:59','SKYBTC','4h','0.000282000000000','0.000281000000000','0.001475622693727','0.001470389989139','5.232704587684396','5.232704587684396','test'),('2019-01-27 07:59:59','2019-01-27 11:59:59','SKYBTC','4h','0.000285000000000','0.000280000000000','0.001475622693727','0.001449734576293','5.177623486761403','5.177623486761403','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','SKYBTC','4h','0.000281000000000','0.000270000000000','0.001475622693727','0.001417858104293','5.251326312195729','5.251326312195729','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','SKYBTC','4h','0.000273000000000','0.000271000000000','0.001475622693727','0.001464812271062','5.405211332333333','5.405211332333333','test'),('2019-02-17 23:59:59','2019-02-18 19:59:59','SKYBTC','4h','0.000268000000000','0.000267000000000','0.001475622693727','0.001470116638900','5.506054827339551','5.506054827339551','test'),('2019-02-20 23:59:59','2019-02-21 07:59:59','SKYBTC','4h','0.000268000000000','0.000266000000000','0.001475622693727','0.001464610584072','5.506054827339551','5.506054827339551','test'),('2019-02-23 03:59:59','2019-02-23 15:59:59','SKYBTC','4h','0.000272000000000','0.000264000000000','0.001475622693727','0.001432222026264','5.425083432819853','5.425083432819853','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','SKYBTC','4h','0.000264000000000','0.000265000000000','0.001475622693727','0.001481212173627','5.589479900481059','5.589479900481059','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','SKYBTC','4h','0.000265000000000','0.000261000000000','0.001475622693727','0.001453349143633','5.568387523498113','5.568387523498113','test'),('2019-02-27 23:59:59','2019-03-04 07:59:59','SKYBTC','4h','0.000267000000000','0.000304000000000','0.001475622693727','0.001680109733682','5.5266767555318355','5.526676755531835','test'),('2019-03-12 15:59:59','2019-03-14 11:59:59','SKYBTC','4h','0.000277000000000','0.000282000000000','0.001475622693727','0.001502258482422','5.327157739086642','5.327157739086642','test'),('2019-03-16 23:59:59','2019-03-17 03:59:59','SKYBTC','4h','0.000278000000000','0.000276000000000','0.001475622693727','0.001465006703125','5.307995301176259','5.307995301176259','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','SKYBTC','4h','0.000279000000000','0.000277000000000','0.001475622693727','0.001465044753270','5.288970228412186','5.288970228412186','test'),('2019-03-20 11:59:59','2019-03-20 23:59:59','SKYBTC','4h','0.000282000000000','0.000275000000000','0.001475622693727','0.001438993761613','5.232704587684396','5.232704587684396','test'),('2019-03-26 07:59:59','2019-03-26 19:59:59','SKYBTC','4h','0.000277000000000','0.000282000000000','0.001475622693727','0.001502258482422','5.327157739086642','5.327157739086642','test'),('2019-04-03 07:59:59','2019-04-03 19:59:59','SKYBTC','4h','0.000303000000000','0.000291000000000','0.001475622693727','0.001417182191005','4.870041893488448','4.870041893488448','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','SKYBTC','4h','0.000292000000000','0.000292000000000','0.001475622693727','0.001475622693727','5.053502375777397','5.053502375777397','test'),('2019-04-05 15:59:59','2019-04-05 23:59:59','SKYBTC','4h','0.000292000000000','0.000291000000000','0.001475622693727','0.001470569191351','5.053502375777397','5.053502375777397','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','SKYBTC','4h','0.000268000000000','0.000265000000000','0.001475622693727','0.001459104529245','5.506054827339551','5.506054827339551','test'),('2019-05-15 19:59:59','2019-05-18 23:59:59','SKYBTC','4h','0.000214000000000','0.000186000000000','0.001475622693727','0.001282550565576','6.895433148257009','6.895433148257009','test'),('2019-05-19 19:59:59','2019-05-19 23:59:59','SKYBTC','4h','0.000199000000000','0.000184000000000','0.001475622693727','0.001364394852491','7.4151894157135665','7.415189415713566','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','SKYBTC','4h','0.000197000000000','0.000199000000000','0.001475622693727','0.001490603634780','7.490470526532994','7.490470526532994','test'),('2019-05-24 23:59:59','2019-05-25 11:59:59','SKYBTC','4h','0.000198000000000','0.000195000000000','0.001475622693727','0.001453264774125','7.452639867308081','7.452639867308081','test'),('2019-06-08 15:59:59','2019-06-08 19:59:59','SKYBTC','4h','0.000228000000000','0.000226000000000','0.001475622693727','0.001462678635010','6.472029358451754','6.472029358451754','test'),('2019-06-30 11:59:59','2019-06-30 19:59:59','SKYBTC','4h','0.000170000000000','0.000167000000000','0.001475622693727','0.001449582293249','8.680133492511763','8.680133492511763','test'),('2019-07-21 11:59:59','2019-07-24 03:59:59','SKYBTC','4h','0.000129000000000','0.000128000000000','0.001475622693727','0.001464183758117','11.438935610286821','11.438935610286821','test'),('2019-08-24 07:59:59','2019-08-25 15:59:59','SKYBTC','4h','0.000087000000000','0.000080000000000','0.001475622693727','0.001356894431013','16.961180387666666','16.961180387666666','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','SKYBTC','4h','0.000056000000000','0.000052000000000','0.001475622693727','0.001370221072746','26.350405245125','26.350405245125000','test'),('2019-09-18 07:59:59','2019-09-19 23:59:59','SKYBTC','4h','0.000051910000000','0.000052250000000','0.001475622693727','0.001485287723892','28.426559308938543','28.426559308938543','test'),('2019-09-22 15:59:59','2019-09-22 19:59:59','SKYBTC','4h','0.000052410000000','0.000053990000000','0.001475622693727','0.001520108170851','28.155365268593776','28.155365268593776','test'),('2019-09-30 15:59:59','2019-10-20 19:59:59','SKYBTC','4h','0.000060040000000','0.000086630000000','0.001475622693727','0.002129133810086','24.57732667766489','24.577326677664889','test'),('2019-11-01 15:59:59','2019-11-01 19:59:59','SKYBTC','4h','0.000074900000000','0.000073100000000','0.001477307861452','0.001441805135810','19.72373646798399','19.723736467983990','test'),('2019-11-04 15:59:59','2019-11-04 19:59:59','SKYBTC','4h','0.000074280000000','0.000073010000000','0.001477307861452','0.001452049636034','19.88836647081314','19.888366470813139','test'),('2019-11-09 07:59:59','2019-11-10 19:59:59','SKYBTC','4h','0.000073360000000','0.000072220000000','0.001477307861452','0.001454350787269','20.13778437093784','20.137784370937840','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','SKYBTC','4h','0.000071870000000','0.000071360000000','0.001477307861452','0.001466824669448','20.55527843957145','20.555278439571449','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','SKYBTC','4h','0.000072560000000','0.000073080000000','0.001477307861452','0.001487894962995','20.35981065948181','20.359810659481809','test'),('2019-11-16 19:59:59','2019-11-16 23:59:59','SKYBTC','4h','0.000071810000000','0.000071770000000','0.001477307861452','0.001476484963326','20.57245316045119','20.572453160451190','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','SKYBTC','4h','0.000071550000000','0.000071510000000','0.001477307861452','0.001476481973060','20.647209803661774','20.647209803661774','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','SKYBTC','4h','0.000071000000000','0.000068510000000','0.001477307861452','0.001425498050536','20.80715297819718','20.807152978197180','test'),('2019-11-25 15:59:59','2019-11-28 07:59:59','SKYBTC','4h','0.000070170000000','0.000071740000000','0.001477307861452','0.001510361493239','21.053268654011685','21.053268654011685','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','SKYBTC','4h','0.000068720000000','0.000066000000000','0.001477307861452','0.001418834674852','21.497495073515715','21.497495073515715','test'),('2019-12-29 19:59:59','2019-12-29 23:59:59','SKYBTC','4h','0.000058090000000','0.000058230000000','0.001477307861452','0.001480868252235','25.431362738027197','25.431362738027197','test'),('2020-01-01 11:59:59','2020-01-01 15:59:59','SKYBTC','4h','0.000058470000000','0.000058490000000','0.001477307861452','0.001477813183108','25.26608280232598','25.266082802325979','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:30:42
