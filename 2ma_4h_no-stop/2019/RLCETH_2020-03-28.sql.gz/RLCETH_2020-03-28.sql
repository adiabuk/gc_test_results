-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-07 15:59:59','RLCETH','4h','0.001391000000000','0.001396000000000','0.072144500000000','0.072403826024443','51.86520488856937','51.865204888569373','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','RLCETH','4h','0.001387000000000','0.001406000000000','0.072209331506111','0.073198500430852','52.06152235480227','52.061522354802271','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','RLCETH','4h','0.001989000000000','0.002034000000000','0.072456623737296','0.074095913867099','36.42866955117949','36.428669551179489','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','RLCETH','4h','0.002047000000000','0.001978000000000','0.072866446269747','0.070410273923576','35.59670066914838','35.596700669148383','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','RLCETH','4h','0.002423000000000','0.002391000000000','0.072866446269747','0.071904115984715','30.072821407241854','30.072821407241854','test'),('2019-03-12 15:59:59','2019-03-19 19:59:59','RLCETH','4h','0.002598000000000','0.002887000000000','0.072866446269747','0.080972067121155','28.04713097372864','28.047130973728638','test'),('2019-03-22 07:59:59','2019-03-23 19:59:59','RLCETH','4h','0.002933000000000','0.002877000000000','0.074038225824798','0.072624608147952','25.243172800817593','25.243172800817593','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','RLCETH','4h','0.002873000000000','0.002861000000000','0.074038225824798','0.073728981581882','25.770353576330667','25.770353576330667','test'),('2019-03-24 19:59:59','2019-03-24 23:59:59','RLCETH','4h','0.002879000000000','0.002871000000000','0.074038225824798','0.073832492651266','25.71664669148941','25.716646691489409','test'),('2019-03-25 19:59:59','2019-03-30 03:59:59','RLCETH','4h','0.002896000000000','0.002953000000000','0.074038225824798','0.075495469910438','25.565685712982734','25.565685712982734','test'),('2019-03-30 15:59:59','2019-04-03 03:59:59','RLCETH','4h','0.003011000000000','0.002959000000000','0.074038225824798','0.072759584927126','24.589248032148127','24.589248032148127','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','RLCETH','4h','0.003133000000000','0.003123000000000','0.074038225824798','0.073801908474575','23.63173502227833','23.631735022278331','test'),('2019-04-04 11:59:59','2019-04-07 15:59:59','RLCETH','4h','0.003191000000000','0.003243000000000','0.074038225824798','0.075244740316459','23.20220176270699','23.202201762706991','test'),('2019-04-15 19:59:59','2019-04-16 03:59:59','RLCETH','4h','0.003174000000000','0.003009000000000','0.074038225824798','0.070189357752620','23.326473164712667','23.326473164712667','test'),('2019-04-17 15:59:59','2019-04-18 03:59:59','RLCETH','4h','0.003121000000000','0.002978000000000','0.074038225824798','0.070645894426866','23.722597188336433','23.722597188336433','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','RLCETH','4h','0.003037000000000','0.003027000000000','0.074038225824798','0.073794438449675','24.378737512281198','24.378737512281198','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','RLCETH','4h','0.003119000000000','0.003020000000000','0.074038225824798','0.071688182747961','23.73780885694069','23.737808856940688','test'),('2019-04-30 19:59:59','2019-04-30 23:59:59','RLCETH','4h','0.003098000000000','0.002946000000000','0.074038225824798','0.070405620813381','23.89871718037379','23.898717180373790','test'),('2019-05-13 07:59:59','2019-05-13 19:59:59','RLCETH','4h','0.003717000000000','0.003444000000000','0.074038225824798','0.068600390029756','19.918812436050043','19.918812436050043','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','RLCETH','4h','0.003534000000000','0.003403000000000','0.074038225824798','0.071293741505882','20.95026197645671','20.950261976456709','test'),('2019-05-15 15:59:59','2019-05-15 19:59:59','RLCETH','4h','0.003511000000000','0.002993000000000','0.074038225824798','0.063114898858906','21.08750379515751','21.087503795157510','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','RLCETH','4h','0.001786000000000','0.001784000000000','0.074038225824798','0.073955316277402','41.45477369809519','41.454773698095188','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','RLCETH','4h','0.001392000000000','0.001268000000000','0.074038225824798','0.067442866627761','53.18838062126294','53.188380621262937','test'),('2019-06-27 15:59:59','2019-06-27 19:59:59','RLCETH','4h','0.001277000000000','0.001257000000000','0.074038225824798','0.072878660815796','57.97825045011591','57.978250450115908','test'),('2019-06-28 19:59:59','2019-06-28 23:59:59','RLCETH','4h','0.001350000000000','0.001243000000000','0.074038225824798','0.068170010889055','54.843130240591115','54.843130240591115','test'),('2019-06-29 07:59:59','2019-06-29 11:59:59','RLCETH','4h','0.001283000000000','0.001274000000000','0.074038225824798','0.073518861808880','57.70711287981138','57.707112879811383','test'),('2019-06-30 15:59:59','2019-06-30 19:59:59','RLCETH','4h','0.001286000000000','0.001252000000000','0.074038225824798','0.072080761067377','57.572492865317265','57.572492865317265','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','RLCETH','4h','0.001252000000000','0.001248000000000','0.074038225824798','0.073801681972323','59.135963118848245','59.135963118848245','test'),('2019-07-06 19:59:59','2019-07-07 03:59:59','RLCETH','4h','0.001302000000000','0.001227000000000','0.074038225824798','0.069773351065305','56.864996793239634','56.864996793239634','test'),('2019-07-13 19:59:59','2019-07-13 23:59:59','RLCETH','4h','0.001149000000000','0.001127000000000','0.074038225824798','0.072620609664532','64.43709819390601','64.437098193906010','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','RLCETH','4h','0.001257000000000','0.001240000000000','0.074038225824798','0.073036913303699','58.90073653524105','58.900736535241052','test'),('2019-08-01 15:59:59','2019-08-03 03:59:59','RLCETH','4h','0.001404000000000','0.001338000000000','0.074038225824798','0.070557796405684','52.733779077491455','52.733779077491455','test'),('2019-08-07 07:59:59','2019-08-07 15:59:59','RLCETH','4h','0.001373000000000','0.001333000000000','0.074038225824798','0.071881249107397','53.92441793503132','53.924417935031322','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','RLCETH','4h','0.001290000000000','0.001235000000000','0.074038225824798','0.070881557281880','57.393973507595355','57.393973507595355','test'),('2019-08-18 03:59:59','2019-08-18 07:59:59','RLCETH','4h','0.001245000000000','0.001239000000000','0.074038225824798','0.073681415097932','59.468454477749404','59.468454477749404','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','RLCETH','4h','0.001208000000000','0.001190000000000','0.074038225824798','0.072935007228071','61.289922040395695','61.289922040395695','test'),('2019-08-24 07:59:59','2019-08-24 15:59:59','RLCETH','4h','0.001257000000000','0.001249000000000','0.074038225824798','0.073567019932516','58.90073653524105','58.900736535241052','test'),('2019-08-26 15:59:59','2019-08-27 15:59:59','RLCETH','4h','0.001217000000000','0.001221000000000','0.074038225824798','0.074281572499654','60.83666871388497','60.836668713884968','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','RLCETH','4h','0.001214000000000','0.001196000000000','0.074038225824798','0.072940459708780','60.98700644546788','60.987006445467877','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','RLCETH','4h','0.001216000000000','0.001221000000000','0.074038225824798','0.074342659319143','60.88669886907731','60.886698869077307','test'),('2019-08-30 03:59:59','2019-08-30 15:59:59','RLCETH','4h','0.001214000000000','0.001211000000000','0.074038225824798','0.073855264805462','60.98700644546788','60.987006445467877','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','RLCETH','4h','0.001220000000000','0.001205000000000','0.074038225824798','0.073127919769575','60.68707034819509','60.687070348195093','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','RLCETH','4h','0.001135000000000','0.001061000000000','0.074038225824798','0.069211063964855','65.23191702625375','65.231917026253754','test'),('2019-09-12 07:59:59','2019-09-14 23:59:59','RLCETH','4h','0.001156000000000','0.001108000000000','0.074038225824798','0.070963974233457','64.04690815293945','64.046908152939451','test'),('2019-09-18 15:59:59','2019-09-19 03:59:59','RLCETH','4h','0.001126000000000','0.001117000000000','0.049358817216532','0.048964297363114','43.83553926867851','43.835539268678509','test'),('2019-09-20 03:59:59','2019-09-20 07:59:59','RLCETH','4h','0.001116000000000','0.001120000000000','0.054758026386183','0.054954291713732','49.066331887260475','49.066331887260475','test'),('2019-09-21 07:59:59','2019-09-21 11:59:59','RLCETH','4h','0.001122000000000','0.001121000000000','0.054807092718070','0.054758245041851','48.84767621931367','48.847676219313669','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','RLCETH','4h','0.001124000000000','0.001067000000000','0.054807092718070','0.052027729475250','48.76075864596975','48.760758645969752','test'),('2019-09-25 07:59:59','2019-09-25 11:59:59','RLCETH','4h','0.001103000000000','0.001097000000000','0.054807092718070','0.054508958034200','49.689113978304626','49.689113978304626','test'),('2019-10-21 15:59:59','2019-10-23 15:59:59','RLCETH','4h','0.001809000000000','0.002015000000000','0.054807092718070','0.061048254188453','30.296900341663903','30.296900341663903','test'),('2019-11-10 11:59:59','2019-11-10 15:59:59','RLCETH','4h','0.003325000000000','0.003318000000000','0.055585796684938','0.055468773955075','16.717532837575472','16.717532837575472','test'),('2019-11-20 19:59:59','2019-11-21 15:59:59','RLCETH','4h','0.004002000000000','0.004051000000000','0.055585796684938','0.056266382401470','13.889504419024988','13.889504419024988','test'),('2019-11-22 19:59:59','2019-11-27 07:59:59','RLCETH','4h','0.004125000000000','0.004304000000000','0.055726687431606','0.058144887928638','13.50949998341956','13.509499983419561','test'),('2019-11-28 11:59:59','2019-11-28 23:59:59','RLCETH','4h','0.004713000000000','0.004447000000000','0.056331237555864','0.053151923066184','11.952310111577274','11.952310111577274','test'),('2019-11-29 19:59:59','2019-11-29 23:59:59','RLCETH','4h','0.004395000000000','0.004593000000000','0.056331237555864','0.058869027097630','12.817118897807509','12.817118897807509','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','RLCETH','4h','0.004421000000000','0.004155000000000','0.056331237555864','0.052941934414073','12.741741134554175','12.741741134554175','test'),('2019-12-08 11:59:59','2019-12-08 19:59:59','RLCETH','4h','0.003987000000000','0.004066000000000','0.056331237555864','0.057447407048443','14.128727754167043','14.128727754167043','test'),('2019-12-12 07:59:59','2019-12-12 11:59:59','RLCETH','4h','0.003898000000000','0.003849000000000','0.056331237555864','0.055623122973966','14.451317997912776','14.451317997912776','test'),('2019-12-12 15:59:59','2019-12-13 11:59:59','RLCETH','4h','0.003974000000000','0.003804000000000','0.056331237555864','0.053921496643811','14.174946541485657','14.174946541485657','test'),('2019-12-31 19:59:59','2020-01-01 03:59:59','RLCETH','4h','0.003211000000000','0.003186000000000','0.056331237555864','0.055892657381807','17.54320696227468','17.543206962274681','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 19:54:29
