-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 15:59:59','THETABTC','4h','0.000013290000000','0.000013110000000','0.001467500000000','0.001447624153499','110.42136945071483','110.421369450714835','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','THETABTC','4h','0.000013100000000','0.000012850000000','0.001467500000000','0.001439494274809','112.02290076335878','112.022900763358777','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','THETABTC','4h','0.000012770000000','0.000012670000000','0.001467500000000','0.001456008222396','114.9177760375881','114.917776037588098','test'),('2019-01-13 07:59:59','2019-01-13 11:59:59','THETABTC','4h','0.000012850000000','0.000012710000000','0.001467500000000','0.001451511673152','114.2023346303502','114.202334630350194','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','THETABTC','4h','0.000012980000000','0.000012580000000','0.001467500000000','0.001422276579353','113.05855161787366','113.058551617873661','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','THETABTC','4h','0.000012710000000','0.000012900000000','0.001467500000000','0.001489437450826','115.46026750590087','115.460267505900873','test'),('2019-01-19 15:59:59','2019-01-20 15:59:59','THETABTC','4h','0.000013360000000','0.000012970000000','0.001467500000000','0.001424661302395','109.84281437125748','109.842814371257475','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','THETABTC','4h','0.000023020000000','0.000022740000000','0.001467500000000','0.001449650304083','63.748913987836666','63.748913987836666','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','THETABTC','4h','0.000023240000000','0.000023630000000','0.001467500000000','0.001492126721170','63.14543889845095','63.145438898450948','test'),('2019-02-25 03:59:59','2019-03-04 03:59:59','THETABTC','4h','0.000025470000000','0.000032420000000','0.001467500000000','0.001867936788378','57.61680408323519','57.616804083235188','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','THETABTC','4h','0.000033250000000','0.000033260000000','0.001533931867515','0.001534393200407','46.13328924857894','46.133289248578940','test'),('2019-03-09 19:59:59','2019-03-09 23:59:59','THETABTC','4h','0.000033280000000','0.000035450000000','0.001534047200738','0.001634073715930','46.095168291413756','46.095168291413756','test'),('2019-04-10 03:59:59','2019-04-10 07:59:59','THETABTC','4h','0.000025140000000','0.000023720000000','0.001559053829536','0.001470992714264','62.01486990995426','62.014869909954257','test'),('2019-04-14 07:59:59','2019-04-14 11:59:59','THETABTC','4h','0.000023730000000','0.000023920000000','0.001559053829536','0.001571536772124','65.69969783126842','65.699697831268423','test'),('2019-04-16 03:59:59','2019-04-18 07:59:59','THETABTC','4h','0.000024310000000','0.000023880000000','0.001559053829536','0.001531476982695','64.1322019554093','64.132201955409300','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','THETABTC','4h','0.000014470000000','0.000014390000000','0.001559053829536','0.001550434319767','107.74387211720801','107.743872117208014','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','THETABTC','4h','0.000014590000000','0.000014030000000','0.001559053829536','0.001499213518053','106.85769907717615','106.857699077176150','test'),('2019-05-17 11:59:59','2019-05-19 23:59:59','THETABTC','4h','0.000014650000000','0.000014300000000','0.001559053829536','0.001521806809718','106.42005662361774','106.420056623617739','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','THETABTC','4h','0.000014970000000','0.000014710000000','0.001559053829536','0.001531976074314','104.14521239385437','104.145212393854365','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','THETABTC','4h','0.000014680000000','0.000014750000000','0.001559053829536','0.001566488009922','106.2025769438692','106.202576943869204','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','THETABTC','4h','0.000017350000000','0.000015490000000','0.001559053829536','0.001391916070289','89.85901034789624','89.859010347896245','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','THETABTC','4h','0.000015090000000','0.000015050000000','0.001559053829536','0.001554921148742','103.31701984996687','103.317019849966869','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','THETABTC','4h','0.000015500000000','0.000015140000000','0.001559053829536','0.001522843547044','100.58411803458064','100.584118034580641','test'),('2019-06-02 03:59:59','2019-06-03 07:59:59','THETABTC','4h','0.000016140000000','0.000015740000000','0.001559053829536','0.001520415568581','96.59565238760841','96.595652387608411','test'),('2019-07-02 03:59:59','2019-07-02 11:59:59','THETABTC','4h','0.000011620000000','0.000011210000000','0.001559053829536','0.001504044184948','134.16986484819276','134.169864848192759','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','THETABTC','4h','0.000010890000000','0.000010720000000','0.001559053829536','0.001534715982794','143.1638043651056','143.163804365105591','test'),('2019-07-13 11:59:59','2019-07-13 23:59:59','THETABTC','4h','0.000010210000000','0.000010120000000','0.001559053829536','0.001545310945632','152.69871004270323','152.698710042703226','test'),('2019-07-17 03:59:59','2019-07-31 15:59:59','THETABTC','4h','0.000011120000000','0.000012600000000','0.001559053829536','0.001766553799654','140.2026825122302','140.202682512230211','test'),('2019-08-12 07:59:59','2019-08-12 11:59:59','THETABTC','4h','0.000011160000000','0.000010950000000','0.001559053829536','0.001529716795109','139.70016393691756','139.700163936917562','test'),('2019-08-13 19:59:59','2019-08-13 23:59:59','THETABTC','4h','0.000011160000000','0.000011020000000','0.001559053829536','0.001539495806585','139.70016393691756','139.700163936917562','test'),('2019-08-17 03:59:59','2019-08-17 19:59:59','THETABTC','4h','0.000010930000000','0.000010980000000','0.001559053829536','0.001566185823267','142.6398746144556','142.639874614455607','test'),('2019-08-27 15:59:59','2019-08-28 15:59:59','THETABTC','4h','0.000012160000000','0.000011920000000','0.001559053829536','0.001528283030269','128.2116636131579','128.211663613157896','test'),('2019-08-29 19:59:59','2019-08-30 03:59:59','THETABTC','4h','0.000012070000000','0.000011870000000','0.001559053829536','0.001533220294664','129.16767436089478','129.167674360894779','test'),('2019-09-11 03:59:59','2019-09-11 07:59:59','THETABTC','4h','0.000010910000000','0.000010810000000','0.001559053829536','0.001544763693610','142.90135926086157','142.901359260861568','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','THETABTC','4h','0.000010650000000','0.000010280000000','0.001559053829536','0.001504889518087','146.3900309423474','146.390030942347408','test'),('2019-09-18 03:59:59','2019-09-19 23:59:59','THETABTC','4h','0.000010580000000','0.000010570000000','0.001559053829536','0.001557580243686','147.35858502230622','147.358585022306215','test'),('2019-09-26 23:59:59','2019-09-27 07:59:59','THETABTC','4h','0.000010540000000','0.000010280000000','0.001559053829536','0.001520595196170','147.91782063908917','147.917820639089172','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','THETABTC','4h','0.000010370000000','0.000010260000000','0.001559053829536','0.001542516132212','150.342702944648','150.342702944648011','test'),('2019-09-27 23:59:59','2019-09-28 03:59:59','THETABTC','4h','0.000010420000000','0.000010330000000','0.001559053829536','0.001545587913542','149.62128882303261','149.621288823032614','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','THETABTC','4h','0.000010180000000','0.000009970000000','0.001559053829536','0.001526892601225','153.14870624125734','153.148706241257344','test'),('2019-10-03 19:59:59','2019-10-03 23:59:59','THETABTC','4h','0.000010190000000','0.000010240000000','0.001559053829536','0.001566703750191','152.99841310461235','152.998413104612354','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','THETABTC','4h','0.000010490000000','0.000010330000000','0.001559053829536','0.001535274171507','148.6228626821735','148.622862682173491','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETABTC','4h','0.000010560000000','0.000010290000000','0.001559053829536','0.001519191657758','147.63767325151514','147.637673251515139','test'),('2019-10-13 23:59:59','2019-10-14 03:59:59','THETABTC','4h','0.000010420000000','0.000010230000000','0.001559053829536','0.001530625784660','149.62128882303261','149.621288823032614','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','THETABTC','4h','0.000010350000000','0.000010480000000','0.001559053829536','0.001578636148168','150.63322024502415','150.633220245024148','test'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETABTC','4h','0.000010620000000','0.000010470000000','0.001559053829536','0.001537033295221','146.8035621032015','146.803562103201500','test'),('2019-10-20 03:59:59','2019-10-20 07:59:59','THETABTC','4h','0.000010480000000','0.000010430000000','0.001559053829536','0.001551615595616','148.7646783908397','148.764678390839691','test'),('2019-10-21 23:59:59','2019-10-26 03:59:59','THETABTC','4h','0.000010540000000','0.000010200000000','0.001559053829536','0.001508761770519','147.91782063908917','147.917820639089172','test'),('2019-10-29 03:59:59','2019-10-29 11:59:59','THETABTC','4h','0.000011180000000','0.000010730000000','0.001559053829536','0.001496301215646','139.45025308908765','139.450253089087653','test'),('2019-10-29 19:59:59','2019-10-29 23:59:59','THETABTC','4h','0.000011140000000','0.000010750000000','0.001559053829536','0.001504472950405','139.95097213070017','139.950972130700166','test'),('2019-11-09 11:59:59','2019-11-09 19:59:59','THETABTC','4h','0.000010320000000','0.000010200000000','0.001559053829536','0.001540925296634','151.0711075131783','151.071107513178305','test'),('2019-11-12 19:59:59','2019-11-13 11:59:59','THETABTC','4h','0.000010200000000','0.000010240000000','0.001559053829536','0.001565167766122','152.84841466039214','152.848414660392137','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','THETABTC','4h','0.000010240000000','0.000010680000000','0.001559053829536','0.001626044423774','152.251350540625','152.251350540624998','test'),('2019-11-21 23:59:59','2019-11-22 07:59:59','THETABTC','4h','0.000010780000000','0.000010520000000','0.001559053829536','0.001521451418063','144.6246595116883','144.624659511688293','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','THETABTC','4h','0.000010450000000','0.000010180000000','0.001559053829536','0.001518772055950','149.19175402258372','149.191754022583723','test'),('2019-12-05 15:59:59','2019-12-07 07:59:59','THETABTC','4h','0.000010560000000','0.000010330000000','0.001559053829536','0.001525097164688','147.63767325151514','147.637673251515139','test'),('2019-12-11 03:59:59','2019-12-22 19:59:59','THETABTC','4h','0.000010640000000','0.000012980000000','0.001559053829536','0.001901928449941','146.52761555789473','146.527615557894734','test'),('2019-12-31 03:59:59','2019-12-31 07:59:59','THETABTC','4h','0.000012680000000','0.000012530000000','0.001559053829536','0.001540610763729','122.95377204542585','122.953772045425850','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:16:35
