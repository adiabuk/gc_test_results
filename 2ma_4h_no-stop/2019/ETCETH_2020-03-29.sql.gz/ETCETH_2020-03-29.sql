-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 07:59:59','2019-01-11 15:59:59','ETCETH','4h','0.035193000000000','0.035487000000000','0.072144500000000','0.072747190392976','2.0499673230471966','2.049967323047197','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ETCETH','4h','0.035154000000000','0.035032000000000','0.072295172598244','0.072044276226366','2.056527638341128','2.056527638341128','test'),('2019-01-17 03:59:59','2019-01-17 11:59:59','ETCETH','4h','0.035141000000000','0.035560000000000','0.072295172598244','0.073157176448979','2.057288426574201','2.057288426574201','test'),('2019-01-31 19:59:59','2019-02-01 15:59:59','ETCETH','4h','0.036879000000000','0.036593000000000','0.072447949467958','0.071886109029013','1.9644770592466783','1.964477059246678','test'),('2019-02-07 15:59:59','2019-02-08 11:59:59','ETCETH','4h','0.036930000000000','0.036032000000000','0.072447949467958','0.070686285275642','1.9617641339820744','1.961764133982074','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','ETCETH','4h','0.031730000000000','0.031591000000000','0.072447949467958','0.072130575847534','2.2832634562861016','2.283263456286102','test'),('2019-03-02 07:59:59','2019-03-05 15:59:59','ETCETH','4h','0.031841000000000','0.031803000000000','0.072447949467958','0.072361487922159','2.2753038368128515','2.275303836812852','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','ETCETH','4h','0.031729000000000','0.031694000000000','0.072447949467958','0.072368032728339','2.283335417692269','2.283335417692269','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','ETCETH','4h','0.031846000000000','0.031653000000000','0.072447949467958','0.072008884773889','2.274946601392891','2.274946601392891','test'),('2019-03-16 15:59:59','2019-03-16 19:59:59','ETCETH','4h','0.032003000000000','0.031840000000000','0.072447949467958','0.072078952318838','2.2637861909182893','2.263786190918289','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','ETCETH','4h','0.032078000000000','0.031773000000000','0.072447949467958','0.071759108998236','2.2584933433492735','2.258493343349274','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','ETCETH','4h','0.031909000000000','0.031873000000000','0.072447949467958','0.072366213086973','2.270455027357736','2.270455027357736','test'),('2019-03-19 15:59:59','2019-03-28 11:59:59','ETCETH','4h','0.032903000000000','0.034118000000000','0.072447949467958','0.075123214902829','2.2018645554495944','2.201864555449594','test'),('2019-03-29 15:59:59','2019-03-29 23:59:59','ETCETH','4h','0.034912000000000','0.034037000000000','0.072447949467958','0.070632185381556','2.07515895588789','2.075158955887890','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','ETCETH','4h','0.034762000000000','0.033837000000000','0.072447949467958','0.070520144587403','2.08411338438404','2.084113384384040','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ETCETH','4h','0.034241000000000','0.033860000000000','0.072447949467958','0.071641820302709','2.1158245807061125','2.115824580706112','test'),('2019-04-05 03:59:59','2019-04-06 11:59:59','ETCETH','4h','0.034436000000000','0.034531000000000','0.072447949467958','0.072647814585842','2.103843346148159','2.103843346148159','test'),('2019-04-28 23:59:59','2019-05-01 19:59:59','ETCETH','4h','0.035645000000000','0.036325000000000','0.072447949467958','0.073830039680841','2.0324856071807544','2.032485607180754','test'),('2019-05-03 15:59:59','2019-05-03 23:59:59','ETCETH','4h','0.035948000000000','0.036119000000000','0.072447949467958','0.072792575020395','2.015354107821242','2.015354107821242','test'),('2019-05-04 11:59:59','2019-05-04 15:59:59','ETCETH','4h','0.035815000000000','0.035500000000000','0.072447949467958','0.071810755440807','2.022838181431188','2.022838181431188','test'),('2019-05-27 23:59:59','2019-05-29 03:59:59','ETCETH','4h','0.030074000000000','0.029842000000000','0.072447949467958','0.071889063909783','2.408989474893862','2.408989474893862','test'),('2019-06-07 19:59:59','2019-06-11 07:59:59','ETCETH','4h','0.032816000000000','0.033305000000000','0.072447949467958','0.073527515755435','2.2077020193795103','2.207702019379510','test'),('2019-06-13 23:59:59','2019-06-14 03:59:59','ETCETH','4h','0.033559000000000','0.033279000000000','0.072447949467958','0.071843478957781','2.158823250631962','2.158823250631962','test'),('2019-07-16 11:59:59','2019-07-18 15:59:59','ETCETH','4h','0.026887000000000','0.026394000000000','0.072447949467958','0.071119543952739','2.6945345136295606','2.694534513629561','test'),('2019-07-31 19:59:59','2019-07-31 23:59:59','ETCETH','4h','0.028009000000000','0.027684000000000','0.072447949467958','0.071607305975613','2.586595361061016','2.586595361061016','test'),('2019-08-04 19:59:59','2019-08-04 23:59:59','ETCETH','4h','0.027578000000000','0.027467000000000','0.072447949467958','0.072156350280528','2.627019706576184','2.627019706576184','test'),('2019-08-08 19:59:59','2019-08-09 11:59:59','ETCETH','4h','0.027276000000000','0.027469000000000','0.072447949467958','0.072960577941609','2.656106081095395','2.656106081095395','test'),('2019-08-12 11:59:59','2019-08-12 15:59:59','ETCETH','4h','0.027233000000000','0.027499000000000','0.072447949467958','0.073155589263738','2.6602999841353507','2.660299984135351','test'),('2019-08-20 07:59:59','2019-08-29 15:59:59','ETCETH','4h','0.029691000000000','0.035752000000000','0.072447949467958','0.087237179258982','2.4400643113387224','2.440064311338722','test'),('2019-08-30 03:59:59','2019-09-07 03:59:59','ETCETH','4h','0.035706000000000','0.038415000000000','0.074571479221034','0.080229187651264','2.0884859469286527','2.088485946928653','test'),('2019-10-14 07:59:59','2019-10-14 11:59:59','ETCETH','4h','0.026264000000000','0.026298000000000','0.075985906328592','0.076084273706568','2.8931581757764233','2.893158175776423','test'),('2019-10-20 07:59:59','2019-10-20 11:59:59','ETCETH','4h','0.025832000000000','0.025724000000000','0.076010498173086','0.075692708849662','2.9424937354090264','2.942493735409026','test'),('2019-10-20 19:59:59','2019-10-20 23:59:59','ETCETH','4h','0.025804000000000','0.025726000000000','0.076010498173086','0.075780734614820','2.945686644438304','2.945686644438304','test'),('2019-10-21 15:59:59','2019-10-22 23:59:59','ETCETH','4h','0.026039000000000','0.026002000000000','0.076010498173086','0.075902491397388','2.919102045896002','2.919102045896002','test'),('2019-10-27 15:59:59','2019-10-27 19:59:59','ETCETH','4h','0.026215000000000','0.025958000000000','0.076010498173086','0.075265325637115','2.89950403101606','2.899504031016060','test'),('2019-10-30 07:59:59','2019-10-30 19:59:59','ETCETH','4h','0.026335000000000','0.026061000000000','0.076010498173086','0.075219654182221','2.88629193746292','2.886291937462920','test'),('2019-11-05 19:59:59','2019-11-05 23:59:59','ETCETH','4h','0.026601000000000','0.026606000000000','0.076010498173086','0.076024785323602','2.857430103119657','2.857430103119657','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','ETCETH','4h','0.026574000000000','0.026950000000000','0.076010498173086','0.077085983508868','2.8603333398466924','2.860333339846692','test'),('2019-11-21 15:59:59','2019-11-22 15:59:59','ETCETH','4h','0.025765000000000','0.026051000000000','0.076010498173086','0.076854239779044','2.9501454753769067','2.950145475376907','test'),('2019-11-27 19:59:59','2019-11-27 23:59:59','ETCETH','4h','0.025983000000000','0.025891000000000','0.076010498173086','0.075741361975113','2.9253934562246853','2.925393456224685','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','ETCETH','4h','0.025996000000000','0.026041000000000','0.076010498173086','0.076142075047135','2.923930534431682','2.923930534431682','test'),('2019-12-01 03:59:59','2019-12-01 07:59:59','ETCETH','4h','0.026065000000000','0.026204000000000','0.076010498173086','0.076415848614139','2.91619022340633','2.916190223406330','test'),('2019-12-03 07:59:59','2019-12-03 11:59:59','ETCETH','4h','0.026103000000000','0.026148000000000','0.076012930429376','0.076143972143712','2.9120380963634913','2.912038096363491','test'),('2019-12-06 11:59:59','2019-12-08 03:59:59','ETCETH','4h','0.026250000000000','0.026149000000000','0.076045690857960','0.075753096009326','2.896978699350866','2.896978699350866','test'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ETCETH','4h','0.026159000000000','0.025878000000000','0.076045690857960','0.075228807982809','2.9070564952008864','2.907056495200886','test'),('2019-12-11 03:59:59','2019-12-11 07:59:59','ETCETH','4h','0.025999000000000','0.025917000000000','0.076045690857960','0.075805845223499','2.924946761720066','2.924946761720066','test'),('2019-12-11 11:59:59','2019-12-11 15:59:59','ETCETH','4h','0.026035000000000','0.026414000000000','0.076045690857960','0.077152712822053','2.920902279929326','2.920902279929326','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:03:20
