-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 03:59:59','2019-01-13 07:59:59','WANETH','4h','0.002495000000000','0.002481000000000','0.072144500000000','0.071739681162325','28.915631262525054','28.915631262525054','test'),('2019-01-16 11:59:59','2019-01-20 15:59:59','WANETH','4h','0.002579000000000','0.002626000000000','0.072144500000000','0.073459269872043','27.97382706475378','27.973827064753781','test'),('2019-02-06 15:59:59','2019-02-07 03:59:59','WANETH','4h','0.002660000000000','0.002614000000000','0.072371987758592','0.071120442105624','27.207514194959394','27.207514194959394','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','WANETH','4h','0.002610000000000','0.002587000000000','0.072371987758592','0.071734226946926','27.72873094198927','27.728730941989269','test'),('2019-02-26 07:59:59','2019-03-05 15:59:59','WANETH','4h','0.002183000000000','0.002272000000000','0.072371987758592','0.075322563530701','33.152536765273474','33.152536765273474','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','WANETH','4h','0.002269000000000','0.002268000000000','0.072637305085461','0.072605292170042','32.01291541888971','32.012915418889712','test'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANETH','4h','0.002292000000000','0.002912000000000','0.072637305085461','0.092286139794443','31.691668885454185','31.691668885454185','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','WANETH','4h','0.003000000000000','0.003001000000000','0.077541510533851','0.077567357704029','25.8471701779505','25.847170177950499','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WANETH','4h','0.002993000000000','0.002811000000000','0.077547972326396','0.072832392318576','25.909780262745077','25.909780262745077','test'),('2019-03-23 03:59:59','2019-03-23 11:59:59','WANETH','4h','0.002963000000000','0.002930000000000','0.077547972326396','0.076684292580608','26.17211350873979','26.172113508739791','test'),('2019-03-26 23:59:59','2019-03-27 15:59:59','WANETH','4h','0.002973000000000','0.002911000000000','0.077547972326396','0.075930759314544','26.084080836325597','26.084080836325597','test'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANETH','4h','0.002974000000000','0.002955000000000','0.077547972326396','0.077052541433927','26.07531012992468','26.075310129924681','test'),('2019-03-31 07:59:59','2019-03-31 11:59:59','WANETH','4h','0.002955000000000','0.003002000000000','0.077547972326396','0.078781391852400','26.24296863837428','26.242968638374279','test'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANETH','4h','0.002591000000000','0.002594000000000','0.077547972326396','0.077637761564906','29.92974616997144','29.929746169971441','test'),('2019-04-22 23:59:59','2019-04-23 03:59:59','WANETH','4h','0.002534000000000','0.002497000000000','0.077547972326396','0.076415661759673','30.602988289816892','30.602988289816892','test'),('2019-05-01 07:59:59','2019-05-01 15:59:59','WANETH','4h','0.002363000000000','0.002311000000000','0.077547972326396','0.075841457488913','32.81759302852137','32.817593028521372','test'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANETH','4h','0.001722000000000','0.001713000000000','0.077547972326396','0.077142669335143','45.033665694771194','45.033665694771194','test'),('2019-06-02 11:59:59','2019-06-11 19:59:59','WANETH','4h','0.001771000000000','0.001830000000000','0.077547972326396','0.080131445148111','43.78767494432298','43.787674944322980','test'),('2019-06-12 11:59:59','2019-06-12 19:59:59','WANETH','4h','0.001837000000000','0.001816000000000','0.077547972326396','0.076661468560008','42.21446506608383','42.214465066083832','test'),('2019-06-13 07:59:59','2019-06-13 15:59:59','WANETH','4h','0.001831000000000','0.001801000000000','0.077547972326396','0.076277388399694','42.352797556742765','42.352797556742765','test'),('2019-07-07 07:59:59','2019-07-07 19:59:59','WANETH','4h','0.001336000000000','0.001207000000000','0.077547972326396','0.070060181585299','58.044889465865275','58.044889465865275','test'),('2019-07-14 15:59:59','2019-07-14 19:59:59','WANETH','4h','0.001165000000000','0.001163000000000','0.077547972326396','0.077414842760170','66.56478311278626','66.564783112786259','test'),('2019-07-20 19:59:59','2019-07-21 15:59:59','WANETH','4h','0.001148000000000','0.001144000000000','0.077547972326396','0.077277770332227','67.5504985421568','67.550498542156802','test'),('2019-08-10 03:59:59','2019-08-10 07:59:59','WANETH','4h','0.001158000000000','0.001146000000000','0.077547972326396','0.076744366395553','66.9671609036235','66.967160903623494','test'),('2019-08-10 11:59:59','2019-08-10 15:59:59','WANETH','4h','0.001182000000000','0.001167000000000','0.077547972326396','0.076563861002457','65.60742159593569','65.607421595935691','test'),('2019-08-11 03:59:59','2019-08-11 07:59:59','WANETH','4h','0.001175000000000','0.001159000000000','0.077547972326396','0.076491999937271','65.99827432033702','65.998274320337018','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','WANETH','4h','0.001163000000000','0.001147000000000','0.077547972326396','0.076481104263436','66.67925393499226','66.679253934992261','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','WANETH','4h','0.001179000000000','0.001151000000000','0.077547972326396','0.075706290201596','65.77436159999661','65.774361599996610','test'),('2019-08-15 15:59:59','2019-08-15 23:59:59','WANETH','4h','0.001172000000000','0.001152000000000','0.077547972326396','0.076224628088744','66.16721188259044','66.167211882590436','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','WANETH','4h','0.001154000000000','0.001192000000000','0.077547972326396','0.080101545071979','67.19928277850606','67.199282778506060','test'),('2019-08-30 15:59:59','2019-09-03 15:59:59','WANETH','4h','0.002236000000000','0.002043000000000','0.077547972326396','0.070854430886774','34.68156186332558','34.681561863325577','test'),('2019-10-02 23:59:59','2019-10-03 03:59:59','WANETH','4h','0.001169000000000','0.001169000000000','0.077547972326396','0.077547972326396','66.33701653241745','66.337016532417451','test'),('2019-10-05 03:59:59','2019-10-05 15:59:59','WANETH','4h','0.001167000000000','0.001150000000000','0.077547972326396','0.076418310347348','66.45070464986803','66.450704649868030','test'),('2019-10-08 19:59:59','2019-10-10 11:59:59','WANETH','4h','0.001171000000000','0.001169000000000','0.077547972326396','0.077415524892875','66.22371676037234','66.223716760372341','test'),('2019-10-15 03:59:59','2019-10-15 07:59:59','WANETH','4h','0.001148000000000','0.001147000000000','0.077547972326396','0.077480421827854','67.5504985421568','67.550498542156802','test'),('2019-10-20 19:59:59','2019-10-20 23:59:59','WANETH','4h','0.001134000000000','0.001137000000000','0.077547972326396','0.077753125692339','68.38445531428219','68.384455314282192','test'),('2019-10-21 15:59:59','2019-10-23 15:59:59','WANETH','4h','0.001152000000000','0.001109000000000','0.077547972326396','0.074653386553796','67.31594819999653','67.315948199996527','test'),('2019-10-26 03:59:59','2019-10-26 11:59:59','WANETH','4h','0.001178000000000','0.001140000000000','0.077547972326396','0.075046424831996','65.83019722104923','65.830197221049232','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','WANETH','4h','0.001143000000000','0.001110000000000','0.077547972326396','0.075309054490201','67.84599503621698','67.845995036216976','test'),('2019-10-27 15:59:59','2019-10-29 07:59:59','WANETH','4h','0.001266000000000','0.001199000000000','0.077547972326396','0.073443932716705','61.25432253269826','61.254322532698261','test'),('2019-10-30 19:59:59','2019-11-04 23:59:59','WANETH','4h','0.001210000000000','0.001232000000000','0.077547972326396','0.078957935459603','64.0892333276','64.089233327599999','test'),('2019-11-12 07:59:59','2019-11-12 15:59:59','WANETH','4h','0.001210000000000','0.001198000000000','0.077547972326396','0.076778901526465','64.0892333276','64.089233327599999','test'),('2019-11-16 11:59:59','2019-11-19 11:59:59','WANETH','4h','0.001222000000000','0.001231000000000','0.077547972326396','0.078119111238784','63.45987915417021','63.459879154170210','test'),('2019-12-08 15:59:59','2019-12-08 19:59:59','WANETH','4h','0.001308000000000','0.001283000000000','0.077547972326396','0.076065786310983','59.28744061651071','59.287440616510708','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','WANETH','4h','0.001274000000000','0.001255000000000','0.077547972326396','0.076391448406301','60.86968000502041','60.869680005020413','test'),('2019-12-16 07:59:59','2019-12-16 11:59:59','WANETH','4h','0.001264000000000','0.001296000000000','0.077547972326396','0.079511212132128','61.351243929110765','61.351243929110765','test'),('2019-12-24 07:59:59','2019-12-24 11:59:59','WANETH','4h','0.001394000000000','0.001367000000000','0.077547972326396','0.076045967123517','55.629822328835004','55.629822328835004','test'),('2019-12-25 03:59:59','2019-12-25 07:59:59','WANETH','4h','0.001397000000000','0.001377000000000','0.077547972326396','0.076437765134894','55.51035957508661','55.510359575086611','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','WANETH','4h','0.001395000000000','0.001386000000000','0.077547972326396','0.077047662827516','55.58994431999714','55.589944319997137','test'),('2019-12-31 03:59:59','2019-12-31 07:59:59','WANETH','4h','0.001385000000000','0.001365000000000','0.077547972326396','0.076428146011213','55.991315759130686','55.991315759130686','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 21:00:06
