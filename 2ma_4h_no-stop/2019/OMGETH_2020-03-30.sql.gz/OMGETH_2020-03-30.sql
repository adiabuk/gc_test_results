-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 15:59:59','2019-01-11 19:59:59','OMGETH','4h','0.010232000000000','0.010295000000000','0.072144500000000','0.072588704798671','7.05086982017201','7.050869820172010','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','OMGETH','4h','0.010215000000000','0.010256000000000','0.072255551199668','0.072545563691023','7.073475398890627','7.073475398890627','test'),('2019-01-16 03:59:59','2019-01-16 07:59:59','OMGETH','4h','0.010224000000000','0.010235000000000','0.072328054322506','0.072405872064833','7.074340211512763','7.074340211512763','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','OMGETH','4h','0.010628000000000','0.010578000000000','0.072347508758088','0.072007145995771','6.807255246338751','6.807255246338751','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','OMGETH','4h','0.010394000000000','0.010219000000000','0.072347508758088','0.071129420049923','6.960506903799114','6.960506903799114','test'),('2019-02-16 19:59:59','2019-02-17 11:59:59','OMGETH','4h','0.010050000000000','0.009597000000000','0.072347508758088','0.069086471796156','7.198757090357015','7.198757090357015','test'),('2019-02-24 15:59:59','2019-02-24 19:59:59','OMGETH','4h','0.009217000000000','0.009268000000000','0.072347508758088','0.072747825883689','7.849355403937073','7.849355403937073','test'),('2019-03-08 23:59:59','2019-04-02 07:59:59','OMGETH','4h','0.009346000000000','0.012757000000000','0.072347508758088','0.098752104560981','7.741013134826449','7.741013134826449','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','OMGETH','4h','0.012800000000000','0.012386000000000','0.077843864882108','0.075326102377327','6.0815519439147065','6.081551943914707','test'),('2019-04-04 07:59:59','2019-04-08 03:59:59','OMGETH','4h','0.013488000000000','0.012985000000000','0.077843864882108','0.074940879707456','5.771342295529952','5.771342295529952','test'),('2019-05-02 19:59:59','2019-05-03 07:59:59','OMGETH','4h','0.010356000000000','0.010123000000000','0.077843864882108','0.076092453090149','7.516788806692545','7.516788806692545','test'),('2019-05-04 03:59:59','2019-05-04 07:59:59','OMGETH','4h','0.010446000000000','0.010188000000000','0.077843864882108','0.075921242142343','7.452026123119662','7.452026123119662','test'),('2019-05-27 19:59:59','2019-05-27 23:59:59','OMGETH','4h','0.008205000000000','0.008140000000000','0.077843864882108','0.077227185879386','9.487369272651797','9.487369272651797','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','OMGETH','4h','0.008298000000000','0.008228000000000','0.077843864882108','0.077187192124606','9.381039392878765','9.381039392878765','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','OMGETH','4h','0.008305000000000','0.008161000000000','0.077843864882108','0.076494133811304','9.37313243613582','9.373132436135821','test'),('2019-06-13 23:59:59','2019-06-14 15:59:59','OMGETH','4h','0.008215000000000','0.008125000000000','0.077843864882108','0.076991041042864','9.475820436044796','9.475820436044796','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','OMGETH','4h','0.007657000000000','0.007839000000000','0.077843864882108','0.079694143504094','10.166366054865874','10.166366054865874','test'),('2019-06-25 19:59:59','2019-06-27 19:59:59','OMGETH','4h','0.007784000000000','0.008134000000000','0.077843864882108','0.081344038662778','10.000496516200924','10.000496516200924','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','OMGETH','4h','0.008277000000000','0.008318000000000','0.077843864882108','0.078229463342923','9.40484050768491','9.404840507684909','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','OMGETH','4h','0.008211000000000','0.008204000000000','0.077843864882108','0.077777501825943','9.480436595068566','9.480436595068566','test'),('2019-07-04 11:59:59','2019-07-04 15:59:59','OMGETH','4h','0.008242000000000','0.008297000000000','0.077843864882108','0.078363327702845','9.444778558858044','9.444778558858044','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','OMGETH','4h','0.008244000000000','0.008137000000000','0.077843864882108','0.076833518746447','9.442487249163998','9.442487249163998','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','OMGETH','4h','0.008260000000000','0.008134000000000','0.077843864882108','0.076656416095771','9.424196716962227','9.424196716962227','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','OMGETH','4h','0.008208000000000','0.008053000000000','0.077843864882108','0.076373860123735','9.483901666923488','9.483901666923488','test'),('2019-07-08 15:59:59','2019-07-09 03:59:59','OMGETH','4h','0.008367000000000','0.008079000000000','0.077843864882108','0.075164405925965','9.303676931051513','9.303676931051513','test'),('2019-07-20 11:59:59','2019-07-23 19:59:59','OMGETH','4h','0.007231000000000','0.007454000000000','0.077843864882108','0.080244526183271','10.765297314632555','10.765297314632555','test'),('2019-08-18 03:59:59','2019-08-18 07:59:59','OMGETH','4h','0.006459000000000','0.006450000000000','0.077843864882108','0.077735396886452','12.051999517279453','12.051999517279453','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','OMGETH','4h','0.006514000000000','0.006309000000000','0.077843864882108','0.075394065634206','11.950240233667179','11.950240233667179','test'),('2019-08-22 23:59:59','2019-08-23 15:59:59','OMGETH','4h','0.006484000000000','0.006376000000000','0.077843864882108','0.076547267502826','12.005531289652682','12.005531289652682','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','OMGETH','4h','0.006400000000000','0.006528000000000','0.077843864882108','0.079400742179750','12.163103887829374','12.163103887829374','test'),('2019-08-30 23:59:59','2019-08-31 03:59:59','OMGETH','4h','0.006407000000000','0.006365000000000','0.077843864882108','0.077333572650947','12.14981502764289','12.149815027642889','test'),('2019-10-05 19:59:59','2019-10-05 23:59:59','OMGETH','4h','0.004806000000000','0.004763000000000','0.077843864882108','0.077147384193400','16.197225318790675','16.197225318790675','test'),('2019-10-06 03:59:59','2019-10-09 15:59:59','OMGETH','4h','0.004911000000000','0.004765000000000','0.077843864882108','0.075529630658368','15.850919340685808','15.850919340685808','test'),('2019-10-20 15:59:59','2019-10-21 11:59:59','OMGETH','4h','0.004746000000000','0.004582000000000','0.077843864882108','0.075153937819178','16.40199428615845','16.401994286158448','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','OMGETH','4h','0.004690000000000','0.004585000000000','0.077843864882108','0.076101091787732','16.59783899405288','16.597838994052879','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','OMGETH','4h','0.004789000000000','0.004634000000000','0.077843864882108','0.075324382932489','16.254722255608268','16.254722255608268','test'),('2019-11-10 19:59:59','2019-11-11 03:59:59','OMGETH','4h','0.005331000000000','0.005215000000000','0.077843864882108','0.076150019763683','14.602113089872068','14.602113089872068','test'),('2019-11-13 15:59:59','2019-11-13 23:59:59','OMGETH','4h','0.005311000000000','0.005234000000000','0.077843864882108','0.076715268083780','14.657101276992657','14.657101276992657','test'),('2019-11-14 15:59:59','2019-11-18 15:59:59','OMGETH','4h','0.005326000000000','0.005393000000000','0.077843864882108','0.078823124917238','14.61582141984754','14.615821419847540','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','OMGETH','4h','0.005311000000000','0.005254000000000','0.077843864882108','0.077008410109319','14.657101276992657','14.657101276992657','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','OMGETH','4h','0.005300000000000','0.005225000000000','0.077843864882108','0.076742300756418','14.687521675869434','14.687521675869434','test'),('2019-11-28 19:59:59','2019-11-28 23:59:59','OMGETH','4h','0.005197000000000','0.005145000000000','0.077843864882108','0.077064976874821','14.978615524746584','14.978615524746584','test'),('2019-11-29 15:59:59','2019-11-30 07:59:59','OMGETH','4h','0.005236000000000','0.005136000000000','0.077843864882108','0.076357160052427','14.867048296812069','14.867048296812069','test'),('2019-12-07 03:59:59','2019-12-07 07:59:59','OMGETH','4h','0.005050000000000','0.005026000000000','0.077843864882108','0.077473913841084','15.414626709328317','15.414626709328317','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','OMGETH','4h','0.005087000000000','0.004990000000000','0.077843864882108','0.076359521478616','15.302509314351875','15.302509314351875','test'),('2019-12-11 07:59:59','2019-12-11 15:59:59','OMGETH','4h','0.005074000000000','0.005028000000000','0.077843864882108','0.077138145965163','15.341715585752462','15.341715585752462','test'),('2019-12-12 03:59:59','2019-12-12 07:59:59','OMGETH','4h','0.005058000000000','0.005052000000000','0.077843864882108','0.077751523405380','15.390246121413206','15.390246121413206','test'),('2019-12-19 03:59:59','2019-12-19 23:59:59','OMGETH','4h','0.005020000000000','0.004932000000000','0.077843864882108','0.076479271234772','15.506745992451792','15.506745992451792','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','OMGETH','4h','0.004974000000000','0.004923000000000','0.077843864882108','0.077045707039529','15.650153776057095','15.650153776057095','test'),('2019-12-27 23:59:59','2019-12-28 03:59:59','OMGETH','4h','0.004941000000000','0.004930000000000','0.077843864882108','0.077670563422140','15.754678178933009','15.754678178933009','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  5:16:09
