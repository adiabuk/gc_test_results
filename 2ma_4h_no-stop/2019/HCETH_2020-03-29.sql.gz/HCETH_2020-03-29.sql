-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-07 11:59:59','2019-02-08 19:59:59','HCETH','4h','0.008682000000000','0.009187000000000','0.072144500000000','0.076340880154342','8.309663671964985','8.309663671964985','test'),('2019-02-15 11:59:59','2019-02-15 15:59:59','HCETH','4h','0.009391000000000','0.009142000000000','0.073193595038585','0.071252885298982','7.79401501848424','7.794015018484240','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','HCETH','4h','0.009208000000000','0.009301000000000','0.073193595038585','0.073932843989344','7.94891344902096','7.948913449020960','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','HCETH','4h','0.008514000000000','0.008266000000000','0.073193595038585','0.071061575826749','8.596851660627788','8.596851660627788','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','HCETH','4h','0.008387000000000','0.008416000000000','0.073193595038585','0.073446678889321','8.727029335708238','8.727029335708238','test'),('2019-03-05 07:59:59','2019-03-05 15:59:59','HCETH','4h','0.008582000000000','0.008258000000000','0.073193595038585','0.070430285228226','8.528733982589722','8.528733982589722','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','HCETH','4h','0.008411000000000','0.008326000000000','0.073193595038585','0.072453914194657','8.70212757562537','8.702127575625370','test'),('2019-03-08 11:59:59','2019-03-20 15:59:59','HCETH','4h','0.008718000000000','0.009494000000000','0.073193595038585','0.079708647774298','8.395686515093484','8.395686515093484','test'),('2019-03-26 19:59:59','2019-03-27 07:59:59','HCETH','4h','0.009958000000000','0.009846000000000','0.073193595038585','0.072370369225739','7.350230471840229','7.350230471840229','test'),('2019-03-28 19:59:59','2019-03-29 11:59:59','HCETH','4h','0.010016000000000','0.009836000000000','0.073193595038585','0.071878214936055','7.307667236280451','7.307667236280451','test'),('2019-03-31 07:59:59','2019-03-31 11:59:59','HCETH','4h','0.009848000000000','0.009855000000000','0.073193595038585','0.073245621355123','7.432330934056153','7.432330934056153','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','HCETH','4h','0.009988000000000','0.009962000000000','0.073193595038585','0.073003063053102','7.328153287803864','7.328153287803864','test'),('2019-04-05 19:59:59','2019-04-05 23:59:59','HCETH','4h','0.009918000000000','0.009812000000000','0.073193595038585','0.072411328344283','7.379874474549808','7.379874474549808','test'),('2019-04-06 03:59:59','2019-04-06 11:59:59','HCETH','4h','0.009986000000000','0.009834000000000','0.073193595038585','0.072079492650655','7.329620973221009','7.329620973221009','test'),('2019-04-07 03:59:59','2019-04-07 15:59:59','HCETH','4h','0.010152000000000','0.009724000000000','0.073193595038585','0.070107813057053','7.209770984888199','7.209770984888199','test'),('2019-05-30 11:59:59','2019-07-01 11:59:59','HCETH','4h','0.005197000000000','0.014674000000000','0.073193595038585','0.206665925263844','14.083816632400422','14.083816632400422','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','HCETH','4h','0.015966000000000','0.015777000000000','0.104729778415750','0.103490023428867','6.559550195149036','6.559550195149036','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','HCETH','4h','0.014984000000000','0.014281000000000','0.104729778415750','0.099816201652117','6.98944063105646','6.989440631056460','test'),('2019-07-21 03:59:59','2019-07-21 19:59:59','HCETH','4h','0.014486000000000','0.014124000000000','0.104729778415750','0.102112618413921','7.229723761959823','7.229723761959823','test'),('2019-07-24 07:59:59','2019-07-24 11:59:59','HCETH','4h','0.014361000000000','0.014060000000000','0.104729778415750','0.102534690099954','7.292652211945547','7.292652211945547','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','HCETH','4h','0.014148000000000','0.013975000000000','0.104729778415750','0.103449155595145','7.402444049742012','7.402444049742012','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','HCETH','4h','0.014041000000000','0.014144000000000','0.104729778415750','0.105498040446718','7.458854669592622','7.458854669592622','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','HCETH','4h','0.014076000000000','0.013963000000000','0.104729778415750','0.103889023587604','7.440308213679312','7.440308213679312','test'),('2019-08-17 11:59:59','2019-08-24 07:59:59','HCETH','4h','0.011182000000000','0.013333000000000','0.104729778415750','0.124875884065211','9.365925453027186','9.365925453027186','test'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCETH','4h','0.013227000000000','0.013011000000000','0.106686630906634','0.104944413300538','8.06582225044483','8.065822250444830','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCETH','4h','0.013438000000000','0.013110000000000','0.106686630906634','0.104082581573595','7.939174795850126','7.939174795850126','test'),('2019-08-28 15:59:59','2019-08-28 19:59:59','HCETH','4h','0.013314000000000','0.013402000000000','0.106686630906634','0.107391785144262','8.013116336685744','8.013116336685744','test'),('2019-08-30 07:59:59','2019-08-30 15:59:59','HCETH','4h','0.012906000000000','0.012767000000000','0.106686630906634','0.105537596217650','8.266436611392685','8.266436611392685','test'),('2019-08-31 03:59:59','2019-08-31 07:59:59','HCETH','4h','0.012804000000000','0.012681000000000','0.106686630906634','0.105661759335132','8.332289199206029','8.332289199206029','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','HCETH','4h','0.012955000000000','0.012530000000000','0.106686630906634','0.103186683539956','8.235170274537554','8.235170274537554','test'),('2019-09-08 07:59:59','2019-09-08 15:59:59','HCETH','4h','0.012761000000000','0.012216000000000','0.106686630906634','0.102130231420378','8.360366029827913','8.360366029827913','test'),('2019-10-27 11:59:59','2019-11-08 15:59:59','HCETH','4h','0.008467000000000','0.009677000000000','0.106686630906634','0.121932978302055','12.600287103653477','12.600287103653477','test'),('2019-11-09 03:59:59','2019-11-09 07:59:59','HCETH','4h','0.009905000000000','0.009853000000000','0.107030376301757','0.106468480333287','10.805691701338443','10.805691701338443','test'),('2019-11-09 19:59:59','2019-11-09 23:59:59','HCETH','4h','0.009991000000000','0.009946000000000','0.107030376301757','0.106548305744898','10.712679041312882','10.712679041312882','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','HCETH','4h','0.010012000000000','0.010042000000000','0.107030376301757','0.107351082583125','10.690209378920995','10.690209378920995','test'),('2019-11-29 11:59:59','2019-11-29 15:59:59','HCETH','4h','0.008554000000000','0.008598000000000','0.107030376301757','0.107580918335575','12.512318950404138','12.512318950404138','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','HCETH','4h','0.008421000000000','0.008326000000000','0.107030376301757','0.105822932322578','12.709936622937539','12.709936622937539','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','HCETH','4h','0.008360000000000','0.008359000000000','0.107030376301757','0.107017573625166','12.80267659111926','12.802676591119260','test'),('2019-12-07 15:59:59','2019-12-07 19:59:59','HCETH','4h','0.008386000000000','0.008407000000000','0.107030376301757','0.107298398946920','12.762983102999883','12.762983102999883','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCETH','4h','0.008245000000000','0.008598000000000','0.107030376301757','0.111612756269558','12.98124636770855','12.981246367708550','test'),('2019-12-15 03:59:59','2019-12-15 11:59:59','HCETH','4h','0.008291000000000','0.008219000000000','0.107894735738520','0.106957765412483','13.013476750515018','13.013476750515018','test'),('2019-12-16 15:59:59','2019-12-17 03:59:59','HCETH','4h','0.008436000000000','0.008202000000000','0.107894735738520','0.104901923011776','12.789797977539116','12.789797977539116','test'),('2019-12-17 11:59:59','2019-12-17 15:59:59','HCETH','4h','0.008344000000000','0.008321000000000','0.107894735738520','0.107597326951130','12.930816843063278','12.930816843063278','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','HCETH','4h','0.008588000000000','0.008493000000000','0.107894735738520','0.106701209900705','12.563429871741965','12.563429871741965','test'),('2020-01-07 07:59:59','2020-01-07 11:59:59','HCETH','4h','0.008357000000000','0.008624000000000','0.107894735738520','0.111341893144549','12.910701895239919','12.910701895239919','test'),('2020-01-10 03:59:59','2020-01-10 07:59:59','HCETH','4h','0.008357000000000','0.008316000000000','0.107894735738520','0.107365396960815','12.910701895239919','12.910701895239919','test'),('2020-01-10 23:59:59','2020-01-11 07:59:59','HCETH','4h','0.008516000000000','0.008452000000000','0.107894735738520','0.107083878166037','12.669649570046971','12.669649570046971','test'),('2020-01-13 11:59:59','2020-01-13 15:59:59','HCETH','4h','0.008447000000000','0.008330000000000','0.107894735738520','0.106400278051601','12.773142623241387','12.773142623241387','test'),('2020-01-15 03:59:59','2020-01-18 15:59:59','HCETH','4h','0.009394000000000','0.008735000000000','0.107894735738520','0.100325794834572','11.485494543167981','11.485494543167981','test'),('2020-01-19 03:59:59','2020-01-19 07:59:59','HCETH','4h','0.008851000000000','0.008733000000000','0.107894735738520','0.106456301796915','12.190118149194442','12.190118149194442','test'),('2020-01-20 03:59:59','2020-01-20 07:59:59','HCETH','4h','0.008765000000000','0.008627000000000','0.107894735738520','0.106195993749710','12.309724556590986','12.309724556590986','test'),('2020-01-25 03:59:59','2020-01-25 07:59:59','HCETH','4h','0.008686000000000','0.008653000000000','0.107894735738520','0.107484820210156','12.42168267770205','12.421682677702050','test'),('2020-01-26 19:59:59','2020-01-28 23:59:59','HCETH','4h','0.008974000000000','0.008835000000000','0.107894735738520','0.106223533569180','12.023037189494096','12.023037189494096','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:39:49
