-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 19:59:59','2019-01-07 03:59:59','IOSTETH','4h','0.000039560000000','0.000039210000000','0.072144500000000','0.071506214484328','1823.6729019211325','1823.672901921132507','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','IOSTETH','4h','0.000054290000000','0.000053930000000','0.072144500000000','0.071666105820593','1328.8727205746916','1328.872720574691584','test'),('2019-01-29 15:59:59','2019-01-30 19:59:59','IOSTETH','4h','0.000054400000000','0.000053780000000','0.072144500000000','0.071322264889706','1326.1856617647059','1326.185661764705856','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','IOSTETH','4h','0.000053650000000','0.000053410000000','0.072144500000000','0.071821765983225','1344.7250698974835','1344.725069897483536','test'),('2019-02-03 03:59:59','2019-02-08 19:59:59','IOSTETH','4h','0.000055000000000','0.000054790000000','0.072144500000000','0.071869039181818','1311.7181818181818','1311.718181818181847','test'),('2019-02-11 15:59:59','2019-02-12 03:59:59','IOSTETH','4h','0.000056800000000','0.000055990000000','0.072144500000000','0.071115678785211','1270.149647887324','1270.149647887323908','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','IOSTETH','4h','0.000056450000000','0.000053890000000','0.072144500000000','0.068872756510186','1278.0248007085916','1278.024800708591556','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','IOSTETH','4h','0.000056190000000','0.000055570000000','0.072144500000000','0.071348458177612','1283.9384232069763','1283.938423206976267','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','IOSTETH','4h','0.000055590000000','0.000054880000000','0.072144500000000','0.071223064579960','1297.7963662529232','1297.796366252923235','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','IOSTETH','4h','0.000054800000000','0.000053510000000','0.072144500000000','0.070446207937956','1316.5054744525548','1316.505474452554836','test'),('2019-02-27 07:59:59','2019-02-28 11:59:59','IOSTETH','4h','0.000054510000000','0.000054100000000','0.072144500000000','0.071601861126399','1323.5094478077417','1323.509447807741708','test'),('2019-03-01 07:59:59','2019-03-05 07:59:59','IOSTETH','4h','0.000054610000000','0.000056970000000','0.072144500000000','0.075262262680828','1321.0858817066471','1321.085881706647115','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','IOSTETH','4h','0.000056030000000','0.000056830000000','0.072144500000000','0.073174583883634','1287.6048545422095','1287.604854542209523','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','IOSTETH','4h','0.000056910000000','0.000056370000000','0.072144500000000','0.071459944913021','1267.6946055174838','1267.694605517483751','test'),('2019-03-13 15:59:59','2019-03-13 19:59:59','IOSTETH','4h','0.000057230000000','0.000056880000000','0.072144500000000','0.071703287786126','1260.6063253538355','1260.606325353835473','test'),('2019-03-20 07:59:59','2019-03-21 03:59:59','IOSTETH','4h','0.000057670000000','0.000059660000000','0.072144500000000','0.074633966880527','1250.9883821744409','1250.988382174440858','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','IOSTETH','4h','0.000085790000000','0.000084470000000','0.072144500000000','0.071034455239538','840.943000349691','840.943000349691033','test'),('2019-04-09 19:59:59','2019-04-10 15:59:59','IOSTETH','4h','0.000085720000000','0.000085620000000','0.072144500000000','0.072060337027531','841.629724685021','841.629724685020960','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','IOSTETH','4h','0.000078950000000','0.000081480000000','0.072144500000000','0.074456413679544','913.7998733375555','913.799873337555482','test'),('2019-04-21 15:59:59','2019-04-22 07:59:59','IOSTETH','4h','0.000082930000000','0.000079490000000','0.072144500000000','0.069151890811528','869.9445315326179','869.944531532617930','test'),('2019-05-09 11:59:59','2019-05-09 15:59:59','IOSTETH','4h','0.000068640000000','0.000067510000000','0.072144500000000','0.070956806453963','1051.0562354312356','1051.056235431235564','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','IOSTETH','4h','0.000069940000000','0.000068400000000','0.072144500000000','0.070555959393766','1031.5198741778668','1031.519874177866768','test'),('2019-05-13 03:59:59','2019-05-13 15:59:59','IOSTETH','4h','0.000068780000000','0.000063860000000','0.072144500000000','0.066983829165455','1048.9168362896191','1048.916836289619141','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','IOSTETH','4h','0.000052300000000','0.000050970000000','0.072144500000000','0.070309850191205','1379.4359464627153','1379.435946462715265','test'),('2019-05-31 03:59:59','2019-05-31 07:59:59','IOSTETH','4h','0.000051440000000','0.000050840000000','0.072144500000000','0.071303001166407','1402.4980559875582','1402.498055987558246','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','IOSTETH','4h','0.000050180000000','0.000046980000000','0.072144500000000','0.067543814467916','1437.714228776405','1437.714228776404980','test'),('2019-06-17 19:59:59','2019-06-18 07:59:59','IOSTETH','4h','0.000047770000000','0.000045390000000','0.072144500000000','0.068550112099644','1510.2470169562487','1510.247016956248672','test'),('2019-06-20 03:59:59','2019-06-20 07:59:59','IOSTETH','4h','0.000046140000000','0.000045400000000','0.072144500000000','0.070987436064153','1563.5999133073256','1563.599913307325551','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','IOSTETH','4h','0.000043650000000','0.000043290000000','0.072144500000000','0.071549493814433','1652.794959908362','1652.794959908361989','test'),('2019-06-28 07:59:59','2019-06-28 11:59:59','IOSTETH','4h','0.000042890000000','0.000042000000000','0.072144500000000','0.070647446957333','1682.0820704126836','1682.082070412683606','test'),('2019-06-29 03:59:59','2019-06-29 23:59:59','IOSTETH','4h','0.000042960000000','0.000043180000000','0.072144500000000','0.072513955074488','1679.341247672253','1679.341247672253076','test'),('2019-06-30 11:59:59','2019-06-30 15:59:59','IOSTETH','4h','0.000043100000000','0.000042780000000','0.072144500000000','0.071608856380510','1673.8863109048725','1673.886310904872516','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','IOSTETH','4h','0.000043420000000','0.000042280000000','0.072144500000000','0.070250333026255','1661.5499769691387','1661.549976969138697','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','IOSTETH','4h','0.000043120000000','0.000043050000000','0.072144500000000','0.072027382305195','1673.109925788497','1673.109925788497094','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','IOSTETH','4h','0.000042640000000','0.000042360000000','0.072144500000000','0.071670755628518','1691.9441838649157','1691.944183864915658','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','IOSTETH','4h','0.000042650000000','0.000042690000000','0.072144500000000','0.072212161899179','1691.5474794841734','1691.547479484173437','test'),('2019-07-06 07:59:59','2019-07-06 15:59:59','IOSTETH','4h','0.000042800000000','0.000042540000000','0.072144500000000','0.071706239018692','1685.6191588785048','1685.619158878504777','test'),('2019-07-08 11:59:59','2019-07-08 23:59:59','IOSTETH','4h','0.000043420000000','0.000042900000000','0.072144500000000','0.071280494011976','1661.5499769691387','1661.549976969138697','test'),('2019-07-20 15:59:59','2019-08-05 03:59:59','IOSTETH','4h','0.000038100000000','0.000043830000000','0.072144500000000','0.082994578346457','1893.5564304461943','1893.556430446194327','test'),('2019-08-07 15:59:59','2019-08-08 23:59:59','IOSTETH','4h','0.000047870000000','0.000044900000000','0.072144500000000','0.067668436390224','1507.0921245038646','1507.092124503864625','test'),('2019-08-14 15:59:59','2019-08-14 19:59:59','IOSTETH','4h','0.000043530000000','0.000044770000000','0.072144500000000','0.074199615552493','1657.351252010108','1657.351252010108055','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','IOSTETH','4h','0.000044890000000','0.000044820000000','0.072144500000000','0.072032000222767','1607.1396747605258','1607.139674760525850','test'),('2019-08-20 07:59:59','2019-08-20 15:59:59','IOSTETH','4h','0.000045130000000','0.000044720000000','0.072144500000000','0.071489076888987','1598.5929536893418','1598.592953689341812','test'),('2019-08-22 23:59:59','2019-08-23 15:59:59','IOSTETH','4h','0.000044970000000','0.000044410000000','0.072144500000000','0.071246102846342','1604.2806315321327','1604.280631532132702','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','IOSTETH','4h','0.000045440000000','0.000045110000000','0.072144500000000','0.071620563270246','1587.687059859155','1587.687059859154942','test'),('2019-08-24 19:59:59','2019-08-24 23:59:59','IOSTETH','4h','0.000045000000000','0.000044640000000','0.072144500000000','0.071567344000000','1603.211111111111','1603.211111111110995','test'),('2019-08-25 03:59:59','2019-08-25 11:59:59','IOSTETH','4h','0.000045260000000','0.000045010000000','0.072144500000000','0.071745999668582','1594.0013256738844','1594.001325673884367','test'),('2019-08-27 07:59:59','2019-08-27 11:59:59','IOSTETH','4h','0.000044970000000','0.000044350000000','0.072144500000000','0.071149846008450','1604.2806315321327','1604.280631532132702','test'),('2019-08-28 19:59:59','2019-08-29 03:59:59','IOSTETH','4h','0.000045590000000','0.000042640000000','0.072144500000000','0.067476233384514','1582.4632594867294','1582.463259486729385','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','IOSTETH','4h','0.000044820000000','0.000043520000000','0.072144500000000','0.070051955377064','1609.6497099509147','1609.649709950914712','test'),('2019-10-03 19:59:59','2019-10-07 19:59:59','IOSTETH','4h','0.000029730000000','0.000029530000000','0.072144500000000','0.071659168684830','2426.6565758493102','2426.656575849310229','test'),('2019-10-27 07:59:59','2019-11-07 11:59:59','IOSTETH','4h','0.000025680000000','0.000034470000000','0.072144500000000','0.096838820677570','2809.3652647975077','2809.365264797507734','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','IOSTETH','4h','0.000033890000000','0.000034930000000','0.072144500000000','0.074358435674240','2128.7843021540275','2128.784302154027500','test'),('2019-11-19 07:59:59','2019-11-20 11:59:59','IOSTETH','4h','0.000035550000000','0.000034940000000','0.072144500000000','0.070906577496484','2029.3811533052042','2029.381153305204180','test'),('2019-11-27 03:59:59','2019-11-30 15:59:59','IOSTETH','4h','0.000034610000000','0.000034540000000','0.072144500000000','0.071998585091014','2084.498699797746','2084.498699797746212','test'),('2019-12-01 11:59:59','2019-12-08 19:59:59','IOSTETH','4h','0.000035850000000','0.000038980000000','0.072144500000000','0.078443308507671','2012.3988842398885','2012.398884239888503','test'),('2019-12-13 15:59:59','2019-12-13 19:59:59','IOSTETH','4h','0.000037820000000','0.000036990000000','0.072144500000000','0.070561212453728','1907.5753569539927','1907.575356953992696','test'),('2019-12-14 03:59:59','2019-12-14 07:59:59','IOSTETH','4h','0.000037900000000','0.000037270000000','0.072144500000000','0.070945264248021','1903.5488126649077','1903.548812664907700','test'),('2019-12-17 19:59:59','2019-12-24 03:59:59','IOSTETH','4h','0.000037350000000','0.000040710000000','0.072144500000000','0.078634607630522','1931.5796519410978','1931.579651941097836','test'),('2019-12-26 23:59:59','2019-12-27 15:59:59','IOSTETH','4h','0.000040340000000','0.000039930000000','0.072144500000000','0.071411251487357','1788.411006445216','1788.411006445215889','test'),('2019-12-28 07:59:59','2019-12-28 15:59:59','IOSTETH','4h','0.000040190000000','0.000040070000000','0.072144500000000','0.071929089698930','1795.0858422493159','1795.085842249315874','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:00:06
