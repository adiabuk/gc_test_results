-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 23:59:59','2019-01-07 03:59:59','MTHETH','4h','0.000125500000000','0.000124500000000','0.072144500000000','0.071569643426295','574.8565737051794','574.856573705179358','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','MTHETH','4h','0.000126480000000','0.000123580000000','0.072144500000000','0.070490332938014','570.4024351676154','570.402435167615408','test'),('2019-01-12 23:59:59','2019-01-13 11:59:59','MTHETH','4h','0.000122940000000','0.000124150000000','0.072144500000000','0.072854560557996','586.8269074345209','586.826907434520876','test'),('2019-01-15 07:59:59','2019-01-23 23:59:59','MTHETH','4h','0.000124700000000','0.000150090000000','0.072144500000000','0.086833745028067','578.5445068163593','578.544506816359331','test'),('2019-01-29 15:59:59','2019-01-30 15:59:59','MTHETH','4h','0.000156370000000','0.000151840000000','0.075437070487593','0.073251677321968','482.42674737860847','482.426747378608468','test'),('2019-02-02 11:59:59','2019-02-03 15:59:59','MTHETH','4h','0.000156440000000','0.000149820000000','0.075437070487593','0.072244834444203','482.2108826872475','482.210882687247476','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','MTHETH','4h','0.000150240000000','0.000149220000000','0.075437070487593','0.074924917852494','502.11042656811105','502.110426568111052','test'),('2019-02-07 03:59:59','2019-02-07 11:59:59','MTHETH','4h','0.000152250000000','0.000149440000000','0.075437070487593','0.074044767249037','495.4815795572611','495.481579557261114','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','MTHETH','4h','0.000127950000000','0.000126660000000','0.075437070487593','0.074676509167320','589.5824188166706','589.582418816670611','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','MTHETH','4h','0.000135200000000','0.000133830000000','0.075437070487593','0.074672656385759','557.9664976892973','557.966497689297285','test'),('2019-03-09 11:59:59','2019-03-10 03:59:59','MTHETH','4h','0.000136890000000','0.000137820000000','0.075437070487593','0.075949573048434','551.0780224091826','551.078022409182608','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','MTHETH','4h','0.000142400000000','0.000141920000000','0.075437070487593','0.075182788227522','529.754708480288','529.754708480287945','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','MTHETH','4h','0.000141930000000','0.000143510000000','0.075437070487593','0.076276854686638','531.5089867370747','531.508986737074679','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','MTHETH','4h','0.000143760000000','0.000142210000000','0.075437070487593','0.074623718656376','524.7431169142529','524.743116914252937','test'),('2019-03-25 15:59:59','2019-03-29 23:59:59','MTHETH','4h','0.000146230000000','0.000152890000000','0.075437070487593','0.078872828467812','515.8795766094031','515.879576609403102','test'),('2019-03-30 15:59:59','2019-04-02 03:59:59','MTHETH','4h','0.000153910000000','0.000155770000000','0.075437070487593','0.076348726332612','490.13755108565397','490.137551085653968','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','MTHETH','4h','0.000156730000000','0.000151500000000','0.075437070487593','0.072919773999045','481.3186402577235','481.318640257723473','test'),('2019-04-03 23:59:59','2019-04-05 07:59:59','MTHETH','4h','0.000159580000000','0.000157130000000','0.075437070487593','0.074278900148612','472.7225873392218','472.722587339221775','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','MTHETH','4h','0.000158540000000','0.000158240000000','0.075437070487593','0.075294323413377','475.8235807215403','475.823580721540282','test'),('2019-04-09 15:59:59','2019-04-10 03:59:59','MTHETH','4h','0.000157320000000','0.000155810000000','0.075437070487593','0.074713005038596','479.5135423823608','479.513542382360811','test'),('2019-04-11 11:59:59','2019-04-11 23:59:59','MTHETH','4h','0.000157250000000','0.000158300000000','0.075437070487593','0.075940783835841','479.72699833127507','479.726998331275070','test'),('2019-04-15 07:59:59','2019-04-18 03:59:59','MTHETH','4h','0.000157880000000','0.000160000000000','0.075437070487593','0.076450033430548','477.8127089409235','477.812708940923528','test'),('2019-05-06 07:59:59','2019-05-06 15:59:59','MTHETH','4h','0.000124690000000','0.000119000000000','0.075437070487593','0.071994637805947','604.9969563524982','604.996956352498160','test'),('2019-05-21 11:59:59','2019-05-24 15:59:59','MTHETH','4h','0.000097130000000','0.000101420000000','0.075437070487593','0.078768945628042','776.660871899444','776.660871899444032','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','MTHETH','4h','0.000101350000000','0.000094290000000','0.075437070487593','0.070182154674644','744.3223531089591','744.322353108959078','test'),('2019-05-28 15:59:59','2019-05-28 19:59:59','MTHETH','4h','0.000101710000000','0.000097270000000','0.075437070487593','0.072143976465718','741.6878427646544','741.687842764654420','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','MTHETH','4h','0.000096540000000','0.000093760000000','0.075437070487593','0.073264757912955','781.4074009487571','781.407400948757072','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','MTHETH','4h','0.000096500000000','0.000094600000000','0.075437070487593','0.073951781016853','781.7313003895648','781.731300389564808','test'),('2019-06-13 15:59:59','2019-06-16 07:59:59','MTHETH','4h','0.000099390000000','0.000111420000000','0.075437070487593','0.084567847808910','759.0006085883188','759.000608588318755','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','MTHETH','4h','0.000111070000000','0.000106350000000','0.075437070487593','0.072231317604713','679.184932813478','679.184932813477985','test'),('2019-07-02 19:59:59','2019-07-02 23:59:59','MTHETH','4h','0.000084300000000','0.000096590000000','0.075437070487593','0.086434954192131','894.8644185954092','894.864418595409234','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','MTHETH','4h','0.000075810000000','0.000071670000000','0.075437070487593','0.071317436246482','995.0807345679067','995.080734567906688','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','MTHETH','4h','0.000073770000000','0.000072960000000','0.075437070487593','0.074608765931609','1022.5982172643759','1022.598217264375876','test'),('2019-07-23 03:59:59','2019-07-24 23:59:59','MTHETH','4h','0.000075110000000','0.000075490000000','0.075437070487593','0.075818725217792','1004.3545531566103','1004.354553156610336','test'),('2019-08-10 19:59:59','2019-08-10 23:59:59','MTHETH','4h','0.000062500000000','0.000064260000000','0.075437070487593','0.077561378392524','1206.993127801488','1206.993127801488072','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','MTHETH','4h','0.000061920000000','0.000063280000000','0.075437070487593','0.077093957048690','1218.298941983091','1218.298941983091026','test'),('2019-08-16 11:59:59','2019-08-16 15:59:59','MTHETH','4h','0.000061620000000','0.000060780000000','0.075437070487593','0.074408717043750','1224.2302902887538','1224.230290288753849','test'),('2019-08-16 19:59:59','2019-08-16 23:59:59','MTHETH','4h','0.000063540000000','0.000060990000000','0.075437070487593','0.072409614873124','1187.2374958702078','1187.237495870207795','test'),('2019-08-20 15:59:59','2019-08-23 11:59:59','MTHETH','4h','0.000068000000000','0.000069740000000','0.075437070487593','0.077367371997128','1109.3686836410736','1109.368683641073630','test'),('2019-09-22 19:59:59','2019-09-22 23:59:59','MTHETH','4h','0.000082130000000','0.000079710000000','0.075437070487593','0.073214280878681','918.5081028563619','918.508102856361916','test'),('2019-09-23 03:59:59','2019-09-24 03:59:59','MTHETH','4h','0.000086680000000','0.000082170000000','0.075437070487593','0.071512045246487','870.2938450345293','870.293845034529340','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','MTHETH','4h','0.000081370000000','0.000086700000000','0.075437070487593','0.080378444282590','927.0870159468232','927.087015946823158','test'),('2019-10-02 07:59:59','2019-10-02 19:59:59','MTHETH','4h','0.000081830000000','0.000086310000000','0.075437070487593','0.079567072635759','921.8754795013199','921.875479501319887','test'),('2019-10-08 11:59:59','2019-10-08 15:59:59','MTHETH','4h','0.000087050000000','0.000088950000000','0.075437070487593','0.077083600458029','866.5947212819415','866.594721281941474','test'),('2019-10-12 11:59:59','2019-10-12 15:59:59','MTHETH','4h','0.000088600000000','0.000085500000000','0.075437070487593','0.072797624454731','851.4342041489052','851.434204148905224','test'),('2019-10-17 19:59:59','2019-10-17 23:59:59','MTHETH','4h','0.000083860000000','0.000083330000000','0.075437070487593','0.074960303884225','899.5596289958622','899.559628995862226','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','MTHETH','4h','0.000083640000000','0.000084190000000','0.075437070487593','0.075933129655075','901.9257590577834','901.925759057783353','test'),('2019-10-20 07:59:59','2019-10-20 11:59:59','MTHETH','4h','0.000082990000000','0.000082770000000','0.075437070487593','0.075237092713075','908.9898841739125','908.989884173912515','test'),('2019-10-20 19:59:59','2019-10-20 23:59:59','MTHETH','4h','0.000083390000000','0.000083330000000','0.075437070487593','0.075382792705734','904.6296976567095','904.629697656709482','test'),('2019-10-24 15:59:59','2019-10-24 23:59:59','MTHETH','4h','0.000085970000000','0.000087270000000','0.075437070487593','0.076577796224872','877.4813363684192','877.481336368419193','test'),('2019-11-03 19:59:59','2019-11-03 23:59:59','MTHETH','4h','0.000080660000000','0.000079690000000','0.075437070487593','0.074529880326758','935.2475884898711','935.247588489871077','test'),('2019-11-15 15:59:59','2019-11-15 23:59:59','MTHETH','4h','0.000076510000000','0.000076140000000','0.075437070487593','0.075072259141620','985.9766107383741','985.976610738374120','test'),('2019-11-18 11:59:59','2019-11-18 15:59:59','MTHETH','4h','0.000077520000000','0.000074580000000','0.075437070487593','0.072576067040308','973.1304242465558','973.130424246555776','test'),('2019-11-19 07:59:59','2019-11-19 15:59:59','MTHETH','4h','0.000076920000000','0.000076240000000','0.075437070487593','0.074770180108868','980.7211451845163','980.721145184516331','test'),('2019-11-25 07:59:59','2019-11-27 11:59:59','MTHETH','4h','0.000081220000000','0.000077800000000','0.075437070487593','0.072260577246180','928.7991933956292','928.799193395629231','test'),('2019-12-16 19:59:59','2019-12-16 23:59:59','MTHETH','4h','0.000079770000000','0.000078800000000','0.075437070487593','0.074519758736647','945.6822174701391','945.682217470139108','test'),('2019-12-19 19:59:59','2019-12-21 23:59:59','MTHETH','4h','0.000079280000000','0.000079410000000','0.075437070487593','0.075560769013872','951.5271252219097','951.527125221909728','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','MTHETH','4h','0.000083770000000','0.000074260000000','0.075437070487593','0.066873067379834','900.5260891440014','900.526089144001389','test'),('2019-12-31 19:59:59','2020-01-01 15:59:59','MTHETH','4h','0.000076000000000','0.000077300000000','0.075437070487593','0.076727441430144','992.5930327314868','992.593032731486801','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:03:07
