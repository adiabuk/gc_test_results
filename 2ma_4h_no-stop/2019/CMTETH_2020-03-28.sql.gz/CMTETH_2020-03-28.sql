-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','0.072144500000000','0.071480243911741','393.0509397984201','393.050939798420075','test'),('2019-01-12 15:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000180670000000','0.000180000000000','0.072144500000000','0.071876957989705','399.31643327613887','399.316433276138866','test'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','0.072144500000000','0.087458825494061','384.29925957492145','384.299259574921450','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','0.075740131848877','0.074954023539446','350.9412095675876','350.941209567587578','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','0.075740131848877','0.075452905709507','350.27577972009897','350.275779720098967','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','0.075740131848877','0.076333645639194','353.28201804597694','353.282018045976940','test'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000214460000000','0.075740131848877','0.073732313555652','343.80450226453473','343.804502264534733','test'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000210440000000','0.075740131848877','0.073491116498883','349.22598602396255','349.225986023962548','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000208490000000','0.075740131848877','0.074035632655879','355.10399854131464','355.103998541314638','test'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000203070000000','0.075740131848877','0.073035512486592','359.65683009106317','359.656830091063171','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','0.075740131848877','0.074720049573602','390.83612079507196','390.836120795071963','test'),('2019-02-25 23:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000194840000000','0.000205520000000','0.075740131848877','0.079891767078532','388.7298904171474','388.729890417147374','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CMTETH','4h','0.000207250000000','0.000212910000000','0.075740131848877','0.077808595763302','365.4529884143643','365.452988414364313','test'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','0.075740131848877','0.075781257139748','316.34839131600114','316.348391316001141','test'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','0.075740131848877','0.075452657442751','312.4721805721234','312.472180572123420','test'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238650000000','0.075740131848877','0.074182805818495','310.84351903831976','310.843519038319755','test'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','0.075740131848877','0.075132290639291','311.71344081355255','311.713440813552552','test'),('2019-03-30 11:59:59','2019-03-30 15:59:59','CMTETH','4h','0.000243340000000','0.000252750000000','0.075740131848877','0.078669015882320','311.2522883573477','311.252288357347709','test'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','0.075740131848877','0.079644948705261','289.4601079602423','289.460107960242283','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','CMTETH','4h','0.000259730000000','0.000253220000000','0.075859238985482','0.073957865844930','292.0696068435779','292.069606843577901','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','CMTETH','4h','0.000246410000000','0.000242480000000','0.075859238985482','0.074649357855605','307.8577938617832','307.857793861783193','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','CMTETH','4h','0.000162740000000','0.000160690000000','0.075859238985482','0.074903656830387','466.1376366319405','466.137636631940495','test'),('2019-05-24 03:59:59','2019-05-24 19:59:59','CMTETH','4h','0.000164790000000','0.000169570000000','0.075859238985482','0.078059658685407','460.3388493566478','460.338849356647813','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','CMTETH','4h','0.000162530000000','0.000159280000000','0.075859238985482','0.074342334249724','466.73991869489936','466.739918694899359','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTETH','4h','0.000168090000000','0.000161000000000','0.075859238985482','0.072659512622182','451.30132063467187','451.301320634671868','test'),('2019-05-27 11:59:59','2019-05-27 19:59:59','CMTETH','4h','0.000164310000000','0.000164360000000','0.075859238985482','0.075882323167512','461.68364059084655','461.683640590846551','test'),('2019-06-08 11:59:59','2019-06-09 15:59:59','CMTETH','4h','0.000148210000000','0.000149640000000','0.075859238985482','0.076591164710799','511.8361715503812','511.836171550381209','test'),('2019-06-10 07:59:59','2019-06-11 07:59:59','CMTETH','4h','0.000153230000000','0.000148790000000','0.075859238985482','0.073661137953729','495.06779994441035','495.067799944410353','test'),('2019-06-13 19:59:59','2019-06-18 07:59:59','CMTETH','4h','0.000167940000000','0.000167170000000','0.075859238985482','0.075511426588085','451.7044122036561','451.704412203656091','test'),('2019-06-18 15:59:59','2019-06-20 03:59:59','CMTETH','4h','0.000172610000000','0.000170060000000','0.075859238985482','0.074738556177922','439.48345394520595','439.483453945205952','test'),('2019-07-03 07:59:59','2019-07-07 19:59:59','CMTETH','4h','0.000153910000000','0.000180160000000','0.075859238985482','0.088797352320346','492.88050799481516','492.880507994815162','test'),('2019-07-09 15:59:59','2019-07-16 19:59:59','CMTETH','4h','0.000233600000000','0.000206600000000','0.076720108780694','0.067852630454158','328.42512320502357','328.425123205023567','test'),('2019-07-19 15:59:59','2019-07-19 19:59:59','CMTETH','4h','0.000208700000000','0.000204870000000','0.076720108780694','0.075312164283185','367.60952937563013','367.609529375630132','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','CMTETH','4h','0.000205140000000','0.000198810000000','0.076720108780694','0.074352758246513','373.9890259368919','373.989025936891892','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','CMTETH','4h','0.000204010000000','0.000198700000000','0.076720108780694','0.074723227364952','376.0605302715259','376.060530271525920','test'),('2019-07-22 19:59:59','2019-07-22 23:59:59','CMTETH','4h','0.000203780000000','0.000204010000000','0.076720108780694','0.076806700325593','376.48497782262245','376.484977822622454','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CMTETH','4h','0.000203240000000','0.000198770000000','0.076720108780694','0.075032749568680','377.4852823297284','377.485282329728420','test'),('2019-08-18 03:59:59','2019-08-18 07:59:59','CMTETH','4h','0.000159250000000','0.000152810000000','0.076720108780694','0.073617581304727','481.7589248395228','481.758924839522820','test'),('2019-08-19 11:59:59','2019-08-22 19:59:59','CMTETH','4h','0.000170960000000','0.000162260000000','0.076720108780694','0.072815891733478','448.7605801397637','448.760580139763704','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','CMTETH','4h','0.000162970000000','0.000163010000000','0.076720108780694','0.076738939266987','470.7621573338284','470.762157333828384','test'),('2019-09-22 03:59:59','2019-09-22 07:59:59','CMTETH','4h','0.000113060000000','0.000112630000000','0.076720108780694','0.076428319936048','678.5787084795153','678.578708479515285','test'),('2019-10-03 03:59:59','2019-10-03 15:59:59','CMTETH','4h','0.000106100000000','0.000103630000000','0.076720108780694','0.074934070433019','723.0924484514044','723.092448451404380','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','CMTETH','4h','0.000103000000000','0.000102320000000','0.076720108780694','0.076213607091656','744.8554250552817','744.855425055281671','test'),('2019-10-08 19:59:59','2019-10-09 03:59:59','CMTETH','4h','0.000104310000000','0.000102670000000','0.076720108780694','0.075513887149016','735.5009949256448','735.500994925644818','test'),('2019-10-22 11:59:59','2019-10-23 03:59:59','CMTETH','4h','0.000095550000000','0.000096390000000','0.076720108780694','0.077394571275469','802.9315413992047','802.931541399204662','test'),('2019-10-27 15:59:59','2019-11-04 19:59:59','CMTETH','4h','0.000099330000000','0.000106670000000','0.076720108780694','0.082389348672472','772.3760070542032','772.376007054203228','test'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CMTETH','4h','0.000106670000000','0.000111490000000','0.076720108780694','0.080186790362422','719.2285439270087','719.228543927008673','test'),('2019-11-28 15:59:59','2019-11-28 19:59:59','CMTETH','4h','0.000102160000000','0.000099780000000','0.076720108780694','0.074932776567518','750.9799215024864','750.979921502486377','test'),('2019-11-29 07:59:59','2019-11-29 11:59:59','CMTETH','4h','0.000099960000000','0.000100180000000','0.076720108780694','0.076888960560724','767.5080910433574','767.508091043357354','test'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTETH','4h','0.000098250000000','0.000096490000000','0.076720108780694','0.075345784185742','780.8662471317456','780.866247131745581','test'),('2019-12-19 15:59:59','2019-12-19 19:59:59','CMTETH','4h','0.000091710000000','0.000089370000000','0.076720108780694','0.074762579017889','836.5511806857922','836.551180685792247','test'),('2019-12-20 03:59:59','2019-12-22 03:59:59','CMTETH','4h','0.000091280000000','0.000092160000000','0.076720108780694','0.077459741731253','840.4919892714067','840.491989271406737','test'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTETH','4h','0.000094120000000','0.000090060000000','0.076720108780694','0.073410677823941','815.1307775254356','815.130777525435633','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:02:46
