-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-14 07:59:59','2019-01-14 11:59:59','TRXUSDT','4h','0.023710000000000','0.022870000000000','15.000000000000000','14.468578658793760','632.6444538169549','632.644453816954865','test'),('2019-01-14 15:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024100000000000','0.023950000000000','15.000000000000000','14.906639004149376','622.4066390041494','622.406639004149383','test'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXUSDT','4h','0.025160000000000','0.025900000000000','15.000000000000000','15.441176470588237','596.1844197138315','596.184419713831517','test'),('2019-01-28 23:59:59','2019-01-29 07:59:59','TRXUSDT','4h','0.026730000000000','0.025940000000000','15.000000000000000','14.556677890011224','561.1672278338945','561.167227833894458','test'),('2019-01-29 11:59:59','2019-01-31 11:59:59','TRXUSDT','4h','0.026620000000000','0.025860000000000','15.000000000000000','14.571750563486100','563.4861006761832','563.486100676183241','test'),('2019-02-04 11:59:59','2019-02-05 19:59:59','TRXUSDT','4h','0.027060000000000','0.026390000000000','15.000000000000000','14.628603104212861','554.3237250554323','554.323725055432305','test'),('2019-02-08 15:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.026640000000000','0.026400000000000','15.000000000000000','14.864864864864865','563.063063063063','563.063063063063055','test'),('2019-02-18 19:59:59','2019-02-20 03:59:59','TRXUSDT','4h','0.024840000000000','0.024640000000000','15.000000000000000','14.879227053140095','603.8647342995168','603.864734299516840','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','TRXUSDT','4h','0.024750000000000','0.024770000000000','15.000000000000000','15.012121212121212','606.060606060606','606.060606060606005','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','TRXUSDT','4h','0.023600000000000','0.023750000000000','15.000000000000000','15.095338983050850','635.5932203389831','635.593220338983087','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','TRXUSDT','4h','0.023420000000000','0.023320000000000','15.000000000000000','14.935952177625961','640.4782237403929','640.478223740392878','test'),('2019-03-15 15:59:59','2019-03-15 19:59:59','TRXUSDT','4h','0.022740000000000','0.022910000000000','15.000000000000000','15.112137203166226','659.6306068601583','659.630606860158309','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','TRXUSDT','4h','0.022790000000000','0.022690000000000','15.000000000000000','14.934181658622201','658.1834137779728','658.183413777972760','test'),('2019-03-23 11:59:59','2019-03-24 23:59:59','TRXUSDT','4h','0.023960000000000','0.023240000000000','15.000000000000000','14.549248747913190','626.0434056761269','626.043405676126895','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','TRXUSDT','4h','0.022980000000000','0.022530000000000','15.000000000000000','14.706266318537860','652.7415143603133','652.741514360313317','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','TRXUSDT','4h','0.023200000000000','0.022870000000000','15.000000000000000','14.786637931034484','646.551724137931','646.551724137931046','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','TRXUSDT','4h','0.026830000000000','0.027130000000000','15.000000000000000','15.167722698471861','559.0756615728662','559.075661572866238','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','TRXUSDT','4h','0.026920000000000','0.026690000000000','15.000000000000000','14.871842496285289','557.2065378900446','557.206537890044615','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','TRXUSDT','4h','0.026790000000000','0.026720000000000','15.000000000000000','14.960806270996640','559.9104143337066','559.910414333706626','test'),('2019-05-03 23:59:59','2019-05-04 07:59:59','TRXUSDT','4h','0.023810000000000','0.023740000000000','15.000000000000000','14.955900881982359','629.9874002519949','629.987400251994927','test'),('2019-05-06 15:59:59','2019-05-07 15:59:59','TRXUSDT','4h','0.023890000000000','0.023830000000000','15.000000000000000','14.962327333612389','627.8777731268312','627.877773126831244','test'),('2019-05-11 11:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.024500000000000','0.024020000000000','15.000000000000000','14.706122448979592','612.2448979591836','612.244897959183618','test'),('2019-05-13 03:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024470000000000','0.024330000000000','15.000000000000000','14.914180629342052','612.9955046996322','612.995504699632193','test'),('2019-05-17 19:59:59','2019-05-20 15:59:59','TRXUSDT','4h','0.026250000000000','0.027310000000000','15.000000000000000','15.605714285714287','571.4285714285714','571.428571428571445','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','TRXUSDT','4h','0.027000000000000','0.027590000000000','15.000000000000000','15.327777777777778','555.5555555555555','555.555555555555543','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','TRXUSDT','4h','0.032820000000000','0.032420000000000','15.000000000000000','14.817184643510053','457.03839122486283','457.038391224862835','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','TRXUSDT','4h','0.032450000000000','0.032640000000000','15.000000000000000','15.087827426810478','462.24961479198765','462.249614791987653','test'),('2019-06-21 03:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033030000000000','0.036770000000000','15.000000000000000','16.698455949137148','454.13260672116263','454.132606721162631','test'),('2019-07-07 19:59:59','2019-07-10 11:59:59','TRXUSDT','4h','0.034810000000000','0.033510000000000','15.000000000000000','14.439816144785981','430.91065785693763','430.910657856937632','test'),('2019-07-19 23:59:59','2019-07-21 15:59:59','TRXUSDT','4h','0.028060000000000','0.027870000000000','15.000000000000000','14.898431931575194','534.5687811831789','534.568781183178885','test'),('2019-08-05 15:59:59','2019-08-05 23:59:59','TRXUSDT','4h','0.023330000000000','0.022900000000000','15.000000000000000','14.723531933133305','642.9489927132447','642.948992713244706','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','TRXUSDT','4h','0.022860000000000','0.022340000000000','15.000000000000000','14.658792650918636','656.1679790026247','656.167979002624747','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','TRXUSDT','4h','0.016060000000000','0.015630000000000','15.000000000000000','14.598381070983811','933.9975093399751','933.997509339975068','test'),('2019-09-08 23:59:59','2019-09-09 03:59:59','TRXUSDT','4h','0.015760000000000','0.015410000000000','15.000000000000000','14.666878172588833','951.7766497461929','951.776649746192902','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','TRXUSDT','4h','0.015800000000000','0.015680000000000','15.000000000000000','14.886075949367086','949.3670886075948','949.367088607594837','test'),('2019-09-10 03:59:59','2019-09-10 15:59:59','TRXUSDT','4h','0.015980000000000','0.015730000000000','15.000000000000000','14.765331664580724','938.6733416770963','938.673341677096346','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','TRXUSDT','4h','0.015510000000000','0.015290000000000','15.000000000000000','14.787234042553191','967.1179883945841','967.117988394584131','test'),('2019-09-14 15:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015680000000000','0.015470000000000','15.000000000000000','14.799107142857142','956.6326530612246','956.632653061224573','test'),('2019-09-16 23:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015650000000000','0.016580000000000','15.000000000000000','15.891373801916934','958.4664536741213','958.466453674121340','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','TRXUSDT','4h','0.014630000000000','0.014530000000000','15.000000000000000','14.897470950102527','1025.2904989747094','1025.290498974709408','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','TRXUSDT','4h','0.014420000000000','0.014710000000000','15.000000000000000','15.301664355062414','1040.2219140083218','1040.221914008321846','test'),('2019-10-19 15:59:59','2019-10-19 19:59:59','TRXUSDT','4h','0.015650000000000','0.015460000000000','15.000000000000000','14.817891373801915','958.4664536741213','958.466453674121340','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','TRXUSDT','4h','0.015630000000000','0.015420000000000','15.000000000000000','14.798464491362761','959.6928982725527','959.692898272552725','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','TRXUSDT','4h','0.015570000000000','0.015540000000000','15.000000000000000','14.971098265895954','963.3911368015414','963.391136801541393','test'),('2019-10-25 11:59:59','2019-11-04 07:59:59','TRXUSDT','4h','0.015410000000000','0.019090000000000','15.000000000000000','18.582089552238806','973.3939000648929','973.393900064892932','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','TRXUSDT','4h','0.019330000000000','0.019170000000000','15.252224544415910','15.125977471104655','789.0442081953394','789.044208195339365','test'),('2019-11-10 19:59:59','2019-11-11 03:59:59','TRXUSDT','4h','0.019420000000000','0.019190000000000','15.252224544415910','15.071585427772467','785.3874636671426','785.387463667142583','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','TRXUSDT','4h','0.019600000000000','0.019410000000000','15.252224544415910','15.104371347301674','778.174721653873','778.174721653873007','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','TRXUSDT','4h','0.019410000000000','0.019030000000000','15.252224544415910','14.953623548698337','785.7920939936068','785.792093993606841','test'),('2019-11-27 19:59:59','2019-11-28 07:59:59','TRXUSDT','4h','0.016240000000000','0.016080000000000','15.252224544415910','15.101956322303439','939.1763882029501','939.176388202950079','test'),('2019-12-01 23:59:59','2019-12-02 03:59:59','TRXUSDT','4h','0.015910000000000','0.015670000000000','15.252224544415910','15.022146990006116','958.6564767074739','958.656476707473871','test'),('2019-12-22 03:59:59','2019-12-23 19:59:59','TRXUSDT','4h','0.013870000000000','0.014040000000000','15.252224544415910','15.439166013237157','1099.6556989485155','1099.655698948515465','test'),('2019-12-29 19:59:59','2019-12-30 03:59:59','TRXUSDT','4h','0.013770000000000','0.013600000000000','15.252224544415910','15.063925475966331','1107.6415791151715','1107.641579115171453','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:01:35
