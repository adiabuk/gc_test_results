-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','0.072144500000000','0.127149435128998','31.20369369174542','31.203693691745421','test'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','0.085895733782250','0.087756547135883','21.354296002209995','21.354296002209995','test'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','0.086360937120658','0.087278625339667','22.17709567444956','22.177095674449561','test'),('2019-02-07 19:59:59','2019-02-07 23:59:59','LINKETH','4h','0.003880300000000','0.003839990000000','0.086590359175410','0.085690826309817','22.31537746447697','22.315377464476970','test'),('2019-02-09 15:59:59','2019-02-10 07:59:59','LINKETH','4h','0.004048190000000','0.003979650000000','0.086590359175410','0.085124295769818','21.389895033437163','21.389895033437163','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003214830000000','0.086590359175410','0.083138940888598','25.861069135412404','25.861069135412404','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','LINKETH','4h','0.003211970000000','0.003197420000000','0.086590359175410','0.086198110889778','26.958645060635682','26.958645060635682','test'),('2019-03-03 03:59:59','2019-03-03 07:59:59','LINKETH','4h','0.003201150000000','0.003181010000000','0.086590359175410','0.086045576883486','27.049766232575795','27.049766232575795','test'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','0.086590359175410','0.087588021290691','27.066253805767065','27.066253805767065','test'),('2019-03-07 19:59:59','2019-03-16 03:59:59','LINKETH','4h','0.003401970000000','0.003471800000000','0.086590359175410','0.088367742509543','25.453004928147514','25.453004928147514','test'),('2019-03-20 03:59:59','2019-03-20 11:59:59','LINKETH','4h','0.003519810000000','0.003469920000000','0.086590359175410','0.085363022182998','24.600861744074255','24.600861744074255','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','LINKETH','4h','0.003477940000000','0.003466360000000','0.086590359175410','0.086302051625754','24.897025013487866','24.897025013487866','test'),('2019-03-25 19:59:59','2019-03-26 15:59:59','LINKETH','4h','0.003439950000000','0.003412920000000','0.086590359175410','0.085909960504350','25.171981911193473','25.171981911193473','test'),('2019-03-27 15:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003437430000000','0.003450000000000','0.086590359175410','0.086907002951381','25.190435638081357','25.190435638081357','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','LINKETH','4h','0.003489740000000','0.003460350000000','0.086590359175410','0.085861109816958','24.812839688747587','24.812839688747587','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','LINKETH','4h','0.003584450000000','0.003453670000000','0.086590359175410','0.083431077507941','24.157223332843255','24.157223332843255','test'),('2019-04-06 07:59:59','2019-04-06 11:59:59','LINKETH','4h','0.003562480000000','0.003517170000000','0.086590359175410','0.085489045154212','24.306202189320363','24.306202189320363','test'),('2019-04-13 19:59:59','2019-04-14 07:59:59','LINKETH','4h','0.003268570000000','0.003169790000000','0.086590359175410','0.083973497465443','26.491817270368998','26.491817270368998','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','LINKETH','4h','0.002925320000000','0.002952000000000','0.086590359175410','0.087380095266778','29.60030327465371','29.600303274653712','test'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LINKETH','4h','0.002958000000000','0.002909380000000','0.086590359175410','0.085167092352182','29.273278963965517','29.273278963965517','test'),('2019-05-14 15:59:59','2019-05-15 15:59:59','LINKETH','4h','0.004178870000000','0.003374510000000','0.086590359175410','0.069923216788513','20.72099854156985','20.720998541569848','test'),('2019-05-17 03:59:59','2019-05-25 15:59:59','LINKETH','4h','0.003537770000000','0.004581860000000','0.086590359175410','0.112145476696180','24.475971918866968','24.475971918866968','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKETH','4h','0.004651490000000','0.004505950000000','0.086590359175410','0.083881042187866','18.615617614014003','18.615617614014003','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','LINKETH','4h','0.004490750000000','0.004386690000000','0.086590359175410','0.084583880797457','19.2819371319735','19.281937131973500','test'),('2019-05-28 07:59:59','2019-05-28 11:59:59','LINKETH','4h','0.004453770000000','0.004606650000000','0.086590359175410','0.089562657724894','19.4420365612526','19.442036561252600','test'),('2019-06-05 07:59:59','2019-06-12 07:59:59','LINKETH','4h','0.004069090000000','0.004446760000000','0.086590359175410','0.094627188282109','21.280030467600863','21.280030467600863','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','LINKETH','4h','0.004482070000000','0.004354110000000','0.086861026878489','0.084381204609008','19.379667626451454','19.379667626451454','test'),('2019-06-13 19:59:59','2019-06-21 03:59:59','LINKETH','4h','0.006918550000000','0.006006820000000','0.086861026878489','0.075414437053175','12.5548022170092','12.554802217009200','test'),('2019-06-24 03:59:59','2019-06-24 07:59:59','LINKETH','4h','0.006034300000000','0.005954170000000','0.086861026878489','0.085707591669140','14.394548974775699','14.394548974775699','test'),('2019-06-24 15:59:59','2019-06-24 19:59:59','LINKETH','4h','0.006053700000000','0.005956320000000','0.086861026878489','0.085463777791579','14.348419458924127','14.348419458924127','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','LINKETH','4h','0.010931360000000','0.011201500000000','0.086861026878489','0.089007570199810','7.946040280302634','7.946040280302634','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','LINKETH','4h','0.011111730000000','0.010818280000000','0.086861026878489','0.084567111499201','7.817057008988609','7.817057008988609','test'),('2019-07-11 07:59:59','2019-07-11 11:59:59','LINKETH','4h','0.010840590000000','0.010594380000000','0.086861026878489','0.084888251095275','8.012573750920291','8.012573750920291','test'),('2019-07-12 19:59:59','2019-07-16 19:59:59','LINKETH','4h','0.012013940000000','0.011354580000000','0.086861026878489','0.082093840869353','7.230020033268769','7.230020033268769','test'),('2019-07-17 15:59:59','2019-07-17 19:59:59','LINKETH','4h','0.011569380000000','0.011424460000000','0.086861026878489','0.085772991044656','7.507837661005948','7.507837661005948','test'),('2019-07-24 07:59:59','2019-07-24 11:59:59','LINKETH','4h','0.011574670000000','0.011335640000000','0.086861026878489','0.085067248632132','7.504406335428051','7.504406335428051','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','LINKETH','4h','0.011424470000000','0.011109880000000','0.086861026878489','0.084469177589576','7.603068403040928','7.603068403040928','test'),('2019-08-02 19:59:59','2019-08-05 19:59:59','LINKETH','4h','0.010892850000000','0.010835450000000','0.086861026878489','0.086403311685236','7.9741322866365545','7.974132286636554','test'),('2019-08-06 23:59:59','2019-08-07 03:59:59','LINKETH','4h','0.010970120000000','0.010749840000000','0.086861026878489','0.085116857534781','7.917965061320113','7.917965061320113','test'),('2019-08-10 07:59:59','2019-08-10 11:59:59','LINKETH','4h','0.011107090000000','0.011089990000000','0.086861026878489','0.086727299362135','7.82032259381071','7.820322593810710','test'),('2019-08-21 03:59:59','2019-08-21 11:59:59','LINKETH','4h','0.012102040000000','0.011789810000000','0.086861026878489','0.084620031275907','7.177387190795023','7.177387190795023','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','LINKETH','4h','0.008806250000000','0.008836640000000','0.086861026878489','0.087160780645057','9.863565862709894','9.863565862709894','test'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKETH','4h','0.013595980000000','0.013620690000000','0.086861026878489','0.087018892363299','6.388728644679456','6.388728644679456','test'),('2019-10-28 03:59:59','2019-10-28 19:59:59','LINKETH','4h','0.015350370000000','0.014742070000000','0.086861026878489','0.083418923355891','5.6585624241297765','5.658562424129777','test'),('2019-10-31 19:59:59','2019-11-01 11:59:59','LINKETH','4h','0.014931840000000','0.014721240000000','0.086861026878489','0.085635931226472','5.8171683381612045','5.817168338161204','test'),('2019-11-01 23:59:59','2019-11-02 15:59:59','LINKETH','4h','0.014833760000000','0.014660290000000','0.086861026878489','0.085845250545812','5.855631133204865','5.855631133204865','test'),('2019-11-02 19:59:59','2019-11-02 23:59:59','LINKETH','4h','0.014824380000000','0.014749590000000','0.086861026878489','0.086422807121559','5.859336233858617','5.859336233858617','test'),('2019-11-08 07:59:59','2019-11-08 11:59:59','LINKETH','4h','0.014602270000000','0.014529110000000','0.086861026878489','0.086425837505437','5.948460539251021','5.948460539251021','test'),('2019-11-08 23:59:59','2019-11-10 19:59:59','LINKETH','4h','0.014775770000000','0.014727770000000','0.086861026878489','0.086578853476347','5.878612544624679','5.878612544624679','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','LINKETH','4h','0.014681640000000','0.014828280000000','0.086861026878489','0.087728593511472','5.916302734468969','5.916302734468969','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','LINKETH','4h','0.015709140000000','0.015605560000000','0.086861026878489','0.086288298825644','5.529330496671937','5.529330496671937','test'),('2019-11-21 15:59:59','2019-11-22 07:59:59','LINKETH','4h','0.016019970000000','0.015479940000000','0.086861026878489','0.083932958951696','5.422046787758591','5.422046787758591','test'),('2019-11-22 15:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015711740000000','0.015699910000000','0.086861026878489','0.086795625723176','5.528415495577766','5.528415495577766','test'),('2019-11-23 11:59:59','2019-11-24 03:59:59','LINKETH','4h','0.015779060000000','0.015822910000000','0.086861026878489','0.087102413629577','5.504828987182316','5.504828987182316','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','LINKETH','4h','0.015676090000000','0.015120220000000','0.086861026878489','0.083780957868235','5.540988019237513','5.540988019237513','test'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKETH','4h','0.014754620000000','0.014520610000000','0.086861026878489','0.085483400826457','5.887039237776981','5.887039237776981','test'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKETH','4h','0.014574440000000','0.014580070000000','0.086861026878489','0.086894580660406','5.9598191682485915','5.959819168248591','test'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKETH','4h','0.014614260000000','0.014467430000000','0.086861026878489','0.085988330992651','5.943580234544137','5.943580234544137','test'),('2019-12-18 03:59:59','2019-12-18 07:59:59','LINKETH','4h','0.014609280000000','0.014476310000000','0.086861026878489','0.086070439611763','5.945606277550228','5.945606277550228','test'),('2019-12-20 07:59:59','2019-12-22 11:59:59','LINKETH','4h','0.014693420000000','0.014558630000000','0.086861026878489','0.086064207770824','5.911559519736658','5.911559519736658','test'),('2019-12-25 03:59:59','2019-12-25 07:59:59','LINKETH','4h','0.014586490000000','0.014568620000000','0.086861026878489','0.086754612891963','5.954895720525568','5.954895720525568','test'),('2019-12-26 19:59:59','2019-12-28 19:59:59','LINKETH','4h','0.014805500000000','0.014665560000000','0.086861026878489','0.086040025757191','5.86680806987194','5.866808069871940','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 16:03:20
