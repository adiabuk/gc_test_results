-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-19 11:59:59','2019-01-19 15:59:59','ETCUSDT','4h','4.504100000000000','4.436000000000000','15.000000000000000','14.773206633955727','3.3302990608556646','3.330299060855665','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','ETCUSDT','4h','4.348400000000000','4.314200000000000','15.000000000000000','14.882025572624412','3.4495446601048663','3.449544660104866','test'),('2019-02-08 15:59:59','2019-02-10 07:59:59','ETCUSDT','4h','4.009800000000000','3.970500000000000','15.000000000000000','14.852985186293580','3.740834954361813','3.740834954361813','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETCUSDT','4h','4.283800000000000','4.266400000000000','15.000000000000000','14.939072785844344','3.501564031934264','3.501564031934264','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','ETCUSDT','4h','4.272700000000000','4.307300000000000','15.000000000000000','15.121468860439533','3.5106607063449338','3.510660706344934','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','ETCUSDT','4h','4.265000000000000','4.437500000000000','15.000000000000000','15.606682297772567','3.5169988276670576','3.516998827667058','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','ETCUSDT','4h','4.279100000000000','4.270900000000000','15.043860334232541','15.015031922944956','3.5156599131201753','3.515659913120175','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','ETCUSDT','4h','4.309400000000000','4.230400000000000','15.043860334232541','14.768076010102879','3.490940811767889','3.490940811767889','test'),('2019-03-12 23:59:59','2019-03-13 03:59:59','ETCUSDT','4h','4.270400000000000','4.263900000000000','15.043860334232541','15.020961989306416','3.5228222963264657','3.522822296326466','test'),('2019-03-14 15:59:59','2019-03-18 11:59:59','ETCUSDT','4h','4.285500000000000','4.347600000000000','15.043860334232541','15.261856770297374','3.5104095984675165','3.510409598467517','test'),('2019-03-26 23:59:59','2019-03-30 19:59:59','ETCUSDT','4h','4.666300000000000','4.781700000000000','15.043860334232541','15.415902740972449','3.2239376667236446','3.223937666723645','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ETCUSDT','4h','6.206000000000000','6.241100000000000','15.109492274847884','15.194948797382072','2.4346587616577318','2.434658761657732','test'),('2019-04-12 11:59:59','2019-04-13 11:59:59','ETCUSDT','4h','6.267600000000000','6.153600000000000','15.130856405481431','14.855644581142789','2.4141388099881027','2.414138809988103','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','ETCUSDT','4h','6.239300000000000','6.215900000000000','15.130856405481431','15.074109328102837','2.4250887768630185','2.425088776863018','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','ETCUSDT','4h','6.317400000000000','6.209700000000000','15.130856405481431','14.872903254680413','2.395108178282431','2.395108178282431','test'),('2019-04-30 11:59:59','2019-05-01 15:59:59','ETCUSDT','4h','5.890600000000000','5.829900000000000','15.130856405481431','14.974939693463519','2.568644349553769','2.568644349553769','test'),('2019-05-04 23:59:59','2019-05-05 03:59:59','ETCUSDT','4h','5.830600000000000','5.837900000000000','15.130856405481431','15.149800468143939','2.5950770770557803','2.595077077055780','test'),('2019-05-07 03:59:59','2019-05-07 11:59:59','ETCUSDT','4h','5.885200000000000','5.821000000000000','15.130856405481431','14.965798126878850','2.571001224339263','2.571001224339263','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ETCUSDT','4h','5.896400000000000','5.789400000000000','15.130856405481431','14.856281811595922','2.566117699864567','2.566117699864567','test'),('2019-05-23 23:59:59','2019-05-24 07:59:59','ETCUSDT','4h','7.055200000000000','7.180100000000000','15.130856405481431','15.398721804767721','2.144638905414649','2.144638905414649','test'),('2019-06-08 03:59:59','2019-06-08 19:59:59','ETCUSDT','4h','8.575699999999999','8.156200000000000','15.130856405481431','14.390695921544324','1.7643873276212358','1.764387327621236','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ETCUSDT','4h','8.312400000000000','8.183999999999999','15.130856405481431','14.897133056934221','1.820275300211904','1.820275300211904','test'),('2019-06-12 03:59:59','2019-06-12 07:59:59','ETCUSDT','4h','8.244100000000000','8.199900000000000','15.130856405481431','15.049733680972718','1.8353557581156745','1.835355758115675','test'),('2019-06-12 15:59:59','2019-06-14 07:59:59','ETCUSDT','4h','8.322900000000001','8.250299999999999','15.130856405481431','14.998871138923144','1.8179788782132946','1.817978878213295','test'),('2019-06-19 07:59:59','2019-06-19 15:59:59','ETCUSDT','4h','8.649400000000000','8.494899999999999','15.130856405481431','14.860581321123338','1.7493532968161296','1.749353296816130','test'),('2019-06-21 03:59:59','2019-06-26 23:59:59','ETCUSDT','4h','8.606999999999999','9.085599999999999','15.130856405481431','15.972221326553051','1.757971000985411','1.757971000985411','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','ETCUSDT','4h','8.072500000000000','8.012900000000000','15.130856405481431','15.019143919663321','1.8743705674179538','1.874370567417954','test'),('2019-07-22 03:59:59','2019-07-22 15:59:59','ETCUSDT','4h','6.462500000000000','6.234700000000000','15.130856405481431','14.597501033849916','2.3413317455290414','2.341331745529041','test'),('2019-07-22 19:59:59','2019-07-23 03:59:59','ETCUSDT','4h','6.314600000000000','6.266200000000000','15.130856405481431','15.014881767337242','2.396170209590699','2.396170209590699','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','ETCUSDT','4h','6.217600000000000','6.163600000000000','15.130856405481431','14.999444567168256','2.4335525613550937','2.433552561355094','test'),('2019-08-04 15:59:59','2019-08-06 15:59:59','ETCUSDT','4h','6.093900000000000','5.956000000000000','15.130856405481431','14.788457433014559','2.4829512144080854','2.482951214408085','test'),('2019-08-08 11:59:59','2019-08-08 15:59:59','ETCUSDT','4h','6.066000000000000','5.980800000000000','15.130856405481431','14.918335969321356','2.494371316432811','2.494371316432811','test'),('2019-08-13 23:59:59','2019-08-14 15:59:59','ETCUSDT','4h','5.920400000000000','5.877300000000000','15.130856405481431','15.020705079375722','2.555715222870318','2.555715222870318','test'),('2019-08-20 07:59:59','2019-08-28 19:59:59','ETCUSDT','4h','5.935800000000000','6.375400000000000','15.130856405481431','16.251433998366913','2.549084606199911','2.549084606199911','test'),('2019-09-02 11:59:59','2019-09-06 23:59:59','ETCUSDT','4h','6.559500000000000','6.656300000000000','15.130856405481431','15.354145817791913','2.3067088048603446','2.306708804860345','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','ETCUSDT','4h','6.683900000000000','6.636100000000000','15.130856405481431','15.022647884081945','2.2637765983155687','2.263776598315569','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETCUSDT','4h','6.738600000000000','6.683500000000000','15.130856405481431','15.007134833056591','2.2454005884725956','2.245400588472596','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','ETCUSDT','4h','6.744100000000000','6.572000000000000','15.130856405481431','14.744738111360146','2.2435694022154817','2.243569402215482','test'),('2019-09-18 03:59:59','2019-09-18 11:59:59','ETCUSDT','4h','6.421500000000000','6.386400000000000','15.130856405481431','15.048150953510335','2.3562806829372316','2.356280682937232','test'),('2019-10-09 15:59:59','2019-10-11 07:59:59','ETCUSDT','4h','4.838500000000000','4.772400000000000','15.130856405481431','14.924149862461421','3.127179168230119','3.127179168230119','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ETCUSDT','4h','4.776800000000000','4.740400000000000','15.130856405481431','15.015556796295467','3.167571680933142','3.167571680933142','test'),('2019-10-14 07:59:59','2019-10-14 15:59:59','ETCUSDT','4h','4.784400000000000','4.759900000000000','15.130856405481431','15.053374175330463','3.1625400061619913','3.162540006161991','test'),('2019-10-21 23:59:59','2019-10-22 11:59:59','ETCUSDT','4h','4.577500000000000','4.577100000000000','15.130856405481431','15.129534211584721','3.3054847417763917','3.305484741776392','test'),('2019-10-25 15:59:59','2019-10-26 11:59:59','ETCUSDT','4h','4.598300000000000','4.614500000000000','15.130856405481431','15.184163034837670','3.2905326763111216','3.290532676311122','test'),('2019-12-07 07:59:59','2019-12-07 11:59:59','ETCUSDT','4h','3.914600000000000','3.906400000000000','15.130856405481431','15.099161462824469','3.8652369093857435','3.865236909385743','test'),('2019-12-08 15:59:59','2019-12-08 23:59:59','ETCUSDT','4h','3.930100000000000','3.897700000000000','15.130856405481431','15.006116641216501','3.849992724226211','3.849992724226211','test'),('2019-12-13 07:59:59','2019-12-13 11:59:59','ETCUSDT','4h','3.871900000000000','3.864500000000000','15.130856405481431','15.101938216116892','3.907863427640546','3.907863427640546','test'),('2019-12-20 07:59:59','2019-12-24 15:59:59','ETCUSDT','4h','3.806700000000000','3.928700000000000','15.130856405481431','15.615781532617465','3.9747961240658394','3.974796124065839','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  7:08:21
