-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','0.072144500000000','0.075379153504910','244.30917710802572','244.309177108025722','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','DLTETH','4h','0.000311960000000','0.000308990000000','0.072953163376227','0.072258616334211','233.85422290110108','233.854222901101082','test'),('2019-01-06 19:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000317850000000','0.001133500000000','0.072953163376227','0.260161745121766','229.52072794156678','229.520727941566776','test'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','0.119581672052108','0.118792776585464','109.41684696871467','109.416846968714665','test'),('2019-02-06 07:59:59','2019-02-06 11:59:59','DLTETH','4h','0.001151260000000','0.001051900000000','0.119581672052108','0.109261123318462','103.87025698114066','103.870256981140656','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000782380000000','0.119581672052108','0.113757001823997','145.39865771619571','145.398657716195714','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','0.119581672052108','0.120572493971802','164.58835875315947','164.588358753159469','test'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','0.119581672052108','0.121473813150086','164.5340085198035','164.534008519803507','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','DLTETH','4h','0.000720120000000','0.000737110000000','0.119581672052108','0.122402997120382','166.05797929804478','166.057979298044785','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','DLTETH','4h','0.000718790000000','0.000718260000000','0.119581672052108','0.119493498474029','166.36524165904925','166.365241659049246','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','0.119581672052108','0.118443124749552','162.88230365602593','162.882303656025925','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','DLTETH','4h','0.000725570000000','0.000714140000000','0.119581672052108','0.117697886185058','164.8106620341359','164.810662034135902','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','0.119581672052108','0.120858157381596','164.4955321504732','164.495532150473196','test'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','0.119581672052108','0.119345044229966','156.70716698175576','156.707166981755762','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','DLTETH','4h','0.000782480000000','0.000768090000000','0.119581672052108','0.117382535638615','152.82393422465495','152.823934224654948','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000830370000000','0.000861450000000','0.119581672052108','0.124057506159048','144.01010640089117','144.010106400891175','test'),('2019-05-05 23:59:59','2019-05-07 23:59:59','DLTETH','4h','0.000587770000000','0.000524280000000','0.119581672052108','0.106664646074960','203.4497712576484','203.449771257648393','test'),('2019-05-10 07:59:59','2019-05-11 03:59:59','DLTETH','4h','0.000624000000000','0.000528080000000','0.119581672052108','0.101199822719996','191.6372949553013','191.637294955301286','test'),('2019-05-12 15:59:59','2019-05-12 19:59:59','DLTETH','4h','0.000554000000000','0.000547750000000','0.119581672052108','0.118232600842134','215.85139359586282','215.851393595862817','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','DLTETH','4h','0.000491160000000','0.000485690000000','0.119581672052108','0.118249902880911','243.46785579466567','243.467855794665667','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','DLTETH','4h','0.000495470000000','0.000490960000000','0.119581672052108','0.118493183665415','241.34997487659797','241.349974876597969','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','DLTETH','4h','0.000460610000000','0.000450870000000','0.119581672052108','0.117053013347808','259.61588339833696','259.615883398336962','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','DLTETH','4h','0.000447870000000','0.000447280000000','0.119581672052108','0.119424141548813','267.00085304241856','267.000853042418555','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','DLTETH','4h','0.000445900000000','0.000445120000000','0.119581672052108','0.119372491284670','268.1804710744741','268.180471074474099','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','DLTETH','4h','0.000467780000000','0.000461350000000','0.119581672052108','0.117937928943606','255.63656430823892','255.636564308238917','test'),('2019-07-15 23:59:59','2019-07-17 15:59:59','DLTETH','4h','0.000293110000000','0.000288720000000','0.119581672052108','0.117790660007794','407.9754087274675','407.975408727467482','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','DLTETH','4h','0.000288340000000','0.000284850000000','0.119581672052108','0.118134283429434','414.7245337175141','414.724533717514078','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','DLTETH','4h','0.000285730000000','0.000297270000000','0.119581672052108','0.124411310156197','418.5128339765093','418.512833976509285','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','DLTETH','4h','0.000286860000000','0.000280900000000','0.119581672052108','0.117097161261372','416.86422663357735','416.864226633577346','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','DLTETH','4h','0.000285730000000','0.000285730000000','0.119581672052108','0.119581672052108','418.5128339765093','418.512833976509285','test'),('2019-07-28 15:59:59','2019-07-30 15:59:59','DLTETH','4h','0.000295960000000','0.000287650000000','0.119581672052108','0.116224043674108','404.04673622147584','404.046736221475840','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','DLTETH','4h','0.000294200000000','0.000280470000000','0.119581672052108','0.114000923047093','406.4638750921414','406.463875092141393','test'),('2019-08-02 03:59:59','2019-08-02 07:59:59','DLTETH','4h','0.000303730000000','0.000288820000000','0.119581672052108','0.113711449386264','393.71044036515326','393.710440365153261','test'),('2019-08-04 11:59:59','2019-08-04 15:59:59','DLTETH','4h','0.000292380000000','0.000287400000000','0.119581672052108','0.117544881824256','408.9940216571174','408.994021657117401','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','DLTETH','4h','0.000247400000000','0.000242650000000','0.119581672052108','0.117285742616993','483.3535652874212','483.353565287421191','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','DLTETH','4h','0.000247660000000','0.000260270000000','0.119581672052108','0.125670361725762','482.8461279661955','482.846127966195525','test'),('2019-08-24 03:59:59','2019-08-26 03:59:59','DLTETH','4h','0.000252410000000','0.000256620000000','0.119581672052108','0.121576200158520','473.7596452284299','473.759645228429918','test'),('2019-09-10 07:59:59','2019-09-10 19:59:59','DLTETH','4h','0.000217480000000','0.000208570000000','0.119581672052108','0.114682496505004','549.8513520880448','549.851352088044791','test'),('2019-09-11 03:59:59','2019-09-11 07:59:59','DLTETH','4h','0.000209590000000','0.000209020000000','0.119581672052108','0.119256458286806','570.5504654425688','570.550465442568793','test'),('2019-09-14 19:59:59','2019-09-15 03:59:59','DLTETH','4h','0.000331540000000','0.000252000000000','0.119581672052108','0.090892747050525','360.6855041687519','360.685504168751891','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','DLTETH','4h','0.000221230000000','0.000205700000000','0.119581672052108','0.111187225697774','540.5309951277313','540.530995127731330','test'),('2019-09-19 11:59:59','2019-09-19 15:59:59','DLTETH','4h','0.000217850000000','0.000207900000000','0.119581672052108','0.114119943170224','548.9174755662519','548.917475566251937','test'),('2019-09-20 07:59:59','2019-09-21 23:59:59','DLTETH','4h','0.000217550000000','0.000218220000000','0.119581672052108','0.119949953919609','549.6744291064491','549.674429106449111','test'),('2019-09-23 07:59:59','2019-09-24 15:59:59','DLTETH','4h','0.000224760000000','0.000220990000000','0.119581672052108','0.117575875185955','532.0416090590318','532.041609059031771','test'),('2019-09-25 07:59:59','2019-09-25 11:59:59','DLTETH','4h','0.000220550000000','0.000215380000000','0.119581672052108','0.116778510662358','542.1975608801089','542.197560880108881','test'),('2019-09-25 15:59:59','2019-09-26 23:59:59','DLTETH','4h','0.000250200000000','0.000238890000000','0.119581672052108','0.114176121648793','477.9443327422382','477.944332742238203','test'),('2019-10-15 07:59:59','2019-10-15 11:59:59','DLTETH','4h','0.000247680000000','0.000247750000000','0.079721114701405','0.079743645701199','321.8714256355189','321.871425635518904','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','DLTETH','4h','0.000234290000000','0.000232670000000','0.089537758132725','0.088918648618128','382.16636703540695','382.166367035406950','test'),('2019-10-24 19:59:59','2019-10-24 23:59:59','DLTETH','4h','0.000240820000000','0.000238580000000','0.089537758132725','0.088704917927521','371.80366303764225','371.803663037642252','test'),('2019-10-29 07:59:59','2019-10-29 11:59:59','DLTETH','4h','0.000231500000000','0.000226740000000','0.089537758132725','0.087696722587534','386.7721733595033','386.772173359503313','test'),('2019-10-30 15:59:59','2019-10-30 23:59:59','DLTETH','4h','0.000230480000000','0.000226930000000','0.089537758132725','0.088158640459299','388.4838516692338','388.483851669233786','test'),('2019-11-03 11:59:59','2019-11-04 15:59:59','DLTETH','4h','0.000234850000000','0.000225320000000','0.089537758132725','0.085904397115033','381.2550910484352','381.255091048435190','test'),('2019-11-05 19:59:59','2019-11-05 23:59:59','DLTETH','4h','0.000229660000000','0.000232700000000','0.089537758132725','0.090722965764544','389.87093151931117','389.870931519311171','test'),('2019-11-07 15:59:59','2019-11-08 11:59:59','DLTETH','4h','0.000231270000000','0.000225820000000','0.089537758132725','0.087427753454975','387.1568216055909','387.156821605590892','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','DLTETH','4h','0.000226820000000','0.000231280000000','0.089537758132725','0.091298354205699','394.75248272958737','394.752482729587371','test'),('2019-11-22 03:59:59','2019-11-22 07:59:59','DLTETH','4h','0.000246770000000','0.000244110000000','0.089537758132725','0.088572606628762','362.83891126443655','362.838911264436547','test'),('2019-11-22 15:59:59','2019-11-22 19:59:59','DLTETH','4h','0.000246970000000','0.000248910000000','0.089537758132725','0.090241095585766','362.5450788870106','362.545078887010618','test'),('2019-12-03 19:59:59','2019-12-03 23:59:59','DLTETH','4h','0.000277470000000','0.000276770000000','0.089537758132725','0.089311872701172','322.69347364661047','322.693473646610471','test'),('2019-12-04 15:59:59','2019-12-04 23:59:59','DLTETH','4h','0.000278590000000','0.000275720000000','0.089537758132725','0.088615351133763','321.39616688583584','321.396166885835839','test'),('2019-12-06 15:59:59','2019-12-06 19:59:59','DLTETH','4h','0.000278520000000','0.000281940000000','0.089537758132725','0.090637209277397','321.47694288641753','321.476942886417532','test'),('2019-12-16 11:59:59','2019-12-17 11:59:59','DLTETH','4h','0.000277130000000','0.000279830000000','0.089537758132725','0.090410099441708','323.08937369727204','323.089373697272038','test'),('2019-12-19 11:59:59','2019-12-19 15:59:59','DLTETH','4h','0.000280070000000','0.000272020000000','0.089537758132725','0.086964190978198','319.6977831710823','319.697783171082278','test'),('2019-12-23 07:59:59','2019-12-23 15:59:59','DLTETH','4h','0.000278360000000','0.000277340000000','0.089537758132725','0.089209663171900','321.6617262994863','321.661726299486304','test'),('2019-12-30 07:59:59','2019-12-30 11:59:59','DLTETH','4h','0.000291510000000','0.000291530000000','0.089537758132725','0.089543901164397','307.15158359138627','307.151583591386270','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:31:35
