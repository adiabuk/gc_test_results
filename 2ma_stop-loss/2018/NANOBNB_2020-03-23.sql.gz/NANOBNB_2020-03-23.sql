-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-21 15:59:59','2018-07-21 19:59:59','NANOBNB','4h','0.201000000000000','0.197600000000000','0.711908500000000','0.699866266666667','3.5418333333333334','3.541833333333333','test'),('2018-07-21 23:59:59','2018-07-22 03:59:59','NANOBNB','4h','0.200000000000000','0.196800000000000','0.711908500000000','0.700517964000000','3.5595425','3.559542500000000','test'),('2018-08-15 15:59:59','2018-08-15 19:59:59','NANOBNB','4h','0.124300000000000','0.114700000000000','0.711908500000000','0.656926025341915','5.727341110217217','5.727341110217217','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','NANOBNB','4h','0.258400000000000','0.266500000000000','0.711908500000000','0.734224517221362','2.755063854489164','2.755063854489164','test'),('2018-09-13 11:59:59','2018-09-17 11:59:59','NANOBNB','4h','0.235700000000000','0.246700000000000','0.711908500000000','0.745132910267289','3.0204009333899027','3.020400933389903','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','NANOBNB','4h','0.242100000000000','0.235400000000000','0.711908500000000','0.692206777777778','2.9405555555555556','2.940555555555556','test'),('2018-09-18 15:59:59','2018-09-19 03:59:59','NANOBNB','4h','0.248100000000000','0.241100000000000','0.711908500000000','0.691822407698509','2.8694417573559052','2.869441757355905','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','NANOBNB','4h','0.242000000000000','0.242600000000000','0.711908500000000','0.713673562396694','2.941770661157025','2.941770661157025','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','NANOBNB','4h','0.236600000000000','0.233800000000000','0.711908500000000','0.703483547337278','3.0089116652578194','3.008911665257819','test'),('2018-10-17 07:59:59','2018-10-18 15:59:59','NANOBNB','4h','0.208500000000000','0.205400000000000','0.711908500000000','0.701323769304556','3.4144292565947247','3.414429256594725','test'),('2018-10-18 23:59:59','2018-10-20 03:59:59','NANOBNB','4h','0.203500000000000','0.203600000000000','0.711908500000000','0.712258332186732','3.498321867321868','3.498321867321868','test'),('2018-10-22 19:59:59','2018-10-22 23:59:59','NANOBNB','4h','0.205800000000000','0.205900000000000','0.711908500000000','0.712254422497571','3.4592249757045677','3.459224975704568','test'),('2018-10-24 11:59:59','2018-10-24 19:59:59','NANOBNB','4h','0.206900000000000','0.208600000000000','0.711908500000000','0.717757917351378','3.4408337361043984','3.440833736104398','test'),('2018-10-26 11:59:59','2018-10-27 19:59:59','NANOBNB','4h','0.210500000000000','0.206200000000000','0.711908500000000','0.697365951068884','3.38198812351544','3.381988123515440','test'),('2018-10-31 11:59:59','2018-10-31 19:59:59','NANOBNB','4h','0.215700000000000','0.210700000000000','0.711908500000000','0.695406216736208','3.300456652758461','3.300456652758461','test'),('2018-11-20 15:59:59','2018-11-20 23:59:59','NANOBNB','4h','0.199100000000000','0.197000000000000','0.711908500000000','0.704399671019588','3.5756328478151684','3.575632847815168','test'),('2018-11-23 07:59:59','2018-11-23 15:59:59','NANOBNB','4h','0.189800000000000','0.192800000000000','0.711908500000000','0.723161005268704','3.7508350895679667','3.750835089567967','test'),('2018-12-07 19:59:59','2018-12-08 03:59:59','NANOBNB','4h','0.186100000000000','0.186000000000000','0.711908500000000','0.711525959161741','3.825408382590006','3.825408382590006','test'),('2018-12-09 03:59:59','2018-12-09 07:59:59','NANOBNB','4h','0.185200000000000','0.184900000000000','0.711908500000000','0.710755300485961','3.84399838012959','3.843998380129590','test'),('2018-12-19 03:59:59','2018-12-19 15:59:59','NANOBNB','4h','0.176700000000000','0.170600000000000','0.711908500000000','0.687332145444256','4.028910582908885','4.028910582908885','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','NANOBNB','4h','0.178400000000000','0.177800000000000','0.711908500000000','0.709514188901345','3.9905184977578476','3.990518497757848','test'),('2018-12-25 23:59:59','2018-12-26 03:59:59','NANOBNB','4h','0.176800000000000','0.174100000000000','0.711908500000000','0.701036594174208','4.026631787330317','4.026631787330317','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','NANOBNB','4h','0.162600000000000','0.155100000000000','0.711908500000000','0.679071392066421','4.378281057810579','4.378281057810579','test'),('2019-01-23 03:59:59','2019-01-23 19:59:59','NANOBNB','4h','0.145100000000000','0.142000000000000','0.711908500000000','0.696698876636802','4.906330117160579','4.906330117160579','test'),('2019-01-28 19:59:59','2019-01-28 23:59:59','NANOBNB','4h','0.147100000000000','0.145300000000000','0.711908500000000','0.703197179129844','4.83962270564242','4.839622705642420','test'),('2019-01-29 11:59:59','2019-01-29 15:59:59','NANOBNB','4h','0.143400000000000','0.140900000000000','0.711908500000000','0.699497263947002','4.964494421199443','4.964494421199443','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','NANOBNB','4h','0.143000000000000','0.140500000000000','0.711908500000000','0.699462547202797','4.97838111888112','4.978381118881120','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','NANOBNB','4h','0.143200000000000','0.144800000000000','0.711908500000000','0.719862784916201','4.971428072625699','4.971428072625699','test'),('2019-02-24 07:59:59','2019-02-24 11:59:59','NANOBNB','4h','0.092600000000000','0.091500000000000','0.711908500000000','0.703451703563715','7.68799676025918','7.687996760259180','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','NANOBNB','4h','0.090800000000000','0.090700000000000','0.711908500000000','0.711124459801762','7.840401982378855','7.840401982378855','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','NANOBNB','4h','0.069300000000000','0.067100000000000','0.711908500000000','0.689308230158730','10.27284992784993','10.272849927849929','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','NANOBNB','4h','0.068000000000000','0.067600000000000','0.711908500000000','0.707720802941176','10.469242647058824','10.469242647058824','test'),('2019-03-20 11:59:59','2019-03-21 03:59:59','NANOBNB','4h','0.066900000000000','0.066800000000000','0.711908500000000','0.710844361733931','10.641382660687594','10.641382660687594','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOBNB','4h','0.067000000000000','0.065700000000000','0.711908500000000','0.698095350000000','10.6255','10.625500000000001','test'),('2019-03-29 23:59:59','2019-03-30 07:59:59','NANOBNB','4h','0.063000000000000','0.062200000000000','0.711908500000000','0.702868392063492','11.300134920634921','11.300134920634921','test'),('2019-03-31 15:59:59','2019-03-31 23:59:59','NANOBNB','4h','0.063900000000000','0.062700000000000','0.711908500000000','0.698539326291080','11.140978090766824','11.140978090766824','test'),('2019-04-15 03:59:59','2019-04-15 11:59:59','NANOBNB','4h','0.082000000000000','0.079200000000000','0.711908500000000','0.687599429268293','8.681810975609757','8.681810975609757','test'),('2019-04-17 07:59:59','2019-04-18 07:59:59','NANOBNB','4h','0.083000000000000','0.079700000000000','0.711908500000000','0.683603704216867','8.577210843373495','8.577210843373495','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','NANOBNB','4h','0.076300000000000','0.076500000000000','0.711908500000000','0.713774577326343','9.330386631716907','9.330386631716907','test'),('2019-04-25 11:59:59','2019-04-25 15:59:59','NANOBNB','4h','0.078300000000000','0.078400000000000','0.711908500000000','0.712817706257982','9.092062579821201','9.092062579821201','test'),('2019-05-07 03:59:59','2019-05-13 07:59:59','NANOBNB','4h','0.069000000000000','0.072700000000000','0.711908500000000','0.750083303623188','10.317514492753624','10.317514492753624','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','NANOBNB','4h','0.073200000000000','0.072200000000000','0.711908500000000','0.702182974043716','9.725525956284153','9.725525956284153','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','NANOBNB','4h','0.072600000000000','0.071600000000000','0.711908500000000','0.702102597796143','9.80590220385675','9.805902203856750','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','NANOBNB','4h','0.054300000000000','0.053200000000000','0.711908500000000','0.697486780847146','13.110653775322284','13.110653775322284','test'),('2019-06-14 03:59:59','2019-06-14 15:59:59','NANOBNB','4h','0.050600000000000','0.050300000000000','0.711908500000000','0.707687698616601','14.069337944664033','14.069337944664033','test'),('2019-07-01 23:59:59','2019-07-02 03:59:59','NANOBNB','4h','0.040200000000000','0.040500000000000','0.711908500000000','0.717221250000000','17.70916666666667','17.709166666666668','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','NANOBNB','4h','0.040000000000000','0.039000000000000','0.711908500000000','0.694110787500000','17.7977125','17.797712499999999','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','NANOBNB','4h','0.039400000000000','0.038400000000000','0.711908500000000','0.693839756345178','18.068743654822338','18.068743654822338','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOBNB','4h','0.039500000000000','0.039200000000000','0.711908500000000','0.706501600000000','18.023','18.023000000000000','test'),('2019-07-17 19:59:59','2019-07-18 07:59:59','NANOBNB','4h','0.041110000000000','0.039400000000000','0.711908500000000','0.682296154220384','17.317161274629044','17.317161274629044','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','NANOBNB','4h','0.038050000000000','0.036820000000000','0.711908500000000','0.688895426281209','18.709816031537454','18.709816031537454','test'),('2019-07-20 23:59:59','2019-07-21 03:59:59','NANOBNB','4h','0.038270000000000','0.037330000000000','0.711908500000000','0.694422375359289','18.602260256075258','18.602260256075258','test'),('2019-07-21 07:59:59','2019-07-21 11:59:59','NANOBNB','4h','0.038180000000000','0.039910000000000','0.711908500000000','0.744166271215296','18.646110529072814','18.646110529072814','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:57:58
