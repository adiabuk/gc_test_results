-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-29 23:59:59','2018-05-30 03:59:59','LENDETH','4h','0.000079730000000','0.000079000000000','0.072144500000000','0.071483952088298','904.8601530164304','904.860153016430445','test'),('2018-05-30 07:59:59','2018-05-30 11:59:59','LENDETH','4h','0.000081700000000','0.000080550000000','0.072144500000000','0.071129002141983','883.0416156670748','883.041615667074780','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','LENDETH','4h','0.000080040000000','0.000078380000000','0.072144500000000','0.070648249750125','901.3555722138931','901.355572213893083','test'),('2018-05-31 15:59:59','2018-05-31 23:59:59','LENDETH','4h','0.000080000000000','0.000079540000000','0.072144500000000','0.071729669125000','901.80625','901.806249999999977','test'),('2018-06-01 19:59:59','2018-06-02 03:59:59','LENDETH','4h','0.000080600000000','0.000080630000000','0.072144500000000','0.072171352791563','895.0930521091813','895.093052109181258','test'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDETH','4h','0.000077580000000','0.000077610000000','0.072144500000000','0.072172398105182','929.9368393915958','929.936839391595754','test'),('2018-06-28 11:59:59','2018-06-28 15:59:59','LENDETH','4h','0.000059100000000','0.000058220000000','0.072144500000000','0.071070267174281','1220.7191201353637','1220.719120135363710','test'),('2018-06-30 07:59:59','2018-06-30 11:59:59','LENDETH','4h','0.000057380000000','0.000056350000000','0.072144500000000','0.070849469762984','1257.3109097246427','1257.310909724642670','test'),('2018-06-30 15:59:59','2018-06-30 19:59:59','LENDETH','4h','0.000057820000000','0.000061610000000','0.072144500000000','0.076873445952957','1247.742995503286','1247.742995503286011','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','LENDETH','4h','0.000065610000000','0.000065960000000','0.072144500000000','0.072529358634355','1099.596098155769','1099.596098155768914','test'),('2018-07-17 03:59:59','2018-07-17 07:59:59','LENDETH','4h','0.000060430000000','0.000058620000000','0.072144500000000','0.069983627171934','1193.8523911964255','1193.852391196425515','test'),('2018-07-17 19:59:59','2018-07-20 03:59:59','LENDETH','4h','0.000061040000000','0.000061200000000','0.072144500000000','0.072333607470511','1181.9216906946265','1181.921690694626477','test'),('2018-07-30 15:59:59','2018-07-31 11:59:59','LENDETH','4h','0.000059700000000','0.000058380000000','0.072144500000000','0.070549345226131','1208.4505862646565','1208.450586264656522','test'),('2018-08-13 07:59:59','2018-08-13 11:59:59','LENDETH','4h','0.000050100000000','0.000049980000000','0.072144500000000','0.071971698802395','1440.0099800399203','1440.009980039920265','test'),('2018-08-17 11:59:59','2018-08-17 15:59:59','LENDETH','4h','0.000048690000000','0.000047990000000','0.072144500000000','0.071107302423496','1481.7108235777366','1481.710823577736619','test'),('2018-08-23 23:59:59','2018-08-24 03:59:59','LENDETH','4h','0.000046350000000','0.000046170000000','0.072144500000000','0.071864327184466','1556.5156418554477','1556.515641855447711','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','LENDETH','4h','0.000046470000000','0.000045950000000','0.072144500000000','0.071337201958253','1552.4962341295459','1552.496234129545883','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','LENDETH','4h','0.000046660000000','0.000046000000000','0.072144500000000','0.071124024860694','1546.1744534933564','1546.174453493356395','test'),('2018-08-31 03:59:59','2018-09-12 11:59:59','LENDETH','4h','0.000048870000000','0.000057810000000','0.072144500000000','0.085342204726826','1476.2533251483528','1476.253325148352815','test'),('2018-09-16 15:59:59','2018-09-17 11:59:59','LENDETH','4h','0.000056340000000','0.000070060000000','0.073525751337858','0.091430850882682','1305.0364099726391','1305.036409972639149','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','LENDETH','4h','0.000060390000000','0.000059520000000','0.078002026224064','0.076878301057398','1291.6381226041478','1291.638122604147839','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','LENDETH','4h','0.000062840000000','0.000062060000000','0.078002026224064','0.077033827935478','1241.2798571620624','1241.279857162062399','test'),('2018-10-02 11:59:59','2018-10-11 23:59:59','LENDETH','4h','0.000062360000000','0.000073780000000','0.078002026224064','0.092286553797489','1250.8342883910198','1250.834288391019754','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LENDETH','4h','0.000075400000000','0.000072200000000','0.081050177253608','0.077610381932500','1074.9360378462566','1074.936037846256568','test'),('2018-10-17 19:59:59','2018-10-20 03:59:59','LENDETH','4h','0.000075080000000','0.000095690000000','0.081050177253608','0.103299033849198','1079.5175446671283','1079.517544667128277','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','LENDETH','4h','0.000074430000000','0.000072440000000','0.085752442572228','0.083459719735754','1152.1220283787216','1152.122028378721552','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','LENDETH','4h','0.000077600000000','0.000076510000000','0.085752442572228','0.084547930170118','1105.0572496421134','1105.057249642113447','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','LENDETH','4h','0.000078080000000','0.000076500000000','0.085752442572228','0.084017185665669','1098.263864910707','1098.263864910707071','test'),('2018-12-12 19:59:59','2018-12-13 03:59:59','LENDETH','4h','0.000078200000000','0.000077000000000','0.085752442572228','0.084436548312808','1096.578549516982','1096.578549516982093','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','LENDETH','4h','0.000076590000000','0.000077700000000','0.085752442572228','0.086995231595014','1119.6297502575794','1119.629750257579417','test'),('2019-01-10 11:59:59','2019-01-10 19:59:59','LENDETH','4h','0.000057150000000','0.000054620000000','0.085752442572228','0.081956227704201','1500.480184990866','1500.480184990866064','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','0.085752442572228','0.085296555051908','1519.6250677339713','1519.625067733971264','test'),('2019-01-12 19:59:59','2019-01-27 15:59:59','LENDETH','4h','0.000057470000000','0.000071030000000','0.085752442572228','0.105985662013317','1492.1253275139725','1492.125327513972479','test'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','0.088421322489969','0.087891626933760','1261.1798957348378','1261.179895734837828','test'),('2019-01-29 07:59:59','2019-01-29 11:59:59','LENDETH','4h','0.000070090000000','0.000070100000000','0.088421322489969','0.088433937887671','1261.5397701522186','1261.539770152218580','test'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000070330000000','0.088421322489969','0.086250646473225','1226.370630928835','1226.370630928834998','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDETH','4h','0.000073720000000','0.000071470000000','0.088421322489969','0.085722625045552','1199.42108640761','1199.421086407609891','test'),('2019-02-03 11:59:59','2019-02-03 15:59:59','LENDETH','4h','0.000070910000000','0.000070350000000','0.088421322489969','0.087723029716109','1246.9513818921027','1246.951381892102745','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','LENDETH','4h','0.000056950000000','0.000056250000000','0.088421322489969','0.087334493240751','1552.6132131689026','1552.613213168902575','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','LENDETH','4h','0.000056940000000','0.000056590000000','0.088421322489969','0.087877812429002','1552.8858884785566','1552.885888478556581','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','LENDETH','4h','0.000057280000000','0.000056480000000','0.088421322489969','0.087186387818321','1543.6683395595148','1543.668339559514834','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','LENDETH','4h','0.000057330000000','0.000056710000000','0.088421322489969','0.087465082825853','1542.3220388970697','1542.322038897069660','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','LENDETH','4h','0.000063210000000','0.000061380000000','0.088421322489969','0.085861426584944','1398.8502213252493','1398.850221325249322','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','LENDETH','4h','0.000066750000000','0.000064460000000','0.088421322489969','0.085387841913160','1324.6640073403598','1324.664007340359831','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','0.088421322489969','0.097093517480977','1348.7083967353417','1348.708396735341694','test'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000068740000000','0.088421322489969','0.086681142440965','1261.0000355101113','1261.000035510111275','test'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000066160000000','0.088421322489969','0.083237830050318','1258.1292329250002','1258.129232925000224','test'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','0.088421322489969','0.088196668106121','1321.496375578673','1321.496375578672996','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','LENDETH','4h','0.000066540000000','0.000065760000000','0.088421322489969','0.087384823669077','1328.8446421696576','1328.844642169657618','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000065300000000','0.088421322489969','0.086435813751422','1323.6724923648055','1323.672492364805521','test'),('2019-04-20 11:59:59','2019-04-20 15:59:59','LENDETH','4h','0.000066200000000','0.000064980000000','0.088421322489969','0.086791805670667','1335.669524017659','1335.669524017658887','test'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000035790000000','0.088421322489969','0.080136721496986','2239.0813494547733','2239.081349454773317','test'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDETH','4h','0.000039090000000','0.000038310000000','0.088421322489969','0.086656967628312','2261.9934123808903','2261.993412380890277','test'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','0.088421322489969','0.089291791467850','2290.7078365276943','2290.707836527694326','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:44:17
