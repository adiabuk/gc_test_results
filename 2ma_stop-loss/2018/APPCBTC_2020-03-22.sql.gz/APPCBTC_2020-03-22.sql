-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 03:59:59','APPCBTC','4h','0.000028850000000','0.000028020000000','0.001467500000000','0.001425280762565','50.86655112651647','50.866551126516470','test'),('2018-07-08 15:59:59','2018-07-08 19:59:59','APPCBTC','4h','0.000034010000000','0.000033270000000','0.001467500000000','0.001435569685387','43.14907380182299','43.149073801822993','test'),('2018-07-11 11:59:59','2018-07-11 15:59:59','APPCBTC','4h','0.000032350000000','0.000031870000000','0.001467500000000','0.001445725656878','45.36321483771252','45.363214837712519','test'),('2018-07-13 19:59:59','2018-07-13 23:59:59','APPCBTC','4h','0.000031540000000','0.000029920000000','0.001467500000000','0.001392124286620','46.5282181357007','46.528218135700698','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','APPCBTC','4h','0.000031500000000','0.000030670000000','0.001467500000000','0.001428832539683','46.58730158730159','46.587301587301589','test'),('2018-07-17 15:59:59','2018-07-17 19:59:59','APPCBTC','4h','0.000031520000000','0.000030940000000','0.001467500000000','0.001440496510152','46.55774111675127','46.557741116751266','test'),('2018-07-18 19:59:59','2018-07-18 23:59:59','APPCBTC','4h','0.000030770000000','0.000029960000000','0.001467500000000','0.001428869028274','47.69255768605785','47.692557686057853','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','APPCBTC','4h','0.000013250000000','0.000013190000000','0.001467500000000','0.001460854716981','110.75471698113208','110.754716981132077','test'),('2018-08-26 15:59:59','2018-08-30 11:59:59','APPCBTC','4h','0.000013510000000','0.000013340000000','0.001467500000000','0.001449034048853','108.62324204293117','108.623242042931167','test'),('2018-08-30 23:59:59','2018-08-31 03:59:59','APPCBTC','4h','0.000013970000000','0.000014180000000','0.001467500000000','0.001489559770938','105.04652827487473','105.046528274874731','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','APPCBTC','4h','0.000014250000000','0.000013880000000','0.001467500000000','0.001429396491228','102.98245614035088','102.982456140350877','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','APPCBTC','4h','0.000014660000000','0.000014430000000','0.001467500000000','0.001444476466576','100.10231923601637','100.102319236016370','test'),('2018-09-15 03:59:59','2018-09-15 07:59:59','APPCBTC','4h','0.000012040000000','0.000012140000000','0.001467500000000','0.001479688538206','121.88538205980068','121.885382059800676','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','APPCBTC','4h','0.000012210000000','0.000011950000000','0.001467500000000','0.001436251023751','120.18837018837019','120.188370188370186','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','APPCBTC','4h','0.000016990000000','0.000016810000000','0.001467500000000','0.001451952619188','86.37433784579164','86.374337845791644','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','APPCBTC','4h','0.000017150000000','0.000016660000000','0.001467500000000','0.001425571428571','85.56851311953353','85.568513119533534','test'),('2018-10-15 23:59:59','2018-10-16 03:59:59','APPCBTC','4h','0.000016230000000','0.000016040000000','0.001467500000000','0.001450320394331','90.41897720271103','90.418977202711034','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','APPCBTC','4h','0.000016180000000','0.000015990000000','0.001467500000000','0.001450267305315','90.69839307787392','90.698393077873916','test'),('2018-10-27 11:59:59','2018-10-27 15:59:59','APPCBTC','4h','0.000017170000000','0.000016580000000','0.001467500000000','0.001417073383809','85.46884100174724','85.468841001747236','test'),('2018-10-27 19:59:59','2018-10-27 23:59:59','APPCBTC','4h','0.000016740000000','0.000019600000000','0.001467500000000','0.001718219832736','87.66427718040622','87.664277180406216','test'),('2018-10-29 19:59:59','2018-10-30 03:59:59','APPCBTC','4h','0.000017850000000','0.000017650000000','0.001467500000000','0.001451057422969','82.21288515406162','82.212885154061624','test'),('2018-11-04 19:59:59','2018-11-04 23:59:59','APPCBTC','4h','0.000018460000000','0.000018900000000','0.001467500000000','0.001502478331528','79.49620801733478','79.496208017334780','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','APPCBTC','4h','0.000012210000000','0.000012010000000','0.001467500000000','0.001443462325962','120.18837018837019','120.188370188370186','test'),('2018-12-01 07:59:59','2018-12-03 07:59:59','APPCBTC','4h','0.000012250000000','0.000012100000000','0.001467500000000','0.001449530612245','119.79591836734694','119.795918367346943','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','APPCBTC','4h','0.000011290000000','0.000011240000000','0.001467500000000','0.001461000885740','129.9822852081488','129.982285208148795','test'),('2018-12-18 15:59:59','2018-12-18 19:59:59','APPCBTC','4h','0.000011260000000','0.000011330000000','0.001467500000000','0.001476623001776','130.32859680284193','130.328596802841929','test'),('2018-12-22 03:59:59','2018-12-25 03:59:59','APPCBTC','4h','0.000011350000000','0.000011050000000','0.001467500000000','0.001428711453744','129.29515418502203','129.295154185022028','test'),('2018-12-29 07:59:59','2018-12-29 11:59:59','APPCBTC','4h','0.000011310000000','0.000011240000000','0.001467500000000','0.001458417329797','129.7524314765694','129.752431476569399','test'),('2018-12-30 19:59:59','2018-12-30 23:59:59','APPCBTC','4h','0.000011470000000','0.000011300000000','0.001467500000000','0.001445749782040','127.94245858761988','127.942458587619882','test'),('2019-01-01 23:59:59','2019-01-02 15:59:59','APPCBTC','4h','0.000011330000000','0.000011350000000','0.001467500000000','0.001470090467785','129.5233892321271','129.523389232127101','test'),('2019-01-04 03:59:59','2019-01-08 03:59:59','APPCBTC','4h','0.000011400000000','0.000011510000000','0.001467500000000','0.001481660087719','128.7280701754386','128.728070175438603','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','APPCBTC','4h','0.000011710000000','0.000011800000000','0.001467500000000','0.001478778821520','125.32023911187021','125.320239111870208','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','APPCBTC','4h','0.000011440000000','0.000011750000000','0.001467500000000','0.001507266171329','128.27797202797203','128.277972027972027','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','APPCBTC','4h','0.000013100000000','0.000012670000000','0.001467500000000','0.001419330152672','112.02290076335878','112.022900763358777','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','APPCBTC','4h','0.000012380000000','0.000012000000000','0.001467500000000','0.001422455573506','118.53796445880452','118.537964458804524','test'),('2019-02-09 19:59:59','2019-02-10 07:59:59','APPCBTC','4h','0.000012510000000','0.000012100000000','0.001467500000000','0.001419404476419','117.30615507593924','117.306155075939245','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','APPCBTC','4h','0.000015410000000','0.000014880000000','0.001467500000000','0.001417027903958','95.23036988968202','95.230369889682024','test'),('2019-03-01 23:59:59','2019-03-03 03:59:59','APPCBTC','4h','0.000015490000000','0.000018730000000','0.001467500000000','0.001774452872821','94.7385409941898','94.738540994189805','test'),('2019-03-12 15:59:59','2019-03-12 19:59:59','APPCBTC','4h','0.000019920000000','0.000019750000000','0.001467500000000','0.001454976154618','73.66967871485944','73.669678714859444','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','APPCBTC','4h','0.000019470000000','0.000019180000000','0.001467500000000','0.001445642013354','75.3723677452491','75.372367745249093','test'),('2019-03-14 23:59:59','2019-03-16 07:59:59','APPCBTC','4h','0.000019440000000','0.000019040000000','0.001467500000000','0.001437304526749','75.48868312757202','75.488683127572017','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','APPCBTC','4h','0.000019340000000','0.000019190000000','0.001467500000000','0.001456118148914','75.87900723888315','75.879007238883148','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','APPCBTC','4h','0.000020090000000','0.000019580000000','0.001467500000000','0.001430246391239','73.04629168740668','73.046291687406679','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','APPCBTC','4h','0.000019670000000','0.000019300000000','0.001467500000000','0.001439895780376','74.60599898322319','74.605998983223188','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','APPCBTC','4h','0.000020130000000','0.000019000000000','0.001467500000000','0.001385121708892','72.90114257327373','72.901142573273731','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','APPCBTC','4h','0.000012720000000','0.000012170000000','0.001467500000000','0.001404046776730','115.36949685534591','115.369496855345915','test'),('2019-05-16 23:59:59','2019-05-17 03:59:59','APPCBTC','4h','0.000010710000000','0.000010040000000','0.001467500000000','0.001375695611578','137.02147525676938','137.021475256769378','test'),('2019-05-21 19:59:59','2019-05-23 11:59:59','APPCBTC','4h','0.000010110000000','0.000010940000000','0.001467500000000','0.001587977250247','145.15331355093969','145.153313550939686','test'),('2019-05-28 07:59:59','2019-05-28 23:59:59','APPCBTC','4h','0.000011110000000','0.000010970000000','0.001467500000000','0.001449007650765','132.0882088208821','132.088208820882102','test'),('2019-05-29 07:59:59','2019-05-30 15:59:59','APPCBTC','4h','0.000011200000000','0.000010900000000','0.001467500000000','0.001428191964286','131.02678571428572','131.026785714285722','test'),('2019-05-31 11:59:59','2019-05-31 19:59:59','APPCBTC','4h','0.000011190000000','0.000011370000000','0.001467500000000','0.001491105898123','131.14387846291334','131.143878462913335','test'),('2019-06-01 07:59:59','2019-06-01 11:59:59','APPCBTC','4h','0.000011230000000','0.000011060000000','0.001467500000000','0.001445284951024','130.67675868210154','130.676758682101536','test'),('2019-06-01 19:59:59','2019-06-02 07:59:59','APPCBTC','4h','0.000011320000000','0.000011200000000','0.001467500000000','0.001451943462898','129.63780918727915','129.637809187279146','test'),('2019-06-04 11:59:59','2019-06-04 19:59:59','APPCBTC','4h','0.000011710000000','0.000011240000000','0.001467500000000','0.001408599487617','125.32023911187021','125.320239111870208','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','APPCBTC','4h','0.000011640000000','0.000011490000000','0.001467500000000','0.001448588917526','126.07388316151203','126.073883161512029','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:12:09
