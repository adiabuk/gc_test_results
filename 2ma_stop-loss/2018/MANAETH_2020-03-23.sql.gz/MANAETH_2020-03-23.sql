-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 15:59:59','2018-05-30 19:59:59','MANAETH','4h','0.000179650000000','0.000174760000000','0.072144500000000','0.070180756025605','401.58363484553297','401.583634845532970','test'),('2018-06-06 15:59:59','2018-06-07 03:59:59','MANAETH','4h','0.000172410000000','0.000172660000000','0.072144500000000','0.072249111826460','418.44730584072846','418.447305840728461','test'),('2018-06-20 15:59:59','2018-06-20 23:59:59','MANAETH','4h','0.000198780000000','0.000196540000000','0.072144500000000','0.071331522436865','362.9364121138948','362.936412113894789','test'),('2018-06-21 11:59:59','2018-06-21 15:59:59','MANAETH','4h','0.000195800000000','0.000190370000000','0.072144500000000','0.070143761312564','368.46016343207356','368.460163432073557','test'),('2018-06-22 15:59:59','2018-06-23 03:59:59','MANAETH','4h','0.000198010000000','0.000194530000000','0.072144500000000','0.070876569794455','364.3477602141306','364.347760214130574','test'),('2018-07-02 19:59:59','2018-07-02 23:59:59','MANAETH','4h','0.000198900000000','0.000196260000000','0.072144500000000','0.071186925942685','362.71744595274004','362.717445952740036','test'),('2018-07-03 07:59:59','2018-07-04 00:22:27','MANAETH','4h','0.000208860000000','0.000273670000000','0.072144500000000','0.094531194651920','345.42037728622046','345.420377286220457','test'),('2018-07-05 19:59:59','2018-07-05 23:59:59','MANAETH','4h','0.000229920000000','0.000223110000000','0.076016585497638','0.073765050410482','330.62189238708464','330.621892387084642','test'),('2018-07-09 19:59:59','2018-07-09 23:59:59','MANAETH','4h','0.000238000000000','0.000219730000000','0.076016585497638','0.070181194669731','319.3974180573025','319.397418057302502','test'),('2018-07-12 03:59:59','2018-07-12 07:59:59','MANAETH','4h','0.000219320000000','0.000217880000000','0.076016585497638','0.075517479701921','346.60124702552434','346.601247025524344','test'),('2018-07-12 19:59:59','2018-07-12 23:59:59','MANAETH','4h','0.000216300000000','0.000216600000000','0.076016585497638','0.076122017655055','351.44052472324546','351.440524723245460','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','MANAETH','4h','0.000218370000000','0.000214280000000','0.076016585497638','0.074592819253716','348.10910609350185','348.109106093501850','test'),('2018-07-15 07:59:59','2018-07-15 11:59:59','MANAETH','4h','0.000217300000000','0.000215840000000','0.076016585497638','0.075505843597838','349.82321904113206','349.823219041132063','test'),('2018-07-16 23:59:59','2018-07-20 23:59:59','MANAETH','4h','0.000217020000000','0.000267540000000','0.076016585497638','0.093712456382076','350.27456224144316','350.274562241443164','test'),('2018-07-30 23:59:59','2018-07-31 03:59:59','MANAETH','4h','0.000273500000000','0.000262650000000','0.077836776294477','0.074748918807109','284.5951601260576','284.595160126057579','test'),('2018-08-11 03:59:59','2018-08-11 11:59:59','MANAETH','4h','0.000252000000000','0.000247800000000','0.077836776294477','0.076539496689569','308.87609640665477','308.876096406654767','test'),('2018-08-13 15:59:59','2018-08-14 03:59:59','MANAETH','4h','0.000253410000000','0.000251060000000','0.077836776294477','0.077114956223083','307.15747718904936','307.157477189049359','test'),('2018-08-15 07:59:59','2018-08-15 11:59:59','MANAETH','4h','0.000250800000000','0.000246030000000','0.077836776294477','0.076356387845814','310.35397246601667','310.353972466016671','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','MANAETH','4h','0.000248650000000','0.000244930000000','0.077836776294477','0.076672276765760','313.0375077195938','313.037507719593805','test'),('2018-08-19 19:59:59','2018-08-19 23:59:59','MANAETH','4h','0.000245990000000','0.000247330000000','0.077836776294477','0.078260782474544','316.4225224378104','316.422522437810414','test'),('2018-08-21 15:59:59','2018-08-21 19:59:59','MANAETH','4h','0.000244430000000','0.000247720000000','0.077836776294477','0.078884450450713','318.4419927769791','318.441992776979077','test'),('2018-08-24 15:59:59','2018-08-24 19:59:59','MANAETH','4h','0.000244500000000','0.000242830000000','0.077836776294477','0.077305130419582','318.3508232902945','318.350823290294500','test'),('2018-08-25 03:59:59','2018-08-25 07:59:59','MANAETH','4h','0.000248210000000','0.000244720000000','0.077836776294477','0.076742338724404','313.5924269549051','313.592426954905079','test'),('2018-08-29 15:59:59','2018-08-29 23:59:59','MANAETH','4h','0.000288710000000','0.000280230000000','0.077836776294477','0.075550551837488','269.6019406826123','269.601940682612280','test'),('2018-09-06 15:59:59','2018-09-21 07:59:59','MANAETH','4h','0.000268290000000','0.000355790000000','0.077836776294477','0.103222433328905','290.12179467917923','290.121794679179231','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','MANAETH','4h','0.000329900000000','0.000310590000000','0.081635072376408','0.076856735766561','247.45399325979923','247.453993259799233','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','MANAETH','4h','0.000328880000000','0.000321180000000','0.081635072376408','0.079723767166914','248.22145577842377','248.221455778423774','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','MANAETH','4h','0.000326130000000','0.000332600000000','0.081635072376408','0.083254607280512','250.31451377183333','250.314513771833333','test'),('2018-10-02 11:59:59','2018-10-02 15:59:59','MANAETH','4h','0.000334680000000','0.000333960000000','0.081635072376408','0.081459450133935','243.91978121312297','243.919781213122974','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','MANAETH','4h','0.000339260000000','0.000340250000000','0.081635072376408','0.081873292979051','240.62687135650538','240.626871356505376','test'),('2018-10-10 19:59:59','2018-10-10 23:59:59','MANAETH','4h','0.000338470000000','0.000333630000000','0.081635072376408','0.080467720025234','241.18850230864774','241.188502308647742','test'),('2018-10-11 15:59:59','2018-10-11 19:59:59','MANAETH','4h','0.000360200000000','0.000349070000000','0.081635072376408','0.079112589434849','226.6381798345586','226.638179834558599','test'),('2018-10-14 07:59:59','2018-10-14 11:59:59','MANAETH','4h','0.000339970000000','0.000342720000000','0.081635072376408','0.082295414315506','240.12434149015505','240.124341490155047','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','MANAETH','4h','0.000344170000000','0.000342970000000','0.081635072376408','0.081350439529699','237.19403892381092','237.194038923810922','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','MANAETH','4h','0.000340820000000','0.000338640000000','0.081635072376408','0.081112906840992','239.52547496158678','239.525474961586781','test'),('2018-11-08 03:59:59','2018-11-13 19:59:59','MANAETH','4h','0.000386180000000','0.000495400000000','0.081635072376408','0.104723224546254','211.39124857943963','211.391248579439633','test'),('2018-11-21 15:59:59','2018-11-21 19:59:59','MANAETH','4h','0.000465210000000','0.000467320000000','0.085196160346163','0.085582574865048','183.1348430733701','183.134843073370092','test'),('2018-11-26 03:59:59','2018-11-26 07:59:59','MANAETH','4h','0.000476900000000','0.000472320000000','0.085292763975884','0.084473638668672','178.84832035203135','178.848320352031351','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','MANAETH','4h','0.000595150000000','0.000600310000000','0.085292763975884','0.086032259333551','143.3130538114492','143.313053811449208','test'),('2019-01-16 11:59:59','2019-01-18 15:59:59','MANAETH','4h','0.000316630000000','0.000323210000000','0.085292763975884','0.087065263066183','269.37676144359034','269.376761443590340','test'),('2019-01-28 15:59:59','2019-01-28 23:59:59','MANAETH','4h','0.000336440000000','0.000333830000000','0.085715981261072','0.085051022543050','254.77345518093045','254.773455180930455','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','MANAETH','4h','0.000336660000000','0.000324080000000','0.085715981261072','0.082513025625522','254.60696625994174','254.606966259941743','test'),('2019-02-05 23:59:59','2019-02-06 07:59:59','MANAETH','4h','0.000322800000000','0.000319490000000','0.085715981261072','0.084837047252478','265.5389754060471','265.538975406047086','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','MANAETH','4h','0.000302290000000','0.000298420000000','0.085715981261072','0.084618621614771','283.5554641604817','283.555464160481677','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','MANAETH','4h','0.000274280000000','0.000340020000000','0.085715981261072','0.106260565656955','312.51269236208253','312.512692362082532','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','MANAETH','4h','0.000306140000000','0.000341100000000','0.089391075357926','0.099599189274804','291.99410517386247','291.994105173862465','test'),('2019-04-14 03:59:59','2019-04-14 07:59:59','MANAETH','4h','0.000347000000000','0.000332800000000','0.091943103837146','0.088180590654185','264.96571710993015','264.965717109930154','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','MANAETH','4h','0.000339800000000','0.000338740000000','0.091943103837146','0.091656288975264','270.5800583788876','270.580058378887600','test'),('2019-04-19 19:59:59','2019-04-20 07:59:59','MANAETH','4h','0.000338440000000','0.000338810000000','0.091943103837146','0.092043620763100','271.6673674422231','271.667367442223110','test'),('2019-05-01 19:59:59','2019-05-02 03:59:59','MANAETH','4h','0.000320350000000','0.000317850000000','0.091943103837146','0.091225583126695','287.00828418025907','287.008284180259068','test'),('2019-05-03 03:59:59','2019-05-03 07:59:59','MANAETH','4h','0.000320250000000','0.000316140000000','0.091943103837146','0.090763131450665','287.0979042533833','287.097904253383319','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:49:56
