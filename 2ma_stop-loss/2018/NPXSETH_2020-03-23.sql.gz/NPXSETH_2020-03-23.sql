-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-07 07:59:59','2018-12-07 11:59:59','NPXSETH','4h','0.000006020000000','0.000006000000000','0.072144500000000','0.071904817275748','11984.136212624584','11984.136212624584005','test'),('2019-01-08 15:59:59','2019-01-10 07:59:59','NPXSETH','4h','0.000003340000000','0.000003300000000','0.072144500000000','0.071280494011976','21600.149700598802','21600.149700598802156','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','NPXSETH','4h','0.000005180000000','0.000005100000000','0.072144500000000','0.071030299227799','13927.509652509652','13927.509652509652369','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','NPXSETH','4h','0.000005180000000','0.000005200000000','0.072144500000000','0.072423050193050','13927.509652509652','13927.509652509652369','test'),('2019-02-12 07:59:59','2019-02-13 07:59:59','NPXSETH','4h','0.000005580000000','0.000005490000000','0.072144500000000','0.070980879032258','12929.121863799284','12929.121863799284256','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','NPXSETH','4h','0.000005720000000','0.000005590000000','0.072144500000000','0.070504852272727','12612.674825174825','12612.674825174824946','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','NPXSETH','4h','0.000004830000000','0.000004850000000','0.072144500000000','0.072443234989648','14936.749482401656','14936.749482401655769','test'),('2019-03-03 23:59:59','2019-03-04 11:59:59','NPXSETH','4h','0.000004970000000','0.000004960000000','0.072144500000000','0.071999340040241','14515.99597585513','14515.995975855130382','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','NPXSETH','4h','0.000004810000000','0.000004750000000','0.072144500000000','0.071244568607069','14998.85654885655','14998.856548856549125','test'),('2019-03-25 07:59:59','2019-03-25 11:59:59','NPXSETH','4h','0.000004770000000','0.000004710000000','0.072144500000000','0.071237022012579','15124.633123689728','15124.633123689727654','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','NPXSETH','4h','0.000004530000000','0.000004420000000','0.072144500000000','0.070392646799117','15925.938189845476','15925.938189845475790','test'),('2019-04-05 07:59:59','2019-04-05 15:59:59','NPXSETH','4h','0.000004750000000','0.000004680000000','0.072144500000000','0.071081317894737','15188.315789473683','15188.315789473683253','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','NPXSETH','4h','0.000004290000000','0.000004240000000','0.072144500000000','0.071303655011655','16816.89976689977','16816.899766899769020','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','NPXSETH','4h','0.000004270000000','0.000004250000000','0.072144500000000','0.071806586651054','16895.667447306794','16895.667447306794202','test'),('2019-04-16 15:59:59','2019-04-16 19:59:59','NPXSETH','4h','0.000004250000000','0.000004250000000','0.072144500000000','0.072144500000000','16975.176470588234','16975.176470588234224','test'),('2019-04-17 11:59:59','2019-04-17 15:59:59','NPXSETH','4h','0.000004340000000','0.000004290000000','0.072144500000000','0.071313342165899','16623.15668202765','16623.156682027649367','test'),('2019-04-26 07:59:59','2019-04-26 15:59:59','NPXSETH','4h','0.000004080000000','0.000004100000000','0.072144500000000','0.072498149509804','17682.47549019608','17682.475490196080500','test'),('2019-04-28 03:59:59','2019-04-28 07:59:59','NPXSETH','4h','0.000004130000000','0.000004070000000','0.072144500000000','0.071096395883777','17468.401937046005','17468.401937046004605','test'),('2019-05-02 11:59:59','2019-05-02 15:59:59','NPXSETH','4h','0.000004070000000','0.000004030000000','0.072144500000000','0.071435463144963','17725.921375921374','17725.921375921374420','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','NPXSETH','4h','0.000003360000000','0.000003250000000','0.072144500000000','0.069782626488095','21471.57738095238','21471.577380952381645','test'),('2019-05-23 15:59:59','2019-05-24 19:59:59','NPXSETH','4h','0.000003130000000','0.000003210000000','0.072144500000000','0.073988448881789','23049.361022364217','23049.361022364217206','test'),('2019-05-27 07:59:59','2019-05-27 15:59:59','NPXSETH','4h','0.000003370000000','0.000003270000000','0.072144500000000','0.070003713649852','21407.86350148368','21407.863501483680011','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','NPXSETH','4h','0.000003640000000','0.000003610000000','0.072144500000000','0.071549902472527','19819.917582417584','19819.917582417583617','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','NPXSETH','4h','0.000003630000000','0.000003580000000','0.072144500000000','0.071150774104683','19874.51790633609','19874.517906336088345','test'),('2019-06-07 23:59:59','2019-06-08 03:59:59','NPXSETH','4h','0.000003590000000','0.000003550000000','0.072144500000000','0.071340661559889','20095.961002785516','20095.961002785516030','test'),('2019-07-01 03:59:59','2019-07-01 11:59:59','NPXSETH','4h','0.000002980000000','0.000003010000000','0.072144500000000','0.072870786912752','24209.563758389264','24209.563758389263967','test'),('2019-07-14 19:59:59','2019-07-14 23:59:59','NPXSETH','4h','0.000002690000000','0.000002710000000','0.072144500000000','0.072680890334572','26819.516728624534','26819.516728624534153','test'),('2019-07-19 07:59:59','2019-07-19 15:59:59','NPXSETH','4h','0.000002760000000','0.000002740000000','0.072144500000000','0.071621713768116','26139.3115942029','26139.311594202899869','test'),('2019-07-31 03:59:59','2019-07-31 15:59:59','NPXSETH','4h','0.000002750000000','0.000002750000000','0.072144500000000','0.072144500000000','26234.363636363636','26234.363636363636033','test'),('2019-08-01 11:59:59','2019-08-01 15:59:59','NPXSETH','4h','0.000002740000000','0.000002730000000','0.072144500000000','0.071881198905109','26330.109489051094','26330.109489051093988','test'),('2019-08-22 07:59:59','2019-08-22 15:59:59','NPXSETH','4h','0.000002320000000','0.000002230000000','0.072144500000000','0.069345790948276','31096.76724137931','31096.767241379311599','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NPXSETH','4h','0.000002290000000','0.000002260000000','0.072144500000000','0.071199375545852','31504.14847161572','31504.148471615721064','test'),('2019-08-24 15:59:59','2019-08-26 03:59:59','NPXSETH','4h','0.000002280000000','0.000002240000000','0.072144500000000','0.070878807017544','31642.324561403508','31642.324561403507687','test'),('2019-08-26 15:59:59','2019-08-26 23:59:59','NPXSETH','4h','0.000002280000000','0.000002280000000','0.072144500000000','0.072144500000000','31642.324561403508','31642.324561403507687','test'),('2019-08-28 23:59:59','2019-08-29 03:59:59','NPXSETH','4h','0.000002270000000','0.000002270000000','0.072144500000000','0.072144500000000','31781.71806167401','31781.718061674011551','test'),('2019-08-29 15:59:59','2019-08-29 19:59:59','NPXSETH','4h','0.000002280000000','0.000002260000000','0.072144500000000','0.071511653508772','31642.324561403508','31642.324561403507687','test'),('2019-09-01 11:59:59','2019-09-01 15:59:59','NPXSETH','4h','0.000002280000000','0.000002270000000','0.072144500000000','0.071828076754386','31642.324561403508','31642.324561403507687','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','NPXSETH','4h','0.000001690000000','0.000001690000000','0.072144500000000','0.072144500000000','42689.05325443787','42689.053254437872965','test'),('2019-11-01 19:59:59','2019-11-04 15:59:59','NPXSETH','4h','0.000001020000000','0.000001000000000','0.072144500000000','0.070729901960784','70729.90196078432','70729.901960784322000','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','NPXSETH','4h','0.000001020000000','0.000001010000000','0.072144500000000','0.071437200980392','70729.90196078432','70729.901960784322000','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','NPXSETH','4h','0.000001040000000','0.000001020000000','0.072144500000000','0.070757105769231','69369.71153846155','69369.711538461546297','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','NPXSETH','4h','0.000000980000000','0.000000950000000','0.072144500000000','0.069935994897959','73616.83673469388','73616.836734693875769','test'),('2019-11-22 07:59:59','2019-11-22 11:59:59','NPXSETH','4h','0.000000960000000','0.000000950000000','0.072144500000000','0.071392994791667','75150.52083333334','75150.520833333343035','test'),('2019-11-22 23:59:59','2019-11-23 03:59:59','NPXSETH','4h','0.000000970000000','0.000000960000000','0.072144500000000','0.071400742268041','74375.77319587629','74375.773195876288810','test'),('2019-11-24 07:59:59','2019-11-24 11:59:59','NPXSETH','4h','0.000000960000000','0.000000950000000','0.072144500000000','0.071392994791667','75150.52083333334','75150.520833333343035','test'),('2019-11-24 15:59:59','2019-11-24 19:59:59','NPXSETH','4h','0.000000970000000','0.000000950000000','0.072144500000000','0.070656984536082','74375.77319587629','74375.773195876288810','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','NPXSETH','4h','0.000000980000000','0.000000960000000','0.072144500000000','0.070672163265306','73616.83673469388','73616.836734693875769','test'),('2019-11-26 07:59:59','2019-11-26 11:59:59','NPXSETH','4h','0.000000960000000','0.000000950000000','0.072144500000000','0.071392994791667','75150.52083333334','75150.520833333343035','test'),('2019-11-26 19:59:59','2019-11-26 23:59:59','NPXSETH','4h','0.000000960000000','0.000000960000000','0.072144500000000','0.072144500000000','75150.52083333334','75150.520833333343035','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:16:12
