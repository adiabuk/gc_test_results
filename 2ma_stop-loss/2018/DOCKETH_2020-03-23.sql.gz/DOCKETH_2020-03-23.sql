-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-29 15:59:59','2019-01-29 19:59:59','DOCKETH','4h','0.000084480000000','0.000082580000000','0.072144500000000','0.070521931936553','853.9831912878788','853.983191287878753','test'),('2019-02-22 19:59:59','2019-02-23 03:59:59','DOCKETH','4h','0.000070470000000','0.000067950000000','0.072144500000000','0.069564620051086','1023.761884489854','1023.761884489853969','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','DOCKETH','4h','0.000066340000000','0.000064910000000','0.072144500000000','0.070589380388906','1087.496231534519','1087.496231534518984','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','DOCKETH','4h','0.000065620000000','0.000065010000000','0.072144500000000','0.071473848597988','1099.4285278878392','1099.428527887839209','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','DOCKETH','4h','0.000065550000000','0.000065730000000','0.072144500000000','0.072342608466819','1100.602593440122','1100.602593440122064','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DOCKETH','4h','0.000074950000000','0.000073840000000','0.072144500000000','0.071076049099400','962.5683789192794','962.568378919279439','test'),('2019-03-24 19:59:59','2019-03-24 23:59:59','DOCKETH','4h','0.000081420000000','0.000080530000000','0.072144500000000','0.071355890260378','886.078359125522','886.078359125521956','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','DOCKETH','4h','0.000081450000000','0.000080300000000','0.072144500000000','0.071125885205648','885.7519950890116','885.751995089011643','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','DOCKETH','4h','0.000082470000000','0.000083570000000','0.072144500000000','0.073106776585425','874.7968958409118','874.796895840911816','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','DOCKETH','4h','0.000093370000000','0.000090960000000','0.072144500000000','0.070282357502410','772.6732355146193','772.673235514619250','test'),('2019-04-07 03:59:59','2019-04-08 03:59:59','DOCKETH','4h','0.000095660000000','0.000095320000000','0.072144500000000','0.071888080075267','754.1762492159733','754.176249215973257','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','DOCKETH','4h','0.000092810000000','0.000089780000000','0.072144500000000','0.069789173688180','777.3354164421937','777.335416442193718','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','DOCKETH','4h','0.000089900000000','0.000086480000000','0.072144500000000','0.069399959510567','802.4972191323693','802.497219132369310','test'),('2019-04-25 11:59:59','2019-04-25 19:59:59','DOCKETH','4h','0.000088010000000','0.000088630000000','0.072144500000000','0.072652733041700','819.7307124190432','819.730712419043243','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','DOCKETH','4h','0.000088620000000','0.000083930000000','0.072144500000000','0.068326426145340','814.0882419318439','814.088241931843868','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','DOCKETH','4h','0.000062610000000','0.000058860000000','0.072144500000000','0.067823435074269','1152.2839801948571','1152.283980194857122','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','DOCKETH','4h','0.000061860000000','0.000059970000000','0.072144500000000','0.069940279097963','1166.2544455221469','1166.254445522146852','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','DOCKETH','4h','0.000054130000000','0.000054060000000','0.072144500000000','0.072051203953445','1332.800665065583','1332.800665065582962','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','DOCKETH','4h','0.000054610000000','0.000054700000000','0.072144500000000','0.072263397729354','1321.0858817066471','1321.085881706647115','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','DOCKETH','4h','0.000055840000000','0.000055260000000','0.072144500000000','0.071395148101719','1291.9860315186247','1291.986031518624713','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','DOCKETH','4h','0.000055820000000','0.000052210000000','0.072144500000000','0.067478759315657','1292.4489430311717','1292.448943031171666','test'),('2019-06-14 23:59:59','2019-06-15 03:59:59','DOCKETH','4h','0.000056290000000','0.000054200000000','0.072144500000000','0.069465835850062','1281.6574880085273','1281.657488008527253','test'),('2019-06-15 11:59:59','2019-06-15 15:59:59','DOCKETH','4h','0.000055750000000','0.000054570000000','0.072144500000000','0.070617495336323','1294.0717488789237','1294.071748878923700','test'),('2019-06-19 23:59:59','2019-06-20 15:59:59','DOCKETH','4h','0.000057320000000','0.000055490000000','0.072144500000000','0.069841212578507','1258.6270062805304','1258.627006280530395','test'),('2019-07-02 15:59:59','2019-07-03 03:59:59','DOCKETH','4h','0.000049120000000','0.000048620000000','0.072144500000000','0.071410130089577','1468.7398208469056','1468.739820846905559','test'),('2019-07-10 23:59:59','2019-07-11 11:59:59','DOCKETH','4h','0.000042680000000','0.000042160000000','0.072144500000000','0.071265513589503','1690.3584817244612','1690.358481724461171','test'),('2019-07-12 15:59:59','2019-07-12 19:59:59','DOCKETH','4h','0.000043000000000','0.000042330000000','0.072144500000000','0.071020388023256','1677.7790697674418','1677.779069767441797','test'),('2019-07-13 03:59:59','2019-07-13 07:59:59','DOCKETH','4h','0.000042240000000','0.000042330000000','0.072144500000000','0.072298216974432','1707.9663825757575','1707.966382575757507','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','DOCKETH','4h','0.000043100000000','0.000042440000000','0.072144500000000','0.071039735034803','1673.8863109048725','1673.886310904872516','test'),('2019-07-17 19:59:59','2019-07-17 23:59:59','DOCKETH','4h','0.000042760000000','0.000042250000000','0.072144500000000','0.071284030051450','1687.1959775491114','1687.195977549111376','test'),('2019-07-18 19:59:59','2019-07-18 23:59:59','DOCKETH','4h','0.000042510000000','0.000042410000000','0.072144500000000','0.071974788167490','1697.1183250999766','1697.118325099976573','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','DOCKETH','4h','0.000042270000000','0.000041770000000','0.072144500000000','0.071291122900402','1706.754199195647','1706.754199195647061','test'),('2019-07-21 03:59:59','2019-07-21 07:59:59','DOCKETH','4h','0.000042310000000','0.000042270000000','0.072144500000000','0.072076294374852','1705.1406286929805','1705.140628692980499','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','DOCKETH','4h','0.000043170000000','0.000042610000000','0.072144500000000','0.071208643618253','1671.1721102617557','1671.172110261755734','test'),('2019-07-26 03:59:59','2019-07-26 07:59:59','DOCKETH','4h','0.000042680000000','0.000042570000000','0.072144500000000','0.071958560567010','1690.3584817244612','1690.358481724461171','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','DOCKETH','4h','0.000043660000000','0.000042460000000','0.072144500000000','0.070161600320660','1652.4163994502978','1652.416399450297831','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','DOCKETH','4h','0.000029390000000','0.000028610000000','0.072144500000000','0.070229810990133','2454.729499829874','2454.729499829873930','test'),('2019-08-22 07:59:59','2019-08-23 03:59:59','DOCKETH','4h','0.000029510000000','0.000029770000000','0.072144500000000','0.072780134361233','2444.747543205693','2444.747543205693091','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','DOCKETH','4h','0.000035940000000','0.000034930000000','0.072144500000000','0.070117066917084','2007.359488035615','2007.359488035614959','test'),('2019-09-09 23:59:59','2019-09-10 03:59:59','DOCKETH','4h','0.000034600000000','0.000034090000000','0.072144500000000','0.071081098410405','2085.101156069364','2085.101156069364151','test'),('2019-09-10 11:59:59','2019-09-11 11:59:59','DOCKETH','4h','0.000036720000000','0.000043000000000','0.072144500000000','0.084482938453159','1964.7194989106754','1964.719498910675384','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','DOCKETH','4h','0.000049640000000','0.000047990000000','0.072144500000000','0.069746465652699','1453.3541498791299','1453.354149879129864','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','DOCKETH','4h','0.000062390000000','0.000061160000000','0.072144500000000','0.070722192979644','1156.347171020997','1156.347171020996939','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','DOCKETH','4h','0.000063220000000','0.000061280000000','0.072144500000000','0.069930638405568','1141.1657703258463','1141.165770325846324','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','DOCKETH','4h','0.000056820000000','0.000055390000000','0.072144500000000','0.070328825325590','1269.7025695177754','1269.702569517775373','test'),('2019-11-15 23:59:59','2019-11-16 03:59:59','DOCKETH','4h','0.000056230000000','0.000055810000000','0.072144500000000','0.071605629468255','1283.0250755824293','1283.025075582429281','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','DOCKETH','4h','0.000056010000000','0.000055010000000','0.072144500000000','0.070856435368684','1288.0646313158366','1288.064631315836550','test'),('2019-12-02 15:59:59','2019-12-10 03:59:59','DOCKETH','4h','0.000056870000000','0.000059790000000','0.072144500000000','0.075848771848075','1268.5862493406014','1268.586249340601398','test'),('2019-12-19 19:59:59','2019-12-19 23:59:59','DOCKETH','4h','0.000059190000000','0.000058440000000','0.072144500000000','0.071230352762291','1218.8629836120965','1218.862983612096514','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','DOCKETH','4h','0.000058480000000','0.000058190000000','0.072144500000000','0.071786738286594','1233.6610807113543','1233.661080711354316','test'),('2019-12-31 19:59:59','2020-01-02 07:59:59','DOCKETH','4h','0.000057590000000','0.000056980000000','0.072144500000000','0.071380337037680','1252.7261677374543','1252.726167737454261','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:33:09
