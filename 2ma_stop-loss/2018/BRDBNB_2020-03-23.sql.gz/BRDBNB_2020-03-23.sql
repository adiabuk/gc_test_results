-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-20 15:59:59','2018-06-20 19:59:59','BRDBNB','4h','0.030360000000000','0.030190000000000','0.711908500000000','0.707922187582345','23.448896574440052','23.448896574440052','test'),('2018-06-25 03:59:59','2018-06-25 07:59:59','BRDBNB','4h','0.029040000000000','0.027900000000000','0.711908500000000','0.683961678719008','24.514755509641876','24.514755509641876','test'),('2018-06-26 23:59:59','2018-06-27 03:59:59','BRDBNB','4h','0.029110000000000','0.027610000000000','0.711908500000000','0.675224791652353','24.455805565097904','24.455805565097904','test'),('2018-06-27 11:59:59','2018-06-27 23:59:59','BRDBNB','4h','0.029010000000000','0.029440000000000','0.711908500000000','0.722460745949673','24.540106859703553','24.540106859703553','test'),('2018-06-28 19:59:59','2018-06-28 23:59:59','BRDBNB','4h','0.029260000000000','0.028660000000000','0.711908500000000','0.697310239576213','24.330434039644565','24.330434039644565','test'),('2018-06-29 11:59:59','2018-07-04 23:59:59','BRDBNB','4h','0.029130000000000','0.035240000000000','0.711908500000000','0.861230880192242','24.439014761414352','24.439014761414352','test'),('2018-07-07 23:59:59','2018-07-08 03:59:59','BRDBNB','4h','0.033960000000000','0.033040000000000','0.731073380917958','0.711268094980251','21.527484714898662','21.527484714898662','test'),('2018-07-12 03:59:59','2018-07-12 07:59:59','BRDBNB','4h','0.033500000000000','0.031860000000000','0.731073380917958','0.695283519881974','21.823085997550987','21.823085997550987','test'),('2018-07-12 11:59:59','2018-07-12 15:59:59','BRDBNB','4h','0.032660000000000','0.031990000000000','0.731073380917958','0.716075855957302','22.38436561291972','22.384365612919719','test'),('2018-07-14 15:59:59','2018-07-14 19:59:59','BRDBNB','4h','0.033230000000000','0.032530000000000','0.731073380917958','0.715673099044874','22.000402675833826','22.000402675833826','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','BRDBNB','4h','0.034980000000000','0.033370000000000','0.731073380917958','0.697424777622420','20.899753599712923','20.899753599712923','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','BRDBNB','4h','0.033140000000000','0.032530000000000','0.731073380917958','0.717616689235401','22.060150299274532','22.060150299274532','test'),('2018-07-21 07:59:59','2018-07-21 11:59:59','BRDBNB','4h','0.032770000000000','0.032370000000000','0.731073380917958','0.722149689969921','22.309227370093318','22.309227370093318','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','BRDBNB','4h','0.033020000000000','0.032650000000000','0.731073380917958','0.722881462355280','22.140320439671655','22.140320439671655','test'),('2018-07-23 11:59:59','2018-07-24 03:59:59','BRDBNB','4h','0.033060000000000','0.032970000000000','0.731073380917958','0.729083163002573','22.113532393162675','22.113532393162675','test'),('2018-08-07 07:59:59','2018-08-07 15:59:59','BRDBNB','4h','0.028320000000000','0.027340000000000','0.731073380917958','0.705774937651729','25.814738026764054','25.814738026764054','test'),('2018-08-11 15:59:59','2018-08-12 03:59:59','BRDBNB','4h','0.028380000000000','0.028170000000000','0.731073380917958','0.725663747021102','25.76016141359965','25.760161413599651','test'),('2018-08-12 19:59:59','2018-08-12 23:59:59','BRDBNB','4h','0.029910000000000','0.029340000000000','0.731073380917958','0.717141190108087','24.44244001731722','24.442440017317221','test'),('2018-08-13 19:59:59','2018-08-14 15:59:59','BRDBNB','4h','0.030210000000000','0.028750000000000','0.731073380917958','0.695741797464128','24.199714694404435','24.199714694404435','test'),('2018-09-08 07:59:59','2018-09-08 11:59:59','BRDBNB','4h','0.032030000000000','0.032300000000000','0.731073380917958','0.737236035081175','22.824645048952792','22.824645048952792','test'),('2018-09-09 03:59:59','2018-09-09 07:59:59','BRDBNB','4h','0.035290000000000','0.033800000000000','0.731073380917958','0.700206298527259','20.716162678321282','20.716162678321282','test'),('2018-09-12 11:59:59','2018-09-12 15:59:59','BRDBNB','4h','0.035310000000000','0.033640000000000','0.731073380917958','0.696496984822433','20.704428799715604','20.704428799715604','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','BRDBNB','4h','0.034000000000000','0.032620000000000','0.731073380917958','0.701400402515994','21.50215826229288','21.502158262292880','test'),('2018-09-15 15:59:59','2018-09-15 19:59:59','BRDBNB','4h','0.032720000000000','0.032480000000000','0.731073380917958','0.725710984480907','22.343318487712654','22.343318487712654','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','BRDBNB','4h','0.034390000000000','0.033140000000000','0.731073380917958','0.704500489782528','21.25831290834423','21.258312908344230','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','BRDBNB','4h','0.034160000000000','0.033990000000000','0.731073380917958','0.727435135169830','21.401445577223594','21.401445577223594','test'),('2018-09-18 11:59:59','2018-09-18 23:59:59','BRDBNB','4h','0.033960000000000','0.033390000000000','0.731073380917958','0.718802714630466','21.527484714898648','21.527484714898648','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BRDBNB','4h','0.034530000000000','0.034990000000000','0.731073380917958','0.740812557147968','21.172122239153143','21.172122239153143','test'),('2018-09-26 19:59:59','2018-09-26 23:59:59','BRDBNB','4h','0.034900000000000','0.033710000000000','0.731073380917958','0.706145663918177','20.9476613443541','20.947661344354099','test'),('2018-09-27 03:59:59','2018-09-27 07:59:59','BRDBNB','4h','0.034900000000000','0.034100000000000','0.731073380917958','0.714315251842475','20.9476613443541','20.947661344354099','test'),('2018-09-27 11:59:59','2018-09-27 15:59:59','BRDBNB','4h','0.035060000000000','0.034650000000000','0.731073380917958','0.722524034478244','20.852064487106617','20.852064487106617','test'),('2018-09-30 03:59:59','2018-09-30 07:59:59','BRDBNB','4h','0.035050000000000','0.034410000000000','0.731073380917958','0.717724252136575','20.858013720911785','20.858013720911785','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','BRDBNB','4h','0.034990000000000','0.035170000000000','0.731073380917958','0.734834261414249','20.893780534951645','20.893780534951645','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','BRDBNB','4h','0.039130000000000','0.035290000000000','0.731073380917958','0.659329915987599','18.683193992281065','18.683193992281065','test'),('2018-10-06 11:59:59','2018-10-07 15:59:59','BRDBNB','4h','0.035060000000000','0.034680000000000','0.731073380917958','0.723149596412858','20.852064487106617','20.852064487106617','test'),('2018-10-08 11:59:59','2018-10-15 07:59:59','BRDBNB','4h','0.035060000000000','0.036520000000000','0.731073380917958','0.761517395069134','20.852064487106617','20.852064487106617','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','BRDBNB','4h','0.039480000000000','0.038000000000000','0.731073380917958','0.703667387914955','18.517562839867225','18.517562839867225','test'),('2018-10-19 11:59:59','2018-10-19 23:59:59','BRDBNB','4h','0.038280000000000','0.037410000000000','0.731073380917958','0.714458076806186','19.098050703185947','19.098050703185947','test'),('2018-10-29 15:59:59','2018-10-29 19:59:59','BRDBNB','4h','0.039400000000000','0.039140000000000','0.731073380917958','0.726249038810378','18.55516195223244','18.555161952232439','test'),('2018-11-10 15:59:59','2018-11-11 03:59:59','BRDBNB','4h','0.036690000000000','0.036240000000000','0.731073380917958','0.722106822689201','19.925684952792533','19.925684952792533','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','BRDBNB','4h','0.038300000000000','0.037570000000000','0.731073380917958','0.717139084101506','19.088077830756085','19.088077830756085','test'),('2018-11-13 15:59:59','2018-11-13 23:59:59','BRDBNB','4h','0.037270000000000','0.036620000000000','0.731073380917958','0.718323241460038','19.615599166030535','19.615599166030535','test'),('2018-11-16 03:59:59','2018-11-16 07:59:59','BRDBNB','4h','0.036850000000000','0.035910000000000','0.731073380917958','0.712424561974596','19.839169088682713','19.839169088682713','test'),('2018-11-16 11:59:59','2018-11-16 19:59:59','BRDBNB','4h','0.037810000000000','0.037210000000000','0.731073380917958','0.719472110657424','19.33545043422264','19.335450434222640','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','BRDBNB','4h','0.045660000000000','0.044860000000000','0.731073380917958','0.718264386070512','16.011243559307008','16.011243559307008','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','BRDBNB','4h','0.048800000000000','0.044920000000000','0.731073380917958','0.672947054730219','14.981011904056516','14.981011904056516','test'),('2018-12-01 07:59:59','2018-12-02 15:59:59','BRDBNB','4h','0.044900000000000','0.045210000000000','0.731073380917958','0.736120880875298','16.282257926903295','16.282257926903295','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','BRDBNB','4h','0.043220000000000','0.041900000000000','0.731073380917958','0.708745364656697','16.91516383428871','16.915163834288709','test'),('2018-12-08 23:59:59','2018-12-09 03:59:59','BRDBNB','4h','0.042280000000000','0.041770000000000','0.731073380917958','0.722254851488721','17.291234174975358','17.291234174975358','test'),('2018-12-27 23:59:59','2018-12-28 03:59:59','BRDBNB','4h','0.037170000000000','0.034830000000000','0.731073380917958','0.685049390835956','19.66837182991547','19.668371829915468','test'),('2018-12-30 15:59:59','2018-12-30 19:59:59','BRDBNB','4h','0.037090000000000','0.035120000000000','0.731073380917958','0.692243115067099','19.71079484815201','19.710794848152009','test'),('2019-01-02 15:59:59','2019-01-02 19:59:59','BRDBNB','4h','0.036690000000000','0.035810000000000','0.487382253945305','0.475692518773000','13.283789968528355','13.283789968528355','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','BRDBNB','4h','0.033360000000000','0.034100000000000','0.536921753260779','0.548831888075317','16.09477677640225','16.094776776402249','test'),('2019-01-19 03:59:59','2019-01-19 19:59:59','BRDBNB','4h','0.033620000000000','0.032400000000000','0.539899286964414','0.520307462749762','16.058872307091427','16.058872307091427','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','BRDBNB','4h','0.034040000000000','0.032050000000000','0.539899286964414','0.508336432056682','15.860731109412868','15.860731109412868','test'),('2019-01-24 15:59:59','2019-01-24 19:59:59','BRDBNB','4h','0.033240000000000','0.032520000000000','0.539899286964414','0.528204717571683','16.242457489904154','16.242457489904154','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','BRDBNB','4h','0.032470000000000','0.030140000000000','0.539899286964414','0.501156898956189','16.627634338294243','16.627634338294243','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','BRDBNB','4h','0.031440000000000','0.031130000000000','0.539899286964414','0.534575852519154','17.17236917825744','17.172369178257441','test'),('2019-01-29 07:59:59','2019-01-31 15:59:59','BRDBNB','4h','0.031700000000000','0.032470000000000','0.539899286964414','0.553013559865442','17.03152324808877','17.031523248088771','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','BRDBNB','4h','0.022260000000000','0.021830000000000','0.539899286964414','0.529469965607959','24.254235712687066','24.254235712687066','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','BRDBNB','4h','0.022420000000000','0.015660000000000','0.539899286964414','0.377110741920728','24.08114571652159','24.081145716521590','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','BRDBNB','4h','0.017310000000000','0.017020000000000','0.539899286964414','0.530854180481475','31.19002235496326','31.190022354963261','test'),('2019-03-15 15:59:59','2019-03-15 19:59:59','BRDBNB','4h','0.017790000000000','0.017310000000000','0.539899286964414','0.525332021211580','30.348470318404384','30.348470318404384','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','BRDBNB','4h','0.016840000000000','0.016590000000000','0.539899286964414','0.531884155032044','32.06052772947827','32.060527729478267','test'),('2019-03-23 15:59:59','2019-03-24 11:59:59','BRDBNB','4h','0.017010000000000','0.014870000000000','0.539899286964414','0.471975449568538','31.740110932652204','31.740110932652204','test'),('2019-03-27 03:59:59','2019-03-27 11:59:59','BRDBNB','4h','0.016800000000000','0.016480000000000','0.539899286964414','0.529615491022235','32.13686231931036','32.136862319310360','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','BRDBNB','4h','0.017100000000000','0.016830000000000','0.539899286964414','0.531374561380765','31.573057717217193','31.573057717217193','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','BRDBNB','4h','0.016850000000000','0.016970000000000','0.539899286964414','0.543744267049620','32.041500710054244','32.041500710054244','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BRDBNB','4h','0.017280000000000','0.016310000000000','0.539899286964414','0.509592440416064','31.244171699329517','31.244171699329517','test'),('2019-04-05 03:59:59','2019-04-11 11:59:59','BRDBNB','4h','0.016780000000000','0.016860000000000','0.539899286964414','0.542473300251491','32.17516608846329','32.175166088463293','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDBNB','4h','0.018740000000000','0.017420000000000','0.539899286964414','0.501870094926366','28.809993968218464','28.809993968218464','test'),('2019-04-29 15:59:59','2019-05-11 15:59:59','BRDBNB','4h','0.014190000000000','0.020750000000000','0.539899286964414','0.789493319556842','38.04787082201649','38.047870822016492','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BRDBNB','4h','0.019740000000000','0.019200000000000','0.539899286964414','0.525130005558093','27.350521122817327','27.350521122817327','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:22:20
