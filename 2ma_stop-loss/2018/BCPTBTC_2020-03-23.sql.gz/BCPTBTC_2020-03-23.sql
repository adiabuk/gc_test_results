-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 19:59:59','2018-07-01 23:59:59','BCPTBTC','4h','0.000027240000000','0.000026670000000','0.001467500000000','0.001436792400881','53.872980910425845','53.872980910425845','test'),('2018-07-07 11:59:59','2018-07-07 15:59:59','BCPTBTC','4h','0.000027030000000','0.000026470000000','0.001467500000000','0.001437096744358','54.29152793192749','54.291527931927490','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','BCPTBTC','4h','0.000027110000000','0.000028070000000','0.001467500000000','0.001519466064183','54.13131685724825','54.131316857248251','test'),('2018-07-11 15:59:59','2018-07-11 19:59:59','BCPTBTC','4h','0.000027840000000','0.000026500000000','0.001467500000000','0.001396866020115','52.71192528735632','52.711925287356323','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','BCPTBTC','4h','0.000026830000000','0.000026120000000','0.001467500000000','0.001428665672754','54.69623555721208','54.696235557212077','test'),('2018-07-13 15:59:59','2018-07-13 19:59:59','BCPTBTC','4h','0.000026790000000','0.000026300000000','0.001467500000000','0.001440658827921','54.7779022023143','54.777902202314301','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','BCPTBTC','4h','0.000026740000000','0.000026360000000','0.001467500000000','0.001446645474944','54.88032909498878','54.880329094988781','test'),('2018-07-16 15:59:59','2018-07-17 07:59:59','BCPTBTC','4h','0.000027720000000','0.000027230000000','0.001467500000000','0.001441559343434','52.94011544011544','52.940115440115441','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','BCPTBTC','4h','0.000013810000000','0.000013490000000','0.001467500000000','0.001433495655322','106.26357711803041','106.263577118030412','test'),('2018-08-29 23:59:59','2018-08-30 03:59:59','BCPTBTC','4h','0.000013660000000','0.000013400000000','0.001467500000000','0.001439568081991','107.43045387994144','107.430453879941439','test'),('2018-08-31 03:59:59','2018-08-31 07:59:59','BCPTBTC','4h','0.000013760000000','0.000013690000000','0.001467500000000','0.001460034520349','106.64970930232558','106.649709302325576','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','BCPTBTC','4h','0.000012520000000','0.000012320000000','0.001467500000000','0.001444057507987','117.21246006389777','117.212460063897765','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BCPTBTC','4h','0.000012940000000','0.000012580000000','0.001467500000000','0.001426673106646','113.4080370942813','113.408037094281298','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','BCPTBTC','4h','0.000013120000000','0.000012850000000','0.001467500000000','0.001437299923780','111.85213414634147','111.852134146341470','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','BCPTBTC','4h','0.000013100000000','0.000012920000000','0.001467500000000','0.001447335877863','112.02290076335878','112.022900763358777','test'),('2018-10-04 11:59:59','2018-10-06 11:59:59','BCPTBTC','4h','0.000014200000000','0.000013890000000','0.001467500000000','0.001435463028169','103.34507042253522','103.345070422535215','test'),('2018-10-07 03:59:59','2018-10-07 07:59:59','BCPTBTC','4h','0.000014200000000','0.000013900000000','0.001467500000000','0.001436496478873','103.34507042253522','103.345070422535215','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BCPTBTC','4h','0.000016190000000','0.000015660000000','0.001467500000000','0.001419459542928','90.64237183446573','90.642371834465735','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','BCPTBTC','4h','0.000016590000000','0.000015970000000','0.001467500000000','0.001412656720916','88.456901748041','88.456901748041005','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','BCPTBTC','4h','0.000016600000000','0.000016020000000','0.001467500000000','0.001416225903614','88.40361445783132','88.403614457831324','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','BCPTBTC','4h','0.000017210000000','0.000016920000000','0.001467500000000','0.001442771644393','85.27019174898315','85.270191748983152','test'),('2018-10-28 15:59:59','2018-10-29 03:59:59','BCPTBTC','4h','0.000017360000000','0.000017820000000','0.001467500000000','0.001506385368664','84.53341013824885','84.533410138248854','test'),('2018-10-29 19:59:59','2018-10-30 03:59:59','BCPTBTC','4h','0.000018560000000','0.000017820000000','0.001467500000000','0.001408989762931','79.06788793103449','79.067887931034491','test'),('2018-11-04 19:59:59','2018-11-05 11:59:59','BCPTBTC','4h','0.000018140000000','0.000018040000000','0.001467500000000','0.001459410143330','80.89856670341787','80.898566703417870','test'),('2018-11-29 07:59:59','2018-11-29 19:59:59','BCPTBTC','4h','0.000010670000000','0.000010150000000','0.001467500000000','0.001395981724461','137.53514526710404','137.535145267104042','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','BCPTBTC','4h','0.000010300000000','0.000010200000000','0.001467500000000','0.001453252427184','142.47572815533982','142.475728155339823','test'),('2018-12-02 03:59:59','2018-12-02 07:59:59','BCPTBTC','4h','0.000010240000000','0.000010290000000','0.001467500000000','0.001474665527344','143.310546875','143.310546875000000','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','BCPTBTC','4h','0.000010380000000','0.000010880000000','0.001467500000000','0.001538188824663','141.3776493256262','141.377649325626209','test'),('2018-12-16 03:59:59','2018-12-16 11:59:59','BCPTBTC','4h','0.000009230000000','0.000009140000000','0.001467500000000','0.001453190682557','158.99241603466956','158.992416034669560','test'),('2018-12-17 19:59:59','2018-12-18 03:59:59','BCPTBTC','4h','0.000009280000000','0.000009230000000','0.001467500000000','0.001459593211207','158.13577586206898','158.135775862068982','test'),('2018-12-18 15:59:59','2018-12-19 07:59:59','BCPTBTC','4h','0.000009410000000','0.000009270000000','0.001467500000000','0.001445666843783','155.95111583421894','155.951115834218939','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','BCPTBTC','4h','0.000009150000000','0.000008970000000','0.001467500000000','0.001438631147541','160.38251366120218','160.382513661202182','test'),('2018-12-22 19:59:59','2018-12-22 23:59:59','BCPTBTC','4h','0.000009120000000','0.000009160000000','0.001467500000000','0.001473936403509','160.91008771929825','160.910087719298247','test'),('2019-01-01 15:59:59','2019-01-01 19:59:59','BCPTBTC','4h','0.000009180000000','0.000009040000000','0.001467500000000','0.001445119825708','159.85838779956427','159.858387799564269','test'),('2019-01-06 11:59:59','2019-01-06 19:59:59','BCPTBTC','4h','0.000008970000000','0.000008710000000','0.001467500000000','0.001424963768116','163.60089186176143','163.600891861761426','test'),('2019-01-08 23:59:59','2019-01-09 07:59:59','BCPTBTC','4h','0.000008670000000','0.000008660000000','0.001467500000000','0.001465807381776','169.26182237600923','169.261822376009235','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BCPTBTC','4h','0.000008550000000','0.000007930000000','0.001467500000000','0.001361084795322','171.6374269005848','171.637426900584813','test'),('2019-01-17 07:59:59','2019-01-22 11:59:59','BCPTBTC','4h','0.000008450000000','0.000008950000000','0.001467500000000','0.001554334319527','173.66863905325442','173.668639053254424','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','BCPTBTC','4h','0.000008800000000','0.000008540000000','0.001467500000000','0.001424142045455','166.76136363636363','166.761363636363626','test'),('2019-02-08 07:59:59','2019-02-08 15:59:59','BCPTBTC','4h','0.000008690000000','0.000008620000000','0.001467500000000','0.001455678941312','168.87226697353282','168.872266973532817','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','BCPTBTC','4h','0.000008550000000','0.000008510000000','0.001467500000000','0.001460634502924','171.6374269005848','171.637426900584813','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','BCPTBTC','4h','0.000008580000000','0.000008620000000','0.001467500000000','0.001474341491841','171.03729603729607','171.037296037296073','test'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BCPTBTC','4h','0.000008550000000','0.000008490000000','0.001467500000000','0.001457201754386','171.6374269005848','171.637426900584813','test'),('2019-02-13 07:59:59','2019-02-14 03:59:59','BCPTBTC','4h','0.000008570000000','0.000008560000000','0.001467500000000','0.001465787631272','171.23687281213537','171.236872812135374','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','BCPTBTC','4h','0.000008610000000','0.000008520000000','0.001467500000000','0.001452160278746','170.44134727061555','170.441347270615552','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','BCPTBTC','4h','0.000008560000000','0.000008580000000','0.001467500000000','0.001470928738318','171.4369158878505','171.436915887850489','test'),('2019-02-17 15:59:59','2019-02-18 11:59:59','BCPTBTC','4h','0.000008620000000','0.000008680000000','0.001467500000000','0.001477714617169','170.24361948955917','170.243619489559165','test'),('2019-02-20 19:59:59','2019-02-22 03:59:59','BCPTBTC','4h','0.000008720000000','0.000008670000000','0.001467500000000','0.001459085435780','168.29128440366975','168.291284403669749','test'),('2019-02-26 23:59:59','2019-02-27 23:59:59','BCPTBTC','4h','0.000008590000000','0.000008530000000','0.001467500000000','0.001457249708964','170.83818393480792','170.838183934807915','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','BCPTBTC','4h','0.000011480000000','0.000011530000000','0.001467500000000','0.001473891550523','127.83101045296168','127.831010452961678','test'),('2019-03-27 03:59:59','2019-03-28 07:59:59','BCPTBTC','4h','0.000011310000000','0.000011420000000','0.001467500000000','0.001481772767462','129.7524314765694','129.752431476569399','test'),('2019-04-02 19:59:59','2019-04-02 23:59:59','BCPTBTC','4h','0.000012040000000','0.000011810000000','0.001467500000000','0.001439466362126','121.88538205980068','121.885382059800676','test'),('2019-04-07 03:59:59','2019-04-07 23:59:59','BCPTBTC','4h','0.000011850000000','0.000011830000000','0.001467500000000','0.001465023206751','123.83966244725738','123.839662447257382','test'),('2019-04-08 19:59:59','2019-04-08 23:59:59','BCPTBTC','4h','0.000012030000000','0.000011650000000','0.001467500000000','0.001421145054032','121.98669991687449','121.986699916874485','test'),('2019-04-09 23:59:59','2019-04-10 15:59:59','BCPTBTC','4h','0.000011870000000','0.000011830000000','0.001467500000000','0.001462554759899','123.63100252737996','123.631002527379962','test'),('2019-04-19 11:59:59','2019-04-20 11:59:59','BCPTBTC','4h','0.000011830000000','0.000011710000000','0.001467500000000','0.001452614116653','124.04902789518174','124.049027895181737','test'),('2019-04-22 03:59:59','2019-04-22 07:59:59','BCPTBTC','4h','0.000011290000000','0.000011220000000','0.001467500000000','0.001458401240035','129.9822852081488','129.982285208148795','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','BCPTBTC','4h','0.000011530000000','0.000011400000000','0.001467500000000','0.001450954032958','127.27666955767563','127.276669557675632','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:08:30
