-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-06-01 07:59:59','WABIBTC','4h','0.000103280000000','0.000101650000000','0.001467500000000','0.001444339417119','14.208946553059643','14.208946553059643','test'),('2018-06-01 19:59:59','2018-06-01 23:59:59','WABIBTC','4h','0.000100840000000','0.000099080000000','0.001467500000000','0.001441887147957','14.55275684252281','14.552756842522809','test'),('2018-06-02 07:59:59','2018-06-02 11:59:59','WABIBTC','4h','0.000102970000000','0.000107200000000','0.001467500000000','0.001527784791687','14.251723803049433','14.251723803049433','test'),('2018-06-05 15:59:59','2018-06-05 19:59:59','WABIBTC','4h','0.000102770000000','0.000103120000000','0.001470377839191','0.001475385450787','14.30746170274156','14.307461702741559','test'),('2018-06-30 03:59:59','2018-06-30 07:59:59','WABIBTC','4h','0.000060880000000','0.000059880000000','0.001471629742090','0.001447457111635','24.172630454825065','24.172630454825065','test'),('2018-07-01 07:59:59','2018-07-01 11:59:59','WABIBTC','4h','0.000060080000000','0.000060680000000','0.001471629742090','0.001486326443908','24.494503030792277','24.494503030792277','test'),('2018-07-06 19:59:59','2018-07-07 03:59:59','WABIBTC','4h','0.000064390000000','0.000063300000000','0.001471629742090','0.001446717854858','22.854942414815966','22.854942414815966','test'),('2018-07-16 11:59:59','2018-07-16 19:59:59','WABIBTC','4h','0.000060260000000','0.000059400000000','0.001471629742090','0.001450627392634','24.42133657633588','24.421336576335879','test'),('2018-08-24 23:59:59','2018-08-25 03:59:59','WABIBTC','4h','0.000024630000000','0.000024530000000','0.001471629742090','0.001465654793888','59.749482017458384','59.749482017458384','test'),('2018-09-07 11:59:59','2018-09-07 15:59:59','WABIBTC','4h','0.000031750000000','0.000028150000000','0.001471629742090','0.001304767787081','46.350543057952756','46.350543057952756','test'),('2018-09-08 11:59:59','2018-09-08 15:59:59','WABIBTC','4h','0.000029880000000','0.000029500000000','0.001471629742090','0.001452914236669','49.251330056559574','49.251330056559574','test'),('2018-09-13 11:59:59','2018-09-13 15:59:59','WABIBTC','4h','0.000028880000000','0.000027900000000','0.001471629742090','0.001421692167739','50.95670852112188','50.956708521121882','test'),('2018-09-15 07:59:59','2018-09-15 11:59:59','WABIBTC','4h','0.000028170000000','0.000027780000000','0.001471629742090','0.001451255741401','52.241027408235716','52.241027408235716','test'),('2018-09-15 15:59:59','2018-09-15 19:59:59','WABIBTC','4h','0.000032650000000','0.000032160000000','0.001471629742090','0.001449544027737','45.072886434609494','45.072886434609494','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','WABIBTC','4h','0.000032210000000','0.000031260000000','0.001471629742090','0.001428225573975','45.6885980158336','45.688598015833598','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','WABIBTC','4h','0.000032790000000','0.000031640000000','0.001471629742090','0.001420017232075','44.88044349161329','44.880443491613292','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','WABIBTC','4h','0.000032360000000','0.000032190000000','0.001471629742090','0.001463898683494','45.47681526854141','45.476815268541408','test'),('2018-10-05 07:59:59','2018-10-05 23:59:59','WABIBTC','4h','0.000032550000000','0.000032670000000','0.001471629742090','0.001477055105194','45.21135920399386','45.211359203993858','test'),('2018-10-06 23:59:59','2018-10-07 11:59:59','WABIBTC','4h','0.000032390000000','0.000031480000000','0.001471629742090','0.001430284170454','45.43469410589688','45.434694105896881','test'),('2018-10-08 19:59:59','2018-10-08 23:59:59','WABIBTC','4h','0.000032400000000','0.000031990000000','0.001471629742090','0.001453007266959','45.42067105216049','45.420671052160493','test'),('2018-10-10 11:59:59','2018-10-10 19:59:59','WABIBTC','4h','0.000033380000000','0.000032980000000','0.001471629742090','0.001453994874000','44.08717022438586','44.087170224385858','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','WABIBTC','4h','0.000039510000000','0.000038390000000','0.001471629742090','0.001429913080203','37.247019541635034','37.247019541635034','test'),('2018-10-22 23:59:59','2018-10-24 07:59:59','WABIBTC','4h','0.000039600000000','0.000039370000000','0.001471629742090','0.001463082397628','37.16236722449495','37.162367224494950','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','WABIBTC','4h','0.000039430000000','0.000039700000000','0.001471629742090','0.001481706841516','37.32259046639614','37.322590466396143','test'),('2018-11-09 11:59:59','2018-11-09 15:59:59','WABIBTC','4h','0.000044440000000','0.000044320000000','0.001471629742090','0.001467655944407','33.11498069509451','33.114980695094509','test'),('2018-11-11 19:59:59','2018-11-11 23:59:59','WABIBTC','4h','0.000050000000000','0.000048570000000','0.001471629742090','0.001429541131466','29.4325948418','29.432594841800000','test'),('2018-11-25 19:59:59','2018-11-25 23:59:59','WABIBTC','4h','0.000037020000000','0.000036860000000','0.001471629742090','0.001465269375836','39.75228908941113','39.752289089411128','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','WABIBTC','4h','0.000038220000000','0.000037730000000','0.001471629742090','0.001452762694114','38.5041795418629','38.504179541862896','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','WABIBTC','4h','0.000038490000000','0.000038450000000','0.001471629742090','0.001470100378887','38.23408007508444','38.234080075084442','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','WABIBTC','4h','0.000037300000000','0.000035830000000','0.001471629742090','0.001413632537777','39.4538804849866','39.453880484986598','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','WABIBTC','4h','0.000035790000000','0.000035000000000','0.001471629742090','0.001439146157395','41.11846163984353','41.118461639843531','test'),('2019-01-03 19:59:59','2019-01-03 23:59:59','WABIBTC','4h','0.000034040000000','0.000033000000000','0.001471629742090','0.001426668081345','43.23236610135135','43.232366101351353','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','WABIBTC','4h','0.000032580000000','0.000031800000000','0.001471629742090','0.001436397354158','45.16972811817065','45.169728118170653','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','WABIBTC','4h','0.000032170000000','0.000031640000000','0.001471629742090','0.001447384676398','45.74540696580666','45.745406965806659','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WABIBTC','4h','0.000031800000000','0.000031650000000','0.001471629742090','0.001464688092363','46.277664845597485','46.277664845597485','test'),('2019-01-17 03:59:59','2019-01-18 23:59:59','WABIBTC','4h','0.000031730000000','0.000039350000000','0.001471629742090','0.001825043503033','46.37975865395524','46.379758653955243','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','WABIBTC','4h','0.000036240000000','0.000036220000000','0.001471629742090','0.001470817584396','40.60788471550773','40.607884715507730','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','WABIBTC','4h','0.000033880000000','0.000033920000000','0.001471629742090','0.001473367203415','43.436533119539554','43.436533119539554','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','WABIBTC','4h','0.000035550000000','0.000037100000000','0.001471629742090','0.001535793626766','41.396054629817165','41.396054629817165','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','WABIBTC','4h','0.000036550000000','0.000034450000000','0.001471629742090','0.001387076460055','40.263467635841316','40.263467635841316','test'),('2019-02-20 11:59:59','2019-02-21 11:59:59','WABIBTC','4h','0.000035470000000','0.000035440000000','0.001471629742090','0.001470385059478','41.48942041415281','41.489420414152811','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','WABIBTC','4h','0.000035530000000','0.000035510000000','0.001471629742090','0.001470801354957','41.41935665887982','41.419356658879821','test'),('2019-02-24 23:59:59','2019-02-25 07:59:59','WABIBTC','4h','0.000035950000000','0.000034930000000','0.001471629742090','0.001429875574164','40.93545875076495','40.935458750764951','test'),('2019-02-25 19:59:59','2019-03-07 15:59:59','WABIBTC','4h','0.000035670000000','0.000056090000000','0.001471629742090','0.002314093418386','41.25679119960751','41.256791199607513','test'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIBTC','4h','0.000052080000000','0.000056530000000','0.001547493069151','0.001679719339461','29.713768608885363','29.713768608885363','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIBTC','4h','0.000056290000000','0.000055990000000','0.001580549636728','0.001572126028787','28.078693137826434','28.078693137826434','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','WABIBTC','4h','0.000058590000000','0.000057260000000','0.001580549636728','0.001544670971139','26.976440292336576','26.976440292336576','test'),('2019-04-12 19:59:59','2019-04-12 23:59:59','WABIBTC','4h','0.000070580000000','0.000068400000000','0.001580549636728','0.001531731299974','22.393732455766507','22.393732455766507','test'),('2019-04-24 23:59:59','2019-04-25 07:59:59','WABIBTC','4h','0.000068360000000','0.000071120000000','0.001580549636728','0.001644363519077','23.120971865535402','23.120971865535402','test'),('2019-04-28 15:59:59','2019-04-28 19:59:59','WABIBTC','4h','0.000069000000000','0.000068000000000','0.001580549636728','0.001557643120254','22.906516474318842','22.906516474318842','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WABIBTC','4h','0.000044940000000','0.000046300000000','0.001580549636728','0.001628381134413','35.170218885803294','35.170218885803294','test'),('2019-05-26 03:59:59','2019-05-26 07:59:59','WABIBTC','4h','0.000043740000000','0.000043390000000','0.001580549636728','0.001567902348826','36.13510829282122','36.135108292821222','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:34:59
