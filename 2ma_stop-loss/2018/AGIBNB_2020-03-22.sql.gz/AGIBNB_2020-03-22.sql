-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-21 11:59:59','2018-11-21 15:59:59','AGIBNB','4h','0.006590000000000','0.006670000000000','0.711908500000000','0.720550788315630','108.02860394537178','108.028603945371785','test'),('2018-11-24 15:59:59','2018-11-24 19:59:59','AGIBNB','4h','0.006630000000000','0.006520000000000','0.714069072078908','0.702221772240495','107.7027258037568','107.702725803756806','test'),('2018-11-25 03:59:59','2018-11-25 07:59:59','AGIBNB','4h','0.006670000000000','0.006430000000000','0.714069072078908','0.688375432303955','107.0568323956384','107.056832395638395','test'),('2018-11-25 11:59:59','2018-11-25 15:59:59','AGIBNB','4h','0.006540000000000','0.006560000000000','0.714069072078908','0.716252769547039','109.18487340656087','109.184873406560868','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','AGIBNB','4h','0.007760000000000','0.007410000000000','0.714069072078908','0.681862348467102','92.0192103194469','92.019210319446898','test'),('2018-12-06 07:59:59','2018-12-06 15:59:59','AGIBNB','4h','0.008560000000000','0.007990000000000','0.714069072078908','0.666520080129728','83.41928412136777','83.419284121367767','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','AGIBNB','4h','0.007790000000000','0.007400000000000','0.714069072078908','0.678319786056986','91.66483595364673','91.664835953646730','test'),('2018-12-07 15:59:59','2018-12-08 07:59:59','AGIBNB','4h','0.008380000000000','0.008290000000000','0.714069072078908','0.706400072498108','85.21110645333032','85.211106453330316','test'),('2018-12-16 03:59:59','2018-12-16 07:59:59','AGIBNB','4h','0.007750000000000','0.007800000000000','0.714069072078908','0.718675969318127','92.13794478437522','92.137944784375222','test'),('2018-12-17 23:59:59','2018-12-18 19:59:59','AGIBNB','4h','0.007700000000000','0.007680000000000','0.714069072078908','0.712214347216365','92.7362431271309','92.736243127130905','test'),('2018-12-19 03:59:59','2018-12-22 15:59:59','AGIBNB','4h','0.007800000000000','0.008200000000000','0.714069072078908','0.750687998852185','91.54731693319334','91.547316933193343','test'),('2018-12-23 15:59:59','2018-12-23 23:59:59','AGIBNB','4h','0.008100000000000','0.007910000000000','0.714069072078908','0.697319303721502','88.15667556529729','88.156675565297292','test'),('2018-12-30 15:59:59','2018-12-31 03:59:59','AGIBNB','4h','0.008010000000000','0.007860000000000','0.714069072078908','0.700696992077430','89.14720000985119','89.147200009851190','test'),('2018-12-31 11:59:59','2018-12-31 15:59:59','AGIBNB','4h','0.007760000000000','0.007850000000000','0.714069072078908','0.722350801007658','92.0192103194469','92.019210319446898','test'),('2019-01-01 11:59:59','2019-01-01 15:59:59','AGIBNB','4h','0.007800000000000','0.007810000000000','0.714069072078908','0.714984545248240','91.54731693319334','91.547316933193343','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','AGIBNB','4h','0.008470000000000','0.008370000000000','0.714069072078908','0.705638504521896','84.305675570119','84.305675570119007','test'),('2019-01-26 11:59:59','2019-01-26 15:59:59','AGIBNB','4h','0.007620000000000','0.007340000000000','0.714069072078908','0.687830313524827','93.70985197885932','93.709851978859319','test'),('2019-01-27 03:59:59','2019-01-27 07:59:59','AGIBNB','4h','0.007480000000000','0.007200000000000','0.714069072078908','0.687339213765794','95.4637796896936','95.463779689693595','test'),('2019-01-28 19:59:59','2019-01-29 03:59:59','AGIBNB','4h','0.007580000000000','0.007490000000000','0.714069072078908','0.705590679402509','94.20436307109604','94.204363071096040','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','AGIBNB','4h','0.007480000000000','0.007480000000000','0.714069072078908','0.714069072078908','95.4637796896936','95.463779689693595','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','AGIBNB','4h','0.004780000000000','0.004720000000000','0.714069072078908','0.705105861969131','149.38683516295146','149.386835162951456','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','AGIBNB','4h','0.003490000000000','0.003350000000000','0.714069072078908','0.685424467468293','204.60431864725157','204.604318647251574','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','AGIBNB','4h','0.004040000000000','0.003820000000000','0.714069072078908','0.675184122609265','176.74977031656138','176.749770316561381','test'),('2019-03-16 19:59:59','2019-03-18 03:59:59','AGIBNB','4h','0.003500000000000','0.003520000000000','0.714069072078908','0.718149466776502','204.019734879688','204.019734879688002','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','AGIBNB','4h','0.003520000000000','0.003380000000000','0.714069072078908','0.685668597621224','202.86053184059887','202.860531840598867','test'),('2019-03-20 07:59:59','2019-03-21 03:59:59','AGIBNB','4h','0.003570000000000','0.003500000000000','0.714069072078908','0.700067717724420','200.01934792126275','200.019347921262749','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','AGIBNB','4h','0.003530000000000','0.003510000000000','0.714069072078908','0.710023354956648','202.28585611300508','202.285856113005082','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','AGIBNB','4h','0.003520000000000','0.003520000000000','0.714069072078908','0.714069072078908','202.86053184059887','202.860531840598867','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','AGIBNB','4h','0.001850000000000','0.001770000000000','0.714069072078908','0.683190409502523','385.9832822048151','385.983282204815112','test'),('2019-05-05 03:59:59','2019-05-05 07:59:59','AGIBNB','4h','0.001800000000000','0.001760000000000','0.714069072078908','0.698200870477155','396.7050400438378','396.705040043837812','test'),('2019-05-06 15:59:59','2019-05-10 03:59:59','AGIBNB','4h','0.001740000000000','0.001990000000000','0.714069072078908','0.816665203124728','410.38452418328046','410.384524183280462','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','AGIBNB','4h','0.001840000000000','0.001800000000000','0.714069072078908','0.698545831381540','388.0810174341891','388.081017434189107','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','AGIBNB','4h','0.001670000000000','0.001630000000000','0.714069072078908','0.696965621250671','427.5862707059329','427.586270705932918','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','AGIBNB','4h','0.001580000000000','0.001560000000000','0.714069072078908','0.705030223065251','451.9424506828532','451.942450682853178','test'),('2019-06-01 23:59:59','2019-06-02 07:59:59','AGIBNB','4h','0.001520000000000','0.001520000000000','0.714069072078908','0.714069072078908','469.7822842624395','469.782284262439475','test'),('2019-06-02 23:59:59','2019-06-04 11:59:59','AGIBNB','4h','0.001590000000000','0.001550000000000','0.714069072078908','0.696105070265602','449.1000453326465','449.100045332646516','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','AGIBNB','4h','0.001570000000000','0.001600000000000','0.714069072078908','0.727713704029460','454.82106501841275','454.821065018412753','test'),('2019-07-19 23:59:59','2019-07-20 03:59:59','AGIBNB','4h','0.000916000000000','0.000852000000000','0.714069072078908','0.664177783200032','779.5513887324323','779.551388732432315','test'),('2019-07-21 11:59:59','2019-07-21 23:59:59','AGIBNB','4h','0.000912000000000','0.000927000000000','0.714069072078908','0.725813629185469','782.9704737707324','782.970473770732383','test'),('2019-07-22 15:59:59','2019-07-23 19:59:59','AGIBNB','4h','0.000945000000000','0.001260000000000','0.714069072078908','0.952092096105211','755.6286477025482','755.628647702548164','test'),('2019-07-30 15:59:59','2019-07-31 03:59:59','AGIBNB','4h','0.001078000000000','0.001052000000000','0.714069072078908','0.696846626926727','662.4017366223637','662.401736622363728','test'),('2019-08-01 07:59:59','2019-08-01 11:59:59','AGIBNB','4h','0.001035000000000','0.000977000000000','0.714069072078908','0.674053607170138','689.9218087718918','689.921808771891847','test'),('2019-08-03 03:59:59','2019-08-06 23:59:59','AGIBNB','4h','0.001047000000000','0.001100000000000','0.714069072078908','0.750215835039923','682.0143954908386','682.014395490838638','test'),('2019-08-11 03:59:59','2019-08-11 07:59:59','AGIBNB','4h','0.001095000000000','0.001065000000000','0.714069072078908','0.694505535857568','652.1178740446649','652.117874044664859','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','AGIBNB','4h','0.001079000000000','0.001062000000000','0.714069072078908','0.702818678913624','661.7878332519999','661.787833251999928','test'),('2019-08-12 07:59:59','2019-08-12 11:59:59','AGIBNB','4h','0.001081000000000','0.001089000000000','0.714069072078908','0.719353579550352','660.5634339305348','660.563433930534757','test'),('2019-09-04 19:59:59','2019-09-05 19:59:59','AGIBNB','4h','0.001404000000000','0.001292000000000','0.714069072078908','0.657106297098254','508.5962051844074','508.596205184407381','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','AGIBNB','4h','0.001322000000000','0.001280000000000','0.714069072078908','0.691383065250380','540.1430197268593','540.143019726859279','test'),('2019-09-15 23:59:59','2019-09-16 07:59:59','AGIBNB','4h','0.001260000000000','0.001262000000000','0.714069072078908','0.715202515050462','566.7214857769111','566.721485776911095','test'),('2019-09-20 03:59:59','2019-09-20 15:59:59','AGIBNB','4h','0.001254000000000','0.001234000000000','0.714069072078908','0.702680410642243','569.43307183326','569.433071833259987','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','AGIBNB','4h','0.001288000000000','0.001257000000000','0.714069072078908','0.696882627021108','554.401453477413','554.401453477413042','test'),('2019-10-02 11:59:59','2019-10-09 07:59:59','AGIBNB','4h','0.001320000000000','0.001402000000000','0.714069072078908','0.758427908374719','540.961418241597','540.961418241597016','test'),('2019-10-12 15:59:59','2019-10-12 19:59:59','AGIBNB','4h','0.001371000000000','0.001348000000000','0.714069072078908','0.702089795158547','520.838126972216','520.838126972215946','test'),('2019-10-12 23:59:59','2019-10-13 03:59:59','AGIBNB','4h','0.001390000000000','0.001302000000000','0.714069072078908','0.668861821472474','513.7187568913007','513.718756891300700','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','AGIBNB','4h','0.001241000000000','0.001177000000000','0.714069072078908','0.677243592132856','575.3981241570573','575.398124157057282','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','AGIBNB','4h','0.001118000000000','0.001088000000000','0.714069072078908','0.694908005744054','638.7022111618139','638.702211161813921','test'),('2019-11-07 07:59:59','2019-11-07 15:59:59','AGIBNB','4h','0.001113000000000','0.001080000000000','0.714069072078908','0.692897212798940','641.5714933323521','641.571493332352134','test'),('2019-11-15 03:59:59','2019-11-17 11:59:59','AGIBNB','4h','0.001080000000000','0.001098000000000','0.714069072078908','0.725970223280223','661.1750667397297','661.175066739729687','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:15:20
