-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-18 15:59:59','2018-05-20 15:59:59','PPTBTC','4h','0.002082400000000','0.002117000000000','0.001467500000000','0.001491883163657','0.7047157126392625','0.704715712639262','test'),('2018-06-30 03:59:59','2018-06-30 07:59:59','PPTBTC','4h','0.001082100000000','0.001050000000000','0.001473595790914','0.001429882247907','1.361792617054108','1.361792617054108','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','PPTBTC','4h','0.001261000000000','0.001207000000000','0.001473595790914','0.001410491768147','1.1685930142061856','1.168593014206186','test'),('2018-07-07 23:59:59','2018-07-08 03:59:59','PPTBTC','4h','0.001196900000000','0.001170100000000','0.001473595790914','0.001440600246427','1.2311770330971676','1.231177033097168','test'),('2018-08-08 23:59:59','2018-08-09 03:59:59','PPTBTC','4h','0.000718900000000','0.000698200000000','0.001473595790914','0.001431165087239','2.0497924480650993','2.049792448065099','test'),('2018-08-10 03:59:59','2018-08-10 11:59:59','PPTBTC','4h','0.000694300000000','0.000689300000000','0.001473595790914','0.001462983693903','2.1224194021518072','2.122419402151807','test'),('2018-08-16 11:59:59','2018-08-16 15:59:59','PPTBTC','4h','0.000672100000000','0.000636000000000','0.001473595790914','0.001394445652464','2.1925246107930367','2.192524610793037','test'),('2018-08-21 19:59:59','2018-08-22 19:59:59','PPTBTC','4h','0.000737200000000','0.000721600000000','0.001473595790914','0.001442412808903','1.9989091032474224','1.998909103247422','test'),('2018-08-23 11:59:59','2018-08-24 03:59:59','PPTBTC','4h','0.000748600000000','0.000745800000000','0.001473595790914','0.001468084078097','1.9684688630964466','1.968468863096447','test'),('2018-09-07 07:59:59','2018-09-07 11:59:59','PPTBTC','4h','0.000640200000000','0.000629700000000','0.001473595790914','0.001449427162666','2.3017741188909717','2.301774118890972','test'),('2018-09-15 19:59:59','2018-09-15 23:59:59','PPTBTC','4h','0.000566600000000','0.000540100000000','0.001473595790914','0.001404675408882','2.6007691332756795','2.600769133275679','test'),('2018-09-29 11:59:59','2018-09-29 15:59:59','PPTBTC','4h','0.000485500000000','0.000487600000000','0.001473595790914','0.001479969737692','3.035212751625129','3.035212751625129','test'),('2018-10-02 11:59:59','2018-10-02 23:59:59','PPTBTC','4h','0.000486300000000','0.000484600000000','0.001473595790914','0.001468444417596','3.0302195988361094','3.030219598836109','test'),('2018-10-03 15:59:59','2018-10-03 19:59:59','PPTBTC','4h','0.000485100000000','0.000478800000000','0.001473595790914','0.001454458183240','3.0377155038425068','3.037715503842507','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','PPTBTC','4h','0.000491000000000','0.000493300000000','0.001473595790914','0.001480498581788','3.0012134234501016','3.001213423450102','test'),('2018-10-13 15:59:59','2018-10-13 23:59:59','PPTBTC','4h','0.000518000000000','0.000514900000000','0.001473595790914','0.001464776974405','2.8447795191389957','2.844779519138996','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','PPTBTC','4h','0.000516600000000','0.000511600000000','0.001473595790914','0.001459333346170','2.8524889487301586','2.852488948730159','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','PPTBTC','4h','0.000514900000000','0.000507800000000','0.001473595790914','0.001453276252915','2.8619067603690036','2.861906760369004','test'),('2018-10-18 07:59:59','2018-10-18 11:59:59','PPTBTC','4h','0.000525500000000','0.000519900000000','0.001473595790914','0.001457892391429','2.804178479379638','2.804178479379638','test'),('2018-10-19 15:59:59','2018-10-22 03:59:59','PPTBTC','4h','0.000525600000000','0.000517800000000','0.001473595790914','0.001451727360227','2.8036449598820394','2.803644959882039','test'),('2018-10-26 23:59:59','2018-10-27 23:59:59','PPTBTC','4h','0.000528200000000','0.000525800000000','0.001473595790914','0.001466900164450','2.789844359928057','2.789844359928057','test'),('2018-11-11 15:59:59','2018-11-11 19:59:59','PPTBTC','4h','0.000548000000000','0.000537300000000','0.001473595790914','0.001444823026383','2.689043414076642','2.689043414076642','test'),('2018-11-12 03:59:59','2018-11-12 11:59:59','PPTBTC','4h','0.000544100000000','0.000539800000000','0.001473595790914','0.001461950023774','2.708317939558904','2.708317939558904','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','PPTBTC','4h','0.000430900000000','0.000423600000000','0.001473595790914','0.001448631183642','3.4198092153956834','3.419809215395683','test'),('2018-12-04 15:59:59','2018-12-04 23:59:59','PPTBTC','4h','0.000436400000000','0.000426800000000','0.001473595790914','0.001441179384881','3.3767089617644364','3.376708961764436','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','PPTBTC','4h','0.000425100000000','0.000415000000000','0.001473595790914','0.001438584458314','3.4664685742507646','3.466468574250765','test'),('2018-12-19 03:59:59','2018-12-21 19:59:59','PPTBTC','4h','0.000367500000000','0.000381100000000','0.001473595790914','0.001528128859639','4.009784465072109','4.009784465072109','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','PPTBTC','4h','0.000401400000000','0.000401100000000','0.001473595790914','0.001472494448768','3.671140485585451','3.671140485585451','test'),('2018-12-29 07:59:59','2018-12-29 11:59:59','PPTBTC','4h','0.000402100000000','0.000403000000000','0.001473595790914','0.001476894065502','3.66474954218851','3.664749542188510','test'),('2018-12-30 07:59:59','2018-12-30 11:59:59','PPTBTC','4h','0.000407500000000','0.000407000000000','0.001473595790914','0.001471787697919','3.616185989973006','3.616185989973006','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','PPTBTC','4h','0.000396600000000','0.000393600000000','0.001473595790914','0.001462449075400','3.7155718379072113','3.715571837907211','test'),('2019-01-06 03:59:59','2019-01-06 11:59:59','PPTBTC','4h','0.000395700000000','0.000397700000000','0.001473595790914','0.001481043836357','3.7240227215415715','3.724022721541572','test'),('2019-01-13 15:59:59','2019-01-13 19:59:59','PPTBTC','4h','0.000410200000000','0.000398800000000','0.001473595790914','0.001432642616813','3.5923836931106776','3.592383693110678','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','PPTBTC','4h','0.000373800000000','0.000372600000000','0.001473595790914','0.001468865146320','3.942203828020332','3.942203828020332','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','PPTBTC','4h','0.000372300000000','0.000371000000000','0.001473595790914','0.001468450277811','3.9580870021864087','3.958087002186409','test'),('2019-01-23 07:59:59','2019-01-23 11:59:59','PPTBTC','4h','0.000372000000000','0.000367900000000','0.001473595790914','0.001457354546982','3.9612790078333333','3.961279007833333','test'),('2019-01-24 11:59:59','2019-01-24 23:59:59','PPTBTC','4h','0.000374300000000','0.000367700000000','0.001473595790914','0.001447612001921','3.9369377261928933','3.936937726192893','test'),('2019-01-26 11:59:59','2019-01-26 15:59:59','PPTBTC','4h','0.000389000000000','0.000372600000000','0.001473595790914','0.001411469901528','3.7881639869254493','3.788163986925449','test'),('2019-02-08 11:59:59','2019-02-08 15:59:59','PPTBTC','4h','0.000349000000000','0.000346100000000','0.001473595790914','0.001461351012136','4.222337509782235','4.222337509782235','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','PPTBTC','4h','0.000348900000000','0.000343700000000','0.001473595790914','0.001451633342898','4.2235476953683','4.223547695368300','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','PPTBTC','4h','0.000352600000000','0.000347400000000','0.001473595790914','0.001451863805342','4.179227994651162','4.179227994651162','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','PPTBTC','4h','0.000343100000000','0.000340200000000','0.001473595790914','0.001461140449050','4.294945470457592','4.294945470457592','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','PPTBTC','4h','0.000343400000000','0.000342200000000','0.001473595790914','0.001468446358913','4.291193334053582','4.291193334053582','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','PPTBTC','4h','0.000346100000000','0.000342700000000','0.001473595790914','0.001459119553731','4.257716818590002','4.257716818590002','test'),('2019-03-03 23:59:59','2019-03-04 11:59:59','PPTBTC','4h','0.000330000000000','0.000318200000000','0.001473595790914','0.001420903577784','4.465441790648485','4.465441790648485','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','PPTBTC','4h','0.000321000000000','0.000318500000000','0.001473595790914','0.001462119188181','4.590641093190031','4.590641093190031','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','PPTBTC','4h','0.000318600000000','0.000316000000000','0.001473595790914','0.001461570213210','4.625222193703704','4.625222193703704','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','PPTBTC','4h','0.000323500000000','0.000319900000000','0.001473595790914','0.001457197197878','4.555164732346213','4.555164732346213','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','PPTBTC','4h','0.000318800000000','0.000317900000000','0.001473595790914','0.001469435702420','4.622320548663739','4.622320548663739','test'),('2019-03-12 11:59:59','2019-03-14 03:59:59','PPTBTC','4h','0.000333400000000','0.000327800000000','0.001473595790914','0.001448844331918','4.419903392063587','4.419903392063587','test'),('2019-03-22 07:59:59','2019-03-25 07:59:59','PPTBTC','4h','0.000349700000000','0.000353300000000','0.001473595790914','0.001488765779039','4.213885590260223','4.213885590260223','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','PPTBTC','4h','0.000352300000000','0.000351700000000','0.001473595790914','0.001471086118832','4.182786803616236','4.182786803616236','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','PPTBTC','4h','0.000361300000000','0.000355900000000','0.001473595790914','0.001451571386621','4.07859338752837','4.078593387528370','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:19:55
