-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-31 15:59:59','2018-03-31 19:59:59','ENGBTC','4h','0.000207430000000','0.000205720000000','0.001467500000000','0.001455402304392','7.074675794243841','7.074675794243841','test'),('2018-03-31 23:59:59','2018-04-01 03:59:59','ENGBTC','4h','0.000207510000000','0.000205770000000','0.001467500000000','0.001455194809889','7.071948339839044','7.071948339839044','test'),('2018-04-02 11:59:59','2018-04-03 15:59:59','ENGBTC','4h','0.000207790000000','0.000210010000000','0.001467500000000','0.001483178569710','7.062418788199626','7.062418788199626','test'),('2018-04-08 07:59:59','2018-04-08 15:59:59','ENGBTC','4h','0.000209150000000','0.000206290000000','0.001467500000000','0.001447432823333','7.016495338273967','7.016495338273967','test'),('2018-04-10 15:59:59','2018-04-11 15:59:59','ENGBTC','4h','0.000206440000000','0.000211560000000','0.001467500000000','0.001503896047278','7.108602983917845','7.108602983917845','test'),('2018-04-25 19:59:59','2018-04-25 23:59:59','ENGBTC','4h','0.000261080000000','0.000253050000000','0.001469401138651','0.001424206979223','5.628164312281676','5.628164312281676','test'),('2018-04-26 11:59:59','2018-04-28 11:59:59','ENGBTC','4h','0.000263640000000','0.000271140000000','0.001469401138651','0.001511202491025','5.573513649867243','5.573513649867243','test'),('2018-05-08 19:59:59','2018-05-08 23:59:59','ENGBTC','4h','0.000294170000000','0.000290910000000','0.001469401138651','0.001453117194972','4.9950747481082365','4.995074748108236','test'),('2018-05-09 11:59:59','2018-05-09 15:59:59','ENGBTC','4h','0.000287740000000','0.000281300000000','0.001469401138651','0.001436514006751','5.1066975000034756','5.106697500003476','test'),('2018-05-09 23:59:59','2018-05-10 23:59:59','ENGBTC','4h','0.000290460000000','0.000286180000000','0.001469401138651','0.001447749149140','5.058876054021208','5.058876054021208','test'),('2018-05-12 11:59:59','2018-05-16 03:59:59','ENGBTC','4h','0.000290450000000','0.000309690000000','0.001469401138651','0.001566737265033','5.059050227753486','5.059050227753486','test'),('2018-05-17 11:59:59','2018-05-17 15:59:59','ENGBTC','4h','0.000307980000000','0.000300920000000','0.001475181202210','0.001441364787873','4.789860387719982','4.789860387719982','test'),('2018-06-02 11:59:59','2018-06-02 15:59:59','ENGBTC','4h','0.000273640000000','0.000267410000000','0.001475181202210','0.001441595546276','5.390956008661014','5.390956008661014','test'),('2018-06-05 23:59:59','2018-06-06 03:59:59','ENGBTC','4h','0.000262580000000','0.000259960000000','0.001475181202210','0.001460461974737','5.618025752951481','5.618025752951481','test'),('2018-06-06 11:59:59','2018-06-08 07:59:59','ENGBTC','4h','0.000264560000000','0.000266110000000','0.001475181202210','0.001483823970820','5.575979748299062','5.575979748299062','test'),('2018-06-20 15:59:59','2018-06-22 15:59:59','ENGBTC','4h','0.000228000000000','0.000233170000000','0.001475181202210','0.001508631582979','6.470092992149122','6.470092992149122','test'),('2018-06-24 19:59:59','2018-06-24 23:59:59','ENGBTC','4h','0.000237730000000','0.000233170000000','0.001475181202210','0.001446885125644','6.205279948723342','6.205279948723342','test'),('2018-06-27 23:59:59','2018-06-28 03:59:59','ENGBTC','4h','0.000237950000000','0.000228140000000','0.001475181202210','0.001414363687633','6.199542770371926','6.199542770371926','test'),('2018-06-28 15:59:59','2018-06-28 19:59:59','ENGBTC','4h','0.000234410000000','0.000232470000000','0.001475181202210','0.001462972458845','6.293166683204642','6.293166683204642','test'),('2018-07-01 11:59:59','2018-07-01 19:59:59','ENGBTC','4h','0.000232740000000','0.000231270000000','0.001475181202210','0.001465863867986','6.338322601228839','6.338322601228839','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','ENGBTC','4h','0.000239750000000','0.000237140000000','0.001475181202210','0.001459121878173','6.152997715161627','6.152997715161627','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','ENGBTC','4h','0.000200690000000','0.000200590000000','0.001475181202210','0.001474446147547','7.3505466251930835','7.350546625193084','test'),('2018-07-17 23:59:59','2018-07-18 19:59:59','ENGBTC','4h','0.000205740000000','0.000201410000000','0.001475181202210','0.001444134567596','7.170123467531837','7.170123467531837','test'),('2018-08-18 03:59:59','2018-08-18 07:59:59','ENGBTC','4h','0.000118460000000','0.000111410000000','0.001475181202210','0.001387387622305','12.452990057487758','12.452990057487758','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','ENGBTC','4h','0.000116750000000','0.000113900000000','0.001475181202210','0.001439170354876','12.635385029635973','12.635385029635973','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ENGBTC','4h','0.000116700000000','0.000117440000000','0.001475181202210','0.001484535393209','12.6407986479006','12.640798647900599','test'),('2018-09-21 15:59:59','2018-09-21 23:59:59','ENGBTC','4h','0.000096390000000','0.000093850000000','0.001475181202210','0.001436308287451','15.304297149185599','15.304297149185599','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','ENGBTC','4h','0.000091070000000','0.000090540000000','0.001475181202210','0.001466596091447','16.198322194026574','16.198322194026574','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','ENGBTC','4h','0.000091520000000','0.000089870000000','0.001475181202210','0.001448585387266','16.118675723448426','16.118675723448426','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','ENGBTC','4h','0.000091070000000','0.000091000000000','0.001475181202210','0.001474047319656','16.198322194026574','16.198322194026574','test'),('2018-09-26 23:59:59','2018-09-28 11:59:59','ENGBTC','4h','0.000090340000000','0.000090590000000','0.001475181202210','0.001479263505736','16.329214104604823','16.329214104604823','test'),('2018-10-04 11:59:59','2018-10-04 15:59:59','ENGBTC','4h','0.000093120000000','0.000092340000000','0.001475181202210','0.001462824658635','15.841722532323882','15.841722532323882','test'),('2018-10-07 11:59:59','2018-10-11 07:59:59','ENGBTC','4h','0.000093390000000','0.000090740000000','0.001475181202210','0.001433322007587','15.795922499303993','15.795922499303993','test'),('2018-10-14 11:59:59','2018-10-14 15:59:59','ENGBTC','4h','0.000093910000000','0.000094470000000','0.001475181202210','0.001483977938162','15.708457056862953','15.708457056862953','test'),('2018-10-16 15:59:59','2018-10-16 23:59:59','ENGBTC','4h','0.000092160000000','0.000091830000000','0.001475181202210','0.001469898977853','16.00674047536892','16.006740475368922','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','ENGBTC','4h','0.000092480000000','0.000091610000000','0.001475181202210','0.001461303524378','15.951353830125433','15.951353830125433','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','ENGBTC','4h','0.000092120000000','0.000092310000000','0.001475181202210','0.001478223803474','16.013690862027786','16.013690862027786','test'),('2018-10-20 07:59:59','2018-10-20 11:59:59','ENGBTC','4h','0.000092560000000','0.000094360000000','0.001475181202210','0.001503868822823','15.937567007454625','15.937567007454625','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','ENGBTC','4h','0.000098600000000','0.000097480000000','0.001475181202210','0.001458424580035','14.961269799290061','14.961269799290061','test'),('2018-10-31 23:59:59','2018-11-03 03:59:59','ENGBTC','4h','0.000100460000000','0.000099440000000','0.001475181202210','0.001460203252516','14.684264405833167','14.684264405833167','test'),('2018-11-04 23:59:59','2018-11-06 11:59:59','ENGBTC','4h','0.000102130000000','0.000100820000000','0.001475181202210','0.001456259363623','14.444151593165573','14.444151593165573','test'),('2018-11-07 19:59:59','2018-11-07 23:59:59','ENGBTC','4h','0.000101360000000','0.000099770000000','0.001475181202210','0.001452040534180','14.553879264108128','14.553879264108128','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','ENGBTC','4h','0.000100860000000','0.000099330000000','0.001475181202210','0.001452803379095','14.626028179754114','14.626028179754114','test'),('2018-11-21 23:59:59','2018-11-22 03:59:59','ENGBTC','4h','0.000092000000000','0.000088050000000','0.001475181202210','0.001411844617985','16.034578284891303','16.034578284891303','test'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENGBTC','4h','0.000079340000000','0.000080860000000','0.001475181202210','0.001503442803261','18.593158585959163','18.593158585959163','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ENGBTC','4h','0.000085380000000','0.000077940000000','0.001475181202210','0.001346634140317','17.277830899625204','17.277830899625204','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','ENGBTC','4h','0.000080140000000','0.000080420000000','0.001475181202210','0.001480335316717','18.40755181195408','18.407551811954079','test'),('2018-12-02 15:59:59','2018-12-02 23:59:59','ENGBTC','4h','0.000080110000000','0.000078950000000','0.001475181202210','0.001453820445818','18.414445165522405','18.414445165522405','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','ENGBTC','4h','0.000069530000000','0.000067590000000','0.001475181202210','0.001434021249207','21.216470620020136','21.216470620020136','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','ENGBTC','4h','0.000083010000000','0.000081850000000','0.001475181202210','0.001454566695590','17.771126396940126','17.771126396940126','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENGBTC','4h','0.000080250000000','0.000079390000000','0.001475181202210','0.001459372406772','18.382320276760122','18.382320276760122','test'),('2019-01-23 11:59:59','2019-01-23 19:59:59','ENGBTC','4h','0.000082790000000','0.000080890000000','0.001475181202210','0.001441326337079','17.818350068969682','17.818350068969682','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','ENGBTC','4h','0.000079210000000','0.000078690000000','0.001475181202210','0.001465496891831','18.62367380646383','18.623673806463831','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','ENGBTC','4h','0.000080160000000','0.000075730000000','0.001475181202210','0.001393656093355','18.402959109406186','18.402959109406186','test'),('2019-02-08 11:59:59','2019-02-08 15:59:59','ENGBTC','4h','0.000077200000000','0.000074650000000','0.001475181202210','0.001426454361982','19.108564795466318','19.108564795466318','test'),('2019-02-09 15:59:59','2019-02-16 15:59:59','ENGBTC','4h','0.000078490000000','0.000081660000000','0.001475181202210','0.001534759803446','18.794511430882913','18.794511430882913','test'),('2019-02-20 11:59:59','2019-02-24 07:59:59','ENGBTC','4h','0.000083920000000','0.000085010000000','0.001475181202210','0.001494341682553','17.578422333293613','17.578422333293613','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','ENGBTC','4h','0.000085580000000','0.000085000000000','0.001475181202210','0.001465183479643','17.237452701682635','17.237452701682635','test'),('2019-03-05 15:59:59','2019-03-05 19:59:59','ENGBTC','4h','0.000087190000000','0.000085100000000','0.001475181202210','0.001439820166396','16.919155891845396','16.919155891845396','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','ENGBTC','4h','0.000088000000000','0.000086940000000','0.001475181202210','0.001457411974092','16.763422752386365','16.763422752386365','test'),('2019-03-18 19:59:59','2019-03-18 23:59:59','ENGBTC','4h','0.000104480000000','0.000104790000000','0.001475181202210','0.001479558175532','14.119268780723582','14.119268780723582','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','ENGBTC','4h','0.000106060000000','0.000106730000000','0.001475181202210','0.001484500185856','13.908930814727512','13.908930814727512','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:22:44
