-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-12 19:59:59','2018-12-13 03:59:59','KEYETH','4h','0.000028880000000','0.000028150000000','0.072144500000000','0.070320902873961','2498.0782548476454','2498.078254847645439','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','KEYETH','4h','0.000027940000000','0.000028000000000','0.072144500000000','0.072299427344309','2582.122405153901','2582.122405153901127','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','KEYETH','4h','0.000019880000000','0.000020180000000','0.072144500000000','0.073233199698189','3628.9989939637826','3628.998993963782596','test'),('2019-02-01 11:59:59','2019-02-02 11:59:59','KEYETH','4h','0.000025230000000','0.000024980000000','0.072144500000000','0.071429631787555','2859.4728497820056','2859.472849782005596','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','KEYETH','4h','0.000025100000000','0.000024730000000','0.072144500000000','0.071081015338645','2874.2828685258964','2874.282868525896447','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','KEYETH','4h','0.000024900000000','0.000023740000000','0.072144500000000','0.068783551405622','2897.3694779116468','2897.369477911646754','test'),('2019-03-02 19:59:59','2019-03-02 23:59:59','KEYETH','4h','0.000019550000000','0.000020530000000','0.072144500000000','0.075760950639386','3690.2557544757033','3690.255754475703270','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','KEYETH','4h','0.000019480000000','0.000019390000000','0.072144500000000','0.071811183521561','3703.516427104723','3703.516427104722879','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','KEYETH','4h','0.000019430000000','0.000019350000000','0.072144500000000','0.071847456253217','3713.04683479156','3713.046834791559832','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','KEYETH','4h','0.000019510000000','0.000020330000000','0.072144500000000','0.075176713736545','3697.821629933367','3697.821629933367149','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','KEYETH','4h','0.000020730000000','0.000020600000000','0.072219258149748','0.071766363622036','3483.8040593221176','3483.804059322117610','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','KEYETH','4h','0.000020620000000','0.000020300000000','0.072219258149748','0.071098493716774','3502.388853043065','3502.388853043064955','test'),('2019-03-18 19:59:59','2019-03-19 15:59:59','KEYETH','4h','0.000020730000000','0.000020600000000','0.072219258149748','0.071766363622036','3483.8040593221417','3483.804059322141711','test'),('2019-03-27 07:59:59','2019-03-29 03:59:59','KEYETH','4h','0.000021640000000','0.000021720000000','0.072219258149748','0.072486242468231','3337.3039810419596','3337.303981041959560','test'),('2019-03-31 15:59:59','2019-04-02 15:59:59','KEYETH','4h','0.000022220000000','0.000022140000000','0.072219258149748','0.071959242818876','3250.1916359022503','3250.191635902250255','test'),('2019-04-04 03:59:59','2019-04-04 07:59:59','KEYETH','4h','0.000021880000000','0.000021790000000','0.072219258149748','0.071922195387706','3300.697356021389','3300.697356021389169','test'),('2019-04-05 07:59:59','2019-04-05 11:59:59','KEYETH','4h','0.000021810000000','0.000021290000000','0.072219258149748','0.070497386795421','3311.291066013205','3311.291066013205182','test'),('2019-04-30 19:59:59','2019-05-03 23:59:59','KEYETH','4h','0.000017740000000','0.000017700000000','0.072219258149748','0.072056418785262','4070.9841121616687','4070.984112161668691','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','KEYETH','4h','0.000018210000000','0.000018050000000','0.072219258149748','0.071584712224215','3965.912034582537','3965.912034582537217','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','KEYETH','4h','0.000017400000000','0.000016570000000','0.072219258149748','0.068774316525363','4150.532077571725','4150.532077571724585','test'),('2019-05-10 23:59:59','2019-05-11 03:59:59','KEYETH','4h','0.000016930000000','0.000016890000000','0.072219258149748','0.072048627888319','4265.756535720497','4265.756535720496686','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','KEYETH','4h','0.000016900000000','0.000016480000000','0.072219258149748','0.070424460018216','4273.328884600473','4273.328884600473430','test'),('2019-05-12 11:59:59','2019-05-12 15:59:59','KEYETH','4h','0.000017110000000','0.000016620000000','0.072219258149748','0.070151026911094','4220.880078886499','4220.880078886499177','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','KEYETH','4h','0.000016920000000','0.000016440000000','0.072219258149748','0.070170484868904','4268.277668424823','4268.277668424822878','test'),('2019-05-13 03:59:59','2019-05-13 07:59:59','KEYETH','4h','0.000016920000000','0.000017410000000','0.072219258149748','0.074310714207276','4268.277668424823','4268.277668424822878','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','KEYETH','4h','0.000015350000000','0.000015350000000','0.072219258149748','0.072219258149748','4704.837664478697','4704.837664478696752','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','KEYETH','4h','0.000015270000000','0.000014470000000','0.072219258149748','0.068435668986696','4729.4864538145375','4729.486453814537526','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','KEYETH','4h','0.000014690000000','0.000014340000000','0.072219258149748','0.070498581474975','4916.219070779306','4916.219070779306094','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','KEYETH','4h','0.000014480000000','0.000014680000000','0.072219258149748','0.073216761715352','4987.51782802127','4987.517828021270361','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','KEYETH','4h','0.000014540000000','0.000014000000000','0.072219258149748','0.069537112386277','4966.9365990198075','4966.936599019807545','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','KEYETH','4h','0.000014230000000','0.000014140000000','0.072219258149748','0.071762495448871','5075.141120853689','5075.141120853689245','test'),('2019-06-07 07:59:59','2019-06-07 15:59:59','KEYETH','4h','0.000014250000000','0.000014280000000','0.072219258149748','0.072371298693221','5068.018115771789','5068.018115771788871','test'),('2019-06-10 03:59:59','2019-06-10 11:59:59','KEYETH','4h','0.000014220000000','0.000014160000000','0.072219258149748','0.071914535541521','5078.71013711308','5078.710137113080236','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','KEYETH','4h','0.000011010000000','0.000011280000000','0.072219258149748','0.073990302627535','6559.423991802725','6559.423991802725141','test'),('2019-07-15 03:59:59','2019-07-15 07:59:59','KEYETH','4h','0.000009530000000','0.000009430000000','0.072219258149748','0.071461448515438','7578.096343100525','7578.096343100524791','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','KEYETH','4h','0.000009400000000','0.000009640000000','0.072219258149748','0.074063154102508','7682.899803164681','7682.899803164680634','test'),('2019-07-19 11:59:59','2019-07-20 03:59:59','KEYETH','4h','0.000009620000000','0.000009400000000','0.072219258149748','0.070567674283538','7507.199391865697','7507.199391865697180','test'),('2019-07-20 23:59:59','2019-07-21 07:59:59','KEYETH','4h','0.000009600000000','0.000009490000000','0.072219258149748','0.071391745816782','7522.8393905987505','7522.839390598750470','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','KEYETH','4h','0.000009560000000','0.000009510000000','0.072219258149748','0.071841542364446','7554.315706040586','7554.315706040585610','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','KEYETH','4h','0.000009610000000','0.000009290000000','0.072219258149748','0.069814454548508','7515.011253875963','7515.011253875963121','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','KEYETH','4h','0.000011360000000','0.000010050000000','0.072219258149748','0.063891157077902','6357.329062477817','6357.329062477817388','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','KEYETH','4h','0.000009580000000','0.000009390000000','0.072219258149748','0.070786934658260','7538.544692040501','7538.544692040501104','test'),('2019-08-09 11:59:59','2019-08-09 15:59:59','KEYETH','4h','0.000008970000000','0.000009010000000','0.072219258149748','0.072541306123660','8051.199347797993','8051.199347797993141','test'),('2019-08-11 07:59:59','2019-08-11 11:59:59','KEYETH','4h','0.000008920000000','0.000008780000000','0.072219258149748','0.071085772035290','8096.329388985202','8096.329388985202058','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','KEYETH','4h','0.000008750000000','0.000008630000000','0.072219258149748','0.071228822609409','8253.629502828344','8253.629502828343902','test'),('2019-08-13 03:59:59','2019-08-13 07:59:59','KEYETH','4h','0.000008830000000','0.000008530000000','0.072219258149748','0.069765602719972','8178.851432587542','8178.851432587542149','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','KEYETH','4h','0.000008710000000','0.000008710000000','0.072219258149748','0.072219258149748','8291.533656687487','8291.533656687486655','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','KEYETH','4h','0.000008370000000','0.000008330000000','0.072219258149748','0.071874124299570','8628.34625445018','8628.346254450179913','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','KEYETH','4h','0.000008280000000','0.000008110000000','0.072219258149748','0.070736495603195','8722.132626781158','8722.132626781158251','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','KEYETH','4h','0.000008200000000','0.000008690000000','0.072219258149748','0.076534799185526','8807.226603627805','8807.226603627805162','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','KEYETH','4h','0.000008630000000','0.000008570000000','0.072219258149748','0.071717154385092','8368.396077606953','8368.396077606952531','test'),('2019-09-09 19:59:59','2019-09-10 03:59:59','KEYETH','4h','0.000008420000000','0.000008270000000','0.072219258149748','0.070932691793161','8577.109043913064','8577.109043913063942','test'),('2019-09-18 07:59:59','2019-09-18 11:59:59','KEYETH','4h','0.000008120000000','0.000008000000000','0.072219258149748','0.071151978472658','8893.997309082266','8893.997309082265929','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','KEYETH','4h','0.000007600000000','0.000007440000000','0.072219258149748','0.070698852715016','9502.533967072106','9502.533967072105952','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','KEYETH','4h','0.000007480000000','0.000007290000000','0.072219258149748','0.070384811752896','9654.981036062567','9654.981036062567000','test'),('2019-09-25 03:59:59','2019-09-25 07:59:59','KEYETH','4h','0.000007430000000','0.000007340000000','0.072219258149748','0.071344462290599','9719.953990544818','9719.953990544818225','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','KEYETH','4h','0.000007540000000','0.000007300000000','0.072219258149748','0.069920501922170','9578.15094824244','9578.150948242440791','test'),('2019-10-01 11:59:59','2019-10-01 19:59:59','KEYETH','4h','0.000007330000000','0.000007160000000','0.072219258149748','0.070544323103983','9852.55909273506','9852.559092735060403','test'),('2019-10-03 15:59:59','2019-10-03 23:59:59','KEYETH','4h','0.000007380000000','0.000007250000000','0.072219258149748','0.070947103195891','9785.807337364227','9785.807337364227351','test'),('2019-10-19 03:59:59','2019-10-23 15:59:59','KEYETH','4h','0.000008090000000','0.000008060000000','0.072219258149748','0.071951448787017','8926.978757694436','8926.978757694436354','test'),('2019-11-01 03:59:59','2019-11-01 11:59:59','KEYETH','4h','0.000007630000000','0.000007680000000','0.072219258149748','0.072692516722158','9465.171448197641','9465.171448197641439','test'),('2019-11-02 23:59:59','2019-11-03 19:59:59','KEYETH','4h','0.000007610000000','0.000007640000000','0.072219258149748','0.072503959561639','9490.047063041788','9490.047063041787624','test'),('2019-11-07 03:59:59','2019-11-07 19:59:59','KEYETH','4h','0.000008120000000','0.000010460000000','0.072219258149748','0.093031211853000','8893.997309082266','8893.997309082265929','test'),('2019-11-15 07:59:59','2019-11-16 07:59:59','KEYETH','4h','0.000009740000000','0.000009470000000','0.072219258149748','0.070217286927938','7414.708228926899','7414.708228926899210','test'),('2019-11-18 19:59:59','2019-11-19 07:59:59','KEYETH','4h','0.000009100000000','0.000008820000000','0.072219258149748','0.069997127129756','7936.182214258022','7936.182214258022213','test'),('2019-11-20 07:59:59','2019-11-22 11:59:59','KEYETH','4h','0.000009330000000','0.000015100000000','0.072219258149748','0.116882186287373','7740.542138236656','7740.542138236655774','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','KEYETH','4h','0.000013920000000','0.000014000000000','0.076070887522782','0.076508076531534','5464.8626093952225','5464.862609395222535','test'),('2019-12-08 15:59:59','2019-12-08 19:59:59','KEYETH','4h','0.000014550000000','0.000014110000000','0.076180184774970','0.073876454101363','5235.75153092574','5235.751530925739644','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:42:15
