-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 07:59:59','2019-01-18 19:59:59','NULSUSDT','4h','0.404200000000000','0.395400000000000','15.000000000000000','14.673428995546757','37.11034141514102','37.110341415141022','test'),('2019-01-22 15:59:59','2019-01-22 23:59:59','NULSUSDT','4h','0.405000000000000','0.400800000000000','15.000000000000000','14.844444444444443','37.03703703703704','37.037037037037038','test'),('2019-01-24 11:59:59','2019-01-27 15:59:59','NULSUSDT','4h','0.399600000000000','0.432300000000000','15.000000000000000','16.227477477477478','37.53753753753754','37.537537537537538','test'),('2019-02-08 19:59:59','2019-02-08 23:59:59','NULSUSDT','4h','0.403000000000000','0.397700000000000','15.186337729367169','14.986616662454896','37.683220172126966','37.683220172126966','test'),('2019-02-12 19:59:59','2019-02-13 15:59:59','NULSUSDT','4h','0.404200000000000','0.400000000000000','15.186337729367169','15.028538079532083','37.57134519883021','37.571345198830208','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','NULSUSDT','4h','0.426100000000000','0.423800000000000','15.186337729367169','15.104365007523603','35.64031384502974','35.640313845029738','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','NULSUSDT','4h','0.423500000000000','0.421900000000000','15.186337729367169','15.128963135820564','35.8591209666285','35.859120966628502','test'),('2019-03-05 03:59:59','2019-03-08 23:59:59','NULSUSDT','4h','0.424800000000000','0.429000000000000','15.186337729367169','15.336485136295941','35.74938260208844','35.749382602088438','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','NULSUSDT','4h','0.887700000000000','0.874400000000000','15.186337729367169','14.958807829850908','17.107511241824003','17.107511241824003','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','NULSUSDT','4h','0.851100000000000','0.882800000000000','15.186337729367169','15.751966804706072','17.843188496495323','17.843188496495323','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','NULSUSDT','4h','0.869400000000000','0.853600000000000','15.186337729367169','14.910349535067652','17.467607234146733','17.467607234146733','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','NULSUSDT','4h','0.863900000000000','0.866700000000000','15.186337729367169','15.235558409587368','17.578814364356024','17.578814364356024','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','NULSUSDT','4h','0.877400000000000','0.863000000000000','15.186337729367169','14.937097629865361','17.308340243181185','17.308340243181185','test'),('2019-04-23 03:59:59','2019-04-23 07:59:59','NULSUSDT','4h','0.864600000000000','0.907900000000000','15.186337729367169','15.946884136586227','17.564582152865103','17.564582152865103','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','NULSUSDT','4h','0.696400000000000','0.651000000000000','15.255317065430123','14.260786056282324','21.905969364488975','21.905969364488975','test'),('2019-05-14 07:59:59','2019-05-14 11:59:59','NULSUSDT','4h','0.701100000000000','0.676700000000000','15.255317065430123','14.724394605871581','21.759117195022284','21.759117195022284','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','NULSUSDT','4h','0.713400000000000','0.698700000000000','15.255317065430123','14.940972853400654','21.383960002004656','21.383960002004656','test'),('2019-05-19 03:59:59','2019-05-19 15:59:59','NULSUSDT','4h','0.706400000000000','0.704000000000000','15.255317065430123','15.203486996125150','21.595862210405045','21.595862210405045','test'),('2019-05-21 03:59:59','2019-05-22 23:59:59','NULSUSDT','4h','0.714400000000000','0.712300000000000','15.255317065430123','15.210473608210915','21.354027247242612','21.354027247242612','test'),('2019-05-23 15:59:59','2019-05-29 07:59:59','NULSUSDT','4h','0.723100000000000','0.761000000000000','15.255317065430123','16.054897367988278','21.097105608394585','21.097105608394585','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','NULSUSDT','4h','0.761300000000000','0.772100000000000','15.255317065430123','15.471732964952842','20.038509215066497','20.038509215066497','test'),('2019-06-05 15:59:59','2019-06-05 23:59:59','NULSUSDT','4h','0.770000000000000','0.765500000000000','15.255317065430123','15.166162615047739','19.812100084974187','19.812100084974187','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','NULSUSDT','4h','0.772200000000000','0.833800000000000','15.255317065430123','16.472265435321987','19.755655355387365','19.755655355387365','test'),('2019-06-22 19:59:59','2019-06-22 23:59:59','NULSUSDT','4h','0.967500000000000','0.968100000000000','15.307146794012713','15.316639598226054','15.821340355568696','15.821340355568696','test'),('2019-06-24 07:59:59','2019-06-24 11:59:59','NULSUSDT','4h','0.975700000000000','0.951900000000000','15.309519995066049','14.936078798097132','15.690806595332631','15.690806595332631','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','NULSUSDT','4h','0.966900000000000','0.959700000000000','15.309519995066049','15.195517984553613','15.833612571171837','15.833612571171837','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','NULSUSDT','4h','0.913700000000000','0.848800000000000','15.309519995066049','14.222086649679394','16.75552150056479','16.755521500564790','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','NULSUSDT','4h','0.894900000000000','0.928600000000000','15.309519995066049','15.886043432135805','17.10752038782663','17.107520387826629','test'),('2019-07-05 11:59:59','2019-07-08 11:59:59','NULSUSDT','4h','0.914000000000000','0.903400000000000','15.309519995066049','15.131969763175785','16.750021876439877','16.750021876439877','test'),('2019-08-04 15:59:59','2019-08-05 03:59:59','NULSUSDT','4h','0.554000000000000','0.543900000000000','15.309519995066049','15.030411417538671','27.63451262647301','27.634512626473011','test'),('2019-08-17 07:59:59','2019-08-18 23:59:59','NULSUSDT','4h','0.453900000000000','0.448900000000000','15.309519995066049','15.140875800363846','33.72883894044073','33.728838940440731','test'),('2019-08-19 15:59:59','2019-08-19 23:59:59','NULSUSDT','4h','0.451600000000000','0.452300000000000','15.309519995066049','15.333250429070802','33.9006200067893','33.900620006789303','test'),('2019-08-23 07:59:59','2019-08-23 11:59:59','NULSUSDT','4h','0.441700000000000','0.442400000000000','15.309519995066049','15.333782308845871','34.66044825688488','34.660448256884877','test'),('2019-08-24 19:59:59','2019-08-25 15:59:59','NULSUSDT','4h','0.514400000000000','0.495200000000000','15.309519995066049','14.738091566012262','29.761897346551418','29.761897346551418','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','NULSUSDT','4h','0.468400000000000','0.440600000000000','15.309519995066049','14.400884948390480','32.6847139091931','32.684713909193100','test'),('2019-09-09 07:59:59','2019-09-10 15:59:59','NULSUSDT','4h','0.443600000000000','0.437700000000000','15.309519995066049','15.105899237692537','34.511992775171436','34.511992775171436','test'),('2019-09-17 03:59:59','2019-09-17 07:59:59','NULSUSDT','4h','0.427700000000000','0.421500000000000','15.309519995066049','15.087591016881785','35.794996481332824','35.794996481332824','test'),('2019-09-19 19:59:59','2019-09-19 23:59:59','NULSUSDT','4h','0.435500000000000','0.433500000000000','15.309519995066049','15.239212210932566','35.15389206674179','35.153892066741790','test'),('2019-10-01 03:59:59','2019-10-01 07:59:59','NULSUSDT','4h','0.367800000000000','0.370400000000000','15.309519995066049','15.417743899326984','41.6245785618979','41.624578561897899','test'),('2019-10-02 23:59:59','2019-10-03 03:59:59','NULSUSDT','4h','0.369800000000000','0.376500000000000','15.309519995066049','15.586896371396344','41.39945915377515','41.399459153775148','test'),('2019-10-03 23:59:59','2019-10-04 03:59:59','NULSUSDT','4h','0.369700000000000','0.364100000000000','15.309519995066049','15.077620314318498','41.41065727634852','41.410657276348523','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','NULSUSDT','4h','0.371700000000000','0.380800000000000','15.309519995066049','15.684329335811546','41.187839642362256','41.187839642362256','test'),('2019-10-07 19:59:59','2019-10-08 07:59:59','NULSUSDT','4h','0.372500000000000','0.370700000000000','15.309519995066049','15.235541106499285','41.099382537090065','41.099382537090065','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','NULSUSDT','4h','0.329100000000000','0.316000000000000','15.309519995066049','14.700116434034856','46.51935580390778','46.519355803907779','test'),('2019-10-26 07:59:59','2019-10-26 11:59:59','NULSUSDT','4h','0.332400000000000','0.322900000000000','15.309519995066049','14.871973545146895','46.05752104412169','46.057521044121692','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','NULSUSDT','4h','0.327000000000000','0.317300000000000','15.309519995066049','14.855384386649717','46.81810396044663','46.818103960446628','test'),('2019-10-27 15:59:59','2019-10-27 19:59:59','NULSUSDT','4h','0.375800000000000','0.368900000000000','15.309519995066049','15.028424497551532','40.73847790065473','40.738477900654729','test'),('2019-11-10 03:59:59','2019-11-10 11:59:59','NULSUSDT','4h','0.414600000000000','0.405900000000000','15.309519995066049','14.988263786775949','36.92600095288483','36.926000952884827','test'),('2019-11-12 07:59:59','2019-11-12 15:59:59','NULSUSDT','4h','0.421900000000000','0.401700000000000','15.309519995066049','14.576520933913324','36.28708223528336','36.287082235283357','test'),('2019-12-08 19:59:59','2019-12-09 03:59:59','NULSUSDT','4h','0.304100000000000','0.302000000000000','15.309519995066049','15.203798219368453','50.34370271314058','50.343702713140580','test'),('2019-12-27 11:59:59','2019-12-28 15:59:59','NULSUSDT','4h','0.253900000000000','0.252100000000000','15.309519995066049','15.200984603214458','60.297439917550406','60.297439917550406','test'),('2019-12-29 19:59:59','2019-12-29 23:59:59','NULSUSDT','4h','0.251200000000000','0.246300000000000','15.309519995066049','15.010886842296051','60.94554138163237','60.945541381632367','test'),('2020-01-06 11:59:59','2020-01-06 11:59:59','NULSUSDT','4h','0.239200000000000','0.239200000000000','15.309519995066049','15.309519995066049','64.00301001281794','64.003010012817938','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:42:59
