-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 07:59:59','2018-03-19 11:59:59','KNCETH','4h','0.002049200000000','0.001929900000000','0.072144500000000','0.067944402962132','35.206178020691','35.206178020690999','test'),('2018-04-02 11:59:59','2018-04-03 03:59:59','KNCETH','4h','0.002529900000000','0.002548800000000','0.072144500000000','0.072683466382070','28.516739792086646','28.516739792086646','test'),('2018-04-07 11:59:59','2018-04-07 15:59:59','KNCETH','4h','0.002491000000000','0.002538000000000','0.072144500000000','0.073505716981132','28.96206342834203','28.962063428342031','test'),('2018-04-09 23:59:59','2018-04-10 03:59:59','KNCETH','4h','0.002488600000000','0.002481000000000','0.072144500000000','0.071924176042755','28.98999437434702','28.989994374347020','test'),('2018-04-10 11:59:59','2018-04-10 15:59:59','KNCETH','4h','0.002499400000000','0.002457600000000','0.072144500000000','0.070937954389053','28.864727534608303','28.864727534608303','test'),('2018-04-10 19:59:59','2018-04-10 23:59:59','KNCETH','4h','0.002522400000000','0.002495500000000','0.072144500000000','0.071375118835236','28.60153028861402','28.601530288614018','test'),('2018-04-22 03:59:59','2018-04-22 07:59:59','KNCETH','4h','0.002685900000000','0.002618700000000','0.072144500000000','0.070339477326036','26.86045645779813','26.860456457798129','test'),('2018-04-22 15:59:59','2018-04-22 19:59:59','KNCETH','4h','0.002700000000000','0.002638000000000','0.072144500000000','0.070487848518519','26.720185185185183','26.720185185185183','test'),('2018-04-22 23:59:59','2018-04-23 03:59:59','KNCETH','4h','0.002737300000000','0.002748200000000','0.072144500000000','0.072431781280824','26.356080809556865','26.356080809556865','test'),('2018-05-10 07:59:59','2018-05-10 11:59:59','KNCETH','4h','0.003516700000000','0.003277900000000','0.072144500000000','0.067245558776694','20.514829243324705','20.514829243324705','test'),('2018-05-13 03:59:59','2018-05-13 07:59:59','KNCETH','4h','0.003239800000000','0.003153200000000','0.072144500000000','0.070216074263843','22.26819556762763','22.268195567627629','test'),('2018-06-01 11:59:59','2018-06-04 07:59:59','KNCETH','4h','0.002441900000000','0.002401800000000','0.072144500000000','0.070959769073263','29.544412138089193','29.544412138089193','test'),('2018-06-04 19:59:59','2018-06-04 23:59:59','KNCETH','4h','0.002471400000000','0.002445200000000','0.072144500000000','0.071379676054058','29.191753661892047','29.191753661892047','test'),('2018-06-25 19:59:59','2018-06-26 01:59:59','KNCETH','4h','0.001943100000000','0.001920700000000','0.072144500000000','0.071312820312902','37.1285574597293','37.128557459729301','test'),('2018-06-28 03:59:59','2018-06-28 07:59:59','KNCETH','4h','0.001907100000000','0.001852400000000','0.072144500000000','0.070075230349746','37.82942687850664','37.829426878506638','test'),('2018-06-30 11:59:59','2018-06-30 15:59:59','KNCETH','4h','0.001955100000000','0.001926800000000','0.072144500000000','0.071100211037799','36.90067004245307','36.900670042453072','test'),('2018-07-01 19:59:59','2018-07-04 00:22:25','KNCETH','4h','0.001897100000000','0.001927700000000','0.072144500000000','0.073308182304570','38.02883348268409','38.028833482684092','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','KNCETH','4h','0.002059800000000','0.002035000000000','0.072144500000000','0.071275879939800','35.025002427420134','35.025002427420134','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','KNCETH','4h','0.002011500000000','0.002058800000000','0.072144500000000','0.073840962764106','35.86602038279891','35.866020382798908','test'),('2018-07-16 23:59:59','2018-07-17 03:59:59','KNCETH','4h','0.002028300000000','0.001993100000000','0.072144500000000','0.070892472982300','35.56894936646453','35.568949366464530','test'),('2018-07-17 07:59:59','2018-07-17 11:59:59','KNCETH','4h','0.002017500000000','0.002017100000000','0.072144500000000','0.072130196257745','35.75935563816604','35.759355638166042','test'),('2018-07-17 19:59:59','2018-07-17 23:59:59','KNCETH','4h','0.002010600000000','0.002012300000000','0.072144500000000','0.072205499527504','35.88207500248682','35.882075002486822','test'),('2018-07-23 03:59:59','2018-07-23 07:59:59','KNCETH','4h','0.002083500000000','0.002074500000000','0.072144500000000','0.071832860691145','34.62658987281018','34.626589872810179','test'),('2018-08-17 15:59:59','2018-08-18 03:59:59','KNCETH','4h','0.001569900000000','0.001568200000000','0.072144500000000','0.072066376775591','45.95483788776355','45.954837887763553','test'),('2018-08-19 19:59:59','2018-08-19 23:59:59','KNCETH','4h','0.001571000000000','0.001575500000000','0.072144500000000','0.072351151973265','45.922660725652456','45.922660725652456','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','KNCETH','4h','0.001596100000000','0.001572600000000','0.072144500000000','0.071082288515757','45.20048869118476','45.200488691184759','test'),('2018-09-05 11:59:59','2018-09-05 15:59:59','KNCETH','4h','0.001868000000000','0.001822800000000','0.072144500000000','0.070398819379015','38.62125267665953','38.621252676659530','test'),('2018-09-05 23:59:59','2018-09-06 03:59:59','KNCETH','4h','0.001868200000000','0.001840000000000','0.072144500000000','0.071055497270100','38.617118081575846','38.617118081575846','test'),('2018-09-06 11:59:59','2018-09-06 19:59:59','KNCETH','4h','0.001921800000000','0.001885400000000','0.072144500000000','0.070778041575606','37.5400666042252','37.540066604225203','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','KNCETH','4h','0.001860000000000','0.001842500000000','0.072144500000000','0.071465721102151','38.787365591397844','38.787365591397844','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','KNCETH','4h','0.001733100000000','0.001728000000000','0.072144500000000','0.071932200103860','41.6274306156598','41.627430615659797','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','KNCETH','4h','0.001727900000000','0.001706900000000','0.072144500000000','0.071267693182476','41.75270559638868','41.752705596388680','test'),('2018-10-02 15:59:59','2018-10-02 23:59:59','KNCETH','4h','0.001718500000000','0.001735800000000','0.072144500000000','0.072870772825138','41.981088158277565','41.981088158277565','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','KNCETH','4h','0.001710900000000','0.001721300000000','0.072144500000000','0.072583042755275','42.167572622596296','42.167572622596296','test'),('2018-10-06 03:59:59','2018-10-06 07:59:59','KNCETH','4h','0.001721200000000','0.001703100000000','0.072144500000000','0.071385834272601','41.9152335579828','41.915233557982802','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','KNCETH','4h','0.002174400000000','0.002177600000000','0.072144500000000','0.072250672921266','33.17903789551141','33.179037895511406','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','KNCETH','4h','0.002186600000000','0.002180900000000','0.072144500000000','0.071956434670264','32.99391749748468','32.993917497484681','test'),('2018-11-01 07:59:59','2018-11-01 11:59:59','KNCETH','4h','0.002179300000000','0.002183800000000','0.072144500000000','0.072293469967421','33.10443720460699','33.104437204606988','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','KNCETH','4h','0.001553700000000','0.001526300000000','0.072144500000000','0.070872208502285','46.433996266975605','46.433996266975605','test'),('2018-12-15 19:59:59','2018-12-15 23:59:59','KNCETH','4h','0.001515800000000','0.001462300000000','0.072144500000000','0.069598167535295','47.59499934028236','47.594999340282357','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','KNCETH','4h','0.001589000000000','0.001466600000000','0.072144500000000','0.066587239584644','45.402454373820014','45.402454373820014','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','KNCETH','4h','0.001468500000000','0.001447900000000','0.072144500000000','0.071132462751107','49.12802179094314','49.128021790943137','test'),('2019-01-11 11:59:59','2019-01-11 19:59:59','KNCETH','4h','0.001174500000000','0.001156500000000','0.072144500000000','0.071038837164751','61.42571306939123','61.425713069391229','test'),('2019-01-17 07:59:59','2019-01-17 11:59:59','KNCETH','4h','0.001143100000000','0.001128300000000','0.072144500000000','0.071210427215467','63.11302598197883','63.113025981978829','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','KNCETH','4h','0.001167300000000','0.001110100000000','0.072144500000000','0.068609277349439','61.80459179302664','61.804591793026638','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','KNCETH','4h','0.001145100000000','0.001133200000000','0.072144500000000','0.071394766745262','63.002794515762815','63.002794515762815','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','KNCETH','4h','0.001270400000000','0.001188900000000','0.072144500000000','0.067516212255982','56.78880667506297','56.788806675062972','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','KNCETH','4h','0.001114000000000','0.001099500000000','0.072144500000000','0.071205455789946','64.7616696588869','64.761669658886902','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','KNCETH','4h','0.001075700000000','0.001073000000000','0.072144500000000','0.071963417774472','67.06749093613462','67.067490936134618','test'),('2019-02-25 23:59:59','2019-03-02 07:59:59','KNCETH','4h','0.001072300000000','0.001377500000000','0.072144500000000','0.092678400401007','67.28014548167491','67.280145481674907','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:37:23
