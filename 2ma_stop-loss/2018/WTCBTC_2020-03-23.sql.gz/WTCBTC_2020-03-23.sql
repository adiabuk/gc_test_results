-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-15 19:59:59','2018-02-16 03:59:59','WTCBTC','4h','0.002753400000000','0.002661600000000','0.001467500000000','0.001418572673785','0.532977409747948','0.532977409747948','test'),('2018-02-16 15:59:59','2018-02-16 19:59:59','WTCBTC','4h','0.002729700000000','0.002657700000000','0.001467500000000','0.001428792449720','0.5376048650034803','0.537604865003480','test'),('2018-02-25 19:59:59','2018-02-25 23:59:59','WTCBTC','4h','0.002275100000000','0.002270900000000','0.001467500000000','0.001464790888313','0.6450265922377039','0.645026592237704','test'),('2018-03-06 15:59:59','2018-03-07 07:59:59','WTCBTC','4h','0.002166200000000','0.002110000000000','0.001467500000000','0.001429427107377','0.6774536053919306','0.677453605391931','test'),('2018-03-21 11:59:59','2018-03-21 15:59:59','WTCBTC','4h','0.001633600000000','0.001600000000000','0.001467500000000','0.001437316356513','0.898322722820764','0.898322722820764','test'),('2018-03-25 15:59:59','2018-03-26 15:59:59','WTCBTC','4h','0.001614400000000','0.001568400000000','0.001467500000000','0.001425685703667','0.9090064420218038','0.909006442021804','test'),('2018-03-26 23:59:59','2018-03-27 03:59:59','WTCBTC','4h','0.001621700000000','0.001562400000000','0.001467500000000','0.001413838564469','0.9049145957945366','0.904914595794537','test'),('2018-03-27 07:59:59','2018-03-29 07:59:59','WTCBTC','4h','0.001700100000000','0.001613100000000','0.001467500000000','0.001392402946885','0.8631845185577319','0.863184518557732','test'),('2018-04-11 11:59:59','2018-04-12 07:59:59','WTCBTC','4h','0.001410900000000','0.001382800000000','0.001467500000000','0.001438272733716','1.0401162378623574','1.040116237862357','test'),('2018-04-15 03:59:59','2018-04-15 07:59:59','WTCBTC','4h','0.001368300000000','0.001351300000000','0.001467500000000','0.001449267521742','1.0724987210407075','1.072498721040708','test'),('2018-04-17 11:59:59','2018-04-17 15:59:59','WTCBTC','4h','0.001451500000000','0.001396500000000','0.001467500000000','0.001411893730623','1.0110230795728556','1.011023079572856','test'),('2018-04-22 07:59:59','2018-04-22 11:59:59','WTCBTC','4h','0.001419300000000','0.001413300000000','0.001467500000000','0.001461296237582','1.0339604030155711','1.033960403015571','test'),('2018-04-25 15:59:59','2018-04-25 19:59:59','WTCBTC','4h','0.001463200000000','0.001430000000000','0.001467500000000','0.001434202433024','1.002938764352105','1.002938764352105','test'),('2018-04-26 03:59:59','2018-04-26 07:59:59','WTCBTC','4h','0.001469200000000','0.001473500000000','0.001467500000000','0.001471795024503','0.9988429077048735','0.998842907704873','test'),('2018-05-15 15:59:59','2018-05-15 19:59:59','WTCBTC','4h','0.001614600000000','0.001510000000000','0.001467500000000','0.001372429703951','0.9088938436764523','0.908893843676452','test'),('2018-05-21 11:59:59','2018-05-21 15:59:59','WTCBTC','4h','0.001555000000000','0.001512900000000','0.001467500000000','0.001427768971061','0.9437299035369775','0.943729903536977','test'),('2018-05-25 03:59:59','2018-05-25 07:59:59','WTCBTC','4h','0.001470300000000','0.001501100000000','0.001467500000000','0.001498241345304','0.9980956267428417','0.998095626742842','test'),('2018-05-26 07:59:59','2018-05-26 11:59:59','WTCBTC','4h','0.001470000000000','0.001461600000000','0.001467500000000','0.001459114285714','0.9982993197278912','0.998299319727891','test'),('2018-05-29 07:59:59','2018-05-30 15:59:59','WTCBTC','4h','0.001504200000000','0.001462200000000','0.001467500000000','0.001426524730754','0.975601648716926','0.975601648716926','test'),('2018-06-02 15:59:59','2018-06-02 19:59:59','WTCBTC','4h','0.001482800000000','0.001488100000000','0.001467500000000','0.001472745312921','0.9896816833018613','0.989681683301861','test'),('2018-06-05 03:59:59','2018-06-05 07:59:59','WTCBTC','4h','0.001528000000000','0.001496400000000','0.001467500000000','0.001437151178010','0.9604057591623036','0.960405759162304','test'),('2018-07-02 15:59:59','2018-07-03 03:59:59','WTCBTC','4h','0.001112700000000','0.001107100000000','0.001467500000000','0.001460114361463','1.3188640244450436','1.318864024445044','test'),('2018-07-05 03:59:59','2018-07-05 07:59:59','WTCBTC','4h','0.001097800000000','0.001099600000000','0.001467500000000','0.001469906175988','1.3367644379668429','1.336764437966843','test'),('2018-07-07 03:59:59','2018-07-07 07:59:59','WTCBTC','4h','0.001092300000000','0.001096300000000','0.001467500000000','0.001472873981507','1.3434953767280051','1.343495376728005','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','WTCBTC','4h','0.001084800000000','0.001078100000000','0.001467500000000','0.001458436347714','1.352783923303835','1.352783923303835','test'),('2018-07-11 11:59:59','2018-07-12 19:59:59','WTCBTC','4h','0.001094400000000','0.001038500000000','0.001467500000000','0.001392542717471','1.3409173976608189','1.340917397660819','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','WTCBTC','4h','0.001185600000000','0.001115900000000','0.001467500000000','0.001381227437584','1.2377699055330635','1.237769905533064','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','WTCBTC','4h','0.000440100000000','0.000440700000000','0.001467500000000','0.001469500681663','3.334469438763917','3.334469438763917','test'),('2018-08-19 03:59:59','2018-08-19 07:59:59','WTCBTC','4h','0.000450000000000','0.000433600000000','0.001467500000000','0.001414017777778','3.2611111111111115','3.261111111111112','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','WTCBTC','4h','0.000429900000000','0.000432900000000','0.001467500000000','0.001477740753664','3.4135845545475694','3.413584554547569','test'),('2018-08-21 19:59:59','2018-08-22 23:59:59','WTCBTC','4h','0.000441600000000','0.000447300000000','0.001467500000000','0.001486441915761','3.3231431159420293','3.323143115942029','test'),('2018-09-07 03:59:59','2018-09-07 07:59:59','WTCBTC','4h','0.000627900000000','0.000609300000000','0.001467500000000','0.001424028905877','2.3371555980251633','2.337155598025163','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','WTCBTC','4h','0.000539900000000','0.000528800000000','0.001467500000000','0.001437329135025','2.718095943693277','2.718095943693277','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','WTCBTC','4h','0.000445800000000','0.000446300000000','0.001467500000000','0.001469145917452','3.2918349035441903','3.291834903544190','test'),('2018-10-07 19:59:59','2018-10-08 03:59:59','WTCBTC','4h','0.000444000000000','0.000442100000000','0.001467500000000','0.001461220157658','3.30518018018018','3.305180180180180','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','WTCBTC','4h','0.000445400000000','0.000457400000000','0.001467500000000','0.001507037494387','3.2947911989223173','3.294791198922317','test'),('2018-10-20 15:59:59','2018-10-20 19:59:59','WTCBTC','4h','0.000452200000000','0.000449100000000','0.001467500000000','0.001457439739054','3.2452454666076958','3.245245466607696','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','WTCBTC','4h','0.000458000000000','0.000453700000000','0.001467500000000','0.001453722161572','3.2041484716157207','3.204148471615721','test'),('2018-11-05 07:59:59','2018-11-05 11:59:59','WTCBTC','4h','0.000506100000000','0.000501300000000','0.001467500000000','0.001453581802015','2.8996245801225053','2.899624580122505','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','WTCBTC','4h','0.000309700000000','0.000301200000000','0.001467500000000','0.001427223119148','4.738456570875041','4.738456570875041','test'),('2018-12-05 03:59:59','2018-12-05 07:59:59','WTCBTC','4h','0.000320500000000','0.000303700000000','0.001467500000000','0.001390576443058','4.5787831513260535','4.578783151326054','test'),('2018-12-14 11:59:59','2018-12-14 19:59:59','WTCBTC','4h','0.000286300000000','0.000278100000000','0.001467500000000','0.001425468913727','5.125742228431715','5.125742228431715','test'),('2018-12-15 23:59:59','2018-12-16 03:59:59','WTCBTC','4h','0.000282300000000','0.000282800000000','0.001467500000000','0.001470099185264','5.198370527807298','5.198370527807298','test'),('2018-12-17 23:59:59','2018-12-18 11:59:59','WTCBTC','4h','0.000282100000000','0.000281700000000','0.001467500000000','0.001465419177597','5.202056008507621','5.202056008507621','test'),('2018-12-30 07:59:59','2018-12-30 11:59:59','WTCBTC','4h','0.000312000000000','0.000307300000000','0.001467500000000','0.001445393429487','4.703525641025641','4.703525641025641','test'),('2019-01-03 07:59:59','2019-01-03 11:59:59','WTCBTC','4h','0.000298100000000','0.000297900000000','0.001467500000000','0.001466515431063','4.922844682992285','4.922844682992285','test'),('2019-01-04 23:59:59','2019-01-05 03:59:59','WTCBTC','4h','0.000297400000000','0.000297200000000','0.001467500000000','0.001466513113652','4.934431741761936','4.934431741761936','test'),('2019-01-05 11:59:59','2019-01-05 23:59:59','WTCBTC','4h','0.000296800000000','0.000295700000000','0.001467500000000','0.001462061152291','4.944407008086253','4.944407008086253','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','WTCBTC','4h','0.000310100000000','0.000305600000000','0.001467500000000','0.001446204450177','4.732344405030635','4.732344405030635','test'),('2019-01-14 03:59:59','2019-01-14 15:59:59','WTCBTC','4h','0.000303400000000','0.000303500000000','0.001467500000000','0.001467983684904','4.836849044166118','4.836849044166118','test'),('2019-01-19 07:59:59','2019-01-20 11:59:59','WTCBTC','4h','0.000316300000000','0.000313500000000','0.001467500000000','0.001454509168511','4.639582674675941','4.639582674675941','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','WTCBTC','4h','0.000316500000000','0.000315600000000','0.001467500000000','0.001463327014218','4.636650868878357','4.636650868878357','test'),('2019-01-22 23:59:59','2019-01-23 03:59:59','WTCBTC','4h','0.000317400000000','0.000315400000000','0.001467500000000','0.001458252993069','4.623503465658475','4.623503465658475','test'),('2019-01-25 11:59:59','2019-01-25 15:59:59','WTCBTC','4h','0.000313700000000','0.000311800000000','0.001467500000000','0.001458611730953','4.678036340452662','4.678036340452662','test'),('2019-01-25 23:59:59','2019-01-26 03:59:59','WTCBTC','4h','0.000313200000000','0.000309600000000','0.001467500000000','0.001450632183908','4.685504469987229','4.685504469987229','test'),('2019-02-09 15:59:59','2019-02-09 19:59:59','WTCBTC','4h','0.000281300000000','0.000277600000000','0.001467500000000','0.001448197653750','5.216850337717739','5.216850337717739','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','WTCBTC','4h','0.000279900000000','0.000278500000000','0.001467500000000','0.001460159878528','5.242943908538765','5.242943908538765','test'),('2019-02-11 07:59:59','2019-02-11 11:59:59','WTCBTC','4h','0.000280800000000','0.000279400000000','0.001467500000000','0.001460183404558','5.226139601139601','5.226139601139601','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:33:40
