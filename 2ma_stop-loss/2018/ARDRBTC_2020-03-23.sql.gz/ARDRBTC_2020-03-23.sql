-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 03:59:59','ARDRBTC','4h','0.000014110000000','0.000013970000000','0.001467500000000','0.001452939404678','104.00425230333097','104.004252303330972','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','ARDRBTC','4h','0.000014770000000','0.000015070000000','0.001467500000000','0.001497307041300','99.35680433310766','99.356804333107661','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','ARDRBTC','4h','0.000015280000000','0.000015060000000','0.001471311611494','0.001450127805569','96.29002693026833','96.290026930268326','test'),('2019-02-01 23:59:59','2019-02-02 11:59:59','ARDRBTC','4h','0.000015130000000','0.000015170000000','0.001471311611494','0.001475201397645','97.24465376695308','97.244653766953078','test'),('2019-02-03 15:59:59','2019-02-03 19:59:59','ARDRBTC','4h','0.000015080000000','0.000015030000000','0.001471311611494','0.001466433257344','97.56708299031831','97.567082990318312','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','ARDRBTC','4h','0.000015070000000','0.000015080000000','0.001471311611494','0.001472287929750','97.63182558022562','97.631825580225623','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','ARDRBTC','4h','0.000014830000000','0.000014770000000','0.001471311611494','0.001465358900996','99.21184163816588','99.211841638165879','test'),('2019-02-09 07:59:59','2019-02-09 15:59:59','ARDRBTC','4h','0.000015020000000','0.000014940000000','0.001471311611494','0.001463475064961','97.95683165739015','97.956831657390154','test'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ARDRBTC','4h','0.000014860000000','0.000014690000000','0.001471311611494','0.001454479648240','99.0115485527591','99.011548552759095','test'),('2019-02-11 11:59:59','2019-02-11 15:59:59','ARDRBTC','4h','0.000014820000000','0.000014550000000','0.001471311611494','0.001444506339220','99.27878620067476','99.278786200674759','test'),('2019-02-15 23:59:59','2019-02-16 03:59:59','ARDRBTC','4h','0.000014660000000','0.000014670000000','0.001471311611494','0.001472315234694','100.36232002005457','100.362320020054568','test'),('2019-02-16 11:59:59','2019-02-16 15:59:59','ARDRBTC','4h','0.000014720000000','0.000014830000000','0.001471311611494','0.001482306467286','99.95323447649457','99.953234476494572','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','ARDRBTC','4h','0.000015120000000','0.000015000000000','0.001471311611494','0.001459634535212','97.30896901415345','97.308969014153448','test'),('2019-02-20 11:59:59','2019-02-20 15:59:59','ARDRBTC','4h','0.000015010000000','0.000014730000000','0.001471311611494','0.001443865425537','98.02209270446369','98.022092704463688','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','ARDRBTC','4h','0.000014800000000','0.000014800000000','0.001471311611494','0.001471311611494','99.41294672256757','99.412946722567568','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','ARDRBTC','4h','0.000014710000000','0.000014670000000','0.001471311611494','0.001467310764148','100.02118365016996','100.021183650169959','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','ARDRBTC','4h','0.000014750000000','0.000014790000000','0.001471311611494','0.001475301609084','99.74993976230509','99.749939762305090','test'),('2019-03-10 19:59:59','2019-03-11 07:59:59','ARDRBTC','4h','0.000015200000000','0.000015110000000','0.001471311611494','0.001462599898005','96.7968165456579','96.796816545657904','test'),('2019-03-11 19:59:59','2019-03-12 15:59:59','ARDRBTC','4h','0.000015350000000','0.000017390000000','0.001471311611494','0.001666847486898','95.85091931557004','95.850919315570039','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','ARDRBTC','4h','0.000011160000000','0.000011270000000','0.001491578106666','0.001506280041409','133.65395221019264','133.653952210192642','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','ARDRBTC','4h','0.000010860000000','0.000010680000000','0.001495253590351','0.001470470381671','137.68449266588397','137.684492665883965','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','ARDRBTC','4h','0.000010420000000','0.000010310000000','0.001495253590351','0.001479468763581','143.49842517763915','143.498425177639149','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','ARDRBTC','4h','0.000010470000000','0.000010360000000','0.001495253590351','0.001479544144798','142.81314138978033','142.813141389780327','test'),('2019-05-28 03:59:59','2019-05-28 15:59:59','ARDRBTC','4h','0.000010370000000','0.000010260000000','0.001495253590351','0.001479392655449','144.1903172951784','144.190317295178403','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','ARDRBTC','4h','0.000010260000000','0.000010240000000','0.001495253590351','0.001492338866003','145.7362173831384','145.736217383138410','test'),('2019-05-30 03:59:59','2019-05-30 07:59:59','ARDRBTC','4h','0.000010230000000','0.000010110000000','0.001495253590351','0.001477713958793','146.16359631974584','146.163596319745835','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ARDRBTC','4h','0.000010200000000','0.000009900000000','0.001495253590351','0.001451275543576','146.59348925009803','146.593489250098031','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','ARDRBTC','4h','0.000010570000000','0.000010280000000','0.001495253590351','0.001454229603482','141.46202368505203','141.462023685052031','test'),('2019-06-18 11:59:59','2019-06-18 15:59:59','ARDRBTC','4h','0.000012300000000','0.000011990000000','0.001495253590351','0.001457568337261','121.56533254886179','121.565332548861790','test'),('2019-06-18 23:59:59','2019-06-20 23:59:59','ARDRBTC','4h','0.000012100000000','0.000012580000000','0.001495253590351','0.001554569435257','123.57467688851241','123.574676888512414','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','ARDRBTC','4h','0.000010480000000','0.000010160000000','0.001495253590351','0.001449596992172','142.67686930830155','142.676869308301548','test'),('2019-07-02 19:59:59','2019-07-02 23:59:59','ARDRBTC','4h','0.000010760000000','0.000011040000000','0.001495253590351','0.001534163535081','138.96408832258365','138.964088322583649','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','ARDRBTC','4h','0.000007390000000','0.000007310000000','0.001495253590351','0.001479066812648','202.3347212924222','202.334721292422188','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ARDRBTC','4h','0.000006940000000','0.000006780000000','0.001495253590351','0.001460780885098','215.4544078315562','215.454407831556210','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','ARDRBTC','4h','0.000006950000000','0.000006890000000','0.001495253590351','0.001482344926262','215.1444014893525','215.144401489352504','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ARDRBTC','4h','0.000007120000000','0.000007140000000','0.001495253590351','0.001499453740886','210.00752673469103','210.007526734691027','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','ARDRBTC','4h','0.000005500000000','0.000005370000000','0.001495253590351','0.001459911232761','271.8642891547273','271.864289154727317','test'),('2019-08-21 11:59:59','2019-08-21 15:59:59','ARDRBTC','4h','0.000005430000000','0.000005430000000','0.001495253590351','0.001495253590351','275.3689853316759','275.368985331675901','test'),('2019-09-08 15:59:59','2019-09-08 19:59:59','ARDRBTC','4h','0.000005540000000','0.000005480000000','0.001495253590351','0.001479059508145','269.90137009945846','269.901370099458461','test'),('2019-09-15 19:59:59','2019-09-17 11:59:59','ARDRBTC','4h','0.000005660000000','0.000005860000000','0.001495253590351','0.001548089406264','264.1790795673145','264.179079567314488','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','ARDRBTC','4h','0.000006310000000','0.000006250000000','0.001495253590351','0.001481035648129','236.96570370063392','236.965703700633924','test'),('2019-10-02 07:59:59','2019-10-09 15:59:59','ARDRBTC','4h','0.000006520000000','0.000006710000000','0.001495253590351','0.001538826931174','229.33337275322086','229.333372753220857','test'),('2019-10-09 23:59:59','2019-10-10 03:59:59','ARDRBTC','4h','0.000006800000000','0.000006780000000','0.001495253590351','0.001490855785673','219.89023387514706','219.890233875147061','test'),('2019-10-12 11:59:59','2019-10-12 15:59:59','ARDRBTC','4h','0.000006800000000','0.000006680000000','0.001495253590351','0.001468866762286','219.89023387514706','219.890233875147061','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','ARDRBTC','4h','0.000006480000000','0.000006490000000','0.001495253590351','0.001497561080460','230.7490108566358','230.749010856635806','test'),('2019-10-24 23:59:59','2019-10-25 03:59:59','ARDRBTC','4h','0.000006480000000','0.000006430000000','0.001495253590351','0.001483716139808','230.7490108566358','230.749010856635806','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','ARDRBTC','4h','0.000006130000000','0.000006100000000','0.001495253590351','0.001487935872943','243.92391359722677','243.923913597226772','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','ARDRBTC','4h','0.000006040000000','0.000006010000000','0.001495253590351','0.001487826834108','247.55854144884108','247.558541448841083','test'),('2019-11-03 15:59:59','2019-11-04 03:59:59','ARDRBTC','4h','0.000006240000000','0.000006170000000','0.001495253590351','0.001478479912254','239.62397281266024','239.623972812660242','test'),('2019-11-06 07:59:59','2019-11-06 11:59:59','ARDRBTC','4h','0.000006040000000','0.000006050000000','0.001495253590351','0.001497729175765','247.55854144884108','247.558541448841083','test'),('2019-11-09 07:59:59','2019-11-09 11:59:59','ARDRBTC','4h','0.000006040000000','0.000006010000000','0.001495253590351','0.001487826834108','247.55854144884108','247.558541448841083','test'),('2019-11-20 03:59:59','2019-11-20 11:59:59','ARDRBTC','4h','0.000006250000000','0.000006250000000','0.001495253590351','0.001495253590351','239.24057445616','239.240574456160005','test'),('2019-11-21 19:59:59','2019-11-21 23:59:59','ARDRBTC','4h','0.000006250000000','0.000006200000000','0.001495253590351','0.001483291561628','239.24057445616','239.240574456160005','test'),('2019-11-23 19:59:59','2019-11-24 03:59:59','ARDRBTC','4h','0.000006260000000','0.000006240000000','0.001495253590351','0.001490476422331','238.85840101453675','238.858401014536753','test'),('2019-11-26 07:59:59','2019-11-26 11:59:59','ARDRBTC','4h','0.000006270000000','0.000006230000000','0.001495253590351','0.001485714492486','238.47744662695376','238.477446626953764','test'),('2019-12-03 23:59:59','2019-12-04 07:59:59','ARDRBTC','4h','0.000006680000000','0.000006670000000','0.001495253590351','0.001493015186773','223.84035783697604','223.840357836976040','test'),('2019-12-16 03:59:59','2019-12-16 07:59:59','ARDRBTC','4h','0.000006370000000','0.000006340000000','0.001495253590351','0.001488211579721','234.73368765321823','234.733687653218226','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:03:46
