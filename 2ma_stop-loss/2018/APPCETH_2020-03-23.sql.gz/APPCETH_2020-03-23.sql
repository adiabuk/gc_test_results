-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 07:59:59','2018-06-30 11:59:59','APPCETH','4h','0.000384600000000','0.000376000000000','0.072144500000000','0.070531284451378','187.58320332813312','187.583203328133123','test'),('2018-06-30 15:59:59','2018-06-30 23:59:59','APPCETH','4h','0.000393100000000','0.000385700000000','0.072144500000000','0.070786399516662','183.5270923429153','183.527092342915296','test'),('2018-07-01 19:59:59','2018-07-04 23:59:59','APPCETH','4h','0.000384000000000','0.000502200000000','0.072144500000000','0.094351478906250','187.87630208333334','187.876302083333343','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','APPCETH','4h','0.000428400000000','0.000415300000000','0.076953415718573','0.074600265051175','179.629821938778','179.629821938778008','test'),('2018-07-08 15:59:59','2018-07-08 19:59:59','APPCETH','4h','0.000468300000000','0.000457900000000','0.076953415718573','0.075244435313975','164.32503890363657','164.325038903636568','test'),('2018-07-13 15:59:59','2018-07-13 23:59:59','APPCETH','4h','0.000441900000000','0.000431000000000','0.076953415718573','0.075055266292611','174.14214917079204','174.142149170792038','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','APPCETH','4h','0.000441600000000','0.000429700000000','0.076953415718573','0.074879716336664','174.26045226126132','174.260452261261321','test'),('2018-07-16 23:59:59','2018-07-17 03:59:59','APPCETH','4h','0.000435600000000','0.000432800000000','0.076953415718573','0.076458765663449','176.66073397284896','176.660733972848959','test'),('2018-07-17 15:59:59','2018-07-19 15:59:59','APPCETH','4h','0.000452000000000','0.000443600000000','0.076953415718573','0.075523307992830','170.25091973135622','170.250919731356220','test'),('2018-07-29 23:59:59','2018-07-30 03:59:59','APPCETH','4h','0.000403100000000','0.000390700000000','0.076953415718573','0.074586205708872','190.90403304036965','190.904033040369654','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','APPCETH','4h','0.000292600000000','0.000277200000000','0.076953415718573','0.072903235943911','262.99868666634654','262.998686666346543','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','APPCETH','4h','0.000289900000000','0.000285500000000','0.076953415718573','0.075785443903596','265.4481397674129','265.448139767412897','test'),('2018-09-06 19:59:59','2018-09-06 23:59:59','APPCETH','4h','0.000353200000000','0.000350600000000','0.076953415718573','0.076386940970928','217.87490294046717','217.874902940467166','test'),('2018-09-09 03:59:59','2018-09-09 07:59:59','APPCETH','4h','0.000351000000000','0.000348900000000','0.076953415718573','0.076493010667265','219.2405006227151','219.240500622715103','test'),('2018-09-15 03:59:59','2018-09-15 07:59:59','APPCETH','4h','0.000364800000000','0.000367400000000','0.076953415718573','0.077501877563058','210.94686326363214','210.946863263632139','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','APPCETH','4h','0.000369300000000','0.000359000000000','0.076953415718573','0.074807138486238','208.37643032378284','208.376430323782841','test'),('2018-09-22 19:59:59','2018-09-22 23:59:59','APPCETH','4h','0.000415000000000','0.000497900000000','0.076953415718573','0.092325555870548','185.4299173941518','185.429917394151801','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','APPCETH','4h','0.000494200000000','0.000487800000000','0.076953415718573','0.075956851856576','155.7131034370154','155.713103437015405','test'),('2018-10-14 03:59:59','2018-10-14 07:59:59','APPCETH','4h','0.000483000000000','0.000492000000000','0.076953415718573','0.078387330297180','159.32384206743893','159.323842067438932','test'),('2018-10-15 15:59:59','2018-10-18 15:59:59','APPCETH','4h','0.000499700000000','0.000496200000000','0.076953415718573','0.076414418410158','153.99923097573145','153.999230975731450','test'),('2018-10-27 11:59:59','2018-10-27 15:59:59','APPCETH','4h','0.000547900000000','0.000530400000000','0.076953415718573','0.074495513227106','140.45157094099835','140.451570940998351','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','APPCETH','4h','0.000416800000000','0.000393400000000','0.076953415718573','0.072633094394642','184.62911640732486','184.629116407324858','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','APPCETH','4h','0.000413700000000','0.000418300000000','0.076953415718573','0.077809073713027','186.0126074899033','186.012607489903303','test'),('2018-12-07 11:59:59','2018-12-07 15:59:59','APPCETH','4h','0.000439800000000','0.000440400000000','0.076953415718573','0.077058399914642','174.9736601149909','174.973660114990906','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','APPCETH','4h','0.000439200000000','0.000428900000000','0.076953415718573','0.075148724958324','175.21269516979282','175.212695169792823','test'),('2018-12-09 07:59:59','2018-12-09 11:59:59','APPCETH','4h','0.000435200000000','0.000438900000000','0.076953415718573','0.077607661210666','176.82310597098575','176.823105970985750','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','APPCETH','4h','0.000438000000000','0.000437900000000','0.076953415718573','0.076935846445578','175.6927299510799','175.692729951079912','test'),('2018-12-12 23:59:59','2018-12-13 07:59:59','APPCETH','4h','0.000436100000000','0.000429800000000','0.076953415718573','0.075841729135159','176.45818784355197','176.458187843551968','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','APPCETH','4h','0.000426200000000','0.000414600000000','0.076953415718573','0.074858953911122','180.55705236643126','180.557052366431265','test'),('2018-12-19 07:59:59','2018-12-19 19:59:59','APPCETH','4h','0.000428700000000','0.000426900000000','0.076953415718573','0.076630308304779','179.50411877437136','179.504118774371364','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','APPCETH','4h','0.000425600000000','0.000405500000000','0.076953415718573','0.073319102617202','180.81159708311327','180.811597083113270','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','APPCETH','4h','0.000330400000000','0.000331700000000','0.076953415718573','0.077256198528604','232.909853869773','232.909853869773002','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','APPCETH','4h','0.000320200000000','0.000316700000000','0.076953415718573','0.076112263454316','240.32921835906623','240.329218359066232','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','APPCETH','4h','0.000317600000000','0.000310200000000','0.076953415718573','0.075160420516062','242.29664898795025','242.296648987950249','test'),('2019-01-09 11:59:59','2019-01-09 15:59:59','APPCETH','4h','0.000317700000000','0.000310000000000','0.076953415718573','0.075088318768516','242.22038312424613','242.220383124246126','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','APPCETH','4h','0.000318700000000','0.000314900000000','0.076953415718573','0.076035866362657','241.4603568201224','241.460356820122399','test'),('2019-02-01 15:59:59','2019-02-01 23:59:59','APPCETH','4h','0.000401000000000','0.000390600000000','0.076953415718573','0.074957616408166','191.90377984681547','191.903779846815468','test'),('2019-02-11 15:59:59','2019-02-12 07:59:59','APPCETH','4h','0.000407400000000','0.000400500000000','0.076953415718573','0.075650080989908','188.88909111088122','188.889091110881225','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','APPCETH','4h','0.000433500000000','0.000414500000000','0.076953415718573','0.073580601650170','177.51652991597','177.516529915970011','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','APPCETH','4h','0.000408000000000','0.000409800000000','0.076953415718573','0.077292916082037','188.61131303571815','188.611313035718155','test'),('2019-03-12 11:59:59','2019-03-13 03:59:59','APPCETH','4h','0.000567600000000','0.000554600000000','0.076953415718573','0.075190916768007','135.57684235125618','135.576842351256175','test'),('2019-03-13 19:59:59','2019-03-13 23:59:59','APPCETH','4h','0.000556000000000','0.000558300000000','0.076953415718573','0.077271748193668','138.405423954268','138.405423954268002','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','APPCETH','4h','0.000583800000000','0.000568500000000','0.076953415718573','0.074936650969525','131.81468948025523','131.814689480255225','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','APPCETH','4h','0.000598900000000','0.000558800000000','0.076953415718573','0.071800916185571','128.49126017460847','128.491260174608470','test'),('2019-04-27 19:59:59','2019-04-27 23:59:59','APPCETH','4h','0.000441000000000','0.000424000000000','0.076953415718573','0.073986957516270','174.49754131195692','174.497541311956923','test'),('2019-04-28 11:59:59','2019-04-28 15:59:59','APPCETH','4h','0.000433600000000','0.000427000000000','0.076953415718573','0.075782076826178','177.47558975685655','177.475589756856550','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','APPCETH','4h','0.000437300000000','0.000406800000000','0.076953415718573','0.071586209728597','175.9739668844569','175.973966884456900','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','APPCETH','4h','0.000333300000000','0.000323200000000','0.076953415718573','0.074621494030131','230.88333548926792','230.883335489267921','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','APPCETH','4h','0.000356700000000','0.000344400000000','0.076953415718573','0.074299849659312','215.7370779887104','215.737077988710411','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','APPCETH','4h','0.000365200000000','0.000361200000000','0.076953415718573','0.076110552457690','210.71581522062706','210.715815220627064','test'),('2019-05-29 07:59:59','2019-05-30 03:59:59','APPCETH','4h','0.000358400000000','0.000349800000000','0.076953415718573','0.075106877283362','214.71377153619702','214.713771536197015','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','APPCETH','4h','0.000362100000000','0.000345400000000','0.076953415718573','0.073404335236661','212.51978933602044','212.519789336020438','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','APPCETH','4h','0.000359400000000','0.000355000000000','0.076953415718573','0.076011303784345','214.11634868829438','214.116348688294380','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','APPCETH','4h','0.000358000000000','0.000364400000000','0.076953415718573','0.078329119239799','214.95367519154473','214.953675191544733','test'),('2019-06-01 19:59:59','2019-06-02 07:59:59','APPCETH','4h','0.000367100000000','0.000359200000000','0.076953415718573','0.075297376535308','209.62521307156908','209.625213071569078','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','APPCETH','4h','0.000382100000000','0.000372700000000','0.076953415718573','0.075060293217252','201.39601077878305','201.396010778783051','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','APPCETH','4h','0.000370000000000','0.000365800000000','0.076953415718573','0.076079890459065','207.9822046447919','207.982204644791892','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','APPCETH','4h','0.000366100000000','0.000358000000000','0.076953415718573','0.075250813513382','210.19780311000548','210.197803110005481','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','APPCETH','4h','0.000372900000000','0.000368900000000','0.076953415718573','0.076127956713815','206.36475118952268','206.364751189522678','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','APPCETH','4h','0.000384700000000','0.000383800000000','0.076953415718573','0.076773384332696','200.03487319618662','200.034873196186624','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','APPCETH','4h','0.000368500000000','0.000378600000000','0.076953415718573','0.079062586678566','208.82880792014382','208.828807920143817','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:54:06
