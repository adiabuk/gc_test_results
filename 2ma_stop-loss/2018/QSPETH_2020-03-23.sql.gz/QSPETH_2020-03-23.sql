-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 23:59:59','2018-05-15 03:59:59','QSPETH','4h','0.000287620000000','0.000284000000000','0.072144500000000','0.071236485640776','250.83269591822545','250.832695918225454','test'),('2018-05-17 23:59:59','2018-05-18 03:59:59','QSPETH','4h','0.000287370000000','0.000284980000000','0.072144500000000','0.071544488325156','251.0509099766851','251.050909976685091','test'),('2018-05-23 23:59:59','2018-05-26 03:59:59','QSPETH','4h','0.000308390000000','0.000304490000000','0.072144500000000','0.071232137245047','233.9391679367035','233.939167936703512','test'),('2018-05-28 07:59:59','2018-05-29 03:59:59','QSPETH','4h','0.000302380000000','0.000296310000000','0.072144500000000','0.070696265609498','238.58886169720222','238.588861697202219','test'),('2018-05-29 11:59:59','2018-05-30 03:59:59','QSPETH','4h','0.000302700000000','0.000300940000000','0.072144500000000','0.071725027518996','238.33663693425837','238.336636934258365','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','QSPETH','4h','0.000303970000000','0.000298670000000','0.072144500000000','0.070886593463171','237.3408560055269','237.340856005526888','test'),('2018-06-30 23:59:59','2018-07-01 03:59:59','QSPETH','4h','0.000160000000000','0.000158350000000','0.072144500000000','0.071400509843750','450.903125','450.903124999999989','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','QSPETH','4h','0.000168580000000','0.000162550000000','0.072144500000000','0.069563936854906','427.954087080318','427.954087080318004','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','QSPETH','4h','0.000166530000000','0.000163390000000','0.072144500000000','0.070784182159371','433.2222422386357','433.222242238635715','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','QSPETH','4h','0.000158010000000','0.000154110000000','0.072144500000000','0.070363830738561','456.58186190747415','456.581861907474149','test'),('2018-07-17 19:59:59','2018-07-19 19:59:59','QSPETH','4h','0.000158320000000','0.000161120000000','0.072144500000000','0.073420425972713','455.6878473976756','455.687847397675625','test'),('2018-07-22 23:59:59','2018-07-23 07:59:59','QSPETH','4h','0.000155660000000','0.000153120000000','0.072144500000000','0.070967273801876','463.474881151227','463.474881151227009','test'),('2018-07-26 15:59:59','2018-07-26 19:59:59','QSPETH','4h','0.000154280000000','0.000152840000000','0.072144500000000','0.071471126393570','467.62056002074155','467.620560020741550','test'),('2018-08-13 23:59:59','2018-08-14 03:59:59','QSPETH','4h','0.000124750000000','0.000116540000000','0.072144500000000','0.067396553346693','578.312625250501','578.312625250501014','test'),('2018-08-16 23:59:59','2018-08-17 03:59:59','QSPETH','4h','0.000121330000000','0.000122210000000','0.072144500000000','0.072667760199456','594.6138630182147','594.613863018214715','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','QSPETH','4h','0.000124260000000','0.000122800000000','0.072144500000000','0.071296834057621','580.593111218413','580.593111218413014','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','QSPETH','4h','0.000151710000000','0.000145760000000','0.072144500000000','0.069315024190891','475.54215279151015','475.542152791510148','test'),('2018-09-06 19:59:59','2018-09-06 23:59:59','QSPETH','4h','0.000153300000000','0.000151350000000','0.072144500000000','0.071226810665362','470.60991519895623','470.609915198956230','test'),('2018-09-16 23:59:59','2018-09-17 07:59:59','QSPETH','4h','0.000150990000000','0.000143460000000','0.072144500000000','0.068546592290880','477.80978872773034','477.809788727730336','test'),('2018-09-17 15:59:59','2018-09-17 23:59:59','QSPETH','4h','0.000151050000000','0.000148860000000','0.072144500000000','0.071098512214499','477.6199933796756','477.619993379675577','test'),('2018-09-25 11:59:59','2018-09-29 11:59:59','QSPETH','4h','0.000152530000000','0.000156350000000','0.072144500000000','0.073951305153085','472.98564216875366','472.985642168753657','test'),('2018-10-02 07:59:59','2018-10-02 15:59:59','QSPETH','4h','0.000167780000000','0.000166000000000','0.072144500000000','0.071379109548218','429.994635832638','429.994635832637982','test'),('2018-10-12 19:59:59','2018-10-13 03:59:59','QSPETH','4h','0.000167280000000','0.000166390000000','0.072144500000000','0.071760660897896','431.2798900047824','431.279890004782374','test'),('2018-10-13 11:59:59','2018-10-13 15:59:59','QSPETH','4h','0.000167320000000','0.000170260000000','0.072144500000000','0.073412159753765','431.1767869949797','431.176786994979693','test'),('2018-10-28 15:59:59','2018-10-28 23:59:59','QSPETH','4h','0.000210810000000','0.000208330000000','0.072144500000000','0.071295781438262','342.22522650728143','342.225226507281434','test'),('2018-11-28 11:59:59','2018-11-28 23:59:59','QSPETH','4h','0.000157100000000','0.000159800000000','0.072144500000000','0.073384411839593','459.2266072565245','459.226607256524517','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','QSPETH','4h','0.000160200000000','0.000158220000000','0.072144500000000','0.071252826404494','450.34019975031214','450.340199750312138','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','QSPETH','4h','0.000158890000000','0.000151560000000','0.072144500000000','0.068816290641324','454.0531185096608','454.053118509660806','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','QSPETH','4h','0.000159000000000','0.000156910000000','0.072144500000000','0.071196185503145','453.73899371069183','453.738993710691830','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','QSPETH','4h','0.000159690000000','0.000155440000000','0.072144500000000','0.070224441605611','451.77844573861853','451.778445738618530','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','QSPETH','4h','0.000157790000000','0.000153520000000','0.072144500000000','0.070192177197541','457.2184549084226','457.218454908422586','test'),('2018-12-12 11:59:59','2018-12-12 15:59:59','QSPETH','4h','0.000156580000000','0.000153840000000','0.072144500000000','0.070882040362754','460.7516924255971','460.751692425597128','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','QSPETH','4h','0.000156500000000','0.000155890000000','0.072144500000000','0.071863297795527','460.9872204472843','460.987220447284301','test'),('2018-12-13 07:59:59','2018-12-13 11:59:59','QSPETH','4h','0.000155880000000','0.000151760000000','0.072144500000000','0.070237678470618','462.82075955863485','462.820759558634848','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','QSPETH','4h','0.000153170000000','0.000149970000000','0.072144500000000','0.070637270124698','471.00933603186','471.009336031860016','test'),('2018-12-18 03:59:59','2018-12-18 11:59:59','QSPETH','4h','0.000152300000000','0.000149920000000','0.072144500000000','0.071017094156271','473.6999343401182','473.699934340118205','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','QSPETH','4h','0.000151540000000','0.000151630000000','0.072144500000000','0.072187346806124','476.07562359773','476.075623597729987','test'),('2018-12-19 07:59:59','2018-12-19 11:59:59','QSPETH','4h','0.000153640000000','0.000152560000000','0.072144500000000','0.071637366050508','469.5684717521479','469.568471752147900','test'),('2018-12-19 23:59:59','2018-12-20 03:59:59','QSPETH','4h','0.000151920000000','0.000148880000000','0.072144500000000','0.070700850184308','474.8848077935756','474.884807793575590','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','QSPETH','4h','0.000110370000000','0.000109390000000','0.072144500000000','0.071503912793332','653.6604149678354','653.660414967835436','test'),('2019-01-11 03:59:59','2019-01-11 07:59:59','QSPETH','4h','0.000110230000000','0.000109520000000','0.072144500000000','0.071679811666515','654.4906105415948','654.490610541594833','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','QSPETH','4h','0.000136700000000','0.000132630000000','0.072144500000000','0.069996525493782','527.7578639356256','527.757863935625551','test'),('2019-02-02 03:59:59','2019-02-02 07:59:59','QSPETH','4h','0.000135640000000','0.000135730000000','0.072144500000000','0.072192369396933','531.8821881450899','531.882188145089913','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','QSPETH','4h','0.000133910000000','0.000132880000000','0.072144500000000','0.071589583750280','538.7536405048166','538.753640504816644','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','QSPETH','4h','0.000127450000000','0.000127400000000','0.072144500000000','0.072116196939976','566.0612004707729','566.061200470772860','test'),('2019-02-26 07:59:59','2019-03-15 23:59:59','QSPETH','4h','0.000113420000000','0.000141250000000','0.072144500000000','0.089846681581732','636.0827014635867','636.082701463586659','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','QSPETH','4h','0.000171910000000','0.000169920000000','0.072144500000000','0.071309367925077','419.66435925775113','419.664359257751130','test'),('2019-04-03 23:59:59','2019-04-06 19:59:59','QSPETH','4h','0.000171160000000','0.000176410000000','0.072144500000000','0.074357392176910','421.50327179247483','421.503271792474834','test'),('2019-04-13 15:59:59','2019-04-13 23:59:59','QSPETH','4h','0.000168460000000','0.000167630000000','0.072144500000000','0.071789045084887','428.25893387154224','428.258933871542240','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','QSPETH','4h','0.000177200000000','0.000173520000000','0.072144500000000','0.070646239503386','407.1360045146727','407.136004514672720','test'),('2019-04-16 19:59:59','2019-04-16 23:59:59','QSPETH','4h','0.000168260000000','0.000168200000000','0.072144500000000','0.072118773921312','428.767978129086','428.767978129085975','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','QSPETH','4h','0.000168670000000','0.000167470000000','0.072144500000000','0.071631229116025','427.72573664552084','427.725736645520840','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:52:21
