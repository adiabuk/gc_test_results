-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-15 19:59:59','XZCBNB','4h','3.012000000000000','3.035000000000000','0.711908500000000','0.717344720285525','0.2363574037184595','0.236357403718460','test'),('2018-05-16 15:59:59','2018-05-16 23:59:59','XZCBNB','4h','3.035000000000000','2.994000000000000','0.713267555071381','0.703631980192328','0.23501402144032332','0.235014021440323','test'),('2018-07-02 19:59:59','2018-07-07 11:59:59','XZCBNB','4h','1.153000000000000','1.174000000000000','0.713267555071381','0.726258551304251','0.6186188682319002','0.618618868231900','test'),('2018-07-17 19:59:59','2018-07-17 23:59:59','XZCBNB','4h','1.287000000000000','1.285000000000000','0.714106410409836','0.712996687938337','0.554861235749678','0.554861235749678','test'),('2018-08-07 15:59:59','2018-08-07 19:59:59','XZCBNB','4h','1.165000000000000','1.086000000000000','0.714106410409836','0.665682027214663','0.6129668758882713','0.612966875888271','test'),('2018-08-08 19:59:59','2018-08-08 23:59:59','XZCBNB','4h','1.143000000000000','1.098000000000000','0.714106410409836','0.685991984803150','0.6247650134819213','0.624765013481921','test'),('2018-08-12 03:59:59','2018-08-12 07:59:59','XZCBNB','4h','1.123000000000000','1.096000000000000','0.714106410409836','0.696937333757062','0.6358917278805307','0.635891727880531','test'),('2018-08-13 03:59:59','2018-08-16 15:59:59','XZCBNB','4h','1.083000000000000','1.356000000000000','0.714106410409836','0.894116613587939','0.6593780336194238','0.659378033619424','test'),('2018-08-24 03:59:59','2018-08-24 11:59:59','XZCBNB','4h','1.336000000000000','1.312000000000000','0.735404559222828','0.722193698877508','0.5504525143883445','0.550452514388345','test'),('2018-09-14 03:59:59','2018-09-14 07:59:59','XZCBNB','4h','1.140000000000000','1.062000000000000','0.735404559222828','0.685087405170740','0.6450917186165158','0.645091718616516','test'),('2018-09-27 23:59:59','2018-09-28 03:59:59','XZCBNB','4h','0.960000000000000','0.931000000000000','0.735404559222828','0.713189213162972','0.7660464158571125','0.766046415857113','test'),('2018-09-28 15:59:59','2018-10-02 23:59:59','XZCBNB','4h','0.991000000000000','0.960000000000000','0.735404559222828','0.712399976643708','0.7420833090038628','0.742083309003863','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','XZCBNB','4h','0.961000000000000','0.943000000000000','0.735404559222828','0.721630072161422','0.7652492811892071','0.765249281189207','test'),('2018-10-08 03:59:59','2018-10-08 07:59:59','XZCBNB','4h','0.967000000000000','0.950000000000000','0.735404559222828','0.722476040601537','0.7605010953700393','0.760501095370039','test'),('2018-10-08 19:59:59','2018-10-09 03:59:59','XZCBNB','4h','0.966000000000000','0.964000000000000','0.735404559222828','0.733881982495659','0.7612883635847081','0.761288363584708','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','XZCBNB','4h','1.000000000000000','0.989000000000000','0.735404559222828','0.727315109071377','0.735404559222828','0.735404559222828','test'),('2018-10-11 15:59:59','2018-10-12 15:59:59','XZCBNB','4h','0.973000000000000','0.956000000000000','0.735404559222828','0.722555764251823','0.7558114688826598','0.755811468882660','test'),('2018-10-13 07:59:59','2018-10-13 11:59:59','XZCBNB','4h','0.985000000000000','0.958000000000000','0.735404559222828','0.715246261660375','0.7466036134241909','0.746603613424191','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','XZCBNB','4h','0.965000000000000','0.956000000000000','0.735404559222828','0.728545863851838','0.7620772634433451','0.762077263443345','test'),('2018-10-16 15:59:59','2018-10-17 03:59:59','XZCBNB','4h','1.001000000000000','0.986000000000000','0.735404559222828','0.724384510882826','0.7346698893334945','0.734669889333495','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','XZCBNB','4h','0.989000000000000','0.980000000000000','0.735404559222828','0.728712303375502','0.7435839830362265','0.743583983036227','test'),('2018-10-24 15:59:59','2018-10-25 07:59:59','XZCBNB','4h','1.003000000000000','1.009000000000000','0.735404559222828','0.739803788889166','0.7332049443896591','0.733204944389659','test'),('2018-11-07 15:59:59','2018-11-07 23:59:59','XZCBNB','4h','1.070000000000000','1.085000000000000','0.735404559222828','0.745713968931559','0.6872939805820822','0.687293980582082','test'),('2018-11-09 19:59:59','2018-11-14 11:59:59','XZCBNB','4h','1.074000000000000','1.096000000000000','0.735404559222828','0.750468712205046','0.684734226464458','0.684734226464458','test'),('2018-11-17 23:59:59','2018-11-18 03:59:59','XZCBNB','4h','1.078000000000000','1.058000000000000','0.735404559222828','0.721760689849492','0.6821934686668163','0.682193468666816','test'),('2018-11-21 07:59:59','2018-11-21 19:59:59','XZCBNB','4h','1.091000000000000','1.072000000000000','0.735404559222828','0.722597330418764','0.6740646738981009','0.674064673898101','test'),('2018-11-24 03:59:59','2018-11-24 11:59:59','XZCBNB','4h','1.073000000000000','1.055000000000000','0.735404559222828','0.723067856458605','0.6853723757901473','0.685372375790147','test'),('2018-11-24 15:59:59','2018-11-24 19:59:59','XZCBNB','4h','1.078000000000000','1.060000000000000','0.735404559222828','0.723125076786825','0.6821934686668163','0.682193468666816','test'),('2018-11-25 03:59:59','2018-11-25 15:59:59','XZCBNB','4h','1.080000000000000','1.057000000000000','0.735404559222828','0.719743165831971','0.6809301474285444','0.680930147428544','test'),('2018-11-25 19:59:59','2018-11-25 23:59:59','XZCBNB','4h','1.068000000000000','1.053000000000000','0.735404559222828','0.725075843503406','0.6885810479614494','0.688581047961449','test'),('2018-11-27 11:59:59','2018-11-27 23:59:59','XZCBNB','4h','1.069000000000000','1.061000000000000','0.735404559222828','0.729901063924622','0.687936912275798','0.687936912275798','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','XZCBNB','4h','1.159000000000000','1.126000000000000','0.735404559222828','0.714465516552980','0.6345164445408352','0.634516444540835','test'),('2018-12-10 07:59:59','2018-12-10 11:59:59','XZCBNB','4h','1.157000000000000','1.111000000000000','0.735404559222828','0.706166348570926','0.6356132750413379','0.635613275041338','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','XZCBNB','4h','1.000000000000000','0.986000000000000','0.735404559222828','0.725108895393708','0.735404559222828','0.735404559222828','test'),('2018-12-21 19:59:59','2018-12-21 23:59:59','XZCBNB','4h','0.974000000000000','0.951000000000000','0.735404559222828','0.718038743142617','0.7550354817482834','0.755035481748283','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','XZCBNB','4h','0.983000000000000','0.956000000000000','0.735404559222828','0.715205247830136','0.7481226441737823','0.748122644173782','test'),('2018-12-24 07:59:59','2018-12-24 11:59:59','XZCBNB','4h','1.151000000000000','1.100000000000000','0.735404559222828','0.702819300734241','0.6389266370311277','0.638926637031128','test'),('2018-12-30 03:59:59','2018-12-30 07:59:59','XZCBNB','4h','0.994000000000000','0.969000000000000','0.735404559222828','0.716908468699115','0.7398436209485191','0.739843620948519','test'),('2019-01-03 07:59:59','2019-01-03 11:59:59','XZCBNB','4h','0.944000000000000','0.930000000000000','0.735404559222828','0.724498135675032','0.7790302534140128','0.779030253414013','test'),('2019-01-19 11:59:59','2019-01-19 19:59:59','XZCBNB','4h','0.851000000000000','0.830000000000000','0.735404559222828','0.717257090663863','0.8641651694745335','0.864165169474533','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','XZCBNB','4h','0.855000000000000','0.840000000000000','0.735404559222828','0.722502724850498','0.8601222914886877','0.860122291488688','test'),('2019-01-30 07:59:59','2019-01-30 19:59:59','XZCBNB','4h','0.770000000000000','0.785000000000000','0.735404559222828','0.749730622064831','0.9550708561335428','0.955070856133543','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','XZCBNB','4h','0.577000000000000','0.578000000000000','0.735404559222828','0.736679090521308','1.2745312984797712','1.274531298479771','test'),('2019-02-25 19:59:59','2019-02-27 15:59:59','XZCBNB','4h','0.553000000000000','0.547000000000000','0.735404559222828','0.727425486247535','1.3298454958821482','1.329845495882148','test'),('2019-03-12 15:59:59','2019-03-12 19:59:59','XZCBNB','4h','0.602000000000000','0.499000000000000','0.735404559222828','0.609579526664769','1.2216022578452292','1.221602257845229','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','XZCBNB','4h','0.452000000000000','0.455000000000000','0.735404559222828','0.740285562934484','1.627001237218646','1.627001237218646','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','XZCBNB','4h','0.440000000000000','0.442000000000000','0.735404559222828','0.738747307219295','1.6713739982337','1.671373998233700','test'),('2019-03-27 11:59:59','2019-03-28 07:59:59','XZCBNB','4h','0.434000000000000','0.435000000000000','0.735404559222828','0.737099039774033','1.6944805512046728','1.694480551204673','test'),('2019-03-29 07:59:59','2019-03-29 19:59:59','XZCBNB','4h','0.434000000000000','0.430000000000000','0.735404559222828','0.728626637018009','1.6944805512046728','1.694480551204673','test'),('2019-03-31 19:59:59','2019-03-31 23:59:59','XZCBNB','4h','0.437000000000000','0.473000000000000','0.735404559222828','0.795987085840727','1.682847961608302','1.682847961608302','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','XZCBNB','4h','0.435000000000000','0.426000000000000','0.735404559222828','0.720189292480287','1.6905851936156966','1.690585193615697','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','XZCBNB','4h','0.459000000000000','0.453000000000000','0.735404559222828','0.725791427729719','1.6021885821848103','1.602188582184810','test'),('2019-04-11 15:59:59','2019-04-11 23:59:59','XZCBNB','4h','0.459000000000000','0.454000000000000','0.735404559222828','0.727393616311904','1.6021885821848103','1.602188582184810','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','XZCBNB','4h','0.304000000000000','0.299000000000000','0.735404559222828','0.723309089498768','2.419093944811934','2.419093944811934','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:55:30
