-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 15:59:59','2018-08-17 19:59:59','POAETH','4h','0.000256980000000','0.000263720000000','0.072144500000000','0.074036685889953','280.7397462837575','280.739746283757484','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','POAETH','4h','0.000257830000000','0.000253180000000','0.072617546472488','0.071307878896577','281.64894105607664','281.648941056076637','test'),('2018-08-20 19:59:59','2018-08-20 23:59:59','POAETH','4h','0.000253640000000','0.000248500000000','0.072617546472488','0.071145956073227','286.30163409749247','286.301634097492467','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','POAETH','4h','0.000252360000000','0.000250480000000','0.072617546472488','0.072076569347079','287.7537901113013','287.753790111301328','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','POAETH','4h','0.000256450000000','0.000249300000000','0.072617546472488','0.070592920006205','283.16454073888866','283.164540738888661','test'),('2018-08-23 15:59:59','2018-08-24 11:59:59','POAETH','4h','0.000253510000000','0.000292120000000','0.072617546472488','0.083677321113736','286.44844965677095','286.448449656770947','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','POAETH','4h','0.000321480000000','0.000323340000000','0.074045774741084','0.074474184412038','230.3277800830044','230.327780083004399','test'),('2018-09-13 07:59:59','2018-09-13 11:59:59','POAETH','4h','0.000316910000000','0.000314980000000','0.074152877158823','0.073701281901758','233.98717982652096','233.987179826520958','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','POAETH','4h','0.000339000000000','0.000326530000000','0.074152877158823','0.071425188727642','218.74005061599706','218.740050615997063','test'),('2018-09-23 11:59:59','2018-09-24 03:59:59','POAETH','4h','0.000328540000000','0.000320060000000','0.074152877158823','0.072238905044904','225.70425871681684','225.704258716816838','test'),('2018-10-03 19:59:59','2018-10-03 23:59:59','POAETH','4h','0.000356500000000','0.000352500000000','0.074152877158823','0.073320867316929','208.00246047355682','208.002460473556823','test'),('2018-10-30 23:59:59','2018-10-31 11:59:59','POAETH','4h','0.000504550000000','0.000518110000000','0.074152877158823','0.076145767881791','146.96834240178973','146.968342401789727','test'),('2018-11-28 07:59:59','2018-11-29 11:59:59','POAETH','4h','0.000341800000000','0.000354840000000','0.074152877158823','0.076981881015321','216.94814850445582','216.948148504455816','test'),('2018-12-01 07:59:59','2018-12-02 07:59:59','POAETH','4h','0.000344860000000','0.000353440000000','0.074152877158823','0.075997775627833','215.0231315862176','215.023131586217602','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','POAETH','4h','0.000346260000000','0.000320050000000','0.074338259009927','0.068711256847823','214.68913247249753','214.689132472497533','test'),('2019-01-10 03:59:59','2019-01-10 11:59:59','POAETH','4h','0.000207470000000','0.000205060000000','0.074338259009927','0.073474735588642','358.3084735620909','358.308473562090910','test'),('2019-01-11 07:59:59','2019-01-11 11:59:59','POAETH','4h','0.000201320000000','0.000205400000000','0.074338259009927','0.075844816216168','369.2542172160093','369.254217216009295','test'),('2019-02-01 11:59:59','2019-02-01 23:59:59','POAETH','4h','0.000251000000000','0.000252510000000','0.074338259009927','0.074785473237437','296.1683625893506','296.168362589350579','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','POAETH','4h','0.000251220000000','0.000250640000000','0.074338259009927','0.074166631789858','295.90900011912663','295.909000119126631','test'),('2019-02-04 03:59:59','2019-02-04 15:59:59','POAETH','4h','0.000255230000000','0.000250000000000','0.074338259009927','0.072814969840856','291.2598793634251','291.259879363425114','test'),('2019-02-26 03:59:59','2019-02-27 15:59:59','POAETH','4h','0.000203470000000','0.000200170000000','0.074338259009927','0.073132595989665','365.3524303824986','365.352430382498596','test'),('2019-03-06 15:59:59','2019-03-16 07:59:59','POAETH','4h','0.000215540000000','0.000237990000000','0.074338259009927','0.082081109129500','344.89310109458563','344.893101094585631','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','POAETH','4h','0.000236160000000','0.000236390000000','0.074414638150060','0.074487111755982','315.10263444300585','315.102634443005854','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','POAETH','4h','0.000234910000000','0.000240500000000','0.074432756551541','0.076203984294605','316.8564835534492','316.856483553449209','test'),('2019-04-11 03:59:59','2019-04-11 11:59:59','POAETH','4h','0.000252010000000','0.000234830000000','0.074875563487307','0.069771154215009','297.1134617170222','297.113461717022176','test'),('2019-04-12 03:59:59','2019-04-12 07:59:59','POAETH','4h','0.000248440000000','0.000245620000000','0.074875563487307','0.074025663756852','301.38288314002176','301.382883140021761','test'),('2019-04-13 23:59:59','2019-04-16 15:59:59','POAETH','4h','0.000247520000000','0.000246180000000','0.074875563487307','0.074470209354013','302.5030845479436','302.503084547943615','test'),('2019-04-17 07:59:59','2019-04-18 03:59:59','POAETH','4h','0.000248410000000','0.000247160000000','0.074875563487307','0.074498789386590','301.4192805736766','301.419280573676588','test'),('2019-04-18 23:59:59','2019-04-19 03:59:59','POAETH','4h','0.000248390000000','0.000250090000000','0.074875563487307','0.075388017523011','301.4435504138935','301.443550413893490','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','POAETH','4h','0.000134520000000','0.000125510000000','0.074875563487307','0.069860481514213','556.612871597584','556.612871597583990','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','POAETH','4h','0.000139780000000','0.000133770000000','0.074875563487307','0.071656203517650','535.6672162491559','535.667216249155899','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','POAETH','4h','0.000135960000000','0.000127760000000','0.074875563487307','0.070359679252268','550.7175896389159','550.717589638915911','test'),('2019-05-26 23:59:59','2019-05-30 03:59:59','POAETH','4h','0.000154040000000','0.000143360000000','0.074875563487307','0.069684242933915','486.07870350108414','486.078703501084135','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','POAETH','4h','0.000140040000000','0.000138930000000','0.074875563487307','0.074282076801568','534.6726898550914','534.672689855091448','test'),('2019-06-08 23:59:59','2019-06-09 07:59:59','POAETH','4h','0.000142780000000','0.000139780000000','0.074875563487307','0.073302327106428','524.4121269597073','524.412126959707280','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','POAETH','4h','0.000141380000000','0.000139780000000','0.074875563487307','0.074028195390124','529.6050607391923','529.605060739192254','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','POAETH','4h','0.000157260000000','0.000152540000000','0.074875563487307','0.072628249105645','476.12592831811656','476.125928318116564','test'),('2019-06-16 11:59:59','2019-06-16 15:59:59','POAETH','4h','0.000142830000000','0.000135610000000','0.074875563487307','0.071090633371937','524.2285478352377','524.228547835237691','test'),('2019-06-19 23:59:59','2019-06-20 03:59:59','POAETH','4h','0.000140430000000','0.000137790000000','0.074875563487307','0.073467947681521','533.1878052218685','533.187805221868530','test'),('2019-06-24 19:59:59','2019-06-24 23:59:59','POAETH','4h','0.000134000000000','0.000129000000000','0.074875563487307','0.072081699178079','558.7728618455747','558.772861845574653','test'),('2019-06-25 11:59:59','2019-06-25 15:59:59','POAETH','4h','0.000130550000000','0.000124570000000','0.074875563487307','0.071445798112707','573.5393603010878','573.539360301087754','test'),('2019-07-22 15:59:59','2019-07-24 23:59:59','POAETH','4h','0.000096470000000','0.000096470000000','0.074875563487307','0.074875563487307','776.1538663554162','776.153866355416199','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','POAETH','4h','0.000097630000000','0.000096730000000','0.074875563487307','0.074185324758038','766.931921410499','766.931921410498944','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','POAETH','4h','0.000097750000000','0.000096750000000','0.074875563487307','0.074109573068000','765.9904193074885','765.990419307488537','test'),('2019-08-12 11:59:59','2019-08-12 15:59:59','POAETH','4h','0.000081430000000','0.000079730000000','0.074875563487307','0.073312399322645','919.5083321540834','919.508332154083405','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:20:47
