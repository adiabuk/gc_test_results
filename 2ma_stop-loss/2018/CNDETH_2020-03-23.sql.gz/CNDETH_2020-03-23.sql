-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-29 19:59:59','2018-05-29 23:59:59','CNDETH','4h','0.000109540000000','0.000108090000000','0.072144500000000','0.071189510726675','658.6132919481469','658.613291948146866','test'),('2018-05-30 15:59:59','2018-05-30 19:59:59','CNDETH','4h','0.000109410000000','0.000108620000000','0.072144500000000','0.071623577278128','659.3958504707065','659.395850470706478','test'),('2018-06-02 03:59:59','2018-06-02 07:59:59','CNDETH','4h','0.000109470000000','0.000109330000000','0.072144500000000','0.072052235178588','659.0344386589934','659.034438658993395','test'),('2018-06-02 15:59:59','2018-06-02 19:59:59','CNDETH','4h','0.000110710000000','0.000109300000000','0.072144500000000','0.071225669316232','651.652967211634','651.652967211633950','test'),('2018-07-01 23:59:59','2018-07-02 07:59:59','CNDETH','4h','0.000077370000000','0.000073690000000','0.072144500000000','0.068713043880057','932.4609021584594','932.460902158459362','test'),('2018-07-17 11:59:59','2018-07-19 19:59:59','CNDETH','4h','0.000068990000000','0.000069510000000','0.072144500000000','0.072688276489346','1045.7240179736193','1045.724017973619311','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','CNDETH','4h','0.000069830000000','0.000068330000000','0.072144500000000','0.070594782829729','1033.1447801804381','1033.144780180438147','test'),('2018-07-29 15:59:59','2018-07-29 19:59:59','CNDETH','4h','0.000067000000000','0.000065270000000','0.072144500000000','0.070281664402985','1076.7835820895523','1076.783582089552283','test'),('2018-08-07 03:59:59','2018-08-07 07:59:59','CNDETH','4h','0.000060000000000','0.000060000000000','0.072144500000000','0.072144500000000','1202.4083333333333','1202.408333333333303','test'),('2018-08-11 15:59:59','2018-08-11 23:59:59','CNDETH','4h','0.000059890000000','0.000057630000000','0.072144500000000','0.069422066037736','1204.6167974620137','1204.616797462013665','test'),('2018-08-14 23:59:59','2018-08-15 03:59:59','CNDETH','4h','0.000059140000000','0.000055250000000','0.072144500000000','0.067399114389584','1219.8934731146433','1219.893473114643257','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','CNDETH','4h','0.000057420000000','0.000059380000000','0.072144500000000','0.074607112678509','1256.4350400557296','1256.435040055729587','test'),('2018-08-20 15:59:59','2018-08-20 19:59:59','CNDETH','4h','0.000056750000000','0.000059500000000','0.072144500000000','0.075640488986784','1271.2687224669605','1271.268722466960526','test'),('2018-09-11 15:59:59','2018-09-11 19:59:59','CNDETH','4h','0.000071170000000','0.000070900000000','0.072144500000000','0.071870803006885','1013.6925670928763','1013.692567092876288','test'),('2018-09-24 23:59:59','2018-09-25 03:59:59','CNDETH','4h','0.000098950000000','0.000098130000000','0.072144500000000','0.071546637544214','729.1005558362809','729.100555836280932','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','CNDETH','4h','0.000102420000000','0.000099420000000','0.072144500000000','0.070031304335091','704.3985549697325','704.398554969732459','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','CNDETH','4h','0.000100650000000','0.000097600000000','0.072144500000000','0.069958303030303','716.7858917039246','716.785891703924563','test'),('2018-10-01 23:59:59','2018-10-02 03:59:59','CNDETH','4h','0.000101770000000','0.000096690000000','0.072144500000000','0.068543300628869','708.8975140021618','708.897514002161756','test'),('2018-10-03 03:59:59','2018-10-03 07:59:59','CNDETH','4h','0.000098500000000','0.000096930000000','0.072144500000000','0.070994582588832','732.4314720812183','732.431472081218317','test'),('2018-10-03 15:59:59','2018-10-03 19:59:59','CNDETH','4h','0.000097570000000','0.000096900000000','0.072144500000000','0.071649093471354','739.4127293225376','739.412729322537643','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','CNDETH','4h','0.000098190000000','0.000097290000000','0.072144500000000','0.071483230522456','734.7438639372646','734.743863937264564','test'),('2018-10-06 19:59:59','2018-10-07 03:59:59','CNDETH','4h','0.000098070000000','0.000100090000000','0.072144500000000','0.073630498674416','735.6429081268482','735.642908126848170','test'),('2018-10-09 23:59:59','2018-10-10 07:59:59','CNDETH','4h','0.000100000000000','0.000098160000000','0.072144500000000','0.070817041200000','721.4449999999999','721.444999999999936','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','CNDETH','4h','0.000099400000000','0.000100510000000','0.072144500000000','0.072950137776660','725.7997987927565','725.799798792756519','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','CNDETH','4h','0.000100730000000','0.000096460000000','0.072144500000000','0.069086255038221','716.2166186836096','716.216618683609568','test'),('2018-10-16 07:59:59','2018-10-16 11:59:59','CNDETH','4h','0.000100280000000','0.000105910000000','0.072144500000000','0.076194894246111','719.4305943358596','719.430594335859610','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','CNDETH','4h','0.000119900000000','0.000116110000000','0.072144500000000','0.069864035821518','601.7055879899916','601.705587989991614','test'),('2018-10-27 23:59:59','2018-10-28 03:59:59','CNDETH','4h','0.000120230000000','0.000123870000000','0.072144500000000','0.074328696789487','600.0540630458288','600.054063045828798','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','CNDETH','4h','0.000120950000000','0.000120360000000','0.072144500000000','0.071792575609756','596.4820173625465','596.482017362546458','test'),('2018-10-31 03:59:59','2018-11-04 07:59:59','CNDETH','4h','0.000122480000000','0.000123590000000','0.072144500000000','0.072798324257022','589.0308621815807','589.030862181580687','test'),('2018-11-09 19:59:59','2018-11-09 23:59:59','CNDETH','4h','0.000120280000000','0.000117680000000','0.072144500000000','0.070585007981377','599.8046225473895','599.804622547389499','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','CNDETH','4h','0.000107270000000','0.000105730000000','0.072144500000000','0.071108772117088','672.5505733196607','672.550573319660657','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','CNDETH','4h','0.000103670000000','0.000108280000000','0.072144500000000','0.075352623324009','695.9052763576734','695.905276357673415','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','CNDETH','4h','0.000107150000000','0.000104430000000','0.072144500000000','0.070313113719085','673.3037797480168','673.303779748016836','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','CNDETH','4h','0.000105870000000','0.000105180000000','0.072144500000000','0.071674303485407','681.4442240483612','681.444224048361207','test'),('2018-12-04 11:59:59','2018-12-04 15:59:59','CNDETH','4h','0.000106790000000','0.000109050000000','0.072144500000000','0.073671296235603','675.5735555763648','675.573555576364811','test'),('2018-12-05 23:59:59','2018-12-06 15:59:59','CNDETH','4h','0.000106780000000','0.000105850000000','0.072144500000000','0.071516157754261','675.6368233751639','675.636823375163885','test'),('2018-12-08 11:59:59','2018-12-08 23:59:59','CNDETH','4h','0.000108580000000','0.000106910000000','0.072144500000000','0.071034891278320','664.4363602873458','664.436360287345792','test'),('2018-12-09 07:59:59','2018-12-09 11:59:59','CNDETH','4h','0.000107070000000','0.000106810000000','0.072144500000000','0.071969310217615','673.8068553282899','673.806855328289885','test'),('2018-12-10 03:59:59','2018-12-10 07:59:59','CNDETH','4h','0.000108290000000','0.000106330000000','0.072144500000000','0.070838717194570','666.2157170560532','666.215717056053222','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','CNDETH','4h','0.000107190000000','0.000104850000000','0.072144500000000','0.070569557094878','673.0525235563019','673.052523556301935','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','CNDETH','4h','0.000107810000000','0.000101220000000','0.072144500000000','0.067734591318060','669.1818940729061','669.181894072906061','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','CNDETH','4h','0.000106380000000','0.000103570000000','0.072144500000000','0.070238821818011','678.1772889640911','678.177288964091076','test'),('2019-01-10 03:59:59','2019-01-16 19:59:59','CNDETH','4h','0.000072410000000','0.000092950000000','0.072144500000000','0.092609187612208','996.3333793674906','996.333379367490579','test'),('2019-01-27 03:59:59','2019-01-27 07:59:59','CNDETH','4h','0.000091990000000','0.000090880000000','0.072144500000000','0.071273966300685','784.2645939776062','784.264593977606182','test'),('2019-01-29 03:59:59','2019-01-29 23:59:59','CNDETH','4h','0.000093580000000','0.000092930000000','0.072144500000000','0.071643389452875','770.9393032699295','770.939303269929496','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','CNDETH','4h','0.000091930000000','0.000091080000000','0.072144500000000','0.071477440008702','784.7764603502666','784.776460350266575','test'),('2019-02-01 07:59:59','2019-02-01 11:59:59','CNDETH','4h','0.000092890000000','0.000091530000000','0.072144500000000','0.071088234309398','776.6659489719023','776.665948971902253','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','CNDETH','4h','0.000093400000000','0.000092730000000','0.072144500000000','0.071626975214133','772.4250535331906','772.425053533190635','test'),('2019-02-09 15:59:59','2019-02-09 23:59:59','CNDETH','4h','0.000102190000000','0.000099220000000','0.072144500000000','0.070047727664155','705.9839514629612','705.983951462961159','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','CNDETH','4h','0.000095690000000','0.000095310000000','0.072144500000000','0.071858002873864','753.9398056223221','753.939805622322069','test'),('2019-02-15 11:59:59','2019-02-15 19:59:59','CNDETH','4h','0.000094400000000','0.000092240000000','0.072144500000000','0.070493736016949','764.2425847457627','764.242584745762656','test'),('2019-02-15 23:59:59','2019-02-16 07:59:59','CNDETH','4h','0.000095370000000','0.000093020000000','0.072144500000000','0.070366796581734','756.4695396875327','756.469539687532688','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CNDETH','4h','0.000086030000000','0.000084950000000','0.072144500000000','0.071238815238870','838.5970010461467','838.597001046146715','test'),('2019-02-26 03:59:59','2019-03-05 19:59:59','CNDETH','4h','0.000088930000000','0.000096620000000','0.072144500000000','0.078383015742719','811.250421679973','811.250421679972987','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CNDETH','4h','0.000095320000000','0.000094700000000','0.072144500000000','0.071675242866135','756.8663449433487','756.866344943348736','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','CNDETH','4h','0.000112540000000','0.000110480000000','0.072144500000000','0.070823923582726','641.056513239737','641.056513239737001','test'),('2019-03-25 11:59:59','2019-03-26 11:59:59','CNDETH','4h','0.000111470000000','0.000112510000000','0.072144500000000','0.072817598412129','647.2100116623307','647.210011662330658','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','CNDETH','4h','0.000121730000000','0.000118150000000','0.072144500000000','0.070022777252937','592.6599852131767','592.659985213176697','test'),('2019-04-13 15:59:59','2019-04-13 19:59:59','CNDETH','4h','0.000119970000000','0.000114720000000','0.072144500000000','0.068987388847212','601.3545052929899','601.354505292989870','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','CNDETH','4h','0.000078800000000','0.000077000000000','0.072144500000000','0.070496529187817','915.5393401015228','915.539340101522839','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:15:46
