-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-17 23:59:59','2018-09-18 03:59:59','SYSETH','4h','0.000397920000000','0.000393160000000','0.072144500000000','0.071281492812626','181.30403096099718','181.304030960997181','test'),('2018-09-20 15:59:59','2018-09-20 23:59:59','SYSETH','4h','0.000395330000000','0.000380130000000','0.072144500000000','0.069370623997673','182.49184225836643','182.491842258366432','test'),('2018-09-24 07:59:59','2018-09-25 03:59:59','SYSETH','4h','0.000393150000000','0.000386250000000','0.072144500000000','0.070878324112934','183.50375174869643','183.503751748696430','test'),('2018-09-29 23:59:59','2018-09-30 11:59:59','SYSETH','4h','0.000399270000000','0.000395350000000','0.072144500000000','0.071436191236507','180.69101109524883','180.691011095248825','test'),('2018-10-01 03:59:59','2018-10-05 23:59:59','SYSETH','4h','0.000397310000000','0.000412470000000','0.072144500000000','0.074897289056404','181.58239158339836','181.582391583398362','test'),('2018-10-09 19:59:59','2018-10-09 23:59:59','SYSETH','4h','0.000417390000000','0.000417690000000','0.072144500000000','0.072196354021419','172.84673806272312','172.846738062723119','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','SYSETH','4h','0.000421290000000','0.000419000000000','0.072144500000000','0.071752345177906','171.2466472026395','171.246647202639508','test'),('2018-10-28 03:59:59','2018-10-28 07:59:59','SYSETH','4h','0.000479830000000','0.000477940000000','0.072144500000000','0.071860330387846','150.35429214513474','150.354292145134735','test'),('2018-10-31 07:59:59','2018-10-31 11:59:59','SYSETH','4h','0.000479730000000','0.000471580000000','0.072144500000000','0.070918857086278','150.38563358555854','150.385633585558537','test'),('2018-11-11 19:59:59','2018-11-11 23:59:59','SYSETH','4h','0.000438370000000','0.000437230000000','0.072144500000000','0.071956885131282','164.57444624404042','164.574446244040416','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','SYSETH','4h','0.000348800000000','0.000354210000000','0.072144500000000','0.073263484360665','206.83629587155963','206.836295871559628','test'),('2018-11-29 03:59:59','2018-11-29 07:59:59','SYSETH','4h','0.000346290000000','0.000344590000000','0.072144500000000','0.071790329651448','208.33549914811283','208.335499148112831','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','SYSETH','4h','0.000356100000000','0.000353860000000','0.072144500000000','0.071690684554900','202.5961808480764','202.596180848076386','test'),('2018-12-08 11:59:59','2018-12-08 15:59:59','SYSETH','4h','0.000367820000000','0.000362310000000','0.072144500000000','0.071063764327660','196.1407753792616','196.140775379261612','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','SYSETH','4h','0.000362150000000','0.000357230000000','0.072144500000000','0.071164378669060','199.21165263012566','199.211652630125656','test'),('2018-12-10 23:59:59','2018-12-11 03:59:59','SYSETH','4h','0.000360960000000','0.000349340000000','0.072144500000000','0.069822029116800','199.8684064716312','199.868406471631204','test'),('2018-12-13 23:59:59','2018-12-14 19:59:59','SYSETH','4h','0.000399110000000','0.000484750000000','0.072144500000000','0.087625081744381','180.7634486732981','180.763448673298086','test'),('2018-12-29 19:59:59','2018-12-29 23:59:59','SYSETH','4h','0.000411500000000','0.000354260000000','0.073772486361447','0.063510670761619','179.277002093432','179.277002093432003','test'),('2018-12-30 07:59:59','2018-12-30 11:59:59','SYSETH','4h','0.000392880000000','0.000366920000000','0.073772486361447','0.068897884075906','187.77358572960443','187.773585729604434','test'),('2019-01-07 23:59:59','2019-01-08 03:59:59','SYSETH','4h','0.000340000000000','0.000342990000000','0.073772486361447','0.074421250285626','216.97790106307937','216.977901063079372','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','SYSETH','4h','0.000338050000000','0.000331730000000','0.073772486361447','0.072393275848788','218.2295114966632','218.229511496663207','test'),('2019-01-13 03:59:59','2019-01-13 07:59:59','SYSETH','4h','0.000338660000000','0.000331250000000','0.073772486361447','0.072158318393756','217.83643288680975','217.836432886809746','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SYSETH','4h','0.000370150000000','0.000340200000000','0.073772486361447','0.067803322599390','199.30429923395107','199.304299233951070','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','SYSETH','4h','0.000354690000000','0.000344390000000','0.073772486361447','0.071630174456621','207.991447070532','207.991447070531990','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','SYSETH','4h','0.000357310000000','0.000345300000000','0.073772486361447','0.071292825671287','206.4663355670062','206.466335567006212','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','SYSETH','4h','0.000356050000000','0.000349070000000','0.073772486361447','0.072326251409045','207.1969845848813','207.196984584881307','test'),('2019-02-20 15:59:59','2019-02-20 19:59:59','SYSETH','4h','0.000370060000000','0.000362540000000','0.073772486361447','0.072273353525047','199.35277079783546','199.352770797835461','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','SYSETH','4h','0.000365370000000','0.000356020000000','0.073772486361447','0.071884611748097','201.9117233528943','201.911723352894313','test'),('2019-02-27 15:59:59','2019-02-27 19:59:59','SYSETH','4h','0.000352540000000','0.000370730000000','0.073772486361447','0.077578924005160','209.25990344768536','209.259903447685360','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','SYSETH','4h','0.000394960000000','0.000384930000000','0.073772486361447','0.071899035788717','186.7847031634773','186.784703163477303','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','SYSETH','4h','0.000417460000000','0.000413070000000','0.073772486361447','0.072996696548946','176.71749715289369','176.717497152893685','test'),('2019-03-17 03:59:59','2019-03-25 03:59:59','SYSETH','4h','0.000404690000000','0.000416950000000','0.073772486361447','0.076007408605118','182.29382085410313','182.293820854103132','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','SYSETH','4h','0.000434530000000','0.000423750000000','0.073772486361447','0.071942308000974','169.77535811439256','169.775358114392560','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','SYSETH','4h','0.000443000000000','0.000431960000000','0.073772486361447','0.071934002728421','166.52931458565914','166.529314585659137','test'),('2019-04-24 11:59:59','2019-04-24 19:59:59','SYSETH','4h','0.000359710000000','0.000353890000000','0.073772486361447','0.072578869640690','205.08878363528117','205.088783635281175','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','SYSETH','4h','0.000351350000000','0.000346320000000','0.073772486361447','0.072716344034997','209.96865336970825','209.968653369708250','test'),('2019-05-04 07:59:59','2019-05-04 11:59:59','SYSETH','4h','0.000349340000000','0.000375620000000','0.073772486361447','0.079322211390298','211.17675147835058','211.176751478350582','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','SYSETH','4h','0.000355260000000','0.000356200000000','0.073772486361447','0.073967684630826','207.65773338244384','207.657733382443837','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','SYSETH','4h','0.000362680000000','0.000336590000000','0.073772486361447','0.068465537621042','203.409303963403','203.409303963403005','test'),('2019-05-19 03:59:59','2019-05-19 19:59:59','SYSETH','4h','0.000302280000000','0.000287890000000','0.073772486361447','0.070260556763917','244.0534814127531','244.053481412753086','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','SYSETH','4h','0.000288770000000','0.000282280000000','0.073772486361447','0.072114476746578','255.47143526490632','255.471435264906319','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','SYSETH','4h','0.000295190000000','0.000299740000000','0.073772486361447','0.074909600806193','249.91526258154744','249.915262581547438','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','SYSETH','4h','0.000293770000000','0.000280150000000','0.073772486361447','0.070352187269494','251.1232813474725','251.123281347472499','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','SYSETH','4h','0.000297840000000','0.000271190000000','0.073772486361447','0.067171503412439','247.6916678802276','247.691667880227612','test'),('2019-06-01 11:59:59','2019-06-01 23:59:59','SYSETH','4h','0.000286650000000','0.000281950000000','0.073772486361447','0.072562890387615','257.3608454960649','257.360845496064883','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','SYSETH','4h','0.000282350000000','0.000276030000000','0.073772486361447','0.072121195007438','261.28027753301575','261.280277533015749','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','SYSETH','4h','0.000270040000000','0.000266490000000','0.073772486361447','0.072802658459717','273.1909582337691','273.190958233769095','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','SYSETH','4h','0.000270880000000','0.000266710000000','0.073772486361447','0.072636812749046','272.3437919427311','272.343791942731116','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','SYSETH','4h','0.000271320000000','0.000267750000000','0.073772486361447','0.072801795751428','271.90213165799423','271.902131657994232','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','SYSETH','4h','0.000138110000000','0.000136330000000','0.073772486361447','0.072821686088307','534.1574568202665','534.157456820266475','test'),('2019-08-16 19:59:59','2019-08-17 15:59:59','SYSETH','4h','0.000151490000000','0.000145320000000','0.073772486361447','0.070767824397950','486.97924854080793','486.979248540807930','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','SYSETH','4h','0.000133770000000','0.000133220000000','0.073772486361447','0.073469168222112','551.4875260629962','551.487526062996153','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','SYSETH','4h','0.000133760000000','0.000150260000000','0.073772486361447','0.082872710830375','551.5287556926361','551.528755692636082','test'),('2019-09-04 07:59:59','2019-09-04 11:59:59','SYSETH','4h','0.000152190000000','0.000147190000000','0.073772486361447','0.071348789457529','484.7393807835403','484.739380783540298','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','SYSETH','4h','0.000147670000000','0.000146720000000','0.073772486361447','0.073297888528147','499.5766666313198','499.576666631319824','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','SYSETH','4h','0.000147310000000','0.000149150000000','0.073772486361447','0.074693953844341','500.79754505089267','500.797545050892666','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','SYSETH','4h','0.000152080000000','0.000146780000000','0.073772486361447','0.071201509390671','485.089994486106','485.089994486105979','test'),('2019-09-11 07:59:59','2019-09-11 11:59:59','SYSETH','4h','0.000146770000000','0.000148000000000','0.073772486361447','0.074390733675098','502.6400923993118','502.640092399311811','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:20:57
