-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-16 03:59:59','2018-04-16 07:59:59','BTGBTC','4h','0.006376000000000','0.006253000000000','0.001467500000000','0.001439190323087','0.23015997490589712','0.230159974905897','test'),('2018-05-02 07:59:59','2018-05-03 19:59:59','BTGBTC','4h','0.008039000000000','0.007879000000000','0.001467500000000','0.001438292387113','0.1825475805448439','0.182547580544844','test'),('2018-05-05 11:59:59','2018-05-05 19:59:59','BTGBTC','4h','0.008089000000000','0.007988000000000','0.001467500000000','0.001449176659661','0.1814192112745704','0.181419211274570','test'),('2018-06-03 11:59:59','2018-06-03 19:59:59','BTGBTC','4h','0.006027000000000','0.006004000000000','0.001467500000000','0.001461899784304','0.24348763895802222','0.243487638958022','test'),('2018-06-05 19:59:59','2018-06-05 23:59:59','BTGBTC','4h','0.005997000000000','0.006005000000000','0.001467500000000','0.001469457645489','0.24470568617642158','0.244705686176422','test'),('2018-07-02 11:59:59','2018-07-03 23:59:59','BTGBTC','4h','0.004348000000000','0.004404000000000','0.001467500000000','0.001486400643974','0.3375114995400184','0.337511499540018','test'),('2018-07-06 23:59:59','2018-07-07 07:59:59','BTGBTC','4h','0.004524000000000','0.004413000000000','0.001467500000000','0.001431493700265','0.3243810786914235','0.324381078691424','test'),('2018-07-13 11:59:59','2018-07-13 19:59:59','BTGBTC','4h','0.004441000000000','0.004364000000000','0.001467500000000','0.001442055843279','0.33044359378518356','0.330443593785184','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','BTGBTC','4h','0.004384000000000','0.004468000000000','0.001467500000000','0.001495618156934','0.33473996350364965','0.334739963503650','test'),('2018-08-05 19:59:59','2018-08-06 07:59:59','BTGBTC','4h','0.003526000000000','0.003530000000000','0.001467500000000','0.001469164775950','0.41619398752127057','0.416193987521271','test'),('2018-08-19 19:59:59','2018-08-19 23:59:59','BTGBTC','4h','0.002979000000000','0.003033000000000','0.001467500000000','0.001494101208459','0.4926149714669352','0.492614971466935','test'),('2018-08-25 07:59:59','2018-08-26 03:59:59','BTGBTC','4h','0.002954000000000','0.002897000000000','0.001467500000000','0.001439183310765','0.49678402166553826','0.496784021665538','test'),('2018-08-26 07:59:59','2018-08-26 11:59:59','BTGBTC','4h','0.002927000000000','0.002950000000000','0.001467500000000','0.001479031431500','0.5013665869490946','0.501366586949095','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','BTGBTC','4h','0.002951000000000','0.002926000000000','0.001467500000000','0.001455067773636','0.49728905455777705','0.497289054557777','test'),('2018-09-06 15:59:59','2018-09-07 07:59:59','BTGBTC','4h','0.003006000000000','0.002992000000000','0.001467500000000','0.001460665335995','0.48819028609447773','0.488190286094478','test'),('2018-09-08 11:59:59','2018-09-08 15:59:59','BTGBTC','4h','0.003069000000000','0.003022000000000','0.001467500000000','0.001445026067123','0.4781687846203975','0.478168784620398','test'),('2018-09-09 07:59:59','2018-09-11 19:59:59','BTGBTC','4h','0.003020000000000','0.003018000000000','0.001467500000000','0.001466528145695','0.4859271523178808','0.485927152317881','test'),('2018-09-12 23:59:59','2018-09-13 03:59:59','BTGBTC','4h','0.003043000000000','0.003000000000000','0.001467500000000','0.001446763062767','0.48225435425566876','0.482254354255669','test'),('2018-09-13 11:59:59','2018-09-14 03:59:59','BTGBTC','4h','0.003143000000000','0.003078000000000','0.001467500000000','0.001437150811327','0.4669105949729558','0.466910594972956','test'),('2018-10-12 11:59:59','2018-10-12 19:59:59','BTGBTC','4h','0.004005000000000','0.004002000000000','0.001467500000000','0.001466400749064','0.36641697877652935','0.366416978776529','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','BTGBTC','4h','0.003960000000000','0.003993000000000','0.001467500000000','0.001479729166667','0.3705808080808081','0.370580808080808','test'),('2018-10-18 23:59:59','2018-10-19 11:59:59','BTGBTC','4h','0.003994000000000','0.003982000000000','0.001467500000000','0.001463090886329','0.36742613920881323','0.367426139208813','test'),('2018-10-31 07:59:59','2018-11-01 03:59:59','BTGBTC','4h','0.004188000000000','0.004135000000000','0.001467500000000','0.001448928486151','0.3504059216809933','0.350405921680993','test'),('2018-11-14 23:59:59','2018-11-15 03:59:59','BTGBTC','4h','0.004531000000000','0.004482000000000','0.001467500000000','0.001451629883028','0.3238799382034871','0.323879938203487','test'),('2018-11-15 07:59:59','2018-11-20 07:59:59','BTGBTC','4h','0.004560000000000','0.004464000000000','0.001467500000000','0.001436605263158','0.32182017543859653','0.321820175438597','test'),('2018-11-24 03:59:59','2018-11-24 11:59:59','BTGBTC','4h','0.004741000000000','0.005126000000000','0.001467500000000','0.001586670533643','0.3095338536173803','0.309533853617380','test'),('2018-11-26 19:59:59','2018-11-26 23:59:59','BTGBTC','4h','0.004743000000000','0.004728000000000','0.001467500000000','0.001462858950032','0.3094033312249631','0.309403331224963','test'),('2018-12-20 19:59:59','2018-12-25 03:59:59','BTGBTC','4h','0.003576000000000','0.003592000000000','0.001467500000000','0.001474065995526','0.4103747203579418','0.410374720357942','test'),('2018-12-25 23:59:59','2018-12-27 07:59:59','BTGBTC','4h','0.003682000000000','0.003644000000000','0.001467500000000','0.001452354698533','0.39856056491037484','0.398560564910375','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','BTGBTC','4h','0.003684000000000','0.003722000000000','0.001467500000000','0.001482637079262','0.3983441910966341','0.398344191096634','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','BTGBTC','4h','0.002838000000000','0.002822000000000','0.001467500000000','0.001459226568006','0.5170894996476393','0.517089499647639','test'),('2019-02-13 07:59:59','2019-02-13 15:59:59','BTGBTC','4h','0.002829000000000','0.002816000000000','0.001467500000000','0.001460756451043','0.5187345351714387','0.518734535171439','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BTGBTC','4h','0.002813000000000','0.002811000000000','0.001467500000000','0.001466456629932','0.5216850337717739','0.521685033771774','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','BTGBTC','4h','0.002820000000000','0.002792000000000','0.001467500000000','0.001452929078014','0.5203900709219859','0.520390070921986','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','BTGBTC','4h','0.002824000000000','0.003114000000000','0.001467500000000','0.001618199362606','0.5196529745042493','0.519652974504249','test'),('2019-03-05 15:59:59','2019-03-06 19:59:59','BTGBTC','4h','0.003199000000000','0.003233000000000','0.001469076712079','0.001484690531463','0.45922998189410735','0.459229981894107','test'),('2019-03-08 07:59:59','2019-03-08 11:59:59','BTGBTC','4h','0.003342000000000','0.003286000000000','0.001472980166925','0.001448298273045','0.440748105004563','0.440748105004563','test'),('2019-03-12 19:59:59','2019-03-13 11:59:59','BTGBTC','4h','0.003235000000000','0.003257000000000','0.001472980166925','0.001482997342712','0.45532617215610505','0.455326172156105','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','BTGBTC','4h','0.003302000000000','0.003285000000000','0.001472980166925','0.001465396683328','0.44608727041944274','0.446087270419443','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','BTGBTC','4h','0.003296000000000','0.003270000000000','0.001472980166925','0.001461360784540','0.4468993224893811','0.446899322489381','test'),('2019-04-01 07:59:59','2019-04-01 23:59:59','BTGBTC','4h','0.003219000000000','0.003207000000000','0.001472980166925','0.001467489094541','0.4575893653075489','0.457589365307549','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','BTGBTC','4h','0.003271000000000','0.003211000000000','0.001472980166925','0.001445961270558','0.4503149394451238','0.450314939445124','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','BTGBTC','4h','0.003246000000000','0.003137000000000','0.001472980166925','0.001423517801492','0.45378316910813304','0.453783169108133','test'),('2019-04-05 07:59:59','2019-04-08 15:59:59','BTGBTC','4h','0.003496000000000','0.003434000000000','0.001472980166925','0.001446857520944','0.4213329996925057','0.421332999692506','test'),('2019-04-09 03:59:59','2019-04-09 07:59:59','BTGBTC','4h','0.003373000000000','0.003344000000000','0.001472980166925','0.001460315943729','0.43669735159353684','0.436697351593537','test'),('2019-04-09 15:59:59','2019-04-10 11:59:59','BTGBTC','4h','0.003419000000000','0.003464000000000','0.001472980166925','0.001492367153620','0.43082192656478496','0.430821926564785','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:39:57
