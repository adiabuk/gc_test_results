-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-21 07:59:59','2018-04-21 11:59:59','YOYOETH','4h','0.000202000000000','0.000193140000000','0.072144500000000','0.068980142227723','357.1509900990099','357.150990099009903','test'),('2018-04-22 15:59:59','2018-04-22 19:59:59','YOYOETH','4h','0.000210410000000','0.000205490000000','0.072144500000000','0.070457550995675','342.8758138871726','342.875813887172626','test'),('2018-04-24 15:59:59','2018-04-24 19:59:59','YOYOETH','4h','0.000206330000000','0.000204870000000','0.072144500000000','0.071634002399069','349.65589104832065','349.655891048320655','test'),('2018-04-29 19:59:59','2018-05-02 15:59:59','YOYOETH','4h','0.000199040000000','0.000300520000000','0.072144500000000','0.108927176145498','362.4623191318328','362.462319131832828','test'),('2018-05-07 19:59:59','2018-05-07 23:59:59','YOYOETH','4h','0.000236020000000','0.000230310000000','0.079999717941991','0.078064295564867','338.95313084480654','338.953130844806537','test'),('2018-05-12 15:59:59','2018-05-12 19:59:59','YOYOETH','4h','0.000231130000000','0.000205500000000','0.079999717941991','0.071128551192312','346.1243367022498','346.124336702249821','test'),('2018-06-01 15:59:59','2018-06-03 11:59:59','YOYOETH','4h','0.000172010000000','0.000169620000000','0.079999717941991','0.078888158579853','465.0875992209232','465.087599220923209','test'),('2018-06-04 03:59:59','2018-06-04 07:59:59','YOYOETH','4h','0.000172220000000','0.000167670000000','0.079999717941991','0.077886149734837','464.52048508878755','464.520485088787552','test'),('2018-06-08 07:59:59','2018-06-08 11:59:59','YOYOETH','4h','0.000168400000000','0.000161580000000','0.079999717941991','0.076759824376882','475.0577074940083','475.057707494008298','test'),('2018-06-08 19:59:59','2018-06-08 23:59:59','YOYOETH','4h','0.000167380000000','0.000160950000000','0.079999717941991','0.076926482272455','477.95267022338993','477.952670223389930','test'),('2018-07-02 15:59:59','2018-07-02 19:59:59','YOYOETH','4h','0.000144460000000','0.000138970000000','0.079999717941991','0.076959440692223','553.7845627993285','553.784562799328455','test'),('2018-07-09 07:59:59','2018-07-09 11:59:59','YOYOETH','4h','0.000138230000000','0.000136730000000','0.079999717941991','0.079131602649269','578.7435284814511','578.743528481451108','test'),('2018-07-18 03:59:59','2018-07-19 23:59:59','YOYOETH','4h','0.000126500000000','0.000127010000000','0.079999717941991','0.080322246449109','632.4088374860947','632.408837486094740','test'),('2018-08-13 07:59:59','2018-08-13 11:59:59','YOYOETH','4h','0.000084670000000','0.000079310000000','0.079999717941991','0.074935368252974','944.8413598912365','944.841359891236493','test'),('2018-08-15 11:59:59','2018-08-15 15:59:59','YOYOETH','4h','0.000087000000000','0.000083530000000','0.079999717941991','0.076808924594190','919.536987838977','919.536987838976984','test'),('2018-08-17 11:59:59','2018-08-18 07:59:59','YOYOETH','4h','0.000082070000000','0.000082500000000','0.079999717941991','0.080418870844575','974.7741920554525','974.774192055452545','test'),('2018-08-28 03:59:59','2018-08-28 07:59:59','YOYOETH','4h','0.000096780000000','0.000098100000000','0.079999717941991','0.081090848626879','826.6141552179272','826.614155217927191','test'),('2018-09-01 11:59:59','2018-09-01 15:59:59','YOYOETH','4h','0.000097010000000','0.000092080000000','0.079999717941991','0.075934172024518','824.6543443149263','824.654344314926334','test'),('2018-09-04 07:59:59','2018-09-04 15:59:59','YOYOETH','4h','0.000093250000000','0.000097500000000','0.079999717941991','0.083645817687336','857.9058224342198','857.905822434219772','test'),('2018-09-06 07:59:59','2018-09-06 11:59:59','YOYOETH','4h','0.000094040000000','0.000092380000000','0.079999717941991','0.078587557884742','850.6988296681305','850.698829668130543','test'),('2018-09-06 15:59:59','2018-09-09 11:59:59','YOYOETH','4h','0.000094570000000','0.000099710000000','0.079999717941991','0.084347804546853','845.9312460821719','845.931246082171924','test'),('2018-09-16 07:59:59','2018-09-16 11:59:59','YOYOETH','4h','0.000099410000000','0.000099800000000','0.079999717941991','0.080313568560615','804.7451759580625','804.745175958062532','test'),('2018-09-22 23:59:59','2018-09-24 03:59:59','YOYOETH','4h','0.000109840000000','0.000110050000000','0.079999717941991','0.080152667147816','728.3295515476237','728.329551547623737','test'),('2018-10-16 15:59:59','2018-10-19 11:59:59','YOYOETH','4h','0.000144000000000','0.000147520000000','0.079999717941991','0.081955266602795','555.5535968193819','555.553596819381937','test'),('2018-11-18 19:59:59','2018-11-18 23:59:59','YOYOETH','4h','0.000195880000000','0.000171510000000','0.079999717941991','0.070046720564789','408.4118743209669','408.411874320966888','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','YOYOETH','4h','0.000151040000000','0.000148800000000','0.079999717941991','0.078813281447089','529.659149510004','529.659149510003999','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','YOYOETH','4h','0.000153010000000','0.000148410000000','0.079999717941991','0.077594654857662','522.8398009410561','522.839800941056069','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','YOYOETH','4h','0.000156000000000','0.000155000000000','0.079999717941991','0.079486899237235','512.8187047563525','512.818704756352531','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','YOYOETH','4h','0.000154750000000','0.000153750000000','0.079999717941991','0.079482756921364','516.9610206267593','516.961020626759250','test'),('2018-12-05 23:59:59','2018-12-06 03:59:59','YOYOETH','4h','0.000154300000000','0.000155920000000','0.079999717941991','0.080839637210079','518.4686840051263','518.468684005126306','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','YOYOETH','4h','0.000155460000000','0.000153860000000','0.079999717941991','0.079176357922004','514.6000124919015','514.600012491901452','test'),('2018-12-09 19:59:59','2018-12-09 23:59:59','YOYOETH','4h','0.000159500000000','0.000157560000000','0.079999717941991','0.079026680620314','501.5656297303511','501.565629730351077','test'),('2018-12-17 23:59:59','2018-12-18 03:59:59','YOYOETH','4h','0.000146760000000','0.000144730000000','0.079999717941991','0.078893153296159','545.1057368628441','545.105736862844083','test'),('2019-01-09 15:59:59','2019-01-09 23:59:59','YOYOETH','4h','0.000100750000000','0.000100580000000','0.079999717941991','0.079864730824868','794.041865429191','794.041865429191034','test'),('2019-01-11 11:59:59','2019-01-12 11:59:59','YOYOETH','4h','0.000104760000000','0.000103260000000','0.079999717941991','0.078854246608343','763.6475557654734','763.647555765473385','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','YOYOETH','4h','0.000132900000000','0.000132260000000','0.079999717941991','0.079614467231059','601.9542358313845','601.954235831384494','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','YOYOETH','4h','0.000132360000000','0.000129000000000','0.079999717941991','0.077968900079456','604.4100781353203','604.410078135320305','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','YOYOETH','4h','0.000122030000000','0.000121430000000','0.079999717941991','0.079606373430271','655.574186200041','655.574186200041026','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','YOYOETH','4h','0.000125930000000','0.000118150000000','0.079999717941991','0.075057307034434','635.2713248788294','635.271324878829432','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','YOYOETH','4h','0.000123050000000','0.000120690000000','0.079999717941991','0.078465387715716','650.1399263875741','650.139926387574064','test'),('2019-02-26 11:59:59','2019-02-26 23:59:59','YOYOETH','4h','0.000120020000000','0.000117720000000','0.079999717941991','0.078466645526839','666.5532239792617','666.553223979261702','test'),('2019-03-01 03:59:59','2019-03-01 15:59:59','YOYOETH','4h','0.000118770000000','0.000119060000000','0.079999717941991','0.080195052775730','673.5683922033426','673.568392203342569','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','YOYOETH','4h','0.000142490000000','0.000138270000000','0.079999717941991','0.077630437222536','561.440928780904','561.440928780903960','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','YOYOETH','4h','0.000142580000000','0.000139370000000','0.079999717941991','0.078198630169556','561.0865334688666','561.086533468866605','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','YOYOETH','4h','0.000141660000000','0.000140160000000','0.079999717941991','0.079152622241631','564.7304669066144','564.730466906614424','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','YOYOETH','4h','0.000144340000000','0.000161040000000','0.079999717941991','0.089255608822074','554.2449628792504','554.244962879250352','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','YOYOETH','4h','0.000153990000000','0.000153980000000','0.079999717941991','0.079994522817766','519.5124225078965','519.512422507896531','test'),('2019-04-05 03:59:59','2019-04-05 15:59:59','YOYOETH','4h','0.000158190000000','0.000156700000000','0.079999717941991','0.079246196355711','505.71918542253616','505.719185422536157','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','YOYOETH','4h','0.000156710000000','0.000153800000000','0.079999717941991','0.078514176628666','510.49529667533017','510.495296675330167','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','YOYOETH','4h','0.000164810000000','0.000139400000000','0.079999717941991','0.067665558407339','485.4057274558037','485.405727455803685','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','YOYOETH','4h','0.000147610000000','0.000138400000000','0.079999717941991','0.075008203801718','541.9667904748391','541.966790474839058','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','YOYOETH','4h','0.000199640000000','0.000182800000000','0.079999717941991','0.073251595070106','400.7198855038619','400.719885503861917','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:44:57
