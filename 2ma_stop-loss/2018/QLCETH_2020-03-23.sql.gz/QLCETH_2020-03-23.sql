-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-19 23:59:59','2018-09-20 03:59:59','QLCETH','4h','0.000254370000000','0.000254050000000','0.072144500000000','0.072053741498604','283.62031686126505','283.620316861265053','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','QLCETH','4h','0.000253700000000','0.000256510000000','0.072144500000000','0.072943577828143','284.36933385888847','284.369333858888467','test'),('2018-09-24 07:59:59','2018-09-24 11:59:59','QLCETH','4h','0.000255280000000','0.000251640000000','0.072321579831687','0.071290357054394','283.30296079476165','283.302960794761646','test'),('2018-09-24 19:59:59','2018-09-25 03:59:59','QLCETH','4h','0.000258670000000','0.000260650000000','0.072321579831687','0.072875168296011','279.5901334970696','279.590133497069587','test'),('2018-10-06 11:59:59','2018-10-06 15:59:59','QLCETH','4h','0.000241710000000','0.000237000000000','0.072321579831687','0.070912309875925','299.2080585482065','299.208058548206509','test'),('2018-10-07 07:59:59','2018-10-07 11:59:59','QLCETH','4h','0.000241760000000','0.000237500000000','0.072321579831687','0.071047217116254','299.1461773315974','299.146177331597414','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','QLCETH','4h','0.000242550000000','0.000241880000000','0.072321579831687','0.072121804698777','298.171840163624','298.171840163623983','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','QLCETH','4h','0.000255150000000','0.000245670000000','0.072321579831687','0.069634499381738','283.44730484690183','283.447304846901829','test'),('2018-10-13 19:59:59','2018-10-13 23:59:59','QLCETH','4h','0.000254270000000','0.000250980000000','0.072321579831687','0.071385810776563','284.4282842320643','284.428284232064300','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','QLCETH','4h','0.000255990000000','0.000252670000000','0.072321579831687','0.071383622704295','282.51720704592753','282.517207045927535','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','QLCETH','4h','0.000251520000000','0.000236140000000','0.072321579831687','0.067899244042043','287.5380877532085','287.538087753208515','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','QLCETH','4h','0.000253840000000','0.000250860000000','0.072321579831687','0.071472547733127','284.9101001878624','284.910100187862383','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','QLCETH','4h','0.000249990000000','0.000246660000000','0.072321579831687','0.071358217853850','289.29789124239767','289.297891242397668','test'),('2018-10-18 07:59:59','2018-10-18 11:59:59','QLCETH','4h','0.000250140000000','0.000251860000000','0.072321579831687','0.072818873816298','289.12440965733987','289.124409657339868','test'),('2018-10-21 07:59:59','2018-10-21 11:59:59','QLCETH','4h','0.000248720000000','0.000247640000000','0.072321579831687','0.072007542736889','290.7750877761619','290.775087776161911','test'),('2018-10-22 03:59:59','2018-10-22 07:59:59','QLCETH','4h','0.000249330000000','0.000249250000000','0.072321579831687','0.072298374736486','290.0636900159908','290.063690015990801','test'),('2018-10-25 19:59:59','2018-10-27 15:59:59','QLCETH','4h','0.000252230000000','0.000253150000000','0.072321579831687','0.072585370235069','286.7286993287357','286.728699328735672','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','QLCETH','4h','0.000259520000000','0.000269000000000','0.072321579831687','0.074963413127018','278.6743982417039','278.674398241703898','test'),('2018-11-08 15:59:59','2018-11-08 19:59:59','QLCETH','4h','0.000259640000000','0.000258180000000','0.072321579831687','0.071914903254294','278.5456009539632','278.545600953963174','test'),('2018-11-08 23:59:59','2018-11-09 03:59:59','QLCETH','4h','0.000258530000000','0.000255270000000','0.072321579831687','0.071409622417649','279.7415380485321','279.741538048532107','test'),('2018-11-18 19:59:59','2018-11-18 23:59:59','QLCETH','4h','0.000241380000000','0.000243910000000','0.072321579831687','0.073079611139062','299.6171175395103','299.617117539510275','test'),('2018-11-28 11:59:59','2018-11-28 23:59:59','QLCETH','4h','0.000218300000000','0.000214380000000','0.072321579831687','0.071022905562607','331.29445639801645','331.294456398016450','test'),('2018-12-15 15:59:59','2018-12-16 03:59:59','QLCETH','4h','0.000215210000000','0.000214420000000','0.072321579831687','0.072056099379724','336.05120501689976','336.051205016899758','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','QLCETH','4h','0.000215450000000','0.000215210000000','0.072321579831687','0.072241017384903','335.6768615998468','335.676861599846802','test'),('2018-12-20 11:59:59','2018-12-20 19:59:59','QLCETH','4h','0.000218000000000','0.000208380000000','0.072321579831687','0.069130141308839','331.750366200399','331.750366200399014','test'),('2018-12-21 19:59:59','2018-12-21 23:59:59','QLCETH','4h','0.000216950000000','0.000218500000000','0.072321579831687','0.072838281600478','333.3559798648859','333.355979864885910','test'),('2018-12-27 15:59:59','2018-12-27 19:59:59','QLCETH','4h','0.000208560000000','0.000210110000000','0.072321579831687','0.072859067598944','346.76630145611335','346.766301456113354','test'),('2018-12-28 23:59:59','2018-12-29 03:59:59','QLCETH','4h','0.000216300000000','0.000205020000000','0.072321579831687','0.068550024489563','334.3577430961026','334.357743096102581','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','QLCETH','4h','0.000194620000000','0.000218420000000','0.072321579831687','0.081165756175301','371.60404805100706','371.604048051007055','test'),('2019-01-17 15:59:59','2019-01-17 23:59:59','QLCETH','4h','0.000211120000000','0.000205780000000','0.072321579831687','0.070492301524084','342.5614808245879','342.561480824587875','test'),('2019-01-24 11:59:59','2019-01-25 15:59:59','QLCETH','4h','0.000215500000000','0.000217700000000','0.072321579831687','0.073059897584029','335.5989783372946','335.598978337294625','test'),('2019-01-29 19:59:59','2019-01-30 15:59:59','QLCETH','4h','0.000217110000000','0.000210920000000','0.072321579831687','0.070259627000596','333.1103119694486','333.110311969448617','test'),('2019-02-02 15:59:59','2019-02-02 23:59:59','QLCETH','4h','0.000218560000000','0.000214330000000','0.072321579831687','0.070921871364044','330.90034696050054','330.900346960500542','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','QLCETH','4h','0.000186740000000','0.000175980000000','0.072321579831687','0.068154394445648','387.2848871783603','387.284887178360293','test'),('2019-02-26 11:59:59','2019-02-27 07:59:59','QLCETH','4h','0.000189460000000','0.000184920000000','0.072321579831687','0.070588549258290','381.72479590249657','381.724795902496567','test'),('2019-03-19 15:59:59','2019-03-19 19:59:59','QLCETH','4h','0.000248110000000','0.000249000000000','0.072321579831687','0.072581005917093','291.489983602785','291.489983602785003','test'),('2019-04-27 15:59:59','2019-04-27 19:59:59','QLCETH','4h','0.000229590000000','0.000214560000000','0.072321579831687','0.067587082053603','315.00317884788967','315.003178847889671','test'),('2019-05-06 11:59:59','2019-05-06 15:59:59','QLCETH','4h','0.000208240000000','0.000196730000000','0.072321579831687','0.068324166347905','347.29917322170087','347.299173221700869','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','QLCETH','4h','0.000164580000000','0.000161880000000','0.072321579831687','0.071135115707580','439.4311570767225','439.431157076722513','test'),('2019-06-03 19:59:59','2019-06-04 03:59:59','QLCETH','4h','0.000161690000000','0.000158910000000','0.072321579831687','0.071078126359412','447.2854216815325','447.285421681532512','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','QLCETH','4h','0.000164210000000','0.000159250000000','0.072321579831687','0.070137090239304','440.42128878683997','440.421288786839966','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','QLCETH','4h','0.000171310000000','0.000169400000000','0.072321579831687','0.071515239177443','422.1678818030879','422.167881803087880','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','QLCETH','4h','0.000119200000000','0.000111010000000','0.072321579831687','0.067352504841574','606.7246630175083','606.724663017508306','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','QLCETH','4h','0.000113920000000','0.000105430000000','0.072321579831687','0.066931742992054','634.8453285787131','634.845328578713065','test'),('2019-07-13 07:59:59','2019-07-13 11:59:59','QLCETH','4h','0.000105660000000','0.000102490000000','0.072321579831687','0.070151795541829','684.4745393875354','684.474539387535401','test'),('2019-07-14 19:59:59','2019-07-15 03:59:59','QLCETH','4h','0.000103340000000','0.000103340000000','0.072321579831687','0.072321579831687','699.8411053966228','699.841105396622766','test'),('2019-07-15 23:59:59','2019-07-16 07:59:59','QLCETH','4h','0.000105860000000','0.000102500000000','0.072321579831687','0.070026090428376','683.1813700329396','683.181370032939640','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','QLCETH','4h','0.000101330000000','0.000099790000000','0.072321579831687','0.071222445982474','713.7232787100266','713.723278710026648','test'),('2019-07-23 11:59:59','2019-07-23 23:59:59','QLCETH','4h','0.000102500000000','0.000100000000000','0.072321579831687','0.070557638860182','705.5763886018243','705.576388601824306','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','QLCETH','4h','0.000101840000000','0.000100310000000','0.072321579831687','0.071235051776478','710.1490556921347','710.149055692134652','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','QLCETH','4h','0.000102400000000','0.000100310000000','0.072321579831687','0.070845485087075','706.2654280438184','706.265428043818360','test'),('2019-07-26 07:59:59','2019-07-26 15:59:59','QLCETH','4h','0.000101610000000','0.000102090000000','0.072321579831687','0.072663222960505','711.7565183710954','711.756518371095353','test'),('2019-08-19 23:59:59','2019-08-20 03:59:59','QLCETH','4h','0.000073960000000','0.000071910000000','0.072321579831687','0.070316993046195','977.8472124349241','977.847212434924131','test'),('2019-08-20 15:59:59','2019-08-20 19:59:59','QLCETH','4h','0.000074460000000','0.000072150000000','0.072321579831687','0.070077920828045','971.280953957655','971.280953957655015','test'),('2019-08-21 03:59:59','2019-08-21 07:59:59','QLCETH','4h','0.000072860000000','0.000073940000000','0.072321579831687','0.073393598857465','992.6102090541723','992.610209054172287','test'),('2019-08-21 15:59:59','2019-08-28 11:59:59','QLCETH','4h','0.000073170000000','0.000084250000000','0.072321579831687','0.083273105108919','988.404808414473','988.404808414472996','test'),('2019-08-29 19:59:59','2019-09-01 03:59:59','QLCETH','4h','0.000083990000000','0.000084440000000','0.072321579831687','0.072709062995448','861.0736972459458','861.073697245945823','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','QLCETH','4h','0.000085860000000','0.000084550000000','0.072321579831687','0.071218140866167','842.3198210073026','842.319821007302608','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','QLCETH','4h','0.000087180000000','0.000081730000000','0.072321579831687','0.067800444134478','829.5661829741568','829.566182974156845','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','QLCETH','4h','0.000083840000000','0.000082910000000','0.072321579831687','0.071519348566856','862.6142632596254','862.614263259625432','test'),('2019-09-05 11:59:59','2019-09-05 15:59:59','QLCETH','4h','0.000084100000000','0.000082950000000','0.072321579831687','0.071332640273941','859.9474415182758','859.947441518275809','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','QLCETH','4h','0.000084720000000','0.000082410000000','0.072321579831687','0.070349638738543','853.654152876381','853.654152876380977','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:04:45
