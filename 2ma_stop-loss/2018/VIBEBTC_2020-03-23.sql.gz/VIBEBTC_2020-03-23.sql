-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 03:59:59','VIBEBTC','4h','0.000012480000000','0.000012870000000','0.001467500000000','0.001513359375000','117.58814102564102','117.588141025641022','test'),('2018-07-04 15:59:59','2018-07-05 03:59:59','VIBEBTC','4h','0.000012750000000','0.000012800000000','0.001478964843750','0.001484764705882','115.99724264705884','115.997242647058840','test'),('2018-07-07 03:59:59','2018-07-07 07:59:59','VIBEBTC','4h','0.000012500000000','0.000011950000000','0.001480414809283','0.001415276557675','118.43318474264','118.433184742639995','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','VIBEBTC','4h','0.000011510000000','0.000011510000000','0.001480414809283','0.001480414809283','128.61987917315378','128.619879173153777','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','VIBEBTC','4h','0.000004870000000','0.000004780000000','0.001480414809283','0.001453056014040','303.9866138158111','303.986613815811097','test'),('2018-08-26 23:59:59','2018-08-27 03:59:59','VIBEBTC','4h','0.000004830000000','0.000004870000000','0.001480414809283','0.001492674973335','306.50410130082815','306.504101300828154','test'),('2018-09-03 15:59:59','2018-09-04 15:59:59','VIBEBTC','4h','0.000005340000000','0.000005230000000','0.001480414809283','0.001449919373137','277.2312376934457','277.231237693445678','test'),('2018-09-10 07:59:59','2018-09-10 11:59:59','VIBEBTC','4h','0.000005280000000','0.000005130000000','0.001480414809283','0.001438357570383','280.3815926672348','280.381592667234827','test'),('2018-09-11 03:59:59','2018-09-11 07:59:59','VIBEBTC','4h','0.000004900000000','0.000004740000000','0.001480414809283','0.001432074733878','302.1254712822449','302.125471282244916','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','VIBEBTC','4h','0.000004830000000','0.000004600000000','0.001480414809283','0.001409918865984','306.50410130082815','306.504101300828154','test'),('2018-09-15 03:59:59','2018-09-16 03:59:59','VIBEBTC','4h','0.000004990000000','0.000008360000000','0.001480414809283','0.002480213989099','296.67631448557114','296.676314485571140','test'),('2018-09-30 07:59:59','2018-09-30 11:59:59','VIBEBTC','4h','0.000012600000000','0.000012440000000','0.001662458210100','0.001641347629654','131.94112778569445','131.941127785694448','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','VIBEBTC','4h','0.000011920000000','0.000011750000000','0.001662458210100','0.001638748655090','139.46797064597317','139.467970645973168','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','VIBEBTC','4h','0.000012360000000','0.000011930000000','0.001662458210100','0.001604621880784','134.50309143203884','134.503091432038843','test'),('2018-10-07 11:59:59','2018-10-07 15:59:59','VIBEBTC','4h','0.000012290000000','0.000011580000000','0.001662458210100','0.001566417092999','135.26917901545974','135.269179015459741','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','VIBEBTC','4h','0.000011610000000','0.000011750000000','0.001662458210100','0.001682505079128','143.19192162790696','143.191921627906964','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','VIBEBTC','4h','0.000012600000000','0.000012050000000','0.001662458210100','0.001589890589818','131.9411277857143','131.941127785714286','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','VIBEBTC','4h','0.000011430000000','0.000011050000000','0.001662458210100','0.001607188383343','145.44691251968504','145.446912519685043','test'),('2018-10-17 11:59:59','2018-10-17 15:59:59','VIBEBTC','4h','0.000011270000000','0.000011150000000','0.001662458210100','0.001644756791714','147.5118198846495','147.511819884649498','test'),('2018-10-18 07:59:59','2018-10-18 11:59:59','VIBEBTC','4h','0.000011260000000','0.000011480000000','0.001662458210100','0.001694939631612','147.64282505328597','147.642825053285975','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','VIBEBTC','4h','0.000011240000000','0.000011370000000','0.001662458210100','0.001681685929612','147.9055347064057','147.905534706405689','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','VIBEBTC','4h','0.000011560000000','0.000011400000000','0.001662458210100','0.001639448407884','143.81126384948098','143.811263849480980','test'),('2018-10-27 07:59:59','2018-10-27 11:59:59','VIBEBTC','4h','0.000011420000000','0.000011110000000','0.001662458210100','0.001617330185132','145.574274089317','145.574274089316987','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','VIBEBTC','4h','0.000007530000000','0.000006900000000','0.001662458210100','0.001523368080968','220.777982749004','220.777982749003996','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','VIBEBTC','4h','0.000007150000000','0.000007060000000','0.001662458210100','0.001641532162700','232.51163777622378','232.511637776223779','test'),('2018-12-17 23:59:59','2018-12-25 07:59:59','VIBEBTC','4h','0.000006870000000','0.000007180000000','0.001662458210100','0.001737474519435','241.98809462882096','241.988094628820960','test'),('2018-12-27 23:59:59','2018-12-28 03:59:59','VIBEBTC','4h','0.000007310000000','0.000007320000000','0.001662458210100','0.001664732434738','227.4224637619699','227.422463761969908','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','VIBEBTC','4h','0.000007600000000','0.000007510000000','0.001662458210100','0.001642771204980','218.74450132894736','218.744501328947365','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000007960000000','0.001662458210100','0.001625696234938','204.23319534398036','204.233195343980356','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','VIBEBTC','4h','0.000008010000000','0.000008150000000','0.001662458210100','0.001691514907904','207.54784146067416','207.547841460674164','test'),('2019-01-14 15:59:59','2019-01-15 19:59:59','VIBEBTC','4h','0.000009810000000','0.000013520000000','0.001662458210100','0.002291175841035','169.46566871559634','169.465668715596337','test'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010430000000','0.001706953570467','0.001656141929300','158.78637864806976','158.786378648069757','test'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.001706953570467','0.001750982134785','169.3406319907738','169.340631990773801','test'),('2019-02-17 15:59:59','2019-02-17 19:59:59','VIBEBTC','4h','0.000010150000000','0.000009990000000','0.001706953570467','0.001680045927977','168.17276556325123','168.172765563251232','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000009950000000','0.001706953570467','0.001674969233348','168.3386164168639','168.338616416863914','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009700000000','0.001706953570467','0.001664065289802','171.55312266','171.553122660000014','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009770000000','0.001706953570467','0.001687949026666','172.76858000678138','172.768580006781377','test'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009660000000','0.001706953570467','0.001680853362968','174.00138332996943','174.001383329969428','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','VIBEBTC','4h','0.000010190000000','0.000009900000000','0.001706953570467','0.001658374911445','167.51261731766436','167.512617317664365','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','VIBEBTC','4h','0.000009780000000','0.000010110000000','0.001706953570467','0.001764550163336','174.53512990460123','174.535129904601234','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.001706953570467','0.001749235906616','156.60124499697247','156.601244996972468','test'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.001706953570467','0.001692569130266','239.74067000941014','239.740670009410138','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000005660000000','0.001706953570467','0.001570952391682','277.5534260921951','277.553426092195082','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.001706953570467','0.001762817505500','310.35519463036366','310.355194630363656','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBEBTC','4h','0.000005930000000','0.000005810000000','0.001706953570467','0.001672411508333','287.85051778532886','287.850517785328861','test'),('2019-05-25 19:59:59','2019-05-25 23:59:59','VIBEBTC','4h','0.000005810000000','0.000005740000000','0.001706953570467','0.001686387864799','293.79579526110155','293.795795261101546','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005660000000','0.001706953570467','0.001677318959869','296.34610598385416','296.346105983854159','test'),('2019-05-29 07:59:59','2019-05-29 15:59:59','VIBEBTC','4h','0.000005680000000','0.000005620000000','0.001706953570467','0.001688922370779','300.5199948005282','300.519994800528195','test'),('2019-05-31 07:59:59','2019-05-31 15:59:59','VIBEBTC','4h','0.000005730000000','0.000005750000000','0.001706953570467','0.001712911523593','297.89765627696335','297.897656276963346','test'),('2019-06-05 11:59:59','2019-06-05 15:59:59','VIBEBTC','4h','0.000005860000000','0.000005740000000','0.001706953570467','0.001671998889843','291.28900519914674','291.289005199146743','test'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.001706953570467','0.001712730063091','288.82463121269035','288.824631212690349','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.001706953570467','0.001709798493084','284.4922617445','284.492261744500013','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:09:35
