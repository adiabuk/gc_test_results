-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-05 07:59:59','2018-05-05 11:59:59','GVTBTC','4h','0.002533500000000','0.002417800000000','0.001467500000000','0.001400482139333','0.5792382080126307','0.579238208012631','test'),('2018-05-19 11:59:59','2018-05-19 23:59:59','GVTBTC','4h','0.002232300000000','0.002209500000000','0.001467500000000','0.001452511423196','0.6573937194821485','0.657393719482149','test'),('2018-05-31 19:59:59','2018-06-01 03:59:59','GVTBTC','4h','0.001981700000000','0.001945700000000','0.001467500000000','0.001440841070798','0.7405258111722259','0.740525811172226','test'),('2018-06-05 15:59:59','2018-06-08 07:59:59','GVTBTC','4h','0.002160000000000','0.002067000000000','0.001467500000000','0.001404315972222','0.6793981481481481','0.679398148148148','test'),('2018-07-02 15:59:59','2018-07-02 19:59:59','GVTBTC','4h','0.001426900000000','0.001390200000000','0.001467500000000','0.001429755764244','1.0284532903497092','1.028453290349709','test'),('2018-07-04 15:59:59','2018-07-04 23:59:59','GVTBTC','4h','0.001419500000000','0.001389800000000','0.001467500000000','0.001436795702712','1.0338147234941881','1.033814723494188','test'),('2018-07-05 07:59:59','2018-07-05 11:59:59','GVTBTC','4h','0.001407800000000','0.001404600000000','0.001467500000000','0.001464164298906','1.0424065918454326','1.042406591845433','test'),('2018-07-16 15:59:59','2018-07-18 23:59:59','GVTBTC','4h','0.001260500000000','0.001292000000000','0.001467500000000','0.001504172947243','1.1642205474018248','1.164220547401825','test'),('2018-07-19 23:59:59','2018-07-20 03:59:59','GVTBTC','4h','0.001296800000000','0.001272500000000','0.001467500000000','0.001440001349476','1.131631708821715','1.131631708821715','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','GVTBTC','4h','0.000797000000000','0.000792700000000','0.001467500000000','0.001459582496863','1.841279799247177','1.841279799247177','test'),('2018-08-24 23:59:59','2018-08-25 03:59:59','GVTBTC','4h','0.000798700000000','0.000785800000000','0.001467500000000','0.001443798046826','1.837360711155628','1.837360711155628','test'),('2018-08-30 23:59:59','2018-09-05 11:59:59','GVTBTC','4h','0.000863200000000','0.000918100000000','0.001467500000000','0.001560833816033','1.7000695088044486','1.700069508804449','test'),('2018-09-06 15:59:59','2018-09-08 19:59:59','GVTBTC','4h','0.000948200000000','0.000925000000000','0.001467500000000','0.001431594072980','1.5476692680869015','1.547669268086902','test'),('2018-10-30 11:59:59','2018-10-30 15:59:59','GVTBTC','4h','0.002187500000000','0.002076600000000','0.001467500000000','0.001393101942857','0.6708571428571428','0.670857142857143','test'),('2018-11-24 11:59:59','2018-11-24 15:59:59','GVTBTC','4h','0.001309500000000','0.001294000000000','0.001467500000000','0.001450129820542','1.1206567392134403','1.120656739213440','test'),('2018-12-15 15:59:59','2018-12-16 03:59:59','GVTBTC','4h','0.001074400000000','0.001058900000000','0.001467500000000','0.001446328881236','1.3658786299329857','1.365878629932986','test'),('2018-12-17 07:59:59','2018-12-17 11:59:59','GVTBTC','4h','0.001015700000000','0.001001000000000','0.001467500000000','0.001446261199173','1.4448163827901939','1.444816382790194','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','GVTBTC','4h','0.001009100000000','0.001038600000000','0.001467500000000','0.001510400852245','1.4542661777821821','1.454266177782182','test'),('2018-12-21 11:59:59','2018-12-21 15:59:59','GVTBTC','4h','0.001026800000000','0.001000900000000','0.001467500000000','0.001430483784573','1.4291975068172964','1.429197506817296','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','GVTBTC','4h','0.001030600000000','0.001010200000000','0.001467500000000','0.001438451872696','1.4239278090432759','1.423927809043276','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','GVTBTC','4h','0.001020500000000','0.001023200000000','0.001467500000000','0.001471382655561','1.438020578147967','1.438020578147967','test'),('2018-12-25 23:59:59','2018-12-26 07:59:59','GVTBTC','4h','0.001020700000000','0.001030100000000','0.001467500000000','0.001481014744783','1.4377388067012835','1.437738806701284','test'),('2019-01-01 11:59:59','2019-01-01 15:59:59','GVTBTC','4h','0.001106500000000','0.001078700000000','0.001467500000000','0.001430630140081','1.3262539539087213','1.326253953908721','test'),('2019-01-02 07:59:59','2019-01-02 11:59:59','GVTBTC','4h','0.001093700000000','0.001120100000000','0.001467500000000','0.001502922876474','1.341775624028527','1.341775624028527','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','GVTBTC','4h','0.001098100000000','0.001082800000000','0.001467500000000','0.001447053091704','1.336399235042346','1.336399235042346','test'),('2019-01-17 07:59:59','2019-01-17 15:59:59','GVTBTC','4h','0.001019800000000','0.001001900000000','0.001467500000000','0.001441741763091','1.439007648558541','1.439007648558541','test'),('2019-01-23 11:59:59','2019-01-27 03:59:59','GVTBTC','4h','0.001045200000000','0.001032000000000','0.001467500000000','0.001448966704937','1.4040375047837734','1.404037504783773','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','GVTBTC','4h','0.001026100000000','0.001021100000000','0.001467500000000','0.001460349137511','1.4301724978072312','1.430172497807231','test'),('2019-01-30 11:59:59','2019-01-30 19:59:59','GVTBTC','4h','0.001043900000000','0.001045700000000','0.001467500000000','0.001470030414791','1.4057859948270908','1.405785994827091','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','GVTBTC','4h','0.001011000000000','0.000995100000000','0.001467500000000','0.001444420623145','1.4515331355093968','1.451533135509397','test'),('2019-02-08 07:59:59','2019-02-08 19:59:59','GVTBTC','4h','0.001038900000000','0.001042500000000','0.001467500000000','0.001472585186255','1.4125517374145733','1.412551737414573','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','GVTBTC','4h','0.001025500000000','0.001027700000000','0.001467500000000','0.001470648220380','1.431009263773769','1.431009263773769','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','GVTBTC','4h','0.001040000000000','0.001025000000000','0.001467500000000','0.001446334134615','1.4110576923076925','1.411057692307693','test'),('2019-02-20 07:59:59','2019-02-21 03:59:59','GVTBTC','4h','0.001038200000000','0.001045500000000','0.001467500000000','0.001477818580235','1.4135041417838567','1.413504141783857','test'),('2019-02-23 03:59:59','2019-02-23 07:59:59','GVTBTC','4h','0.001037600000000','0.001027100000000','0.001467500000000','0.001452649624133','1.4143215111796452','1.414321511179645','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','GVTBTC','4h','0.001055700000000','0.001039500000000','0.001467500000000','0.001444980818414','1.3900729373875156','1.390072937387516','test'),('2019-02-24 11:59:59','2019-02-24 15:59:59','GVTBTC','4h','0.001046200000000','0.001018900000000','0.001467500000000','0.001429206413688','1.4026954693175302','1.402695469317530','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','GVTBTC','4h','0.001082300000000','0.001055700000000','0.001467500000000','0.001431432828236','1.3559087129261758','1.355908712926176','test'),('2019-03-01 15:59:59','2019-03-01 19:59:59','GVTBTC','4h','0.001069000000000','0.001081200000000','0.001467500000000','0.001484247895229','1.372778297474275','1.372778297474275','test'),('2019-03-12 15:59:59','2019-03-12 19:59:59','GVTBTC','4h','0.001025000000000','0.001046300000000','0.001467500000000','0.001497995365854','1.4317073170731707','1.431707317073171','test'),('2019-03-14 15:59:59','2019-03-16 03:59:59','GVTBTC','4h','0.001045900000000','0.001019500000000','0.001467500000000','0.001430458217803','1.4030978104981355','1.403097810498136','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','GVTBTC','4h','0.001025300000000','0.001024300000000','0.001467500000000','0.001466068711597','1.4312884033941284','1.431288403394128','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','GVTBTC','4h','0.001013400000000','0.001005500000000','0.001467500000000','0.001456060045392','1.4480955200315768','1.448095520031577','test'),('2019-03-26 23:59:59','2019-04-02 07:59:59','GVTBTC','4h','0.001013300000000','0.000967500000000','0.001467500000000','0.001401170679957','1.4482384288956875','1.448238428895688','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','GVTBTC','4h','0.000808000000000','0.000808900000000','0.001467500000000','0.001469134591584','1.8162128712871288','1.816212871287129','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:09:07
