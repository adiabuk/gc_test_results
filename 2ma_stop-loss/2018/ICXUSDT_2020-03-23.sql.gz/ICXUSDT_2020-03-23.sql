-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-17 23:59:59','2018-12-18 03:59:59','ICXUSDT','4h','0.208900000000000','0.212700000000000','15.000000000000000','15.272857826711345','71.80469123982766','71.804691239827662','test'),('2018-12-18 23:59:59','2018-12-24 15:59:59','ICXUSDT','4h','0.220500000000000','0.270000000000000','15.068214456677836','18.450874844911638','68.33657349967272','68.336573499672724','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','ICXUSDT','4h','0.238200000000000','0.241800000000000','15.913879553736287','16.154391587294015','66.8088982104798','66.808898210479796','test'),('2018-12-26 19:59:59','2018-12-26 23:59:59','ICXUSDT','4h','0.240600000000000','0.240800000000000','15.974007562125719','15.987286038902214','66.39238388248428','66.392383882484282','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','ICXUSDT','4h','0.243400000000000','0.239900000000000','15.977327181319843','15.747579255540799','65.64226450829845','65.642264508298453','test'),('2018-12-30 15:59:59','2018-12-30 19:59:59','ICXUSDT','4h','0.236400000000000','0.237700000000000','15.977327181319843','16.065188963619828','67.58598638460171','67.585986384601711','test'),('2018-12-31 15:59:59','2018-12-31 19:59:59','ICXUSDT','4h','0.238100000000000','0.230900000000000','15.977327181319843','15.494182470250951','67.10343209290149','67.103432092901485','test'),('2019-01-01 23:59:59','2019-01-10 07:59:59','ICXUSDT','4h','0.241800000000000','0.259700000000000','15.977327181319843','17.160098713766597','66.07662192439969','66.076621924399689','test'),('2019-01-17 23:59:59','2019-01-18 07:59:59','ICXUSDT','4h','0.242200000000000','0.243000000000000','16.116762350794545','16.169996908518058','66.54319715439532','66.543197154395315','test'),('2019-01-19 11:59:59','2019-01-20 07:59:59','ICXUSDT','4h','0.242300000000000','0.239600000000000','16.130070990225420','15.950330207420597','66.57066029808263','66.570660298082629','test'),('2019-02-07 07:59:59','2019-02-14 11:59:59','ICXUSDT','4h','0.203500000000000','0.214700000000000','16.130070990225420','17.017819369048638','79.26324810921582','79.263248109215823','test'),('2019-02-25 19:59:59','2019-03-04 07:59:59','ICXUSDT','4h','0.248800000000000','0.266100000000000','16.307072889230021','17.440965015370210','65.5428974647509','65.542897464750894','test'),('2019-03-05 11:59:59','2019-03-10 07:59:59','ICXUSDT','4h','0.274700000000000','0.350100000000000','16.590545920765067','21.144339741026027','60.395143504787285','60.395143504787285','test'),('2019-03-18 23:59:59','2019-03-21 15:59:59','ICXUSDT','4h','0.327100000000000','0.318600000000000','17.728994375830307','17.268289844510964','54.20053309639348','54.200533096393478','test'),('2019-03-24 15:59:59','2019-03-24 19:59:59','ICXUSDT','4h','0.342100000000000','0.337200000000000','17.728994375830307','17.475056718883305','51.82401162183662','51.824011621836618','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','ICXUSDT','4h','0.327000000000000','0.330600000000000','17.728994375830307','17.924175965288988','54.2171081829673','54.217108182967301','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','ICXUSDT','4h','0.325500000000000','0.322900000000000','17.728994375830307','17.587380288650099','54.466956607773604','54.466956607773604','test'),('2019-03-29 03:59:59','2019-03-29 07:59:59','ICXUSDT','4h','0.325700000000000','0.326100000000000','17.728994375830307','17.750767780037652','54.4335105183614','54.433510518361402','test'),('2019-04-20 03:59:59','2019-04-20 15:59:59','ICXUSDT','4h','0.381200000000000','0.378500000000000','17.728994375830307','17.603421750398141','46.50837978969126','46.508379789691261','test'),('2019-04-22 11:59:59','2019-04-23 23:59:59','ICXUSDT','4h','0.391700000000000','0.376600000000000','17.728994375830307','17.045543226800341','45.26166549867324','45.261665498673239','test'),('2019-04-24 23:59:59','2019-04-25 07:59:59','ICXUSDT','4h','0.386700000000000','0.381900000000000','17.728994375830307','17.508929278845603','45.84689520514691','45.846895205146907','test'),('2019-05-11 11:59:59','2019-05-12 03:59:59','ICXUSDT','4h','0.340600000000000','0.345400000000000','17.728994375830307','17.978845148008773','52.05224420384705','52.052244203847053','test'),('2019-05-13 07:59:59','2019-05-13 11:59:59','ICXUSDT','4h','0.334500000000000','0.339900000000000','17.728994375830307','18.015202356785412','53.001477954649644','53.001477954649644','test'),('2019-05-17 19:59:59','2019-05-17 23:59:59','ICXUSDT','4h','0.351600000000000','0.373500000000000','17.728994375830307','18.833274742242942','50.423761023408154','50.423761023408154','test'),('2019-05-23 15:59:59','2019-05-25 19:59:59','ICXUSDT','4h','0.377800000000000','0.371200000000000','17.728994375830307','17.419276633955025','46.92693058716333','46.926930587163334','test'),('2019-05-26 23:59:59','2019-05-28 15:59:59','ICXUSDT','4h','0.378600000000000','0.390900000000000','17.728994375830307','18.304975968072025','46.82777172696859','46.827771726968592','test'),('2019-05-31 19:59:59','2019-05-31 23:59:59','ICXUSDT','4h','0.390800000000000','0.398700000000000','17.788547580001627','18.148142067928990','45.518289611058414','45.518289611058414','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','ICXUSDT','4h','0.390900000000000','0.387200000000000','17.878446201983468','17.709220694315679','45.7366236939971','45.736623693997103','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','ICXUSDT','4h','0.385900000000000','0.377300000000000','17.878446201983468','17.480014905437582','46.32922052859152','46.329220528591520','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ICXUSDT','4h','0.378800000000000','0.372400000000000','17.878446201983468','17.576381641020706','47.19758765043154','47.197587650431537','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ICXUSDT','4h','0.380200000000000','0.366800000000000','17.878446201983468','17.248327372139759','47.02379327191865','47.023793271918649','test'),('2019-06-12 03:59:59','2019-06-14 03:59:59','ICXUSDT','4h','0.384700000000000','0.382500000000000','17.878446201983468','17.776203982996304','46.4737359032583','46.473735903258302','test'),('2019-06-26 07:59:59','2019-06-26 11:59:59','ICXUSDT','4h','0.376400000000000','0.358600000000000','17.878446201983468','17.032972391156406','47.49852869814949','47.498528698149492','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','ICXUSDT','4h','0.328000000000000','0.320600000000000','17.878446201983468','17.475091013280181','54.50745793287643','54.507457932876427','test'),('2019-07-10 19:59:59','2019-07-10 23:59:59','ICXUSDT','4h','0.330700000000000','0.330100000000000','17.878446201983468','17.846008742893083','54.062431817307136','54.062431817307136','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','ICXUSDT','4h','0.278300000000000','0.272000000000000','17.878446201983468','17.473723920012588','64.24163205886981','64.241632058869811','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','ICXUSDT','4h','0.277800000000000','0.269400000000000','17.878446201983468','17.337845236912692','64.35725774652077','64.357257746520773','test'),('2019-07-26 11:59:59','2019-07-27 11:59:59','ICXUSDT','4h','0.280000000000000','0.263100000000000','17.878446201983468','16.799354270506608','63.85159357851238','63.851593578512379','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','ICXUSDT','4h','0.241000000000000','0.224700000000000','17.878446201983468','16.669240089567161','74.18442407462021','74.184424074620210','test'),('2019-09-02 07:59:59','2019-09-02 15:59:59','ICXUSDT','4h','0.215800000000000','0.215100000000000','17.878446201983468','17.820453095674903','82.8472947265221','82.847294726522094','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','ICXUSDT','4h','0.215900000000000','0.211700000000000','17.878446201983468','17.530648730708197','82.8089217322069','82.808921732206898','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','ICXUSDT','4h','0.208500000000000','0.204200000000000','17.878446201983468','17.509730045299875','85.74794341478882','85.747943414788821','test'),('2019-09-12 15:59:59','2019-09-12 19:59:59','ICXUSDT','4h','0.210500000000000','0.206000000000000','17.878446201983468','17.496246639470755','84.93323611393572','84.933236113935720','test'),('2019-09-17 15:59:59','2019-09-19 03:59:59','ICXUSDT','4h','0.203300000000000','0.204800000000000','17.878446201983468','18.010358003768886','87.94120119027775','87.941201190277752','test'),('2019-10-05 07:59:59','2019-10-05 11:59:59','ICXUSDT','4h','0.173600000000000','0.172000000000000','17.878446201983468','17.713667895974403','102.98644125566514','102.986441255665142','test'),('2019-10-07 23:59:59','2019-10-08 11:59:59','ICXUSDT','4h','0.172000000000000','0.172500000000000','17.878446201983468','17.930418429314816','103.9444546626946','103.944454662694596','test'),('2019-10-26 03:59:59','2019-10-26 07:59:59','ICXUSDT','4h','0.158300000000000','0.155300000000000','17.878446201983468','17.539625364295848','112.94027922920701','112.940279229207007','test'),('2019-10-27 15:59:59','2019-10-31 11:59:59','ICXUSDT','4h','0.161100000000000','0.161700000000000','17.878446201983468','17.945032593797190','110.97731968953116','110.977319689531157','test'),('2019-11-17 19:59:59','2019-11-17 23:59:59','ICXUSDT','4h','0.166500000000000','0.164600000000000','17.878446201983468','17.674427896975850','107.37805526716797','107.378055267167966','test'),('2019-11-20 03:59:59','2019-11-20 07:59:59','ICXUSDT','4h','0.162300000000000','0.160000000000000','17.878446201983468','17.625085596533303','110.15678497833314','110.156784978333135','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:44:37
