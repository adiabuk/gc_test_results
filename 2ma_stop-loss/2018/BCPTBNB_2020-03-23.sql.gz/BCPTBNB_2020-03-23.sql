-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-08 07:59:59','2018-05-08 11:59:59','BCPTBNB','4h','0.042230000000000','0.040760000000000','0.711908500000000','0.687127408477386','16.85788538953351','16.857885389533511','test'),('2018-07-01 11:59:59','2018-07-01 15:59:59','BCPTBNB','4h','0.011040000000000','0.010850000000000','0.711908500000000','0.699656451539855','64.48446557971015','64.484465579710147','test'),('2018-07-11 15:59:59','2018-07-11 19:59:59','BCPTBNB','4h','0.014130000000000','0.013560000000000','0.711908500000000','0.683190322717622','50.38276716206653','50.382767162066528','test'),('2018-07-16 15:59:59','2018-07-23 23:59:59','BCPTBNB','4h','0.013920000000000','0.014280000000000','0.711908500000000','0.730319926724138','51.142852011494256','51.142852011494256','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','BCPTBNB','4h','0.014830000000000','0.014520000000000','0.711908500000000','0.697027068105192','48.00461901550911','48.004619015509107','test'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BCPTBNB','4h','0.009020000000000','0.008780000000000','0.711908500000000','0.692966366962306','78.92555432372507','78.925554323725066','test'),('2018-08-24 07:59:59','2018-08-24 15:59:59','BCPTBNB','4h','0.008760000000000','0.008360000000000','0.711908500000000','0.679401262557078','81.26809360730594','81.268093607305943','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','BCPTBNB','4h','0.008760000000000','0.008600000000000','0.711908500000000','0.698905605022831','81.26809360730594','81.268093607305943','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','BCPTBNB','4h','0.008700000000000','0.008500000000000','0.711908500000000','0.695542787356322','81.82856321839081','81.828563218390812','test'),('2018-08-28 11:59:59','2018-08-29 15:59:59','BCPTBNB','4h','0.008710000000000','0.008540000000000','0.711908500000000','0.698013615384615','81.73461538461538','81.734615384615381','test'),('2018-08-29 23:59:59','2018-08-30 03:59:59','BCPTBNB','4h','0.008730000000000','0.008460000000000','0.711908500000000','0.689890711340206','81.54736540664376','81.547365406643763','test'),('2018-08-31 03:59:59','2018-08-31 11:59:59','BCPTBNB','4h','0.009100000000000','0.008810000000000','0.711908500000000','0.689221306043956','78.2317032967033','78.231703296703301','test'),('2018-09-01 19:59:59','2018-09-01 23:59:59','BCPTBNB','4h','0.009270000000000','0.009110000000000','0.711908500000000','0.699620974649407','76.7970334412082','76.797033441208200','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','BCPTBNB','4h','0.008470000000000','0.008170000000000','0.711908500000000','0.686693322904368','84.05059031877214','84.050590318772137','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','BCPTBNB','4h','0.007960000000000','0.008330000000000','0.711908500000000','0.744999724246231','89.43574120603016','89.435741206030158','test'),('2018-09-25 03:59:59','2018-09-25 11:59:59','BCPTBNB','4h','0.008630000000000','0.008470000000000','0.711908500000000','0.698709732908459','82.4922943221321','82.492294322132096','test'),('2018-10-04 15:59:59','2018-10-04 19:59:59','BCPTBNB','4h','0.009340000000000','0.009450000000000','0.711908500000000','0.720292861349036','76.22146680942186','76.221466809421855','test'),('2018-10-08 07:59:59','2018-10-08 11:59:59','BCPTBNB','4h','0.009030000000000','0.009290000000000','0.711908500000000','0.732406419158361','78.83815060908086','78.838150609080856','test'),('2018-10-09 15:59:59','2018-10-09 19:59:59','BCPTBNB','4h','0.009180000000000','0.009160000000000','0.711908500000000','0.710357501089325','77.54994553376906','77.549945533769062','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','BCPTBNB','4h','0.010890000000000','0.010530000000000','0.711908500000000','0.688374334710744','65.372681359045','65.372681359045004','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','BCPTBNB','4h','0.011350000000000','0.011650000000000','0.711908500000000','0.730725464757709','62.72321585903084','62.723215859030837','test'),('2018-11-04 19:59:59','2018-11-05 03:59:59','BCPTBNB','4h','0.012020000000000','0.012490000000000','0.711908500000000','0.739745188435940','59.226996672212984','59.226996672212984','test'),('2018-11-28 23:59:59','2018-11-30 03:59:59','BCPTBNB','4h','0.007740000000000','0.007880000000000','0.711908500000000','0.724785397932816','91.97784237726098','91.977842377260984','test'),('2018-12-01 11:59:59','2018-12-01 19:59:59','BCPTBNB','4h','0.008080000000000','0.007990000000000','0.711908500000000','0.703978826113861','88.10748762376238','88.107487623762381','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','BCPTBNB','4h','0.006730000000000','0.006400000000000','0.711908500000000','0.677000653789005','105.78135215453196','105.781352154531959','test'),('2019-01-01 23:59:59','2019-01-02 03:59:59','BCPTBNB','4h','0.005810000000000','0.005590000000000','0.711908500000000','0.684951551635112','122.53158347676421','122.531583476764212','test'),('2019-01-02 07:59:59','2019-01-02 11:59:59','BCPTBNB','4h','0.005800000000000','0.005720000000000','0.711908500000000','0.702089072413793','122.74284482758623','122.742844827586225','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','BCPTBNB','4h','0.005740000000000','0.005570000000000','0.711908500000000','0.690824101916376','124.02587108013938','124.025871080139382','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','BCPTBNB','4h','0.005660000000000','0.005540000000000','0.711908500000000','0.696815033568905','125.77888692579506','125.778886925795064','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BCPTBNB','4h','0.005200000000000','0.004900000000000','0.711908500000000','0.670836855769231','136.9054807692308','136.905480769230792','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','BCPTBNB','4h','0.005350000000000','0.005150000000000','0.711908500000000','0.685295098130841','133.06700934579442','133.067009345794418','test'),('2019-01-18 23:59:59','2019-01-19 07:59:59','BCPTBNB','4h','0.006000000000000','0.005850000000000','0.711908500000000','0.694110787500000','118.65141666666668','118.651416666666677','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','BCPTBNB','4h','0.005370000000000','0.005240000000000','0.711908500000000','0.694674216014898','132.57141527001863','132.571415270018633','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','BCPTBNB','4h','0.004910000000000','0.004930000000000','0.711908500000000','0.714808330957230','144.99154786150714','144.991547861507144','test'),('2019-02-21 07:59:59','2019-02-21 11:59:59','BCPTBNB','4h','0.003670000000000','0.003560000000000','0.711908500000000','0.690570643051771','193.98051771117167','193.980517711171672','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','BCPTBNB','4h','0.003390000000000','0.003370000000000','0.711908500000000','0.707708449852508','210.0025073746313','210.002507374631307','test'),('2019-03-02 19:59:59','2019-03-03 19:59:59','BCPTBNB','4h','0.003330000000000','0.003310000000000','0.711908500000000','0.707632773273273','213.78633633633635','213.786336336336348','test'),('2019-03-06 07:59:59','2019-03-06 15:59:59','BCPTBNB','4h','0.003410000000000','0.003210000000000','0.711908500000000','0.670154335777126','208.77082111436954','208.770821114369539','test'),('2019-03-09 15:59:59','2019-03-09 23:59:59','BCPTBNB','4h','0.003450000000000','0.003350000000000','0.711908500000000','0.691273471014493','206.35028985507248','206.350289855072475','test'),('2019-03-10 11:59:59','2019-03-10 15:59:59','BCPTBNB','4h','0.003350000000000','0.003320000000000','0.711908500000000','0.705533200000000','212.51000000000002','212.510000000000019','test'),('2019-03-20 19:59:59','2019-03-21 11:59:59','BCPTBNB','4h','0.003070000000000','0.003050000000000','0.711908500000000','0.707270659609121','231.892019543974','231.892019543973987','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','BCPTBNB','4h','0.002880000000000','0.002940000000000','0.711908500000000','0.726739927083333','247.1904513888889','247.190451388888903','test'),('2019-03-28 11:59:59','2019-03-28 23:59:59','BCPTBNB','4h','0.002880000000000','0.002860000000000','0.711908500000000','0.706964690972222','247.1904513888889','247.190451388888903','test'),('2019-03-31 11:59:59','2019-04-01 07:59:59','BCPTBNB','4h','0.002940000000000','0.002960000000000','0.711908500000000','0.716751414965986','242.14574829931976','242.145748299319763','test'),('2019-04-01 19:59:59','2019-04-02 03:59:59','BCPTBNB','4h','0.002950000000000','0.002860000000000','0.711908500000000','0.690189257627119','241.3249152542373','241.324915254237311','test'),('2019-04-03 03:59:59','2019-04-03 19:59:59','BCPTBNB','4h','0.003090000000000','0.003170000000000','0.711908500000000','0.730339788025890','230.3911003236246','230.391100323624613','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','BCPTBNB','4h','0.002990000000000','0.002930000000000','0.711908500000000','0.697622710702341','238.09648829431438','238.096488294314383','test'),('2019-04-12 07:59:59','2019-04-12 11:59:59','BCPTBNB','4h','0.003190000000000','0.003070000000000','0.711908500000000','0.685128242946708','223.16880877742946','223.168808777429462','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','BCPTBNB','4h','0.002860000000000','0.002790000000000','0.711908500000000','0.694484166083916','248.91905594405594','248.919055944055941','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:29:28
