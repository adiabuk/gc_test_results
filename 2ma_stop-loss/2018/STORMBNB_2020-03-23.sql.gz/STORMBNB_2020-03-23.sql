-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-28 03:59:59','2018-08-29 03:59:59','STORMBNB','4h','0.000841000000000','0.000804000000000','0.711908500000000','0.680587912009513','846.5023781212843','846.502378121284323','test'),('2018-08-31 03:59:59','2018-08-31 07:59:59','STORMBNB','4h','0.000824000000000','0.000836000000000','0.711908500000000','0.722276099514563','863.9666262135923','863.966626213592349','test'),('2018-09-01 11:59:59','2018-09-01 15:59:59','STORMBNB','4h','0.000830000000000','0.000829000000000','0.711908500000000','0.711050778915663','857.7210843373495','857.721084337349453','test'),('2018-09-16 19:59:59','2018-09-18 07:59:59','STORMBNB','4h','0.000755000000000','0.000746000000000','0.711908500000000','0.703422173509934','942.9251655629139','942.925165562913890','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','STORMBNB','4h','0.000804000000000','0.000812000000000','0.711908500000000','0.718992166666667','885.4583333333334','885.458333333333371','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','STORMBNB','4h','0.000809000000000','0.000799000000000','0.711908500000000','0.703108642150803','879.985784919654','879.985784919653952','test'),('2018-10-05 15:59:59','2018-10-05 19:59:59','STORMBNB','4h','0.000812000000000','0.000818000000000','0.711908500000000','0.717168907635468','876.7346059113302','876.734605911330164','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','STORMBNB','4h','0.000836000000000','0.000789000000000','0.711908500000000','0.671884936004785','851.5651913875598','851.565191387559821','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','STORMBNB','4h','0.000816000000000','0.000786000000000','0.711908500000000','0.685735393382353','872.436887254902','872.436887254901990','test'),('2018-10-17 19:59:59','2018-10-18 03:59:59','STORMBNB','4h','0.000810000000000','0.000806000000000','0.711908500000000','0.708392902469136','878.8993827160494','878.899382716049445','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','STORMBNB','4h','0.000804000000000','0.000795000000000','0.711908500000000','0.703939375000000','885.4583333333334','885.458333333333371','test'),('2018-10-19 05:59:59','2018-10-19 11:59:59','STORMBNB','4h','0.000804000000000','0.000789000000000','0.711908500000000','0.698626625000000','885.4583333333334','885.458333333333371','test'),('2018-10-20 15:59:59','2018-10-27 23:59:59','STORMBNB','4h','0.000825000000000','0.000930000000000','0.711908500000000','0.802515036363637','862.919393939394','862.919393939394013','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','STORMBNB','4h','0.000869000000000','0.000828000000000','0.711908500000000','0.678320181818182','819.2272727272729','819.227272727272862','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','STORMBNB','4h','0.000782000000000','0.000771000000000','0.711908500000000','0.701894441815857','910.3689258312021','910.368925831202091','test'),('2018-12-16 11:59:59','2018-12-16 15:59:59','STORMBNB','4h','0.000636000000000','0.000598000000000','0.711908500000000','0.669373086477988','1119.352987421384','1119.352987421383887','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','STORMBNB','4h','0.000608000000000','0.000606000000000','0.711908500000000','0.709566695723684','1170.9021381578948','1170.902138157894797','test'),('2018-12-22 15:59:59','2018-12-22 19:59:59','STORMBNB','4h','0.000587000000000','0.000580000000000','0.711908500000000','0.703418960817717','1212.791311754685','1212.791311754685012','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','STORMBNB','4h','0.000587000000000','0.000577000000000','0.711908500000000','0.699780586882453','1212.791311754685','1212.791311754685012','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','STORMBNB','4h','0.000513000000000','0.000504000000000','0.711908500000000','0.699418877192982','1387.735867446394','1387.735867446393968','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','STORMBNB','4h','0.000520000000000','0.000513000000000','0.711908500000000','0.702325116346154','1369.054807692308','1369.054807692308032','test'),('2019-01-07 15:59:59','2019-01-07 23:59:59','STORMBNB','4h','0.000516000000000','0.000506000000000','0.711908500000000','0.698111823643411','1379.6676356589148','1379.667635658914833','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','STORMBNB','4h','0.000510000000000','0.000516000000000','0.711908500000000','0.720283894117647','1395.8990196078432','1395.899019607843229','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','STORMBNB','4h','0.000452000000000','0.000449000000000','0.711908500000000','0.707183443584071','1575.0188053097347','1575.018805309734717','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','STORMBNB','4h','0.000324000000000','0.000311000000000','0.711908500000000','0.683344270061728','2197.2484567901233','2197.248456790123328','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','STORMBNB','4h','0.000303000000000','0.000299000000000','0.711908500000000','0.702510367986799','2349.53300330033','2349.533003300330165','test'),('2019-03-10 15:59:59','2019-03-10 19:59:59','STORMBNB','4h','0.000245000000000','0.000239000000000','0.711908500000000','0.694474006122449','2905.7489795918373','2905.748979591837269','test'),('2019-03-15 03:59:59','2019-03-15 15:59:59','STORMBNB','4h','0.000230000000000','0.000227000000000','0.711908500000000','0.702622736956522','3095.2543478260873','3095.254347826087269','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','STORMBNB','4h','0.000222000000000','0.000223000000000','0.711908500000000','0.715115295045045','3206.7950450450453','3206.795045045045299','test'),('2019-03-19 15:59:59','2019-03-22 11:59:59','STORMBNB','4h','0.000225000000000','0.000226000000000','0.711908500000000','0.715072537777778','3164.037777777778','3164.037777777778047','test'),('2019-03-29 07:59:59','2019-03-30 07:59:59','STORMBNB','4h','0.000212000000000','0.000214000000000','0.711908500000000','0.718624617924528','3358.058962264151','3358.058962264150978','test'),('2019-04-06 03:59:59','2019-04-06 19:59:59','STORMBNB','4h','0.000208000000000','0.000206000000000','0.711908500000000','0.705063225961539','3422.6370192307695','3422.637019230769511','test'),('2019-04-10 19:59:59','2019-04-10 23:59:59','STORMBNB','4h','0.000214000000000','0.000209000000000','0.711908500000000','0.695275123831776','3326.6752336448603','3326.675233644860327','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','STORMBNB','4h','0.000131000000000','0.000127000000000','0.711908500000000','0.690170835877863','5434.416030534351','5434.416030534351194','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','STORMBNB','4h','0.000133000000000','0.000130000000000','0.711908500000000','0.695850413533834','5352.695488721804','5352.695488721804395','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','STORMBNB','4h','0.000131000000000','0.000124000000000','0.711908500000000','0.673867587786260','5434.416030534351','5434.416030534351194','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','STORMBNB','4h','0.000126000000000','0.000123000000000','0.711908500000000','0.694958297619048','5650.067460317461','5650.067460317461155','test'),('2019-05-17 23:59:59','2019-05-18 03:59:59','STORMBNB','4h','0.000126000000000','0.000120000000000','0.711908500000000','0.678008095238095','5650.067460317461','5650.067460317461155','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','STORMBNB','4h','0.000124000000000','0.000120000000000','0.711908500000000','0.688943709677419','5741.197580645162','5741.197580645161906','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','STORMBNB','4h','0.000122000000000','0.000116000000000','0.711908500000000','0.676896606557377','5835.315573770492','5835.315573770491937','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','STORMBNB','4h','0.000111000000000','0.000112000000000','0.711908500000000','0.718322090090090','6413.590090090091','6413.590090090090598','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','STORMBNB','4h','0.000111000000000','0.000111000000000','0.711908500000000','0.711908500000000','6413.590090090091','6413.590090090090598','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','STORMBNB','4h','0.000112000000000','0.000109000000000','0.711908500000000','0.692839522321429','6356.325892857143','6356.325892857143117','test'),('2019-06-03 15:59:59','2019-06-03 19:59:59','STORMBNB','4h','0.000111000000000','0.000115000000000','0.711908500000000','0.737562860360360','6413.590090090091','6413.590090090090598','test'),('2019-06-07 11:59:59','2019-06-07 19:59:59','STORMBNB','4h','0.000109000000000','0.000110000000000','0.711908500000000','0.718439770642202','6531.270642201835','6531.270642201834562','test'),('2019-06-15 23:59:59','2019-06-16 03:59:59','STORMBNB','4h','0.000104000000000','0.000102000000000','0.711908500000000','0.698217951923077','6845.274038461539','6845.274038461539021','test'),('2019-06-16 23:59:59','2019-06-17 03:59:59','STORMBNB','4h','0.000103000000000','0.000103000000000','0.711908500000000','0.711908500000000','6911.733009708739','6911.733009708738791','test'),('2019-06-25 19:59:59','2019-06-25 23:59:59','STORMBNB','4h','0.000091000000000','0.000090000000000','0.711908500000000','0.704085329670330','7823.17032967033','7823.170329670329920','test'),('2019-07-01 03:59:59','2019-07-01 07:59:59','STORMBNB','4h','0.000090000000000','0.000087000000000','0.711908500000000','0.688178216666667','7910.094444444445','7910.094444444444889','test'),('2019-07-01 23:59:59','2019-07-02 07:59:59','STORMBNB','4h','0.000086000000000','0.000084000000000','0.711908500000000','0.695352488372093','8278.005813953489','8278.005813953488541','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','STORMBNB','4h','0.000086000000000','0.000084000000000','0.711908500000000','0.695352488372093','8278.005813953489','8278.005813953488541','test'),('2019-07-05 07:59:59','2019-07-05 11:59:59','STORMBNB','4h','0.000086000000000','0.000085000000000','0.711908500000000','0.703630494186047','8278.005813953489','8278.005813953488541','test'),('2019-07-29 19:59:59','2019-07-31 03:59:59','STORMBNB','4h','0.000080600000000','0.000080000000000','0.711908500000000','0.706608933002482','8832.611662531019','8832.611662531018737','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','STORMBNB','4h','0.000066000000000','0.000061900000000','0.711908500000000','0.667683881060606','10786.492424242424','10786.492424242424022','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:23:51
