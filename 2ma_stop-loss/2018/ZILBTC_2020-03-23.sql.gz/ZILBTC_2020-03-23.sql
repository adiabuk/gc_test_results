-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-19 11:59:59','2018-08-19 15:59:59','ZILBTC','4h','0.000005870000000','0.000005890000000','0.001467500000000','0.001472500000000','250.00000000000003','250.000000000000028','test'),('2018-08-24 11:59:59','2018-08-24 15:59:59','ZILBTC','4h','0.000005630000000','0.000005550000000','0.001468750000000','0.001447879662522','260.8792184724689','260.879218472468892','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ZILBTC','4h','0.000005810000000','0.000005750000000','0.001468750000000','0.001453582185886','252.7969018932874','252.796901893287412','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','ZILBTC','4h','0.000006250000000','0.000006170000000','0.001468750000000','0.001449950000000','235.0','235.000000000000000','test'),('2018-09-04 07:59:59','2018-09-04 15:59:59','ZILBTC','4h','0.000006380000000','0.000006290000000','0.001468750000000','0.001448030956113','230.2115987460815','230.211598746081506','test'),('2018-09-20 23:59:59','2018-09-21 03:59:59','ZILBTC','4h','0.000005370000000','0.000005360000000','0.001468750000000','0.001466014897579','273.51024208566105','273.510242085661048','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ZILBTC','4h','0.000005390000000','0.000005530000000','0.001468750000000','0.001506899350649','272.49536178107604','272.495361781076042','test'),('2018-09-23 07:59:59','2018-09-23 23:59:59','ZILBTC','4h','0.000005340000000','0.000005380000000','0.001468750000000','0.001479751872659','275.0468164794008','275.046816479400775','test'),('2018-09-24 15:59:59','2018-09-25 03:59:59','ZILBTC','4h','0.000005340000000','0.000005300000000','0.001468750000000','0.001457748127341','275.0468164794008','275.046816479400775','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','ZILBTC','4h','0.000005320000000','0.000005300000000','0.001468750000000','0.001463228383459','276.0808270676692','276.080827067669190','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','ZILBTC','4h','0.000005320000000','0.000005290000000','0.001468750000000','0.001460467575188','276.0808270676692','276.080827067669190','test'),('2018-09-29 07:59:59','2018-09-29 15:59:59','ZILBTC','4h','0.000005300000000','0.000005290000000','0.001468750000000','0.001465978773585','277.12264150943395','277.122641509433947','test'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ZILBTC','4h','0.000005510000000','0.000005490000000','0.001468750000000','0.001463418784029','266.5607985480944','266.560798548094397','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','ZILBTC','4h','0.000005520000000','0.000005500000000','0.001468750000000','0.001463428442029','266.0778985507246','266.077898550724626','test'),('2018-10-07 19:59:59','2018-10-08 03:59:59','ZILBTC','4h','0.000005490000000','0.000005490000000','0.001468750000000','0.001468750000000','267.5318761384335','267.531876138433518','test'),('2018-10-17 15:59:59','2018-10-18 03:59:59','ZILBTC','4h','0.000005380000000','0.000005330000000','0.001468750000000','0.001455099907063','273.0018587360595','273.001858736059489','test'),('2018-10-20 19:59:59','2018-10-21 19:59:59','ZILBTC','4h','0.000005340000000','0.000005310000000','0.001468750000000','0.001460498595506','275.0468164794008','275.046816479400775','test'),('2018-10-22 23:59:59','2018-10-23 03:59:59','ZILBTC','4h','0.000005340000000','0.000005270000000','0.001468750000000','0.001449496722846','275.0468164794008','275.046816479400775','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','ZILBTC','4h','0.000005320000000','0.000005320000000','0.001468750000000','0.001468750000000','276.0808270676692','276.080827067669190','test'),('2018-10-24 07:59:59','2018-10-24 11:59:59','ZILBTC','4h','0.000005320000000','0.000005330000000','0.001468750000000','0.001471510808271','276.0808270676692','276.080827067669190','test'),('2018-10-25 07:59:59','2018-10-25 11:59:59','ZILBTC','4h','0.000005310000000','0.000005270000000','0.001468750000000','0.001457685969868','276.60075329566854','276.600753295668540','test'),('2018-10-25 15:59:59','2018-10-29 15:59:59','ZILBTC','4h','0.000005320000000','0.000005400000000','0.001468750000000','0.001490836466165','276.0808270676692','276.080827067669190','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','ZILBTC','4h','0.000005430000000','0.000005440000000','0.001468750000000','0.001471454880295','270.48802946593','270.488029465930026','test'),('2018-11-01 19:59:59','2018-11-01 23:59:59','ZILBTC','4h','0.000005640000000','0.000005560000000','0.001468750000000','0.001447916666667','260.4166666666667','260.416666666666686','test'),('2018-11-04 11:59:59','2018-11-05 15:59:59','ZILBTC','4h','0.000005540000000','0.000005490000000','0.001468750000000','0.001455494133574','265.11732851985556','265.117328519855562','test'),('2018-11-06 15:59:59','2018-11-06 19:59:59','ZILBTC','4h','0.000005540000000','0.000005530000000','0.001468750000000','0.001466098826715','265.11732851985556','265.117328519855562','test'),('2018-11-08 15:59:59','2018-11-08 19:59:59','ZILBTC','4h','0.000005540000000','0.000005480000000','0.001468750000000','0.001452842960289','265.11732851985556','265.117328519855562','test'),('2018-11-09 07:59:59','2018-11-09 11:59:59','ZILBTC','4h','0.000005550000000','0.000005480000000','0.001468750000000','0.001450225225225','264.63963963963965','264.639639639639654','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','ZILBTC','4h','0.000004180000000','0.000004200000000','0.001468750000000','0.001475777511962','351.3755980861244','351.375598086124398','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','ZILBTC','4h','0.000004350000000','0.000004340000000','0.001468750000000','0.001465373563218','337.64367816091954','337.643678160919535','test'),('2018-12-12 15:59:59','2018-12-12 19:59:59','ZILBTC','4h','0.000004060000000','0.000004050000000','0.001468750000000','0.001465132389163','361.76108374384233','361.761083743842335','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','ZILBTC','4h','0.000004010000000','0.000004020000000','0.001468750000000','0.001472412718204','366.2718204488778','366.271820448877804','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','ZILBTC','4h','0.000004030000000','0.000004010000000','0.001468750000000','0.001461460918114','364.4540942928039','364.454094292803916','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','ZILBTC','4h','0.000004040000000','0.000004010000000','0.001468750000000','0.001457843440594','363.5519801980198','363.551980198019805','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','ZILBTC','4h','0.000005580000000','0.000005540000000','0.001468750000000','0.001458221326165','263.2168458781362','263.216845878136212','test'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ZILBTC','4h','0.000005600000000','0.000005520000000','0.001468750000000','0.001447767857143','262.2767857142857','262.276785714285722','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','ZILBTC','4h','0.000005050000000','0.000004850000000','0.001468750000000','0.001410581683168','290.84158415841586','290.841584158415856','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','ZILBTC','4h','0.000004820000000','0.000004750000000','0.001468750000000','0.001447419605809','304.71991701244815','304.719917012448150','test'),('2019-03-08 15:59:59','2019-03-08 19:59:59','ZILBTC','4h','0.000004570000000','0.000004520000000','0.001468750000000','0.001452680525164','321.3894967177243','321.389496717724285','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','ZILBTC','4h','0.000004510000000','0.000004450000000','0.001468750000000','0.001449210088692','325.66518847006654','325.665188470066539','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','ZILBTC','4h','0.000004490000000','0.000004430000000','0.001468750000000','0.001449123051225','327.11581291759467','327.115812917594667','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','ZILBTC','4h','0.000004550000000','0.000004590000000','0.001468750000000','0.001481662087912','322.80219780219784','322.802197802197838','test'),('2019-03-17 15:59:59','2019-03-17 19:59:59','ZILBTC','4h','0.000004590000000','0.000004550000000','0.001468750000000','0.001455950435730','319.9891067538126','319.989106753812621','test'),('2019-03-20 03:59:59','2019-03-20 15:59:59','ZILBTC','4h','0.000004700000000','0.000004650000000','0.001468750000000','0.001453125000000','312.5','312.500000000000000','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ZILBTC','4h','0.000004790000000','0.000004740000000','0.001468750000000','0.001453418580376','306.6283924843424','306.628392484342385','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','ZILBTC','4h','0.000004780000000','0.000004750000000','0.001468750000000','0.001459531903766','307.26987447698747','307.269874476987468','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','ZILBTC','4h','0.000004820000000','0.000004700000000','0.001468750000000','0.001432183609959','304.71991701244815','304.719917012448150','test'),('2019-04-05 11:59:59','2019-04-07 15:59:59','ZILBTC','4h','0.000004790000000','0.000004840000000','0.001468750000000','0.001484081419624','306.6283924843424','306.628392484342385','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','ZILBTC','4h','0.000002450000000','0.000002390000000','0.001468750000000','0.001432780612245','599.4897959183673','599.489795918367349','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','ZILBTC','4h','0.000002470000000','0.000002390000000','0.001468750000000','0.001421179149798','594.6356275303643','594.635627530364332','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','ZILBTC','4h','0.000002490000000','0.000002460000000','0.001468750000000','0.001451054216867','589.8594377510041','589.859437751004066','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ZILBTC','4h','0.000002470000000','0.000002440000000','0.001468750000000','0.001450910931174','594.6356275303643','594.635627530364332','test'),('2019-05-30 03:59:59','2019-05-30 07:59:59','ZILBTC','4h','0.000002450000000','0.000002460000000','0.001468750000000','0.001474744897959','599.4897959183673','599.489795918367349','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','ZILBTC','4h','0.000002430000000','0.000002390000000','0.001468750000000','0.001444573045267','604.4238683127572','604.423868312757236','test'),('2019-06-12 23:59:59','2019-06-13 03:59:59','ZILBTC','4h','0.000002860000000','0.000002850000000','0.001468750000000','0.001463614510490','513.548951048951','513.548951048951039','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','ZILBTC','4h','0.000002880000000','0.000002790000000','0.001468750000000','0.001422851562500','509.9826388888889','509.982638888888914','test'),('2019-06-17 03:59:59','2019-06-17 07:59:59','ZILBTC','4h','0.000002790000000','0.000002850000000','0.001468750000000','0.001500336021505','526.4336917562724','526.433691756272424','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','ZILBTC','4h','0.000001120000000','0.000001120000000','0.001468750000000','0.001468750000000','1311.3839285714284','1311.383928571428442','test'),('2019-07-26 23:59:59','2019-07-27 03:59:59','ZILBTC','4h','0.000001120000000','0.000001090000000','0.001468750000000','0.001429408482143','1311.3839285714284','1311.383928571428442','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','ZILBTC','4h','0.000001130000000','0.000001070000000','0.001468750000000','0.001390763274336','1299.7787610619469','1299.778761061946852','test'),('2019-08-14 11:59:59','2019-08-14 15:59:59','ZILBTC','4h','0.000000830000000','0.000000810000000','0.001468750000000','0.001433358433735','1769.578313253012','1769.578313253012084','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:53:17
