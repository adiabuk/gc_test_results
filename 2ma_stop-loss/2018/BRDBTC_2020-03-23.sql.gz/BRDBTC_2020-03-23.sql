-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-15 19:59:59','2018-06-21 11:59:59','BRDBTC','4h','0.000068330000000','0.000070050000000','0.001467500000000','0.001504439850724','21.476657397921848','21.476657397921848','test'),('2018-06-28 11:59:59','2018-07-06 11:59:59','BRDBTC','4h','0.000067900000000','0.000072450000000','0.001476734962681','0.001575691429252','21.74867397173785','21.748673971737851','test'),('2018-07-15 03:59:59','2018-07-15 07:59:59','BRDBTC','4h','0.000067570000000','0.000065720000000','0.001501474079324','0.001460365198952','22.221016417400474','22.221016417400474','test'),('2018-08-06 11:59:59','2018-08-11 07:59:59','BRDBTC','4h','0.000049390000000','0.000053860000000','0.001501474079324','0.001637363715578','30.400366052318287','30.400366052318287','test'),('2018-08-12 19:59:59','2018-08-13 03:59:59','BRDBTC','4h','0.000055600000000','0.000054540000000','0.001525169268294','0.001496092300229','27.431101947738306','27.431101947738306','test'),('2018-08-16 15:59:59','2018-08-16 19:59:59','BRDBTC','4h','0.000053270000000','0.000051970000000','0.001525169268294','0.001487949068392','28.630923001576868','28.630923001576868','test'),('2018-09-08 11:59:59','2018-09-08 15:59:59','BRDBTC','4h','0.000049770000000','0.000049870000000','0.001525169268294','0.001528233703231','30.64434937299578','30.644349372995780','test'),('2018-09-09 03:59:59','2018-09-09 07:59:59','BRDBTC','4h','0.000051800000000','0.000050450000000','0.001525169268294','0.001485420648367','29.443422167837838','29.443422167837838','test'),('2018-09-10 15:59:59','2018-09-10 19:59:59','BRDBTC','4h','0.000050780000000','0.000050430000000','0.001525169268294','0.001514657073652','30.03484183328082','30.034841833280819','test'),('2018-09-12 11:59:59','2018-09-12 15:59:59','BRDBTC','4h','0.000052680000000','0.000048190000000','0.001525169268294','0.001395176671205','28.951580643394077','28.951580643394077','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','BRDBTC','4h','0.000050190000000','0.000049210000000','0.001525169268294','0.001495389115217','30.38791130292887','30.387911302928870','test'),('2018-09-15 03:59:59','2018-09-15 07:59:59','BRDBTC','4h','0.000050090000000','0.000049730000000','0.001525169268294','0.001514207780241','30.44857792561389','30.448577925613890','test'),('2018-09-16 03:59:59','2018-09-16 15:59:59','BRDBTC','4h','0.000050320000000','0.000049730000000','0.001525169268294','0.001507286719242','30.309405172774245','30.309405172774245','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','BRDBTC','4h','0.000052600000000','0.000052980000000','0.001525169268294','0.001536187601411','28.9956134656654','28.995613465665400','test'),('2018-09-30 03:59:59','2018-09-30 07:59:59','BRDBTC','4h','0.000052760000000','0.000052270000000','0.001525169268294','0.001511004504430','28.907681355079603','28.907681355079603','test'),('2018-10-02 03:59:59','2018-10-03 03:59:59','BRDBTC','4h','0.000052730000000','0.000052150000000','0.001525169268294','0.001508393274067','28.92412797826664','28.924127978266640','test'),('2018-10-03 15:59:59','2018-10-04 07:59:59','BRDBTC','4h','0.000053210000000','0.000052990000000','0.001525169268294','0.001518863362655','28.663207447735385','28.663207447735385','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','BRDBTC','4h','0.000059160000000','0.000058170000000','0.001525169268294','0.001499646658835','25.780413595233263','25.780413595233263','test'),('2018-10-19 11:59:59','2018-10-20 03:59:59','BRDBTC','4h','0.000057650000000','0.000056750000000','0.001525169268294','0.001501359166968','26.45566814039896','26.455668140398959','test'),('2018-10-27 07:59:59','2018-10-27 15:59:59','BRDBTC','4h','0.000059450000000','0.000058450000000','0.001525169268294','0.001499514612814','25.654655480134565','25.654655480134565','test'),('2018-10-29 15:59:59','2018-10-29 19:59:59','BRDBTC','4h','0.000058640000000','0.000057860000000','0.001525169268294','0.001504882228231','26.009025721248292','26.009025721248292','test'),('2018-10-29 23:59:59','2018-10-30 03:59:59','BRDBTC','4h','0.000059180000000','0.000058140000000','0.001525169268294','0.001498366699199','25.771701052619125','25.771701052619125','test'),('2018-11-10 23:59:59','2018-11-11 03:59:59','BRDBTC','4h','0.000054800000000','0.000054690000000','0.001525169268294','0.001522107797135','27.83155599076642','27.831555990766422','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','BRDBTC','4h','0.000057270000000','0.000055070000000','0.001525169268294','0.001466580611227','26.631207757883708','26.631207757883708','test'),('2018-11-14 15:59:59','2018-11-14 19:59:59','BRDBTC','4h','0.000054830000000','0.000052570000000','0.001525169268294','0.001462304366847','27.816328073937623','27.816328073937623','test'),('2018-11-16 15:59:59','2018-11-16 19:59:59','BRDBTC','4h','0.000054180000000','0.000052890000000','0.001525169268294','0.001488855714287','28.15004186589147','28.150041865891470','test'),('2018-11-17 19:59:59','2018-11-18 11:59:59','BRDBTC','4h','0.000054590000000','0.000053360000000','0.001525169268294','0.001490804765638','27.938620045686022','27.938620045686022','test'),('2018-11-18 15:59:59','2018-11-18 23:59:59','BRDBTC','4h','0.000055010000000','0.000054300000000','0.001525169268294','0.001505484298643','27.725309367278676','27.725309367278676','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','BRDBTC','4h','0.000055360000000','0.000054660000000','0.001525169268294','0.001505884252257','27.55002290993497','27.550022909934970','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','BRDBTC','4h','0.000058150000000','0.000057550000000','0.001525169268294','0.001509432354090','26.22819034039553','26.228190340395528','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','BRDBTC','4h','0.000058390000000','0.000057520000000','0.001525169268294','0.001502444533521','26.12038479695153','26.120384796951530','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','BRDBTC','4h','0.000060600000000','0.000057030000000','0.001525169268294','0.001435320187637','25.167809707821778','25.167809707821778','test'),('2018-12-01 11:59:59','2018-12-01 23:59:59','BRDBTC','4h','0.000058200000000','0.000057680000000','0.001525169268294','0.001511542326378','26.20565753082474','26.205657530824741','test'),('2018-12-20 15:59:59','2018-12-20 19:59:59','BRDBTC','4h','0.000054520000000','0.000052670000000','0.001525169268294','0.001473416459300','27.974491348019075','27.974491348019075','test'),('2018-12-23 03:59:59','2018-12-23 19:59:59','BRDBTC','4h','0.000054180000000','0.000054070000000','0.001525169268294','0.001522072763689','28.15004186589147','28.150041865891470','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','BRDBTC','4h','0.000054230000000','0.000053690000000','0.001525169268294','0.001509982261012','28.124087558436287','28.124087558436287','test'),('2018-12-30 07:59:59','2018-12-31 03:59:59','BRDBTC','4h','0.000053630000000','0.000052960000000','0.001525169268294','0.001506115316965','28.438733326384483','28.438733326384483','test'),('2019-01-01 19:59:59','2019-01-01 23:59:59','BRDBTC','4h','0.000053730000000','0.000053190000000','0.001525169268294','0.001509840933939','28.38580436058068','28.385804360580678','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','BRDBTC','4h','0.000054640000000','0.000054330000000','0.001525169268294','0.001516516221567','27.91305395852855','27.913053958528550','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','BRDBTC','4h','0.000054790000000','0.000054130000000','0.001525169268294','0.001506797088753','27.836635668808174','27.836635668808174','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','BRDBTC','4h','0.000053100000000','0.000052900000000','0.001525169268294','0.001519424751276','28.722585090282482','28.722585090282482','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BRDBTC','4h','0.000053030000000','0.000053500000000','0.001525169268294','0.001538686702880','28.76049911925325','28.760499119253250','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','BRDBTC','4h','0.000057610000000','0.000057820000000','0.001525169268294','0.001530728816052','26.47403694313487','26.474036943134870','test'),('2019-02-10 07:59:59','2019-02-10 11:59:59','BRDBTC','4h','0.000055270000000','0.000055660000000','0.001525169268294','0.001535931273263','27.59488453580604','27.594884535806042','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BRDBTC','4h','0.000054610000000','0.000054500000000','0.001525169268294','0.001522097145615','27.928387992931697','27.928387992931697','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','BRDBTC','4h','0.000054620000000','0.000054730000000','0.001525169268294','0.001528240828519','27.923274776528743','27.923274776528743','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','BRDBTC','4h','0.000055520000000','0.000056300000000','0.001525169268294','0.001546596358158','27.47062803123199','27.470628031231989','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','BRDBTC','4h','0.000056400000000','0.000055750000000','0.001525169268294','0.001507591962897','27.042008303085105','27.042008303085105','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','BRDBTC','4h','0.000055610000000','0.000055960000000','0.001525169268294','0.001534768427508','27.426169183492178','27.426169183492178','test'),('2019-03-03 15:59:59','2019-03-04 07:59:59','BRDBTC','4h','0.000056910000000','0.000056240000000','0.001525169268294','0.001507213488822','26.799670853874535','26.799670853874535','test'),('2019-03-05 11:59:59','2019-03-05 15:59:59','BRDBTC','4h','0.000056790000000','0.000056880000000','0.001525169268294','0.001527586335280','26.856299846698363','26.856299846698363','test'),('2019-03-06 07:59:59','2019-03-07 03:59:59','BRDBTC','4h','0.000057040000000','0.000056790000000','0.001525169268294','0.001518484620379','26.73859166013324','26.738591660133238','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','BRDBTC','4h','0.000057140000000','0.000056810000000','0.001525169268294','0.001516360975355','26.69179678498425','26.691796784984248','test'),('2019-03-11 19:59:59','2019-03-11 23:59:59','BRDBTC','4h','0.000058360000000','0.000087000000000','0.001525169268294','0.002273641643961','26.13381199955449','26.133811999554489','test'),('2019-03-20 15:59:59','2019-03-21 07:59:59','BRDBTC','4h','0.000062920000000','0.000062880000000','0.001525169268294','0.001524199675625','24.23981672431659','24.239816724316590','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','BRDBTC','4h','0.000063060000000','0.000063190000000','0.001525169268294','0.001528313448517','24.18600171731684','24.186001717316842','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','BRDBTC','4h','0.000066020000000','0.000063500000000','0.001525169268294','0.001466953173836','23.101624784822782','23.101624784822782','test'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BRDBTC','4h','0.000067170000000','0.000066610000000','0.001525169268294','0.001512453847865','22.706107909691827','22.706107909691827','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','BRDBTC','4h','0.000067920000000','0.000066050000000','0.001525169268294','0.001483177711584','22.455377919522967','22.455377919522967','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BRDBTC','4h','0.000067630000000','0.000062060000000','0.001525169268294','0.001399556480709','22.551667430045836','22.551667430045836','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','BRDBTC','4h','0.000061910000000','0.000063220000000','0.001525169268294','0.001557441465701','24.63526519615571','24.635265196155711','test'),('2019-04-29 11:59:59','2019-05-07 23:59:59','BRDBTC','4h','0.000058900000000','0.000061080000000','0.001525169268294','0.001581618657171','25.894215081392186','25.894215081392186','test'),('2019-05-08 07:59:59','2019-05-09 07:59:59','BRDBTC','4h','0.000063150000000','0.000064800000000','0.001525169268294','0.001565019296682','24.15153235619952','24.151532356199521','test'),('2019-05-10 11:59:59','2019-05-10 15:59:59','BRDBTC','4h','0.000063360000000','0.000064180000000','0.001525169268294','0.001544907885718','24.07148466373106','24.071484663731059','test'),('2019-05-15 19:59:59','2019-05-15 23:59:59','BRDBTC','4h','0.000063990000000','0.000062230000000','0.001525169268294','0.001483220558930','23.834493956774494','23.834493956774494','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','BRDBTC','4h','0.000065870000000','0.000061810000000','0.001525169268294','0.001431163085976','23.15423209798087','23.154232097980870','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','BRDBTC','4h','0.000061970000000','0.000059440000000','0.001525169268294','0.001462902393213','24.611413075584956','24.611413075584956','test'),('2019-05-26 11:59:59','2019-05-26 19:59:59','BRDBTC','4h','0.000060820000000','0.000058810000000','0.001525169268294','0.001474764956731','25.076771921966458','25.076771921966458','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','BRDBTC','4h','0.000056560000000','0.000056010000000','0.001525169268294','0.001510338237573','26.965510401237623','26.965510401237623','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:37:56
