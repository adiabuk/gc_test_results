-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-16 15:59:59','2018-03-17 11:59:59','SNMETH','4h','0.000225710000000','0.000225680000000','0.072144500000000','0.072134910991981','319.6336006379868','319.633600637986774','test'),('2018-03-18 03:59:59','2018-03-18 07:59:59','SNMETH','4h','0.000231460000000','0.000222980000000','0.072144500000000','0.069501341959734','311.6931651257237','311.693165125723681','test'),('2018-03-18 23:59:59','2018-03-19 03:59:59','SNMETH','4h','0.000228850000000','0.000230290000000','0.072144500000000','0.072598457089797','315.2479790255626','315.247979025562586','test'),('2018-04-01 19:59:59','2018-04-01 23:59:59','SNMETH','4h','0.000264780000000','0.000262310000000','0.072144500000000','0.071471500094418','272.46959740161645','272.469597401616454','test'),('2018-04-06 15:59:59','2018-04-09 19:59:59','SNMETH','4h','0.000274230000000','0.000273830000000','0.072144500000000','0.072039267895562','263.08026109470154','263.080261094701541','test'),('2018-04-11 07:59:59','2018-04-11 11:59:59','SNMETH','4h','0.000273080000000','0.000270050000000','0.072144500000000','0.071344009905522','264.18814999267613','264.188149992676131','test'),('2018-04-12 19:59:59','2018-04-12 23:59:59','SNMETH','4h','0.000276860000000','0.000266630000000','0.072144500000000','0.069478754731633','260.581160153146','260.581160153146016','test'),('2018-04-13 11:59:59','2018-04-13 15:59:59','SNMETH','4h','0.000275910000000','0.000272940000000','0.072144500000000','0.071367909209525','261.4783806313653','261.478380631365326','test'),('2018-04-25 15:59:59','2018-04-25 19:59:59','SNMETH','4h','0.000324650000000','0.000322530000000','0.072144500000000','0.071673388526105','222.22239334668103','222.222393346681031','test'),('2018-04-26 15:59:59','2018-05-04 07:59:59','SNMETH','4h','0.000339340000000','0.000362660000000','0.072144500000000','0.077102388076855','212.6024046678847','212.602404667884713','test'),('2018-05-08 23:59:59','2018-05-09 03:59:59','SNMETH','4h','0.000370710000000','0.000357660000000','0.072144500000000','0.069604817431415','194.6116910792803','194.611691079280291','test'),('2018-05-22 03:59:59','2018-05-22 07:59:59','SNMETH','4h','0.000425690000000','0.000416800000000','0.072144500000000','0.070637852897649','169.47661443773637','169.476614437736373','test'),('2018-06-17 11:59:59','2018-06-17 15:59:59','SNMETH','4h','0.000296550000000','0.000316300000000','0.072144500000000','0.076949267745743','243.27937953127633','243.279379531276334','test'),('2018-06-21 15:59:59','2018-06-28 23:59:59','SNMETH','4h','0.000321020000000','0.000348730000000','0.072144500000000','0.078371912918198','224.73521898947106','224.735218989471065','test'),('2018-06-30 19:59:59','2018-06-30 23:59:59','SNMETH','4h','0.000385120000000','0.000372200000000','0.073207694868534','0.070751724216006','190.09060778078066','190.090607780780658','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','SNMETH','4h','0.000363720000000','0.000357580000000','0.073207694868534','0.071971867181047','201.27486766890465','201.274867668904648','test'),('2018-07-02 15:59:59','2018-07-02 19:59:59','SNMETH','4h','0.000358010000000','0.000355580000000','0.073207694868534','0.072710796182658','204.48505591613082','204.485055916130818','test'),('2018-07-02 23:59:59','2018-07-03 07:59:59','SNMETH','4h','0.000360370000000','0.000366300000000','0.073207694868534','0.074412350168838','203.14591910684575','203.145919106845753','test'),('2018-07-18 19:59:59','2018-07-18 23:59:59','SNMETH','4h','0.000285990000000','0.000274280000000','0.073207694868534','0.070210170105743','255.97991142534352','255.979911425343516','test'),('2018-07-26 03:59:59','2018-07-26 07:59:59','SNMETH','4h','0.000258650000000','0.000255060000000','0.073207694868534','0.072191589612095','283.0376758883974','283.037675888397416','test'),('2018-07-26 11:59:59','2018-07-26 15:59:59','SNMETH','4h','0.000262920000000','0.000257440000000','0.073207694868534','0.071681838456395','278.4409511202419','278.440951120241891','test'),('2018-07-27 07:59:59','2018-07-27 11:59:59','SNMETH','4h','0.000257870000000','0.000256280000000','0.073207694868534','0.072756303722449','283.8938025692558','283.893802569255797','test'),('2018-07-27 23:59:59','2018-07-28 07:59:59','SNMETH','4h','0.000260370000000','0.000258850000000','0.073207694868534','0.072780319609479','281.1679335888697','281.167933588869687','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','SNMETH','4h','0.000259730000000','0.000256800000000','0.073207694868534','0.072381842845415','281.86075874382624','281.860758743826239','test'),('2018-07-29 23:59:59','2018-07-30 03:59:59','SNMETH','4h','0.000258000000000','0.000252360000000','0.073207694868534','0.071607340608617','283.75075530439534','283.750755304395341','test'),('2018-07-30 07:59:59','2018-07-30 19:59:59','SNMETH','4h','0.000259650000000','0.000258560000000','0.073207694868534','0.072900371982315','281.94760203556325','281.947602035563250','test'),('2018-08-24 11:59:59','2018-08-29 19:59:59','SNMETH','4h','0.000195960000000','0.000206940000000','0.073207694868534','0.077309656950880','373.58488910254135','373.584889102541354','test'),('2018-09-03 15:59:59','2018-09-05 15:59:59','SNMETH','4h','0.000201780000000','0.000209810000000','0.073207694868534','0.076121054913109','362.8094700591436','362.809470059143621','test'),('2018-09-17 07:59:59','2018-09-17 11:59:59','SNMETH','4h','0.000222590000000','0.000225260000000','0.073207694868534','0.074085832005418','328.89031343966036','328.890313439660360','test'),('2018-09-24 15:59:59','2018-09-25 03:59:59','SNMETH','4h','0.000236720000000','0.000231790000000','0.073207694868534','0.071683049989766','309.2585960989101','309.258596098910118','test'),('2018-09-30 11:59:59','2018-09-30 15:59:59','SNMETH','4h','0.000244410000000','0.000242980000000','0.073207694868534','0.072779369498615','299.5282307128759','299.528230712875882','test'),('2018-09-30 19:59:59','2018-10-01 19:59:59','SNMETH','4h','0.000245400000000','0.000244910000000','0.073207694868534','0.073061518134689','298.3198649899511','298.319864989951100','test'),('2018-10-03 19:59:59','2018-10-03 23:59:59','SNMETH','4h','0.000246880000000','0.000244020000000','0.073207694868534','0.072359614799982','296.53149250054275','296.531492500542754','test'),('2018-10-04 23:59:59','2018-10-06 11:59:59','SNMETH','4h','0.000248710000000','0.000246670000000','0.073207694868534','0.072607221636530','294.3496235315588','294.349623531558791','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','SNMETH','4h','0.000246840000000','0.000247680000000','0.073207694868534','0.073456821686268','296.57954492194943','296.579544921949434','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','SNMETH','4h','0.000247800000000','0.000247460000000','0.073207694868534','0.073107248475252','295.4305684767312','295.430568476731196','test'),('2018-10-13 11:59:59','2018-10-15 07:59:59','SNMETH','4h','0.000258010000000','0.000259240000000','0.073207694868534','0.073556694770430','283.73975763937057','283.739757639370566','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','SNMETH','4h','0.000316350000000','0.000306560000000','0.073207694868534','0.070942155646903','231.41360792961592','231.413607929615921','test'),('2018-11-07 23:59:59','2018-11-08 03:59:59','SNMETH','4h','0.000314890000000','0.000307500000000','0.073207694868534','0.071489619143429','232.48656632009272','232.486566320092720','test'),('2018-11-09 15:59:59','2018-11-09 19:59:59','SNMETH','4h','0.000315240000000','0.000309950000000','0.073207694868534','0.071979206396720','232.22844457725543','232.228444577255431','test'),('2018-11-10 11:59:59','2018-11-10 15:59:59','SNMETH','4h','0.000310410000000','0.000305190000000','0.073207694868534','0.071976599970774','235.84193443682227','235.841934436822271','test'),('2018-11-10 19:59:59','2018-11-11 15:59:59','SNMETH','4h','0.000310550000000','0.000306790000000','0.073207694868534','0.072321328960610','235.73561380947996','235.735613809479958','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','SNMETH','4h','0.000246530000000','0.000234420000000','0.073207694868534','0.069611600337005','296.9524798950797','296.952479895079705','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','SNMETH','4h','0.000240580000000','0.000228820000000','0.073207694868534','0.069629165931573','304.29667831296865','304.296678312968652','test'),('2018-11-28 07:59:59','2018-11-28 19:59:59','SNMETH','4h','0.000237750000000','0.000237980000000','0.073207694868534','0.073278516192697','307.91880070887066','307.918800708870663','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','SNMETH','4h','0.000240170000000','0.000244020000000','0.073207694868534','0.074381237048006','304.8161505122788','304.816150512278796','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','SNMETH','4h','0.000246650000000','0.000236820000000','0.073207694868534','0.070290072162036','296.80800676478407','296.808006764784068','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','SNMETH','4h','0.000155320000000','0.000149750000000','0.073207694868534','0.070582360974523','471.33463088162506','471.334630881625060','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','SNMETH','4h','0.000154170000000','0.000158610000000','0.073207694868534','0.075316030895104','474.850456434676','474.850456434676005','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','SNMETH','4h','0.000161090000000','0.000158190000000','0.073207694868534','0.071889783669088','454.45213773998387','454.452137739983868','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','SNMETH','4h','0.000179940000000','0.000181660000000','0.073207694868534','0.073907468321762','406.84503094661557','406.845030946615566','test'),('2019-01-31 15:59:59','2019-01-31 19:59:59','SNMETH','4h','0.000183000000000','0.000178600000000','0.073207694868534','0.071447509855301','400.0420484619344','400.042048461934428','test'),('2019-02-26 19:59:59','2019-02-27 03:59:59','SNMETH','4h','0.000146330000000','0.000144150000000','0.073207694868534','0.072117058807484','500.29177112372037','500.291771123720366','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','SNMETH','4h','0.000147430000000','0.000145920000000','0.073207694868534','0.072457890763186','496.55901016437633','496.559010164376332','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','SNMETH','4h','0.000145150000000','0.000143300000000','0.073207694868534','0.072274630896734','504.3589036757423','504.358903675742283','test'),('2019-03-06 19:59:59','2019-03-07 03:59:59','SNMETH','4h','0.000151670000000','0.000150260000000','0.073207694868534','0.072527119608004','482.6774897378124','482.677489737812380','test'),('2019-03-07 07:59:59','2019-03-07 11:59:59','SNMETH','4h','0.000150850000000','0.000150050000000','0.073207694868534','0.072819453861608','485.30125865783225','485.301258657832250','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','SNMETH','4h','0.000150800000000','0.000149660000000','0.073207694868534','0.072654267997512','485.4621675632228','485.462167563222806','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','SNMETH','4h','0.000151180000000','0.000152710000000','0.073207694868534','0.073948585020332','484.2419292798915','484.241929279891508','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:50:49
