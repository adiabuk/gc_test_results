-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 19:59:59','2018-03-22 07:59:59','QTUMBTC','4h','0.002178000000000','0.002149000000000','0.001467500000000','0.001447960284665','0.6737832874196511','0.673783287419651','test'),('2018-03-24 19:59:59','2018-03-24 23:59:59','QTUMBTC','4h','0.002090000000000','0.002078000000000','0.001467500000000','0.001459074162679','0.702153110047847','0.702153110047847','test'),('2018-03-30 07:59:59','2018-03-30 11:59:59','QTUMBTC','4h','0.002042000000000','0.002020000000000','0.001467500000000','0.001451689520078','0.7186581782566112','0.718658178256611','test'),('2018-04-02 03:59:59','2018-04-02 07:59:59','QTUMBTC','4h','0.002047000000000','0.002021000000000','0.001467500000000','0.001448860527601','0.7169027845627748','0.716902784562775','test'),('2018-04-02 15:59:59','2018-04-02 19:59:59','QTUMBTC','4h','0.002028000000000','0.002017000000000','0.001467500000000','0.001459540187377','0.7236193293885602','0.723619329388560','test'),('2018-04-03 23:59:59','2018-04-04 03:59:59','QTUMBTC','4h','0.002023000000000','0.001977000000000','0.001467500000000','0.001434131240732','0.7254078101828967','0.725407810182897','test'),('2018-04-09 19:59:59','2018-04-09 23:59:59','QTUMBTC','4h','0.001969000000000','0.001981000000000','0.001467500000000','0.001476443626206','0.74530218384967','0.745302183849670','test'),('2018-04-11 03:59:59','2018-04-11 07:59:59','QTUMBTC','4h','0.001963000000000','0.001972000000000','0.001467500000000','0.001474228222109','0.7475802343352013','0.747580234335201','test'),('2018-04-12 15:59:59','2018-04-13 23:59:59','QTUMBTC','4h','0.001997000000000','0.001984000000000','0.001467500000000','0.001457946920381','0.7348522784176265','0.734852278417626','test'),('2018-04-15 07:59:59','2018-04-15 11:59:59','QTUMBTC','4h','0.001995000000000','0.001999000000000','0.001467500000000','0.001470442355890','0.7355889724310778','0.735588972431078','test'),('2018-04-16 19:59:59','2018-04-16 23:59:59','QTUMBTC','4h','0.002001000000000','0.002069000000000','0.001467500000000','0.001517370064968','0.7333833083458271','0.733383308345827','test'),('2018-04-26 15:59:59','2018-04-27 11:59:59','QTUMBTC','4h','0.002202000000000','0.002211000000000','0.001467500000000','0.001473497956403','0.6664396003633061','0.666439600363306','test'),('2018-05-06 03:59:59','2018-05-06 07:59:59','QTUMBTC','4h','0.002345000000000','0.002305000000000','0.001467500000000','0.001442468017058','0.6257995735607677','0.625799573560768','test'),('2018-05-06 23:59:59','2018-05-07 03:59:59','QTUMBTC','4h','0.002372000000000','0.002280000000000','0.001467500000000','0.001410581787521','0.6186762225969646','0.618676222596965','test'),('2018-06-01 11:59:59','2018-06-04 07:59:59','QTUMBTC','4h','0.001836000000000','0.001841000000000','0.001467500000000','0.001471496459695','0.7992919389978214','0.799291938997821','test'),('2018-07-03 03:59:59','2018-07-03 07:59:59','QTUMBTC','4h','0.001411000000000','0.001410000000000','0.001467500000000','0.001466459957477','1.04004252303331','1.040042523033310','test'),('2018-07-07 07:59:59','2018-07-07 11:59:59','QTUMBTC','4h','0.001409000000000','0.001375000000000','0.001467500000000','0.001432088360539','1.0415188076650106','1.041518807665011','test'),('2018-08-06 03:59:59','2018-08-06 11:59:59','QTUMBTC','4h','0.000940000000000','0.000917000000000','0.001467500000000','0.001431593085106','1.5611702127659575','1.561170212765957','test'),('2018-08-06 19:59:59','2018-08-06 23:59:59','QTUMBTC','4h','0.000930000000000','0.000926000000000','0.001467500000000','0.001461188172043','1.5779569892473118','1.577956989247312','test'),('2018-08-28 11:59:59','2018-08-28 15:59:59','QTUMBTC','4h','0.000669000000000','0.000682000000000','0.001467500000000','0.001496016442451','2.193572496263079','2.193572496263079','test'),('2018-08-31 23:59:59','2018-09-02 03:59:59','QTUMBTC','4h','0.000673000000000','0.000680000000000','0.001467500000000','0.001482763744428','2.1805349182763747','2.180534918276375','test'),('2018-09-21 03:59:59','2018-09-21 07:59:59','QTUMBTC','4h','0.000543000000000','0.000593000000000','0.001467500000000','0.001602628913444','2.7025782688766116','2.702578268876612','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','QTUMBTC','4h','0.000574000000000','0.000555000000000','0.001467500000000','0.001418924216028','2.5566202090592336','2.556620209059234','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','QTUMBTC','4h','0.000563000000000','0.000567000000000','0.001467500000000','0.001477926287744','2.6065719360568385','2.606571936056838','test'),('2018-09-27 15:59:59','2018-09-28 03:59:59','QTUMBTC','4h','0.000596000000000','0.000588000000000','0.001467500000000','0.001447802013423','2.4622483221476514','2.462248322147651','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','QTUMBTC','4h','0.000579000000000','0.000573000000000','0.001467500000000','0.001452292746114','2.5345423143350607','2.534542314335061','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','QTUMBTC','4h','0.000581000000000','0.000575000000000','0.001467500000000','0.001452345094664','2.525817555938038','2.525817555938038','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','QTUMBTC','4h','0.000577000000000','0.000579000000000','0.001467500000000','0.001472586655113','2.5433275563258233','2.543327556325823','test'),('2018-10-10 11:59:59','2018-10-10 15:59:59','QTUMBTC','4h','0.000579000000000','0.000596000000000','0.001467500000000','0.001510587219344','2.5345423143350607','2.534542314335061','test'),('2018-10-17 15:59:59','2018-10-17 23:59:59','QTUMBTC','4h','0.000619000000000','0.000608000000000','0.001467500000000','0.001441421647819','2.3707592891760907','2.370759289176091','test'),('2018-10-26 23:59:59','2018-10-27 15:59:59','QTUMBTC','4h','0.000621000000000','0.000623000000000','0.001467500000000','0.001472226247987','2.363123993558776','2.363123993558776','test'),('2018-10-28 15:59:59','2018-10-29 03:59:59','QTUMBTC','4h','0.000624000000000','0.000617000000000','0.001467500000000','0.001451037660256','2.3517628205128207','2.351762820512821','test'),('2018-11-02 07:59:59','2018-11-02 11:59:59','QTUMBTC','4h','0.000612000000000','0.000611000000000','0.001467500000000','0.001465102124183','2.397875816993464','2.397875816993464','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','QTUMBTC','4h','0.000612000000000','0.000616000000000','0.001467500000000','0.001477091503268','2.397875816993464','2.397875816993464','test'),('2018-11-06 11:59:59','2018-11-06 19:59:59','QTUMBTC','4h','0.000614000000000','0.000615000000000','0.001467500000000','0.001469890065147','2.3900651465798046','2.390065146579805','test'),('2018-12-11 19:59:59','2018-12-11 23:59:59','QTUMBTC','4h','0.000490000000000','0.000478000000000','0.001467500000000','0.001431561224490','2.9948979591836737','2.994897959183674','test'),('2018-12-12 19:59:59','2018-12-12 23:59:59','QTUMBTC','4h','0.000487000000000','0.000478000000000','0.001467500000000','0.001440379876797','3.013347022587269','3.013347022587269','test'),('2018-12-13 07:59:59','2018-12-13 19:59:59','QTUMBTC','4h','0.000545000000000','0.000537000000000','0.001467500000000','0.001445958715596','2.6926605504587156','2.692660550458716','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','QTUMBTC','4h','0.000604000000000','0.000607000000000','0.001467500000000','0.001474788907285','2.4296357615894038','2.429635761589404','test'),('2018-12-29 23:59:59','2018-12-30 03:59:59','QTUMBTC','4h','0.000606000000000','0.000597000000000','0.001467500000000','0.001445705445545','2.421617161716172','2.421617161716172','test'),('2018-12-30 15:59:59','2018-12-30 19:59:59','QTUMBTC','4h','0.000601000000000','0.000600000000000','0.001467500000000','0.001465058236273','2.4417637271214643','2.441763727121464','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','QTUMBTC','4h','0.000600000000000','0.000597000000000','0.001467500000000','0.001460162500000','2.4458333333333337','2.445833333333334','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','QTUMBTC','4h','0.000595000000000','0.000578000000000','0.001467500000000','0.001425571428571','2.466386554621849','2.466386554621849','test'),('2019-01-09 07:59:59','2019-01-10 11:59:59','QTUMBTC','4h','0.000596000000000','0.000587000000000','0.001467500000000','0.001445339765101','2.4622483221476514','2.462248322147651','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','QTUMBTC','4h','0.000630000000000','0.000614000000000','0.001467500000000','0.001430230158730','2.3293650793650795','2.329365079365080','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','QTUMBTC','4h','0.000592000000000','0.000588000000000','0.001467500000000','0.001457584459459','2.4788851351351355','2.478885135135136','test'),('2019-01-14 15:59:59','2019-01-14 19:59:59','QTUMBTC','4h','0.000591000000000','0.000588000000000','0.001467500000000','0.001460050761421','2.4830795262267342','2.483079526226734','test'),('2019-01-26 19:59:59','2019-01-26 23:59:59','QTUMBTC','4h','0.000579000000000','0.000576000000000','0.001467500000000','0.001459896373057','2.5345423143350607','2.534542314335061','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','QTUMBTC','4h','0.000536000000000','0.000528000000000','0.001467500000000','0.001445597014925','2.737873134328358','2.737873134328358','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','QTUMBTC','4h','0.000534000000000','0.000532000000000','0.001467500000000','0.001462003745318','2.74812734082397','2.748127340823970','test'),('2019-02-12 19:59:59','2019-02-13 15:59:59','QTUMBTC','4h','0.000535000000000','0.000530000000000','0.001467500000000','0.001453785046729','2.7429906542056077','2.742990654205608','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','QTUMBTC','4h','0.000544000000000','0.000533000000000','0.001467500000000','0.001437826286765','2.697610294117647','2.697610294117647','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:30:52
