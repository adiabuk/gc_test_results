-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 23:59:59','2018-04-29 03:59:59','YOYOBNB','4h','0.008860000000000','0.008740000000000','0.711908500000000','0.702266398419865','80.35084650112867','80.350846501128672','test'),('2018-04-29 15:59:59','2018-05-02 15:59:59','YOYOBNB','4h','0.008890000000000','0.014580000000000','0.711908500000000','1.167561971878515','80.07969628796401','80.079696287964012','test'),('2018-05-07 15:59:59','2018-05-07 23:59:59','YOYOBNB','4h','0.012740000000000','0.012590000000000','0.823411342574595','0.813716546547422','64.6319735144894','64.631973514489403','test'),('2018-05-12 15:59:59','2018-05-12 19:59:59','YOYOBNB','4h','0.012240000000000','0.010910000000000','0.823411342574595','0.733939358454970','67.27216851099634','67.272168510996337','test'),('2018-05-13 19:59:59','2018-05-13 23:59:59','YOYOBNB','4h','0.011340000000000','0.010720000000000','0.823411342574595','0.778392380282157','72.61122950393255','72.611229503932549','test'),('2018-07-02 11:59:59','2018-07-03 23:59:59','YOYOBNB','4h','0.004416000000000','0.004353000000000','0.823411342574595','0.811664305757974','186.46090185113113','186.460901851131126','test'),('2018-07-07 23:59:59','2018-07-09 07:59:59','YOYOBNB','4h','0.004481000000000','0.004799000000000','0.823411342574595','0.881845800717581','183.75615768234658','183.756157682346583','test'),('2018-07-15 23:59:59','2018-07-16 03:59:59','YOYOBNB','4h','0.004413000000000','0.004440000000000','0.823411342574595','0.828449209388444','186.58765977217197','186.587659772171975','test'),('2018-07-17 03:59:59','2018-07-17 07:59:59','YOYOBNB','4h','0.004444000000000','0.004335000000000','0.823411342574595','0.803215159779674','185.2860806873526','185.286080687352609','test'),('2018-07-17 15:59:59','2018-07-20 19:59:59','YOYOBNB','4h','0.004445000000000','0.004417000000000','0.823411342574595','0.818224499471763','185.24439652971765','185.244396529717648','test'),('2018-07-20 23:59:59','2018-07-21 03:59:59','YOYOBNB','4h','0.004710000000000','0.004443000000000','0.823411342574595','0.776733884301258','174.82194109864014','174.821941098640139','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','YOYOBNB','4h','0.004526000000000','0.004477000000000','0.823411342574595','0.814496814119855','181.92915213755967','181.929152137559669','test'),('2018-07-22 07:59:59','2018-07-22 11:59:59','YOYOBNB','4h','0.004555000000000','0.004449000000000','0.823411342574595','0.804249629662870','180.7708765257069','180.770876525706910','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','YOYOBNB','4h','0.004559000000000','0.004348000000000','0.823411342574595','0.785302153435916','180.61227079942861','180.612270799428615','test'),('2018-08-15 15:59:59','2018-08-15 19:59:59','YOYOBNB','4h','0.002472000000000','0.002255000000000','0.823411342574595','0.751129683457003','333.095203306875','333.095203306875021','test'),('2018-08-16 07:59:59','2018-08-16 11:59:59','YOYOBNB','4h','0.002408000000000','0.002380000000000','0.823411342574595','0.813836792079542','341.94823196619393','341.948231966193930','test'),('2018-08-17 07:59:59','2018-08-22 19:59:59','YOYOBNB','4h','0.002419000000000','0.003226000000000','0.823411342574595','1.098108718952312','340.3932792784601','340.393279278460113','test'),('2018-09-04 15:59:59','2018-09-04 19:59:59','YOYOBNB','4h','0.002515000000000','0.002462000000000','0.823411342574595','0.806059135355329','327.40013621256264','327.400136212562643','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','YOYOBNB','4h','0.002197000000000','0.002151000000000','0.823411342574595','0.806171050467890','374.7889588414178','374.788958841417809','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','YOYOBNB','4h','0.003159000000000','0.003119000000000','0.823411342574595','0.812985114748389','260.6556956551425','260.655695655142495','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','YOYOBNB','4h','0.003046000000000','0.003037000000000','0.823411342574595','0.820978413459962','270.3254571814166','270.325457181416596','test'),('2018-10-20 07:59:59','2018-10-27 23:59:59','YOYOBNB','4h','0.003105000000000','0.003359000000000','0.823411342574595','0.890769307474417','265.1888381882754','265.188838188275383','test'),('2018-11-07 23:59:59','2018-11-08 03:59:59','YOYOBNB','4h','0.003760000000000','0.003691000000000','0.823411342574595','0.808300868468838','218.99237834430718','218.992378344307184','test'),('2018-11-10 07:59:59','2018-11-10 11:59:59','YOYOBNB','4h','0.003758000000000','0.003790000000000','0.823411342574595','0.830422828195241','219.1089256451823','219.108925645182296','test'),('2018-11-12 19:59:59','2018-11-12 23:59:59','YOYOBNB','4h','0.003750000000000','0.003622000000000','0.823411342574595','0.795305568748049','219.576358019892','219.576358019892012','test'),('2018-11-18 19:59:59','2018-11-18 23:59:59','YOYOBNB','4h','0.004330000000000','0.003773000000000','0.823411342574595','0.717489837305762','190.16428234979102','190.164282349791023','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','YOYOBNB','4h','0.003650000000000','0.003474000000000','0.823411342574595','0.783707124412094','225.592148650574','225.592148650573989','test'),('2018-11-21 07:59:59','2018-11-21 11:59:59','YOYOBNB','4h','0.003589000000000','0.003418000000000','0.823411342574595','0.784179428509324','229.4263980425174','229.426398042517405','test'),('2018-11-21 15:59:59','2018-11-21 19:59:59','YOYOBNB','4h','0.003473000000000','0.003424000000000','0.823411342574595','0.811793964000983','237.08935864514686','237.089358645146859','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','YOYOBNB','4h','0.003384000000000','0.003286000000000','0.823411342574595','0.799565505821548','243.32486482700799','243.324864827007985','test'),('2018-11-30 19:59:59','2018-11-30 23:59:59','YOYOBNB','4h','0.003411000000000','0.003319000000000','0.823411342574595','0.801202652009698','241.39881048800794','241.398810488007939','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','YOYOBNB','4h','0.003420000000000','0.003465000000000','0.823411342574595','0.834245702345313','240.7635504604079','240.763550460407913','test'),('2018-12-09 19:59:59','2018-12-09 23:59:59','YOYOBNB','4h','0.003227000000000','0.003122000000000','0.823411342574595','0.796619216460454','255.16310584896036','255.163105848960356','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','YOYOBNB','4h','0.002727000000000','0.002590000000000','0.823411342574595','0.782044509449285','301.94768704605616','301.947687046056160','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','YOYOBNB','4h','0.002426000000000','0.002440000000000','0.823411342574595','0.828163098055240','339.4111057603442','339.411105760344185','test'),('2019-01-15 15:59:59','2019-01-16 19:59:59','YOYOBNB','4h','0.002482000000000','0.002393000000000','0.823411342574595','0.793885311354152','331.7531597802559','331.753159780255885','test'),('2019-01-18 23:59:59','2019-01-19 19:59:59','YOYOBNB','4h','0.002377000000000','0.002262000000000','0.823411342574595','0.783574445479064','346.4078008307089','346.407800830708879','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','YOYOBNB','4h','0.002346000000000','0.002307000000000','0.823411342574595','0.809722918721053','350.98522701389385','350.985227013893848','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','YOYOBNB','4h','0.002459000000000','0.002373000000000','0.823411342574595','0.794613711236077','334.8561783548577','334.856178354857718','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','YOYOBNB','4h','0.002436000000000','0.002329000000000','0.823411342574595','0.787243438775136','338.0177925183067','338.017792518306692','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','YOYOBNB','4h','0.001681000000000','0.001683000000000','0.823411342574595','0.824391011036909','489.83423115680847','489.834231156808471','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','YOYOBNB','4h','0.001658000000000','0.001549000000000','0.823411342574595','0.769278751295566','496.6292777892612','496.629277789261209','test'),('2019-02-20 15:59:59','2019-02-20 23:59:59','YOYOBNB','4h','0.001900000000000','0.001847000000000','0.823411342574595','0.800442499860672','433.37439082873425','433.374390828734249','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','YOYOBNB','4h','0.001720000000000','0.001655000000000','0.823411342574595','0.792294053465671','478.7275247526715','478.727524752671513','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','YOYOBNB','4h','0.001677000000000','0.001665000000000','0.823411342574595','0.817519311500716','491.0025894899195','491.002589489919501','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','YOYOBNB','4h','0.001500000000000','0.001439000000000','0.823411342574595','0.789925947976561','548.94089504973','548.940895049729988','test'),('2019-03-17 15:59:59','2019-03-18 03:59:59','YOYOBNB','4h','0.001331000000000','0.001319000000000','0.823411342574595','0.815987649027717','618.6411289065327','618.641128906532686','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','YOYOBNB','4h','0.001313000000000','0.001320000000000','0.823411342574595','0.827801197409342','627.1221192495012','627.122119249501225','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','YOYOBNB','4h','0.001321000000000','0.001283000000000','0.823411342574595','0.799725020835129','623.3242563017374','623.324256301737364','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','YOYOBNB','4h','0.001356000000000','0.001231000000000','0.823411342574595','0.747506904652896','607.2355033735952','607.235503373595179','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','YOYOBNB','4h','0.001311000000000','0.001281000000000','0.823411342574595','0.804568977755954','628.0788272880205','628.078827288020534','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','YOYOBNB','4h','0.001298000000000','0.001312000000000','0.823411342574595','0.832292512679406','634.3692932007666','634.369293200766606','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','YOYOBNB','4h','0.001307000000000','0.001289000000000','0.823411342574595','0.812071324084662','630.0010272185119','630.001027218511922','test'),('2019-04-05 03:59:59','2019-04-06 23:59:59','YOYOBNB','4h','0.001318000000000','0.001334000000000','0.823411342574595','0.833407231407064','624.743052029283','624.743052029283035','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','YOYOBNB','4h','0.001449000000000','0.001220000000000','0.823411342574595','0.693279391263634','568.261796117733','568.261796117732956','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','YOYOBNB','4h','0.001676000000000','0.001527000000000','0.548940895049730','0.500138870370488','327.5303669747792','327.530366974779213','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:14:11
