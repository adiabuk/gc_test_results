-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-03 11:59:59','2018-12-03 15:59:59','SCETH','4h','0.000026050000000','0.000025860000000','0.072144500000000','0.071618302111324','2769.4625719769674','2769.462571976967411','test'),('2018-12-04 03:59:59','2018-12-04 07:59:59','SCETH','4h','0.000026010000000','0.000026180000000','0.072144500000000','0.072616032679739','2773.7216455209536','2773.721645520953643','test'),('2018-12-05 23:59:59','2018-12-06 03:59:59','SCETH','4h','0.000026100000000','0.000026020000000','0.072144500000000','0.071923367432950','2764.1570881226053','2764.157088122605273','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','SCETH','4h','0.000026400000000','0.000026200000000','0.072144500000000','0.071597950757576','2732.746212121212','2732.746212121212011','test'),('2018-12-11 11:59:59','2018-12-11 15:59:59','SCETH','4h','0.000026770000000','0.000026440000000','0.072144500000000','0.071255158012701','2694.975719088532','2694.975719088532060','test'),('2018-12-19 15:59:59','2018-12-19 19:59:59','SCETH','4h','0.000026810000000','0.000026530000000','0.072144500000000','0.071391032637076','2690.9548675867213','2690.954867586721321','test'),('2019-01-10 07:59:59','2019-01-14 03:59:59','SCETH','4h','0.000019410000000','0.000020000000000','0.072144500000000','0.074337454920144','3716.872746007213','3716.872746007213209','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','SCETH','4h','0.000019680000000','0.000019740000000','0.072144500000000','0.072364452743902','3665.8790650406504','3665.879065040650403','test'),('2019-02-01 15:59:59','2019-02-01 19:59:59','SCETH','4h','0.000021440000000','0.000021360000000','0.072144500000000','0.071875304104478','3364.9486940298507','3364.948694029850685','test'),('2019-02-02 03:59:59','2019-02-02 07:59:59','SCETH','4h','0.000021440000000','0.000021400000000','0.072144500000000','0.072009902052239','3364.9486940298507','3364.948694029850685','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','SCETH','4h','0.000021040000000','0.000020760000000','0.072144500000000','0.071184402091255','3428.921102661597','3428.921102661597160','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','SCETH','4h','0.000021650000000','0.000021010000000','0.072144500000000','0.070011821939954','3332.309468822171','3332.309468822170857','test'),('2019-02-21 19:59:59','2019-02-21 23:59:59','SCETH','4h','0.000018570000000','0.000018210000000','0.072144500000000','0.070745899030695','3885.002692514809','3885.002692514809041','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','SCETH','4h','0.000017900000000','0.000017590000000','0.072144500000000','0.070895070111732','4030.4189944134077','4030.418994413407745','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','SCETH','4h','0.000017750000000','0.000017590000000','0.072144500000000','0.071494183380282','4064.4788732394363','4064.478873239436325','test'),('2019-03-02 07:59:59','2019-03-05 19:59:59','SCETH','4h','0.000017720000000','0.000017830000000','0.072144500000000','0.072592349604966','4071.360045146727','4071.360045146726861','test'),('2019-03-09 15:59:59','2019-03-10 11:59:59','SCETH','4h','0.000017760000000','0.000017920000000','0.072144500000000','0.072794450450450','4062.1903153153153','4062.190315315315274','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','SCETH','4h','0.000019650000000','0.000019430000000','0.072144500000000','0.071336775318066','3671.47582697201','3671.475826972010054','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','SCETH','4h','0.000019520000000','0.000019390000000','0.072144500000000','0.071664029456967','3695.9272540983607','3695.927254098360663','test'),('2019-03-28 03:59:59','2019-03-28 11:59:59','SCETH','4h','0.000019570000000','0.000019520000000','0.072144500000000','0.071960175779254','3686.484414920797','3686.484414920797008','test'),('2019-04-01 07:59:59','2019-04-02 15:59:59','SCETH','4h','0.000019720000000','0.000019910000000','0.072144500000000','0.072839604208925','3658.443204868154','3658.443204868154226','test'),('2019-05-01 11:59:59','2019-05-01 15:59:59','SCETH','4h','0.000017590000000','0.000017120000000','0.072144500000000','0.070216818646959','4101.4496873223425','4101.449687322342470','test'),('2019-05-13 11:59:59','2019-05-13 15:59:59','SCETH','4h','0.000015840000000','0.000015170000000','0.072144500000000','0.069092933396465','4554.57702020202','4554.577020202020321','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','SCETH','4h','0.000014580000000','0.000013860000000','0.072144500000000','0.068581808641975','4948.18244170096','4948.182441700960226','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','SCETH','4h','0.000013530000000','0.000013540000000','0.072144500000000','0.072197821877310','5332.1877309682195','5332.187730968219512','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','SCETH','4h','0.000013400000000','0.000013450000000','0.072144500000000','0.072413695895522','5383.917910447761','5383.917910447760732','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','SCETH','4h','0.000013700000000','0.000013310000000','0.072144500000000','0.070090751459854','5266.021897810219','5266.021897810219343','test'),('2019-06-08 03:59:59','2019-06-08 07:59:59','SCETH','4h','0.000013170000000','0.000013140000000','0.072144500000000','0.071980161731207','5477.942293090357','5477.942293090357452','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','SCETH','4h','0.000013130000000','0.000013270000000','0.072144500000000','0.072913748286367','5494.630616907845','5494.630616907845251','test'),('2019-06-30 19:59:59','2019-06-30 23:59:59','SCETH','4h','0.000010990000000','0.000010700000000','0.072144500000000','0.070240777979982','6564.5586897179255','6564.558689717925517','test'),('2019-07-01 07:59:59','2019-07-01 15:59:59','SCETH','4h','0.000010960000000','0.000010760000000','0.072144500000000','0.070827994525547','6582.5273722627735','6582.527372262773497','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','SCETH','4h','0.000010840000000','0.000010920000000','0.072144500000000','0.072676931734317','6655.39667896679','6655.396678966790205','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','SCETH','4h','0.000010880000000','0.000010650000000','0.072144500000000','0.070619386488971','6630.92830882353','6630.928308823529733','test'),('2019-07-07 03:59:59','2019-07-07 19:59:59','SCETH','4h','0.000010820000000','0.000010310000000','0.072144500000000','0.068743973659889','6667.698706099815','6667.698706099815354','test'),('2019-07-09 07:59:59','2019-07-09 11:59:59','SCETH','4h','0.000010910000000','0.000010660000000','0.072144500000000','0.070491326306141','6612.6947754353805','6612.694775435380507','test'),('2019-07-25 07:59:59','2019-07-25 23:59:59','SCETH','4h','0.000012770000000','0.000012680000000','0.072144500000000','0.071636042286609','5649.530148786218','5649.530148786217978','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','SCETH','4h','0.000012740000000','0.000012550000000','0.072144500000000','0.071068561616954','5662.833594976452','5662.833594976452332','test'),('2019-07-27 03:59:59','2019-07-27 11:59:59','SCETH','4h','0.000012810000000','0.000012910000000','0.072144500000000','0.072707688914910','5631.889149102264','5631.889149102264128','test'),('2019-07-27 23:59:59','2019-07-28 07:59:59','SCETH','4h','0.000012880000000','0.000012740000000','0.072144500000000','0.071360320652174','5601.281055900621','5601.281055900621141','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','SCETH','4h','0.000012890000000','0.000012670000000','0.072144500000000','0.070913174166020','5596.935608999224','5596.935608999224314','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','SCETH','4h','0.000012760000000','0.000012860000000','0.072144500000000','0.072709895768025','5653.957680250784','5653.957680250783596','test'),('2019-08-23 23:59:59','2019-08-26 07:59:59','SCETH','4h','0.000010700000000','0.000011080000000','0.072144500000000','0.074706641121495','6742.476635514019','6742.476635514019108','test'),('2019-08-28 19:59:59','2019-08-28 23:59:59','SCETH','4h','0.000010930000000','0.000010800000000','0.072144500000000','0.071286422689844','6600.594693504117','6600.594693504116549','test'),('2019-08-31 07:59:59','2019-08-31 11:59:59','SCETH','4h','0.000010760000000','0.000010570000000','0.072144500000000','0.070870572955390','6704.8791821561335','6704.879182156133538','test'),('2019-09-22 07:59:59','2019-09-22 15:59:59','SCETH','4h','0.000009260000000','0.000009110000000','0.072144500000000','0.070975852591793','7790.98272138229','7790.982721382290038','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','SCETH','4h','0.000009080000000','0.000009110000000','0.072144500000000','0.072382862885463','7945.429515418503','7945.429515418502888','test'),('2019-10-01 15:59:59','2019-10-01 19:59:59','SCETH','4h','0.000009200000000','0.000009350000000','0.072144500000000','0.073320769021739','7841.79347826087','7841.793478260869961','test'),('2019-10-08 19:59:59','2019-10-09 03:59:59','SCETH','4h','0.000010840000000','0.000010350000000','0.072144500000000','0.068883355627306','6655.39667896679','6655.396678966790205','test'),('2019-10-24 19:59:59','2019-10-24 23:59:59','SCETH','4h','0.000011550000000','0.000011600000000','0.072144500000000','0.072456813852814','6246.2770562770565','6246.277056277056545','test'),('2019-10-30 23:59:59','2019-10-31 03:59:59','SCETH','4h','0.000011210000000','0.000011040000000','0.072144500000000','0.071050426404996','6435.727029438002','6435.727029438002319','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','SCETH','4h','0.000011190000000','0.000011060000000','0.072144500000000','0.071306360142985','6447.229669347632','6447.229669347631898','test'),('2019-11-01 07:59:59','2019-11-01 11:59:59','SCETH','4h','0.000011180000000','0.000011030000000','0.072144500000000','0.071176550536673','6452.996422182468','6452.996422182468450','test'),('2019-11-01 15:59:59','2019-11-04 07:59:59','SCETH','4h','0.000011260000000','0.000011270000000','0.072144500000000','0.072208571492007','6407.149200710479','6407.149200710478908','test'),('2019-11-07 23:59:59','2019-11-08 11:59:59','SCETH','4h','0.000011270000000','0.000011080000000','0.072144500000000','0.070928221827862','6401.464063886424','6401.464063886423901','test'),('2019-11-13 15:59:59','2019-11-14 15:59:59','SCETH','4h','0.000011140000000','0.000011060000000','0.072144500000000','0.071626406642729','6476.166965888689','6476.166965888689447','test'),('2019-11-15 11:59:59','2019-11-16 07:59:59','SCETH','4h','0.000010960000000','0.000010930000000','0.072144500000000','0.071947024178832','6582.5273722627735','6582.527372262773497','test'),('2019-11-28 07:59:59','2019-11-28 11:59:59','SCETH','4h','0.000010550000000','0.000010570000000','0.072144500000000','0.072281266824645','6838.341232227488','6838.341232227488035','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:30:48
