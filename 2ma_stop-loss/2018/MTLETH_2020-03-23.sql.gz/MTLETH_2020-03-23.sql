-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-31 11:59:59','2018-03-31 15:59:59','MTLETH','4h','0.008949000000000','0.008809000000000','0.072144500000000','0.071015856576154','8.061738741758855','8.061738741758855','test'),('2018-04-02 11:59:59','2018-04-02 15:59:59','MTLETH','4h','0.008940000000000','0.008824000000000','0.072144500000000','0.071208396868009','8.069854586129754','8.069854586129754','test'),('2018-04-18 07:59:59','2018-04-18 11:59:59','MTLETH','4h','0.007918000000000','0.007824000000000','0.072144500000000','0.071288023238191','9.111454912856782','9.111454912856782','test'),('2018-04-18 15:59:59','2018-04-18 19:59:59','MTLETH','4h','0.007895000000000','0.008051000000000','0.072144500000000','0.073570027802407','9.137998733375555','9.137998733375555','test'),('2018-04-20 19:59:59','2018-04-20 23:59:59','MTLETH','4h','0.008010000000000','0.007748000000000','0.072144500000000','0.069784717353308','9.006803995006242','9.006803995006242','test'),('2018-04-29 15:59:59','2018-04-30 03:59:59','MTLETH','4h','0.007557000000000','0.007481000000000','0.072144500000000','0.071418949913987','9.54671165806537','9.546711658065369','test'),('2018-05-02 11:59:59','2018-05-03 07:59:59','MTLETH','4h','0.007485000000000','0.007554000000000','0.072144500000000','0.072809559519038','9.638543754175016','9.638543754175016','test'),('2018-05-28 11:59:59','2018-05-28 15:59:59','MTLETH','4h','0.005226000000000','0.004950000000000','0.072144500000000','0.068334342709529','13.804917719096824','13.804917719096824','test'),('2018-05-30 07:59:59','2018-05-30 11:59:59','MTLETH','4h','0.005178000000000','0.005393000000000','0.072144500000000','0.075140071166474','13.932889146388566','13.932889146388566','test'),('2018-07-03 03:59:59','2018-07-03 07:59:59','MTLETH','4h','0.003155000000000','0.003089000000000','0.072144500000000','0.070635296513471','22.866719492868466','22.866719492868466','test'),('2018-07-04 19:59:59','2018-07-04 23:59:59','MTLETH','4h','0.003071000000000','0.003033000000000','0.072144500000000','0.071251796971670','23.49218495604038','23.492184956040379','test'),('2018-07-06 15:59:59','2018-07-06 23:59:59','MTLETH','4h','0.003436000000000','0.003346000000000','0.072144500000000','0.070254801222352','20.99665308498254','20.996653084982540','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','MTLETH','4h','0.002899000000000','0.003061000000000','0.072144500000000','0.076176031217661','24.885995170748533','24.885995170748533','test'),('2018-07-20 19:59:59','2018-07-20 23:59:59','MTLETH','4h','0.003032000000000','0.003160000000000','0.072144500000000','0.075190178100264','23.794360158311346','23.794360158311346','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','MTLETH','4h','0.002938000000000','0.002898000000000','0.072144500000000','0.071162273995916','24.555650102110278','24.555650102110278','test'),('2018-07-26 03:59:59','2018-07-26 07:59:59','MTLETH','4h','0.002902000000000','0.002789000000000','0.072144500000000','0.069335289627843','24.860268780151618','24.860268780151618','test'),('2018-07-29 23:59:59','2018-07-30 03:59:59','MTLETH','4h','0.002847000000000','0.002787000000000','0.072144500000000','0.070624067966280','25.340533895328416','25.340533895328416','test'),('2018-08-24 19:59:59','2018-08-25 07:59:59','MTLETH','4h','0.002163000000000','0.002168000000000','0.072144500000000','0.072311269533056','33.353906611188165','33.353906611188165','test'),('2018-08-31 07:59:59','2018-08-31 23:59:59','MTLETH','4h','0.002322000000000','0.002286000000000','0.072144500000000','0.071025980620155','31.069982773471146','31.069982773471146','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','MTLETH','4h','0.003534000000000','0.003515000000000','0.072144500000000','0.071756626344086','20.414402942840976','20.414402942840976','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','MTLETH','4h','0.003220000000000','0.003105000000000','0.072144500000000','0.069567910714286','22.405124223602485','22.405124223602485','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','MTLETH','4h','0.003225000000000','0.003160000000000','0.072144500000000','0.070690424806202','22.370387596899224','22.370387596899224','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','MTLETH','4h','0.003213000000000','0.003041000000000','0.072144500000000','0.068282422813570','22.453937130407716','22.453937130407716','test'),('2018-10-04 07:59:59','2018-10-05 23:59:59','MTLETH','4h','0.003115000000000','0.003030000000000','0.072144500000000','0.070175869983949','23.160353130016052','23.160353130016052','test'),('2018-10-08 15:59:59','2018-10-08 23:59:59','MTLETH','4h','0.003081000000000','0.003073000000000','0.072144500000000','0.071957172508926','23.415936384290816','23.415936384290816','test'),('2018-10-10 15:59:59','2018-10-10 19:59:59','MTLETH','4h','0.003108000000000','0.003131000000000','0.072144500000000','0.072678387870013','23.212516087516086','23.212516087516086','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','MTLETH','4h','0.003751000000000','0.003537000000000','0.072144500000000','0.068028551452946','19.233404425486537','19.233404425486537','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','MTLETH','4h','0.003389000000000','0.003435000000000','0.072144500000000','0.073123740778991','21.287843021540276','21.287843021540276','test'),('2018-10-27 03:59:59','2018-10-27 15:59:59','MTLETH','4h','0.003436000000000','0.003395000000000','0.072144500000000','0.071283637223516','20.99665308498254','20.996653084982540','test'),('2018-10-30 19:59:59','2018-10-30 23:59:59','MTLETH','4h','0.003422000000000','0.003353000000000','0.072144500000000','0.070689803769725','21.082554061952074','21.082554061952074','test'),('2018-11-28 07:59:59','2018-11-29 15:59:59','MTLETH','4h','0.002440000000000','0.003520000000000','0.072144500000000','0.104077311475410','29.567418032786886','29.567418032786886','test'),('2018-12-10 11:59:59','2018-12-10 15:59:59','MTLETH','4h','0.002769000000000','0.002693000000000','0.074236822664346','0.072199264512490','26.809975682320783','26.809975682320783','test'),('2019-01-12 19:59:59','2019-01-13 19:59:59','MTLETH','4h','0.001817000000000','0.001862000000000','0.074236822664346','0.076075379086963','40.85680939149477','40.856809391494771','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','MTLETH','4h','0.001809000000000','0.001860000000000','0.074236822664346','0.076329734746094','41.037491798975125','41.037491798975125','test'),('2019-02-09 03:59:59','2019-02-09 11:59:59','MTLETH','4h','0.002475000000000','0.002444000000000','0.074710300252473','0.073774534875573','30.185979899989288','30.185979899989288','test'),('2019-02-11 11:59:59','2019-02-11 23:59:59','MTLETH','4h','0.002572000000000','0.002512000000000','0.074710300252473','0.072967447213924','29.04755064248561','29.047550642485611','test'),('2019-02-14 15:59:59','2019-02-15 03:59:59','MTLETH','4h','0.002472000000000','0.002419000000000','0.074710300252473','0.073108501743824','30.222613370741506','30.222613370741506','test'),('2019-02-15 23:59:59','2019-02-16 03:59:59','MTLETH','4h','0.002441000000000','0.002414000000000','0.074710300252473','0.073883926591344','30.606431893680046','30.606431893680046','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','MTLETH','4h','0.002432000000000','0.002435000000000','0.074710300252473','0.074802459339955','30.719695827497116','30.719695827497116','test'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MTLETH','4h','0.002475000000000','0.002427000000000','0.074710300252473','0.073261373217274','30.185979899989086','30.185979899989086','test'),('2019-02-22 15:59:59','2019-02-22 19:59:59','MTLETH','4h','0.002457000000000','0.002460000000000','0.074710300252473','0.074801521620303','30.407122609879117','30.407122609879117','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','MTLETH','4h','0.002400000000000','0.002382000000000','0.074710300252473','0.074149973000579','31.129291771863752','31.129291771863752','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','MTLETH','4h','0.002382000000000','0.002358000000000','0.074710300252473','0.073957551635320','31.364525714724177','31.364525714724177','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','MTLETH','4h','0.002404000000000','0.002363000000000','0.074710300252473','0.073436122918716','31.07749594528827','31.077495945288270','test'),('2019-03-04 23:59:59','2019-03-05 03:59:59','MTLETH','4h','0.002413000000000','0.002353000000000','0.074710300252473','0.072852605260700','30.961583196217568','30.961583196217568','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','MTLETH','4h','0.002322000000000','0.002287000000000','0.074710300252473','0.073584176002328','32.17497857556977','32.174978575569767','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','MTLETH','4h','0.002322000000000','0.002325000000000','0.074710300252473','0.074806825188200','32.17497857556977','32.174978575569767','test'),('2019-03-08 15:59:59','2019-03-10 11:59:59','MTLETH','4h','0.002363000000000','0.002354000000000','0.074710300252473','0.074425749807161','31.616716145777822','31.616716145777822','test'),('2019-03-26 19:59:59','2019-03-26 19:59:59','MTLETH','4h','0.002616000000000','0.002616000000000','0.074710300252473','0.074710300252473','28.55898327693922','28.558983276939220','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:37:03
