-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 15:59:59','2018-06-02 19:59:59','CMTBTC','4h','0.000045130000000','0.000043440000000','0.001467500000000','0.001412545978285','32.51717261245291','32.517172612452910','test'),('2018-06-04 19:59:59','2018-06-05 03:59:59','CMTBTC','4h','0.000044940000000','0.000043190000000','0.001467500000000','0.001410354361371','32.654650645304855','32.654650645304855','test'),('2018-07-02 03:59:59','2018-07-05 23:59:59','CMTBTC','4h','0.000026430000000','0.000029090000000','0.001467500000000','0.001615193908437','55.52402572833901','55.524025728339012','test'),('2018-07-06 19:59:59','2018-07-07 11:59:59','CMTBTC','4h','0.000027850000000','0.000027190000000','0.001476398562023','0.001441410301666','53.012515692037695','53.012515692037695','test'),('2018-07-07 23:59:59','2018-07-08 03:59:59','CMTBTC','4h','0.000027550000000','0.000027490000000','0.001476398562023','0.001473183174955','53.58978446544465','53.589784465444652','test'),('2018-07-08 15:59:59','2018-07-09 03:59:59','CMTBTC','4h','0.000027870000000','0.000027220000000','0.001476398562023','0.001441965154584','52.97447298252602','52.974472982526017','test'),('2018-07-16 19:59:59','2018-07-17 03:59:59','CMTBTC','4h','0.000024550000000','0.000024170000000','0.001476398562023','0.001453545956990','60.138434298289205','60.138434298289205','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','CMTBTC','4h','0.000024170000000','0.000023720000000','0.001476398562023','0.001448910794009','61.08392892110054','61.083928921100537','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','CMTBTC','4h','0.000013840000000','0.000012760000000','0.001476398562023','0.001361188269611','106.67619667796244','106.676196677962437','test'),('2018-08-22 19:59:59','2018-08-22 23:59:59','CMTBTC','4h','0.000012980000000','0.000012840000000','0.001476398562023','0.001460474386470','113.74411109576272','113.744111095762719','test'),('2018-08-23 11:59:59','2018-08-29 03:59:59','CMTBTC','4h','0.000013960000000','0.000014250000000','0.001476398562023','0.001507068732724','105.75920931396848','105.759209313968483','test'),('2018-08-29 19:59:59','2018-08-30 03:59:59','CMTBTC','4h','0.000014450000000','0.000014400000000','0.001476398562023','0.001471289916480','102.1729108666436','102.172910866643605','test'),('2018-09-01 07:59:59','2018-09-01 23:59:59','CMTBTC','4h','0.000014600000000','0.000014410000000','0.001476398562023','0.001457185156079','101.12318917965753','101.123189179657530','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','CMTBTC','4h','0.000014320000000','0.000014290000000','0.001476398562023','0.001473305548276','103.10045824182961','103.100458241829614','test'),('2018-09-17 23:59:59','2018-09-18 07:59:59','CMTBTC','4h','0.000013710000000','0.000013550000000','0.001476398562023','0.001459168527747','107.68771422487237','107.687714224872366','test'),('2018-09-19 03:59:59','2018-09-22 11:59:59','CMTBTC','4h','0.000013590000000','0.000013500000000','0.001476398562023','0.001466621088102','108.63859911869021','108.638599118690209','test'),('2018-09-24 15:59:59','2018-09-25 11:59:59','CMTBTC','4h','0.000013630000000','0.000013500000000','0.001476398562023','0.001462316990999','108.31977711100514','108.319777111005138','test'),('2018-09-28 19:59:59','2018-09-29 03:59:59','CMTBTC','4h','0.000013720000000','0.000014280000000','0.001476398562023','0.001536659727820','107.60922463724489','107.609224637244893','test'),('2018-10-12 15:59:59','2018-10-12 23:59:59','CMTBTC','4h','0.000018230000000','0.000017760000000','0.001476398562023','0.001438334528883','80.98730455419638','80.987304554196385','test'),('2018-10-16 11:59:59','2018-10-16 23:59:59','CMTBTC','4h','0.000018840000000','0.000018190000000','0.001476398562023','0.001425461244331','78.3651041413482','78.365104141348198','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','CMTBTC','4h','0.000017800000000','0.000017530000000','0.001476398562023','0.001454003752374','82.9437394394944','82.943739439494394','test'),('2018-10-21 23:59:59','2018-10-22 03:59:59','CMTBTC','4h','0.000017780000000','0.000017370000000','0.001476398562023','0.001442353375835','83.03703948385828','83.037039483858280','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','CMTBTC','4h','0.000012200000000','0.000011470000000','0.001476398562023','0.001388056680853','121.01627557565574','121.016275575655740','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','CMTBTC','4h','0.000007820000000','0.000007090000000','0.001476398562023','0.001338576189865','188.79777007966754','188.797770079667544','test'),('2018-12-24 07:59:59','2018-12-24 11:59:59','CMTBTC','4h','0.000007190000000','0.000007280000000','0.001476398562023','0.001494879211617','205.34055104631435','205.340551046314346','test'),('2019-01-02 23:59:59','2019-01-03 03:59:59','CMTBTC','4h','0.000006690000000','0.000006650000000','0.001476398562023','0.001467571066884','220.6873784787743','220.687378478774292','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','CMTBTC','4h','0.000006860000000','0.000006750000000','0.001476398562023','0.001452724532603','215.21844927448979','215.218449274489785','test'),('2019-01-13 15:59:59','2019-01-13 19:59:59','CMTBTC','4h','0.000006650000000','0.000006250000000','0.001476398562023','0.001387592633480','222.0148213568421','222.014821356842106','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','CMTBTC','4h','0.000006910000000','0.000006730000000','0.001476398562023','0.001437939554619','213.66115224645444','213.661152246454435','test'),('2019-02-08 11:59:59','2019-02-08 19:59:59','CMTBTC','4h','0.000006810000000','0.000006590000000','0.001476398562023','0.001428702866921','216.7986141002937','216.798614100293690','test'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTBTC','4h','0.000007100000000','0.000006920000000','0.001476398562023','0.001438968739324','207.94345943985917','207.943459439859168','test'),('2019-02-23 03:59:59','2019-02-23 07:59:59','CMTBTC','4h','0.000006930000000','0.000006960000000','0.001476398562023','0.001482789897789','213.04452554444447','213.044525544444468','test'),('2019-02-25 07:59:59','2019-02-25 11:59:59','CMTBTC','4h','0.000006940000000','0.000006750000000','0.001476398562023','0.001435978428481','212.73754496008647','212.737544960086467','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTBTC','4h','0.000006980000000','0.000006940000000','0.001476398562023','0.001467937825278','211.51841862793697','211.518418627936967','test'),('2019-03-04 19:59:59','2019-03-04 23:59:59','CMTBTC','4h','0.000007360000000','0.000007310000000','0.001476398562023','0.001466368680488','200.59763070964675','200.597630709646751','test'),('2019-03-06 03:59:59','2019-03-06 11:59:59','CMTBTC','4h','0.000007350000000','0.000007260000000','0.001476398562023','0.001458320212284','200.87055265619048','200.870552656190483','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','CMTBTC','4h','0.000007300000000','0.000007470000000','0.001476398562023','0.001510780446344','202.24637835931506','202.246378359315059','test'),('2019-03-17 15:59:59','2019-03-18 11:59:59','CMTBTC','4h','0.000008350000000','0.000008200000000','0.001476398562023','0.001449876432166','176.81419904467066','176.814199044670659','test'),('2019-03-19 11:59:59','2019-03-20 03:59:59','CMTBTC','4h','0.000008370000000','0.000008280000000','0.001476398562023','0.001460523308668','176.39170394540025','176.391703945400252','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','CMTBTC','4h','0.000008330000000','0.000008290000000','0.001476398562023','0.001469309013106','177.23872293193278','177.238722931932784','test'),('2019-03-23 07:59:59','2019-03-24 07:59:59','CMTBTC','4h','0.000008460000000','0.000008350000000','0.001476398562023','0.001457201890413','174.51519645661938','174.515196456619378','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','CMTBTC','4h','0.000008330000000','0.000008240000000','0.001476398562023','0.001460447076959','177.23872293193278','177.238722931932784','test'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTBTC','4h','0.000008290000000','0.000008340000000','0.001476398562023','0.001485303257813','178.0939158049457','178.093915804945709','test'),('2019-04-03 07:59:59','2019-04-03 23:59:59','CMTBTC','4h','0.000008840000000','0.000008940000000','0.001476398562023','0.001493099903222','167.01341199355204','167.013411993552040','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','CMTBTC','4h','0.000008060000000','0.000007970000000','0.001476398562023','0.001459912722000','183.17600025099256','183.176000250992558','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','CMTBTC','4h','0.000004970000000','0.000005070000000','0.001476398562023','0.001506104770514','297.06208491408455','297.062084914084551','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','CMTBTC','4h','0.000005090000000','0.000005020000000','0.001476398562023','0.001456094456062','290.0586565860511','290.058656586051086','test'),('2019-05-21 11:59:59','2019-05-21 15:59:59','CMTBTC','4h','0.000004970000000','0.000004930000000','0.001476398562023','0.001464516078626','297.06208491408455','297.062084914084551','test'),('2019-05-21 19:59:59','2019-05-22 03:59:59','CMTBTC','4h','0.000005130000000','0.000005040000000','0.001476398562023','0.001450496832865','287.7969906477583','287.796990647758321','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:23:20
