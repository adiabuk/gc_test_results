-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-14 07:59:59','2019-01-14 11:59:59','DOCKBTC','4h','0.000002250000000','0.000002240000000','0.001467500000000','0.001460977777778','652.2222222222223','652.222222222222285','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','DOCKBTC','4h','0.000002260000000','0.000002390000000','0.001467500000000','0.001551913716814','649.3362831858408','649.336283185840784','test'),('2019-02-08 15:59:59','2019-02-08 19:59:59','DOCKBTC','4h','0.000002490000000','0.000002540000000','0.001486972873648','0.001516831766693','597.1778609028113','597.177860902811290','test'),('2019-02-09 23:59:59','2019-02-10 07:59:59','DOCKBTC','4h','0.000002460000000','0.000002400000000','0.001494437596909','0.001457987899423','607.494958093191','607.494958093191030','test'),('2019-02-12 19:59:59','2019-02-13 07:59:59','DOCKBTC','4h','0.000002470000000','0.000002420000000','0.001494437596909','0.001464185823692','605.0354643356276','605.035464335627580','test'),('2019-02-15 15:59:59','2019-02-15 19:59:59','DOCKBTC','4h','0.000002450000000','0.000002390000000','0.001494437596909','0.001457839125148','609.9745293506123','609.974529350612329','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','DOCKBTC','4h','0.000002430000000','0.000002440000000','0.001494437596909','0.001500587545867','614.9948958473251','614.994895847325097','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','DOCKBTC','4h','0.000002470000000','0.000002380000000','0.001494437596909','0.001439984405119','605.0354643356276','605.035464335627580','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','DOCKBTC','4h','0.000002380000000','0.000002380000000','0.001494437596909','0.001494437596909','627.9149566844537','627.914956684453728','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','DOCKBTC','4h','0.000002500000000','0.000002430000000','0.001494437596909','0.001452593344196','597.7750387635999','597.775038763599923','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DOCKBTC','4h','0.000002640000000','0.000002610000000','0.001494437596909','0.001477455351490','566.0748473140152','566.074847314015187','test'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DOCKBTC','4h','0.000002630000000','0.000002720000000','0.001494437596909','0.001545578046993','568.2272231593156','568.227223159315599','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','DOCKBTC','4h','0.000002820000000','0.000002860000000','0.001494437596909','0.001515635293319','529.9424102514184','529.942410251418437','test'),('2019-04-05 15:59:59','2019-04-06 11:59:59','DOCKBTC','4h','0.000003170000000','0.000003130000000','0.001494437596909','0.001475580340166','471.43141858328073','471.431418583280731','test'),('2019-04-07 07:59:59','2019-04-07 11:59:59','DOCKBTC','4h','0.000003430000000','0.000003360000000','0.001494437596909','0.001463938870441','435.69609239329446','435.696092393294464','test'),('2019-04-19 07:59:59','2019-04-20 07:59:59','DOCKBTC','4h','0.000002830000000','0.000002820000000','0.001494437596909','0.001489156898687','528.0698222293287','528.069822229328679','test'),('2019-05-20 19:59:59','2019-05-20 23:59:59','DOCKBTC','4h','0.000001710000000','0.000001660000000','0.001494437596909','0.001450740591151','873.940115151462','873.940115151462010','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','DOCKBTC','4h','0.000001800000000','0.000001780000000','0.001494437596909','0.001477832734721','830.243109393889','830.243109393888972','test'),('2019-05-25 23:59:59','2019-05-26 19:59:59','DOCKBTC','4h','0.000001850000000','0.000001700000000','0.001494437596909','0.001373266980943','807.8041064372973','807.804106437297264','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','DOCKBTC','4h','0.000001700000000','0.000001700000000','0.001494437596909','0.001494437596909','879.0809393582352','879.080939358235241','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','DOCKBTC','4h','0.000001720000000','0.000001720000000','0.001494437596909','0.001494437596909','868.8590679703489','868.859067970348860','test'),('2019-06-10 19:59:59','2019-06-12 15:59:59','DOCKBTC','4h','0.000001700000000','0.000001710000000','0.001494437596909','0.001503228406303','879.0809393582352','879.080939358235241','test'),('2019-06-13 03:59:59','2019-06-13 07:59:59','DOCKBTC','4h','0.000001710000000','0.000001700000000','0.001494437596909','0.001485698195757','873.940115151462','873.940115151462010','test'),('2019-06-15 19:59:59','2019-06-17 03:59:59','DOCKBTC','4h','0.000001760000000','0.000001720000000','0.001494437596909','0.001460473106070','849.1122709710227','849.112270971022667','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','DOCKBTC','4h','0.000001710000000','0.000001640000000','0.001494437596909','0.001433261788848','873.940115151462','873.940115151462010','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','DOCKBTC','4h','0.000001250000000','0.000001330000000','0.001494437596909','0.001590081603111','1195.5500775271998','1195.550077527199846','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','DOCKBTC','4h','0.000001270000000','0.000001130000000','0.001494437596909','0.001329696444494','1176.7225172511812','1176.722517251181216','test'),('2019-07-23 15:59:59','2019-07-23 19:59:59','DOCKBTC','4h','0.000000970000000','0.000000940000000','0.001494437596909','0.001448217877417','1540.6573164010308','1540.657316401030812','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','DOCKBTC','4h','0.000000940000000','0.000000930000000','0.001494437596909','0.001478539324601','1589.8272307542554','1589.827230754255424','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','DOCKBTC','4h','0.000000940000000','0.000000930000000','0.001494437596909','0.001478539324601','1589.8272307542554','1589.827230754255424','test'),('2019-07-26 03:59:59','2019-07-26 07:59:59','DOCKBTC','4h','0.000000940000000','0.000000940000000','0.001494437596909','0.001494437596909','1589.8272307542554','1589.827230754255424','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','DOCKBTC','4h','0.000000950000000','0.000000940000000','0.001494437596909','0.001478706674836','1573.0922072726316','1573.092207272631640','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','DOCKBTC','4h','0.000000550000000','0.000000560000000','0.001494437596909','0.001521609189580','2717.1592671072726','2717.159267107272626','test'),('2019-08-30 03:59:59','2019-08-30 07:59:59','DOCKBTC','4h','0.000000700000000','0.000000700000000','0.001494437596909','0.001494437596909','2134.910852727143','2134.910852727142810','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','DOCKBTC','4h','0.000000600000000','0.000000590000000','0.001494437596909','0.001469530303627','2490.729328181667','2490.729328181666915','test'),('2019-09-12 23:59:59','2019-09-13 03:59:59','DOCKBTC','4h','0.000000640000000','0.000000670000000','0.001494437596909','0.001564489359264','2335.0587451703127','2335.058745170312704','test'),('2019-09-23 11:59:59','2019-09-23 15:59:59','DOCKBTC','4h','0.000000980000000','0.000000940000000','0.001494437596909','0.001433440143974','1524.9363233765307','1524.936323376530709','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','DOCKBTC','4h','0.000001030000000','0.000001000000000','0.001494437596909','0.001450910288261','1450.9102882611649','1450.910288261164851','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','DOCKBTC','4h','0.000001380000000','0.000001260000000','0.001494437596909','0.001364486501526','1082.9257948615943','1082.925794861594341','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','DOCKBTC','4h','0.000001370000000','0.000001330000000','0.001494437596909','0.001450804382401','1090.8303627072992','1090.830362707299173','test'),('2019-11-12 07:59:59','2019-11-12 11:59:59','DOCKBTC','4h','0.000001180000000','0.000001170000000','0.001494437596909','0.001481772871511','1266.47253975339','1266.472539753390038','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','DOCKBTC','4h','0.000001210000000','0.000001170000000','0.001494437596909','0.001445034701143','1235.0723941396693','1235.072394139669314','test'),('2019-11-25 11:59:59','2019-11-25 15:59:59','DOCKBTC','4h','0.000001140000000','0.000001150000000','0.001494437596909','0.001507546698636','1310.910172727193','1310.910172727192958','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','DOCKBTC','4h','0.000001160000000','0.000001150000000','0.001494437596909','0.001481554514177','1288.3082731974139','1288.308273197413882','test'),('2019-12-02 11:59:59','2019-12-02 15:59:59','DOCKBTC','4h','0.000001150000000','0.000001160000000','0.001494437596909','0.001507432706447','1299.5109538339132','1299.510953833913163','test'),('2019-12-31 19:59:59','2020-01-02 07:59:59','DOCKBTC','4h','0.000001040000000','0.000001030000000','0.001494437596909','0.001480068004631','1436.9592277971153','1436.959227797115318','test'),('2020-01-04 03:59:59','2020-01-04 07:59:59','DOCKBTC','4h','0.000001030000000','0.000001020000000','0.001494437596909','0.001479928494026','1450.9102882611649','1450.910288261164851','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:51:54
