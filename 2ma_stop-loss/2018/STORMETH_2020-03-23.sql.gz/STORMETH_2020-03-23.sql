-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-30 23:59:59','2018-09-02 11:59:59','STORMETH','4h','0.000030460000000','0.000031280000000','0.072144500000000','0.074086669730794','2368.499671700591','2368.499671700591080','test'),('2018-09-16 19:59:59','2018-09-17 03:59:59','STORMETH','4h','0.000033500000000','0.000036430000000','0.072630042432698','0.078982461069349','2168.0609681402534','2168.060968140253408','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','STORMETH','4h','0.000034550000000','0.000033980000000','0.074218147091861','0.072993708775150','2148.1373977383864','2148.137397738386426','test'),('2018-09-24 15:59:59','2018-09-28 15:59:59','STORMETH','4h','0.000034930000000','0.000035400000000','0.074218147091861','0.075216788063323','2124.768024387661','2124.768024387661171','test'),('2018-09-29 19:59:59','2018-09-29 23:59:59','STORMETH','4h','0.000035730000000','0.000035690000000','0.074218147091861','0.074135059325735','2077.1941531447246','2077.194153144724623','test'),('2018-10-02 03:59:59','2018-10-03 03:59:59','STORMETH','4h','0.000036030000000','0.000036210000000','0.074218147091861','0.074588928842528','2059.898614817125','2059.898614817124781','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','STORMETH','4h','0.000038110000000','0.000038100000000','0.074233621251684','0.074214142474132','1947.8777552265615','1947.877755226561476','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','STORMETH','4h','0.000038050000000','0.000038280000000','0.074233621251684','0.074682339593021','1950.949310162523','1950.949310162523034','test'),('2018-10-12 15:59:59','2018-10-12 19:59:59','STORMETH','4h','0.000037980000000','0.000038000000000','0.074340931142630','0.074380078552394','1957.3704882209188','1957.370488220918787','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','STORMETH','4h','0.000038000000000','0.000037950000000','0.074350717995071','0.074252888102972','1956.5978419755654','1956.597841975565416','test'),('2018-10-16 19:59:59','2018-10-17 03:59:59','STORMETH','4h','0.000038000000000','0.000037470000000','0.074350717995071','0.073313721138824','1956.5978419755525','1956.597841975552456','test'),('2018-10-17 19:59:59','2018-10-19 11:59:59','STORMETH','4h','0.000038150000000','0.000037920000000','0.074350717995071','0.073902469891824','1948.904796725321','1948.904796725320921','test'),('2018-10-20 15:59:59','2018-10-27 23:59:59','STORMETH','4h','0.000039270000000','0.000044250000000','0.074350717995071','0.083779456869923','1893.321059207308','1893.321059207308053','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','STORMETH','4h','0.000039380000000','0.000037480000000','0.076312134000886','0.072630238251732','1937.839867975781','1937.839867975781090','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','STORMETH','4h','0.000034770000000','0.000035760000000','0.076312134000886','0.078484955762775','2194.7694564534368','2194.769456453436760','test'),('2018-12-16 11:59:59','2018-12-16 15:59:59','STORMETH','4h','0.000033990000000','0.000032470000000','0.076312134000886','0.072899529008790','2245.1348632211243','2245.134863221124306','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','STORMETH','4h','0.000032390000000','0.000031670000000','0.076312134000886','0.074615785236433','2356.039950629392','2356.039950629392024','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','STORMETH','4h','0.000031990000000','0.000030700000000','0.076312134000886','0.073234839444426','2385.499656170241','2385.499656170240996','test'),('2019-01-08 11:59:59','2019-01-08 15:59:59','STORMETH','4h','0.000021520000000','0.000021500000000','0.076312134000886','0.076241211943264','3546.102881082063','3546.102881082063050','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','STORMETH','4h','0.000022960000000','0.000023310000000','0.076312134000886','0.077475428726509','3323.6992160664636','3323.699216066463578','test'),('2019-02-01 11:59:59','2019-02-01 15:59:59','STORMETH','4h','0.000025260000000','0.000025320000000','0.076312134000886','0.076493397977135','3021.0662708189234','3021.066270818923385','test'),('2019-02-06 11:59:59','2019-02-06 19:59:59','STORMETH','4h','0.000026020000000','0.000025460000000','0.076312134000886','0.074669751409015','2932.8260569133745','2932.826056913374487','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','STORMETH','4h','0.000021130000000','0.000020890000000','0.076312134000886','0.075445361063820','3611.553904443256','3611.553904443256215','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','STORMETH','4h','0.000020770000000','0.000020710000000','0.076312134000886','0.076091684889665','3674.1518536777085','3674.151853677708459','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','STORMETH','4h','0.000021400000000','0.000021300000000','0.076312134000886','0.075955535243873','3565.98757013486','3565.987570134860107','test'),('2019-03-17 15:59:59','2019-03-21 15:59:59','STORMETH','4h','0.000023620000000','0.000024740000000','0.076312134000886','0.079930660253257','3230.8270110451313','3230.827011045131258','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','STORMETH','4h','0.000024440000000','0.000024210000000','0.076312134000886','0.075593975620354','3122.4277414437806','3122.427741443780633','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','STORMETH','4h','0.000024400000000','0.000024750000000','0.076312134000886','0.077406775267292','3127.5464754461477','3127.546475446147724','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','STORMETH','4h','0.000025060000000','0.000024430000000','0.076312134000886','0.074393672531590','3045.176935390503','3045.176935390502877','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','STORMETH','4h','0.000024980000000','0.000024490000000','0.076312134000886','0.074815218642182','3054.9293034782227','3054.929303478222664','test'),('2019-03-31 11:59:59','2019-03-31 19:59:59','STORMETH','4h','0.000024650000000','0.000024870000000','0.076312134000886','0.076993215927060','3095.826937155619','3095.826937155618907','test'),('2019-04-06 03:59:59','2019-04-06 07:59:59','STORMETH','4h','0.000024700000000','0.000024600000000','0.076312134000886','0.076003177992785','3089.5600810075302','3089.560081007530243','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','STORMETH','4h','0.000024840000000','0.000024430000000','0.076312134000886','0.075052553689277','3072.147101484944','3072.147101484943960','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','STORMETH','4h','0.000013860000000','0.000013600000000','0.076312134000886','0.074880593247623','5505.9259740899','5505.925974089899682','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','STORMETH','4h','0.000013840000000','0.000013200000000','0.076312134000886','0.072783249191596','5513.882514514885','5513.882514514884861','test'),('2019-05-23 15:59:59','2019-05-23 19:59:59','STORMETH','4h','0.000013690000000','0.000013950000000','0.076312134000886','0.077761451374168','5574.297589546092','5574.297589546092240','test'),('2019-05-25 15:59:59','2019-05-25 19:59:59','STORMETH','4h','0.000013710000000','0.000013750000000','0.076312134000886','0.076534780635462','5566.165864397229','5566.165864397228688','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','STORMETH','4h','0.000014080000000','0.000013660000000','0.076312134000886','0.074035777730973','5419.895880744744','5419.895880744744318','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','STORMETH','4h','0.000013840000000','0.000013810000000','0.076312134000886','0.076146717525451','5513.882514514885','5513.882514514884861','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','STORMETH','4h','0.000013780000000','0.000013910000000','0.076312134000886','0.077032059793347','5537.890711239913','5537.890711239912889','test'),('2019-05-29 23:59:59','2019-05-30 03:59:59','STORMETH','4h','0.000014230000000','0.000013140000000','0.076312134000886','0.070466721066173','5362.76416028714','5362.764160287139930','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','STORMETH','4h','0.000013990000000','0.000013800000000','0.076312134000886','0.075275729035899','5454.762973615869','5454.762973615868759','test'),('2019-06-03 19:59:59','2019-06-03 23:59:59','STORMETH','4h','0.000014080000000','0.000013540000000','0.076312134000886','0.073385390225284','5419.895880744744','5419.895880744744318','test'),('2019-06-07 07:59:59','2019-06-10 19:59:59','STORMETH','4h','0.000013750000000','0.000013790000000','0.076312134000886','0.076534132936161','5549.973381882618','5549.973381882618014','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','STORMETH','4h','0.000013720000000','0.000013670000000','0.076312134000886','0.076034028556276','5562.108892192857','5562.108892192856729','test'),('2019-07-05 07:59:59','2019-07-05 11:59:59','STORMETH','4h','0.000009900000000','0.000009590000000','0.076312134000886','0.073922562128131','7708.296363725859','7708.296363725859010','test'),('2019-07-05 19:59:59','2019-07-06 03:59:59','STORMETH','4h','0.000009780000000','0.000009830000000','0.076312134000886','0.076702277835246','7802.876687207158','7802.876687207158284','test'),('2019-07-10 11:59:59','2019-07-17 03:59:59','STORMETH','4h','0.000009890000000','0.000010560000000','0.076312134000886','0.081481914565152','7716.0903944273','7716.090394427300453','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','STORMETH','4h','0.000010340000000','0.000010250000000','0.076312134000886','0.075647908463161','7380.283752503483','7380.283752503482901','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','STORMETH','4h','0.000010540000000','0.000010340000000','0.076312134000886','0.074864085917378','7240.240417541366','7240.240417541365787','test'),('2019-07-24 15:59:59','2019-07-24 19:59:59','STORMETH','4h','0.000010550000000','0.000010410000000','0.076312134000886','0.075299461132628','7233.3776304157345','7233.377630415734529','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','STORMETH','4h','0.000010430000000','0.000010320000000','0.076312134000886','0.075507308043063','7316.599616575839','7316.599616575838809','test'),('2019-08-13 03:59:59','2019-08-13 07:59:59','STORMETH','4h','0.000008880000000','0.000008790000000','0.076312134000886','0.075538700210336','8593.70878388356','8593.708783883559590','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','STORMETH','4h','0.000009150000000','0.000008580000000','0.076312134000886','0.071558263358208','8340.12393452306','8340.123934523060598','test'),('2019-08-22 07:59:59','2019-08-22 11:59:59','STORMETH','4h','0.000009450000000','0.000008880000000','0.076312134000886','0.071709179886547','8075.358095331852','8075.358095331852383','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:37:49
