-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-29 15:59:59','2018-06-29 19:59:59','LUNETH','4h','0.015966000000000','0.014885000000000','0.072144500000000','0.067259857353125','4.518633345859952','4.518633345859952','test'),('2018-06-30 11:59:59','2018-07-05 19:59:59','LUNETH','4h','0.015780000000000','0.016000000000000','0.072144500000000','0.073150316856781','4.571894803548796','4.571894803548796','test'),('2018-07-07 07:59:59','2018-07-07 11:59:59','LUNETH','4h','0.016366000000000','0.016699000000000','0.072144500000000','0.073612428540877','4.408193816448736','4.408193816448736','test'),('2018-07-10 19:59:59','2018-07-10 23:59:59','LUNETH','4h','0.017060000000000','0.016680000000000','0.072144500000000','0.070537529894490','4.228868698710434','4.228868698710434','test'),('2018-07-11 11:59:59','2018-07-11 19:59:59','LUNETH','4h','0.017028000000000','0.016911000000000','0.072144500000000','0.071648792547569','4.236815832746065','4.236815832746065','test'),('2018-07-17 19:59:59','2018-07-17 23:59:59','LUNETH','4h','0.016419000000000','0.016445000000000','0.072144500000000','0.072258743072051','4.3939643096412695','4.393964309641269','test'),('2018-07-20 15:59:59','2018-07-20 19:59:59','LUNETH','4h','0.016948000000000','0.016565000000000','0.072144500000000','0.070514139869011','4.256814963417512','4.256814963417512','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','LUNETH','4h','0.016906000000000','0.016667000000000','0.072144500000000','0.071124593724122','4.267390275641784','4.267390275641784','test'),('2018-07-23 11:59:59','2018-07-23 23:59:59','LUNETH','4h','0.016625000000000','0.016411000000000','0.072144500000000','0.071215842977444','4.339518796992481','4.339518796992481','test'),('2018-07-29 11:59:59','2018-07-30 03:59:59','LUNETH','4h','0.016117000000000','0.015898000000000','0.072144500000000','0.071164190668238','4.476298318545635','4.476298318545635','test'),('2018-08-10 03:59:59','2018-08-10 07:59:59','LUNETH','4h','0.013329000000000','0.012781000000000','0.072144500000000','0.069178397066547','5.412596593893015','5.412596593893015','test'),('2018-08-11 07:59:59','2018-08-11 11:59:59','LUNETH','4h','0.013331000000000','0.013033000000000','0.072144500000000','0.070531788200435','5.4117845622984015','5.411784562298402','test'),('2018-08-11 19:59:59','2018-08-11 23:59:59','LUNETH','4h','0.013248000000000','0.012843000000000','0.072144500000000','0.069938995584239','5.445689915458938','5.445689915458938','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','LUNETH','4h','0.011574000000000','0.011629000000000','0.072144500000000','0.072487332858130','6.233324693278037','6.233324693278037','test'),('2018-08-26 11:59:59','2018-08-26 15:59:59','LUNETH','4h','0.011437000000000','0.011406000000000','0.072144500000000','0.071948952260208','6.307991606190435','6.307991606190435','test'),('2018-09-06 15:59:59','2018-09-06 19:59:59','LUNETH','4h','0.012765000000000','0.012616000000000','0.072144500000000','0.071302390285938','5.651743047395221','5.651743047395221','test'),('2018-09-11 03:59:59','2018-09-11 07:59:59','LUNETH','4h','0.012751000000000','0.012564000000000','0.072144500000000','0.071086463649910','5.657948396204219','5.657948396204219','test'),('2018-09-16 23:59:59','2018-09-18 23:59:59','LUNETH','4h','0.012631000000000','0.012764000000000','0.072144500000000','0.072904156282163','5.711701369646109','5.711701369646109','test'),('2018-09-25 11:59:59','2018-09-25 23:59:59','LUNETH','4h','0.013885000000000','0.013486000000000','0.072144500000000','0.070071352322650','5.195858840475333','5.195858840475333','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','LUNETH','4h','0.022672000000000','0.021641000000000','0.072144500000000','0.068863758137791','3.182096859562456','3.182096859562456','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','LUNETH','4h','0.015578000000000','0.014881000000000','0.072144500000000','0.068916568526127','4.631178585184235','4.631178585184235','test'),('2018-12-01 07:59:59','2018-12-02 03:59:59','LUNETH','4h','0.015594000000000','0.015613000000000','0.072144500000000','0.072232402109786','4.626426830832371','4.626426830832371','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','LUNETH','4h','0.016683000000000','0.016271000000000','0.072144500000000','0.070362833992687','4.3244320565845475','4.324432056584548','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','LUNETH','4h','0.015834000000000','0.015037000000000','0.072144500000000','0.068513126594670','4.556302892509789','4.556302892509789','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','LUNETH','4h','0.015863000000000','0.015795000000000','0.072144500000000','0.071835237817563','4.547973271134086','4.547973271134086','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','LUNETH','4h','0.015914000000000','0.015515000000000','0.072144500000000','0.070335674091994','4.533398265678019','4.533398265678019','test'),('2018-12-12 23:59:59','2018-12-13 03:59:59','LUNETH','4h','0.015625000000000','0.015377000000000','0.072144500000000','0.070999422496000','4.617248','4.617248000000000','test'),('2018-12-13 15:59:59','2018-12-13 19:59:59','LUNETH','4h','0.015614000000000','0.015403000000000','0.072144500000000','0.071169574324324','4.620500832586141','4.620500832586141','test'),('2018-12-15 15:59:59','2018-12-15 19:59:59','LUNETH','4h','0.015604000000000','0.015732000000000','0.072144500000000','0.072736303127403','4.623461932837734','4.623461932837734','test'),('2018-12-17 11:59:59','2018-12-17 15:59:59','LUNETH','4h','0.015522000000000','0.015734000000000','0.072144500000000','0.073129852016493','4.647886870248679','4.647886870248679','test'),('2019-01-08 15:59:59','2019-01-08 23:59:59','LUNETH','4h','0.011290000000000','0.011057000000000','0.072144500000000','0.070655601107175','6.390124003542959','6.390124003542959','test'),('2019-01-10 07:59:59','2019-01-10 11:59:59','LUNETH','4h','0.011272000000000','0.011065000000000','0.072144500000000','0.070819632052874','6.400328246983676','6.400328246983676','test'),('2019-01-12 23:59:59','2019-01-14 15:59:59','LUNETH','4h','0.011207000000000','0.011100000000000','0.072144500000000','0.071455692870527','6.437449808155617','6.437449808155617','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','LUNETH','4h','0.011285000000000','0.011210000000000','0.072144500000000','0.071665028356225','6.3929552503322995','6.392955250332299','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','LUNETH','4h','0.011377000000000','0.011314000000000','0.072144500000000','0.071745000703173','6.341258679792564','6.341258679792564','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','LUNETH','4h','0.016988000000000','0.016001000000000','0.072144500000000','0.067952916441017','4.246791853072757','4.246791853072757','test'),('2019-01-29 15:59:59','2019-01-29 23:59:59','LUNETH','4h','0.017599000000000','0.016809000000000','0.072144500000000','0.068906011733621','4.099352235922495','4.099352235922495','test'),('2019-02-02 07:59:59','2019-02-02 15:59:59','LUNETH','4h','0.016885000000000','0.016079000000000','0.072144500000000','0.068700705685520','4.272697660645544','4.272697660645544','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','LUNETH','4h','0.015500000000000','0.014658000000000','0.072144500000000','0.068225424580645','4.654483870967742','4.654483870967742','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','LUNETH','4h','0.014935000000000','0.013647000000000','0.072144500000000','0.065922731268832','4.8305657850686305','4.830565785068631','test'),('2019-02-22 23:59:59','2019-02-23 23:59:59','LUNETH','4h','0.014059000000000','0.013697000000000','0.072144500000000','0.070286877907390','5.13155274201579','5.131552742015790','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','LUNETH','4h','0.014005000000000','0.013366000000000','0.072144500000000','0.068852794501964','5.151338807568726','5.151338807568726','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LUNETH','4h','0.014027000000000','0.013667000000000','0.072144500000000','0.070292926605832','5.143259428245527','5.143259428245527','test'),('2019-03-06 15:59:59','2019-03-15 15:59:59','LUNETH','4h','0.015277000000000','0.018802000000000','0.072144500000000','0.088791051188060','4.722425868953328','4.722425868953328','test'),('2019-04-06 11:59:59','2019-04-06 15:59:59','LUNETH','4h','0.019695000000000','0.018697000000000','0.072144500000000','0.068488739096217','3.663087077938563','3.663087077938563','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','LUNETH','4h','0.016979000000000','0.016571000000000','0.072144500000000','0.070410890482361','4.249042935390777','4.249042935390777','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','LUNETH','4h','0.015539000000000','0.014971000000000','0.072144500000000','0.069507388474162','4.642801982109531','4.642801982109531','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','LUNETH','4h','0.012365000000000','0.011136000000000','0.072144500000000','0.064973809300445','5.834573392640518','5.834573392640518','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','LUNETH','4h','0.010278000000000','0.010130000000000','0.072144500000000','0.071105641661802','7.01931309593306','7.019313095933060','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','LUNETH','4h','0.010154000000000','0.009899000000000','0.072144500000000','0.070332716712626','7.105032499507583','7.105032499507583','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','LUNETH','4h','0.010104000000000','0.009820000000000','0.072144500000000','0.070116685471101','7.140192003167062','7.140192003167062','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','LUNETH','4h','0.010012000000000','0.010255000000000','0.072144500000000','0.073895510137835','7.2058030363563725','7.205803036356373','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','LUNETH','4h','0.010475000000000','0.010160000000000','0.072144500000000','0.069974999522673','6.887303102625299','6.887303102625299','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:51:33
