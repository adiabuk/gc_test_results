-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-28 07:59:59','2019-02-28 11:59:59','GOBNB','4h','0.002018000000000','0.001940000000000','0.711908500000000','0.684391719524282','352.7792368681864','352.779236868186388','test'),('2019-03-02 07:59:59','2019-03-02 23:59:59','GOBNB','4h','0.001965000000000','0.001922000000000','0.711908500000000','0.696329840712468','362.2944020356234','362.294402035623420','test'),('2019-03-03 23:59:59','2019-03-04 03:59:59','GOBNB','4h','0.001956000000000','0.001887000000000','0.711908500000000','0.686795163343558','363.961400817996','363.961400817995980','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','GOBNB','4h','0.001666000000000','0.001683000000000','0.711908500000000','0.719172872448980','427.3160264105643','427.316026410564291','test'),('2019-03-17 11:59:59','2019-03-19 07:59:59','GOBNB','4h','0.001700000000000','0.001648000000000','0.711908500000000','0.690132475294118','418.769705882353','418.769705882352980','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','GOBNB','4h','0.001686000000000','0.001645000000000','0.711908500000000','0.694596371589561','422.247034400949','422.247034400949019','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','GOBNB','4h','0.001693000000000','0.001679000000000','0.711908500000000','0.706021483461311','420.50118133490844','420.501181334908438','test'),('2019-03-22 23:59:59','2019-03-24 11:59:59','GOBNB','4h','0.001690000000000','0.001497000000000','0.711908500000000','0.630607706804734','421.2476331360947','421.247633136094692','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','GOBNB','4h','0.001844000000000','0.001769000000000','0.711908500000000','0.682953436279827','386.0675162689805','386.067516268980512','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GOBNB','4h','0.001688000000000','0.001580000000000','0.711908500000000','0.666359851895735','421.7467417061612','421.746741706161174','test'),('2019-04-04 23:59:59','2019-04-05 03:59:59','GOBNB','4h','0.001664000000000','0.001650000000000','0.711908500000000','0.705918885216346','427.8296274038462','427.829627403846189','test'),('2019-04-05 19:59:59','2019-04-07 23:59:59','GOBNB','4h','0.001695000000000','0.001673000000000','0.711908500000000','0.702668389675516','420.0050147492626','420.005014749262614','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','GOBNB','4h','0.001528000000000','0.001466000000000','0.711908500000000','0.683022160340314','465.9087041884817','465.908704188481693','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','GOBNB','4h','0.000944000000000','0.000924000000000','0.711908500000000','0.696825692796610','754.1403601694916','754.140360169491601','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','GOBNB','4h','0.000848000000000','0.000755000000000','0.711908500000000','0.633833629127359','839.5147405660377','839.514740566037744','test'),('2019-05-23 15:59:59','2019-05-24 07:59:59','GOBNB','4h','0.000825000000000','0.000773000000000','0.711908500000000','0.667036691515152','862.919393939394','862.919393939394013','test'),('2019-05-30 23:59:59','2019-05-31 03:59:59','GOBNB','4h','0.000756000000000','0.000719000000000','0.711908500000000','0.677066417328042','941.6779100529101','941.677910052910079','test'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GOBNB','4h','0.000754000000000','0.000730000000000','0.711908500000000','0.689248282493369','944.1757294429709','944.175729442970919','test'),('2019-06-02 07:59:59','2019-06-02 11:59:59','GOBNB','4h','0.000745000000000','0.000731000000000','0.711908500000000','0.698530353691275','955.5818791946309','955.581879194630915','test'),('2019-06-05 15:59:59','2019-06-05 23:59:59','GOBNB','4h','0.000770000000000','0.000752000000000','0.711908500000000','0.695266483116883','924.5564935064937','924.556493506493666','test'),('2019-06-06 15:59:59','2019-06-06 19:59:59','GOBNB','4h','0.000763000000000','0.000754000000000','0.711908500000000','0.703511152031455','933.0386631716908','933.038663171690814','test'),('2019-06-07 11:59:59','2019-06-09 19:59:59','GOBNB','4h','0.000763000000000','0.000749000000000','0.711908500000000','0.698845958715596','933.0386631716908','933.038663171690814','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','GOBNB','4h','0.000799000000000','0.000780000000000','0.711908500000000','0.694979511889862','890.9993742177722','890.999374217772242','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','GOBNB','4h','0.000758000000000','0.000711000000000','0.711908500000000','0.667766416226913','939.1932717678101','939.193271767810074','test'),('2019-06-28 19:59:59','2019-06-28 23:59:59','GOBNB','4h','0.000574000000000','0.000567000000000','0.711908500000000','0.703226689024390','1240.2587108013938','1240.258710801393818','test'),('2019-06-30 03:59:59','2019-06-30 07:59:59','GOBNB','4h','0.000581000000000','0.000567000000000','0.711908500000000','0.694754078313253','1225.315834767642','1225.315834767641945','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','GOBNB','4h','0.000585000000000','0.000569000000000','0.711908500000000','0.692437498290598','1216.9376068376068','1216.937606837606836','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','GOBNB','4h','0.000564000000000','0.000576000000000','0.711908500000000','0.727055489361702','1262.2491134751772','1262.249113475177182','test'),('2019-07-21 07:59:59','2019-07-22 19:59:59','GOBNB','4h','0.000453200000000','0.000448100000000','0.711908500000000','0.703897173102383','1570.8484112974404','1570.848411297440407','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','GOBNB','4h','0.000443000000000','0.000443200000000','0.711908500000000','0.712229903386005','1607.0169300225737','1607.016930022573661','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','GOBNB','4h','0.000442900000000','0.000435100000000','0.711908500000000','0.699370937796342','1607.3797696997067','1607.379769699706685','test'),('2019-07-26 19:59:59','2019-07-26 23:59:59','GOBNB','4h','0.000450700000000','0.000444400000000','0.711908500000000','0.701957260705569','1579.5617927668072','1579.561792766807230','test'),('2019-08-04 15:59:59','2019-08-05 11:59:59','GOBNB','4h','0.000433200000000','0.000435700000000','0.711908500000000','0.716016928554940','1643.3714219759927','1643.371421975992689','test'),('2019-08-06 15:59:59','2019-08-06 23:59:59','GOBNB','4h','0.000443200000000','0.000435700000000','0.711908500000000','0.699861311935921','1606.2917418772565','1606.291741877256527','test'),('2019-08-07 07:59:59','2019-08-07 11:59:59','GOBNB','4h','0.000449200000000','0.000444500000000','0.711908500000000','0.704459769033838','1584.836375779163','1584.836375779163063','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','GOBNB','4h','0.000417300000000','0.000394300000000','0.711908500000000','0.672670792115984','1705.9872993050565','1705.987299305056467','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','GOBNB','4h','0.000407600000000','0.000398100000000','0.474605666666667','0.463543954612365','1164.3907425580635','1164.390742558063494','test'),('2019-08-18 11:59:59','2019-08-18 15:59:59','GOBNB','4h','0.000398100000000','0.000392000000000','0.526921266271472','0.518847365934230','1323.5902192199742','1323.590219219974188','test'),('2019-08-21 19:59:59','2019-08-27 15:59:59','GOBNB','4h','0.000395000000000','0.000518400000000','0.526921266271472','0.691534137810458','1333.9778892948657','1333.977889294865690','test'),('2019-09-04 03:59:59','2019-09-04 15:59:59','GOBNB','4h','0.000457700000000','0.000447200000000','0.566056009071908','0.553070236523830','1236.7402426740393','1236.740242674039337','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','GOBNB','4h','0.000458200000000','0.000430500000000','0.566056009071908','0.531835687266382','1235.390678899843','1235.390678899842896','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','GOBNB','4h','0.000460000000000','0.000439400000000','0.566056009071908','0.540706544317818','1230.5565414606695','1230.556541460669450','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','GOBNB','4h','0.000461500000000','0.000434000000000','0.566056009071908','0.532325694338479','1226.556899397417','1226.556899397417055','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','GOBNB','4h','0.000458000000000','0.000455700000000','0.566056009071908','0.563213369725040','1235.930150812026','1235.930150812026113','test'),('2019-09-15 07:59:59','2019-09-16 03:59:59','GOBNB','4h','0.000451900000000','0.000435800000000','0.566056009071908','0.545888932846952','1252.6134301215047','1252.613430121504734','test'),('2019-09-16 19:59:59','2019-09-17 03:59:59','GOBNB','4h','0.000464800000000','0.000452900000000','0.566056009071908','0.551563611249284','1217.8485565230378','1217.848556523037814','test'),('2019-09-17 23:59:59','2019-09-18 07:59:59','GOBNB','4h','0.000457800000000','0.000451400000000','0.566056009071908','0.558142600469767','1236.470094084552','1236.470094084552102','test'),('2019-10-10 15:59:59','2019-10-10 19:59:59','GOBNB','4h','0.000643700000000','0.000616800000000','0.566056009071908','0.542400724554222','879.3786066054187','879.378606605418668','test'),('2019-10-11 23:59:59','2019-10-12 07:59:59','GOBNB','4h','0.000632100000000','0.000631000000000','0.566056009071908','0.565070940870707','895.5165465462869','895.516546546286918','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','GOBNB','4h','0.000423400000000','0.000413700000000','0.566056009071908','0.553087791575457','1336.929638809419','1336.929638809418975','test'),('2019-11-15 15:59:59','2019-11-16 03:59:59','GOBNB','4h','0.000409000000000','0.000448100000000','0.566056009071908','0.620170409939173','1384.000022180704','1384.000022180704036','test'),('2020-01-01 19:59:59','2020-01-02 19:59:59','GOBNB','4h','0.001027900000000','0.000999300000000','0.566056009071908','0.550306226155811','550.6917103530577','550.691710353057715','test'),('2020-01-14 07:59:59','2020-01-14 11:59:59','GOBNB','4h','0.001350600000000','0.001324900000000','0.566056009071908','0.555284767080831','419.11447436095665','419.114474360956649','test'),('2020-01-20 07:59:59','2020-01-20 11:59:59','GOBNB','4h','0.001234900000000','0.001170000000000','0.566056009071908','0.536307013210894','458.38206257341324','458.382062573413236','test'),('2020-01-23 19:59:59','2020-01-23 23:59:59','GOBNB','4h','0.001165300000000','0.001138700000000','0.566056009071908','0.553134795786649','485.75989794208186','485.759897942081864','test'),('2020-01-24 03:59:59','2020-01-24 23:59:59','GOBNB','4h','0.001150000000000','0.001154200000000','0.566056009071908','0.568123344061562','492.2226165842678','492.222616584267826','test'),('2020-01-25 07:59:59','2020-01-25 15:59:59','GOBNB','4h','0.001160000000000','0.001164900000000','0.566056009071908','0.568447107730919','487.9793181654379','487.979318165437917','test'),('2020-01-29 07:59:59','2020-01-30 07:59:59','GOBNB','4h','0.001177500000000','0.001160100000000','0.566056009071908','0.557691359765877','480.7269716109622','480.726971610962210','test'),('2020-01-31 15:59:59','2020-02-01 03:59:59','GOBNB','4h','0.001193200000000','0.001176000000000','0.566056009071908','0.557896301264301','474.4016167213443','474.401616721344283','test'),('2020-02-06 19:59:59','2020-02-07 03:59:59','GOBNB','4h','0.001233500000000','0.001202100000000','0.566056009071908','0.551646476291318','458.9023178531885','458.902317853188492','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:01:50
