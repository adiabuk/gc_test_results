-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-13 19:59:59','2018-05-15 15:59:59','BATBTC','4h','0.000044120000000','0.000044400000000','0.001467500000000','0.001476813236627','33.26155938349955','33.261559383499552','test'),('2018-05-16 07:59:59','2018-05-17 19:59:59','BATBTC','4h','0.000045470000000','0.000044860000000','0.001469828309157','0.001450109917501','32.32523222249285','32.325232222492851','test'),('2018-06-03 07:59:59','2018-06-03 23:59:59','BATBTC','4h','0.000039510000000','0.000039330000000','0.001469828309157','0.001463132052623','37.20142518747153','37.201425187471528','test'),('2018-06-15 11:59:59','2018-06-20 03:59:59','BATBTC','4h','0.000035160000000','0.000037380000000','0.001469828309157','0.001562633168268','41.80399059035836','41.803990590358360','test'),('2018-06-30 23:59:59','2018-07-01 03:59:59','BATBTC','4h','0.000038520000000','0.000038130000000','0.001486425861887','0.001471376378862','38.58841801368121','38.588418013681213','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','BATBTC','4h','0.000039790000000','0.000038920000000','0.001486425861887','0.001453925472346','37.356769587509426','37.356769587509426','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','BATBTC','4h','0.000040460000000','0.000039450000000','0.001486425861887','0.001449320322576','36.7381577332427','36.738157733242701','test'),('2018-07-11 03:59:59','2018-07-14 23:59:59','BATBTC','4h','0.000040170000000','0.000050600000000','0.001486425861887','0.001872371137951','37.00338217294','37.003382172940000','test'),('2018-07-23 11:59:59','2018-07-23 15:59:59','BATBTC','4h','0.000050000000000','0.000047310000000','0.001561748327934','0.001477726267891','31.234966558675','31.234966558675001','test'),('2018-07-24 03:59:59','2018-07-24 07:59:59','BATBTC','4h','0.000047170000000','0.000044140000000','0.001561748327934','0.001461428263621','33.10893211647234','33.108932116472339','test'),('2018-08-06 19:59:59','2018-08-06 23:59:59','BATBTC','4h','0.000037990000000','0.000038840000000','0.001561748327934','0.001596691367648','41.10945848733877','41.109458487338770','test'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BATBTC','4h','0.000033910000000','0.000033350000000','0.001561748327934','0.001535957143515','46.055686462223534','46.055686462223534','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','BATBTC','4h','0.000034970000000','0.000034300000000','0.001561748327934','0.001531826355394','44.65966050712039','44.659660507120392','test'),('2018-08-27 19:59:59','2018-08-27 23:59:59','BATBTC','4h','0.000032700000000','0.000032320000000','0.001561748327934','0.001543599570606','47.75988770440367','47.759887704403667','test'),('2018-09-01 11:59:59','2018-09-01 15:59:59','BATBTC','4h','0.000031950000000','0.000032040000000','0.001561748327934','0.001566147618999','48.881011828920194','48.881011828920194','test'),('2018-09-03 03:59:59','2018-09-03 07:59:59','BATBTC','4h','0.000031940000000','0.000031620000000','0.001561748327934','0.001546101506865','48.89631584013775','48.896315840137753','test'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BATBTC','4h','0.000032520000000','0.000029580000000','0.001561748327934','0.001420557058434','48.024241326383766','48.024241326383766','test'),('2018-09-20 23:59:59','2018-09-21 03:59:59','BATBTC','4h','0.000025060000000','0.000024990000000','0.001561748327934','0.001557385902437','62.32036424317638','62.320364243176378','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BATBTC','4h','0.000025750000000','0.000024730000000','0.001561748327934','0.001499884899022','60.65042050229126','60.650420502291261','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','BATBTC','4h','0.000025230000000','0.000025640000000','0.001561748327934','0.001587127512019','61.90044898668252','61.900448986682520','test'),('2018-09-29 11:59:59','2018-10-03 03:59:59','BATBTC','4h','0.000025400000000','0.000025560000000','0.001561748327934','0.001571586112677','61.48615464307086','61.486154643070861','test'),('2018-10-04 03:59:59','2018-10-06 19:59:59','BATBTC','4h','0.000025790000000','0.000026090000000','0.001561748327934','0.001579915233649','60.55635238208608','60.556352382086082','test'),('2018-10-12 03:59:59','2018-10-15 03:59:59','BATBTC','4h','0.000027190000000','0.000027570000000','0.001561748327934','0.001583574895224','57.43833497366679','57.438334973666791','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BATBTC','4h','0.000027350000000','0.000027150000000','0.001561748327934','0.001550327864841','57.102315463766','57.102315463765997','test'),('2018-10-30 07:59:59','2018-10-30 15:59:59','BATBTC','4h','0.000039140000000','0.000038700000000','0.001561748327934','0.001544191627262','39.90159243571794','39.901592435717937','test'),('2018-11-22 03:59:59','2018-11-22 11:59:59','BATBTC','4h','0.000039440000000','0.000040090000000','0.001561748327934','0.001587487080803','39.59808133706896','39.598081337068962','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BATBTC','4h','0.000038660000000','0.000037350000000','0.001561748327934','0.001508828247500','40.397007965183654','40.397007965183654','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','BATBTC','4h','0.000040550000000','0.000039440000000','0.001561748327934','0.001518997633877','38.51413878998767','38.514138789987669','test'),('2018-12-09 07:59:59','2018-12-09 19:59:59','BATBTC','4h','0.000040640000000','0.000039930000000','0.001561748327934','0.001534463846811','38.428846651919294','38.428846651919294','test'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBTC','4h','0.000040180000000','0.000039920000000','0.001561748327934','0.001551642440297','38.86879860462917','38.868798604629170','test'),('2018-12-13 11:59:59','2018-12-13 15:59:59','BATBTC','4h','0.000040020000000','0.000039810000000','0.001561748327934','0.001553553246753','39.024196100299854','39.024196100299854','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','BATBTC','4h','0.000040040000000','0.000039960000000','0.001561748327934','0.001558627951654','39.00470349485514','39.004703494855143','test'),('2018-12-14 03:59:59','2018-12-14 07:59:59','BATBTC','4h','0.000040020000000','0.000039940000000','0.001561748327934','0.001558626392246','39.024196100299854','39.024196100299854','test'),('2018-12-14 15:59:59','2018-12-15 07:59:59','BATBTC','4h','0.000040070000000','0.000039950000000','0.001561748327934','0.001557071267805','38.975501071474916','38.975501071474916','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','BATBTC','4h','0.000040400000000','0.000039980000000','0.001561748327934','0.001545512330465','38.6571368300495','38.657136830049502','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','BATBTC','4h','0.000040010000000','0.000039780000000','0.001561748327934','0.001552770519500','39.03394971092227','39.033949710922272','test'),('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.001561748327934','0.001560876816590','43.57556718565848','43.575567185658478','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035410000000','0.000035120000000','0.001561748327934','0.001548957957556','44.10472544292573','44.104725442925726','test'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034730000000','0.001561748327934','0.001537401344364','44.26724285527211','44.267242855272109','test'),('2019-01-12 07:59:59','2019-01-12 11:59:59','BATBTC','4h','0.000035190000000','0.000035370000000','0.001561748327934','0.001569736810430','44.380458310144924','44.380458310144924','test'),('2019-01-17 23:59:59','2019-01-18 19:59:59','BATBTC','4h','0.000035230000000','0.000034590000000','0.001561748327934','0.001533377083827','44.330068916661936','44.330068916661936','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','BATBTC','4h','0.000034770000000','0.000034510000000','0.001561748327934','0.001550070025798','44.916546676272645','44.916546676272645','test'),('2019-01-19 19:59:59','2019-01-19 23:59:59','BATBTC','4h','0.000034660000000','0.000034900000000','0.001561748327934','0.001572562511393','45.05909774766302','45.059097747663017','test'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.001561748327934','0.001556349025158','44.99418979930856','44.994189799308558','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','BATBTC','4h','0.000034810000000','0.000034050000000','0.001561748327934','0.001527650978631','44.86493329313416','44.864933293134158','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','BATBTC','4h','0.000034240000000','0.000033730000000','0.001561748327934','0.001538486305526','45.611808642932246','45.611808642932246','test'),('2019-02-10 03:59:59','2019-02-11 23:59:59','BATBTC','4h','0.000033160000000','0.000033060000000','0.001561748327934','0.001557038592325','47.097356089686365','47.097356089686365','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','BATBTC','4h','0.000033160000000','0.000032710000000','0.001561748327934','0.001540554517694','47.097356089686365','47.097356089686365','test'),('2019-02-13 07:59:59','2019-02-13 15:59:59','BATBTC','4h','0.000033260000000','0.000032810000000','0.001561748327934','0.001540618239312','46.95575249350572','46.955752493505720','test'),('2019-02-13 19:59:59','2019-02-21 07:59:59','BATBTC','4h','0.000033050000000','0.000035460000000','0.001561748327934','0.001675630732482','47.254109771074134','47.254109771074134','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATBTC','4h','0.000039000000000','0.000037880000000','0.001561748327934','0.001516898119542','40.044828921384614','40.044828921384614','test'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.001561748327934','0.001556299995988','32.04901144949723','32.049011449497229','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000047990000000','0.001561748327934','0.001545007261545','32.194358440197895','32.194358440197895','test'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.001561748327934','0.001555337210003','32.055589653817734','32.055589653817734','test'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BATBTC','4h','0.000062730000000','0.000061180000000','0.001561748327934','0.001523158978208','24.896354661788617','24.896354661788617','test'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.001561748327934','0.001555336771336','26.71481915726993','26.714819157269929','test'),('2019-04-16 07:59:59','2019-04-21 19:59:59','BATBTC','4h','0.000059050000000','0.000081690000000','0.001561748327934','0.002160528719880','26.447897170770535','26.447897170770535','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','BATBTC','4h','0.000073460000000','0.000070790000000','0.001561748327934','0.001504984537632','21.259846555050366','21.259846555050366','test'),('2019-04-27 19:59:59','2019-04-29 11:59:59','BATBTC','4h','0.000074490000000','0.000073500000000','0.001561748327934','0.001540992107708','20.965879016431735','20.965879016431735','test'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.001561748327934','0.001572424758943','21.352862017145203','21.352862017145203','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:20:50
