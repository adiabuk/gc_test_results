-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-13 15:59:59','2018-04-13 19:59:59','REQETH','4h','0.000400880000000','0.000394520000000','0.072144500000000','0.070999920524845','179.9653262821792','179.965326282179205','test'),('2018-04-14 11:59:59','2018-04-14 15:59:59','REQETH','4h','0.000423150000000','0.000415820000000','0.072144500000000','0.070894779605341','170.49391468746308','170.493914687463075','test'),('2018-04-16 15:59:59','2018-04-16 19:59:59','REQETH','4h','0.000400000000000','0.000414450000000','0.072144500000000','0.074750720062500','180.36124999999998','180.361249999999984','test'),('2018-04-23 19:59:59','2018-04-23 23:59:59','REQETH','4h','0.000395230000000','0.000391440000000','0.072197480048172','0.071505152923757','182.67206448946564','182.672064489465640','test'),('2018-04-24 11:59:59','2018-04-24 15:59:59','REQETH','4h','0.000397280000000','0.000396040000000','0.072197480048172','0.071972135517212','181.7294604515002','181.729460451500188','test'),('2018-04-27 15:59:59','2018-04-27 19:59:59','REQETH','4h','0.000394990000000','0.000392890000000','0.072197480048172','0.071813635626538','182.78305792088915','182.783057920889149','test'),('2018-04-28 23:59:59','2018-04-29 11:59:59','REQETH','4h','0.000386310000000','0.000386660000000','0.072197480048172','0.072262891551930','186.89001073793585','186.890010737935853','test'),('2018-04-30 15:59:59','2018-04-30 23:59:59','REQETH','4h','0.000425650000000','0.000412010000000','0.072197480048172','0.069883904040050','169.61700939309762','169.617009393097618','test'),('2018-06-17 03:59:59','2018-06-18 03:59:59','REQETH','4h','0.000205250000000','0.000204000000000','0.072197480048172','0.071757787721447','351.7538613796443','351.753861379644320','test'),('2018-06-19 03:59:59','2018-06-19 07:59:59','REQETH','4h','0.000202690000000','0.000191920000000','0.072197480048172','0.068361243134073','356.19655655519267','356.196556555192672','test'),('2018-07-01 23:59:59','2018-07-02 03:59:59','REQETH','4h','0.000179760000000','0.000176250000000','0.072197480048172','0.070787749546564','401.63262154078774','401.632621540787738','test'),('2018-07-04 11:59:59','2018-07-05 19:59:59','REQETH','4h','0.000173600000000','0.000171220000000','0.072197480048172','0.071207675886221','415.884101659977','415.884101659976977','test'),('2018-07-06 03:59:59','2018-07-06 07:59:59','REQETH','4h','0.000175340000000','0.000169400000000','0.072197480048172','0.069751643208397','411.7570437331584','411.757043733158412','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','REQETH','4h','0.000157540000000','0.000155960000000','0.072197480048172','0.071473397158264','458.28031006837625','458.280310068376252','test'),('2018-07-18 15:59:59','2018-07-20 15:59:59','REQETH','4h','0.000159150000000','0.000164510000000','0.072197480048172','0.074629013149386','453.6442353011122','453.644235301112190','test'),('2018-08-07 19:59:59','2018-08-07 23:59:59','REQETH','4h','0.000140000000000','0.000133590000000','0.072197480048172','0.068891866854538','515.6962860583715','515.696286058371470','test'),('2018-08-09 15:59:59','2018-08-09 19:59:59','REQETH','4h','0.000127600000000','0.000125010000000','0.072197480048172','0.070732029630266','565.8109721643573','565.810972164357281','test'),('2018-08-10 07:59:59','2018-08-11 11:59:59','REQETH','4h','0.000130000000000','0.000125850000000','0.072197480048172','0.069892714338942','555.3652311397847','555.365231139784669','test'),('2018-08-17 07:59:59','2018-08-18 19:59:59','REQETH','4h','0.000127820000000','0.000125760000000','0.072197480048172','0.071033915591129','564.8371150694101','564.837115069410061','test'),('2018-09-06 11:59:59','2018-09-06 15:59:59','REQETH','4h','0.000167780000000','0.000166750000000','0.072197480048172','0.071754260329197','430.3104067717964','430.310406771796409','test'),('2018-09-12 19:59:59','2018-09-12 23:59:59','REQETH','4h','0.000172660000000','0.000169130000000','0.072197480048172','0.070721416660184','418.1482685519055','418.148268551905517','test'),('2018-09-13 11:59:59','2018-09-13 15:59:59','REQETH','4h','0.000173370000000','0.000170270000000','0.072197480048172','0.070906528971577','416.43583115978544','416.435831159785437','test'),('2018-09-17 03:59:59','2018-09-21 19:59:59','REQETH','4h','0.000172870000000','0.000172880000000','0.072197480048172','0.072201656451252','417.6403080243652','417.640308024365197','test'),('2018-09-22 03:59:59','2018-09-22 07:59:59','REQETH','4h','0.000176910000000','0.000174630000000','0.072197480048172','0.071267005487605','408.1028774414787','408.102877441478711','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','REQETH','4h','0.000174600000000','0.000178780000000','0.072197480048172','0.073925919146691','413.5021766791066','413.502176679106583','test'),('2018-10-09 19:59:59','2018-10-10 07:59:59','REQETH','4h','0.000202980000000','0.000199270000000','0.072197480048172','0.070877878851115','355.68765419337865','355.687654193378648','test'),('2018-10-11 15:59:59','2018-10-15 07:59:59','REQETH','4h','0.000215300000000','0.000257200000000','0.072197480048172','0.086247988241476','335.334324422536','335.334324422535985','test'),('2018-10-24 15:59:59','2018-10-24 19:59:59','REQETH','4h','0.000281000000000','0.000278720000000','0.072197480048172','0.071611678430699','256.9305339792598','256.930533979259792','test'),('2018-10-30 23:59:59','2018-10-31 03:59:59','REQETH','4h','0.000272400000000','0.000262780000000','0.072197480048172','0.069647774622095','265.04214408286344','265.042144082863445','test'),('2018-10-31 15:59:59','2018-11-02 23:59:59','REQETH','4h','0.000262550000000','0.000258390000000','0.072197480048172','0.071053539781555','274.9856410137955','274.985641013795487','test'),('2018-11-09 19:59:59','2018-11-10 03:59:59','REQETH','4h','0.000250540000000','0.000248440000000','0.072197480048172','0.071592328343450','288.16747843925924','288.167478439259241','test'),('2018-11-26 19:59:59','2018-11-28 23:59:59','REQETH','4h','0.000215920000000','0.000210000000000','0.072197480048172','0.070218001158374','334.37143408749535','334.371434087495345','test'),('2018-11-30 15:59:59','2018-12-02 11:59:59','REQETH','4h','0.000218570000000','0.000217300000000','0.072197480048172','0.071777976915715','330.31742713168325','330.317427131683246','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','REQETH','4h','0.000220470000000','0.000223340000000','0.072197480048172','0.073137321150083','327.47076721627434','327.470767216274339','test'),('2018-12-08 03:59:59','2018-12-08 19:59:59','REQETH','4h','0.000222710000000','0.000228140000000','0.072197480048172','0.073957761655022','324.17709150092946','324.177091500929464','test'),('2018-12-15 23:59:59','2018-12-16 03:59:59','REQETH','4h','0.000229850000000','0.000227160000000','0.072197480048172','0.071352532380869','314.1069395178247','314.106939517824685','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','REQETH','4h','0.000228290000000','0.000227240000000','0.072197480048172','0.071865414017901','316.2533621629156','316.253362162915607','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','REQETH','4h','0.000229030000000','0.000226770000000','0.072197480048172','0.071485056763411','315.23154192975596','315.231541929755963','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','REQETH','4h','0.000228060000000','0.000225050000000','0.072197480048172','0.071244597407880','316.57230574485664','316.572305744856635','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','REQETH','4h','0.000164250000000','0.000162870000000','0.072197480048172','0.071590889348224','439.5584782232694','439.558478223269390','test'),('2019-01-11 07:59:59','2019-01-11 19:59:59','REQETH','4h','0.000165670000000','0.000166990000000','0.072197480048172','0.072772724049280','435.79090993041586','435.790909930415864','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','REQETH','4h','0.000166970000000','0.000166210000000','0.072197480048172','0.071868857631950','432.3979160817632','432.397916081763185','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','REQETH','4h','0.000166430000000','0.000166220000000','0.072197480048172','0.072106381863890','433.8008775351319','433.800877535131917','test'),('2019-01-29 19:59:59','2019-01-30 23:59:59','REQETH','4h','0.000196000000000','0.000193090000000','0.072197480048172','0.071125568482151','368.3544900416939','368.354490041693907','test'),('2019-02-07 19:59:59','2019-02-08 11:59:59','REQETH','4h','0.000187860000000','0.000183930000000','0.072197480048172','0.070687120756203','384.3153414679655','384.315341467965482','test'),('2019-02-28 15:59:59','2019-03-04 07:59:59','REQETH','4h','0.000155840000000','0.000159190000000','0.072197480048172','0.073749466432678','463.2795177629107','463.279517762910700','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','REQETH','4h','0.000156890000000','0.000156930000000','0.072197480048172','0.072215887207340','460.1789792094589','460.178979209458873','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','REQETH','4h','0.000158460000000','0.000156790000000','0.072197480048172','0.071436595334803','455.61958884369557','455.619588843695567','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','REQETH','4h','0.000186950000000','0.000188750000000','0.072197480048172','0.072892614918922','386.18603930554696','386.186039305546956','test'),('2019-04-03 07:59:59','2019-04-03 11:59:59','REQETH','4h','0.000194250000000','0.000193740000000','0.072197480048172','0.072007926818702','371.6729989609884','371.672998960988423','test'),('2019-04-04 19:59:59','2019-04-04 23:59:59','REQETH','4h','0.000191890000000','0.000195660000000','0.072197480048172','0.073615920299262','376.2440984322893','376.244098432289320','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','REQETH','4h','0.000196970000000','0.000192160000000','0.072197480048172','0.070434420297795','366.5404886438138','366.540488643813774','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:48:40
