-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-24 11:59:59','2018-05-29 23:59:59','CMTBNB','4h','0.022500000000000','0.032330000000000','0.711908500000000','1.022933413555556','31.640377777777783','31.640377777777783','test'),('2018-07-01 03:59:59','2018-07-01 07:59:59','CMTBNB','4h','0.011060000000000','0.011080000000000','0.789664728388889','0.791092693539682','71.39825753968255','71.398257539682547','test'),('2018-07-16 15:59:59','2018-07-17 15:59:59','CMTBNB','4h','0.012160000000000','0.012240000000000','0.790021719676587','0.795219230990249','64.96889142077198','64.968891420771982','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','CMTBNB','4h','0.012460000000000','0.012240000000000','0.791321097505003','0.777349135911817','63.50891633266475','63.508916332664747','test'),('2018-07-24 07:59:59','2018-07-24 11:59:59','CMTBNB','4h','0.012500000000000','0.012150000000000','0.791321097505003','0.769164106774863','63.305687800400236','63.305687800400236','test'),('2018-07-24 19:59:59','2018-07-24 23:59:59','CMTBNB','4h','0.012220000000000','0.012060000000000','0.791321097505003','0.780960101138325','64.7562272917351','64.756227291735101','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','CMTBNB','4h','0.007920000000000','0.007790000000000','0.791321097505003','0.778332241106562','99.91427998800543','99.914279988005433','test'),('2018-08-16 03:59:59','2018-08-16 07:59:59','CMTBNB','4h','0.007940000000000','0.007830000000000','0.791321097505003','0.780358210763750','99.66260673866537','99.662606738665374','test'),('2018-08-17 03:59:59','2018-08-18 15:59:59','CMTBNB','4h','0.008010000000000','0.008080000000000','0.791321097505003','0.798236512839004','98.79164762858964','98.791647628589644','test'),('2018-08-21 15:59:59','2018-08-21 19:59:59','CMTBNB','4h','0.008180000000000','0.008350000000000','0.791321097505003','0.807766645986158','96.73852047738423','96.738520477384228','test'),('2018-08-27 23:59:59','2018-08-28 03:59:59','CMTBNB','4h','0.009170000000000','0.009480000000000','0.791321097505003','0.818072410506808','86.2945580703384','86.294558070338397','test'),('2018-08-29 07:59:59','2018-08-29 11:59:59','CMTBNB','4h','0.009270000000000','0.009150000000000','0.791321097505003','0.781077458702349','85.36365668878133','85.363656688781333','test'),('2018-08-30 23:59:59','2018-08-31 07:59:59','CMTBNB','4h','0.009220000000000','0.009050000000000','0.791321097505003','0.776730578353609','85.82658324349272','85.826583243492720','test'),('2018-09-01 15:59:59','2018-09-01 23:59:59','CMTBNB','4h','0.009270000000000','0.009070000000000','0.791321097505003','0.774248366167247','85.36365668878133','85.363656688781333','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','CMTBNB','4h','0.009230000000000','0.009410000000000','0.791321097505003','0.806753144910301','85.7335966961','85.733596696099994','test'),('2018-09-03 15:59:59','2018-09-03 23:59:59','CMTBNB','4h','0.009240000000000','0.009130000000000','0.791321097505003','0.781900608248991','85.64081141829037','85.640811418290369','test'),('2018-09-17 19:59:59','2018-09-18 11:59:59','CMTBNB','4h','0.008660000000000','0.008480000000000','0.791321097505003','0.774873314877878','91.3765701506932','91.376570150693198','test'),('2018-09-19 03:59:59','2018-09-22 11:59:59','CMTBNB','4h','0.008770000000000','0.008920000000000','0.791321097505003','0.804855665877380','90.23045581584984','90.230455815849837','test'),('2018-09-28 23:59:59','2018-10-04 03:59:59','CMTBNB','4h','0.009260000000000','0.009790000000000','0.791321097505003','0.836612693798486','85.45584206317528','85.455842063175282','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','CMTBNB','4h','0.011390000000000','0.011360000000000','0.791321097505003','0.789236845272769','69.47507440781413','69.475074407814134','test'),('2018-10-12 15:59:59','2018-10-12 19:59:59','CMTBNB','4h','0.012120000000000','0.011810000000000','0.791321097505003','0.771081036430205','65.29051959612235','65.290519596122351','test'),('2018-10-16 11:59:59','2018-10-16 19:59:59','CMTBNB','4h','0.012420000000000','0.012280000000000','0.791321097505003','0.782401213958248','63.713453905394765','63.713453905394765','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','CMTBNB','4h','0.011780000000000','0.011370000000000','0.791321097505003','0.763779361513742','67.1749658323432','67.174965832343204','test'),('2018-10-21 03:59:59','2018-10-21 07:59:59','CMTBNB','4h','0.011640000000000','0.011550000000000','0.791321097505003','0.785202635410892','67.98291215678721','67.982912156787208','test'),('2018-10-21 11:59:59','2018-10-21 15:59:59','CMTBNB','4h','0.011870000000000','0.011640000000000','0.791321097505003','0.775988001260171','66.66563584709377','66.665635847093768','test'),('2018-11-12 11:59:59','2018-11-12 19:59:59','CMTBNB','4h','0.009730000000000','0.009610000000000','0.791321097505003','0.781561741728991','81.32796480010308','81.327964800103075','test'),('2018-11-22 23:59:59','2018-11-23 03:59:59','CMTBNB','4h','0.008500000000000','0.008480000000000','0.791321097505003','0.789459165510874','93.09659970647094','93.096599706470940','test'),('2018-11-23 23:59:59','2018-11-24 23:59:59','CMTBNB','4h','0.008540000000000','0.008400000000000','0.791321097505003','0.778348620496724','92.66055005913384','92.660550059133840','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','CMTBNB','4h','0.008860000000000','0.008580000000000','0.791321097505003','0.766313207290398','89.31389362358951','89.313893623589507','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','CMTBNB','4h','0.009710000000000','0.009110000000000','0.791321097505003','0.742423810326527','81.49547863079331','81.495478630793315','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','CMTBNB','4h','0.005590000000000','0.005040000000000','0.791321097505003','0.713463028877498','141.5601247772814','141.560124777281402','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','CMTBNB','4h','0.005070000000000','0.005010000000000','0.791321097505003','0.781956350788967','156.07911193392565','156.079111933925645','test'),('2019-01-05 15:59:59','2019-01-06 07:59:59','CMTBNB','4h','0.004440000000000','0.004340000000000','0.791321097505003','0.773498550263899','178.2254724110367','178.225472411036691','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','CMTBNB','4h','0.004370000000000','0.004260000000000','0.791321097505003','0.771402259810369','181.0803426784904','181.080342678490410','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','CMTBNB','4h','0.004210000000000','0.004080000000000','0.791321097505003','0.766886004232877','187.96225593943063','187.962255939430634','test'),('2019-01-19 07:59:59','2019-01-19 11:59:59','CMTBNB','4h','0.004450000000000','0.004280000000000','0.791321097505003','0.761090853330655','177.82496573146136','177.824965731461361','test'),('2019-01-21 03:59:59','2019-01-22 07:59:59','CMTBNB','4h','0.004160000000000','0.004260000000000','0.791321097505003','0.810343239271950','190.2214176694719','190.221417669471890','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','CMTBNB','4h','0.004200000000000','0.004160000000000','0.791321097505003','0.783784706100193','188.40978512023884','188.409785120238837','test'),('2019-01-24 19:59:59','2019-01-25 07:59:59','CMTBNB','4h','0.004210000000000','0.004140000000000','0.791321097505003','0.778163739589243','187.96225593943063','187.962255939430634','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','CMTBNB','4h','0.002940000000000','0.002840000000000','0.791321097505003','0.764405413916397','269.15683588605543','269.156835886055433','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','CMTBNB','4h','0.002760000000000','0.002710000000000','0.791321097505003','0.776985570376289','286.7105425742765','286.710542574276474','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTBNB','4h','0.002760000000000','0.002730000000000','0.791321097505003','0.782719781227775','286.7105425742765','286.710542574276474','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','CMTBNB','4h','0.002330000000000','0.002330000000000','0.791321097505003','0.791321097505003','339.62278862875667','339.622788628756666','test'),('2019-03-13 03:59:59','2019-03-13 07:59:59','CMTBNB','4h','0.002320000000000','0.002270000000000','0.791321097505003','0.774266763507050','341.086679959053','341.086679959053015','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','CMTBNB','4h','0.002280000000000','0.002240000000000','0.791321097505003','0.777438271232985','347.0706568004399','347.070656800439906','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','CMTBNB','4h','0.002230000000000','0.002260000000000','0.791321097505003','0.801966672807761','354.85251009192956','354.852510091929560','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','CMTBNB','4h','0.002130000000000','0.002100000000000','0.791321097505003','0.780175729934510','371.5122523497667','371.512252349766698','test'),('2019-04-10 03:59:59','2019-04-10 11:59:59','CMTBNB','4h','0.002430000000000','0.002380000000000','0.791321097505003','0.775038770395847','325.6465421831288','325.646542183128815','test'),('2019-05-06 19:59:59','2019-05-06 23:59:59','CMTBNB','4h','0.001430000000000','0.001410000000000','0.791321097505003','0.780253669567870','553.3713968566454','553.371396856645447','test'),('2019-05-07 03:59:59','2019-05-11 19:59:59','CMTBNB','4h','0.001480000000000','0.001560000000000','0.791321097505003','0.834095210883652','534.6764172331101','534.676417233110101','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','CMTBNB','4h','0.001510000000000','0.001520000000000','0.791321097505003','0.796561634574573','524.0537069569556','524.053706956955580','test'),('2019-05-17 15:59:59','2019-05-18 03:59:59','CMTBNB','4h','0.001540000000000','0.001520000000000','0.791321097505003','0.781044200134808','513.8448685097422','513.844868509742241','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:36:40
