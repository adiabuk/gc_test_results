-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-04 15:59:59','2018-09-04 19:59:59','QTUMBNB','4h','0.428070000000000','0.422370000000000','0.711908500000000','0.702429025965380','1.6630656201088607','1.663065620108861','test'),('2018-09-21 07:59:59','2018-09-21 15:59:59','QTUMBNB','4h','0.383800000000000','0.370510000000000','0.711908500000000','0.687256952410110','1.8548944762897346','1.854894476289735','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','QTUMBNB','4h','0.373000000000000','0.373320000000000','0.711908500000000','0.712519252600536','1.9086018766756034','1.908601876675603','test'),('2018-09-27 15:59:59','2018-09-28 03:59:59','QTUMBNB','4h','0.397370000000000','0.390070000000000','0.711908500000000','0.698830179920477','1.7915506958250498','1.791550695825050','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','QTUMBNB','4h','0.372200000000000','0.370440000000000','0.711908500000000','0.708542140623321','1.912704191295003','1.912704191295003','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','QTUMBNB','4h','0.370340000000000','0.370890000000000','0.711908500000000','0.712965770818707','1.9223105794675164','1.922310579467516','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','QTUMBNB','4h','0.372900000000000','0.366320000000000','0.711908500000000','0.699346531831590','1.9091137034057388','1.909113703405739','test'),('2018-10-17 07:59:59','2018-10-17 11:59:59','QTUMBNB','4h','0.366910000000000','0.366420000000000','0.711908500000000','0.710957762312284','1.9402809953394566','1.940280995339457','test'),('2018-11-02 15:59:59','2018-11-02 23:59:59','QTUMBNB','4h','0.413170000000000','0.408860000000000','0.711908500000000','0.704482196940727','1.7230401529636714','1.723040152963671','test'),('2018-11-03 07:59:59','2018-11-03 11:59:59','QTUMBNB','4h','0.410460000000000','0.407890000000000','0.711908500000000','0.707451050199776','1.7344162646786534','1.734416264678653','test'),('2018-11-04 07:59:59','2018-11-04 11:59:59','QTUMBNB','4h','0.410000000000000','0.411820000000000','0.711908500000000','0.715068679195122','1.7363621951219514','1.736362195121951','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','QTUMBNB','4h','0.408590000000000','0.414590000000000','0.711908500000000','0.722362625162143','1.7423541936904967','1.742354193690497','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','QTUMBNB','4h','0.411710000000000','0.409490000000000','0.711908500000000','0.708069786172306','1.7291503728352482','1.729150372835248','test'),('2018-11-17 11:59:59','2018-11-17 15:59:59','QTUMBNB','4h','0.401920000000000','0.393920000000000','0.711908500000000','0.697738346735669','1.7712691580414015','1.771269158041402','test'),('2018-11-18 03:59:59','2018-11-18 07:59:59','QTUMBNB','4h','0.401530000000000','0.397490000000000','0.711908500000000','0.704745622157747','1.7729895649142033','1.772989564914203','test'),('2018-11-20 11:59:59','2018-11-21 03:59:59','QTUMBNB','4h','0.417210000000000','0.403450000000000','0.711908500000000','0.688429050897630','1.7063553126722755','1.706355312672275','test'),('2018-11-26 03:59:59','2018-11-26 07:59:59','QTUMBNB','4h','0.411370000000000','0.402740000000000','0.711908500000000','0.696973598682451','1.7305795269465445','1.730579526946544','test'),('2018-11-28 19:59:59','2018-11-29 11:59:59','QTUMBNB','4h','0.408870000000000','0.404000000000000','0.711908500000000','0.703429045907012','1.7411610047203268','1.741161004720327','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','QTUMBNB','4h','0.405120000000000','0.398900000000000','0.711908500000000','0.700978230277449','1.7572780904423384','1.757278090442338','test'),('2018-12-01 23:59:59','2018-12-02 03:59:59','QTUMBNB','4h','0.402140000000000','0.400190000000000','0.711908500000000','0.708456414718755','1.7703001442283783','1.770300144228378','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','QTUMBNB','4h','0.404480000000000','0.396760000000000','0.711908500000000','0.698320847656250','1.7600585937500002','1.760058593750000','test'),('2018-12-02 23:59:59','2018-12-03 03:59:59','QTUMBNB','4h','0.403260000000000','0.396880000000000','0.711908500000000','0.700645354064375','1.7653833754897585','1.765383375489759','test'),('2018-12-13 07:59:59','2018-12-14 15:59:59','QTUMBNB','4h','0.381200000000000','0.373000000000000','0.711908500000000','0.696594623557188','1.8675459076600212','1.867545907660021','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','QTUMBNB','4h','0.384300000000000','0.369360000000000','0.711908500000000','0.684232431850117','1.8524811345303152','1.852481134530315','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','QTUMBNB','4h','0.386880000000000','0.372930000000000','0.711908500000000','0.686238722355769','1.840127429693962','1.840127429693962','test'),('2019-02-18 19:59:59','2019-02-18 23:59:59','QTUMBNB','4h','0.223460000000000','0.221250000000000','0.711908500000000','0.704867786740356','3.185843103911215','3.185843103911215','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','QTUMBNB','4h','0.223410000000000','0.221230000000000','0.711908500000000','0.704961807685421','3.1865561076048525','3.186556107604853','test'),('2019-02-23 11:59:59','2019-02-24 15:59:59','QTUMBNB','4h','0.214660000000000','0.208880000000000','0.711908500000000','0.692739436690581','3.316446939345943','3.316446939345943','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','QTUMBNB','4h','0.216710000000000','0.213630000000000','0.711908500000000','0.701790470467445','3.285074523556827','3.285074523556827','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','QTUMBNB','4h','0.183000000000000','0.172900000000000','0.711908500000000','0.672617375136612','3.890210382513662','3.890210382513662','test'),('2019-03-17 15:59:59','2019-03-17 19:59:59','QTUMBNB','4h','0.162080000000000','0.159520000000000','0.711908500000000','0.700664140671273','4.3923278627838105','4.392327862783810','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','QTUMBNB','4h','0.161440000000000','0.160410000000000','0.711908500000000','0.707366467325322','4.409740460852329','4.409740460852329','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','QTUMBNB','4h','0.163750000000000','0.160430000000000','0.711908500000000','0.697474691022901','4.347532824427481','4.347532824427481','test'),('2019-04-04 23:59:59','2019-04-11 03:59:59','QTUMBNB','4h','0.167000000000000','0.176000000000000','0.711908500000000','0.750274826347305','4.262925149700599','4.262925149700599','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','QTUMBNB','4h','0.113320000000000','0.109330000000000','0.711908500000000','0.686842184124603','6.282284680550653','6.282284680550653','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','QTUMBNB','4h','0.111440000000000','0.116480000000000','0.711908500000000','0.744105366834171','6.388267229002154','6.388267229002154','test'),('2019-05-14 15:59:59','2019-05-14 19:59:59','QTUMBNB','4h','0.116500000000000','0.115640000000000','0.711908500000000','0.706653209785408','6.1108025751072965','6.110802575107297','test'),('2019-05-15 19:59:59','2019-05-16 15:59:59','QTUMBNB','4h','0.119240000000000','0.125000000000000','0.711908500000000','0.746297907581349','5.970383260650789','5.970383260650789','test'),('2019-05-28 19:59:59','2019-05-29 03:59:59','QTUMBNB','4h','0.097800000000000','0.096770000000000','0.711908500000000','0.704410895143149','7.279228016359919','7.279228016359919','test'),('2019-05-29 15:59:59','2019-05-30 23:59:59','QTUMBNB','4h','0.099010000000000','0.098060000000000','0.711908500000000','0.705077744773255','7.19026865973134','7.190268659731340','test'),('2019-06-08 03:59:59','2019-06-08 07:59:59','QTUMBNB','4h','0.100620000000000','0.098470000000000','0.711908500000000','0.696696779914530','7.075218644404691','7.075218644404691','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','QTUMBNB','4h','0.104690000000000','0.100940000000000','0.711908500000000','0.686407908969338','6.800157608176521','6.800157608176521','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','QTUMBNB','4h','0.099190000000000','0.093830000000000','0.711908500000000','0.673438598195383','7.177220485936083','7.177220485936083','test'),('2019-06-14 03:59:59','2019-06-18 03:59:59','QTUMBNB','4h','0.099360000000000','0.102950000000000','0.711908500000000','0.737630636825684','7.164940619967794','7.164940619967794','test'),('2019-06-18 19:59:59','2019-06-19 11:59:59','QTUMBNB','4h','0.103120000000000','0.102140000000000','0.711908500000000','0.705142883921645','6.90368987587277','6.903689875872770','test'),('2019-06-22 19:59:59','2019-06-27 07:59:59','QTUMBNB','4h','0.102010000000000','0.141720000000000','0.711908500000000','0.989037080874424','6.97881090089207','6.978810900892070','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','QTUMBNB','4h','0.147980000000000','0.146130000000000','0.711908500000000','0.703008441039330','4.810842681443439','4.810842681443439','test'),('2019-07-29 23:59:59','2019-07-31 03:59:59','QTUMBNB','4h','0.106910000000000','0.106140000000000','0.711908500000000','0.706781107380039','6.658951454494435','6.658951454494435','test'),('2019-07-31 11:59:59','2019-08-01 07:59:59','QTUMBNB','4h','0.109370000000000','0.107180000000000','0.711908500000000','0.697653406144281','6.509175276584073','6.509175276584073','test'),('2019-08-02 07:59:59','2019-08-02 19:59:59','QTUMBNB','4h','0.107780000000000','0.107530000000000','0.711908500000000','0.710257199897940','6.605200408239006','6.605200408239006','test'),('2019-08-18 03:59:59','2019-08-18 23:59:59','QTUMBNB','4h','0.093180000000000','0.091350000000000','0.711908500000000','0.697927038795879','7.640142734492381','7.640142734492381','test'),('2019-08-19 23:59:59','2019-08-20 07:59:59','QTUMBNB','4h','0.093180000000000','0.092590000000000','0.711908500000000','0.707400815786650','7.640142734492381','7.640142734492381','test'),('2019-08-21 19:59:59','2019-08-21 23:59:59','QTUMBNB','4h','0.092400000000000','0.091620000000000','0.711908500000000','0.705898882792208','7.704637445887447','7.704637445887447','test'),('2019-08-29 07:59:59','2019-08-29 11:59:59','QTUMBNB','4h','0.096190000000000','0.096390000000000','0.711908500000000','0.713388713119867','7.401065599334651','7.401065599334651','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','QTUMBNB','4h','0.096990000000000','0.094290000000000','0.711908500000000','0.692090447107949','7.340019589648417','7.340019589648417','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:10:10
