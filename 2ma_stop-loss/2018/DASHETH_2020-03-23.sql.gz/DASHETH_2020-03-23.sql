-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-07 11:59:59','2018-04-07 15:59:59','DASHETH','4h','0.793510000000000','0.790150000000000','0.072144500000000','0.071839014851735','0.0909181988884828','0.090918198888483','test'),('2018-04-18 11:59:59','2018-04-20 03:59:59','DASHETH','4h','0.758210000000000','0.760820000000000','0.072144500000000','0.072392844317537','0.095151079516229','0.095151079516229','test'),('2018-04-22 11:59:59','2018-04-22 15:59:59','DASHETH','4h','0.752000000000000','0.734670000000000','0.072144500000000','0.070481914647606','0.09593683510638298','0.095936835106383','test'),('2018-04-22 23:59:59','2018-04-23 03:59:59','DASHETH','4h','0.753060000000000','0.728150000000000','0.072144500000000','0.069758077278039','0.09580179534167264','0.095801795341673','test'),('2018-04-23 15:59:59','2018-04-23 19:59:59','DASHETH','4h','0.811960000000000','0.776430000000000','0.072144500000000','0.068987578372087','0.0888522833637125','0.088852283363712','test'),('2018-04-25 11:59:59','2018-04-25 15:59:59','DASHETH','4h','0.753000000000000','0.743450000000000','0.072144500000000','0.071229519953519','0.09580942895086321','0.095809428950863','test'),('2018-04-25 19:59:59','2018-04-25 23:59:59','DASHETH','4h','0.759940000000000','0.751550000000000','0.072144500000000','0.071347999809195','0.0949344685106719','0.094934468510672','test'),('2018-04-26 15:59:59','2018-04-27 07:59:59','DASHETH','4h','0.759790000000000','0.744360000000000','0.072144500000000','0.070679371958041','0.09495321075560352','0.094953210755604','test'),('2018-05-15 11:59:59','2018-05-15 15:59:59','DASHETH','4h','0.618220000000000','0.593190000000000','0.072144500000000','0.069223570824302','0.11669713047135324','0.116697130471353','test'),('2018-05-23 23:59:59','2018-05-24 03:59:59','DASHETH','4h','0.584700000000000','0.575760000000000','0.072144500000000','0.071041418368394','0.1233872071147597','0.123387207114760','test'),('2018-05-25 19:59:59','2018-05-26 03:59:59','DASHETH','4h','0.581530000000000','0.566320000000000','0.072144500000000','0.070257550324145','0.12405980774852544','0.124059807748525','test'),('2018-05-28 11:59:59','2018-05-28 15:59:59','DASHETH','4h','0.572660000000000','0.565780000000000','0.072144500000000','0.071277748070408','0.12598138511507703','0.125981385115077','test'),('2018-05-29 11:59:59','2018-05-29 15:59:59','DASHETH','4h','0.574150000000000','0.555290000000000','0.072144500000000','0.069774657154054','0.12565444570234258','0.125654445702343','test'),('2018-06-12 19:59:59','2018-06-12 23:59:59','DASHETH','4h','0.532370000000000','0.525700000000000','0.072144500000000','0.071240610195916','0.13551571275616583','0.135515712756166','test'),('2018-06-13 07:59:59','2018-06-13 19:59:59','DASHETH','4h','0.523610000000000','0.531020000000000','0.072144500000000','0.073165471228586','0.13778289184698533','0.137782891846985','test'),('2018-06-14 03:59:59','2018-06-14 19:59:59','DASHETH','4h','0.530480000000000','0.518890000000000','0.072144500000000','0.070568277041547','0.13599852963353945','0.135998529633539','test'),('2018-06-15 11:59:59','2018-06-15 15:59:59','DASHETH','4h','0.526020000000000','0.516650000000000','0.072144500000000','0.070859389234250','0.13715162921561916','0.137151629215619','test'),('2018-06-16 19:59:59','2018-06-17 03:59:59','DASHETH','4h','0.531340000000000','0.525820000000000','0.072144500000000','0.071395003180638','0.13577840930477658','0.135778409304777','test'),('2018-06-23 03:59:59','2018-06-23 07:59:59','DASHETH','4h','0.527100000000000','0.520440000000000','0.072144500000000','0.071232941718839','0.13687061278694745','0.136870612786947','test'),('2018-06-28 23:59:59','2018-06-29 03:59:59','DASHETH','4h','0.521590000000000','0.524890000000000','0.072144500000000','0.072600944429533','0.13831649379781055','0.138316493797811','test'),('2018-07-02 03:59:59','2018-07-02 15:59:59','DASHETH','4h','0.533810000000000','0.530210000000000','0.072144500000000','0.071657959470598','0.13515014705606865','0.135150147056069','test'),('2018-07-04 23:59:59','2018-07-05 03:59:59','DASHETH','4h','0.527030000000000','0.526730000000000','0.072144500000000','0.072103433362427','0.13688879190937897','0.136888791909379','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','DASHETH','4h','0.550620000000000','0.516900000000000','0.072144500000000','0.067726366732048','0.1310241182666812','0.131024118266681','test'),('2018-07-14 15:59:59','2018-07-14 19:59:59','DASHETH','4h','0.510990000000000','0.513700000000000','0.072144500000000','0.072527113348598','0.14118573748997043','0.141185737489970','test'),('2018-07-15 11:59:59','2018-07-15 15:59:59','DASHETH','4h','0.510110000000000','0.510640000000000','0.072144500000000','0.072219457528768','0.1414292995628394','0.141429299562839','test'),('2018-07-21 11:59:59','2018-07-21 15:59:59','DASHETH','4h','0.534860000000000','0.535510000000000','0.072144500000000','0.072232175139289','0.13488482967505516','0.134884829675055','test'),('2018-07-23 19:59:59','2018-07-23 23:59:59','DASHETH','4h','0.537800000000000','0.538740000000000','0.072144500000000','0.072270598605430','0.13414745258460395','0.134147452584604','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','DASHETH','4h','0.531740000000000','0.520750000000000','0.072144500000000','0.070653417788769','0.1356762703576936','0.135676270357694','test'),('2018-08-01 03:59:59','2018-08-01 07:59:59','DASHETH','4h','0.532690000000000','0.515120000000000','0.072144500000000','0.069764919258856','0.13543430513056373','0.135434305130564','test'),('2018-08-01 11:59:59','2018-08-01 15:59:59','DASHETH','4h','0.524840000000000','0.523770000000000','0.072144500000000','0.071997417813048','0.13745998780580748','0.137459987805807','test'),('2018-08-08 15:59:59','2018-08-08 19:59:59','DASHETH','4h','0.514970000000000','0.498880000000000','0.072144500000000','0.069890378390974','0.1400945686156475','0.140094568615648','test'),('2018-08-10 03:59:59','2018-08-10 15:59:59','DASHETH','4h','0.509100000000000','0.515000000000000','0.072144500000000','0.072980588293066','0.14170988018071107','0.141709880180711','test'),('2018-08-14 03:59:59','2018-08-14 07:59:59','DASHETH','4h','0.526460000000000','0.516000000000000','0.072144500000000','0.070711092960529','0.13703700186148995','0.137037001861490','test'),('2018-08-15 03:59:59','2018-08-17 23:59:59','DASHETH','4h','0.528780000000000','0.529250000000000','0.072144500000000','0.072208624806158','0.13643575778206438','0.136435757782064','test'),('2018-08-19 15:59:59','2018-08-19 23:59:59','DASHETH','4h','0.529550000000000','0.516080000000000','0.072144500000000','0.070309382607875','0.1362373713530356','0.136237371353036','test'),('2018-08-24 23:59:59','2018-08-25 03:59:59','DASHETH','4h','0.517300000000000','0.512980000000000','0.072144500000000','0.071542017417359','0.13946356079644306','0.139463560796443','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','DASHETH','4h','0.522220000000000','0.516600000000000','0.072144500000000','0.071368099077017','0.13814963042395925','0.138149630423959','test'),('2018-08-26 11:59:59','2018-08-26 15:59:59','DASHETH','4h','0.516270000000000','0.519300000000000','0.072144500000000','0.072567917659364','0.13974180177039147','0.139741801770391','test'),('2018-09-17 07:59:59','2018-09-17 11:59:59','DASHETH','4h','0.902960000000000','0.891020000000000','0.072144500000000','0.071190520499247','0.07989778063258617','0.079897780632586','test'),('2018-09-21 03:59:59','2018-09-21 11:59:59','DASHETH','4h','0.925960000000000','0.910030000000000','0.072144500000000','0.070903342838784','0.07791319279450516','0.077913192794505','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','DASHETH','4h','0.879720000000000','0.871050000000000','0.072144500000000','0.071433486478652','0.08200847997089984','0.082008479970900','test'),('2018-09-26 03:59:59','2018-09-26 07:59:59','DASHETH','4h','0.879260000000000','0.880890000000000','0.072144500000000','0.072278243756113','0.08205138411846324','0.082051384118463','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','DASHETH','4h','0.826020000000000','0.817690000000000','0.072144500000000','0.071416958675335','0.0873398949177986','0.087339894917799','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','DASHETH','4h','0.822540000000000','0.793050000000000','0.072144500000000','0.069557949431031','0.08770941230821601','0.087709412308216','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','DASHETH','4h','0.819480000000000','0.803560000000000','0.072144500000000','0.070742952140382','0.08803692585542051','0.088036925855421','test'),('2018-10-24 15:59:59','2018-10-24 23:59:59','DASHETH','4h','0.777670000000000','0.769920000000000','0.072144500000000','0.071425531960857','0.09277006956678283','0.092770069566783','test'),('2018-10-30 03:59:59','2018-10-31 19:59:59','DASHETH','4h','0.772840000000000','0.769160000000000','0.072144500000000','0.071800972542829','0.09334985249210703','0.093349852492107','test'),('2018-11-01 11:59:59','2018-11-01 15:59:59','DASHETH','4h','0.774840000000000','0.775150000000000','0.072144500000000','0.072173363758970','0.09310889990191523','0.093108899901915','test'),('2018-11-02 07:59:59','2018-11-02 11:59:59','DASHETH','4h','0.773780000000000','0.771170000000000','0.072144500000000','0.071901152866448','0.09323644963684768','0.093236449636848','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','DASHETH','4h','0.772200000000000','0.768410000000000','0.072144500000000','0.071790410832686','0.09342722092722093','0.093427220927221','test'),('2018-11-03 07:59:59','2018-11-04 07:59:59','DASHETH','4h','0.774640000000000','0.772410000000000','0.072144500000000','0.071936813545647','0.0931329391717443','0.093132939171744','test'),('2018-11-08 03:59:59','2018-11-08 23:59:59','DASHETH','4h','0.783000000000000','0.779790000000000','0.072144500000000','0.071848735191571','0.09213856960408684','0.092138569604087','test'),('2018-11-12 11:59:59','2018-11-12 15:59:59','DASHETH','4h','0.775120000000000','0.779100000000000','0.072144500000000','0.072514939557746','0.09307526576530085','0.093075265765301','test'),('2018-11-16 15:59:59','2018-11-16 19:59:59','DASHETH','4h','0.775910000000000','0.778640000000000','0.072144500000000','0.072398336765862','0.09298050031575827','0.092980500315758','test'),('2018-11-20 19:59:59','2018-11-20 23:59:59','DASHETH','4h','0.771010000000000','0.803400000000000','0.072144500000000','0.075175278271358','0.09357141930714258','0.093571419307143','test'),('2018-11-26 03:59:59','2018-11-26 11:59:59','DASHETH','4h','0.802160000000000','0.791240000000000','0.072144500000000','0.071162379300888','0.08993779295901068','0.089937792959011','test'),('2018-11-26 19:59:59','2018-11-27 23:59:59','DASHETH','4h','0.808950000000000','0.813030000000000','0.072144500000000','0.072508366196922','0.08918289140243527','0.089182891402435','test'),('2018-11-30 23:59:59','2018-12-01 11:59:59','DASHETH','4h','0.810730000000000','0.797920000000000','0.072144500000000','0.071004575432018','0.08898708571287606','0.088987085712876','test'),('2018-12-01 15:59:59','2018-12-01 23:59:59','DASHETH','4h','0.813650000000000','0.801470000000000','0.072144500000000','0.071064527026363','0.08866773182572359','0.088667731825724','test'),('2018-12-02 03:59:59','2018-12-02 07:59:59','DASHETH','4h','0.810710000000000','0.806270000000000','0.072144500000000','0.071749387592357','0.08898928100060441','0.088989281000604','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','DASHETH','4h','0.804160000000000','0.771820000000000','0.072144500000000','0.069243145630223','0.0897141116195782','0.089714111619578','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','DASHETH','4h','0.752220000000000','0.737030000000000','0.072144500000000','0.070687645682114','0.09590877668767116','0.095908776687671','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','DASHETH','4h','0.741000000000000','0.744010000000000','0.072144500000000','0.072437556605938','0.09736099865047233','0.097360998650472','test'),('2018-12-17 11:59:59','2018-12-17 19:59:59','DASHETH','4h','0.756310000000000','0.747780000000000','0.072144500000000','0.071330822295091','0.095390117808835','0.095390117808835','test'),('2018-12-19 07:59:59','2018-12-19 15:59:59','DASHETH','4h','0.738890000000000','0.725860000000000','0.072144500000000','0.070872263489829','0.09763902610672766','0.097639026106728','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','DASHETH','4h','0.749170000000000','0.729450000000000','0.072144500000000','0.070245479030127','0.096299237823191','0.096299237823191','test'),('2018-12-20 19:59:59','2018-12-22 23:59:59','DASHETH','4h','0.762810000000000','0.745500000000000','0.072144500000000','0.070507367168758','0.0945772866113449','0.094577286611345','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','DASHETH','4h','0.574350000000000','0.568470000000000','0.072144500000000','0.071405909140768','0.12561069034560807','0.125610690345608','test'),('2019-01-10 19:59:59','2019-01-11 07:59:59','DASHETH','4h','0.567730000000000','0.565900000000000','0.072144500000000','0.071911952072288','0.12707537033448998','0.127075370334490','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','DASHETH','4h','0.581100000000000','0.576630000000000','0.072144500000000','0.071589542307692','0.12415160901738084','0.124151609017381','test'),('2019-02-03 23:59:59','2019-02-04 03:59:59','DASHETH','4h','0.622280000000000','0.620050000000000','0.072144500000000','0.071885963272160','0.11593575239442051','0.115935752394421','test'),('2019-02-04 23:59:59','2019-02-05 03:59:59','DASHETH','4h','0.621090000000000','0.619240000000000','0.072144500000000','0.071929607915117','0.11615788372055579','0.116157883720556','test'),('2019-02-05 07:59:59','2019-02-05 11:59:59','DASHETH','4h','0.620830000000000','0.630910000000000','0.072144500000000','0.073315861822077','0.11620652996794614','0.116206529967946','test'),('2019-02-09 03:59:59','2019-02-09 07:59:59','DASHETH','4h','0.630780000000000','0.626110000000000','0.072144500000000','0.071610375875900','0.11437347411141761','0.114373474111418','test'),('2019-02-09 11:59:59','2019-02-09 15:59:59','DASHETH','4h','0.627950000000000','0.622470000000000','0.072144500000000','0.071514908694960','0.11488892427741063','0.114888924277411','test'),('2019-02-11 07:59:59','2019-02-14 15:59:59','DASHETH','4h','0.634610000000000','0.637280000000000','0.072144500000000','0.072448034162714','0.11368320700902916','0.113683207009029','test'),('2019-02-14 23:59:59','2019-02-15 03:59:59','DASHETH','4h','0.642490000000000','0.635850000000000','0.072144500000000','0.071398901656057','0.11228890722034585','0.112288907220346','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','DASHETH','4h','0.644000000000000','0.651460000000000','0.072144500000000','0.072980211133540','0.11202562111801243','0.112025621118012','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','DASHETH','4h','0.602700000000000','0.596160000000000','0.072144500000000','0.071361647784968','0.11970217355234776','0.119702173552348','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','DASHETH','4h','0.599130000000000','0.596750000000000','0.072144500000000','0.071857911262998','0.12041543571512024','0.120415435715120','test'),('2019-02-28 15:59:59','2019-03-05 19:59:59','DASHETH','4h','0.606000000000000','0.602800000000000','0.072144500000000','0.071763538943894','0.1190503300330033','0.119050330033003','test'),('2019-03-09 23:59:59','2019-03-10 03:59:59','DASHETH','4h','0.606520000000000','0.601160000000000','0.072144500000000','0.071506937314516','0.11894826221723934','0.118948262217239','test'),('2019-03-10 15:59:59','2019-03-10 19:59:59','DASHETH','4h','0.605120000000000','0.604010000000000','0.072144500000000','0.072012161959611','0.11922345980962454','0.119223459809625','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','DASHETH','4h','0.661570000000000','0.660460000000000','0.072144500000000','0.072023454010913','0.10905044061852866','0.109050440618529','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','DASHETH','4h','0.679700000000000','0.666580000000000','0.072144500000000','0.070751921156393','0.10614168015300869','0.106141680153009','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:17:38
