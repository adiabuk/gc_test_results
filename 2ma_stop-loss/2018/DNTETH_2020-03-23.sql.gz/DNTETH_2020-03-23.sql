-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-13 15:59:59','2018-02-13 19:59:59','DNTETH','4h','0.000107580000000','0.000104780000000','0.072144500000000','0.070266784811303','670.6125673917085','670.612567391708467','test'),('2018-02-14 03:59:59','2018-02-15 07:59:59','DNTETH','4h','0.000113360000000','0.000111600000000','0.072144500000000','0.071024401905434','636.4193719124912','636.419371912491215','test'),('2018-02-16 15:59:59','2018-02-16 19:59:59','DNTETH','4h','0.000109540000000','0.000109790000000','0.072144500000000','0.072309153322987','658.6132919481469','658.613291948146866','test'),('2018-02-18 15:59:59','2018-02-18 19:59:59','DNTETH','4h','0.000124930000000','0.000110750000000','0.072144500000000','0.063955842271672','577.4793884575362','577.479388457536174','test'),('2018-02-19 07:59:59','2018-02-19 11:59:59','DNTETH','4h','0.000114650000000','0.000113280000000','0.072144500000000','0.071282415699956','629.258613170519','629.258613170518970','test'),('2018-03-01 23:59:59','2018-03-02 03:59:59','DNTETH','4h','0.000098830000000','0.000098300000000','0.072144500000000','0.071757607507842','729.985834260852','729.985834260852016','test'),('2018-03-07 11:59:59','2018-03-07 15:59:59','DNTETH','4h','0.000104610000000','0.000098380000000','0.072144500000000','0.067847967785107','689.6520409138706','689.652040913870565','test'),('2018-03-19 19:59:59','2018-03-19 23:59:59','DNTETH','4h','0.000092070000000','0.000087960000000','0.072144500000000','0.068923973281199','783.5831432605626','783.583143260562565','test'),('2018-03-31 11:59:59','2018-04-03 03:59:59','DNTETH','4h','0.000139640000000','0.000136200000000','0.072144500000000','0.070367236465196','516.646376396448','516.646376396447977','test'),('2018-04-07 03:59:59','2018-04-07 07:59:59','DNTETH','4h','0.000136760000000','0.000140020000000','0.072144500000000','0.073864235814566','527.5263234863995','527.526323486399519','test'),('2018-04-08 23:59:59','2018-04-09 03:59:59','DNTETH','4h','0.000137560000000','0.000139540000000','0.072144500000000','0.073182927667927','524.4584181448096','524.458418144809571','test'),('2018-04-09 15:59:59','2018-04-09 19:59:59','DNTETH','4h','0.000136400000000','0.000137380000000','0.072144500000000','0.072662840249267','528.9186217008797','528.918621700879726','test'),('2018-04-12 19:59:59','2018-04-12 23:59:59','DNTETH','4h','0.000140000000000','0.000135290000000','0.072144500000000','0.069717352892857','515.3178571428572','515.317857142857179','test'),('2018-04-13 19:59:59','2018-04-13 23:59:59','DNTETH','4h','0.000140000000000','0.000142590000000','0.072144500000000','0.073479173250000','515.3178571428572','515.317857142857179','test'),('2018-04-22 15:59:59','2018-04-22 23:59:59','DNTETH','4h','0.000150750000000','0.000174190000000','0.072144500000000','0.083362192072968','478.57048092868985','478.570480928689847','test'),('2018-04-25 07:59:59','2018-04-25 11:59:59','DNTETH','4h','0.000152340000000','0.000148010000000','0.072144500000000','0.070093917848234','473.57555468032035','473.575554680320352','test'),('2018-04-25 19:59:59','2018-04-25 23:59:59','DNTETH','4h','0.000156910000000','0.000151470000000','0.072144500000000','0.069643282231853','459.7826779682621','459.782677968262078','test'),('2018-04-29 23:59:59','2018-04-30 03:59:59','DNTETH','4h','0.000152120000000','0.000147100000000','0.072144500000000','0.069763712529582','474.2604522745201','474.260452274520105','test'),('2018-04-30 11:59:59','2018-05-01 03:59:59','DNTETH','4h','0.000155730000000','0.000152900000000','0.072144500000000','0.070833455660438','463.2665510820009','463.266551082000888','test'),('2018-05-10 03:59:59','2018-05-10 07:59:59','DNTETH','4h','0.000147570000000','0.000141960000000','0.072144500000000','0.069401865013214','488.8832418513248','488.883241851324783','test'),('2018-05-27 15:59:59','2018-05-27 19:59:59','DNTETH','4h','0.000127660000000','0.000121140000000','0.072144500000000','0.068459852185493','565.1300328998904','565.130032899890352','test'),('2018-07-01 19:59:59','2018-07-01 23:59:59','DNTETH','4h','0.000081430000000','0.000077010000000','0.072144500000000','0.068228514613779','885.969544393958','885.969544393958017','test'),('2018-07-17 23:59:59','2018-07-20 03:59:59','DNTETH','4h','0.000083110000000','0.000082520000000','0.072144500000000','0.071632344362893','868.0604018770305','868.060401877030472','test'),('2018-07-21 23:59:59','2018-07-22 03:59:59','DNTETH','4h','0.000081310000000','0.000080790000000','0.072144500000000','0.071683115914402','887.2770876890911','887.277087689091104','test'),('2018-07-23 07:59:59','2018-07-23 11:59:59','DNTETH','4h','0.000081040000000','0.000080350000000','0.072144500000000','0.071530239079467','890.2332181638698','890.233218163869765','test'),('2018-07-24 15:59:59','2018-07-24 19:59:59','DNTETH','4h','0.000088970000000','0.000082820000000','0.072144500000000','0.067157552995392','810.8856918062269','810.885691806226873','test'),('2018-07-25 07:59:59','2018-07-25 11:59:59','DNTETH','4h','0.000081960000000','0.000079840000000','0.072144500000000','0.070278390434358','880.2403611517814','880.240361151781372','test'),('2018-07-27 11:59:59','2018-07-27 15:59:59','DNTETH','4h','0.000083790000000','0.000079040000000','0.072144500000000','0.068054675736961','861.015634323905','861.015634323905033','test'),('2018-07-28 03:59:59','2018-07-28 07:59:59','DNTETH','4h','0.000080030000000','0.000080320000000','0.072144500000000','0.072405925777833','901.4681994252155','901.468199425215516','test'),('2018-08-09 19:59:59','2018-08-09 23:59:59','DNTETH','4h','0.000078790000000','0.000078060000000','0.072144500000000','0.071476071455768','915.6555400431528','915.655540043152769','test'),('2018-08-11 11:59:59','2018-08-11 15:59:59','DNTETH','4h','0.000079730000000','0.000078440000000','0.072144500000000','0.070977230402609','904.8601530164304','904.860153016430445','test'),('2018-08-17 11:59:59','2018-08-18 15:59:59','DNTETH','4h','0.000076730000000','0.000076430000000','0.072144500000000','0.071862428450411','940.2384986315651','940.238498631565108','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','DNTETH','4h','0.000075990000000','0.000075390000000','0.072144500000000','0.071574863205685','949.3946571917359','949.394657191735860','test'),('2018-08-22 07:59:59','2018-08-22 11:59:59','DNTETH','4h','0.000075800000000','0.000075690000000','0.072144500000000','0.072039804815303','951.7744063324539','951.774406332453850','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','DNTETH','4h','0.000076440000000','0.000076120000000','0.072144500000000','0.071842482208268','943.8055991627419','943.805599162741942','test'),('2018-09-16 19:59:59','2018-09-21 19:59:59','DNTETH','4h','0.000102980000000','0.000102480000000','0.072144500000000','0.071794215964265','700.5680714701883','700.568071470188329','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','DNTETH','4h','0.000106200000000','0.000102070000000','0.072144500000000','0.069338880555556','679.3267419962335','679.326741996233523','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','DNTETH','4h','0.000104210000000','0.000103780000000','0.072144500000000','0.071846811342482','692.299203531331','692.299203531331045','test'),('2018-09-29 19:59:59','2018-09-29 23:59:59','DNTETH','4h','0.000106340000000','0.000107100000000','0.072144500000000','0.072660108613880','678.4323866842204','678.432386684220432','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','DNTETH','4h','0.000105250000000','0.000104240000000','0.072144500000000','0.071452186983373','685.4584323040381','685.458432304038070','test'),('2018-10-02 11:59:59','2018-10-02 19:59:59','DNTETH','4h','0.000105970000000','0.000106230000000','0.072144500000000','0.072321508304237','680.8011701424931','680.801170142493106','test'),('2018-10-10 11:59:59','2018-10-15 07:59:59','DNTETH','4h','0.000112540000000','0.000111320000000','0.072144500000000','0.071362411053848','641.056513239737','641.056513239737001','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','DNTETH','4h','0.000117720000000','0.000115720000000','0.072144500000000','0.070918803431872','612.8482840638803','612.848284063880328','test'),('2018-10-16 03:59:59','2018-10-16 07:59:59','DNTETH','4h','0.000117350000000','0.000116780000000','0.072144500000000','0.071794075074563','614.7805709416276','614.780570941627616','test'),('2018-10-22 15:59:59','2018-10-23 23:59:59','DNTETH','4h','0.000121230000000','0.000123290000000','0.072144500000000','0.073370414955044','595.1043471088014','595.104347108801448','test'),('2018-11-10 07:59:59','2018-11-11 03:59:59','DNTETH','4h','0.000138150000000','0.000137180000000','0.072144500000000','0.071637947955121','522.2186029677887','522.218602967788684','test'),('2018-11-28 07:59:59','2018-11-28 19:59:59','DNTETH','4h','0.000107480000000','0.000109130000000','0.072144500000000','0.073252040240045','671.2365091179755','671.236509117975515','test'),('2018-12-01 07:59:59','2018-12-03 03:59:59','DNTETH','4h','0.000108550000000','0.000109540000000','0.072144500000000','0.072802473790880','664.6199907876555','664.619990787655524','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','DNTETH','4h','0.000108930000000','0.000108770000000','0.072144500000000','0.072038531763518','662.3014780134031','662.301478013403084','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','DNTETH','4h','0.000083820000000','0.000084680000000','0.072144500000000','0.072884708422811','860.7074683846338','860.707468384633785','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','DNTETH','4h','0.000102240000000','0.000101650000000','0.072144500000000','0.071728173170970','705.6386932707355','705.638693270735530','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','DNTETH','4h','0.000103300000000','0.000102100000000','0.072144500000000','0.071306422555663','698.3978702807357','698.397870280735674','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:43:31
