-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-06 15:59:59','2018-05-07 03:59:59','WTCBNB','4h','1.141200000000000','1.081300000000000','0.711908500000000','0.674541413468279','0.6238244830003505','0.623824483000351','test'),('2018-05-07 07:59:59','2018-05-07 11:59:59','WTCBNB','4h','1.112000000000000','1.085100000000000','0.711908500000000','0.694686972437050','0.6402054856115108','0.640205485611511','test'),('2018-05-08 07:59:59','2018-05-08 11:59:59','WTCBNB','4h','1.121800000000000','1.098200000000000','0.711908500000000','0.696931640845071','0.6346126760563381','0.634612676056338','test'),('2018-05-14 15:59:59','2018-05-14 19:59:59','WTCBNB','4h','1.052200000000000','1.021800000000000','0.711908500000000','0.691340149496294','0.6765904770956093','0.676590477095609','test'),('2018-05-15 15:59:59','2018-05-15 19:59:59','WTCBNB','4h','1.070100000000000','1.007700000000000','0.711908500000000','0.670395472806280','0.6652728716942342','0.665272871694234','test'),('2018-05-29 07:59:59','2018-05-29 11:59:59','WTCBNB','4h','0.906200000000000','0.885600000000000','0.711908500000000','0.695725190465681','0.7855975502096668','0.785597550209667','test'),('2018-07-01 11:59:59','2018-07-01 15:59:59','WTCBNB','4h','0.465900000000000','0.450400000000000','0.711908500000000','0.688224057523074','1.5280285468984762','1.528028546898476','test'),('2018-07-02 03:59:59','2018-07-03 23:59:59','WTCBNB','4h','0.467400000000000','0.469800000000000','0.711908500000000','0.715563999358152','1.5231247325631152','1.523124732563115','test'),('2018-07-10 19:59:59','2018-07-10 23:59:59','WTCBNB','4h','0.507000000000000','0.502300000000000','0.711908500000000','0.705308953747535','1.4041587771203157','1.404158777120316','test'),('2018-07-15 15:59:59','2018-07-15 19:59:59','WTCBNB','4h','0.526700000000000','0.523100000000000','0.711908500000000','0.707042597968483','1.351639453199165','1.351639453199165','test'),('2018-07-16 03:59:59','2018-07-16 07:59:59','WTCBNB','4h','0.528000000000000','0.528500000000000','0.711908500000000','0.712582655776515','1.3483115530303031','1.348311553030303','test'),('2018-07-17 07:59:59','2018-07-17 11:59:59','WTCBNB','4h','0.541800000000000','0.539100000000000','0.711908500000000','0.708360783222592','1.3139691768180142','1.313969176818014','test'),('2018-07-20 07:59:59','2018-07-20 15:59:59','WTCBNB','4h','0.561300000000000','0.554400000000000','0.711908500000000','0.703157086050241','1.2683208622839837','1.268320862283984','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','WTCBNB','4h','0.544500000000000','0.539300000000000','0.711908500000000','0.705109741138659','1.3074536271809','1.307453627180900','test'),('2018-07-22 03:59:59','2018-07-22 07:59:59','WTCBNB','4h','0.542500000000000','0.541400000000000','0.711908500000000','0.710464998894009','1.3122737327188942','1.312273732718894','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','WTCBNB','4h','0.273200000000000','0.262800000000000','0.711908500000000','0.684808030014641','2.6058144216691073','2.605814421669107','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','WTCBNB','4h','0.356800000000000','0.343400000000000','0.711908500000000','0.685172026065022','1.9952592488789238','1.995259248878924','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','WTCBNB','4h','0.302400000000000','0.293600000000000','0.711908500000000','0.691191585978836','2.3541947751322754','2.354194775132275','test'),('2018-10-08 07:59:59','2018-10-08 11:59:59','WTCBNB','4h','0.286900000000000','0.291700000000000','0.711908500000000','0.723819133670269','2.4813820146392476','2.481382014639248','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','WTCBNB','4h','0.295700000000000','0.282200000000000','0.711908500000000','0.679406759215421','2.407536354413257','2.407536354413257','test'),('2018-10-14 07:59:59','2018-10-14 11:59:59','WTCBNB','4h','0.293600000000000','0.291900000000000','0.711908500000000','0.707786413998638','2.424756471389646','2.424756471389646','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','WTCBNB','4h','0.291300000000000','0.287100000000000','0.711908500000000','0.701644113800206','2.443901476141435','2.443901476141435','test'),('2018-10-17 03:59:59','2018-10-17 11:59:59','WTCBNB','4h','0.292500000000000','0.294700000000000','0.711908500000000','0.717263025470086','2.433875213675214','2.433875213675214','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','WTCBNB','4h','0.304400000000000','0.300100000000000','0.711908500000000','0.701851973883049','2.3387270039421817','2.338727003942182','test'),('2018-11-29 07:59:59','2018-11-29 23:59:59','WTCBNB','4h','0.249200000000000','0.246200000000000','0.711908500000000','0.703338172953451','2.8567756821829855','2.856775682182985','test'),('2018-12-14 15:59:59','2018-12-14 19:59:59','WTCBNB','4h','0.203500000000000','0.199400000000000','0.711908500000000','0.697565380343980','3.498321867321868','3.498321867321868','test'),('2018-12-15 03:59:59','2018-12-15 11:59:59','WTCBNB','4h','0.204500000000000','0.200000000000000','0.711908500000000','0.696243031784841','3.481215158924206','3.481215158924206','test'),('2018-12-18 03:59:59','2018-12-18 11:59:59','WTCBNB','4h','0.202400000000000','0.195400000000000','0.711908500000000','0.687287158596838','3.5173344861660083','3.517334486166008','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','WTCBNB','4h','0.217900000000000','0.202700000000000','0.711908500000000','0.662248063102341','3.267134006424966','3.267134006424966','test'),('2018-12-24 11:59:59','2018-12-24 15:59:59','WTCBNB','4h','0.221400000000000','0.211400000000000','0.711908500000000','0.679753644534779','3.215485546522132','3.215485546522132','test'),('2018-12-30 15:59:59','2018-12-30 19:59:59','WTCBNB','4h','0.200900000000000','0.198400000000000','0.711908500000000','0.703049509208561','3.543596316575411','3.543596316575411','test'),('2018-12-30 23:59:59','2018-12-31 03:59:59','WTCBNB','4h','0.210500000000000','0.189600000000000','0.711908500000000','0.641224948218527','3.38198812351544','3.381988123515440','test'),('2019-01-03 23:59:59','2019-01-04 03:59:59','WTCBNB','4h','0.195100000000000','0.192800000000000','0.711908500000000','0.703515934392619','3.6489415684264483','3.648941568426448','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','WTCBNB','4h','0.194400000000000','0.192800000000000','0.711908500000000','0.706049170781893','3.662080761316873','3.662080761316873','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','WTCBNB','4h','0.194000000000000','0.191900000000000','0.711908500000000','0.704202273969072','3.6696314432989694','3.669631443298969','test'),('2019-01-13 23:59:59','2019-01-14 07:59:59','WTCBNB','4h','0.189400000000000','0.192200000000000','0.711908500000000','0.722433018479409','3.7587565997888066','3.758756599788807','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','WTCBNB','4h','0.188600000000000','0.185800000000000','0.711908500000000','0.701339338812301','3.7747004241781554','3.774700424178155','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','WTCBNB','4h','0.189200000000000','0.189000000000000','0.711908500000000','0.711155954016913','3.762729915433404','3.762729915433404','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','WTCBNB','4h','0.118200000000000','0.115700000000000','0.711908500000000','0.696851213620981','6.022914551607445','6.022914551607445','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','WTCBNB','4h','0.118900000000000','0.114800000000000','0.711908500000000','0.687359931034483','5.987455845248108','5.987455845248108','test'),('2019-02-26 07:59:59','2019-02-27 15:59:59','WTCBNB','4h','0.107900000000000','0.107100000000000','0.711908500000000','0.706630216404078','6.5978544949026885','6.597854494902688','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','WTCBNB','4h','0.108700000000000','0.105100000000000','0.711908500000000','0.688331033578657','6.549296228150874','6.549296228150874','test'),('2019-03-15 19:59:59','2019-03-16 03:59:59','WTCBNB','4h','0.086400000000000','0.086900000000000','0.711908500000000','0.716028340856481','8.239681712962962','8.239681712962962','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','WTCBNB','4h','0.085400000000000','0.085500000000000','0.711908500000000','0.712742116510539','8.336165105386417','8.336165105386417','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','WTCBNB','4h','0.086700000000000','0.085500000000000','0.711908500000000','0.702055095155710','8.211170703575549','8.211170703575549','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','WTCBNB','4h','0.084300000000000','0.072900000000000','0.711908500000000','0.615636176156584','8.444940688018981','8.444940688018981','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WTCBNB','4h','0.081700000000000','0.079900000000000','0.474605666666667','0.464149238270094','5.809126886984905','5.809126886984905','test'),('2019-03-27 19:59:59','2019-03-27 23:59:59','WTCBNB','4h','0.080500000000000','0.080200000000000','0.526701267352636','0.524738405486726','6.542872886368153','6.542872886368153','test'),('2019-03-28 03:59:59','2019-03-28 07:59:59','WTCBNB','4h','0.080600000000000','0.085900000000000','0.526701267352636','0.561335469796420','6.534755178072406','6.534755178072406','test'),('2019-04-11 23:59:59','2019-04-12 03:59:59','WTCBNB','4h','0.112900000000000','0.115400000000000','0.534869102497105','0.546712971020070','4.737547409186048','4.737547409186048','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','WTCBNB','4h','0.112900000000000','0.113400000000000','0.537830069627846','0.540211956561539','4.763773867385706','4.763773867385706','test'),('2019-04-15 03:59:59','2019-04-15 11:59:59','WTCBNB','4h','0.113400000000000','0.111800000000000','0.538425541361269','0.530828708326189','4.7480206469247745','4.748020646924775','test'),('2019-04-17 11:59:59','2019-04-17 23:59:59','WTCBNB','4h','0.113600000000000','0.112900000000000','0.538425541361269','0.535107778342317','4.739661455644973','4.739661455644973','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','WTCBNB','4h','0.111400000000000','0.109800000000000','0.538425541361269','0.530692319941358','4.833263387444066','4.833263387444066','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','WTCBNB','4h','0.116500000000000','0.108300000000000','0.538425541361269','0.500527777934982','4.6216784666203345','4.621678466620335','test'),('2019-04-23 07:59:59','2019-04-23 11:59:59','WTCBNB','4h','0.110200000000000','0.113600000000000','0.538425541361269','0.555037581657352','4.885894204730208','4.885894204730208','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','WTCBNB','4h','0.115600000000000','0.113200000000000','0.538425541361269','0.527247156419512','4.657660392398521','4.657660392398521','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:32:50
