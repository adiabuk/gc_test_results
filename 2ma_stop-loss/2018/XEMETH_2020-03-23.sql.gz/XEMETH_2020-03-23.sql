-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-25 03:59:59','2018-09-25 23:59:59','XEMETH','4h','0.000420610000000','0.000419440000000','0.072144500000000','0.071943817503150','171.52350158103707','171.523501581037067','test'),('2018-10-01 11:59:59','2018-10-09 19:59:59','XEMETH','4h','0.000431620000000','0.000467400000000','0.072144500000000','0.078125062091655','167.14818590426765','167.148185904267649','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','XEMETH','4h','0.000470120000000','0.000464220000000','0.073589469898701','0.072665922990673','156.53337424211105','156.533374242111051','test'),('2018-10-17 23:59:59','2018-10-18 03:59:59','XEMETH','4h','0.000464880000000','0.000462840000000','0.073589469898701','0.073266542436575','158.29777555218766','158.297775552187659','test'),('2018-10-18 11:59:59','2018-10-19 03:59:59','XEMETH','4h','0.000466960000000','0.000469500000000','0.073589469898701','0.073989755262635','157.59266296620908','157.592662966209076','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','XEMETH','4h','0.000465380000000','0.000465890000000','0.073589469898701','0.073670115026657','158.12770187524387','158.127701875243872','test'),('2018-10-25 15:59:59','2018-10-25 19:59:59','XEMETH','4h','0.000476410000000','0.000478240000000','0.073589469898701','0.073872143918798','154.46667764887596','154.466677648875958','test'),('2018-10-26 19:59:59','2018-10-26 23:59:59','XEMETH','4h','0.000477530000000','0.000474520000000','0.073589469898701','0.073125615681385','154.1043911350093','154.104391135009308','test'),('2018-11-02 19:59:59','2018-11-03 11:59:59','XEMETH','4h','0.000471000000000','0.000466750000000','0.073589469898701','0.072925446019573','156.2409127360955','156.240912736095510','test'),('2018-11-12 11:59:59','2018-11-24 23:59:59','XEMETH','4h','0.000501130000000','0.000600110000000','0.073589469898701','0.088124392434916','146.84706542953123','146.847065429531227','test'),('2019-01-11 11:59:59','2019-01-11 19:59:59','XEMETH','4h','0.000469060000000','0.000460810000000','0.076820513544102','0.075469366064592','163.77545206178797','163.775452061787973','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','XEMETH','4h','0.000454900000000','0.000450730000000','0.076820513544102','0.076116311430497','168.8734085383645','168.873408538364487','test'),('2019-01-15 23:59:59','2019-01-16 11:59:59','XEMETH','4h','0.000460760000000','0.000454820000000','0.076820513544102','0.075830163143781','166.72565661971962','166.725656619719615','test'),('2019-02-14 23:59:59','2019-02-15 11:59:59','XEMETH','4h','0.000351740000000','0.000343350000000','0.076820513544102','0.074988125676259','218.40141452238018','218.401414522380179','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','XEMETH','4h','0.000316490000000','0.000305280000000','0.076820513544102','0.074099549353039','242.72651124554332','242.726511245543321','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XEMETH','4h','0.000312620000000','0.000310200000000','0.076820513544102','0.076225843840383','245.73128252863543','245.731282528635433','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','XEMETH','4h','0.000312200000000','0.000311970000000','0.076820513544102','0.076763919315674','246.0618627293466','246.061862729346586','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','XEMETH','4h','0.000314230000000','0.000313380000000','0.076820513544102','0.076612712135858','244.47224499284604','244.472244992846043','test'),('2019-04-08 19:59:59','2019-04-09 07:59:59','XEMETH','4h','0.000418070000000','0.000410000000000','0.076820513544102','0.075337648128500','183.7503612890234','183.750361289023402','test'),('2019-04-13 03:59:59','2019-04-13 15:59:59','XEMETH','4h','0.000411210000000','0.000405500000000','0.076820513544102','0.075753795486815','186.81577185404538','186.815771854045380','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','XEMETH','4h','0.000405730000000','0.000409150000000','0.076820513544102','0.077468052933156','189.339002647332','189.339002647331995','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','XEMETH','4h','0.000378100000000','0.000372990000000','0.076820513544102','0.075782288671819','203.1751217775774','203.175121777577402','test'),('2019-04-27 03:59:59','2019-04-27 15:59:59','XEMETH','4h','0.000381070000000','0.000377170000000','0.076820513544102','0.076034306278188','201.5916066447162','201.591606644716194','test'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XEMETH','4h','0.000323690000000','0.000359530000000','0.076820513544102','0.085326328383673','237.32742297909112','237.327422979091125','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','XEMETH','4h','0.000347960000000','0.000339640000000','0.076820513544102','0.074983674043335','220.77397845758708','220.773978457587077','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','XEMETH','4h','0.000339390000000','0.000336770000000','0.076820513544102','0.076227479732011','226.3487832408203','226.348783240820296','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','XEMETH','4h','0.000338630000000','0.000343670000000','0.076820513544102','0.077963871747044','226.85678629803033','226.856786298030329','test'),('2019-05-28 23:59:59','2019-05-29 03:59:59','XEMETH','4h','0.000338430000000','0.000331720000000','0.076820513544102','0.075297404937061','226.9908505277369','226.990850527736910','test'),('2019-05-29 19:59:59','2019-05-29 23:59:59','XEMETH','4h','0.000342000000000','0.000336230000000','0.076820513544102','0.075524448154776','224.6213846318772','224.621384631877191','test'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XEMETH','4h','0.000344080000000','0.000344430000000','0.076820513544102','0.076898655777712','223.2635245992269','223.263524599226912','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','XEMETH','4h','0.000348790000000','0.000344840000000','0.076820513544102','0.075950531524838','220.24861247198027','220.248612471980266','test'),('2019-06-17 07:59:59','2019-06-17 11:59:59','XEMETH','4h','0.000336700000000','0.000330670000000','0.076820513544102','0.075444725909202','228.15715338313635','228.157153383136347','test'),('2019-06-28 03:59:59','2019-06-29 23:59:59','XEMETH','4h','0.000309170000000','0.000309090000000','0.076820513544102','0.076800635674051','248.4733756318595','248.473375631859511','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','XEMETH','4h','0.000310930000000','0.000315720000000','0.076820513544102','0.078003964030952','247.0669074843277','247.066907484327686','test'),('2019-07-04 19:59:59','2019-07-05 07:59:59','XEMETH','4h','0.000311250000000','0.000311000000000','0.076820513544102','0.076758810320372','246.81289492080967','246.812894920809669','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','XEMETH','4h','0.000310230000000','0.000311110000000','0.076820513544102','0.077038423004563','247.62438688747707','247.624386887477073','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','XEMETH','4h','0.000316380000000','0.000302600000000','0.076820513544102','0.073474579298455','242.81090316739997','242.810903167399971','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','XEMETH','4h','0.000302140000000','0.000306250000000','0.076820513544102','0.077865500340509','254.25469498941553','254.254694989415526','test'),('2019-07-27 11:59:59','2019-07-28 07:59:59','XEMETH','4h','0.000305900000000','0.000303530000000','0.076820513544102','0.076225336633022','251.12949834619812','251.129498346198119','test'),('2019-07-29 19:59:59','2019-07-29 23:59:59','XEMETH','4h','0.000302980000000','0.000300540000000','0.076820513544102','0.076201852071240','253.54978395967393','253.549783959673931','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','XEMETH','4h','0.000303240000000','0.000304270000000','0.076820513544102','0.077081445904445','253.3323886825683','253.332388682568308','test'),('2019-08-01 03:59:59','2019-08-01 07:59:59','XEMETH','4h','0.000304860000000','0.000302580000000','0.076820513544102','0.076245985003524','251.98620200781343','251.986202007813432','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','XEMETH','4h','0.000304630000000','0.000299080000000','0.076820513544102','0.075420934217805','252.176455188596','252.176455188596009','test'),('2019-08-11 03:59:59','2019-08-11 11:59:59','XEMETH','4h','0.000289350000000','0.000285970000000','0.076820513544102','0.075923145872496','265.4933939661379','265.493393966137887','test'),('2019-08-14 19:59:59','2019-08-18 15:59:59','XEMETH','4h','0.000284010000000','0.000284850000000','0.076820513544102','0.077047721147275','270.4852418721242','270.485241872124220','test'),('2019-08-19 15:59:59','2019-08-19 19:59:59','XEMETH','4h','0.000284920000000','0.000284280000000','0.076820513544102','0.076647955883467','269.6213447427419','269.621344742741883','test'),('2019-08-21 03:59:59','2019-08-22 15:59:59','XEMETH','4h','0.000289830000000','0.000282870000000','0.076820513544102','0.074975739799952','265.05369887210435','265.053698872104349','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','XEMETH','4h','0.000286740000000','0.000291180000000','0.076820513544102','0.078010033946333','267.91000050255286','267.910000502552862','test'),('2019-08-30 07:59:59','2019-08-31 15:59:59','XEMETH','4h','0.000293240000000','0.000289680000000','0.076820513544102','0.075887895114771','261.97146891318374','261.971468913183742','test'),('2019-09-02 03:59:59','2019-09-02 07:59:59','XEMETH','4h','0.000294090000000','0.000289830000000','0.076820513544102','0.075707740625275','261.21430019416505','261.214300194165048','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:56:28
