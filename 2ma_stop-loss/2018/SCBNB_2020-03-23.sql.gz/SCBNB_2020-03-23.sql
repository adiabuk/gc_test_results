-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-10 07:59:59','2018-12-10 11:59:59','SCBNB','4h','0.000540000000000','0.000515000000000','0.711908500000000','0.678949773148148','1318.3490740740742','1318.349074074074224','test'),('2018-12-20 15:59:59','2018-12-20 23:59:59','SCBNB','4h','0.000500000000000','0.000494000000000','0.711908500000000','0.703365598000000','1423.817','1423.817000000000007','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','SCBNB','4h','0.000505000000000','0.000481000000000','0.711908500000000','0.678075224752475','1409.719801980198','1409.719801980198099','test'),('2018-12-23 19:59:59','2018-12-23 23:59:59','SCBNB','4h','0.000507000000000','0.000498000000000','0.711908500000000','0.699271071005917','1404.1587771203158','1404.158777120315790','test'),('2018-12-24 19:59:59','2018-12-24 23:59:59','SCBNB','4h','0.000499000000000','0.000491000000000','0.711908500000000','0.700495137274549','1426.6703406813629','1426.670340681362859','test'),('2018-12-25 15:59:59','2018-12-25 19:59:59','SCBNB','4h','0.000498000000000','0.000499000000000','0.711908500000000','0.713338035140562','1429.5351405622491','1429.535140562249126','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','SCBNB','4h','0.000408000000000','0.000392000000000','0.711908500000000','0.683990519607843','1744.873774509804','1744.873774509803980','test'),('2019-01-29 19:59:59','2019-01-31 11:59:59','SCBNB','4h','0.000379000000000','0.000380000000000','0.711908500000000','0.713786886543536','1878.3865435356201','1878.386543535620149','test'),('2019-02-21 19:59:59','2019-02-21 23:59:59','SCBNB','4h','0.000259000000000','0.000254000000000','0.711908500000000','0.698165092664093','2748.6814671814673','2748.681467181467269','test'),('2019-02-26 03:59:59','2019-02-27 07:59:59','SCBNB','4h','0.000252000000000','0.000248000000000','0.711908500000000','0.700608365079365','2825.0337301587306','2825.033730158730577','test'),('2019-03-15 15:59:59','2019-03-16 03:59:59','SCBNB','4h','0.000186000000000','0.000184000000000','0.711908500000000','0.704253569892473','3827.465053763441','3827.465053763441119','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','SCBNB','4h','0.000181000000000','0.000179000000000','0.711908500000000','0.704042107734807','3933.1961325966854','3933.196132596685402','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','SCBNB','4h','0.000180000000000','0.000180000000000','0.711908500000000','0.711908500000000','3955.0472222222224','3955.047222222222445','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','SCBNB','4h','0.000182000000000','0.000179000000000','0.711908500000000','0.700173744505495','3911.585164835165','3911.585164835164960','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','SCBNB','4h','0.000175000000000','0.000173000000000','0.711908500000000','0.703772402857143','4068.048571428572','4068.048571428571904','test'),('2019-04-11 15:59:59','2019-04-11 19:59:59','SCBNB','4h','0.000182000000000','0.000181000000000','0.711908500000000','0.707996914835165','3911.585164835165','3911.585164835164960','test'),('2019-05-01 11:59:59','2019-05-01 15:59:59','SCBNB','4h','0.000131000000000','0.000127000000000','0.711908500000000','0.690170835877863','5434.416030534351','5434.416030534351194','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','SCBNB','4h','0.000126000000000','0.000124000000000','0.711908500000000','0.700608365079365','5650.067460317461','5650.067460317461155','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','SCBNB','4h','0.000126000000000','0.000123000000000','0.711908500000000','0.694958297619048','5650.067460317461','5650.067460317461155','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','SCBNB','4h','0.000125000000000','0.000120000000000','0.711908500000000','0.683432160000000','5695.268','5695.268000000000029','test'),('2019-05-09 15:59:59','2019-05-10 03:59:59','SCBNB','4h','0.000124000000000','0.000130000000000','0.711908500000000','0.746355685483871','5741.197580645162','5741.197580645161906','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','SCBNB','4h','0.000128000000000','0.000130000000000','0.711908500000000','0.723032070312500','5561.785156250001','5561.785156250000909','test'),('2019-05-15 23:59:59','2019-05-17 03:59:59','SCBNB','4h','0.000130000000000','0.000131000000000','0.711908500000000','0.717384719230769','5476.219230769232','5476.219230769232126','test'),('2019-05-30 15:59:59','2019-05-30 19:59:59','SCBNB','4h','0.000111000000000','0.000108000000000','0.711908500000000','0.692667729729730','6413.590090090091','6413.590090090090598','test'),('2019-06-02 07:59:59','2019-06-02 11:59:59','SCBNB','4h','0.000110000000000','0.000108000000000','0.711908500000000','0.698964709090909','6471.895454545454','6471.895454545454413','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','SCBNB','4h','0.000112000000000','0.000109000000000','0.711908500000000','0.692839522321429','6356.325892857143','6356.325892857143117','test'),('2019-06-16 03:59:59','2019-06-16 07:59:59','SCBNB','4h','0.000100000000000','0.000099000000000','0.711908500000000','0.704789415000000','7119.085','7119.085000000000036','test'),('2019-06-25 11:59:59','2019-06-25 15:59:59','SCBNB','4h','0.000091000000000','0.000092000000000','0.711908500000000','0.719731670329670','7823.17032967033','7823.170329670329920','test'),('2019-06-28 11:59:59','2019-06-29 03:59:59','SCBNB','4h','0.000094000000000','0.000093000000000','0.711908500000000','0.704335005319149','7573.494680851065','7573.494680851064913','test'),('2019-07-02 19:59:59','2019-07-02 23:59:59','SCBNB','4h','0.000094000000000','0.000094000000000','0.711908500000000','0.711908500000000','7573.494680851065','7573.494680851064913','test'),('2019-07-06 23:59:59','2019-07-07 03:59:59','SCBNB','4h','0.000094000000000','0.000095000000000','0.711908500000000','0.719481994680851','7573.494680851065','7573.494680851064913','test'),('2019-07-08 19:59:59','2019-07-08 23:59:59','SCBNB','4h','0.000096000000000','0.000095000000000','0.711908500000000','0.704492786458333','7415.713541666667','7415.713541666666970','test'),('2019-07-12 23:59:59','2019-07-13 03:59:59','SCBNB','4h','0.000099300000000','0.000099500000000','0.711908500000000','0.713342353977845','7169.269889224573','7169.269889224572580','test'),('2019-07-15 03:59:59','2019-07-16 19:59:59','SCBNB','4h','0.000100000000000','0.000100900000000','0.711908500000000','0.718315676500000','7119.085','7119.085000000000036','test'),('2019-07-18 19:59:59','2019-07-19 03:59:59','SCBNB','4h','0.000101400000000','0.000100200000000','0.711908500000000','0.703483547337278','7020.793885601579','7020.793885601578950','test'),('2019-07-27 03:59:59','2019-07-27 11:59:59','SCBNB','4h','0.000097300000000','0.000096700000000','0.711908500000000','0.707518519527235','7316.63412127441','7316.634121274410063','test'),('2019-07-29 03:59:59','2019-07-30 23:59:59','SCBNB','4h','0.000097700000000','0.000097100000000','0.711908500000000','0.707536492835210','7286.678607983624','7286.678607983623806','test'),('2019-07-31 15:59:59','2019-08-01 07:59:59','SCBNB','4h','0.000099000000000','0.000098400000000','0.711908500000000','0.707593903030303','7190.994949494951','7190.994949494950561','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','SCBNB','4h','0.000099800000000','0.000098100000000','0.711908500000000','0.699781802104208','7133.3517034068145','7133.351703406814522','test'),('2019-08-23 19:59:59','2019-08-26 11:59:59','SCBNB','4h','0.000074900000000','0.000076900000000','0.711908500000000','0.730918072763685','9504.786381842458','9504.786381842457558','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','SCBNB','4h','0.000081900000000','0.000081000000000','0.711908500000000','0.704085329670330','8692.411477411479','8692.411477411478700','test'),('2019-09-13 19:59:59','2019-09-17 15:59:59','SCBNB','4h','0.000083700000000','0.000084900000000','0.711908500000000','0.722115073476703','8505.47789725209','8505.477897252090770','test'),('2019-09-18 19:59:59','2019-09-19 03:59:59','SCBNB','4h','0.000084100000000','0.000086000000000','0.711908500000000','0.727992045184304','8465.023781212843','8465.023781212843460','test'),('2019-10-08 15:59:59','2019-10-15 07:59:59','SCBNB','4h','0.000105100000000','0.000118200000000','0.711908500000000','0.800643051379639','6773.629876308279','6773.629876308278654','test'),('2019-10-17 23:59:59','2019-10-18 11:59:59','SCBNB','4h','0.000121500000000','0.000120200000000','0.711908500000000','0.704291372016461','5859.329218106996','5859.329218106996450','test'),('2019-11-01 23:59:59','2019-11-02 03:59:59','SCBNB','4h','0.000104900000000','0.000104900000000','0.711908500000000','0.711908500000000','6786.544327931364','6786.544327931364023','test'),('2019-11-02 19:59:59','2019-11-02 23:59:59','SCBNB','4h','0.000105000000000','0.000103400000000','0.711908500000000','0.701060370476191','6780.080952380953','6780.080952380953022','test'),('2019-11-07 23:59:59','2019-11-08 11:59:59','SCBNB','4h','0.000102900000000','0.000102000000000','0.711908500000000','0.705681895043732','6918.449951409136','6918.449951409135792','test'),('2019-11-14 03:59:59','2019-11-14 07:59:59','SCBNB','4h','0.000100500000000','0.000098000000000','0.711908500000000','0.694199333333333','7083.666666666667','7083.666666666666970','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','SCBNB','4h','0.000098900000000','0.000098900000000','0.711908500000000','0.711908500000000','7198.265925176946','7198.265925176946439','test'),('2019-11-18 03:59:59','2019-11-18 15:59:59','SCBNB','4h','0.000099300000000','0.000099300000000','0.711908500000000','0.711908500000000','7169.269889224573','7169.269889224572580','test'),('2019-11-19 11:59:59','2019-11-20 11:59:59','SCBNB','4h','0.000099900000000','0.000096600000000','0.711908500000000','0.688392003003003','7126.211211211212','7126.211211211211776','test'),('2019-11-20 19:59:59','2019-11-21 03:59:59','SCBNB','4h','0.000101000000000','0.000099800000000','0.711908500000000','0.703450181188119','7048.5990099009905','7048.599009900990495','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','SCBNB','4h','0.000102300000000','0.000104000000000','0.711908500000000','0.723738846529814','6959.027370478983','6959.027370478983357','test'),('2019-11-25 23:59:59','2019-11-26 03:59:59','SCBNB','4h','0.000099900000000','0.000096100000000','0.711908500000000','0.684828897397397','7126.211211211212','7126.211211211211776','test'),('2019-11-26 23:59:59','2019-11-27 03:59:59','SCBNB','4h','0.000099600000000','0.000098800000000','0.711908500000000','0.706190359437751','7147.675702811246','7147.675702811246083','test'),('2019-11-28 03:59:59','2019-11-29 03:59:59','SCBNB','4h','0.000100800000000','0.000101300000000','0.711908500000000','0.715439792162698','7062.584325396826','7062.584325396825989','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:00:45
