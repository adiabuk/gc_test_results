-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 19:59:59','2018-06-03 23:59:59','AMBBNB','4h','0.030560000000000','0.029640000000000','0.711908500000000','0.690476699607330','23.295435209424085','23.295435209424085','test'),('2018-06-26 23:59:59','2018-06-27 03:59:59','AMBBNB','4h','0.019100000000000','0.017510000000000','0.711908500000000','0.652644912827225','37.27269633507854','37.272696335078543','test'),('2018-06-28 19:59:59','2018-06-28 23:59:59','AMBBNB','4h','0.019410000000000','0.017830000000000','0.711908500000000','0.653958194487378','36.67740855229263','36.677408552292633','test'),('2018-06-29 11:59:59','2018-06-29 15:59:59','AMBBNB','4h','0.018900000000000','0.018690000000000','0.711908500000000','0.703998405555556','37.667116402116406','37.667116402116406','test'),('2018-07-12 03:59:59','2018-07-12 07:59:59','AMBBNB','4h','0.024080000000000','0.022560000000000','0.711908500000000','0.666970754152824','29.564306478405317','29.564306478405317','test'),('2018-07-13 03:59:59','2018-07-13 07:59:59','AMBBNB','4h','0.023120000000000','0.022430000000000','0.711908500000000','0.690662095804498','30.791890138408306','30.791890138408306','test'),('2018-07-13 11:59:59','2018-07-13 15:59:59','AMBBNB','4h','0.022970000000000','0.023180000000000','0.711908500000000','0.718417023508925','30.992969090117548','30.992969090117548','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','AMBBNB','4h','0.023070000000000','0.022230000000000','0.711908500000000','0.685987254226268','30.858625921109667','30.858625921109667','test'),('2018-07-15 19:59:59','2018-07-16 03:59:59','AMBBNB','4h','0.023240000000000','0.022800000000000','0.711908500000000','0.698430025817556','30.632895869191053','30.632895869191053','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','AMBBNB','4h','0.022900000000000','0.022430000000000','0.711908500000000','0.697297277510917','31.087707423580788','31.087707423580788','test'),('2018-07-17 03:59:59','2018-07-17 11:59:59','AMBBNB','4h','0.022680000000000','0.022680000000000','0.711908500000000','0.711908500000000','31.38926366843034','31.389263668430338','test'),('2018-07-20 11:59:59','2018-07-20 15:59:59','AMBBNB','4h','0.023420000000000','0.021980000000000','0.711908500000000','0.668136158411614','30.397459436379165','30.397459436379165','test'),('2018-07-21 11:59:59','2018-07-21 23:59:59','AMBBNB','4h','0.023430000000000','0.023190000000000','0.711908500000000','0.704616223431498','30.38448570209134','30.384485702091339','test'),('2018-07-22 11:59:59','2018-07-22 19:59:59','AMBBNB','4h','0.024010000000000','0.023760000000000','0.711908500000000','0.704495875052062','29.65049979175344','29.650499791753440','test'),('2018-07-23 07:59:59','2018-07-23 23:59:59','AMBBNB','4h','0.023950000000000','0.023100000000000','0.711908500000000','0.686642436325679','29.724780793319418','29.724780793319418','test'),('2018-08-16 15:59:59','2018-08-16 19:59:59','AMBBNB','4h','0.013310000000000','0.012470000000000','0.711908500000000','0.666979638993238','53.48673929376409','53.486739293764089','test'),('2018-08-17 15:59:59','2018-08-17 23:59:59','AMBBNB','4h','0.013000000000000','0.012210000000000','0.711908500000000','0.668646368076923','54.76219230769232','54.762192307692317','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','AMBBNB','4h','0.013310000000000','0.012950000000000','0.711908500000000','0.692653273854245','53.48673929376409','53.486739293764089','test'),('2018-08-19 15:59:59','2018-08-20 23:59:59','AMBBNB','4h','0.012960000000000','0.012470000000000','0.711908500000000','0.684992206404321','54.93121141975309','54.931211419753090','test'),('2018-08-21 11:59:59','2018-08-21 15:59:59','AMBBNB','4h','0.013220000000000','0.012970000000000','0.711908500000000','0.698445782526475','53.85086989409985','53.850869894099851','test'),('2018-08-23 15:59:59','2018-08-24 03:59:59','AMBBNB','4h','0.013120000000000','0.012910000000000','0.711908500000000','0.700513623094512','54.26131859756098','54.261318597560980','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','AMBBNB','4h','0.013030000000000','0.013300000000000','0.711908500000000','0.726660249424405','54.63610897927859','54.636108979278589','test'),('2018-09-07 07:59:59','2018-09-07 11:59:59','AMBBNB','4h','0.015670000000000','0.014020000000000','0.711908500000000','0.636946851946394','45.431301850670074','45.431301850670074','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','AMBBNB','4h','0.013450000000000','0.012470000000000','0.711908500000000','0.660037100000000','52.93000000000001','52.930000000000007','test'),('2018-09-18 19:59:59','2018-09-18 23:59:59','AMBBNB','4h','0.013360000000000','0.012790000000000','0.711908500000000','0.681535158308383','53.28656437125749','53.286564371257491','test'),('2018-09-19 07:59:59','2018-09-19 11:59:59','AMBBNB','4h','0.013000000000000','0.013210000000000','0.711908500000000','0.723408560384615','54.76219230769232','54.762192307692317','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','AMBBNB','4h','0.014440000000000','0.014730000000000','0.711908500000000','0.726205831371191','49.30114265927978','49.301142659279783','test'),('2018-10-05 23:59:59','2018-10-06 03:59:59','AMBBNB','4h','0.014100000000000','0.014200000000000','0.711908500000000','0.716957496453901','50.4899645390071','50.489964539007097','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','AMBBNB','4h','0.014160000000000','0.013780000000000','0.711908500000000','0.692803610875706','50.276024011299434','50.276024011299434','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','AMBBNB','4h','0.014450000000000','0.014280000000000','0.711908500000000','0.703533105882353','49.26702422145329','49.267024221453291','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','AMBBNB','4h','0.019520000000000','0.019290000000000','0.711908500000000','0.703520233862705','36.47072233606558','36.470722336065577','test'),('2018-10-30 23:59:59','2018-10-31 03:59:59','AMBBNB','4h','0.019640000000000','0.019840000000000','0.711908500000000','0.719158077393075','36.247886965376786','36.247886965376786','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','AMBBNB','4h','0.019660000000000','0.019590000000000','0.711908500000000','0.709373729145473','36.21101220752798','36.211012207527979','test'),('2018-11-03 07:59:59','2018-11-03 11:59:59','AMBBNB','4h','0.019670000000000','0.019530000000000','0.711908500000000','0.706841535587189','36.19260294865278','36.192602948652777','test'),('2018-11-05 19:59:59','2018-11-05 23:59:59','AMBBNB','4h','0.019580000000000','0.019440000000000','0.711908500000000','0.706818245148110','36.358963227783455','36.358963227783455','test'),('2018-11-08 11:59:59','2018-11-08 15:59:59','AMBBNB','4h','0.019630000000000','0.019350000000000','0.711908500000000','0.701753921293938','36.26635252165053','36.266352521650532','test'),('2018-11-09 19:59:59','2018-11-09 23:59:59','AMBBNB','4h','0.019640000000000','0.019760000000000','0.711908500000000','0.716258246435845','36.247886965376786','36.247886965376786','test'),('2018-11-28 15:59:59','2018-11-28 23:59:59','AMBBNB','4h','0.015870000000000','0.015660000000000','0.711908500000000','0.702488160680529','44.858758664146194','44.858758664146194','test'),('2018-11-30 11:59:59','2018-11-30 15:59:59','AMBBNB','4h','0.016060000000000','0.015730000000000','0.711908500000000','0.697280243150685','44.32805105853051','44.328051058530512','test'),('2018-12-01 07:59:59','2018-12-02 03:59:59','AMBBNB','4h','0.016200000000000','0.015930000000000','0.711908500000000','0.700043358333333','43.944969135802474','43.944969135802474','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','AMBBNB','4h','0.016000000000000','0.014510000000000','0.711908500000000','0.645612020937500','44.49428125','44.494281250000000','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','AMBBNB','4h','0.012570000000000','0.012420000000000','0.474605666666667','0.468942114558473','37.757014054627426','37.757014054627426','test'),('2018-12-20 19:59:59','2018-12-21 15:59:59','AMBBNB','4h','0.012690000000000','0.012560000000000','0.519457603544045','0.514136130852104','40.934405322619746','40.934405322619746','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','AMBBNB','4h','0.012420000000000','0.012390000000000','0.519457603544045','0.518202875033069','41.82428369919847','41.824283699198467','test'),('2018-12-24 15:59:59','2018-12-24 23:59:59','AMBBNB','4h','0.012400000000000','0.012390000000000','0.519457603544045','0.519038686121832','41.89174222129395','41.891742221293953','test'),('2018-12-25 07:59:59','2018-12-25 11:59:59','AMBBNB','4h','0.012330000000000','0.011870000000000','0.519457603544045','0.500078001140942','42.12957044152839','42.129570441528386','test'),('2018-12-25 23:59:59','2018-12-26 03:59:59','AMBBNB','4h','0.012820000000000','0.011970000000000','0.519457603544045','0.485016186772404','40.51931384898947','40.519313848989469','test'),('2019-01-01 19:59:59','2019-01-02 03:59:59','AMBBNB','4h','0.012360000000000','0.012060000000000','0.519457603544045','0.506849409283267','42.02731420259264','42.027314202592642','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','AMBBNB','4h','0.011900000000000','0.012040000000000','0.519457603544045','0.525568869468093','43.65189945748277','43.651899457482770','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','AMBBNB','4h','0.011990000000000','0.011920000000000','0.519457603544045','0.516424906942870','43.32423715963678','43.324237159636780','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','AMBBNB','4h','0.011410000000000','0.010810000000000','0.519457603544045','0.492141691000099','45.526520906577126','45.526520906577126','test'),('2019-03-15 19:59:59','2019-03-15 23:59:59','AMBBNB','4h','0.004250000000000','0.004180000000000','0.519457603544045','0.510901831250378','122.22531848095176','122.225318480951756','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','AMBBNB','4h','0.003970000000000','0.003820000000000','0.519457603544045','0.499830741949182','130.84574396575442','130.845743965754423','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','AMBBNB','4h','0.003770000000000','0.003600000000000','0.519457603544045','0.496033785877603','137.7871627437785','137.787162743778509','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','AMBBNB','4h','0.003790000000000','0.003710000000000','0.519457603544045','0.508492799247601','137.06005370555278','137.060053705552775','test'),('2019-03-31 15:59:59','2019-03-31 23:59:59','AMBBNB','4h','0.003840000000000','0.003850000000000','0.519457603544045','0.520810357719941','135.27541758959507','135.275417589595065','test'),('2019-04-01 15:59:59','2019-04-01 19:59:59','AMBBNB','4h','0.003870000000000','0.003810000000000','0.519457603544045','0.511403997287548','134.2267709416137','134.226770941613694','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','AMBBNB','4h','0.003900000000000','0.003850000000000','0.519457603544045','0.512797890678096','133.1942573189859','133.194257318985905','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','AMBBNB','4h','0.004050000000000','0.003780000000000','0.519457603544045','0.484827096641109','128.261136677542','128.261136677541998','test'),('2019-04-07 15:59:59','2019-04-07 23:59:59','AMBBNB','4h','0.003850000000000','0.003810000000000','0.519457603544045','0.514060641429302','134.92405286858312','134.924052868583118','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:14:46
