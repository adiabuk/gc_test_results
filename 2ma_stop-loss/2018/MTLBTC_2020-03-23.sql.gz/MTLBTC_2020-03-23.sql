-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-04 03:59:59','2018-04-04 07:59:59','MTLBTC','4h','0.000515400000000','0.000510200000000','0.001467500000000','0.001452694024059','2.847303065580132','2.847303065580132','test'),('2018-04-04 11:59:59','2018-04-04 15:59:59','MTLBTC','4h','0.000519900000000','0.000509100000000','0.001467500000000','0.001437015291402','2.8226582035006733','2.822658203500673','test'),('2018-04-11 23:59:59','2018-04-12 03:59:59','MTLBTC','4h','0.000490900000000','0.000487900000000','0.001467500000000','0.001458531778366','2.9894072112446533','2.989407211244653','test'),('2018-04-13 07:59:59','2018-04-13 11:59:59','MTLBTC','4h','0.000488500000000','0.000479900000000','0.001467500000000','0.001441664790174','3.0040941658137155','3.004094165813715','test'),('2018-04-13 19:59:59','2018-04-13 23:59:59','MTLBTC','4h','0.000487900000000','0.000469200000000','0.001467500000000','0.001411254355401','3.0077884812461573','3.007788481246157','test'),('2018-04-15 07:59:59','2018-04-15 11:59:59','MTLBTC','4h','0.000486000000000','0.000475100000000','0.001467500000000','0.001434586934156','3.019547325102881','3.019547325102881','test'),('2018-04-15 23:59:59','2018-04-16 03:59:59','MTLBTC','4h','0.000484800000000','0.000467200000000','0.001467500000000','0.001414224422442','3.0270214521452146','3.027021452145215','test'),('2018-04-17 15:59:59','2018-04-17 19:59:59','MTLBTC','4h','0.000485400000000','0.000481800000000','0.001467500000000','0.001456616192831','3.023279769262464','3.023279769262464','test'),('2018-04-26 19:59:59','2018-04-26 23:59:59','MTLBTC','4h','0.000517900000000','0.000516600000000','0.001467500000000','0.001463816373817','2.8335586020467276','2.833558602046728','test'),('2018-05-01 07:59:59','2018-05-01 11:59:59','MTLBTC','4h','0.000530000000000','0.000527000000000','0.001467500000000','0.001459193396226','2.768867924528302','2.768867924528302','test'),('2018-05-04 19:59:59','2018-05-04 23:59:59','MTLBTC','4h','0.000549900000000','0.000540900000000','0.001467500000000','0.001443481996727','2.6686670303691584','2.668667030369158','test'),('2018-05-30 23:59:59','2018-05-31 11:59:59','MTLBTC','4h','0.000404600000000','0.000397500000000','0.001467500000000','0.001441748022739','3.627039050914483','3.627039050914483','test'),('2018-05-31 15:59:59','2018-05-31 19:59:59','MTLBTC','4h','0.000402300000000','0.000398800000000','0.001467500000000','0.001454732786478','3.647775292070594','3.647775292070594','test'),('2018-07-03 03:59:59','2018-07-03 07:59:59','MTLBTC','4h','0.000227800000000','0.000222900000000','0.001467500000000','0.001435933933275','6.442054433713784','6.442054433713784','test'),('2018-07-06 15:59:59','2018-07-06 19:59:59','MTLBTC','4h','0.000254000000000','0.000246300000000','0.001467500000000','0.001423012795276','5.77755905511811','5.777559055118110','test'),('2018-07-18 07:59:59','2018-07-18 11:59:59','MTLBTC','4h','0.000209100000000','0.000202000000000','0.001467500000000','0.001417670970827','7.0181731229077','7.018173122907700','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','MTLBTC','4h','0.000097900000000','0.000099400000000','0.001467500000000','0.001489984678243','14.989785495403474','14.989785495403474','test'),('2018-08-29 15:59:59','2018-08-29 19:59:59','MTLBTC','4h','0.000098700000000','0.000097200000000','0.001467500000000','0.001445197568389','14.868287740628167','14.868287740628167','test'),('2018-09-02 11:59:59','2018-09-02 19:59:59','MTLBTC','4h','0.000098500000000','0.000097400000000','0.001467500000000','0.001451111675127','14.898477157360407','14.898477157360407','test'),('2018-09-06 15:59:59','2018-09-07 07:59:59','MTLBTC','4h','0.000105500000000','0.000101300000000','0.001467500000000','0.001409078199052','13.909952606635072','13.909952606635072','test'),('2018-09-09 11:59:59','2018-09-09 19:59:59','MTLBTC','4h','0.000102600000000','0.000102100000000','0.001467500000000','0.001460348440546','14.303118908382066','14.303118908382066','test'),('2018-09-10 07:59:59','2018-09-10 19:59:59','MTLBTC','4h','0.000102300000000','0.000104500000000','0.001467500000000','0.001499059139785','14.345063538611925','14.345063538611925','test'),('2018-09-11 19:59:59','2018-09-16 23:59:59','MTLBTC','4h','0.000105300000000','0.000117800000000','0.001467500000000','0.001641704653371','13.936372269705604','13.936372269705604','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','MTLBTC','4h','0.000107100000000','0.000103700000000','0.001467500000000','0.001420912698413','13.702147525676938','13.702147525676938','test'),('2018-09-28 11:59:59','2018-09-28 15:59:59','MTLBTC','4h','0.000107300000000','0.000106200000000','0.001467500000000','0.001452455731594','13.676607642124884','13.676607642124884','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','MTLBTC','4h','0.000107400000000','0.000105800000000','0.001467500000000','0.001445637802607','13.663873370577281','13.663873370577281','test'),('2018-09-29 03:59:59','2018-09-29 07:59:59','MTLBTC','4h','0.000106400000000','0.000106200000000','0.001467500000000','0.001464741541353','13.792293233082708','13.792293233082708','test'),('2018-09-29 11:59:59','2018-09-29 19:59:59','MTLBTC','4h','0.000107100000000','0.000107600000000','0.001467500000000','0.001474351073763','13.702147525676938','13.702147525676938','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','MTLBTC','4h','0.000106300000000','0.000105000000000','0.001467500000000','0.001449553151458','13.80526810912512','13.805268109125119','test'),('2018-10-04 15:59:59','2018-10-04 19:59:59','MTLBTC','4h','0.000107300000000','0.000106100000000','0.001467500000000','0.001451088070829','13.676607642124884','13.676607642124884','test'),('2018-10-08 15:59:59','2018-10-09 11:59:59','MTLBTC','4h','0.000106700000000','0.000106000000000','0.001467500000000','0.001457872539831','13.753514526710402','13.753514526710402','test'),('2018-10-10 19:59:59','2018-10-10 23:59:59','MTLBTC','4h','0.000106900000000','0.000104000000000','0.001467500000000','0.001427689429373','13.727782974742752','13.727782974742752','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','MTLBTC','4h','0.000115000000000','0.000109900000000','0.001467500000000','0.001402419565217','12.76086956521739','12.760869565217391','test'),('2018-10-13 15:59:59','2018-10-15 07:59:59','MTLBTC','4h','0.000106600000000','0.000108600000000','0.001467500000000','0.001495032833021','13.76641651031895','13.766416510318949','test'),('2018-10-20 19:59:59','2018-10-20 23:59:59','MTLBTC','4h','0.000108000000000','0.000107100000000','0.001467500000000','0.001455270833333','13.587962962962964','13.587962962962964','test'),('2018-10-21 15:59:59','2018-10-21 19:59:59','MTLBTC','4h','0.000109500000000','0.000106700000000','0.001467500000000','0.001429974885845','13.401826484018265','13.401826484018265','test'),('2018-10-22 15:59:59','2018-10-22 19:59:59','MTLBTC','4h','0.000107800000000','0.000108200000000','0.001467500000000','0.001472945269017','13.613172541743971','13.613172541743971','test'),('2018-10-23 11:59:59','2018-10-23 15:59:59','MTLBTC','4h','0.000108900000000','0.000109000000000','0.001467500000000','0.001468847566575','13.475665748393022','13.475665748393022','test'),('2018-10-27 07:59:59','2018-10-27 15:59:59','MTLBTC','4h','0.000108400000000','0.000107000000000','0.001467500000000','0.001448547047970','13.537822878228782','13.537822878228782','test'),('2018-11-28 15:59:59','2018-11-29 15:59:59','MTLBTC','4h','0.000072300000000','0.000096600000000','0.001467500000000','0.001960726141079','20.29737206085754','20.297372060857541','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','MTLBTC','4h','0.000079500000000','0.000078500000000','0.001467500000000','0.001449040880503','18.459119496855347','18.459119496855347','test'),('2018-12-02 19:59:59','2018-12-02 23:59:59','MTLBTC','4h','0.000081000000000','0.000078100000000','0.001467500000000','0.001414959876543','18.117283950617285','18.117283950617285','test'),('2018-12-03 07:59:59','2018-12-04 07:59:59','MTLBTC','4h','0.000080200000000','0.000079100000000','0.001467500000000','0.001447372194514','18.298004987531172','18.298004987531172','test'),('2018-12-22 15:59:59','2018-12-22 19:59:59','MTLBTC','4h','0.000069800000000','0.000067300000000','0.001467500000000','0.001414939111748','21.0243553008596','21.024355300859600','test'),('2018-12-23 11:59:59','2018-12-23 15:59:59','MTLBTC','4h','0.000068000000000','0.000067400000000','0.001467500000000','0.001454551470588','21.580882352941178','21.580882352941178','test'),('2018-12-23 23:59:59','2018-12-24 03:59:59','MTLBTC','4h','0.000068600000000','0.000069000000000','0.001467500000000','0.001476056851312','21.392128279883384','21.392128279883384','test'),('2018-12-26 07:59:59','2018-12-26 11:59:59','MTLBTC','4h','0.000067500000000','0.000068900000000','0.001467500000000','0.001497937037037','21.74074074074074','21.740740740740740','test'),('2018-12-28 15:59:59','2018-12-28 19:59:59','MTLBTC','4h','0.000068500000000','0.000068300000000','0.001467500000000','0.001463215328467','21.423357664233578','21.423357664233578','test'),('2018-12-30 07:59:59','2018-12-30 11:59:59','MTLBTC','4h','0.000068100000000','0.000065900000000','0.001467500000000','0.001420091776799','21.549192364170338','21.549192364170338','test'),('2018-12-31 15:59:59','2018-12-31 23:59:59','MTLBTC','4h','0.000066800000000','0.000066800000000','0.001467500000000','0.001467500000000','21.9685628742515','21.968562874251500','test'),('2019-01-16 07:59:59','2019-01-17 15:59:59','MTLBTC','4h','0.000064700000000','0.000065200000000','0.001467500000000','0.001478840803709','22.68160741885626','22.681607418856260','test'),('2019-01-19 03:59:59','2019-01-19 11:59:59','MTLBTC','4h','0.000065000000000','0.000064800000000','0.001467500000000','0.001462984615385','22.57692307692308','22.576923076923080','test'),('2019-01-22 03:59:59','2019-01-22 07:59:59','MTLBTC','4h','0.000064900000000','0.000063700000000','0.001467500000000','0.001440365947612','22.61171032357473','22.611710323574730','test'),('2019-01-22 23:59:59','2019-01-23 07:59:59','MTLBTC','4h','0.000066500000000','0.000065700000000','0.001467500000000','0.001449845864662','22.06766917293233','22.067669172932330','test'),('2019-01-30 19:59:59','2019-02-01 03:59:59','MTLBTC','4h','0.000071400000000','0.000068000000000','0.001467500000000','0.001397619047619','20.553221288515406','20.553221288515406','test'),('2019-02-01 15:59:59','2019-02-06 03:59:59','MTLBTC','4h','0.000072400000000','0.000075300000000','0.001467500000000','0.001526281077348','20.269337016574585','20.269337016574585','test'),('2019-02-06 19:59:59','2019-02-06 23:59:59','MTLBTC','4h','0.000075200000000','0.000076100000000','0.001467500000000','0.001485063164894','19.51462765957447','19.514627659574469','test'),('2019-02-07 11:59:59','2019-02-09 23:59:59','MTLBTC','4h','0.000077300000000','0.000077900000000','0.001467500000000','0.001478890685640','18.98447606727038','18.984476067270379','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','MTLBTC','4h','0.000086600000000','0.000085500000000','0.001467500000000','0.001448859699769','16.945727482678983','16.945727482678983','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','MTLBTC','4h','0.000087200000000','0.000085100000000','0.001467500000000','0.001432158830275','16.829128440366972','16.829128440366972','test'),('2019-03-05 19:59:59','2019-03-06 03:59:59','MTLBTC','4h','0.000083000000000','0.000080500000000','0.001467500000000','0.001423298192771','17.680722891566266','17.680722891566266','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','MTLBTC','4h','0.000081700000000','0.000081100000000','0.001467500000000','0.001456722766218','17.962056303549573','17.962056303549573','test'),('2019-03-08 15:59:59','2019-03-09 03:59:59','MTLBTC','4h','0.000082600000000','0.000082000000000','0.001467500000000','0.001456840193705','17.76634382566586','17.766343825665860','test'),('2019-03-10 23:59:59','2019-03-11 03:59:59','MTLBTC','4h','0.000082200000000','0.000081300000000','0.001467500000000','0.001451432481752','17.85279805352798','17.852798053527980','test'),('2019-03-11 19:59:59','2019-03-17 07:59:59','MTLBTC','4h','0.000083100000000','0.000087900000000','0.001467500000000','0.001552265342960','17.65944645006017','17.659446450060170','test'),('2019-03-22 15:59:59','2019-03-23 03:59:59','MTLBTC','4h','0.000088900000000','0.000088900000000','0.001467500000000','0.001467500000000','16.507311586051742','16.507311586051742','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','MTLBTC','4h','0.000089200000000','0.000089600000000','0.001467500000000','0.001474080717489','16.451793721973093','16.451793721973093','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:34:25
