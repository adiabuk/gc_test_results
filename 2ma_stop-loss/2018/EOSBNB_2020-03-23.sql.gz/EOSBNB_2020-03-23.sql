-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-11 23:59:59','2018-11-13 07:59:59','EOSBNB','4h','0.574100000000000','0.572100000000000','0.711908500000000','0.709428414649016','1.2400426754920746','1.240042675492075','test'),('2018-11-15 19:59:59','2018-11-15 23:59:59','EOSBNB','4h','0.570000000000000','0.571800000000000','0.711908500000000','0.714156632105263','1.2489622807017546','1.248962280701755','test'),('2018-12-17 15:59:59','2018-12-19 19:59:59','EOSBNB','4h','0.458100000000000','0.448100000000000','0.711908500000000','0.696368039401877','1.554046059812268','1.554046059812268','test'),('2018-12-23 03:59:59','2018-12-23 11:59:59','EOSBNB','4h','0.458000000000000','0.476300000000000','0.711908500000000','0.740353752292576','1.5543853711790394','1.554385371179039','test'),('2018-12-26 07:59:59','2018-12-26 11:59:59','EOSBNB','4h','0.456800000000000','0.457500000000000','0.715076709612183','0.716172492661063','1.565404355543308','1.565404355543308','test'),('2018-12-27 11:59:59','2018-12-27 15:59:59','EOSBNB','4h','0.460600000000000','0.453800000000000','0.715350655374403','0.704789681738828','1.5530843581728246','1.553084358172825','test'),('2019-01-02 11:59:59','2019-01-03 19:59:59','EOSBNB','4h','0.454700000000000','0.448400000000000','0.715350655374403','0.705439265163586','1.5732365413996108','1.573236541399611','test'),('2019-01-05 03:59:59','2019-01-05 07:59:59','EOSBNB','4h','0.452000000000000','0.443400000000000','0.715350655374403','0.701740001311970','1.5826341933062014','1.582634193306201','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','EOSBNB','4h','0.450200000000000','0.446600000000000','0.715350655374403','0.709630392470476','1.5889619177574479','1.588961917757448','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','EOSBNB','4h','0.451000000000000','0.452300000000000','0.715350655374403','0.717412641742444','1.5861433600319357','1.586143360031936','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','EOSBNB','4h','0.451800000000000','0.444000000000000','0.715350655374403','0.703000644059838','1.5833347839185548','1.583334783918555','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','EOSBNB','4h','0.444000000000000','0.439300000000000','0.715350655374403','0.707778249788233','1.6111501247171238','1.611150124717124','test'),('2019-01-29 15:59:59','2019-01-29 19:59:59','EOSBNB','4h','0.368700000000000','0.371200000000000','0.715350655374403','0.720201148020012','1.9401970582435664','1.940197058243566','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','EOSBNB','4h','0.324400000000000','0.317800000000000','0.715350655374403','0.700796665468512','2.2051499857410697','2.205149985741070','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','EOSBNB','4h','0.320900000000000','0.321800000000000','0.715350655374403','0.717356936427183','2.2292011697550733','2.229201169755073','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','EOSBNB','4h','0.323400000000000','0.313700000000000','0.715350655374403','0.693894559650433','2.211968631337053','2.211968631337053','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','EOSBNB','4h','0.318500000000000','0.312100000000000','0.715350655374403','0.700976262299376','2.245998917973008','2.245998917973008','test'),('2019-02-18 11:59:59','2019-02-20 03:59:59','EOSBNB','4h','0.331500000000000','0.328500000000000','0.715350655374403','0.708876893787304','2.15792052903289','2.157920529032890','test'),('2019-02-27 23:59:59','2019-02-28 11:59:59','EOSBNB','4h','0.356500000000000','0.343300000000000','0.715350655374403','0.688863618485365','2.0065937037150157','2.006593703715016','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','EOSBNB','4h','0.252100000000000','0.247900000000000','0.715350655374403','0.703432873729927','2.8375670582086596','2.837567058208660','test'),('2019-03-27 03:59:59','2019-03-27 07:59:59','EOSBNB','4h','0.246500000000000','0.240400000000000','0.715350655374403','0.697648265931061','2.9020310562856104','2.902031056285610','test'),('2019-04-02 15:59:59','2019-04-02 19:59:59','EOSBNB','4h','0.248600000000000','0.242900000000000','0.715350655374403','0.698948810098321','2.8775167151021845','2.877516715102185','test'),('2019-05-06 19:59:59','2019-05-13 07:59:59','EOSBNB','4h','0.222500000000000','0.234400000000000','0.715350655374403','0.753609858965214','3.215059125278216','3.215059125278216','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','EOSBNB','4h','0.247400000000000','0.238300000000000','0.715350655374403','0.689038242424092','2.8914739505836824','2.891473950583682','test'),('2019-05-14 03:59:59','2019-05-15 02:59:59','EOSBNB','4h','0.246200000000000','0.239400000000000','0.715350655374403','0.695592798117921','2.9055672436003372','2.905567243600337','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','EOSBNB','4h','0.240900000000000','0.247800000000000','0.715350655374403','0.735840151107418','2.9694921352196055','2.969492135219606','test'),('2019-05-27 15:59:59','2019-06-02 03:59:59','EOSBNB','4h','0.218900000000000','0.232100000000000','0.715350655374403','0.758487378311553','3.2679335558446914','3.267933555844691','test'),('2019-06-14 15:59:59','2019-06-14 19:59:59','EOSBNB','4h','0.205200000000000','0.200700000000000','0.715350655374403','0.699663141002157','3.4861143049434844','3.486114304943484','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','EOSBNB','4h','0.207900000000000','0.201400000000000','0.715350655374403','0.692985194768662','3.4408400931909715','3.440840093190972','test'),('2019-06-15 15:59:59','2019-06-18 03:59:59','EOSBNB','4h','0.205300000000000','0.204000000000000','0.715350655374403','0.710820914254156','3.4844162463439017','3.484416246343902','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','EOSBNB','4h','0.200000000000000','0.196100000000000','0.715350655374403','0.701401317594602','3.5767532768720147','3.576753276872015','test'),('2019-06-25 23:59:59','2019-06-26 03:59:59','EOSBNB','4h','0.198800000000000','0.201600000000000','0.715350655374403','0.725426016717704','3.5983433368933753','3.598343336893375','test'),('2019-06-26 11:59:59','2019-06-26 15:59:59','EOSBNB','4h','0.197100000000000','0.199300000000000','0.715350655374403','0.723335289782438','3.629379276379518','3.629379276379518','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','EOSBNB','4h','0.186000000000000','0.182400000000000','0.715350655374403','0.701505158818769','3.84597126545378','3.845971265453780','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','EOSBNB','4h','0.181300000000000','0.181200000000000','0.715350655374403','0.714956087996921','3.9456737748174464','3.945673774817446','test'),('2019-07-24 11:59:59','2019-07-28 23:59:59','EOSBNB','4h','0.149100000000000','0.154100000000000','0.715350655374403','0.739339610953692','4.797791115857834','4.797791115857834','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','EOSBNB','4h','0.153700000000000','0.148700000000000','0.715350655374403','0.692079651621169','4.6542007506467336','4.654200750646734','test'),('2019-08-03 07:59:59','2019-08-04 07:59:59','EOSBNB','4h','0.154500000000000','0.154300000000000','0.715350655374403','0.714424635108546','4.6301013292841615','4.630101329284162','test'),('2019-08-22 19:59:59','2019-08-23 07:59:59','EOSBNB','4h','0.135300000000000','0.138900000000000','0.715350655374403','0.734384375694786','5.287144533439785','5.287144533439785','test'),('2019-08-26 11:59:59','2019-08-28 03:59:59','EOSBNB','4h','0.135900000000000','0.139400000000000','0.715350655374403','0.733773961436290','5.263801731967646','5.263801731967646','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','EOSBNB','4h','0.146800000000000','0.145900000000000','0.715350655374403','0.710964990593497','4.8729608676730445','4.872960867673044','test'),('2019-09-07 15:59:59','2019-09-18 03:59:59','EOSBNB','4h','0.152300000000000','0.189600000000000','0.715350655374403','0.890548156657825','4.696983948617223','4.696983948617223','test'),('2019-09-27 19:59:59','2019-09-27 23:59:59','EOSBNB','4h','0.183500000000000','0.180600000000000','0.723098053686245','0.711670346025808','3.940588848426406','3.940588848426406','test'),('2019-09-30 03:59:59','2019-10-01 15:59:59','EOSBNB','4h','0.183000000000000','0.185300000000000','0.723098053686245','0.732186171300881','3.95135548462429','3.951355484624290','test'),('2019-10-25 19:59:59','2019-10-26 19:59:59','EOSBNB','4h','0.170400000000000','0.167900000000000','0.723098053686245','0.712489220738970','4.243533178909889','4.243533178909889','test'),('2019-10-27 11:59:59','2019-10-27 15:59:59','EOSBNB','4h','0.166000000000000','0.175100000000000','0.723098053686245','0.762737766267840','4.356012371603885','4.356012371603885','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','EOSBNB','4h','0.166300000000000','0.166400000000000','0.729770876083375','0.730209704030509','4.388279471337193','4.388279471337193','test'),('2019-10-30 19:59:59','2019-10-30 23:59:59','EOSBNB','4h','0.165900000000000','0.163100000000000','0.729880583070159','0.717561923440283','4.399521296384321','4.399521296384321','test'),('2019-11-01 19:59:59','2019-11-02 03:59:59','EOSBNB','4h','0.166700000000000','0.167500000000000','0.729880583070159','0.733383309323645','4.378407816857583','4.378407816857583','test'),('2019-11-04 15:59:59','2019-11-11 19:59:59','EOSBNB','4h','0.167700000000000','0.172600000000000','0.729880583070159','0.751206849361416','4.35229924311365','4.352299243113650','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:57:09
