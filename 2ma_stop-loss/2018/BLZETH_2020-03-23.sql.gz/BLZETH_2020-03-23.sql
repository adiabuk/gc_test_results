-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-28 11:59:59','2018-07-28 15:59:59','BLZETH','4h','0.000669270000000','0.000638800000000','0.072144500000000','0.068859961749369','107.79580737221151','107.795807372211513','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','BLZETH','4h','0.000472300000000','0.000446370000000','0.072144500000000','0.068183655441457','152.75142917637095','152.751429176370948','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','BLZETH','4h','0.000429650000000','0.000439160000000','0.072144500000000','0.073741367671360','167.91458163621553','167.914581636215530','test'),('2018-08-30 23:59:59','2018-09-06 11:59:59','BLZETH','4h','0.000480110000000','0.000525970000000','0.072144500000000','0.079035726531420','150.266605569557','150.266605569556987','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','BLZETH','4h','0.000552930000000','0.000535590000000','0.072455177848401','0.070182968375427','131.0386085913253','131.038608591325300','test'),('2018-09-19 19:59:59','2018-09-20 15:59:59','BLZETH','4h','0.000537840000000','0.000531290000000','0.072455177848401','0.071572793840319','134.71511573776772','134.715115737767718','test'),('2018-09-21 03:59:59','2018-09-21 19:59:59','BLZETH','4h','0.000533930000000','0.000529050000000','0.072455177848401','0.071792953834204','135.7016422534808','135.701642253480799','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','BLZETH','4h','0.000532720000000','0.000524890000000','0.072455177848401','0.071390220567741','136.00986981604032','136.009869816040322','test'),('2018-09-25 03:59:59','2018-09-25 07:59:59','BLZETH','4h','0.000532400000000','0.000530340000000','0.072455177848401','0.072174829113676','136.0916187986495','136.091618798649506','test'),('2018-09-30 15:59:59','2018-10-11 07:59:59','BLZETH','4h','0.000546040000000','0.000573190000000','0.072455177848401','0.076057767546196','132.69206990037543','132.692069900375429','test'),('2018-10-12 15:59:59','2018-10-12 19:59:59','BLZETH','4h','0.000582170000000','0.000580720000000','0.072455177848401','0.072274715083435','124.45707928680797','124.457079286807968','test'),('2018-10-13 03:59:59','2018-10-13 07:59:59','BLZETH','4h','0.000592950000000','0.000585530000000','0.072455177848401','0.071548495295681','122.19441411316468','122.194414113164683','test'),('2018-10-15 15:59:59','2018-10-23 03:59:59','BLZETH','4h','0.000601800000000','0.000642380000000','0.072455177848401','0.077340905859515','120.39743743502991','120.397437435029914','test'),('2018-10-24 19:59:59','2018-10-25 03:59:59','BLZETH','4h','0.000633680000000','0.000624850000000','0.073014940068548','0.071997514994685','115.22367767413797','115.223677674137974','test'),('2018-10-26 15:59:59','2018-10-27 11:59:59','BLZETH','4h','0.000634500000000','0.000631390000000','0.073014940068548','0.072657057541183','115.07476764152561','115.074767641525611','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','BLZETH','4h','0.000639800000000','0.000638760000000','0.073014940068548','0.072896253701447','114.12150682798999','114.121506827989990','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BLZETH','4h','0.000510540000000','0.000509100000000','0.073014940068548','0.072808998293763','143.01512137843852','143.015121378438522','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','BLZETH','4h','0.000520280000000','0.000515720000000','0.073014940068548','0.072374999792711','140.33777978885985','140.337779788859848','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','BLZETH','4h','0.000523970000000','0.000511160000000','0.073014940068548','0.071229873400078','139.34946670333798','139.349466703337981','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','BLZETH','4h','0.000518200000000','0.000517990000000','0.073014940068548','0.072985350841581','140.90108079611733','140.901080796117327','test'),('2018-12-08 11:59:59','2018-12-08 19:59:59','BLZETH','4h','0.000545780000000','0.000506700000000','0.073014940068548','0.067786782463141','133.78090085482793','133.780900854827934','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','BLZETH','4h','0.000517040000000','0.000509270000000','0.073014940068548','0.071917682439868','141.21719802829182','141.217198028291818','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','BLZETH','4h','0.000310650000000','0.000310920000000','0.073014940068548','0.073078400663489','235.03924052325127','235.039240523251266','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','BLZETH','4h','0.000315580000000','0.000309640000000','0.073014940068548','0.071640617411830','231.3674506259839','231.367450625983906','test'),('2019-01-15 15:59:59','2019-01-27 11:59:59','BLZETH','4h','0.000328390000000','0.000353070000000','0.073014940068548','0.078502344438023','222.34215435472456','222.342154354724556','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZETH','4h','0.000362750000000','0.000350780000000','0.073014940068548','0.070605598007568','201.28170935505995','201.281709355059945','test'),('2019-02-01 03:59:59','2019-02-01 07:59:59','BLZETH','4h','0.000360000000000','0.000354110000000','0.073014940068548','0.071820334521315','202.81927796818889','202.819277968188885','test'),('2019-02-01 19:59:59','2019-02-02 03:59:59','BLZETH','4h','0.000353990000000','0.000357390000000','0.073014940068548','0.073716233314778','206.26271947949942','206.262719479499424','test'),('2019-02-06 03:59:59','2019-02-06 19:59:59','BLZETH','4h','0.000355350000000','0.000350980000000','0.073014940068548','0.072117021711718','205.47330819909385','205.473308199093850','test'),('2019-02-16 15:59:59','2019-02-17 03:59:59','BLZETH','4h','0.000334800000000','0.000351890000000','0.073014940068548','0.076742016907770','218.08524512708482','218.085245127084818','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BLZETH','4h','0.000312820000000','0.000318980000000','0.073014940068548','0.074452738261829','233.40879761060035','233.408797610600345','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','BLZETH','4h','0.000410490000000','0.000399480000000','0.073014940068548','0.071056562300138','177.8726401825818','177.872640182581790','test'),('2019-03-22 07:59:59','2019-03-22 15:59:59','BLZETH','4h','0.000413020000000','0.000409950000000','0.073014940068548','0.072472216069685','176.78306151892886','176.783061518928861','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','BLZETH','4h','0.000413220000000','0.000464780000000','0.073014940068548','0.082125463058564','176.69749786686995','176.697497866869952','test'),('2019-04-03 23:59:59','2019-04-04 03:59:59','BLZETH','4h','0.000446020000000','0.000430610000000','0.073432519742462','0.070895424703604','164.63952231393603','164.639522313936027','test'),('2019-04-04 07:59:59','2019-04-08 07:59:59','BLZETH','4h','0.000454200000000','0.000481650000000','0.073432519742462','0.077870482461376','161.67441598956847','161.674415989568473','test'),('2019-05-15 23:59:59','2019-05-16 03:59:59','BLZETH','4h','0.000277670000000','0.000253330000000','0.073907736662476','0.067429131446339','266.17112638194885','266.171126381948852','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','BLZETH','4h','0.000259040000000','0.000254500000000','0.073907736662476','0.072612411135732','285.31399267478383','285.313992674783833','test'),('2019-06-03 07:59:59','2019-06-03 11:59:59','BLZETH','4h','0.000246610000000','0.000247470000000','0.073907736662476','0.074165474197571','299.6948082497709','299.694808249770915','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BLZETH','4h','0.000243000000000','0.000243740000000','0.073907736662476','0.074132805490172','304.1470644546338','304.147064454633778','test'),('2019-06-06 23:59:59','2019-06-12 03:59:59','BLZETH','4h','0.000245390000000','0.000259640000000','0.073907736662476','0.078199619980624','301.18479425598434','301.184794255984343','test'),('2019-06-13 15:59:59','2019-06-13 23:59:59','BLZETH','4h','0.000256870000000','0.000257960000000','0.073907736662476','0.074221356131321','287.72428334362127','287.724283343621266','test'),('2019-06-24 11:59:59','2019-06-24 15:59:59','BLZETH','4h','0.000236220000000','0.000250780000000','0.073907736662476','0.078463221574023','312.87671095790364','312.876710957903640','test'),('2019-07-18 07:59:59','2019-07-18 15:59:59','BLZETH','4h','0.000174850000000','0.000166960000000','0.074375202492088','0.071019066674744','425.36575631734763','425.365756317347632','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','BLZETH','4h','0.000171890000000','0.000171570000000','0.074375202492088','0.074236741471683','432.69068876658326','432.690688766583264','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','BLZETH','4h','0.000168730000000','0.000166310000000','0.074375202492088','0.073308480569307','440.7941829673917','440.794182967391691','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','BLZETH','4h','0.000169640000000','0.000166960000000','0.074375202492088','0.073200211082758','438.42963034713506','438.429630347135060','test'),('2019-07-23 23:59:59','2019-07-24 19:59:59','BLZETH','4h','0.000169580000000','0.000169640000000','0.074375202492088','0.074401517577296','438.584753462012','438.584753462011975','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:55:17
