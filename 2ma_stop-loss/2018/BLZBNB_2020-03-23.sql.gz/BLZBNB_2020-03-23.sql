-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-25 19:59:59','2018-07-25 23:59:59','BLZBNB','4h','0.025800000000000','0.025300000000000','0.711908500000000','0.698111823643411','27.593352713178298','27.593352713178298','test'),('2018-08-25 19:59:59','2018-08-26 03:59:59','BLZBNB','4h','0.012490000000000','0.011830000000000','0.711908500000000','0.674289636108887','56.998278622898326','56.998278622898326','test'),('2018-08-26 23:59:59','2018-08-27 03:59:59','BLZBNB','4h','0.012490000000000','0.012360000000000','0.711908500000000','0.704498723779023','56.998278622898326','56.998278622898326','test'),('2018-08-27 19:59:59','2018-08-27 23:59:59','BLZBNB','4h','0.012450000000000','0.012360000000000','0.711908500000000','0.706762173493976','57.18140562248997','57.181405622489969','test'),('2018-08-30 23:59:59','2018-09-05 11:59:59','BLZBNB','4h','0.012580000000000','0.012820000000000','0.711908500000000','0.725490220190779','56.590500794912565','56.590500794912565','test'),('2018-09-16 23:59:59','2018-09-17 03:59:59','BLZBNB','4h','0.011620000000000','0.011280000000000','0.711908500000000','0.691078130808950','61.265791738382106','61.265791738382106','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','BLZBNB','4h','0.011910000000000','0.011610000000000','0.711908500000000','0.693976295969773','59.77401343408901','59.774013434089007','test'),('2018-09-19 19:59:59','2018-09-19 23:59:59','BLZBNB','4h','0.011790000000000','0.011440000000000','0.711908500000000','0.690774659881255','60.382400339270575','60.382400339270575','test'),('2018-09-26 03:59:59','2018-09-27 03:59:59','BLZBNB','4h','0.012150000000000','0.012390000000000','0.711908500000000','0.725970890123457','58.59329218106997','58.593292181069970','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BLZBNB','4h','0.012170000000000','0.011940000000000','0.711908500000000','0.698454189811011','58.49700082169269','58.497000821692687','test'),('2018-09-29 11:59:59','2018-09-29 23:59:59','BLZBNB','4h','0.012190000000000','0.012130000000000','0.711908500000000','0.708404438474159','58.401025430680896','58.401025430680896','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','BLZBNB','4h','0.012420000000000','0.012390000000000','0.711908500000000','0.710188914251208','57.31952495974235','57.319524959742353','test'),('2018-10-06 19:59:59','2018-10-07 03:59:59','BLZBNB','4h','0.012990000000000','0.012680000000000','0.711908500000000','0.694919151655119','54.80434949961509','54.804349499615093','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','BLZBNB','4h','0.012600000000000','0.012390000000000','0.711908500000000','0.700043358333333','56.50067460317461','56.500674603174609','test'),('2018-10-14 19:59:59','2018-10-15 03:59:59','BLZBNB','4h','0.012530000000000','0.012750000000000','0.711908500000000','0.724408090582602','56.81632083000799','56.816320830007989','test'),('2018-10-16 07:59:59','2018-10-22 03:59:59','BLZBNB','4h','0.012800000000000','0.013210000000000','0.711908500000000','0.734711819140625','55.6178515625','55.617851562500000','test'),('2018-10-24 23:59:59','2018-10-25 03:59:59','BLZBNB','4h','0.013200000000000','0.012940000000000','0.711908500000000','0.697886059848485','53.932462121212126','53.932462121212126','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','BLZBNB','4h','0.013290000000000','0.013190000000000','0.711908500000000','0.706551776899925','53.56723100075245','53.567231000752450','test'),('2018-10-28 07:59:59','2018-10-29 03:59:59','BLZBNB','4h','0.013200000000000','0.013490000000000','0.711908500000000','0.727548914015152','53.932462121212126','53.932462121212126','test'),('2018-11-05 03:59:59','2018-11-05 11:59:59','BLZBNB','4h','0.014580000000000','0.014750000000000','0.711908500000000','0.720209216392318','48.827743484224975','48.827743484224975','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','BLZBNB','4h','0.014410000000000','0.014220000000000','0.711908500000000','0.702521781401804','49.403782095766836','49.403782095766836','test'),('2018-11-07 23:59:59','2018-11-08 03:59:59','BLZBNB','4h','0.014420000000000','0.013770000000000','0.711908500000000','0.679818311026352','49.36952149791956','49.369521497919557','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','BLZBNB','4h','0.014430000000000','0.014420000000000','0.711908500000000','0.711415146916147','49.33530838530839','49.335308385308387','test'),('2018-11-28 07:59:59','2018-11-30 11:59:59','BLZBNB','4h','0.011300000000000','0.011160000000000','0.711908500000000','0.703088394690266','63.000752212389386','63.000752212389386','test'),('2018-12-08 11:59:59','2018-12-08 19:59:59','BLZBNB','4h','0.010820000000000','0.009930000000000','0.711908500000000','0.653350407116451','65.79560998151572','65.795609981515724','test'),('2018-12-10 11:59:59','2018-12-11 15:59:59','BLZBNB','4h','0.010480000000000','0.009870000000000','0.711908500000000','0.670471077767176','67.9302003816794','67.930200381679398','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','BLZBNB','4h','0.007550000000000','0.007480000000000','0.711908500000000','0.705308023841060','94.29251655629139','94.292516556291389','test'),('2019-01-04 11:59:59','2019-01-04 15:59:59','BLZBNB','4h','0.007600000000000','0.007510000000000','0.711908500000000','0.703478004605263','93.67217105263158','93.672171052631583','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','BLZBNB','4h','0.007620000000000','0.007380000000000','0.711908500000000','0.689486185039370','93.42631233595802','93.426312335958016','test'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BLZBNB','4h','0.007000000000000','0.007050000000000','0.711908500000000','0.716993560714286','101.70121428571429','101.701214285714286','test'),('2019-01-17 15:59:59','2019-01-17 19:59:59','BLZBNB','4h','0.007080000000000','0.006890000000000','0.711908500000000','0.692803610875706','100.55204802259887','100.552048022598868','test'),('2019-01-19 07:59:59','2019-01-19 11:59:59','BLZBNB','4h','0.006860000000000','0.006750000000000','0.711908500000000','0.700493057580175','103.77674927113704','103.776749271137035','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','BLZBNB','4h','0.006870000000000','0.006700000000000','0.711908500000000','0.694292132459971','103.62569141193596','103.625691411935961','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','BLZBNB','4h','0.007520000000000','0.006620000000000','0.711908500000000','0.626706684840426','94.6686835106383','94.668683510638303','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','BLZBNB','4h','0.006800000000000','0.006590000000000','0.711908500000000','0.689923090441177','104.69242647058825','104.692426470588245','test'),('2019-01-30 23:59:59','2019-01-31 03:59:59','BLZBNB','4h','0.006250000000000','0.006220000000000','0.711908500000000','0.708491339200000','113.90536','113.905360000000002','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','BLZBNB','4h','0.006510000000000','0.006080000000000','0.711908500000000','0.664885357910906','109.35614439324117','109.356144393241166','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','BLZBNB','4h','0.004710000000000','0.004600000000000','0.711908500000000','0.695282186836518','151.14830148619959','151.148301486199585','test'),('2019-02-24 03:59:59','2019-02-24 11:59:59','BLZBNB','4h','0.004460000000000','0.004390000000000','0.711908500000000','0.700735048206278','159.6207399103139','159.620739910313887','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BLZBNB','4h','0.004430000000000','0.004580000000000','0.711908500000000','0.736013753950339','160.70169300225734','160.701693002257343','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','BLZBNB','4h','0.004350000000000','0.004490000000000','0.711908500000000','0.734820497701150','163.65712643678162','163.657126436781624','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','BLZBNB','4h','0.003910000000000','0.003730000000000','0.711908500000000','0.679135218670077','182.0737851662404','182.073785166240413','test'),('2019-03-14 23:59:59','2019-03-15 03:59:59','BLZBNB','4h','0.003820000000000','0.003690000000000','0.711908500000000','0.687681247382199','186.36348167539268','186.363481675392677','test'),('2019-03-15 11:59:59','2019-03-15 15:59:59','BLZBNB','4h','0.003810000000000','0.003970000000000','0.711908500000000','0.741804919947506','186.85262467191603','186.852624671916033','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','BLZBNB','4h','0.003760000000000','0.003700000000000','0.711908500000000','0.700548257978724','189.3373670212766','189.337367021276606','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','BLZBNB','4h','0.003740000000000','0.003750000000000','0.711908500000000','0.713811998663102','190.34986631016045','190.349866310160451','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BLZBNB','4h','0.003750000000000','0.003190000000000','0.711908500000000','0.605596830666667','189.8422666666667','189.842266666666688','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','BLZBNB','4h','0.003610000000000','0.003610000000000','0.711908500000000','0.711908500000000','197.20457063711913','197.204570637119133','test'),('2019-03-28 11:59:59','2019-03-28 15:59:59','BLZBNB','4h','0.003620000000000','0.003840000000000','0.711908500000000','0.755173657458564','196.65980662983426','196.659806629834264','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','BLZBNB','4h','0.003760000000000','0.003700000000000','0.711908500000000','0.700548257978724','189.3373670212766','189.337367021276606','test'),('2019-04-03 07:59:59','2019-04-04 03:59:59','BLZBNB','4h','0.003760000000000','0.003580000000000','0.711908500000000','0.677827773936170','189.3373670212766','189.337367021276606','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','BLZBNB','4h','0.003790000000000','0.003730000000000','0.711908500000000','0.700638180738786','187.83865435356202','187.838654353562021','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','BLZBNB','4h','0.002340000000000','0.002330000000000','0.711908500000000','0.708866155982906','304.2344017094017','304.234401709401709','test'),('2019-05-15 19:59:59','2019-05-16 03:59:59','BLZBNB','4h','0.002530000000000','0.002480000000000','0.711908500000000','0.697839162055336','281.3867588932806','281.386758893280614','test'),('2019-06-03 07:59:59','2019-06-04 03:59:59','BLZBNB','4h','0.002000000000000','0.001960000000000','0.711908500000000','0.697670330000000','355.95425','355.954250000000002','test'),('2019-06-05 03:59:59','2019-06-05 07:59:59','BLZBNB','4h','0.001980000000000','0.001950000000000','0.711908500000000','0.701122007575758','359.5497474747475','359.549747474747505','test'),('2019-06-07 07:59:59','2019-06-08 15:59:59','BLZBNB','4h','0.002040000000000','0.002000000000000','0.711908500000000','0.697949509803922','348.9747549019608','348.974754901960807','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','BLZBNB','4h','0.002000000000000','0.001910000000000','0.711908500000000','0.679872617500000','355.95425','355.954250000000002','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','BLZBNB','4h','0.001970000000000','0.001920000000000','0.474605666666667','0.462559837563452','240.9165820642978','240.916582064297813','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','BLZBNB','4h','0.001980000000000','0.001930000000000','0.529386483439873','0.516018137898462','267.36691082821864','267.366910828218636','test'),('2019-06-17 19:59:59','2019-06-17 23:59:59','BLZBNB','4h','0.001970000000000','0.001890000000000','0.529386483439873','0.507888555178355','268.7241032689711','268.724103268971078','test'),('2019-06-23 11:59:59','2019-06-23 15:59:59','BLZBNB','4h','0.001890000000000','0.001870000000000','0.529386483439873','0.523784510070139','280.0986684867053','280.098668486705321','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','BLZBNB','4h','0.001720000000000','0.001710000000000','0.529386483439873','0.526308655047781','307.78283920922854','307.782839209228541','test'),('2019-07-06 11:59:59','2019-07-06 19:59:59','BLZBNB','4h','0.001700000000000','0.001680000000000','0.529386483439873','0.523158407164110','311.4038137881606','311.403813788160619','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:46:20
