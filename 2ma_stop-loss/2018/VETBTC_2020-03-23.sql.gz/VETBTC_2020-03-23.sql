-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 19:59:59','2019-01-08 23:59:59','VETBTC','4h','0.000001090000000','0.000001080000000','0.001467500000000','0.001454036697248','1346.330275229358','1346.330275229357994','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','VETBTC','4h','0.000001110000000','0.000001090000000','0.001467500000000','0.001441058558559','1322.0720720720722','1322.072072072072160','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','VETBTC','4h','0.000001100000000','0.000001090000000','0.001467500000000','0.001454159090909','1334.090909090909','1334.090909090909008','test'),('2019-01-16 23:59:59','2019-01-17 03:59:59','VETBTC','4h','0.000001100000000','0.000001100000000','0.001467500000000','0.001467500000000','1334.090909090909','1334.090909090909008','test'),('2019-01-27 19:59:59','2019-01-27 23:59:59','VETBTC','4h','0.000001190000000','0.000001160000000','0.001467500000000','0.001430504201681','1233.1932773109243','1233.193277310924259','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','VETBTC','4h','0.000001170000000','0.000001160000000','0.001467500000000','0.001454957264957','1254.2735042735044','1254.273504273504386','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','VETBTC','4h','0.000001160000000','0.000001150000000','0.001467500000000','0.001454849137931','1265.0862068965519','1265.086206896551857','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','VETBTC','4h','0.000001110000000','0.000001100000000','0.001467500000000','0.001454279279279','1322.0720720720722','1322.072072072072160','test'),('2019-02-21 11:59:59','2019-02-24 15:59:59','VETBTC','4h','0.000001150000000','0.000001140000000','0.001467500000000','0.001454739130435','1276.0869565217392','1276.086956521739239','test'),('2019-03-02 23:59:59','2019-03-03 03:59:59','VETBTC','4h','0.000001170000000','0.000001160000000','0.001467500000000','0.001454957264957','1254.2735042735044','1254.273504273504386','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','VETBTC','4h','0.000001170000000','0.000001180000000','0.001467500000000','0.001480042735043','1254.2735042735044','1254.273504273504386','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','VETBTC','4h','0.000001160000000','0.000001160000000','0.001467500000000','0.001467500000000','1265.0862068965519','1265.086206896551857','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','VETBTC','4h','0.000001170000000','0.000001160000000','0.001467500000000','0.001454957264957','1254.2735042735044','1254.273504273504386','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','VETBTC','4h','0.000001390000000','0.000001390000000','0.001467500000000','0.001467500000000','1055.7553956834533','1055.755395683453344','test'),('2019-04-18 15:59:59','2019-04-18 19:59:59','VETBTC','4h','0.000001400000000','0.000001390000000','0.001467500000000','0.001457017857143','1048.2142857142858','1048.214285714285779','test'),('2019-05-01 19:59:59','2019-05-01 23:59:59','VETBTC','4h','0.000001210000000','0.000001220000000','0.001467500000000','0.001479628099174','1212.809917355372','1212.809917355371908','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','VETBTC','4h','0.000001020000000','0.000000990000000','0.001467500000000','0.001424338235294','1438.7254901960785','1438.725490196078454','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VETBTC','4h','0.000001000000000','0.000001000000000','0.001467500000000','0.001467500000000','1467.5000000000002','1467.500000000000227','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','VETBTC','4h','0.000000950000000','0.000000930000000','0.001467500000000','0.001436605263158','1544.7368421052631','1544.736842105263122','test'),('2019-06-10 03:59:59','2019-06-11 07:59:59','VETBTC','4h','0.000000950000000','0.000000960000000','0.001467500000000','0.001482947368421','1544.7368421052631','1544.736842105263122','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','VETBTC','4h','0.000000950000000','0.000000950000000','0.001467500000000','0.001467500000000','1544.7368421052631','1544.736842105263122','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','VETBTC','4h','0.000000950000000','0.000000880000000','0.001467500000000','0.001359368421053','1544.7368421052631','1544.736842105263122','test'),('2019-06-29 23:59:59','2019-06-30 03:59:59','VETBTC','4h','0.000000770000000','0.000000740000000','0.001467500000000','0.001410324675325','1905.844155844156','1905.844155844155921','test'),('2019-07-20 03:59:59','2019-07-20 07:59:59','VETBTC','4h','0.000000580000000','0.000000570000000','0.001467500000000','0.001442198275862','2530.1724137931037','2530.172413793103715','test'),('2019-07-22 03:59:59','2019-07-22 07:59:59','VETBTC','4h','0.000000580000000','0.000000580000000','0.001467500000000','0.001467500000000','2530.1724137931037','2530.172413793103715','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','VETBTC','4h','0.000000590000000','0.000000580000000','0.001467500000000','0.001442627118644','2487.2881355932204','2487.288135593220431','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','VETBTC','4h','0.000000470000000','0.000000450000000','0.001467500000000','0.001405053191489','3122.340425531915','3122.340425531915116','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','VETBTC','4h','0.000000450000000','0.000000440000000','0.001467500000000','0.001434888888889','3261.1111111111113','3261.111111111111313','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','VETBTC','4h','0.000000460000000','0.000000450000000','0.001467500000000','0.001435597826087','3190.217391304348','3190.217391304347984','test'),('2019-08-24 07:59:59','2019-08-24 11:59:59','VETBTC','4h','0.000000450000000','0.000000460000000','0.001467500000000','0.001500111111111','3261.1111111111113','3261.111111111111313','test'),('2019-08-27 15:59:59','2019-08-27 19:59:59','VETBTC','4h','0.000000450000000','0.000000450000000','0.001467500000000','0.001467500000000','3261.1111111111113','3261.111111111111313','test'),('2019-08-28 11:59:59','2019-08-28 15:59:59','VETBTC','4h','0.000000450000000','0.000000450000000','0.001467500000000','0.001467500000000','3261.1111111111113','3261.111111111111313','test'),('2019-09-16 11:59:59','2019-09-16 19:59:59','VETBTC','4h','0.000000410000000','0.000000400000000','0.001467500000000','0.001431707317073','3579.268292682927','3579.268292682927040','test'),('2019-09-23 15:59:59','2019-09-23 19:59:59','VETBTC','4h','0.000000410000000','0.000000410000000','0.001467500000000','0.001467500000000','3579.268292682927','3579.268292682927040','test'),('2019-09-25 23:59:59','2019-09-26 03:59:59','VETBTC','4h','0.000000410000000','0.000000400000000','0.001467500000000','0.001431707317073','3579.268292682927','3579.268292682927040','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','VETBTC','4h','0.000000410000000','0.000000400000000','0.001467500000000','0.001431707317073','3579.268292682927','3579.268292682927040','test'),('2019-09-26 23:59:59','2019-09-27 03:59:59','VETBTC','4h','0.000000410000000','0.000000410000000','0.001467500000000','0.001467500000000','3579.268292682927','3579.268292682927040','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','VETBTC','4h','0.000000410000000','0.000000410000000','0.001467500000000','0.001467500000000','3579.268292682927','3579.268292682927040','test'),('2019-10-03 03:59:59','2019-10-03 07:59:59','VETBTC','4h','0.000000420000000','0.000000420000000','0.001467500000000','0.001467500000000','3494.0476190476193','3494.047619047619264','test'),('2019-10-04 03:59:59','2019-10-04 07:59:59','VETBTC','4h','0.000000420000000','0.000000420000000','0.001467500000000','0.001467500000000','3494.0476190476193','3494.047619047619264','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','VETBTC','4h','0.000000420000000','0.000000420000000','0.001467500000000','0.001467500000000','3494.0476190476193','3494.047619047619264','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','VETBTC','4h','0.000000440000000','0.000000430000000','0.001467500000000','0.001434147727273','3335.2272727272725','3335.227272727272521','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','VETBTC','4h','0.000000440000000','0.000000430000000','0.001467500000000','0.001434147727273','3335.2272727272725','3335.227272727272521','test'),('2019-10-18 19:59:59','2019-10-18 23:59:59','VETBTC','4h','0.000000430000000','0.000000420000000','0.001467500000000','0.001433372093023','3412.7906976744184','3412.790697674418425','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','VETBTC','4h','0.000000430000000','0.000000420000000','0.001467500000000','0.001433372093023','3412.7906976744184','3412.790697674418425','test'),('2019-10-27 15:59:59','2019-10-28 07:59:59','VETBTC','4h','0.000000430000000','0.000000420000000','0.001467500000000','0.001433372093023','3412.7906976744184','3412.790697674418425','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','VETBTC','4h','0.000000790000000','0.000000780000000','0.001467500000000','0.001448924050633','1857.594936708861','1857.594936708861042','test'),('2019-12-01 11:59:59','2019-12-06 11:59:59','VETBTC','4h','0.000000890000000','0.000000900000000','0.001467500000000','0.001483988764045','1648.876404494382','1648.876404494382086','test'),('2019-12-08 15:59:59','2019-12-08 19:59:59','VETBTC','4h','0.000000940000000','0.000000930000000','0.001467500000000','0.001451888297872','1561.1702127659576','1561.170212765957558','test'),('2019-12-13 07:59:59','2019-12-13 11:59:59','VETBTC','4h','0.000000920000000','0.000000890000000','0.001467500000000','0.001419646739130','1595.108695652174','1595.108695652173992','test'),('2019-12-23 15:59:59','2019-12-26 03:59:59','VETBTC','4h','0.000000790000000','0.000000780000000','0.001467500000000','0.001448924050633','1857.594936708861','1857.594936708861042','test'),('2019-12-27 19:59:59','2019-12-27 23:59:59','VETBTC','4h','0.000000800000000','0.000000790000000','0.001467500000000','0.001449156250000','1834.3750000000002','1834.375000000000227','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','VETBTC','4h','0.000000790000000','0.000000790000000','0.001467500000000','0.001467500000000','1857.594936708861','1857.594936708861042','test'),('2020-01-04 23:59:59','2020-01-05 03:59:59','VETBTC','4h','0.000000760000000','0.000000760000000','0.001467500000000','0.001467500000000','1930.921052631579','1930.921052631578959','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:21:29
