-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-16 11:59:59','2018-05-16 15:59:59','ADXBNB','4h','0.068500000000000','0.067110000000000','0.711908500000000','0.697462473503650','10.392824817518248','10.392824817518248','test'),('2018-06-27 19:59:59','2018-06-28 23:59:59','ADXBNB','4h','0.026350000000000','0.024450000000000','0.711908500000000','0.660575439278937','27.017400379506643','27.017400379506643','test'),('2018-06-30 03:59:59','2018-06-30 15:59:59','ADXBNB','4h','0.026570000000000','0.027560000000000','0.711908500000000','0.738434258938653','26.793695897628908','26.793695897628908','test'),('2018-07-08 03:59:59','2018-07-08 11:59:59','ADXBNB','4h','0.029020000000000','0.028890000000000','0.711908500000000','0.708719385423846','24.531650585802897','24.531650585802897','test'),('2018-07-10 03:59:59','2018-07-10 07:59:59','ADXBNB','4h','0.028640000000000','0.029180000000000','0.711908500000000','0.725331355796090','24.857140363128494','24.857140363128494','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','ADXBNB','4h','0.029300000000000','0.029360000000000','0.711908500000000','0.713366333105802','24.297218430034132','24.297218430034132','test'),('2018-07-16 11:59:59','2018-07-16 15:59:59','ADXBNB','4h','0.029200000000000','0.029020000000000','0.711908500000000','0.707520022945206','24.380428082191784','24.380428082191784','test'),('2018-07-16 23:59:59','2018-07-17 07:59:59','ADXBNB','4h','0.029760000000000','0.029290000000000','0.711908500000000','0.700665321404570','23.921656586021506','23.921656586021506','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','ADXBNB','4h','0.019000000000000','0.018560000000000','0.711908500000000','0.695422197894737','37.46886842105263','37.468868421052633','test'),('2018-08-25 23:59:59','2018-08-26 11:59:59','ADXBNB','4h','0.018550000000000','0.018370000000000','0.711908500000000','0.705000492991914','38.3778167115903','38.377816711590299','test'),('2018-08-28 03:59:59','2018-08-28 23:59:59','ADXBNB','4h','0.018970000000000','0.018530000000000','0.711908500000000','0.695396125724829','37.5281233526621','37.528123352662099','test'),('2018-08-29 15:59:59','2018-08-29 19:59:59','ADXBNB','4h','0.018840000000000','0.018530000000000','0.711908500000000','0.700194506634820','37.787075371549896','37.787075371549896','test'),('2018-08-30 15:59:59','2018-08-30 19:59:59','ADXBNB','4h','0.018580000000000','0.018390000000000','0.711908500000000','0.704628488428418','38.3158503767492','38.315850376749196','test'),('2018-08-30 23:59:59','2018-08-31 03:59:59','ADXBNB','4h','0.019470000000000','0.019130000000000','0.711908500000000','0.699476610426297','36.56438109912686','36.564381099126862','test'),('2018-09-09 19:59:59','2018-09-09 23:59:59','ADXBNB','4h','0.019000000000000','0.018400000000000','0.711908500000000','0.689427178947368','37.46886842105263','37.468868421052633','test'),('2018-09-10 15:59:59','2018-09-10 19:59:59','ADXBNB','4h','0.018320000000000','0.017860000000000','0.711908500000000','0.694033068231441','38.85963427947598','38.859634279475983','test'),('2018-09-15 23:59:59','2018-09-16 03:59:59','ADXBNB','4h','0.018940000000000','0.018000000000000','0.711908500000000','0.676576187961985','37.58756599788807','37.587565997888071','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','ADXBNB','4h','0.018030000000000','0.018330000000000','0.711908500000000','0.723753899334443','39.484664448141984','39.484664448141984','test'),('2018-09-25 15:59:59','2018-09-25 19:59:59','ADXBNB','4h','0.021780000000000','0.021360000000000','0.711908500000000','0.698180236914601','32.6863406795225','32.686340679522502','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','ADXBNB','4h','0.019900000000000','0.019450000000000','0.711908500000000','0.695810066582915','35.77429648241206','35.774296482412062','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','ADXBNB','4h','0.020520000000000','0.020010000000000','0.711908500000000','0.694214867690058','34.69339668615984','34.693396686159844','test'),('2018-10-13 07:59:59','2018-10-15 03:59:59','ADXBNB','4h','0.020680000000000','0.020780000000000','0.711908500000000','0.715350997582205','34.42497582205029','34.424975822050293','test'),('2018-10-16 07:59:59','2018-10-17 03:59:59','ADXBNB','4h','0.021550000000000','0.021280000000000','0.711908500000000','0.702988996751740','33.035197215777266','33.035197215777266','test'),('2018-10-28 07:59:59','2018-10-29 15:59:59','ADXBNB','4h','0.023500000000000','0.023030000000000','0.711908500000000','0.697670330000000','30.29397872340426','30.293978723404258','test'),('2018-10-30 19:59:59','2018-10-31 03:59:59','ADXBNB','4h','0.024140000000000','0.023820000000000','0.711908500000000','0.702471436205468','29.490824357912178','29.490824357912178','test'),('2018-11-11 11:59:59','2018-11-11 23:59:59','ADXBNB','4h','0.023010000000000','0.022730000000000','0.711908500000000','0.703245554324207','30.939091699261194','30.939091699261194','test'),('2018-11-24 07:59:59','2018-11-24 11:59:59','ADXBNB','4h','0.019000000000000','0.018490000000000','0.711908500000000','0.692799377105263','37.46886842105263','37.468868421052633','test'),('2018-11-27 23:59:59','2018-11-28 07:59:59','ADXBNB','4h','0.019950000000000','0.019200000000000','0.711908500000000','0.685145022556391','35.6846365914787','35.684636591478700','test'),('2018-12-01 03:59:59','2018-12-02 03:59:59','ADXBNB','4h','0.026560000000000','0.023750000000000','0.711908500000000','0.636589867281627','26.80378388554217','26.803783885542170','test'),('2018-12-10 03:59:59','2018-12-11 03:59:59','ADXBNB','4h','0.020740000000000','0.019830000000000','0.711908500000000','0.680672398987464','34.32538572806172','34.325385728061718','test'),('2018-12-14 03:59:59','2018-12-14 07:59:59','ADXBNB','4h','0.019760000000000','0.019120000000000','0.711908500000000','0.688850734817814','36.02775809716599','36.027758097165993','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','ADXBNB','4h','0.020860000000000','0.020280000000000','0.711908500000000','0.692114303930968','34.127924256951104','34.127924256951104','test'),('2018-12-24 03:59:59','2018-12-24 07:59:59','ADXBNB','4h','0.018850000000000','0.018630000000000','0.711908500000000','0.703599753580902','37.76702917771884','37.767029177718840','test'),('2018-12-24 15:59:59','2018-12-24 19:59:59','ADXBNB','4h','0.018660000000000','0.018540000000000','0.711908500000000','0.707330310289389','38.15158092175778','38.151580921757777','test'),('2018-12-24 23:59:59','2018-12-25 03:59:59','ADXBNB','4h','0.018720000000000','0.018600000000000','0.711908500000000','0.707344983974359','38.029300213675214','38.029300213675214','test'),('2019-01-02 03:59:59','2019-01-03 03:59:59','ADXBNB','4h','0.017760000000000','0.017530000000000','0.711908500000000','0.702688964245496','40.08493806306306','40.084938063063063','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','ADXBNB','4h','0.017890000000000','0.017430000000000','0.711908500000000','0.693603418390162','39.79365567356065','39.793655673560650','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','ADXBNB','4h','0.017930000000000','0.017450000000000','0.711908500000000','0.692850157557167','39.704880089235914','39.704880089235914','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','ADXBNB','4h','0.016450000000000','0.016000000000000','0.711908500000000','0.692433799392097','43.27711246200609','43.277112462006087','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','ADXBNB','4h','0.016180000000000','0.016030000000000','0.711908500000000','0.705308606613103','43.999289245982695','43.999289245982695','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','ADXBNB','4h','0.017900000000000','0.016720000000000','0.711908500000000','0.664978218994413','39.77142458100559','39.771424581005590','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','ADXBNB','4h','0.016470000000000','0.016390000000000','0.711908500000000','0.708450535215543','43.22455980570735','43.224559805707351','test'),('2019-01-30 19:59:59','2019-01-31 07:59:59','ADXBNB','4h','0.015390000000000','0.015100000000000','0.711908500000000','0.698493719948018','46.25786224821313','46.257862248213129','test'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ADXBNB','4h','0.019080000000000','0.017810000000000','0.711908500000000','0.664522556865828','37.31176624737946','37.311766247379460','test'),('2019-02-16 23:59:59','2019-02-18 03:59:59','ADXBNB','4h','0.012800000000000','0.012620000000000','0.711908500000000','0.701897286718750','55.6178515625','55.617851562500000','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','ADXBNB','4h','0.012050000000000','0.011860000000000','0.711908500000000','0.700683386721992','59.079543568464736','59.079543568464736','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','ADXBNB','4h','0.012040000000000','0.012170000000000','0.711908500000000','0.719595219684385','59.128612956810635','59.128612956810635','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','ADXBNB','4h','0.009900000000000','0.009770000000000','0.711908500000000','0.702560206565656','71.9099494949495','71.909949494949501','test'),('2019-03-16 03:59:59','2019-03-16 07:59:59','ADXBNB','4h','0.009850000000000','0.009450000000000','0.711908500000000','0.682998510152284','72.27497461928935','72.274974619289353','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','ADXBNB','4h','0.009570000000000','0.009450000000000','0.474605666666667','0.468654498432602','49.59306861720655','49.593068617206548','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ADXBNB','4h','0.009630000000000','0.009290000000000','0.532398376094801','0.513601341009419','55.28539730994817','55.285397309948173','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','ADXBNB','4h','0.009590000000000','0.009670000000000','0.532398376094801','0.536839655561702','55.51599333626705','55.515993336267051','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','ADXBNB','4h','0.009740000000000','0.009450000000000','0.532398376094801','0.516546679065284','54.661024239712624','54.661024239712624','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','ADXBNB','4h','0.011990000000000','0.010970000000000','0.532398376094801','0.487106771122599','44.403534286472144','44.403534286472144','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','ADXBNB','4h','0.009690000000000','0.009310000000000','0.532398376094801','0.511520008404809','54.94307286840051','54.943072868400513','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','ADXBNB','4h','0.009760000000000','0.009450000000000','0.532398376094801','0.515488181772118','54.54901394413945','54.549013944139453','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','ADXBNB','4h','0.009620000000000','0.009490000000000','0.532398376094801','0.525203803444871','55.342866537921104','55.342866537921104','test'),('2019-04-07 03:59:59','2019-04-07 07:59:59','ADXBNB','4h','0.009400000000000','0.009250000000000','0.532398376094801','0.523902657327331','56.63812511646819','56.638125116468188','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','ADXBNB','4h','0.009330000000000','0.009300000000000','0.532398376094801','0.530686484210252','57.06306281830665','57.063062818306648','test'),('2019-04-07 19:59:59','2019-04-08 07:59:59','ADXBNB','4h','0.009530000000000','0.009380000000000','0.532398376094801','0.524018548559206','55.86551690396652','55.865516903966522','test'),('2019-04-10 15:59:59','2019-04-11 03:59:59','ADXBNB','4h','0.009680000000000','0.009540000000000','0.532398376094801','0.524698399581033','54.999832241198455','54.999832241198455','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','ADXBNB','4h','0.006480000000000','0.006220000000000','0.532398376094801','0.511036712856429','82.16024322450633','82.160243224506331','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','ADXBNB','4h','0.006390000000000','0.006300000000000','0.532398376094801','0.524899807417409','83.31742974879515','83.317429748795149','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','ADXBNB','4h','0.006460000000000','0.006350000000000','0.532398376094801','0.523332769071515','82.41460930260078','82.414609302600780','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','ADXBNB','4h','0.006510000000000','0.006070000000000','0.532398376094801','0.496414461274261','81.78162459213533','81.781624592135330','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:10:48
