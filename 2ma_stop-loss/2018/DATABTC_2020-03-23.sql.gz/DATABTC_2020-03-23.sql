-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 15:59:59','2018-11-28 19:59:59','DATABTC','4h','0.000005160000000','0.000004870000000','0.001467500000000','0.001385024224806','284.3992248062016','284.399224806201573','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','DATABTC','4h','0.000005120000000','0.000004940000000','0.001467500000000','0.001415908203125','286.62109375','286.621093750000000','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','DATABTC','4h','0.000004980000000','0.000005040000000','0.001467500000000','0.001485180722892','294.6787148594378','294.678714859437775','test'),('2018-12-04 07:59:59','2018-12-04 11:59:59','DATABTC','4h','0.000004990000000','0.000005040000000','0.001467500000000','0.001482204408818','294.08817635270543','294.088176352705432','test'),('2018-12-05 03:59:59','2018-12-06 11:59:59','DATABTC','4h','0.000004970000000','0.000004900000000','0.001467500000000','0.001446830985915','295.27162977867204','295.271629778672036','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','DATABTC','4h','0.000005120000000','0.000004950000000','0.001467500000000','0.001418774414063','286.62109375','286.621093750000000','test'),('2018-12-22 23:59:59','2018-12-23 03:59:59','DATABTC','4h','0.000004900000000','0.000004660000000','0.001467500000000','0.001395622448980','299.4897959183674','299.489795918367406','test'),('2018-12-28 07:59:59','2018-12-28 11:59:59','DATABTC','4h','0.000004730000000','0.000004910000000','0.001467500000000','0.001523345665962','310.25369978858356','310.253699788583560','test'),('2019-01-01 15:59:59','2019-01-01 19:59:59','DATABTC','4h','0.000004740000000','0.000004770000000','0.001467500000000','0.001476787974684','309.59915611814347','309.599156118143469','test'),('2019-01-02 23:59:59','2019-01-03 07:59:59','DATABTC','4h','0.000004750000000','0.000004720000000','0.001467500000000','0.001458231578947','308.9473684210526','308.947368421052602','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','DATABTC','4h','0.000004750000000','0.000004730000000','0.001467500000000','0.001461321052632','308.9473684210526','308.947368421052602','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','DATABTC','4h','0.000005400000000','0.000005060000000','0.001467500000000','0.001375101851852','271.7592592592593','271.759259259259295','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','DATABTC','4h','0.000004840000000','0.000004850000000','0.001467500000000','0.001470532024793','303.202479338843','303.202479338842977','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','DATABTC','4h','0.000004830000000','0.000004890000000','0.001467500000000','0.001485729813665','303.8302277432712','303.830227743271223','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','DATABTC','4h','0.000004810000000','0.000004800000000','0.001467500000000','0.001464449064449','305.0935550935551','305.093555093555096','test'),('2019-01-30 23:59:59','2019-01-31 07:59:59','DATABTC','4h','0.000005160000000','0.000005110000000','0.001467500000000','0.001453280038760','284.3992248062016','284.399224806201573','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','DATABTC','4h','0.000005230000000','0.000005160000000','0.001467500000000','0.001447858508604','280.5927342256214','280.592734225621427','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','DATABTC','4h','0.000005170000000','0.000005110000000','0.001467500000000','0.001450469052224','283.84912959381046','283.849129593810460','test'),('2019-02-09 23:59:59','2019-02-10 03:59:59','DATABTC','4h','0.000005050000000','0.000005010000000','0.001467500000000','0.001455876237624','290.5940594059406','290.594059405940584','test'),('2019-02-13 15:59:59','2019-02-13 19:59:59','DATABTC','4h','0.000005170000000','0.000005080000000','0.001467500000000','0.001441953578337','283.84912959381046','283.849129593810460','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','DATABTC','4h','0.000004810000000','0.000004740000000','0.001467500000000','0.001446143451143','305.0935550935551','305.093555093555096','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','DATABTC','4h','0.000004730000000','0.000004700000000','0.001467500000000','0.001458192389006','310.25369978858356','310.253699788583560','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','DATABTC','4h','0.000004790000000','0.000004730000000','0.001467500000000','0.001449117954071','306.36743215031316','306.367432150313164','test'),('2019-03-01 07:59:59','2019-03-01 15:59:59','DATABTC','4h','0.000004730000000','0.000004710000000','0.001467500000000','0.001461294926004','310.25369978858356','310.253699788583560','test'),('2019-03-02 15:59:59','2019-03-02 19:59:59','DATABTC','4h','0.000004760000000','0.000004760000000','0.001467500000000','0.001467500000000','308.29831932773106','308.298319327731065','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','DATABTC','4h','0.000004750000000','0.000004720000000','0.001467500000000','0.001458231578947','308.9473684210526','308.947368421052602','test'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DATABTC','4h','0.000004930000000','0.000005010000000','0.001467500000000','0.001491313387424','297.66734279918865','297.667342799188646','test'),('2019-03-25 15:59:59','2019-03-26 11:59:59','DATABTC','4h','0.000005200000000','0.000006020000000','0.001467500000000','0.001698913461538','282.21153846153845','282.211538461538453','test'),('2019-04-19 03:59:59','2019-04-19 07:59:59','DATABTC','4h','0.000004820000000','0.000004830000000','0.001467500000000','0.001470544605809','304.4605809128631','304.460580912863122','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','DATABTC','4h','0.000002640000000','0.000002560000000','0.001467500000000','0.001423030303030','555.8712121212121','555.871212121212125','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','DATABTC','4h','0.000003510000000','0.000002880000000','0.001467500000000','0.001204102564103','418.09116809116813','418.091168091168129','test'),('2019-05-25 15:59:59','2019-05-26 19:59:59','DATABTC','4h','0.000002810000000','0.000002830000000','0.001467500000000','0.001477944839858','522.2419928825623','522.241992882562272','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','DATABTC','4h','0.000002900000000','0.000002820000000','0.001467500000000','0.001427017241379','506.0344827586207','506.034482758620697','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','DATABTC','4h','0.000003110000000','0.000003100000000','0.001467500000000','0.001462781350482','471.86495176848877','471.864951768488766','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','DATABTC','4h','0.000003050000000','0.000003050000000','0.001467500000000','0.001467500000000','481.1475409836066','481.147540983606575','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','DATABTC','4h','0.000003100000000','0.000003020000000','0.001467500000000','0.001429629032258','473.3870967741936','473.387096774193594','test'),('2019-06-10 19:59:59','2019-06-10 23:59:59','DATABTC','4h','0.000003150000000','0.000003090000000','0.001467500000000','0.001439547619048','465.8730158730159','465.873015873015902','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','DATABTC','4h','0.000003090000000','0.000003070000000','0.001467500000000','0.001458001618123','474.9190938511327','474.919093851132686','test'),('2019-06-13 07:59:59','2019-06-13 11:59:59','DATABTC','4h','0.000003190000000','0.000003150000000','0.001467500000000','0.001449098746082','460.0313479623825','460.031347962382483','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','DATABTC','4h','0.000002000000000','0.000001860000000','0.001467500000000','0.001364775000000','733.7500000000001','733.750000000000114','test'),('2019-07-23 19:59:59','2019-07-23 23:59:59','DATABTC','4h','0.000001480000000','0.000001460000000','0.001467500000000','0.001447668918919','991.5540540540541','991.554054054054063','test'),('2019-07-24 23:59:59','2019-07-25 03:59:59','DATABTC','4h','0.000001450000000','0.000001440000000','0.001467500000000','0.001457379310345','1012.0689655172414','1012.068965517241395','test'),('2019-07-25 11:59:59','2019-07-26 11:59:59','DATABTC','4h','0.000001460000000','0.000001470000000','0.001467500000000','0.001477551369863','1005.1369863013699','1005.136986301369916','test'),('2019-08-15 23:59:59','2019-08-16 15:59:59','DATABTC','4h','0.000001220000000','0.000001150000000','0.001467500000000','0.001383299180328','1202.8688524590166','1202.868852459016580','test'),('2019-08-17 07:59:59','2019-08-17 11:59:59','DATABTC','4h','0.000001120000000','0.000001100000000','0.001467500000000','0.001441294642857','1310.267857142857','1310.267857142857110','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','DATABTC','4h','0.000001080000000','0.000001090000000','0.001467500000000','0.001481087962963','1358.7962962962963','1358.796296296296305','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','DATABTC','4h','0.000001060000000','0.000001060000000','0.001467500000000','0.001467500000000','1384.433962264151','1384.433962264150978','test'),('2019-08-23 23:59:59','2019-08-28 19:59:59','DATABTC','4h','0.000001110000000','0.000001150000000','0.001467500000000','0.001520382882883','1322.0720720720722','1322.072072072072160','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','DATABTC','4h','0.000001210000000','0.000001190000000','0.001467500000000','0.001443243801653','1212.809917355372','1212.809917355371908','test'),('2019-09-10 07:59:59','2019-09-10 15:59:59','DATABTC','4h','0.000001190000000','0.000001180000000','0.001467500000000','0.001455168067227','1233.1932773109243','1233.193277310924259','test'),('2019-09-15 11:59:59','2019-09-16 11:59:59','DATABTC','4h','0.000001180000000','0.000001140000000','0.001467500000000','0.001417754237288','1243.6440677966102','1243.644067796610216','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','DATABTC','4h','0.000001270000000','0.000001230000000','0.001467500000000','0.001421279527559','1155.5118110236222','1155.511811023622158','test'),('2019-09-27 23:59:59','2019-09-28 03:59:59','DATABTC','4h','0.000001270000000','0.000001280000000','0.001467500000000','0.001479055118110','1155.5118110236222','1155.511811023622158','test'),('2019-09-30 11:59:59','2019-09-30 15:59:59','DATABTC','4h','0.000001280000000','0.000001270000000','0.001467500000000','0.001456035156250','1146.484375','1146.484375000000000','test'),('2019-10-01 07:59:59','2019-10-09 15:59:59','DATABTC','4h','0.000001270000000','0.000001400000000','0.001467500000000','0.001617716535433','1155.5118110236222','1155.511811023622158','test'),('2019-10-10 15:59:59','2019-10-11 07:59:59','DATABTC','4h','0.000001450000000','0.000001440000000','0.001467500000000','0.001457379310345','1012.0689655172414','1012.068965517241395','test'),('2019-10-13 23:59:59','2019-10-14 03:59:59','DATABTC','4h','0.000001460000000','0.000001450000000','0.001467500000000','0.001457448630137','1005.1369863013699','1005.136986301369916','test'),('2019-10-20 11:59:59','2019-10-20 15:59:59','DATABTC','4h','0.000001590000000','0.000001540000000','0.001467500000000','0.001421352201258','922.9559748427673','922.955974842767318','test'),('2019-11-07 15:59:59','2019-11-07 23:59:59','DATABTC','4h','0.000001390000000','0.000001360000000','0.001467500000000','0.001435827338129','1055.7553956834533','1055.755395683453344','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','DATABTC','4h','0.000001460000000','0.000001420000000','0.001467500000000','0.001427294520548','1005.1369863013699','1005.136986301369916','test'),('2019-11-14 11:59:59','2019-11-14 15:59:59','DATABTC','4h','0.000001370000000','0.000001370000000','0.001467500000000','0.001467500000000','1071.1678832116788','1071.167883211678827','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','DATABTC','4h','0.000001370000000','0.000001350000000','0.001467500000000','0.001446076642336','1071.1678832116788','1071.167883211678827','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','DATABTC','4h','0.000001370000000','0.000001380000000','0.001467500000000','0.001478211678832','1071.1678832116788','1071.167883211678827','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:07:48
