-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-06 15:59:59','2018-05-07 07:59:59','NULSBTC','4h','0.000391620000000','0.000385040000000','0.001467500000000','0.001442843062152','3.747254992084163','3.747254992084163','test'),('2018-05-07 19:59:59','2018-05-09 03:59:59','NULSBTC','4h','0.000392900000000','0.000392410000000','0.001467500000000','0.001465669826928','3.7350470857724614','3.735047085772461','test'),('2018-05-22 11:59:59','2018-05-23 11:59:59','NULSBTC','4h','0.000518540000000','0.000499900000000','0.001467500000000','0.001414747656883','2.830061326030779','2.830061326030779','test'),('2018-05-25 15:59:59','2018-05-25 19:59:59','NULSBTC','4h','0.000506470000000','0.000504090000000','0.001467500000000','0.001460603935080','2.8975062688806843','2.897506268880684','test'),('2018-05-30 15:59:59','2018-06-02 23:59:59','NULSBTC','4h','0.000500450000000','0.000510070000000','0.001467500000000','0.001495709311620','2.932360875212309','2.932360875212309','test'),('2018-06-07 03:59:59','2018-06-07 07:59:59','NULSBTC','4h','0.000513360000000','0.000507010000000','0.001467500000000','0.001449347777388','2.8586177341436807','2.858617734143681','test'),('2018-06-07 15:59:59','2018-06-07 19:59:59','NULSBTC','4h','0.000506600000000','0.000503400000000','0.001467500000000','0.001458230359258','2.8967627319384133','2.896762731938413','test'),('2018-06-18 23:59:59','2018-06-19 03:59:59','NULSBTC','4h','0.000432230000000','0.000419910000000','0.001467500000000','0.001425671343960','3.395183120098096','3.395183120098096','test'),('2018-07-02 07:59:59','2018-07-02 11:59:59','NULSBTC','4h','0.000372270000000','0.000363510000000','0.001467500000000','0.001432967805625','3.942031321352782','3.942031321352782','test'),('2018-07-07 23:59:59','2018-07-08 03:59:59','NULSBTC','4h','0.000372500000000','0.000355340000000','0.001467500000000','0.001399896510067','3.9395973154362416','3.939597315436242','test'),('2018-07-11 11:59:59','2018-07-11 15:59:59','NULSBTC','4h','0.000393370000000','0.000384510000000','0.001467500000000','0.001434447021888','3.730584437044005','3.730584437044005','test'),('2018-07-18 11:59:59','2018-07-18 15:59:59','NULSBTC','4h','0.000388650000000','0.000377990000000','0.001467500000000','0.001427249002959','3.775890904412711','3.775890904412711','test'),('2018-08-12 15:59:59','2018-08-12 19:59:59','NULSBTC','4h','0.000269100000000','0.000259290000000','0.001467500000000','0.001414002508361','5.453363062058715','5.453363062058715','test'),('2018-08-17 03:59:59','2018-08-17 07:59:59','NULSBTC','4h','0.000244890000000','0.000239150000000','0.001467500000000','0.001433103127935','5.992486422475397','5.992486422475397','test'),('2018-08-17 15:59:59','2018-08-18 03:59:59','NULSBTC','4h','0.000246750000000','0.000243220000000','0.001467500000000','0.001446505977710','5.947315096251266','5.947315096251266','test'),('2018-08-25 19:59:59','2018-08-25 23:59:59','NULSBTC','4h','0.000234520000000','0.000231590000000','0.001467500000000','0.001449165636193','6.257462050144977','6.257462050144977','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','NULSBTC','4h','0.000226510000000','0.000225090000000','0.001467500000000','0.001458300185422','6.478742660368196','6.478742660368196','test'),('2018-08-26 23:59:59','2018-08-27 15:59:59','NULSBTC','4h','0.000228590000000','0.000229050000000','0.001467500000000','0.001470453103810','6.419790891990026','6.419790891990026','test'),('2018-08-30 11:59:59','2018-08-30 15:59:59','NULSBTC','4h','0.000268800000000','0.000265280000000','0.001467500000000','0.001448282738095','5.459449404761905','5.459449404761905','test'),('2018-09-03 11:59:59','2018-09-03 15:59:59','NULSBTC','4h','0.000243400000000','0.000244180000000','0.001467500000000','0.001472202752671','6.029170090386196','6.029170090386196','test'),('2018-09-04 07:59:59','2018-09-04 11:59:59','NULSBTC','4h','0.000242810000000','0.000242220000000','0.001467500000000','0.001463934146040','6.043820270993781','6.043820270993781','test'),('2018-09-23 23:59:59','2018-09-24 03:59:59','NULSBTC','4h','0.000181820000000','0.000182890000000','0.001467500000000','0.001476136151138','8.071169288307118','8.071169288307118','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NULSBTC','4h','0.000194340000000','0.000182050000000','0.001467500000000','0.001374695765154','7.551198929710816','7.551198929710816','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','NULSBTC','4h','0.000179840000000','0.000178840000000','0.001467500000000','0.001459339968861','8.160031138790035','8.160031138790035','test'),('2018-10-02 23:59:59','2018-10-03 03:59:59','NULSBTC','4h','0.000179460000000','0.000177950000000','0.001467500000000','0.001455152262343','8.177309706898473','8.177309706898473','test'),('2018-10-04 23:59:59','2018-10-05 07:59:59','NULSBTC','4h','0.000181230000000','0.000178000000000','0.001467500000000','0.001441345251890','8.097445235336313','8.097445235336313','test'),('2018-10-05 15:59:59','2018-10-05 19:59:59','NULSBTC','4h','0.000179060000000','0.000179960000000','0.001467500000000','0.001474876019211','8.19557690159723','8.195576901597230','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','NULSBTC','4h','0.000179740000000','0.000179070000000','0.001467500000000','0.001462029737398','8.164571047067987','8.164571047067987','test'),('2018-10-23 03:59:59','2018-10-23 07:59:59','NULSBTC','4h','0.000177000000000','0.000175420000000','0.001467500000000','0.001454400282486','8.290960451977401','8.290960451977401','test'),('2018-10-25 19:59:59','2018-10-25 23:59:59','NULSBTC','4h','0.000178150000000','0.000175350000000','0.001467500000000','0.001444435166994','8.237440359247826','8.237440359247826','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','NULSBTC','4h','0.000178260000000','0.000172940000000','0.001467500000000','0.001423703859531','8.232357231010884','8.232357231010884','test'),('2018-11-06 23:59:59','2018-11-07 03:59:59','NULSBTC','4h','0.000174550000000','0.000172350000000','0.001467500000000','0.001449003867087','8.407333142366085','8.407333142366085','test'),('2018-12-03 15:59:59','2018-12-04 07:59:59','NULSBTC','4h','0.000128980000000','0.000128370000000','0.001467500000000','0.001460559582881','11.377732981857653','11.377732981857653','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','NULSBTC','4h','0.000130730000000','0.000127690000000','0.001467500000000','0.001433374703588','11.225426451464852','11.225426451464852','test'),('2018-12-13 07:59:59','2018-12-13 15:59:59','NULSBTC','4h','0.000125650000000','0.000124080000000','0.001467500000000','0.001449163549542','11.679267807401514','11.679267807401514','test'),('2018-12-18 03:59:59','2018-12-18 07:59:59','NULSBTC','4h','0.000123600000000','0.000121810000000','0.001467500000000','0.001446247370550','11.872977346278319','11.872977346278319','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','NULSBTC','4h','0.000123970000000','0.000120820000000','0.001467500000000','0.001430211744777','11.837541340646931','11.837541340646931','test'),('2018-12-23 19:59:59','2018-12-24 03:59:59','NULSBTC','4h','0.000119370000000','0.000121090000000','0.001467500000000','0.001488645178856','12.293708637010974','12.293708637010974','test'),('2019-01-05 11:59:59','2019-01-05 15:59:59','NULSBTC','4h','0.000110110000000','0.000109370000000','0.001467500000000','0.001457637589683','13.32758150939969','13.327581509399691','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','NULSBTC','4h','0.000112970000000','0.000108960000000','0.001467500000000','0.001415409400726','12.990174382579447','12.990174382579447','test'),('2019-01-09 23:59:59','2019-01-10 07:59:59','NULSBTC','4h','0.000110070000000','0.000105200000000','0.001467500000000','0.001402571091124','13.33242482056873','13.332424820568731','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','NULSBTC','4h','0.000107820000000','0.000106780000000','0.001467500000000','0.001453344926730','13.610647375255056','13.610647375255056','test'),('2019-01-16 19:59:59','2019-01-17 03:59:59','NULSBTC','4h','0.000106910000000','0.000106800000000','0.001467500000000','0.001465990085118','13.726498924328874','13.726498924328874','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','NULSBTC','4h','0.000121580000000','0.000116260000000','0.001467500000000','0.001403286313538','12.070241816088172','12.070241816088172','test'),('2019-01-29 11:59:59','2019-01-29 19:59:59','NULSBTC','4h','0.000122160000000','0.000120420000000','0.001467500000000','0.001446597495088','12.01293385723641','12.012933857236410','test'),('2019-01-30 15:59:59','2019-01-30 23:59:59','NULSBTC','4h','0.000119800000000','0.000119060000000','0.001467500000000','0.001458435308848','12.24958263772955','12.249582637729549','test'),('2019-02-03 03:59:59','2019-02-03 07:59:59','NULSBTC','4h','0.000117200000000','0.000117530000000','0.001467500000000','0.001471632039249','12.521331058020477','12.521331058020477','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','NULSBTC','4h','0.000112700000000','0.000112190000000','0.001467500000000','0.001460859139308','13.021295474711623','13.021295474711623','test'),('2019-02-14 03:59:59','2019-02-14 07:59:59','NULSBTC','4h','0.000112670000000','0.000111910000000','0.001467500000000','0.001457601180438','13.024762580988728','13.024762580988728','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','NULSBTC','4h','0.000111970000000','0.000112410000000','0.001467500000000','0.001473266723229','13.106189157810128','13.106189157810128','test'),('2019-02-16 03:59:59','2019-02-16 11:59:59','NULSBTC','4h','0.000114200000000','0.000112090000000','0.001467500000000','0.001440385945709','12.850262697022767','12.850262697022767','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','NULSBTC','4h','0.000113300000000','0.000112930000000','0.001467500000000','0.001462707634598','12.952338923212709','12.952338923212709','test'),('2019-02-20 19:59:59','2019-02-21 03:59:59','NULSBTC','4h','0.000113870000000','0.000113420000000','0.001467500000000','0.001461700623518','12.887503293229122','12.887503293229122','test'),('2019-02-21 15:59:59','2019-02-22 03:59:59','NULSBTC','4h','0.000113130000000','0.000112240000000','0.001467500000000','0.001455955095907','12.971802351277292','12.971802351277292','test'),('2019-02-23 11:59:59','2019-02-23 15:59:59','NULSBTC','4h','0.000113090000000','0.000112420000000','0.001467500000000','0.001458805818375','12.976390485454063','12.976390485454063','test'),('2019-02-28 23:59:59','2019-03-01 07:59:59','NULSBTC','4h','0.000110590000000','0.000110260000000','0.001467500000000','0.001463120987431','13.269735057419297','13.269735057419297','test'),('2019-03-04 19:59:59','2019-03-06 11:59:59','NULSBTC','4h','0.000113170000000','0.000111940000000','0.001467500000000','0.001451550322524','12.967217460457718','12.967217460457718','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','NULSBTC','4h','0.000111070000000','0.000111790000000','0.001467500000000','0.001477012919780','13.212388583775997','13.212388583775997','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','NULSBTC','4h','0.000188380000000','0.000185530000000','0.001467500000000','0.001445298200446','7.790105106699225','7.790105106699225','test'),('2019-04-06 03:59:59','2019-04-06 19:59:59','NULSBTC','4h','0.000189000000000','0.000188090000000','0.001467500000000','0.001460434259259','7.764550264550264','7.764550264550264','test'),('2019-04-15 15:59:59','2019-04-15 19:59:59','NULSBTC','4h','0.000175550000000','0.000167610000000','0.001467500000000','0.001401126032469','8.359441754485902','8.359441754485902','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','NULSBTC','4h','0.000173140000000','0.000172820000000','0.001467500000000','0.001464787744022','8.475799930691926','8.475799930691926','test'),('2019-04-17 19:59:59','2019-04-18 07:59:59','NULSBTC','4h','0.000170960000000','0.000170670000000','0.001467500000000','0.001465010675012','8.58387927000468','8.583879270004680','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','NULSBTC','4h','0.000169260000000','0.000165910000000','0.001467500000000','0.001438455187286','8.670093347512703','8.670093347512703','test'),('2019-04-23 15:59:59','2019-04-23 19:59:59','NULSBTC','4h','0.000168500000000','0.000164100000000','0.001467500000000','0.001429179525223','8.70919881305638','8.709198813056380','test'),('2019-04-23 23:59:59','2019-04-24 03:59:59','NULSBTC','4h','0.000173430000000','0.000168540000000','0.001467500000000','0.001426122643141','8.461627169463185','8.461627169463185','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:14:41
