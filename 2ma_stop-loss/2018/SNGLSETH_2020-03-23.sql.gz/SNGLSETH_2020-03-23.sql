-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-03-19 19:59:59','SNGLSETH','4h','0.000112500000000','0.000113380000000','0.072144500000000','0.072708830311111','641.2844444444445','641.284444444444489','test'),('2018-03-31 07:59:59','2018-03-31 11:59:59','SNGLSETH','4h','0.000133490000000','0.000131980000000','0.072285582577778','0.071467909121396','541.5056002530358','541.505600253035823','test'),('2018-03-31 19:59:59','2018-03-31 23:59:59','SNGLSETH','4h','0.000151450000000','0.000142400000000','0.072285582577778','0.067966107356062','477.29007974762624','477.290079747626237','test'),('2018-04-29 19:59:59','2018-04-29 23:59:59','SNGLSETH','4h','0.000180280000000','0.000175500000000','0.072285582577778','0.070368980155314','400.96284988783','400.962849887829975','test'),('2018-05-04 19:59:59','2018-05-04 23:59:59','SNGLSETH','4h','0.000168000000000','0.000162430000000','0.072285582577778','0.069888971298265','430.27132486772615','430.271324867726150','test'),('2018-05-24 19:59:59','2018-05-25 19:59:59','SNGLSETH','4h','0.000122710000000','0.000119650000000','0.072285582577778','0.070483008356541','589.0765428879308','589.076542887930827','test'),('2018-06-17 23:59:59','2018-06-18 03:59:59','SNGLSETH','4h','0.000097750000000','0.000090000000000','0.072285582577778','0.066554500583120','739.49445092356','739.494450923559953','test'),('2018-06-18 11:59:59','2018-06-18 15:59:59','SNGLSETH','4h','0.000092500000000','0.000094250000000','0.072285582577778','0.073653147653574','781.4657575975999','781.465757597599918','test'),('2018-07-01 07:59:59','2018-07-01 11:59:59','SNGLSETH','4h','0.000082970000000','0.000079870000000','0.072285582577778','0.069584783421564','871.2255342627213','871.225534262721339','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','SNGLSETH','4h','0.000088170000000','0.000080420000000','0.072285582577778','0.065931797106781','819.8432865802199','819.843286580219910','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','SNGLSETH','4h','0.000083510000000','0.000084270000000','0.072285582577778','0.072943432449160','865.5919360289545','865.591936028954478','test'),('2018-07-09 23:59:59','2018-07-10 03:59:59','SNGLSETH','4h','0.000083340000000','0.000082720000000','0.072285582577778','0.071747820864336','867.35760232515','867.357602325149969','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','SNGLSETH','4h','0.000081720000000','0.000080630000000','0.072285582577778','0.071321420989308','884.5519160276309','884.551916027630909','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','SNGLSETH','4h','0.000081410000000','0.000080050000000','0.072285582577778','0.071078011120884','887.9201888929861','887.920188892986062','test'),('2018-07-17 11:59:59','2018-07-17 15:59:59','SNGLSETH','4h','0.000084840000000','0.000081070000000','0.072285582577778','0.069073458033716','852.0224254806459','852.022425480645893','test'),('2018-07-21 07:59:59','2018-07-21 11:59:59','SNGLSETH','4h','0.000086940000000','0.000083410000000','0.072285582577778','0.069350591704767','831.4421736574418','831.442173657441799','test'),('2018-07-29 15:59:59','2018-07-29 19:59:59','SNGLSETH','4h','0.000078230000000','0.000077770000000','0.072285582577778','0.071860536329717','924.0135827403552','924.013582740355218','test'),('2018-07-31 07:59:59','2018-07-31 11:59:59','SNGLSETH','4h','0.000078000000000','0.000077750000000','0.072285582577778','0.072053898018234','926.738238176641','926.738238176640948','test'),('2018-08-13 11:59:59','2018-08-13 15:59:59','SNGLSETH','4h','0.000071170000000','0.000073080000000','0.072285582577778','0.074225521635296','1015.6748992240831','1015.674899224083106','test'),('2018-08-16 19:59:59','2018-08-23 03:59:59','SNGLSETH','4h','0.000072230000000','0.000077290000000','0.072285582577778','0.077349476359358','1000.7695220514743','1000.769522051474269','test'),('2018-08-23 11:59:59','2018-08-23 15:59:59','SNGLSETH','4h','0.000078720000000','0.000080170000000','0.072285582577778','0.073617062439792','918.261973803074','918.261973803074056','test'),('2018-09-06 15:59:59','2018-09-13 23:59:59','SNGLSETH','4h','0.000089710000000','0.000095980000000','0.072285582577778','0.077337757393993','805.7695081682978','805.769508168297762','test'),('2018-09-16 03:59:59','2018-09-17 11:59:59','SNGLSETH','4h','0.000095650000000','0.000134600000000','0.072285582577778','0.101721269367161','755.7300844514166','755.730084451416587','test'),('2018-09-22 07:59:59','2018-09-22 11:59:59','SNGLSETH','4h','0.000107560000000','0.000103980000000','0.074609743839584','0.072126451882112','693.6569713609479','693.656971360947864','test'),('2018-09-22 15:59:59','2018-09-22 19:59:59','SNGLSETH','4h','0.000112300000000','0.000103850000000','0.074609743839584','0.068995742633489','664.3788409580054','664.378840958005412','test'),('2018-09-23 15:59:59','2018-09-23 19:59:59','SNGLSETH','4h','0.000106460000000','0.000104360000000','0.074609743839584','0.073138013029297','700.8241953746384','700.824195374638407','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','SNGLSETH','4h','0.000111150000000','0.000104140000000','0.074609743839584','0.069904262019382','671.252756091624','671.252756091623951','test'),('2018-09-26 23:59:59','2018-09-27 03:59:59','SNGLSETH','4h','0.000106630000000','0.000105190000000','0.074609743839584','0.073602165942848','699.7068727336023','699.706872733602268','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','SNGLSETH','4h','0.000105740000000','0.000104250000000','0.074609743839584','0.073558405478311','705.5962156192927','705.596215619292707','test'),('2018-09-28 15:59:59','2018-09-29 03:59:59','SNGLSETH','4h','0.000106300000000','0.000106780000000','0.074609743839584','0.074946645787307','701.8790577571402','701.879057757140231','test'),('2018-10-01 03:59:59','2018-10-01 15:59:59','SNGLSETH','4h','0.000105500000000','0.000106670000000','0.074609743839584','0.075437169434772','707.2013634083792','707.201363408379166','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','SNGLSETH','4h','0.000111740000000','0.000111120000000','0.074609743839584','0.074195764591503','667.7084646463577','667.708464646357697','test'),('2018-10-13 15:59:59','2018-10-17 19:59:59','SNGLSETH','4h','0.000120560000000','0.000128250000000','0.074609743839584','0.079368776106724','618.859852684008','618.859852684008047','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','SNGLSETH','4h','0.000127350000000','0.000124000000000','0.074609743839584','0.072647100401322','585.8637129138908','585.863712913890822','test'),('2018-10-20 03:59:59','2018-10-20 07:59:59','SNGLSETH','4h','0.000127530000000','0.000126960000000','0.074609743839584','0.074276272860296','585.0368057679292','585.036805767929195','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','SNGLSETH','4h','0.000133300000000','0.000132660000000','0.074609743839584','0.074251527515073','559.7130070486422','559.713007048642226','test'),('2018-11-09 03:59:59','2018-11-09 07:59:59','SNGLSETH','4h','0.000141860000000','0.000139620000000','0.074609743839584','0.073431639890616','525.9392629323559','525.939262932355859','test'),('2018-11-28 11:59:59','2018-11-28 23:59:59','SNGLSETH','4h','0.000114790000000','0.000115000000000','0.074609743839584','0.074746236967960','649.9672779822633','649.967277982263340','test'),('2018-12-01 11:59:59','2018-12-03 15:59:59','SNGLSETH','4h','0.000118370000000','0.000120540000000','0.074609743839584','0.075977515607193','630.3095703268059','630.309570326805897','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','SNGLSETH','4h','0.000118130000000','0.000115710000000','0.074609743839584','0.073081295688464','631.590145090866','631.590145090866031','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','SNGLSETH','4h','0.000118810000000','0.000117560000000','0.074609743839584','0.073824774730928','627.9752869252084','627.975286925208366','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','SNGLSETH','4h','0.000107370000000','0.000100810000000','0.074609743839584','0.070051301820513','694.8844541267022','694.884454126702167','test'),('2019-01-08 07:59:59','2019-01-08 11:59:59','SNGLSETH','4h','0.000074560000000','0.000072220000000','0.074609743839584','0.072268182672945','1000.6671652304722','1000.667165230472165','test'),('2019-01-10 11:59:59','2019-01-14 19:59:59','SNGLSETH','4h','0.000074230000000','0.000076390000000','0.074609743839584','0.076780793909549','1005.1157731319413','1005.115773131941296','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','SNGLSETH','4h','0.000097970000000','0.000095760000000','0.074609743839584','0.072926702766955','761.5570464385424','761.557046438542443','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','SNGLSETH','4h','0.000094600000000','0.000093610000000','0.074609743839584','0.073828944194751','788.6865099321777','788.686509932177728','test'),('2019-02-28 19:59:59','2019-03-06 15:59:59','SNGLSETH','4h','0.000095150000000','0.000100780000000','0.074609743839584','0.079024382387318','784.1276283718761','784.127628371876085','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:47:01
