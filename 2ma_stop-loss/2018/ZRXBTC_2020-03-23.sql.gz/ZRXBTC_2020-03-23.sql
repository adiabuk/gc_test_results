-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 11:59:59','2018-03-23 03:59:59','ZRXBTC','4h','0.000062830000000','0.000062200000000','0.001467500000000','0.001452785293650','23.356676746777016','23.356676746777016','test'),('2018-03-23 11:59:59','2018-03-23 15:59:59','ZRXBTC','4h','0.000064510000000','0.000064360000000','0.001467500000000','0.001464087738335','22.748411099054408','22.748411099054408','test'),('2018-03-24 11:59:59','2018-03-26 15:59:59','ZRXBTC','4h','0.000063970000000','0.000065000000000','0.001467500000000','0.001491128654057','22.940440831639833','22.940440831639833','test'),('2018-05-19 19:59:59','2018-05-19 23:59:59','ZRXBTC','4h','0.000178950000000','0.000178520000000','0.001468875421511','0.001465345852183','8.208300762841576','8.208300762841576','test'),('2018-05-23 19:59:59','2018-05-23 23:59:59','ZRXBTC','4h','0.000183870000000','0.000177920000000','0.001468875421511','0.001421342878095','7.988662759074346','7.988662759074346','test'),('2018-05-29 19:59:59','2018-05-30 15:59:59','ZRXBTC','4h','0.000168960000000','0.000167440000000','0.001468875421511','0.001455661106639','8.693628204965671','8.693628204965671','test'),('2018-05-31 07:59:59','2018-05-31 23:59:59','ZRXBTC','4h','0.000174250000000','0.000170940000000','0.001468875421511','0.001440973110778','8.429701127753228','8.429701127753228','test'),('2018-06-02 19:59:59','2018-06-02 23:59:59','ZRXBTC','4h','0.000168280000000','0.000168370000000','0.001468875421511','0.001469661009745','8.728758150172332','8.728758150172332','test'),('2018-06-06 03:59:59','2018-06-06 19:59:59','ZRXBTC','4h','0.000169560000000','0.000169460000000','0.001468875421511','0.001468009134992','8.662865189378392','8.662865189378392','test'),('2018-06-30 07:59:59','2018-06-30 19:59:59','ZRXBTC','4h','0.000117980000000','0.000118040000000','0.001468875421511','0.001469622433931','12.450206997041871','12.450206997041871','test'),('2018-07-13 15:59:59','2018-07-16 19:59:59','ZRXBTC','4h','0.000136350000000','0.000167800000000','0.001468875421511','0.001807680936777','10.772830374118078','10.772830374118078','test'),('2018-07-21 15:59:59','2018-07-21 23:59:59','ZRXBTC','4h','0.000159580000000','0.000155750000000','0.001530698694273','0.001493961158247','9.59204595985399','9.592045959853991','test'),('2018-07-28 15:59:59','2018-07-29 03:59:59','ZRXBTC','4h','0.000150320000000','0.000147910000000','0.001530698694273','0.001506157822445','10.182934368500531','10.182934368500531','test'),('2018-07-29 23:59:59','2018-07-30 03:59:59','ZRXBTC','4h','0.000148100000000','0.000140700000000','0.001530698694273','0.001454215437436','10.335575248298447','10.335575248298447','test'),('2018-08-06 03:59:59','2018-08-06 11:59:59','ZRXBTC','4h','0.000140090000000','0.000137840000000','0.001530698694273','0.001506113984000','10.92653789901492','10.926537899014919','test'),('2018-08-06 19:59:59','2018-08-06 23:59:59','ZRXBTC','4h','0.000138580000000','0.000136100000000','0.001530698694273','0.001503305616182','11.045596004279117','11.045596004279117','test'),('2018-08-07 11:59:59','2018-08-07 15:59:59','ZRXBTC','4h','0.000142030000000','0.000140430000000','0.001530698694273','0.001513455028070','10.777291376983737','10.777291376983737','test'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ZRXBTC','4h','0.000138670000000','0.000137250000000','0.001530698694273','0.001515024127706','11.038427159969713','11.038427159969713','test'),('2018-08-11 11:59:59','2018-08-11 15:59:59','ZRXBTC','4h','0.000138920000000','0.000137490000000','0.001530698694273','0.001514942149983','11.018562440778865','11.018562440778865','test'),('2018-08-12 07:59:59','2018-08-12 11:59:59','ZRXBTC','4h','0.000139770000000','0.000138030000000','0.001530698694273','0.001511642990416','10.951553940566646','10.951553940566646','test'),('2018-08-13 03:59:59','2018-08-13 07:59:59','ZRXBTC','4h','0.000138480000000','0.000136860000000','0.001530698694273','0.001512791907122','11.053572315662914','11.053572315662914','test'),('2018-08-27 19:59:59','2018-08-28 03:59:59','ZRXBTC','4h','0.000117280000000','0.000115960000000','0.001530698694273','0.001513470502966','13.05166008077251','13.051660080772510','test'),('2018-09-01 15:59:59','2018-09-01 23:59:59','ZRXBTC','4h','0.000114510000000','0.000111930000000','0.001530698694273','0.001496210853637','13.367380091459262','13.367380091459262','test'),('2018-09-21 03:59:59','2018-09-30 07:59:59','ZRXBTC','4h','0.000088280000000','0.000096600000000','0.001530698694273','0.001674960283946','17.339133374184414','17.339133374184414','test'),('2018-10-04 15:59:59','2018-10-05 07:59:59','ZRXBTC','4h','0.000096600000000','0.000096060000000','0.001530698694273','0.001522141993498','15.84574217673913','15.845742176739130','test'),('2018-10-05 23:59:59','2018-10-06 15:59:59','ZRXBTC','4h','0.000097080000000','0.000096690000000','0.001530698694273','0.001524549410273','15.76739487302225','15.767394873022250','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','ZRXBTC','4h','0.000112620000000','0.000110450000000','0.001530698694273','0.001501204677521','13.591712788785296','13.591712788785296','test'),('2018-10-25 15:59:59','2018-10-25 19:59:59','ZRXBTC','4h','0.000131040000000','0.000130650000000','0.001530698694273','0.001526143043397','11.681156091826924','11.681156091826924','test'),('2018-11-01 19:59:59','2018-11-01 23:59:59','ZRXBTC','4h','0.000127490000000','0.000127100000000','0.001530698694273','0.001526016189835','12.006421635210605','12.006421635210605','test'),('2018-11-03 23:59:59','2018-11-04 03:59:59','ZRXBTC','4h','0.000127320000000','0.000127060000000','0.001530698694273','0.001527572856537','12.022452829665411','12.022452829665411','test'),('2018-11-28 15:59:59','2018-11-29 23:59:59','ZRXBTC','4h','0.000096630000000','0.000102350000000','0.001530698694273','0.001621308199926','15.840822666594226','15.840822666594226','test'),('2018-12-03 07:59:59','2018-12-03 11:59:59','ZRXBTC','4h','0.000097700000000','0.000097190000000','0.001530698694273','0.001522708353085','15.667335662978505','15.667335662978505','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','ZRXBTC','4h','0.000098620000000','0.000096610000000','0.001530698694273','0.001499501124049','15.521179215909552','15.521179215909552','test'),('2018-12-08 03:59:59','2018-12-08 07:59:59','ZRXBTC','4h','0.000098360000000','0.000094090000000','0.001530698694273','0.001464248069786','15.5622071398231','15.562207139823100','test'),('2018-12-09 15:59:59','2018-12-09 19:59:59','ZRXBTC','4h','0.000096320000000','0.000094380000000','0.001530698694273','0.001499868591834','15.89180538074128','15.891805380741280','test'),('2018-12-19 15:59:59','2018-12-19 19:59:59','ZRXBTC','4h','0.000088550000000','0.000088360000000','0.001530698694273','0.001527414304076','17.286264192806325','17.286264192806325','test'),('2018-12-23 19:59:59','2018-12-24 03:59:59','ZRXBTC','4h','0.000087070000000','0.000085900000000','0.001530698694273','0.001510129985506','17.580092962823016','17.580092962823016','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','ZRXBTC','4h','0.000086750000000','0.000087000000000','0.001530698694273','0.001535109929703','17.644941720726226','17.644941720726226','test'),('2018-12-26 15:59:59','2018-12-26 19:59:59','ZRXBTC','4h','0.000086990000000','0.000087520000000','0.001530698694273','0.001540024712298','17.596260423876306','17.596260423876306','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','ZRXBTC','4h','0.000087370000000','0.000087990000000','0.001530698694273','0.001541560926051','17.519728674293237','17.519728674293237','test'),('2019-01-03 11:59:59','2019-01-03 19:59:59','ZRXBTC','4h','0.000084950000000','0.000083830000000','0.001530698694273','0.001510517616726','18.01881923805768','18.018819238057681','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','ZRXBTC','4h','0.000084640000000','0.000084230000000','0.001530698694273','0.001523283920352','18.084814440843573','18.084814440843573','test'),('2019-01-16 15:59:59','2019-01-18 23:59:59','ZRXBTC','4h','0.000081700000000','0.000080080000000','0.001530698694273','0.001500347018817','18.735602133084456','18.735602133084456','test'),('2019-01-22 19:59:59','2019-01-22 23:59:59','ZRXBTC','4h','0.000081150000000','0.000079830000000','0.001530698694273','0.001505800083350','18.862584032939004','18.862584032939004','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ZRXBTC','4h','0.000080860000000','0.000080140000000','0.001530698694273','0.001517068926033','18.930233666497653','18.930233666497653','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ZRXBTC','4h','0.000080980000000','0.000083820000000','0.001530698694273','0.001584380891010','18.90218194953075','18.902181949530750','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ZRXBTC','4h','0.000081630000000','0.000081020000000','0.001530698694273','0.001519260176528','18.751668434068357','18.751668434068357','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','ZRXBTC','4h','0.000066900000000','0.000067400000000','0.001530698694273','0.001542138893782','22.880399017533634','22.880399017533634','test'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXBTC','4h','0.000063660000000','0.000065420000000','0.001530698694273','0.001573017728233','24.044905659330823','24.044905659330823','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:31:34
