-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-27 07:59:59','2018-11-27 11:59:59','AGIBTC','4h','0.000008760000000','0.000008500000000','0.001467500000000','0.001423944063927','167.5228310502283','167.522831050228291','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','AGIBTC','4h','0.000008750000000','0.000009000000000','0.001467500000000','0.001509428571429','167.71428571428572','167.714285714285722','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','AGIBTC','4h','0.000010650000000','0.000010070000000','0.001467500000000','0.001387579812207','137.79342723004694','137.793427230046944','test'),('2018-12-07 15:59:59','2018-12-10 03:59:59','AGIBTC','4h','0.000010700000000','0.000010770000000','0.001467500000000','0.001477100467290','137.1495327102804','137.149532710280397','test'),('2018-12-14 15:59:59','2018-12-14 19:59:59','AGIBTC','4h','0.000010640000000','0.000010420000000','0.001467500000000','0.001437156954887','137.92293233082708','137.922932330827081','test'),('2018-12-15 19:59:59','2018-12-16 19:59:59','AGIBTC','4h','0.000010690000000','0.000010610000000','0.001467500000000','0.001456517773620','137.27782974742752','137.277829747427518','test'),('2018-12-17 15:59:59','2018-12-25 03:59:59','AGIBTC','4h','0.000010840000000','0.000011290000000','0.001467500000000','0.001528420202952','135.37822878228783','135.378228782287835','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','AGIBTC','4h','0.000011620000000','0.000011700000000','0.001467500000000','0.001477603270224','126.2908777969019','126.290877796901896','test'),('2018-12-29 15:59:59','2018-12-29 19:59:59','AGIBTC','4h','0.000012010000000','0.000011260000000','0.001467500000000','0.001375857618651','122.18984179850125','122.189841798501249','test'),('2018-12-30 15:59:59','2019-01-10 07:59:59','AGIBTC','4h','0.000012160000000','0.000012830000000','0.001467500000000','0.001548357319079','120.68256578947368','120.682565789473685','test'),('2019-01-11 07:59:59','2019-01-11 11:59:59','AGIBTC','4h','0.000013190000000','0.000012970000000','0.001467500000000','0.001443023123578','111.25852918877938','111.258529188779377','test'),('2019-01-14 15:59:59','2019-01-15 15:59:59','AGIBTC','4h','0.000013390000000','0.000012570000000','0.001467500000000','0.001377630694548','109.596713965646','109.596713965646003','test'),('2019-01-15 23:59:59','2019-01-16 03:59:59','AGIBTC','4h','0.000013130000000','0.000012930000000','0.001467500000000','0.001445146610815','111.76694592536177','111.766945925361767','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','AGIBTC','4h','0.000013230000000','0.000013050000000','0.001467500000000','0.001447534013605','110.92214663643234','110.922146636432345','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','AGIBTC','4h','0.000013750000000','0.000013020000000','0.001467500000000','0.001389589090909','106.72727272727273','106.727272727272734','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','AGIBTC','4h','0.000013070000000','0.000012980000000','0.001467500000000','0.001457394797246','112.28003060443764','112.280030604437641','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','AGIBTC','4h','0.000013030000000','0.000013070000000','0.001467500000000','0.001472004988488','112.62471220260936','112.624712202609359','test'),('2019-01-21 15:59:59','2019-01-21 19:59:59','AGIBTC','4h','0.000013010000000','0.000012900000000','0.001467500000000','0.001455092236741','112.7978478093774','112.797847809377402','test'),('2019-01-22 07:59:59','2019-01-22 11:59:59','AGIBTC','4h','0.000013060000000','0.000012920000000','0.001467500000000','0.001451768759571','112.36600306278714','112.366003062787144','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','AGIBTC','4h','0.000013310000000','0.000013080000000','0.001467500000000','0.001442141247183','110.25544703230655','110.255447032306549','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','AGIBTC','4h','0.000013170000000','0.000013270000000','0.001467500000000','0.001478642748671','111.42748671222476','111.427486712224763','test'),('2019-02-11 03:59:59','2019-02-11 07:59:59','AGIBTC','4h','0.000012330000000','0.000012170000000','0.001467500000000','0.001448457015410','119.01865369018654','119.018653690186540','test'),('2019-02-11 15:59:59','2019-02-11 19:59:59','AGIBTC','4h','0.000012060000000','0.000012240000000','0.001467500000000','0.001489402985075','121.6832504145937','121.683250414593701','test'),('2019-02-13 23:59:59','2019-02-14 07:59:59','AGIBTC','4h','0.000012120000000','0.000011970000000','0.001467500000000','0.001449337871287','121.0808580858086','121.080858085808600','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','AGIBTC','4h','0.000011960000000','0.000011880000000','0.001467500000000','0.001457683946488','122.70066889632106','122.700668896321062','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','AGIBTC','4h','0.000011920000000','0.000011990000000','0.001467500000000','0.001476117869128','123.11241610738256','123.112416107382558','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','AGIBTC','4h','0.000012010000000','0.000011720000000','0.001467500000000','0.001432064945878','122.18984179850125','122.189841798501249','test'),('2019-02-19 15:59:59','2019-02-19 19:59:59','AGIBTC','4h','0.000012020000000','0.000012530000000','0.001467500000000','0.001529764975042','122.08818635607321','122.088186356073209','test'),('2019-02-21 23:59:59','2019-02-22 07:59:59','AGIBTC','4h','0.000012040000000','0.000012150000000','0.001467500000000','0.001480907392027','121.88538205980068','121.885382059800676','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','AGIBTC','4h','0.000012070000000','0.000011790000000','0.001467500000000','0.001433456917978','121.5824357912179','121.582435791217904','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','AGIBTC','4h','0.000012040000000','0.000012030000000','0.001467500000000','0.001466281146179','121.88538205980068','121.885382059800676','test'),('2019-03-01 07:59:59','2019-03-01 11:59:59','AGIBTC','4h','0.000012160000000','0.000011980000000','0.001467500000000','0.001445777138158','120.68256578947368','120.682565789473685','test'),('2019-03-01 19:59:59','2019-03-02 15:59:59','AGIBTC','4h','0.000012330000000','0.000012210000000','0.001467500000000','0.001453217761557','119.01865369018654','119.018653690186540','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','AGIBTC','4h','0.000011930000000','0.000011630000000','0.001467500000000','0.001430597233864','123.00922045264042','123.009220452640420','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','AGIBTC','4h','0.000013190000000','0.000013400000000','0.001467500000000','0.001490864291130','111.25852918877938','111.258529188779377','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','AGIBTC','4h','0.000013160000000','0.000013010000000','0.001467500000000','0.001450773176292','111.51215805471125','111.512158054711250','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','AGIBTC','4h','0.000009320000000','0.000008940000000','0.001467500000000','0.001407666309013','157.45708154506437','157.457081545064369','test'),('2019-05-07 19:59:59','2019-05-08 03:59:59','AGIBTC','4h','0.000007190000000','0.000006870000000','0.001467500000000','0.001402187065369','204.10292072322673','204.102920723226731','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','AGIBTC','4h','0.000006120000000','0.000005940000000','0.001467500000000','0.001424338235294','239.78758169934642','239.787581699346418','test'),('2019-05-18 11:59:59','2019-05-18 15:59:59','AGIBTC','4h','0.000006090000000','0.000006020000000','0.001467500000000','0.001450632183908','240.96880131362892','240.968801313628916','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','AGIBTC','4h','0.000006070000000','0.000005880000000','0.001467500000000','0.001421565074135','241.76276771004942','241.762767710049417','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','AGIBTC','4h','0.000005900000000','0.000005630000000','0.001467500000000','0.001400343220339','248.72881355932202','248.728813559322020','test'),('2019-05-31 19:59:59','2019-06-01 19:59:59','AGIBTC','4h','0.000005880000000','0.000005820000000','0.001467500000000','0.001452525510204','249.57482993197283','249.574829931972829','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','AGIBTC','4h','0.000005870000000','0.000005840000000','0.001467500000000','0.001460000000000','250.00000000000003','250.000000000000028','test'),('2019-06-10 07:59:59','2019-06-10 15:59:59','AGIBTC','4h','0.000006200000000','0.000006220000000','0.001467500000000','0.001472233870968','236.6935483870968','236.693548387096797','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AGIBTC','4h','0.000006190000000','0.000006110000000','0.001467500000000','0.001448533925687','237.07592891760905','237.075928917609048','test'),('2019-06-12 15:59:59','2019-06-13 03:59:59','AGIBTC','4h','0.000006310000000','0.000006170000000','0.001467500000000','0.001434940570523','232.56735340729003','232.567353407290028','test'),('2019-07-20 03:59:59','2019-07-20 19:59:59','AGIBTC','4h','0.000002530000000','0.000002550000000','0.001467500000000','0.001479100790514','580.0395256916996','580.039525691699623','test'),('2019-07-30 19:59:59','2019-07-31 03:59:59','AGIBTC','4h','0.000003070000000','0.000002960000000','0.001467500000000','0.001414918566775','478.013029315961','478.013029315960978','test'),('2019-08-03 19:59:59','2019-08-03 23:59:59','AGIBTC','4h','0.000002920000000','0.000002920000000','0.001467500000000','0.001467500000000','502.56849315068496','502.568493150684958','test'),('2019-08-08 07:59:59','2019-08-08 11:59:59','AGIBTC','4h','0.000002850000000','0.000002810000000','0.001467500000000','0.001446903508772','514.9122807017544','514.912280701754412','test'),('2019-08-10 23:59:59','2019-08-11 11:59:59','AGIBTC','4h','0.000002820000000','0.000002750000000','0.001467500000000','0.001431072695035','520.3900709219859','520.390070921985853','test'),('2019-08-20 11:59:59','2019-08-20 15:59:59','AGIBTC','4h','0.000003220000000','0.000003120000000','0.001467500000000','0.001421925465839','455.74534161490686','455.745341614906863','test'),('2019-08-24 03:59:59','2019-08-24 07:59:59','AGIBTC','4h','0.000003240000000','0.000003330000000','0.001467500000000','0.001508263888889','452.93209876543216','452.932098765432158','test'),('2019-09-01 03:59:59','2019-09-01 07:59:59','AGIBTC','4h','0.000003380000000','0.000003290000000','0.001467500000000','0.001428424556213','434.1715976331361','434.171597633136116','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','AGIBTC','4h','0.000002610000000','0.000002550000000','0.001467500000000','0.001433764367816','562.2605363984675','562.260536398467480','test'),('2019-09-19 23:59:59','2019-09-20 03:59:59','AGIBTC','4h','0.000002600000000','0.000002630000000','0.001467500000000','0.001484432692308','564.4230769230769','564.423076923076906','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','AGIBTC','4h','0.000002810000000','0.000002710000000','0.001467500000000','0.001415275800712','522.2419928825623','522.241992882562272','test'),('2019-09-28 03:59:59','2019-09-29 11:59:59','AGIBTC','4h','0.000002590000000','0.000002530000000','0.001467500000000','0.001433503861004','566.6023166023166','566.602316602316591','test'),('2019-09-29 23:59:59','2019-09-30 03:59:59','AGIBTC','4h','0.000002630000000','0.000002560000000','0.001467500000000','0.001428441064639','557.9847908745248','557.984790874524833','test'),('2019-10-03 07:59:59','2019-10-03 15:59:59','AGIBTC','4h','0.000002570000000','0.000002540000000','0.001467500000000','0.001450369649805','571.011673151751','571.011673151750983','test'),('2019-10-03 23:59:59','2019-10-09 15:59:59','AGIBTC','4h','0.000002570000000','0.000002680000000','0.001467500000000','0.001530311284047','571.011673151751','571.011673151750983','test'),('2019-10-10 23:59:59','2019-10-11 03:59:59','AGIBTC','4h','0.000002720000000','0.000002690000000','0.001467500000000','0.001451314338235','539.5220588235295','539.522058823529505','test'),('2019-10-11 11:59:59','2019-10-11 15:59:59','AGIBTC','4h','0.000002710000000','0.000002720000000','0.001467500000000','0.001472915129151','541.5129151291513','541.512915129151338','test'),('2019-10-13 23:59:59','2019-10-14 03:59:59','AGIBTC','4h','0.000002730000000','0.000002650000000','0.001467500000000','0.001424496336996','537.5457875457876','537.545787545787562','test'),('2019-10-16 11:59:59','2019-10-16 15:59:59','AGIBTC','4h','0.000002720000000','0.000002640000000','0.001467500000000','0.001424338235294','539.5220588235295','539.522058823529505','test'),('2019-10-17 07:59:59','2019-10-17 11:59:59','AGIBTC','4h','0.000002710000000','0.000002750000000','0.001467500000000','0.001489160516605','541.5129151291513','541.512915129151338','test'),('2019-10-18 15:59:59','2019-10-19 15:59:59','AGIBTC','4h','0.000002720000000','0.000002710000000','0.001467500000000','0.001462104779412','539.5220588235295','539.522058823529505','test'),('2019-10-20 15:59:59','2019-10-20 19:59:59','AGIBTC','4h','0.000002720000000','0.000002650000000','0.001467500000000','0.001429733455882','539.5220588235295','539.522058823529505','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','AGIBTC','4h','0.000002730000000','0.000002700000000','0.001467500000000','0.001451373626374','537.5457875457876','537.545787545787562','test'),('2019-11-06 23:59:59','2019-11-07 03:59:59','AGIBTC','4h','0.000002470000000','0.000002410000000','0.001467500000000','0.001431852226721','594.1295546558705','594.129554655870493','test'),('2019-11-12 03:59:59','2019-11-12 07:59:59','AGIBTC','4h','0.000002390000000','0.000002390000000','0.001467500000000','0.001467500000000','614.0167364016737','614.016736401673711','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:17:42
