-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-12-17 19:59:59','2018-12-17 23:59:59','ETCUSDT','4h','4.051200000000000','3.959400000000000','15.000000000000000','14.660100710900474','3.7026066350710902','3.702606635071090','test'),('2018-12-18 15:59:59','2018-12-25 03:59:59','ETCUSDT','4h','3.954100000000000','4.476900000000000','15.000000000000000','16.983257884221437','3.7935307655345087','3.793530765534509','test'),('2019-01-19 11:59:59','2019-01-19 15:59:59','ETCUSDT','4h','4.504100000000000','4.436000000000000','15.410839648780478','15.177834568946114','3.421513653955391','3.421513653955391','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','ETCUSDT','4h','4.348400000000000','4.314200000000000','15.410839648780478','15.289633983251019','3.54402530787887','3.544025307878870','test'),('2019-02-08 15:59:59','2019-02-10 07:59:59','ETCUSDT','4h','4.009800000000000','3.970500000000000','15.410839648780478','15.259798200778812','3.8432938422815295','3.843293842281529','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETCUSDT','4h','4.283800000000000','4.266400000000000','15.410839648780478','15.348243680273828','3.5974694544050787','3.597469454405079','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','ETCUSDT','4h','4.272700000000000','4.307300000000000','15.410839648780478','15.535635457484060','3.6068152804504123','3.606815280450412','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','ETCUSDT','4h','4.265000000000000','4.437500000000000','15.410839648780478','16.034138556028925','3.61332699854173','3.613326998541730','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','ETCUSDT','4h','4.279100000000000','4.270900000000000','15.455901287300451','15.426283285721647','3.6119514120493683','3.611951412049368','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','ETCUSDT','4h','4.309400000000000','4.230400000000000','15.455901287300451','15.172563420846483','3.5865552715692326','3.586555271569233','test'),('2019-03-12 23:59:59','2019-03-13 03:59:59','ETCUSDT','4h','4.270400000000000','4.263900000000000','15.455901287300451','15.432375772508520','3.6193099679890524','3.619309967989052','test'),('2019-03-14 15:59:59','2019-03-18 11:59:59','ETCUSDT','4h','4.285500000000000','4.347600000000000','15.455901287300451','15.679868495313837','3.606557294901517','3.606557294901517','test'),('2019-03-26 23:59:59','2019-03-30 19:59:59','ETCUSDT','4h','4.666300000000000','4.781700000000000','15.455901287300451','15.838133678821457','3.3122390946361038','3.312239094636104','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ETCUSDT','4h','6.206000000000000','6.241100000000000','15.523330841477874','15.611127959192324','2.50134238502705','2.501342385027050','test'),('2019-04-12 11:59:59','2019-04-13 11:59:59','ETCUSDT','4h','6.267600000000000','6.153600000000000','15.545280120906487','15.262530434617743','2.4802604060416247','2.480260406041625','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','ETCUSDT','4h','6.239300000000000','6.215900000000000','15.545280120906487','15.486978780238589','2.491510284952877','2.491510284952877','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','ETCUSDT','4h','6.317400000000000','6.209700000000000','15.545280120906487','15.280261811313673','2.460708538466218','2.460708538466218','test'),('2019-04-30 11:59:59','2019-04-30 15:59:59','ETCUSDT','4h','5.890600000000000','5.823900000000000','15.545280120906487','15.369258971267323','2.6389977457146108','2.638997745714611','test'),('2019-05-04 23:59:59','2019-05-05 03:59:59','ETCUSDT','4h','5.830600000000000','5.837900000000000','15.545280120906487','15.564743048372376','2.6661544473821714','2.666154447382171','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','ETCUSDT','4h','5.885200000000000','5.803700000000000','15.545280120906487','15.330004458252052','2.6414191736740444','2.641419173674044','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ETCUSDT','4h','5.896400000000000','5.789400000000000','15.545280120906487','15.263185118373247','2.636401892834015','2.636401892834015','test'),('2019-05-23 23:59:59','2019-05-24 07:59:59','ETCUSDT','4h','7.055200000000000','7.180100000000000','15.545280120906487','15.820482168630324','2.203379085058749','2.203379085058749','test'),('2019-06-08 03:59:59','2019-06-08 15:59:59','ETCUSDT','4h','8.575699999999999','8.363700000000000','15.545280120906487','15.160985032968224','1.8127126789540782','1.812712678954078','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ETCUSDT','4h','8.312400000000000','8.183999999999999','15.545280120906487','15.305155251130682','1.8701313845467598','1.870131384546760','test'),('2019-06-12 03:59:59','2019-06-12 07:59:59','ETCUSDT','4h','8.244100000000000','8.199900000000000','15.545280120906487','15.461935500954755','1.8856248857857725','1.885624885785772','test'),('2019-06-12 15:59:59','2019-06-14 07:59:59','ETCUSDT','4h','8.322900000000001','8.250299999999999','15.545280120906487','15.409679868977733','1.8677720651343264','1.867772065134326','test'),('2019-06-19 07:59:59','2019-06-19 11:59:59','ETCUSDT','4h','8.649400000000000','8.526400000000001','15.545280120906487','15.324216295106838','1.7972668764199236','1.797266876419924','test'),('2019-06-21 03:59:59','2019-06-26 23:59:59','ETCUSDT','4h','8.606999999999999','9.085599999999999','15.545280120906487','16.409689446556058','1.806120613559485','1.806120613559485','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','ETCUSDT','4h','8.072500000000000','8.012900000000000','15.545280120906487','15.430507907192517','1.9257082837914508','1.925708283791451','test'),('2019-07-22 03:59:59','2019-07-22 15:59:59','ETCUSDT','4h','6.462500000000000','6.234700000000000','15.545280120906487','14.997316513704552','2.405459206329824','2.405459206329824','test'),('2019-07-22 19:59:59','2019-07-23 03:59:59','ETCUSDT','4h','6.314600000000000','6.266200000000000','15.545280120906487','15.426129017455457','2.4617996580791317','2.461799658079132','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','ETCUSDT','4h','6.217600000000000','6.163600000000000','15.545280120906487','15.410269003026766','2.500205886661491','2.500205886661491','test'),('2019-08-04 15:59:59','2019-08-06 15:59:59','ETCUSDT','4h','6.093900000000000','5.956000000000000','15.545280120906487','15.193503076866874','2.5509575347325173','2.550957534732517','test'),('2019-08-08 11:59:59','2019-08-08 15:59:59','ETCUSDT','4h','6.066000000000000','5.980800000000000','15.545280120906487','15.326938896656367','2.562690425470901','2.562690425470901','test'),('2019-08-13 23:59:59','2019-08-14 15:59:59','ETCUSDT','4h','5.920400000000000','5.877300000000000','15.545280120906487','15.432111825992111','2.625714499173449','2.625714499173449','test'),('2019-08-20 07:59:59','2019-08-28 19:59:59','ETCUSDT','4h','5.935800000000000','6.375400000000000','15.545280120906487','16.696549560771459','2.6189022744881036','2.618902274488104','test'),('2019-09-02 11:59:59','2019-09-06 23:59:59','ETCUSDT','4h','6.559500000000000','6.656300000000000','15.545280120906487','15.774685276132304','2.3698879672088555','2.369887967208856','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','ETCUSDT','4h','6.683900000000000','6.636100000000000','15.545280120906487','15.434107842778547','2.325779877153531','2.325779877153531','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETCUSDT','4h','6.738600000000000','6.683500000000000','15.545280120906487','15.418169899990874','2.3069005610818993','2.306900561081899','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','ETCUSDT','4h','6.744100000000000','6.572000000000000','15.545280120906487','15.148586313162234','2.3050192198968706','2.305019219896871','test'),('2019-09-18 03:59:59','2019-09-18 11:59:59','ETCUSDT','4h','6.421500000000000','6.386400000000000','15.545280120906487','15.460309423679387','2.420817584817642','2.420817584817642','test'),('2019-10-09 15:59:59','2019-10-11 07:59:59','ETCUSDT','4h','4.838500000000000','4.772400000000000','15.545280120906487','15.332912028317480','3.212830447640072','3.212830447640072','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ETCUSDT','4h','4.776800000000000','4.740400000000000','15.545280120906487','15.426822534991024','3.2543292833919124','3.254329283391912','test'),('2019-10-14 07:59:59','2019-10-14 15:59:59','ETCUSDT','4h','4.784400000000000','4.759900000000000','15.545280120906487','15.465675705940722','3.249159794521045','3.249159794521045','test'),('2019-10-21 23:59:59','2019-10-22 11:59:59','ETCUSDT','4h','4.577500000000000','4.577100000000000','15.545280120906487','15.543921713031366','3.3960196878004343','3.396019687800434','test'),('2019-10-25 15:59:59','2019-10-26 11:59:59','ETCUSDT','4h','4.598300000000000','4.614500000000000','15.545280120906487','15.600046782054886','3.3806580955802117','3.380658095580212','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:30:53
