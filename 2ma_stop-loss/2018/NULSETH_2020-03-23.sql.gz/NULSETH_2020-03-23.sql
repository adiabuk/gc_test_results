-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 15:59:59','2018-04-26 23:59:59','NULSETH','4h','0.004693010000000','0.004596240000000','0.072144500000000','0.070656878353125','15.372756503821641','15.372756503821641','test'),('2018-05-09 11:59:59','2018-05-09 23:59:59','NULSETH','4h','0.005200000000000','0.005145440000000','0.072144500000000','0.071387537707692','13.873942307692309','13.873942307692309','test'),('2018-05-18 07:59:59','2018-05-19 07:59:59','NULSETH','4h','0.006166510000000','0.006141870000000','0.072144500000000','0.071856226652515','11.699405336243677','11.699405336243677','test'),('2018-05-20 19:59:59','2018-05-21 03:59:59','NULSETH','4h','0.006215670000000','0.005898390000000','0.072144500000000','0.068461870941508','11.606874238818984','11.606874238818984','test'),('2018-05-22 11:59:59','2018-05-23 15:59:59','NULSETH','4h','0.006229900000000','0.006118660000000','0.072144500000000','0.070856300481549','11.58036244562513','11.580362445625131','test'),('2018-05-24 23:59:59','2018-05-25 03:59:59','NULSETH','4h','0.006191970000000','0.005990000000000','0.072144500000000','0.069791286940990','11.651299990148532','11.651299990148532','test'),('2018-05-25 15:59:59','2018-05-25 23:59:59','NULSETH','4h','0.006326880000000','0.006390410000000','0.072144500000000','0.072868923425922','11.402855751966214','11.402855751966214','test'),('2018-05-29 11:59:59','2018-06-03 11:59:59','NULSETH','4h','0.006375310000000','0.006470950000000','0.072144500000000','0.073226784623022','11.316234034109714','11.316234034109714','test'),('2018-06-07 07:59:59','2018-06-07 11:59:59','NULSETH','4h','0.006440670000000','0.006239250000000','0.072144500000000','0.069888314666797','11.201396749095979','11.201396749095979','test'),('2018-06-10 19:59:59','2018-06-10 23:59:59','NULSETH','4h','0.006426690000000','0.006105280000000','0.072144500000000','0.068536427454880','11.225763184469766','11.225763184469766','test'),('2018-06-30 19:59:59','2018-07-01 03:59:59','NULSETH','4h','0.004829200000000','0.004745920000000','0.072144500000000','0.070900361434606','14.93922388801458','14.939223888014579','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','NULSETH','4h','0.004919210000000','0.005179440000000','0.072144500000000','0.075960999648318','14.665871145976691','14.665871145976691','test'),('2018-07-19 15:59:59','2018-07-20 03:59:59','NULSETH','4h','0.005600980000000','0.005480610000000','0.072144500000000','0.070594051066956','12.88069230741763','12.880692307417631','test'),('2018-07-22 19:59:59','2018-07-22 23:59:59','NULSETH','4h','0.005428440000000','0.005372420000000','0.072144500000000','0.071399988705779','13.290098076058685','13.290098076058685','test'),('2018-07-23 03:59:59','2018-07-23 11:59:59','NULSETH','4h','0.005817070000000','0.005659970000000','0.072144500000000','0.070196113449726','12.402205921537819','12.402205921537819','test'),('2018-07-24 15:59:59','2018-07-24 19:59:59','NULSETH','4h','0.005497020000000','0.005301610000000','0.072144500000000','0.069579881944217','13.124292798643628','13.124292798643628','test'),('2018-07-25 23:59:59','2018-07-26 07:59:59','NULSETH','4h','0.005447480000000','0.005480340000000','0.072144500000000','0.072579686227393','13.243646603567154','13.243646603567154','test'),('2018-07-27 07:59:59','2018-07-27 11:59:59','NULSETH','4h','0.005454000000000','0.005365960000000','0.072144500000000','0.070979923215988','13.227814448111479','13.227814448111479','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','NULSETH','4h','0.005450780000000','0.005408090000000','0.072144500000000','0.071579471012406','13.23562866231989','13.235628662319890','test'),('2018-07-28 15:59:59','2018-07-28 19:59:59','NULSETH','4h','0.005420000000000','0.005495040000000','0.072144500000000','0.073143341933579','13.310793357933578','13.310793357933578','test'),('2018-07-29 15:59:59','2018-07-30 11:59:59','NULSETH','4h','0.005433730000000','0.005413750000000','0.072144500000000','0.071879222352785','13.277159520255882','13.277159520255882','test'),('2018-08-12 11:59:59','2018-08-14 15:59:59','NULSETH','4h','0.004820970000000','0.004750010000000','0.072144500000000','0.071082602970979','14.964727015517624','14.964727015517624','test'),('2018-08-19 11:59:59','2018-08-20 03:59:59','NULSETH','4h','0.005013030000000','0.004926680000000','0.072144500000000','0.070901802953503','14.391396021966754','14.391396021966754','test'),('2018-08-22 07:59:59','2018-08-22 11:59:59','NULSETH','4h','0.005500000000000','0.005100000000000','0.072144500000000','0.066897627272727','13.11718181818182','13.117181818181820','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NULSETH','4h','0.005510620000000','0.005261580000000','0.072144500000000','0.068884092590307','13.091902544541268','13.091902544541268','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','NULSETH','4h','0.005313700000000','0.005266910000000','0.072144500000000','0.071509228690931','13.57707435496923','13.577074354969231','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','NULSETH','4h','0.005313700000000','0.005207080000000','0.072144500000000','0.070696912332273','13.57707435496923','13.577074354969231','test'),('2018-09-28 19:59:59','2018-09-29 11:59:59','NULSETH','4h','0.005349240000000','0.005160370000000','0.072144500000000','0.069597235021237','13.486869162722181','13.486869162722181','test'),('2018-10-03 03:59:59','2018-10-03 07:59:59','NULSETH','4h','0.005244420000000','0.005223650000000','0.072144500000000','0.071858778935516','13.756430644380123','13.756430644380123','test'),('2018-10-03 15:59:59','2018-10-03 19:59:59','NULSETH','4h','0.005223930000000','0.005269350000000','0.072144500000000','0.072771767821353','13.810387964616679','13.810387964616679','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','NULSETH','4h','0.005248830000000','0.005349240000000','0.072144500000000','0.073524622664480','13.744872666860996','13.744872666860996','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','NULSETH','4h','0.005259200000000','0.005208070000000','0.072144500000000','0.071443110380856','13.717770763614237','13.717770763614237','test'),('2018-10-07 23:59:59','2018-10-08 03:59:59','NULSETH','4h','0.005293110000000','0.005234310000000','0.072144500000000','0.071343062546405','13.629888666587318','13.629888666587318','test'),('2018-10-15 19:59:59','2018-10-16 07:59:59','NULSETH','4h','0.005545040000000','0.005438790000000','0.072144500000000','0.070762119868387','13.01063653282934','13.010636532829340','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','NULSETH','4h','0.005468110000000','0.005443170000000','0.072144500000000','0.071815449591358','13.193681180517583','13.193681180517583','test'),('2018-10-16 23:59:59','2018-10-17 03:59:59','NULSETH','4h','0.005489750000000','0.005454300000000','0.072144500000000','0.071678627687964','13.141673118083702','13.141673118083702','test'),('2018-10-17 07:59:59','2018-10-18 23:59:59','NULSETH','4h','0.005495130000000','0.005505400000000','0.072144500000000','0.072279332845629','13.128806779821405','13.128806779821405','test'),('2018-10-26 15:59:59','2018-10-26 23:59:59','NULSETH','4h','0.005620000000000','0.005612570000000','0.072144500000000','0.072049120349644','12.837099644128115','12.837099644128115','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','NULSETH','4h','0.005749460000000','0.005537060000000','0.072144500000000','0.069479294606798','12.5480479905939','12.548047990593901','test'),('2018-11-23 15:59:59','2018-11-23 23:59:59','NULSETH','4h','0.004732710000000','0.004607390000000','0.072144500000000','0.070234146578810','15.243803233242687','15.243803233242687','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','NULSETH','4h','0.004447470000000','0.004335090000000','0.072144500000000','0.070321531231239','16.22146973447825','16.221469734478251','test'),('2018-11-29 03:59:59','2018-11-29 07:59:59','NULSETH','4h','0.004442610000000','0.004469570000000','0.072144500000000','0.072582309242765','16.239215236088697','16.239215236088697','test'),('2018-12-01 03:59:59','2018-12-01 07:59:59','NULSETH','4h','0.004427000000000','0.004488580000000','0.072144500000000','0.073148037002485','16.296476168963178','16.296476168963178','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','NULSETH','4h','0.004455920000000','0.004408000000000','0.072144500000000','0.071368641268245','16.19070809170721','16.190708091707211','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','NULSETH','4h','0.004579790000000','0.004495150000000','0.072144500000000','0.070811183302073','15.752796525604886','15.752796525604886','test'),('2018-12-11 19:59:59','2018-12-11 23:59:59','NULSETH','4h','0.004427090000000','0.004449130000000','0.072144500000000','0.072503667032972','16.296144871687723','16.296144871687723','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','NULSETH','4h','0.003000000000000','0.002915530000000','0.072144500000000','0.070113151361667','24.048166666666667','24.048166666666667','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','NULSETH','4h','0.002962680000000','0.002901590000000','0.072144500000000','0.070656891650465','24.35109427950369','24.351094279503691','test'),('2019-01-11 15:59:59','2019-01-14 15:59:59','NULSETH','4h','0.003000000000000','0.003000090000000','0.072144500000000','0.072146664335000','24.048166666666667','24.048166666666667','test'),('2019-01-15 19:59:59','2019-01-26 15:59:59','NULSETH','4h','0.003055700000000','0.004014520000000','0.072144500000000','0.094782059148477','23.60981117256275','23.609811172562750','test'),('2019-02-01 19:59:59','2019-02-02 03:59:59','NULSETH','4h','0.003804500000000','0.003759510000000','0.072144500000000','0.071291357391247','18.96293862531213','18.962938625312130','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','NULSETH','4h','0.003088870000000','0.003079630000000','0.072144500000000','0.071928688010502','23.35627591967289','23.356275919672889','test'),('2019-02-28 19:59:59','2019-03-01 19:59:59','NULSETH','4h','0.003081690000000','0.003087340000000','0.072144500000000','0.072276770418180','23.41069348312127','23.410693483121271','test'),('2019-03-06 15:59:59','2019-03-06 19:59:59','NULSETH','4h','0.003171020000000','0.003138760000000','0.072144500000000','0.071410546392013','22.751196775800846','22.751196775800846','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','NULSETH','4h','0.003149990000000','0.003158570000000','0.072144500000000','0.072341008500027','22.90308858123359','22.903088581233590','test'),('2019-04-15 07:59:59','2019-04-15 23:59:59','NULSETH','4h','0.005302640000000','0.005274420000000','0.072144500000000','0.071760555815594','13.60539278548044','13.605392785480440','test'),('2019-04-17 03:59:59','2019-04-17 11:59:59','NULSETH','4h','0.005312600000000','0.005192210000000','0.072144500000000','0.070509617578022','13.579885555095434','13.579885555095434','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','NULSETH','4h','0.005218180000000','0.005123170000000','0.072144500000000','0.070830929186996','13.825605862580439','13.825605862580439','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','NULSETH','4h','0.005202090000000','0.005074600000000','0.072144500000000','0.070376421726652','13.868368290437111','13.868368290437111','test'),('2019-04-23 07:59:59','2019-04-24 07:59:59','NULSETH','4h','0.005217480000000','0.005087380000000','0.072144500000000','0.070345547354278','13.827460766500304','13.827460766500304','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:47:51
