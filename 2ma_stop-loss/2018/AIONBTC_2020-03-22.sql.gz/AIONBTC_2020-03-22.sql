-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 11:59:59','2018-07-02 19:59:59','AIONBTC','4h','0.000176800000000','0.000174700000000','0.001467500000000','0.001450069287330','8.300339366515837','8.300339366515837','test'),('2018-07-03 03:59:59','2018-07-03 07:59:59','AIONBTC','4h','0.000179400000000','0.000175900000000','0.001467500000000','0.001438869843924','8.180044593088072','8.180044593088072','test'),('2018-07-05 07:59:59','2018-07-05 15:59:59','AIONBTC','4h','0.000176800000000','0.000171500000000','0.001467500000000','0.001423508201357','8.300339366515837','8.300339366515837','test'),('2018-07-16 11:59:59','2018-07-17 15:59:59','AIONBTC','4h','0.000156500000000','0.000154000000000','0.001467500000000','0.001444057507987','9.37699680511182','9.376996805111821','test'),('2018-07-18 03:59:59','2018-07-18 11:59:59','AIONBTC','4h','0.000157900000000','0.000152500000000','0.001467500000000','0.001417313172894','9.293856871437619','9.293856871437619','test'),('2018-08-17 11:59:59','2018-08-18 19:59:59','AIONBTC','4h','0.000072900000000','0.000075900000000','0.001467500000000','0.001527890946502','20.130315500685874','20.130315500685874','test'),('2018-08-21 03:59:59','2018-08-21 07:59:59','AIONBTC','4h','0.000075500000000','0.000078000000000','0.001467500000000','0.001516092715232','19.43708609271523','19.437086092715230','test'),('2018-08-23 19:59:59','2018-08-23 23:59:59','AIONBTC','4h','0.000074300000000','0.000074900000000','0.001467500000000','0.001479350605653','19.75100942126514','19.751009421265142','test'),('2018-08-24 07:59:59','2018-08-30 03:59:59','AIONBTC','4h','0.000079600000000','0.000085800000000','0.001467500000000','0.001581802763819','18.435929648241206','18.435929648241206','test'),('2018-08-31 03:59:59','2018-08-31 07:59:59','AIONBTC','4h','0.000087300000000','0.000088600000000','0.001485363761175','0.001507482580070','17.01447607301833','17.014476073018329','test'),('2018-09-01 11:59:59','2018-09-01 23:59:59','AIONBTC','4h','0.000088700000000','0.000086900000000','0.001490893465898','0.001460638581584','16.80826906311443','16.808269063114430','test'),('2018-09-17 03:59:59','2018-09-17 11:59:59','AIONBTC','4h','0.000069900000000','0.000069100000000','0.001490893465898','0.001473830307490','21.32894800998569','21.328948009985691','test'),('2018-09-20 15:59:59','2018-09-21 11:59:59','AIONBTC','4h','0.000068900000000','0.000069200000000','0.001490893465898','0.001497385019451','21.638511841770683','21.638511841770683','test'),('2018-09-23 03:59:59','2018-09-23 07:59:59','AIONBTC','4h','0.000068800000000','0.000069000000000','0.001490893465898','0.001495227458531','21.66996316712209','21.669963167122091','test'),('2018-10-02 07:59:59','2018-10-02 15:59:59','AIONBTC','4h','0.000066200000000','0.000064200000000','0.001490893465898','0.001445851367230','22.521049333806648','22.521049333806648','test'),('2018-10-04 19:59:59','2018-10-04 23:59:59','AIONBTC','4h','0.000065200000000','0.000064400000000','0.001490893465898','0.001472600294537','22.86646420088957','22.866464200889570','test'),('2018-10-05 03:59:59','2018-10-05 11:59:59','AIONBTC','4h','0.000065500000000','0.000065400000000','0.001490893465898','0.001488617292668','22.761732303786257','22.761732303786257','test'),('2018-10-08 11:59:59','2018-10-08 15:59:59','AIONBTC','4h','0.000066200000000','0.000065900000000','0.001490893465898','0.001484137151098','22.521049333806648','22.521049333806648','test'),('2018-10-13 15:59:59','2018-10-14 23:59:59','AIONBTC','4h','0.000069500000000','0.000068600000000','0.001490893465898','0.001471586931807','21.451704545294966','21.451704545294966','test'),('2018-10-15 11:59:59','2018-10-16 11:59:59','AIONBTC','4h','0.000067300000000','0.000066300000000','0.001490893465898','0.001468740516925','22.15294897322437','22.152948973224369','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','AIONBTC','4h','0.000066800000000','0.000067200000000','0.001490893465898','0.001499820971682','22.3187644595509','22.318764459550898','test'),('2018-10-19 23:59:59','2018-10-20 03:59:59','AIONBTC','4h','0.000067200000000','0.000066300000000','0.001490893465898','0.001470926142694','22.18591467110119','22.185914671101191','test'),('2018-10-20 07:59:59','2018-10-20 11:59:59','AIONBTC','4h','0.000066900000000','0.000066400000000','0.001490893465898','0.001479750764359','22.285403077698057','22.285403077698057','test'),('2018-10-26 03:59:59','2018-10-26 07:59:59','AIONBTC','4h','0.000068000000000','0.000066900000000','0.001490893465898','0.001466776071597','21.924903910264707','21.924903910264707','test'),('2018-11-01 15:59:59','2018-11-02 07:59:59','AIONBTC','4h','0.000066400000000','0.000066000000000','0.001490893465898','0.001481912179959','22.453214847861446','22.453214847861446','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','AIONBTC','4h','0.000040900000000','0.000038700000000','0.001490893465898','0.001410698707341','36.4521629803912','36.452162980391201','test'),('2018-11-29 23:59:59','2018-11-30 03:59:59','AIONBTC','4h','0.000040000000000','0.000038500000000','0.001490893465898','0.001434984960927','37.27233664745','37.272336647449997','test'),('2018-11-30 07:59:59','2018-11-30 11:59:59','AIONBTC','4h','0.000040000000000','0.000036000000000','0.001490893465898','0.001341804119308','37.27233664745','37.272336647449997','test'),('2018-12-01 11:59:59','2018-12-01 19:59:59','AIONBTC','4h','0.000039900000000','0.000039600000000','0.001490893465898','0.001479683740590','37.36575102501253','37.365751025012528','test'),('2018-12-04 15:59:59','2018-12-05 19:59:59','AIONBTC','4h','0.000040500000000','0.000039700000000','0.001490893465898','0.001461443718423','36.81218434316049','36.812184343160489','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','AIONBTC','4h','0.000035800000000','0.000035400000000','0.001490893465898','0.001474235438346','41.6450688798324','41.645068879832401','test'),('2018-12-19 15:59:59','2018-12-25 15:59:59','AIONBTC','4h','0.000035900000000','0.000040700000000','0.001490893465898','0.001690232982230','41.52906590245125','41.529065902451251','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','AIONBTC','4h','0.000040700000000','0.000039600000000','0.001490893465898','0.001450599047901','36.631289088402944','36.631289088402944','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','AIONBTC','4h','0.000040000000000','0.000039600000000','0.001490893465898','0.001475984531239','37.27233664745','37.272336647449997','test'),('2019-01-01 23:59:59','2019-01-02 03:59:59','AIONBTC','4h','0.000040100000000','0.000039800000000','0.001490893465898','0.001479739649445','37.17938817700748','37.179388177007482','test'),('2019-01-03 07:59:59','2019-01-03 11:59:59','AIONBTC','4h','0.000039500000000','0.000039300000000','0.001490893465898','0.001483344638223','37.74413837716456','37.744138377164560','test'),('2019-01-03 15:59:59','2019-01-03 19:59:59','AIONBTC','4h','0.000039500000000','0.000038900000000','0.001490893465898','0.001468246982872','37.74413837716456','37.744138377164560','test'),('2019-01-04 07:59:59','2019-01-04 15:59:59','AIONBTC','4h','0.000039900000000','0.000039000000000','0.001490893465898','0.001457264289975','37.36575102501253','37.365751025012528','test'),('2019-01-05 07:59:59','2019-01-05 11:59:59','AIONBTC','4h','0.000039500000000','0.000039900000000','0.001490893465898','0.001505991121249','37.74413837716456','37.744138377164560','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','AIONBTC','4h','0.000041200000000','0.000040300000000','0.001490893465898','0.001458325404750','36.186734609174756','36.186734609174756','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','AIONBTC','4h','0.000040100000000','0.000039800000000','0.001490893465898','0.001479739649445','37.17938817700748','37.179388177007482','test'),('2019-01-17 07:59:59','2019-01-17 11:59:59','AIONBTC','4h','0.000036900000000','0.000036200000000','0.001490893465898','0.001462610934025','40.403616962005415','40.403616962005415','test'),('2019-01-17 19:59:59','2019-01-18 07:59:59','AIONBTC','4h','0.000037300000000','0.000036700000000','0.001490893465898','0.001466911265374','39.9703342063807','39.970334206380699','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','AIONBTC','4h','0.000037600000000','0.000037100000000','0.001490893465898','0.001471067754915','39.65142196537234','39.651421965372343','test'),('2019-01-22 15:59:59','2019-01-23 07:59:59','AIONBTC','4h','0.000037400000000','0.000037400000000','0.001490893465898','0.001490893465898','39.86346165502673','39.863461655026732','test'),('2019-01-24 11:59:59','2019-01-24 19:59:59','AIONBTC','4h','0.000037700000000','0.000037600000000','0.001490893465898','0.001486938841320','39.546245779787796','39.546245779787796','test'),('2019-02-08 23:59:59','2019-02-09 03:59:59','AIONBTC','4h','0.000033700000000','0.000031900000000','0.001490893465898','0.001411261173951','44.24016219281899','44.240162192818993','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','AIONBTC','4h','0.000033200000000','0.000033100000000','0.001490893465898','0.001486402822928','44.90642969572289','44.906429695722892','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','AIONBTC','4h','0.000030300000000','0.000029700000000','0.001490893465898','0.001461370823009','49.20440481511551','49.204404815115510','test'),('2019-02-27 07:59:59','2019-02-27 15:59:59','AIONBTC','4h','0.000030800000000','0.000029600000000','0.001490893465898','0.001432806707486','48.405632009675315','48.405632009675315','test'),('2019-03-01 03:59:59','2019-03-01 15:59:59','AIONBTC','4h','0.000030700000000','0.000030200000000','0.001490893465898','0.001466611813359','48.563305078110744','48.563305078110744','test'),('2019-03-05 15:59:59','2019-03-05 19:59:59','AIONBTC','4h','0.000030200000000','0.000030200000000','0.001490893465898','0.001490893465898','49.36733330788079','49.367333307880791','test'),('2019-03-07 19:59:59','2019-03-14 15:59:59','AIONBTC','4h','0.000030600000000','0.000035400000000','0.001490893465898','0.001724759107607','48.72200868947713','48.722008689477128','test'),('2019-03-19 19:59:59','2019-03-21 15:59:59','AIONBTC','4h','0.000035400000000','0.000033900000000','0.001490893465898','0.001427720013953','42.115634629887005','42.115634629887005','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','AIONBTC','4h','0.000035200000000','0.000035000000000','0.001490893465898','0.001482422480296','42.354928008465905','42.354928008465905','test'),('2019-03-27 11:59:59','2019-04-02 07:59:59','AIONBTC','4h','0.000035700000000','0.000039000000000','0.001490893465898','0.001628707147620','41.76172173383753','41.761721733837533','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','AIONBTC','4h','0.000042100000000','0.000040300000000','0.001490893465898','0.001427149802273','35.413146458384794','35.413146458384794','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','AIONBTC','4h','0.000037800000000','0.000037300000000','0.001490893465898','0.001471172652857','39.44162608195767','39.441626081957672','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','AIONBTC','4h','0.000037400000000','0.000036600000000','0.001490893465898','0.001459002696574','39.86346165502673','39.863461655026732','test'),('2019-04-27 23:59:59','2019-04-28 03:59:59','AIONBTC','4h','0.000034600000000','0.000034400000000','0.001490893465898','0.001482275584592','43.08940652884393','43.089406528843931','test'),('2019-05-03 19:59:59','2019-05-04 03:59:59','AIONBTC','4h','0.000035300000000','0.000034500000000','0.001490893465898','0.001457105511997','42.23494237671388','42.234942376713882','test'),('2019-05-16 07:59:59','2019-05-16 11:59:59','AIONBTC','4h','0.000030000000000','0.000029400000000','0.001490893465898','0.001461075596580','49.69644886326666','49.696448863266660','test'),('2019-05-31 19:59:59','2019-06-01 03:59:59','AIONBTC','4h','0.000026500000000','0.000025500000000','0.001490893465898','0.001434633335109','56.26013078860377','56.260130788603767','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','AIONBTC','4h','0.000025200000000','0.000025000000000','0.001490893465898','0.001479060978073','59.162439122936505','59.162439122936505','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:15:06
