-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-14 23:59:59','ZECETH','4h','0.443370000000000','0.428290000000000','0.072144500000000','0.069690705065746','0.16271849696641633','0.162718496966416','test'),('2018-06-14 15:59:59','2018-06-14 19:59:59','ZECETH','4h','0.409580000000000','0.382680000000000','0.072144500000000','0.067406263147615','0.17614263391767176','0.176142633917672','test'),('2018-06-25 19:59:59','2018-06-26 15:59:59','ZECETH','4h','0.380580000000000','0.374500000000000','0.072144500000000','0.070991947159599','0.18956461190814022','0.189564611908140','test'),('2018-06-29 15:59:59','2018-06-29 23:59:59','ZECETH','4h','0.374550000000000','0.374810000000000','0.072144500000000','0.072194580283006','0.1926164731010546','0.192616473101055','test'),('2018-07-02 11:59:59','2018-07-05 19:59:59','ZECETH','4h','0.380170000000000','0.376390000000000','0.072144500000000','0.071427172988400','0.18976905068785016','0.189769050687850','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','ZECETH','4h','0.406500000000000','0.394650000000000','0.072144500000000','0.070041394649447','0.17747724477244775','0.177477244772448','test'),('2018-07-21 15:59:59','2018-07-22 07:59:59','ZECETH','4h','0.407500000000000','0.406650000000000','0.072144500000000','0.071994014539877','0.17704171779141106','0.177041717791411','test'),('2018-08-07 07:59:59','2018-08-08 19:59:59','ZECETH','4h','0.451350000000000','0.447650000000000','0.072144500000000','0.071553086130497','0.15984158635205495','0.159841586352055','test'),('2018-08-16 11:59:59','2018-08-17 03:59:59','ZECETH','4h','0.477690000000000','0.480080000000000','0.072144500000000','0.072505456593188','0.15102786325859868','0.151027863258599','test'),('2018-08-18 15:59:59','2018-08-18 23:59:59','ZECETH','4h','0.485000000000000','0.483430000000000','0.072144500000000','0.071910960072165','0.1487515463917526','0.148751546391753','test'),('2018-08-21 19:59:59','2018-08-21 23:59:59','ZECETH','4h','0.483050000000000','0.480000000000000','0.072144500000000','0.071688976296450','0.14935203395093677','0.149352033950937','test'),('2018-08-23 15:59:59','2018-08-23 19:59:59','ZECETH','4h','0.480770000000000','0.476380000000000','0.072144500000000','0.071485735195624','0.15006031990348817','0.150060319903488','test'),('2018-08-24 15:59:59','2018-08-24 19:59:59','ZECETH','4h','0.478150000000000','0.495300000000000','0.072144500000000','0.074732136045174','0.15088256823172644','0.150882568231726','test'),('2018-09-24 15:59:59','2018-09-29 11:59:59','ZECETH','4h','0.593850000000000','0.581990000000000','0.072144500000000','0.070703675263114','0.1214860655047571','0.121486065504757','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','ZECETH','4h','0.583880000000000','0.571000000000000','0.072144500000000','0.070553040864561','0.12356049188189355','0.123560491881894','test'),('2018-10-11 07:59:59','2018-10-11 11:59:59','ZECETH','4h','0.563020000000000','0.562730000000000','0.072144500000000','0.072107339854712','0.12813843202728145','0.128138432027281','test'),('2018-10-11 19:59:59','2018-10-12 03:59:59','ZECETH','4h','0.565780000000000','0.559300000000000','0.072144500000000','0.071318213528227','0.1275133444094878','0.127513344409488','test'),('2018-10-17 15:59:59','2018-10-26 15:59:59','ZECETH','4h','0.558070000000000','0.593820000000000','0.072144500000000','0.076766081298045','0.12927500134391745','0.129275001343917','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','ZECETH','4h','0.597280000000000','0.598900000000000','0.072144500000000','0.072340177220064','0.12078840744709349','0.120788407447093','test'),('2018-11-06 11:59:59','2018-11-06 15:59:59','ZECETH','4h','0.590370000000000','0.597630000000000','0.072144500000000','0.073031687814421','0.12220217829496757','0.122202178294968','test'),('2018-11-07 19:59:59','2018-11-11 23:59:59','ZECETH','4h','0.593330000000000','0.613640000000000','0.072144500000000','0.074614044427216','0.12159253703672492','0.121592537036725','test'),('2018-11-12 19:59:59','2018-11-12 23:59:59','ZECETH','4h','0.645230000000000','0.637570000000000','0.072144500000000','0.071288019566666','0.11181206701486292','0.111812067014863','test'),('2018-11-16 03:59:59','2018-11-16 07:59:59','ZECETH','4h','0.615810000000000','0.608420000000000','0.072144500000000','0.071278733196928','0.11715382991507121','0.117153829915071','test'),('2018-11-16 11:59:59','2018-11-16 15:59:59','ZECETH','4h','0.610610000000000','0.620000000000000','0.072144500000000','0.073253942778533','0.118151520610537','0.118151520610537','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','ZECETH','4h','0.614350000000000','0.614930000000000','0.072144500000000','0.072212610702368','0.11743224546268415','0.117432245462684','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','ZECETH','4h','0.631950000000000','0.619280000000000','0.072144500000000','0.070698070986629','0.11416172165519424','0.114161721655194','test'),('2018-11-23 19:59:59','2018-11-23 23:59:59','ZECETH','4h','0.630380000000000','0.628860000000000','0.072144500000000','0.071970542006409','0.11444604841524159','0.114446048415242','test'),('2018-11-26 11:59:59','2018-11-26 15:59:59','ZECETH','4h','0.628150000000000','0.618200000000000','0.072144500000000','0.071001719175356','0.11485234418530606','0.114852344185306','test'),('2018-11-27 11:59:59','2018-12-03 15:59:59','ZECETH','4h','0.628340000000000','0.650550000000000','0.072144500000000','0.074694599221759','0.11481761466721839','0.114817614667218','test'),('2018-12-04 11:59:59','2018-12-04 19:59:59','ZECETH','4h','0.685580000000000','0.672450000000000','0.072144500000000','0.070762812545582','0.10523133697015666','0.105231336970157','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','ZECETH','4h','0.418200000000000','0.410500000000000','0.072144500000000','0.070816157938785','0.17251195600191296','0.172511956001913','test'),('2019-01-10 19:59:59','2019-01-13 19:59:59','ZECETH','4h','0.425010000000000','0.457000000000000','0.072144500000000','0.077574731182796','0.1697477706406908','0.169747770640691','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ZECETH','4h','0.431600000000000','0.425750000000000','0.072144500000000','0.071166637801205','0.16715593141797963','0.167155931417980','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','ZECETH','4h','0.441540000000000','0.441160000000000','0.072144500000000','0.072082410698917','0.1633928975857227','0.163392897585723','test'),('2019-02-02 15:59:59','2019-02-02 19:59:59','ZECETH','4h','0.454610000000000','0.453240000000000','0.072144500000000','0.071927087349596','0.15869536525813335','0.158695365258133','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','ZECETH','4h','0.444500000000000','0.434910000000000','0.072144500000000','0.070587996614173','0.16230483689538808','0.162304836895388','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZECETH','4h','0.384990000000000','0.381550000000000','0.072144500000000','0.071499867464090','0.18739317904361152','0.187393179043612','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','ZECETH','4h','0.384980000000000','0.374510000000000','0.072144500000000','0.070182442451556','0.18739804665177412','0.187398046651774','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','ZECETH','4h','0.382100000000000','0.384620000000000','0.072144500000000','0.072620302512431','0.18881052080607172','0.188810520806072','test'),('2019-03-02 15:59:59','2019-03-03 03:59:59','ZECETH','4h','0.386190000000000','0.382240000000000','0.072144500000000','0.071406596960046','0.18681089619099409','0.186810896190994','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','ZECETH','4h','0.374370000000000','0.374500000000000','0.072144500000000','0.072169552180997','0.19270908459545372','0.192709084595454','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','ZECETH','4h','0.373820000000000','0.383790000000000','0.072144500000000','0.074068636389171','0.19299261676742818','0.192992616767428','test'),('2019-03-26 23:59:59','2019-03-27 03:59:59','ZECETH','4h','0.405840000000000','0.402530000000000','0.072144500000000','0.071556094975853','0.17776586832249164','0.177765868322492','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','ZECETH','4h','0.404390000000000','0.402360000000000','0.072144500000000','0.071782341353644','0.17840327406711343','0.178403274067113','test'),('2019-03-28 19:59:59','2019-03-29 03:59:59','ZECETH','4h','0.408040000000000','0.403070000000000','0.072144500000000','0.071265767118420','0.176807420841094','0.176807420841094','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','ZECETH','4h','0.407410000000000','0.398420000000000','0.072144500000000','0.070552543359270','0.1770808276674603','0.177080827667460','test'),('2019-03-31 03:59:59','2019-04-04 11:59:59','ZECETH','4h','0.405430000000000','0.418580000000000','0.072144500000000','0.074484485139235','0.17794563796463014','0.177945637964630','test'),('2019-04-11 19:59:59','2019-04-14 07:59:59','ZECETH','4h','0.423700000000000','0.417070000000000','0.072144500000000','0.071015592671702','0.1702725985367005','0.170272598536700','test'),('2019-04-15 23:59:59','2019-04-16 03:59:59','ZECETH','4h','0.421650000000000','0.417700000000000','0.072144500000000','0.071468653266928','0.17110043875251985','0.171100438752520','test'),('2019-04-17 23:59:59','2019-04-18 03:59:59','ZECETH','4h','0.424490000000000','0.415650000000000','0.072144500000000','0.070642091509812','0.16995571155975406','0.169955711559754','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:37:03
