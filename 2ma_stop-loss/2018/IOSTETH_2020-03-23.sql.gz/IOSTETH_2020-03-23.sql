-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-17 19:59:59','2018-07-20 19:59:59','IOSTETH','4h','0.000050600000000','0.000049370000000','0.072144500000000','0.070390789822134','1425.7806324110672','1425.780632411067245','test'),('2018-07-21 15:59:59','2018-07-21 23:59:59','IOSTETH','4h','0.000051440000000','0.000050770000000','0.072144500000000','0.071204826302488','1402.4980559875582','1402.498055987558246','test'),('2018-07-24 07:59:59','2018-07-24 11:59:59','IOSTETH','4h','0.000051130000000','0.000050020000000','0.072144500000000','0.070578288480344','1411.0013690592607','1411.001369059260696','test'),('2018-07-24 15:59:59','2018-07-25 11:59:59','IOSTETH','4h','0.000051660000000','0.000066330000000','0.072144500000000','0.092631527003484','1396.525358110724','1396.525358110724028','test'),('2018-08-17 11:59:59','2018-08-17 15:59:59','IOSTETH','4h','0.000045720000000','0.000048040000000','0.076201357902112','0.080068093473698','1666.696367062828','1666.696367062827903','test'),('2018-09-06 19:59:59','2018-09-07 07:59:59','IOSTETH','4h','0.000054760000000','0.000054510000000','0.077168041795009','0.076815740654601','1409.204561632743','1409.204561632742980','test'),('2018-09-07 15:59:59','2018-09-13 15:59:59','IOSTETH','4h','0.000055700000000','0.000058330000000','0.077168041795009','0.080811703373481','1385.4226534112927','1385.422653411292686','test'),('2018-09-17 19:59:59','2018-09-18 03:59:59','IOSTETH','4h','0.000058600000000','0.000057550000000','0.077990881904525','0.076593434361867','1330.902421578925','1330.902421578924987','test'),('2018-09-19 23:59:59','2018-09-20 03:59:59','IOSTETH','4h','0.000057500000000','0.000057200000000','0.077990881904525','0.077583972955458','1356.3631635569564','1356.363163556956351','test'),('2018-09-25 03:59:59','2018-09-27 03:59:59','IOSTETH','4h','0.000058880000000','0.000057530000000','0.077990881904525','0.076202707811945','1324.5734019110903','1324.573401911090286','test'),('2018-10-01 19:59:59','2018-10-04 15:59:59','IOSTETH','4h','0.000056160000000','0.000057500000000','0.077990881904525','0.079851775454241','1388.7265296389778','1388.726529638977809','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','IOSTETH','4h','0.000056940000000','0.000058070000000','0.077990881904525','0.079538646157284','1369.702878548033','1369.702878548032913','test'),('2018-10-09 15:59:59','2018-10-09 19:59:59','IOSTETH','4h','0.000056950000000','0.000057200000000','0.077990881904525','0.078333247496731','1369.4623688239683','1369.462368823968291','test'),('2018-10-10 11:59:59','2018-10-11 07:59:59','IOSTETH','4h','0.000057190000000','0.000057460000000','0.078030505107119','0.078398895321823','1364.4082026074316','1364.408202607431576','test'),('2018-10-12 03:59:59','2018-10-12 07:59:59','IOSTETH','4h','0.000058320000000','0.000057500000000','0.078122602660795','0.077024171004728','1339.5508000822192','1339.550800082219212','test'),('2018-10-13 11:59:59','2018-10-13 15:59:59','IOSTETH','4h','0.000057550000000','0.000057080000000','0.078122602660795','0.077484590093452','1357.4735475377063','1357.473547537706281','test'),('2018-10-14 07:59:59','2018-10-15 03:59:59','IOSTETH','4h','0.000057940000000','0.000057400000000','0.078122602660795','0.077394501082665','1348.3362557955645','1348.336255795564512','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','IOSTETH','4h','0.000057700000000','0.000057240000000','0.078122602660795','0.077499788150848','1353.944586842201','1353.944586842201034','test'),('2018-10-16 11:59:59','2018-10-16 15:59:59','IOSTETH','4h','0.000057360000000','0.000057790000000','0.078122602660795','0.078708249786739','1361.970060334641','1361.970060334640948','test'),('2018-10-28 11:59:59','2018-10-28 15:59:59','IOSTETH','4h','0.000060110000000','0.000061500000000','0.078122602660795','0.079929130987172','1299.660666458077','1299.660666458077003','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','IOSTETH','4h','0.000044550000000','0.000043800000000','0.078122602660795','0.076807407329805','1753.5937746530865','1753.593774653086484','test'),('2018-12-02 15:59:59','2018-12-02 19:59:59','IOSTETH','4h','0.000043690000000','0.000043340000000','0.078122602660795','0.077496763545865','1788.1117569419778','1788.111756941977774','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','IOSTETH','4h','0.000043850000000','0.000042650000000','0.078122602660795','0.075984697912951','1781.5872898698974','1781.587289869897404','test'),('2018-12-05 11:59:59','2018-12-05 15:59:59','IOSTETH','4h','0.000043620000000','0.000044150000000','0.078122602660795','0.079071822729805','1790.9812622832417','1790.981262283241676','test'),('2018-12-08 15:59:59','2018-12-08 19:59:59','IOSTETH','4h','0.000044680000000','0.000044440000000','0.078122602660795','0.077702964687684','1748.4915546283573','1748.491554628357335','test'),('2018-12-10 11:59:59','2018-12-10 23:59:59','IOSTETH','4h','0.000044630000000','0.000044730000000','0.078122602660795','0.078297647703728','1750.4504293254538','1750.450429325453797','test'),('2018-12-13 19:59:59','2018-12-14 03:59:59','IOSTETH','4h','0.000044400000000','0.000043900000000','0.078122602660795','0.077242843621822','1759.5180779458333','1759.518077945833284','test'),('2018-12-14 15:59:59','2018-12-14 19:59:59','IOSTETH','4h','0.000044200000000','0.000043050000000','0.078122602660795','0.076090001007856','1767.4796982080318','1767.479698208031778','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','IOSTETH','4h','0.000044190000000','0.000044100000000','0.078122602660795','0.077963493490406','1767.8796709842725','1767.879670984272479','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','IOSTETH','4h','0.000045630000000','0.000044260000000','0.078122602660795','0.075777041283515','1712.0885965547884','1712.088596554788410','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','IOSTETH','4h','0.000046360000000','0.000045670000000','0.078122602660795','0.076959863320071','1685.1294793096417','1685.129479309641738','test'),('2018-12-21 15:59:59','2018-12-22 15:59:59','IOSTETH','4h','0.000048880000000','0.000047700000000','0.078122602660795','0.076236664216856','1598.252918592369','1598.252918592369042','test'),('2018-12-30 23:59:59','2018-12-31 03:59:59','IOSTETH','4h','0.000040590000000','0.000043510000000','0.078122602660795','0.083742656855659','1924.6760941314362','1924.676094131436230','test'),('2019-01-06 19:59:59','2019-01-07 03:59:59','IOSTETH','4h','0.000039560000000','0.000039210000000','0.078122602660795','0.077431426954747','1974.7877315671133','1974.787731567113269','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','IOSTETH','4h','0.000054290000000','0.000053930000000','0.078122602660795','0.077604567351200','1438.9869710958742','1438.986971095874196','test'),('2019-01-29 15:59:59','2019-01-30 19:59:59','IOSTETH','4h','0.000054400000000','0.000053780000000','0.078122602660795','0.077232234762823','1436.0772547940257','1436.077254794025748','test'),('2019-02-02 11:59:59','2019-02-02 15:59:59','IOSTETH','4h','0.000053650000000','0.000053410000000','0.078122602660795','0.077773125966693','1456.1528920931034','1456.152892093103446','test'),('2019-02-03 03:59:59','2019-02-08 19:59:59','IOSTETH','4h','0.000055000000000','0.000054790000000','0.078122602660795','0.077824316359727','1420.4109574689999','1420.410957468999868','test'),('2019-02-11 15:59:59','2019-02-11 23:59:59','IOSTETH','4h','0.000056800000000','0.000056220000000','0.078122602660795','0.077324871858977','1375.3979341689262','1375.397934168926213','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','IOSTETH','4h','0.000056450000000','0.000053890000000','0.078122602660795','0.074579753009570','1383.9256450096545','1383.925645009654545','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','IOSTETH','4h','0.000056190000000','0.000055570000000','0.078122602660795','0.077260598502587','1390.3292874318383','1390.329287431838338','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','IOSTETH','4h','0.000055590000000','0.000054880000000','0.078122602660795','0.077124814427495','1405.335539859597','1405.335539859597020','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','IOSTETH','4h','0.000054800000000','0.000053510000000','0.078122602660795','0.076283585189400','1425.5949390656024','1425.594939065602375','test'),('2019-02-27 07:59:59','2019-02-28 11:59:59','IOSTETH','4h','0.000054510000000','0.000054100000000','0.078122602660795','0.077534999155183','1433.1792819811963','1433.179281981196254','test'),('2019-03-01 07:59:59','2019-03-05 07:59:59','IOSTETH','4h','0.000054610000000','0.000056970000000','0.078122602660795','0.081498712206290','1430.5548921588536','1430.554892158853590','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','IOSTETH','4h','0.000056030000000','0.000056830000000','0.078122602660795','0.079238042284722','1394.2995299088882','1394.299529908888189','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','IOSTETH','4h','0.000056910000000','0.000056370000000','0.078122602660795','0.077381323352469','1372.7394598628537','1372.739459862853664','test'),('2019-03-13 15:59:59','2019-03-13 19:59:59','IOSTETH','4h','0.000057230000000','0.000056880000000','0.078122602660795','0.077644830322314','1365.0638242319587','1365.063824231958733','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','IOSTETH','4h','0.000057670000000','0.000057080000000','0.078122602660795','0.077323359803679','1354.6489103657882','1354.648910365788197','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','IOSTETH','4h','0.000085790000000','0.000084470000000','0.078122602660795','0.076920576369709','910.6259780952907','910.625978095290748','test'),('2019-04-09 19:59:59','2019-04-10 15:59:59','IOSTETH','4h','0.000085720000000','0.000085620000000','0.078122602660795','0.078031465700155','911.3696064021815','911.369606402181489','test'),('2019-04-20 23:59:59','2019-04-21 03:59:59','IOSTETH','4h','0.000078950000000','0.000081480000000','0.078122602660795','0.080626088217879','989.5199830373022','989.519983037302154','test'),('2019-04-21 15:59:59','2019-04-21 19:59:59','IOSTETH','4h','0.000082930000000','0.000079590000000','0.078122602660795','0.074976220255308','942.0306603255156','942.030660325515555','test'),('2019-05-09 11:59:59','2019-05-09 15:59:59','IOSTETH','4h','0.000068640000000','0.000067510000000','0.078122602660795','0.076836493380394','1138.1498056642629','1138.149805664262885','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','IOSTETH','4h','0.000069940000000','0.000068400000000','0.078122602660795','0.076402430969379','1116.9946048154848','1116.994604815484763','test'),('2019-05-13 03:59:59','2019-05-13 15:59:59','IOSTETH','4h','0.000068780000000','0.000063860000000','0.078122602660795','0.072534303662669','1135.8331297004215','1135.833129700421523','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','IOSTETH','4h','0.000052300000000','0.000050970000000','0.078122602660795','0.076135928443991','1493.7400126347038','1493.740012634703817','test'),('2019-05-31 03:59:59','2019-05-31 07:59:59','IOSTETH','4h','0.000051440000000','0.000050840000000','0.078122602660795','0.077211374791501','1518.7131154897938','1518.713115489793836','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','IOSTETH','4h','0.000050180000000','0.000046980000000','0.078122602660795','0.073140690972582','1556.84740256666','1556.847402566660094','test'),('2019-06-17 19:59:59','2019-06-18 03:59:59','IOSTETH','4h','0.000047770000000','0.000046750000000','0.078122602660795','0.076454504383340','1635.3904680928408','1635.390468092840820','test'),('2019-06-20 03:59:59','2019-06-20 07:59:59','IOSTETH','4h','0.000046140000000','0.000045400000000','0.078122602660795','0.076869661048983','1693.1643402859775','1693.164340285977460','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','IOSTETH','4h','0.000043650000000','0.000043290000000','0.078122602660795','0.077478292535758','1789.7503473263462','1789.750347326346173','test'),('2019-06-28 07:59:59','2019-06-28 11:59:59','IOSTETH','4h','0.000042890000000','0.000042000000000','0.078122602660795','0.076501499457995','1821.4642728093963','1821.464272809396334','test'),('2019-06-29 03:59:59','2019-06-29 23:59:59','IOSTETH','4h','0.000042960000000','0.000043180000000','0.078122602660795','0.078522671855054','1818.496337541783','1818.496337541783078','test'),('2019-06-30 11:59:59','2019-06-30 15:59:59','IOSTETH','4h','0.000043100000000','0.000042780000000','0.078122602660795','0.077542574056353','1812.5893888815547','1812.589388881554669','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','IOSTETH','4h','0.000043420000000','0.000042280000000','0.078122602660795','0.076071479514012','1799.2308305111699','1799.230830511169870','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','IOSTETH','4h','0.000043120000000','0.000043050000000','0.078122602660795','0.077995780253878','1811.7486702410715','1811.748670241071522','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','IOSTETH','4h','0.000042640000000','0.000042360000000','0.078122602660795','0.077609602455705','1832.1435896058865','1832.143589605886518','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','IOSTETH','4h','0.000042650000000','0.000042690000000','0.078122602660795','0.078195871221321','1831.714013148769','1831.714013148769027','test'),('2019-07-06 07:59:59','2019-07-06 15:59:59','IOSTETH','4h','0.000042800000000','0.000042540000000','0.078122602660795','0.077648026102575','1825.294454691472','1825.294454691472083','test'),('2019-07-08 11:59:59','2019-07-08 23:59:59','IOSTETH','4h','0.000043420000000','0.000042900000000','0.078122602660795','0.077187002628929','1799.2308305111699','1799.230830511169870','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:57:28
