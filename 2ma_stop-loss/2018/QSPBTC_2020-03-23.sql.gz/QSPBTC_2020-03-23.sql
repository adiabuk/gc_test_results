-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 07:59:59','2018-05-09 11:59:59','QSPBTC','4h','0.000023380000000','0.000023010000000','0.001467500000000','0.001444276090676','62.76732249786142','62.767322497861421','test'),('2018-05-09 15:59:59','2018-05-09 19:59:59','QSPBTC','4h','0.000023110000000','0.000023300000000','0.001467500000000','0.001479565123323','63.500649069666814','63.500649069666814','test'),('2018-05-10 11:59:59','2018-05-10 15:59:59','QSPBTC','4h','0.000023480000000','0.000023380000000','0.001467500000000','0.001461250000000','62.50000000000001','62.500000000000007','test'),('2018-05-14 15:59:59','2018-05-14 19:59:59','QSPBTC','4h','0.000022610000000','0.000023470000000','0.001467500000000','0.001523318222026','64.90490933215392','64.904909332153920','test'),('2018-05-17 23:59:59','2018-05-22 15:59:59','QSPBTC','4h','0.000023870000000','0.000024580000000','0.001477102359006','0.001521037954938','61.881121030844156','61.881121030844156','test'),('2018-05-24 07:59:59','2018-05-24 11:59:59','QSPBTC','4h','0.000024380000000','0.000024310000000','0.001488086257989','0.001483813655936','61.037172189878994','61.037172189878994','test'),('2018-05-26 07:59:59','2018-05-26 11:59:59','QSPBTC','4h','0.000024540000000','0.000024790000000','0.001488086257989','0.001503246060943','60.63921181699266','60.639211816992663','test'),('2018-06-03 15:59:59','2018-06-03 19:59:59','QSPBTC','4h','0.000023290000000','0.000022730000000','0.001490808058214','0.001454962093740','64.01065084647918','64.010650846479180','test'),('2018-07-01 07:59:59','2018-07-01 11:59:59','QSPBTC','4h','0.000013110000000','0.000012490000000','0.001490808058214','0.001420304549740','113.71533624820748','113.715336248207478','test'),('2018-07-07 19:59:59','2018-07-07 23:59:59','QSPBTC','4h','0.000012050000000','0.000011750000000','0.001490808058214','0.001453692504897','123.71851105510373','123.718511055103733','test'),('2018-07-09 15:59:59','2018-07-09 19:59:59','QSPBTC','4h','0.000011900000000','0.000011650000000','0.001490808058214','0.001459488561193','125.27798808521008','125.277988085210083','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','QSPBTC','4h','0.000011340000000','0.000011000000000','0.001490808058214','0.001446110109379','131.46455539805996','131.464555398059957','test'),('2018-07-17 23:59:59','2018-07-18 11:59:59','QSPBTC','4h','0.000010930000000','0.000010830000000','0.001490808058214','0.001477168460243','136.3959797085087','136.395979708508690','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','QSPBTC','4h','0.000006110000000','0.000006180000000','0.001490808058214','0.001507887692269','243.99477221178395','243.994772211783953','test'),('2018-08-26 03:59:59','2018-08-30 07:59:59','QSPBTC','4h','0.000006070000000','0.000005950000000','0.001490808058214','0.001461335740753','245.60264550477757','245.602645504777570','test'),('2018-08-30 23:59:59','2018-08-31 03:59:59','QSPBTC','4h','0.000006110000000','0.000006010000000','0.001490808058214','0.001466408580993','243.99477221178395','243.994772211783953','test'),('2018-08-31 19:59:59','2018-08-31 23:59:59','QSPBTC','4h','0.000006140000000','0.000006150000000','0.001490808058214','0.001493236084367','242.80261534429968','242.802615344299682','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','QSPBTC','4h','0.000006070000000','0.000006050000000','0.001490808058214','0.001485896005304','245.60264550477757','245.602645504777570','test'),('2018-09-16 23:59:59','2018-09-17 07:59:59','QSPBTC','4h','0.000005100000000','0.000004860000000','0.001490808058214','0.001420652384886','292.31530553215686','292.315305532156856','test'),('2018-09-18 07:59:59','2018-09-18 11:59:59','QSPBTC','4h','0.000004910000000','0.000004700000000','0.001490808058214','0.001427046410103','303.6268957665988','303.626895766598807','test'),('2018-09-18 15:59:59','2018-09-18 19:59:59','QSPBTC','4h','0.000005190000000','0.000005050000000','0.001490808058214','0.001450593582655','287.24625399113677','287.246253991136768','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','QSPBTC','4h','0.000005210000000','0.000005150000000','0.001490808058214','0.001473639443340','286.14358123109406','286.143581231094061','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','QSPBTC','4h','0.000005310000000','0.000005230000000','0.001490808058214','0.001468347673156','280.7548132229755','280.754813222975486','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','QSPBTC','4h','0.000005630000000','0.000005480000000','0.001490808058214','0.001451088482951','264.7971684216696','264.797168421669596','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','QSPBTC','4h','0.000006930000000','0.000006310000000','0.001490808058214','0.001357431291101','215.12381792409812','215.123817924098120','test'),('2018-10-28 15:59:59','2018-10-28 23:59:59','QSPBTC','4h','0.000006660000000','0.000006550000000','0.001490808058214','0.001466185102298','223.84505378588588','223.845053785885881','test'),('2018-10-29 11:59:59','2018-10-29 15:59:59','QSPBTC','4h','0.000006940000000','0.000007200000000','0.001490808058214','0.001546659656937','214.81384124121038','214.813841241210383','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','QSPBTC','4h','0.000006660000000','0.000006640000000','0.001490808058214','0.001486331157138','223.84505378588588','223.845053785885881','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','QSPBTC','4h','0.000004600000000','0.000004480000000','0.001490808058214','0.001451917413217','324.0887083073913','324.088708307391300','test'),('2018-11-29 07:59:59','2018-11-30 03:59:59','QSPBTC','4h','0.000004590000000','0.000004480000000','0.001490808058214','0.001455080631982','324.79478392461874','324.794783924618741','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','QSPBTC','4h','0.000004800000000','0.000004640000000','0.001490808058214','0.001441114456274','310.5850121279167','310.585012127916684','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','QSPBTC','4h','0.000004050000000','0.000004020000000','0.001490808058214','0.001479765035561','368.10075511456785','368.100755114567846','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','QSPBTC','4h','0.000004040000000','0.000004000000000','0.001490808058214','0.001476047582390','369.0118955975247','369.011895597524699','test'),('2018-12-22 07:59:59','2018-12-22 15:59:59','QSPBTC','4h','0.000004050000000','0.000004020000000','0.001490808058214','0.001479765035561','368.10075511456785','368.100755114567846','test'),('2018-12-29 03:59:59','2018-12-29 07:59:59','QSPBTC','4h','0.000004020000000','0.000004010000000','0.001490808058214','0.001487099580457','370.8477756751244','370.847775675124410','test'),('2019-01-02 15:59:59','2019-01-06 23:59:59','QSPBTC','4h','0.000004020000000','0.000004090000000','0.001490808058214','0.001516767402511','370.8477756751244','370.847775675124410','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','QSPBTC','4h','0.000004260000000','0.000004030000000','0.001490808058214','0.001410318421268','349.954943242723','349.954943242723004','test'),('2019-01-08 19:59:59','2019-01-09 11:59:59','QSPBTC','4h','0.000004110000000','0.000004060000000','0.001490808058214','0.001472671707141','362.72702146326037','362.727021463260371','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','QSPBTC','4h','0.000004040000000','0.000003920000000','0.001490808058214','0.001446526630742','369.0118955975247','369.011895597524699','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','QSPBTC','4h','0.000004010000000','0.000004060000000','0.001490808058214','0.001509396687369','371.77258309576064','371.772583095760638','test'),('2019-02-10 23:59:59','2019-02-11 19:59:59','QSPBTC','4h','0.000004130000000','0.000004090000000','0.001490808058214','0.001476369239248','360.97047414382564','360.970474143825641','test'),('2019-02-12 23:59:59','2019-02-13 03:59:59','QSPBTC','4h','0.000004100000000','0.000004090000000','0.001490808058214','0.001487171940999','363.61172151560976','363.611721515609759','test'),('2019-02-13 19:59:59','2019-02-14 03:59:59','QSPBTC','4h','0.000004220000000','0.000004160000000','0.001490808058214','0.001469611735111','353.27205170947866','353.272051709478660','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','QSPBTC','4h','0.000004140000000','0.000004100000000','0.001490808058214','0.001476404115623','360.09856478599033','360.098564785990334','test'),('2019-02-17 19:59:59','2019-02-18 07:59:59','QSPBTC','4h','0.000004120000000','0.000004100000000','0.001490808058214','0.001483571125893','361.84661607135916','361.846616071359165','test'),('2019-02-22 19:59:59','2019-02-22 23:59:59','QSPBTC','4h','0.000004110000000','0.000004120000000','0.001490808058214','0.001494435328429','362.72702146326037','362.727021463260371','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','QSPBTC','4h','0.000004070000000','0.000004090000000','0.001490808058214','0.001498133896338','366.29190619508597','366.291906195085971','test'),('2019-04-04 11:59:59','2019-04-04 19:59:59','QSPBTC','4h','0.000005910000000','0.000005830000000','0.001490808058214','0.001470627915294','252.25178649983079','252.251786499830786','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','QSPBTC','4h','0.000005900000000','0.000005850000000','0.001490808058214','0.001478174091619','252.67933190067794','252.679331900677937','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','QSPBTC','4h','0.000005710000000','0.000005600000000','0.001490808058214','0.001462088463397','261.08722560665495','261.087225606654954','test'),('2019-04-19 03:59:59','2019-04-19 07:59:59','QSPBTC','4h','0.000005490000000','0.000005570000000','0.001490808058214','0.001512532037204','271.54973737959926','271.549737379599264','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:37:00
