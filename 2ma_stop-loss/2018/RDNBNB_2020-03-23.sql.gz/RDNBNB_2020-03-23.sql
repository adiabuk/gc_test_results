-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 23:59:59','2018-04-27 19:59:59','RDNBNB','4h','0.147710000000000','0.144660000000000','0.711908500000000','0.697208608828109','4.819636449800284','4.819636449800284','test'),('2018-04-28 07:59:59','2018-04-28 11:59:59','RDNBNB','4h','0.150610000000000','0.149060000000000','0.711908500000000','0.704581906978288','4.72683420755594','4.726834207555940','test'),('2018-06-30 07:59:59','2018-07-04 11:59:59','RDNBNB','4h','0.055950000000000','0.059050000000000','0.711908500000000','0.751352938784629','12.72401251117069','12.724012511170690','test'),('2018-07-07 15:59:59','2018-07-07 19:59:59','RDNBNB','4h','0.058980000000000','0.056680000000000','0.716262988647757','0.688331403807305','12.144167321935512','12.144167321935512','test'),('2018-07-08 03:59:59','2018-07-08 11:59:59','RDNBNB','4h','0.059590000000000','0.057710000000000','0.716262988647757','0.693665666636383','12.019852133709632','12.019852133709632','test'),('2018-07-11 03:59:59','2018-07-11 07:59:59','RDNBNB','4h','0.060040000000000','0.059230000000000','0.716262988647757','0.706599880373195','11.929763301927997','11.929763301927997','test'),('2018-07-16 23:59:59','2018-07-17 11:59:59','RDNBNB','4h','0.060160000000000','0.061480000000000','0.716262988647757','0.731978865393353','11.905967231511918','11.905967231511918','test'),('2018-07-30 19:59:59','2018-07-30 23:59:59','RDNBNB','4h','0.064330000000000','0.062110000000000','0.716262988647757','0.691545068007340','11.134198486674288','11.134198486674288','test'),('2018-08-17 19:59:59','2018-08-17 23:59:59','RDNBNB','4h','0.039590000000000','0.037790000000000','0.716262988647757','0.683697356428359','18.092017899665496','18.092017899665496','test'),('2018-08-18 03:59:59','2018-08-18 15:59:59','RDNBNB','4h','0.038550000000000','0.036870000000000','0.716262988647757','0.685048414823419','18.580103466867882','18.580103466867882','test'),('2018-08-26 15:59:59','2018-08-27 11:59:59','RDNBNB','4h','0.037030000000000','0.036500000000000','0.716262988647757','0.706011317462682','19.342775820895408','19.342775820895408','test'),('2018-09-09 07:59:59','2018-09-09 23:59:59','RDNBNB','4h','0.049280000000000','0.048760000000000','0.716262988647757','0.708705018800013','14.534557399508056','14.534557399508056','test'),('2018-09-13 07:59:59','2018-09-13 19:59:59','RDNBNB','4h','0.052380000000000','0.051070000000000','0.716262988647757','0.698349576751450','13.674360226188563','13.674360226188563','test'),('2018-09-18 23:59:59','2018-09-19 03:59:59','RDNBNB','4h','0.046650000000000','0.045140000000000','0.716262988647757','0.693078484620788','15.353976176800794','15.353976176800794','test'),('2018-09-20 15:59:59','2018-09-21 15:59:59','RDNBNB','4h','0.046890000000000','0.048700000000000','0.716262988647757','0.743911442677453','15.27538896668281','15.275388966682810','test'),('2018-09-24 23:59:59','2018-09-25 03:59:59','RDNBNB','4h','0.048390000000000','0.047600000000000','0.716262988647757','0.704569503195562','14.801880319234488','14.801880319234488','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','RDNBNB','4h','0.048000000000000','0.046500000000000','0.716262988647757','0.693879770252515','14.922145596828269','14.922145596828269','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','RDNBNB','4h','0.047670000000000','0.046610000000000','0.716262988647757','0.700336016380784','15.025445534880575','15.025445534880575','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','RDNBNB','4h','0.048520000000000','0.047990000000000','0.716262988647757','0.708439011236724','14.762221530250555','14.762221530250555','test'),('2018-10-04 03:59:59','2018-10-05 11:59:59','RDNBNB','4h','0.047450000000000','0.060950000000000','0.716262988647757','0.920046979095485','15.095110403535447','15.095110403535447','test'),('2018-10-11 15:59:59','2018-10-11 19:59:59','RDNBNB','4h','0.053490000000000','0.052560000000000','0.716262988647757','0.703809734218099','13.390596160922732','13.390596160922732','test'),('2018-10-13 11:59:59','2018-10-13 15:59:59','RDNBNB','4h','0.055590000000000','0.053070000000000','0.716262988647757','0.683793430608679','12.884745253602391','12.884745253602391','test'),('2018-10-16 03:59:59','2018-10-18 19:59:59','RDNBNB','4h','0.054630000000000','0.053780000000000','0.716262988647757','0.705118497702295','13.111165818190683','13.111165818190683','test'),('2018-10-27 11:59:59','2018-10-27 15:59:59','RDNBNB','4h','0.059900000000000','0.059140000000000','0.716262988647757','0.707175177773428','11.95764588727474','11.957645887274740','test'),('2018-10-28 07:59:59','2018-10-28 11:59:59','RDNBNB','4h','0.062450000000000','0.061620000000000','0.716262988647757','0.706743400487987','11.46938332502413','11.469383325024131','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','RDNBNB','4h','0.060240000000000','0.059210000000000','0.716262988647757','0.704016128118089','11.89015585404643','11.890155854046430','test'),('2018-11-01 11:59:59','2018-11-01 19:59:59','RDNBNB','4h','0.059520000000000','0.058890000000000','0.716262988647757','0.708681575965497','12.033988384538926','12.033988384538926','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','RDNBNB','4h','0.048760000000000','0.045500000000000','0.716262988647757','0.668375020169667','14.689560882849815','14.689560882849815','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','RDNBNB','4h','0.047530000000000','0.045640000000000','0.716262988647757','0.687781249776638','15.069703106411886','15.069703106411886','test'),('2018-11-28 11:59:59','2018-12-04 03:59:59','RDNBNB','4h','0.048050000000000','0.048410000000000','0.716262988647757','0.721629371080914','14.906617869880478','14.906617869880478','test'),('2018-12-21 15:59:59','2018-12-22 11:59:59','RDNBNB','4h','0.037240000000000','0.050030000000000','0.716262988647757','0.962262011870228','19.233700017394117','19.233700017394117','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','RDNBNB','4h','0.047510000000000','0.045180000000000','0.731816911542041','0.695926921984201','15.403428994780903','15.403428994780903','test'),('2019-01-02 23:59:59','2019-01-03 23:59:59','RDNBNB','4h','0.045720000000000','0.042750000000000','0.731816911542041','0.684277623981239','16.006494128216122','16.006494128216122','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','RDNBNB','4h','0.043100000000000','0.041000000000000','0.731816911542041','0.696159939053914','16.97951070863204','16.979510708632041','test'),('2019-01-16 23:59:59','2019-01-17 03:59:59','RDNBNB','4h','0.039410000000000','0.037750000000000','0.731816911542041','0.700991839906421','18.569320262421744','18.569320262421744','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','RDNBNB','4h','0.039250000000000','0.038250000000000','0.731816911542041','0.713171894687467','18.645016854574294','18.645016854574294','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','RDNBNB','4h','0.034810000000000','0.034750000000000','0.731816911542041','0.730555520714907','21.02318045222755','21.023180452227550','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','RDNBNB','4h','0.027580000000000','0.026570000000000','0.731816911542041','0.705017234940973','26.534333268384373','26.534333268384373','test'),('2019-02-23 07:59:59','2019-02-24 19:59:59','RDNBNB','4h','0.025540000000000','0.025540000000000','0.731816911542041','0.731816911542041','28.653755346203642','28.653755346203642','test'),('2019-02-25 15:59:59','2019-02-26 23:59:59','RDNBNB','4h','0.025900000000000','0.031530000000000','0.731816911542041','0.890895259495002','28.255479210117414','28.255479210117414','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','RDNBNB','4h','0.022560000000000','0.020590000000000','0.731816911542041','0.667912686553662','32.438692887501816','32.438692887501816','test'),('2019-03-15 23:59:59','2019-03-16 03:59:59','RDNBNB','4h','0.022000000000000','0.021270000000000','0.731816911542041','0.707533895840873','33.26440507009277','33.264405070092771','test'),('2019-03-16 11:59:59','2019-03-16 15:59:59','RDNBNB','4h','0.022190000000000','0.020550000000000','0.731816911542041','0.677730398025640','32.97958141243988','32.979581412439877','test'),('2019-03-17 03:59:59','2019-03-17 11:59:59','RDNBNB','4h','0.022170000000000','0.021210000000000','0.731816911542041','0.700127951908285','33.00933295182865','33.009332951828647','test'),('2019-03-17 19:59:59','2019-03-18 03:59:59','RDNBNB','4h','0.021880000000000','0.021780000000000','0.731816911542041','0.728472227302818','33.44684239223222','33.446842392232220','test'),('2019-03-18 15:59:59','2019-03-18 19:59:59','RDNBNB','4h','0.021890000000000','0.021590000000000','0.731816911542041','0.721787442676686','33.43156288451535','33.431562884515351','test'),('2019-03-19 15:59:59','2019-03-19 19:59:59','RDNBNB','4h','0.021940000000000','0.021720000000000','0.731816911542041','0.724478729202057','33.35537427265456','33.355374272654558','test'),('2019-03-20 03:59:59','2019-03-22 15:59:59','RDNBNB','4h','0.022150000000000','0.022150000000000','0.731816911542041','0.731816911542041','33.039138218602304','33.039138218602304','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','RDNBNB','4h','0.022250000000000','0.019620000000000','0.731816911542041','0.645314508065386','32.89064770975465','32.890647709754653','test'),('2019-03-26 19:59:59','2019-03-27 03:59:59','RDNBNB','4h','0.021900000000000','0.021860000000000','0.731816911542041','0.730480259648814','33.4162973306868','33.416297330686803','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','RDNBNB','4h','0.021760000000000','0.022240000000000','0.731816911542041','0.747959931649586','33.63129189071879','33.631291890718792','test'),('2019-03-31 15:59:59','2019-03-31 19:59:59','RDNBNB','4h','0.021700000000000','0.021250000000000','0.731816911542041','0.716640984804994','33.72428163788207','33.724281637882072','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:01:38
