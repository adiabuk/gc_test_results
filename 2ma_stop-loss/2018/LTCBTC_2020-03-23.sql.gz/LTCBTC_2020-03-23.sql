-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 11:59:59','LTCBTC','4h','0.017919000000000','0.017714000000000','0.001467500000000','0.001450711256208','0.08189631117807913','0.081896311178079','test'),('2018-01-06 03:59:59','2018-01-06 07:59:59','LTCBTC','4h','0.017776000000000','0.016902000000000','0.001467500000000','0.001395346815932','0.08255513051305131','0.082555130513051','test'),('2018-01-07 07:59:59','2018-01-07 19:59:59','LTCBTC','4h','0.016833000000000','0.016720000000000','0.001467500000000','0.001457648666310','0.08717994415731005','0.087179944157310','test'),('2018-01-09 15:59:59','2018-01-09 19:59:59','LTCBTC','4h','0.017102000000000','0.016992000000000','0.001467500000000','0.001458061045492','0.08580867734767864','0.085808677347679','test'),('2018-01-11 03:59:59','2018-01-11 15:59:59','LTCBTC','4h','0.017066000000000','0.016900000000000','0.001467500000000','0.001453225711942','0.08598968709715223','0.085989687097152','test'),('2018-01-16 03:59:59','2018-01-16 07:59:59','LTCBTC','4h','0.017167000000000','0.017010000000000','0.001467500000000','0.001454079047009','0.08548377701403856','0.085483777014039','test'),('2018-01-18 15:59:59','2018-01-18 19:59:59','LTCBTC','4h','0.017300000000000','0.017124000000000','0.001467500000000','0.001452570520231','0.08482658959537573','0.084826589595376','test'),('2018-01-28 23:59:59','2018-01-29 03:59:59','LTCBTC','4h','0.016570000000000','0.016240000000000','0.001467500000000','0.001438273989137','0.08856366928183464','0.088563669281835','test'),('2018-01-30 15:59:59','2018-01-30 19:59:59','LTCBTC','4h','0.016344000000000','0.016545000000000','0.001467500000000','0.001485547448605','0.0897883015173764','0.089788301517376','test'),('2018-02-03 19:59:59','2018-02-15 15:59:59','LTCBTC','4h','0.017014000000000','0.022300000000000','0.001467500000000','0.001923430704126','0.08625249794287057','0.086252497942871','test'),('2018-02-20 07:59:59','2018-02-20 23:59:59','LTCBTC','4h','0.020902000000000','0.020367000000000','0.001540973801248','0.001501531595542','0.07372374898325519','0.073723748983255','test'),('2018-02-22 03:59:59','2018-02-22 07:59:59','LTCBTC','4h','0.020142000000000','0.020074000000000','0.001540973801248','0.001535771427180','0.07650550100526263','0.076505501005263','test'),('2018-02-23 11:59:59','2018-02-23 19:59:59','LTCBTC','4h','0.020582000000000','0.020323000000000','0.001540973801248','0.001521582478028','0.07486997382411816','0.074869973824118','test'),('2018-03-09 11:59:59','2018-03-12 11:59:59','LTCBTC','4h','0.019226000000000','0.019395000000000','0.001540973801248','0.001554519238282','0.08015051499261416','0.080150514992614','test'),('2018-03-12 15:59:59','2018-03-12 19:59:59','LTCBTC','4h','0.019489000000000','0.019733000000000','0.001540973801248','0.001560266612963','0.079068900469393','0.079068900469393','test'),('2018-03-14 19:59:59','2018-03-14 23:59:59','LTCBTC','4h','0.019760000000000','0.019559000000000','0.001540973801248','0.001525298915922','0.07798450411174089','0.077984504111741','test'),('2018-04-03 19:59:59','2018-04-04 11:59:59','LTCBTC','4h','0.017799000000000','0.017146000000000','0.001540973801248','0.001484439395258','0.0865764257120063','0.086576425712006','test'),('2018-04-05 03:59:59','2018-04-05 07:59:59','LTCBTC','4h','0.017568000000000','0.017456000000000','0.001540973801248','0.001531149742406','0.08771481109107468','0.087714811091075','test'),('2018-04-17 07:59:59','2018-04-21 11:59:59','LTCBTC','4h','0.016551000000000','0.016466000000000','0.001540973801248','0.001533059912474','0.09310457381717117','0.093104573817171','test'),('2018-04-23 07:59:59','2018-04-23 11:59:59','LTCBTC','4h','0.017049000000000','0.016989000000000','0.001540973801248','0.001535550701472','0.09038499626066043','0.090384996260660','test'),('2018-05-03 03:59:59','2018-05-03 07:59:59','LTCBTC','4h','0.016635000000000','0.016461000000000','0.001540973801248','0.001524855409819','0.0926344334985272','0.092634433498527','test'),('2018-05-04 11:59:59','2018-05-09 03:59:59','LTCBTC','4h','0.016770000000000','0.016874000000000','0.001540973801248','0.001550530227922','0.09188871802313656','0.091888718023137','test'),('2018-05-14 19:59:59','2018-05-14 23:59:59','LTCBTC','4h','0.017163000000000','0.016981000000000','0.001540973801248','0.001524632996504','0.08978464145242672','0.089784641452427','test'),('2018-05-29 15:59:59','2018-05-29 19:59:59','LTCBTC','4h','0.016151000000000','0.016045000000000','0.001540973801248','0.001530860296020','0.09541042667624296','0.095410426676243','test'),('2018-05-30 11:59:59','2018-05-30 15:59:59','LTCBTC','4h','0.016171000000000','0.015850000000000','0.001540973801248','0.001510384932891','0.09529242478807741','0.095292424788077','test'),('2018-06-02 07:59:59','2018-06-02 15:59:59','LTCBTC','4h','0.016096000000000','0.016084000000000','0.001540973801248','0.001539824963921','0.09573644391451293','0.095736443914513','test'),('2018-07-03 07:59:59','2018-07-03 11:59:59','LTCBTC','4h','0.013304000000000','0.013126000000000','0.001540973801248','0.001520356442813','0.11582785637763078','0.115827856377631','test'),('2018-07-03 19:59:59','2018-07-03 23:59:59','LTCBTC','4h','0.013199000000000','0.013033000000000','0.001540973801248','0.001521593420082','0.11674928413122206','0.116749284131222','test'),('2018-07-16 11:59:59','2018-07-16 15:59:59','LTCBTC','4h','0.012438000000000','0.012542000000000','0.001540973801248','0.001553858611935','0.12389241045570028','0.123892410455700','test'),('2018-08-04 15:59:59','2018-08-04 19:59:59','LTCBTC','4h','0.010655000000000','0.010433000000000','0.001540973801248','0.001508867167379','0.14462447688859692','0.144624476888597','test'),('2018-08-05 03:59:59','2018-08-05 11:59:59','LTCBTC','4h','0.010477000000000','0.010518000000000','0.001540973801248','0.001547004146371','0.14708158836002672','0.147081588360027','test'),('2018-08-28 19:59:59','2018-08-29 03:59:59','LTCBTC','4h','0.008869000000000','0.008710000000000','0.001540973801248','0.001513347819243','0.17374831449408049','0.173748314494080','test'),('2018-08-31 19:59:59','2018-09-05 11:59:59','LTCBTC','4h','0.008798000000000','0.008911000000000','0.001540973801248','0.001560765803924','0.1751504661568538','0.175150466156854','test'),('2018-09-07 03:59:59','2018-09-07 07:59:59','LTCBTC','4h','0.008933000000000','0.008779000000000','0.001540973801248','0.001514408261632','0.1725035040017911','0.172503504001791','test'),('2018-09-14 19:59:59','2018-09-14 23:59:59','LTCBTC','4h','0.008889000000000','0.008674000000000','0.001540973801248','0.001503701963328','0.1733573856730791','0.173357385673079','test'),('2018-09-19 03:59:59','2018-09-19 07:59:59','LTCBTC','4h','0.008600000000000','0.008502000000000','0.001540973801248','0.001523413867234','0.1791830001451163','0.179183000145116','test'),('2018-09-20 23:59:59','2018-09-21 15:59:59','LTCBTC','4h','0.008708000000000','0.008560000000000','0.001540973801248','0.001514783617212','0.1769607029453376','0.176960702945338','test'),('2018-09-25 19:59:59','2018-09-26 15:59:59','LTCBTC','4h','0.008842000000000','0.008930000000000','0.001540973801248','0.001556310342134','0.1742788736991631','0.174278873699163','test'),('2018-10-08 19:59:59','2018-10-09 03:59:59','LTCBTC','4h','0.008965000000000','0.008930000000000','0.001540973801248','0.001534957729520','0.17188776366402675','0.171887763664027','test'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCBTC','4h','0.008083000000000','0.008050000000000','0.001540973801248','0.001534682555987','0.19064379577483606','0.190643795774836','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','LTCBTC','4h','0.007586000000000','0.007615000000000','0.001540973801248','0.001546864684485','0.20313390472554707','0.203133904725547','test'),('2018-11-25 23:59:59','2018-11-26 15:59:59','LTCBTC','4h','0.007710000000000','0.007660000000000','0.001540973801248','0.001530980456233','0.1998669002915694','0.199866900291569','test'),('2018-12-15 07:59:59','2018-12-15 11:59:59','LTCBTC','4h','0.007358000000000','0.007336000000000','0.001540973801248','0.001536366377542','0.20942835026474585','0.209428350264746','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','LTCBTC','4h','0.008015000000000','0.007918000000000','0.001540973801248','0.001522324461420','0.192261235339738','0.192261235339738','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','LTCBTC','4h','0.008060000000000','0.008178000000000','0.001540973801248','0.001563533963599','0.19118781653200995','0.191187816532010','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:23:02
