-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-03 19:59:59','2018-09-03 23:59:59','ZILBNB','4h','0.004017000000000','0.003965000000000','0.711908500000000','0.702692855987055','177.2239233258651','177.223923325865087','test'),('2018-09-04 07:59:59','2018-09-04 23:59:59','ZILBNB','4h','0.004081000000000','0.004022000000000','0.711908500000000','0.701616267336437','174.44462141631954','174.444621416319535','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','ZILBNB','4h','0.003580000000000','0.003518000000000','0.711908500000000','0.699579358379888','198.85712290502795','198.857122905027950','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','ZILBNB','4h','0.003515000000000','0.003574000000000','0.711908500000000','0.723858031009957','202.5344238975818','202.534423897581803','test'),('2018-09-23 11:59:59','2018-09-23 15:59:59','ZILBNB','4h','0.003478000000000','0.003507000000000','0.711908500000000','0.717844482317424','204.68904542840713','204.689045428407127','test'),('2018-09-26 03:59:59','2018-09-26 07:59:59','ZILBNB','4h','0.003495000000000','0.003520000000000','0.711908500000000','0.717000835479256','203.69341917024323','203.693419170243232','test'),('2018-09-27 19:59:59','2018-09-27 23:59:59','ZILBNB','4h','0.003550000000000','0.003558000000000','0.711908500000000','0.713512800845070','200.53760563380283','200.537605633802826','test'),('2018-09-28 23:59:59','2018-09-29 11:59:59','ZILBNB','4h','0.003524000000000','0.003506000000000','0.711908500000000','0.708272190976164','202.01716799091943','202.017167990919432','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','ZILBNB','4h','0.003540000000000','0.003509000000000','0.711908500000000','0.705674273022599','201.10409604519774','201.104096045197736','test'),('2018-10-09 15:59:59','2018-10-10 07:59:59','ZILBNB','4h','0.003642000000000','0.003578000000000','0.711908500000000','0.699398301208128','195.47185612300936','195.471856123009360','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','ZILBNB','4h','0.003564000000000','0.003438000000000','0.711908500000000','0.686740017676768','199.74985970819307','199.749859708193071','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','ZILBNB','4h','0.003516000000000','0.003399000000000','0.711908500000000','0.688218712030717','202.47682025028442','202.476820250284419','test'),('2018-10-17 07:59:59','2018-10-18 15:59:59','ZILBNB','4h','0.003495000000000','0.003422000000000','0.711908500000000','0.697038880400572','203.69341917024323','203.693419170243232','test'),('2018-10-19 05:59:59','2018-10-19 11:59:59','ZILBNB','4h','0.003493000000000','0.003482000000000','0.711908500000000','0.709666589464644','203.81004866876611','203.810048668766115','test'),('2018-10-20 07:59:59','2018-10-20 11:59:59','ZILBNB','4h','0.003475000000000','0.003509000000000','0.711908500000000','0.718873935683453','204.8657553956835','204.865755395683493','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','ZILBNB','4h','0.003526000000000','0.003511000000000','0.711908500000000','0.708879961287578','201.90258082813386','201.902580828133864','test'),('2018-10-30 07:59:59','2018-10-30 11:59:59','ZILBNB','4h','0.003615000000000','0.003615000000000','0.711908500000000','0.711908500000000','196.93181189488243','196.931811894882429','test'),('2018-11-04 11:59:59','2018-11-05 11:59:59','ZILBNB','4h','0.003724000000000','0.003683000000000','0.711908500000000','0.704070624462943','191.16769602577875','191.167696025778753','test'),('2018-11-06 03:59:59','2018-11-06 07:59:59','ZILBNB','4h','0.003693000000000','0.003651000000000','0.711908500000000','0.703812058895207','192.77240725697266','192.772407256972656','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','ZILBNB','4h','0.003682000000000','0.003670000000000','0.711908500000000','0.709588320206410','193.3483161325367','193.348316132536695','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','ZILBNB','4h','0.003668000000000','0.003664000000000','0.711908500000000','0.711132154852781','194.08628680479828','194.086286804798277','test'),('2018-11-09 07:59:59','2018-11-09 11:59:59','ZILBNB','4h','0.003729000000000','0.003680000000000','0.711908500000000','0.702553842853312','190.91137034057388','190.911370340573882','test'),('2018-11-27 11:59:59','2018-11-30 11:59:59','ZILBNB','4h','0.003255000000000','0.003227000000000','0.711908500000000','0.705784555913978','218.71228878648233','218.712288786482333','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','ZILBNB','4h','0.003102000000000','0.003035000000000','0.711908500000000','0.696532010799484','229.49983881366862','229.499838813668617','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','ZILBNB','4h','0.003050000000000','0.002826000000000','0.711908500000000','0.659624072459016','233.41262295081967','233.412622950819667','test'),('2018-12-20 11:59:59','2018-12-28 15:59:59','ZILBNB','4h','0.002955000000000','0.003218000000000','0.711908500000000','0.775269561082910','240.9165820642978','240.916582064297813','test'),('2019-01-01 03:59:59','2019-01-03 03:59:59','ZILBNB','4h','0.003300000000000','0.003374000000000','0.711908500000000','0.727872508787879','215.7298484848485','215.729848484848503','test'),('2019-01-15 15:59:59','2019-01-18 07:59:59','ZILBNB','4h','0.003470000000000','0.003438000000000','0.711908500000000','0.705343349567723','205.16095100864555','205.160951008645554','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','ZILBNB','4h','0.003498000000000','0.003390000000000','0.711908500000000','0.689928477701544','203.51872498570614','203.518724985706143','test'),('2019-01-22 15:59:59','2019-01-23 07:59:59','ZILBNB','4h','0.003450000000000','0.003393000000000','0.711908500000000','0.700146533478261','206.35028985507248','206.350289855072475','test'),('2019-01-24 11:59:59','2019-01-24 15:59:59','ZILBNB','4h','0.003455000000000','0.003400000000000','0.711908500000000','0.700575658465991','206.05166425470333','206.051664254703326','test'),('2019-01-24 19:59:59','2019-01-24 23:59:59','ZILBNB','4h','0.003436000000000','0.003403000000000','0.711908500000000','0.705071194848661','207.19106519208384','207.191065192083840','test'),('2019-01-28 23:59:59','2019-01-29 03:59:59','ZILBNB','4h','0.003397000000000','0.003228000000000','0.711908500000000','0.676491209302326','209.56976744186048','209.569767441860478','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ZILBNB','4h','0.003344000000000','0.003335000000000','0.711908500000000','0.709992478319378','212.89129784688996','212.891297846889955','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','ZILBNB','4h','0.001851000000000','0.001842000000000','0.711908500000000','0.708447032414911','384.60750945434904','384.607509454349042','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','ZILBNB','4h','0.001249000000000','0.001240000000000','0.711908500000000','0.706778654923939','569.9827862289833','569.982786228983286','test'),('2019-04-03 03:59:59','2019-04-03 07:59:59','ZILBNB','4h','0.001195000000000','0.001179000000000','0.711908500000000','0.702376670711297','595.7393305439331','595.739330543933079','test'),('2019-04-10 03:59:59','2019-04-10 11:59:59','ZILBNB','4h','0.001274000000000','0.001245000000000','0.711908500000000','0.695703361459969','558.7978806907379','558.797880690737884','test'),('2019-05-08 07:59:59','2019-05-08 19:59:59','ZILBNB','4h','0.000780000000000','0.000776000000000','0.711908500000000','0.708257687179487','912.7032051282052','912.703205128205241','test'),('2019-05-09 19:59:59','2019-05-10 03:59:59','ZILBNB','4h','0.000769000000000','0.000801000000000','0.711908500000000','0.741532780884265','925.75877763329','925.758777633290038','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','ZILBNB','4h','0.000776000000000','0.000780000000000','0.711908500000000','0.715578131443299','917.4078608247423','917.407860824742329','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','ZILBNB','4h','0.000786000000000','0.000756000000000','0.711908500000000','0.684736419847328','905.7360050890586','905.736005089058608','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','ZILBNB','4h','0.000721000000000','0.000644000000000','0.711908500000000','0.635879436893204','987.3904299583912','987.390429958391223','test'),('2019-05-22 15:59:59','2019-05-22 23:59:59','ZILBNB','4h','0.000715000000000','0.000702000000000','0.711908500000000','0.698964709090909','995.6762237762238','995.676223776223765','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','ZILBNB','4h','0.000704000000000','0.000658000000000','0.711908500000000','0.665391751420455','1011.2336647727274','1011.233664772727366','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','ZILBNB','4h','0.000651000000000','0.000634000000000','0.711908500000000','0.693317955453149','1093.5614439324117','1093.561443932411748','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ZILBNB','4h','0.000642000000000','0.000634000000000','0.711908500000000','0.703037366043614','1108.8917445482866','1108.891744548286624','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ZILBNB','4h','0.000662000000000','0.000648000000000','0.711908500000000','0.696853033232628','1075.3904833836857','1075.390483383685705','test'),('2019-06-02 15:59:59','2019-06-09 23:59:59','ZILBNB','4h','0.000641000000000','0.000727000000000','0.711908500000000','0.807421964898596','1110.6216848673948','1110.621684867394833','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ZILBNB','4h','0.000727000000000','0.000713000000000','0.711908500000000','0.698199120357634','979.2414030261349','979.241403026134890','test'),('2019-06-16 15:59:59','2019-06-18 03:59:59','ZILBNB','4h','0.000706000000000','0.000721000000000','0.711908500000000','0.727034034702550','1008.3689801699717','1008.368980169971678','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','ZILBNB','4h','0.000518000000000','0.000520000000000','0.711908500000000','0.714657181467181','1374.3407335907336','1374.340733590733635','test'),('2019-07-09 23:59:59','2019-07-10 03:59:59','ZILBNB','4h','0.000519000000000','0.000516000000000','0.711908500000000','0.707793421965318','1371.6926782273604','1371.692678227360375','test'),('2019-07-30 03:59:59','2019-07-30 11:59:59','ZILBNB','4h','0.000387000000000','0.000380000000000','0.711908500000000','0.699031602067184','1839.5568475452199','1839.556847545219853','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:25:06
