-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-21 03:59:59','2018-07-21 07:59:59','STEEMBNB','4h','0.115250000000000','0.117480000000000','0.711908500000000','0.725683388980477','6.177080260303688','6.177080260303688','test'),('2018-07-23 03:59:59','2018-07-23 11:59:59','STEEMBNB','4h','0.119130000000000','0.114710000000000','0.715352222245119','0.688810991469299','6.004803342945683','6.004803342945683','test'),('2018-07-24 15:59:59','2018-07-25 03:59:59','STEEMBNB','4h','0.116990000000000','0.113330000000000','0.715352222245119','0.692972624557991','6.114644176811001','6.114644176811001','test'),('2018-07-26 03:59:59','2018-07-26 15:59:59','STEEMBNB','4h','0.116590000000000','0.114190000000000','0.715352222245119','0.700626728348659','6.135622456858384','6.135622456858384','test'),('2018-08-14 07:59:59','2018-08-14 19:59:59','STEEMBNB','4h','0.090340000000000','0.088060000000000','0.715352222245119','0.697298170145065','7.918443903532421','7.918443903532421','test'),('2018-08-15 15:59:59','2018-08-16 11:59:59','STEEMBNB','4h','0.087330000000000','0.088030000000000','0.715352222245119','0.721086180284413','8.191368627563483','8.191368627563483','test'),('2018-08-16 23:59:59','2018-08-18 15:59:59','STEEMBNB','4h','0.088230000000000','0.090110000000000','0.715352222245119','0.730594908154909','8.10781165414393','8.107811654143930','test'),('2018-08-21 11:59:59','2018-08-21 19:59:59','STEEMBNB','4h','0.089600000000000','0.088760000000000','0.715352222245119','0.708645795161571','7.98384176612856','7.983841766128560','test'),('2018-08-22 15:59:59','2018-08-22 19:59:59','STEEMBNB','4h','0.089310000000000','0.090550000000000','0.715352222245119','0.725284332373704','8.00976623273003','8.009766232730030','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','STEEMBNB','4h','0.090000000000000','0.087550000000000','0.715352222245119','0.695878745084002','7.948358024945766','7.948358024945766','test'),('2018-08-26 19:59:59','2018-08-26 23:59:59','STEEMBNB','4h','0.091900000000000','0.086670000000000','0.715352222245119','0.674641753013977','7.784028533679206','7.784028533679206','test'),('2018-08-29 11:59:59','2018-08-29 15:59:59','STEEMBNB','4h','0.088930000000000','0.087160000000000','0.715352222245119','0.701114356132740','8.043992153886416','8.043992153886416','test'),('2018-09-01 19:59:59','2018-09-01 23:59:59','STEEMBNB','4h','0.089070000000000','0.086240000000000','0.715352222245119','0.692623505629494','8.031348627429201','8.031348627429201','test'),('2018-09-02 03:59:59','2018-09-02 11:59:59','STEEMBNB','4h','0.089600000000000','0.087290000000000','0.715352222245119','0.696909547765362','7.98384176612856','7.983841766128560','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','STEEMBNB','4h','0.088850000000000','0.087420000000000','0.715352222245119','0.703838956315907','8.051234915533135','8.051234915533135','test'),('2018-09-04 11:59:59','2018-09-05 11:59:59','STEEMBNB','4h','0.089520000000000','0.085370000000000','0.715352222245119','0.682189669493586','7.990976566634483','7.990976566634483','test'),('2018-09-18 07:59:59','2018-09-18 15:59:59','STEEMBNB','4h','0.087600000000000','0.085150000000000','0.715352222245119','0.695345225161780','8.166121258505925','8.166121258505925','test'),('2018-09-29 19:59:59','2018-09-29 23:59:59','STEEMBNB','4h','0.088940000000000','0.087230000000000','0.715352222245119','0.701598542235684','8.043087724815818','8.043087724815818','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','STEEMBNB','4h','0.088620000000000','0.088540000000000','0.715352222245119','0.714706451789470','8.072130695611813','8.072130695611813','test'),('2018-10-06 19:59:59','2018-10-07 15:59:59','STEEMBNB','4h','0.089820000000000','0.086680000000000','0.715352222245119','0.690344362326953','7.964286598142051','7.964286598142051','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','STEEMBNB','4h','0.087800000000000','0.086010000000000','0.715352222245119','0.700768162133288','8.147519615548052','8.147519615548052','test'),('2018-10-09 19:59:59','2018-10-09 23:59:59','STEEMBNB','4h','0.086940000000000','0.088360000000000','0.715352222245119','0.727036143979511','8.228113897459385','8.228113897459385','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','STEEMBNB','4h','0.086890000000000','0.083370000000000','0.715352222245119','0.686372594873698','8.232848685062942','8.232848685062942','test'),('2018-10-12 19:59:59','2018-10-12 23:59:59','STEEMBNB','4h','0.088300000000000','0.086000000000000','0.715352222245119','0.696719038653230','8.101384170386398','8.101384170386398','test'),('2018-10-21 03:59:59','2018-10-21 07:59:59','STEEMBNB','4h','0.084930000000000','0.084130000000000','0.715352222245119','0.708613946279075','8.422844957554679','8.422844957554679','test'),('2018-10-24 19:59:59','2018-10-24 23:59:59','STEEMBNB','4h','0.084360000000000','0.083590000000000','0.715352222245119','0.708822810069577','8.479756072132751','8.479756072132751','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','STEEMBNB','4h','0.083640000000000','0.083880000000000','0.715352222245119','0.717404882854144','8.552752537603048','8.552752537603048','test'),('2018-10-31 11:59:59','2018-10-31 15:59:59','STEEMBNB','4h','0.085540000000000','0.082930000000000','0.715352222245119','0.693525365802989','8.362780246026642','8.362780246026642','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','STEEMBNB','4h','0.083030000000000','0.083850000000000','0.715352222245119','0.722417003917298','8.615587405095976','8.615587405095976','test'),('2018-11-29 03:59:59','2018-11-29 07:59:59','STEEMBNB','4h','0.070040000000000','0.070030000000000','0.715352222245119','0.715250087433262','10.21348118568131','10.213481185681310','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','STEEMBNB','4h','0.073090000000000','0.071120000000000','0.715352222245119','0.696071282611477','9.787279001848665','9.787279001848665','test'),('2018-12-20 19:59:59','2018-12-21 03:59:59','STEEMBNB','4h','0.050870000000000','0.049860000000000','0.715352222245119','0.701149239259714','14.062359391490446','14.062359391490446','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','STEEMBNB','4h','0.051830000000000','0.050240000000000','0.715352222245119','0.693407209060289','13.801895084798744','13.801895084798744','test'),('2019-01-02 23:59:59','2019-01-03 03:59:59','STEEMBNB','4h','0.047540000000000','0.046880000000000','0.715352222245119','0.705420954540412','15.047375310162368','15.047375310162368','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','STEEMBNB','4h','0.048040000000000','0.048150000000000','0.715352222245119','0.716990206101217','14.890762328166506','14.890762328166506','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','STEEMBNB','4h','0.048070000000000','0.047990000000000','0.715352222245119','0.714161704712778','14.881469154256687','14.881469154256687','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','STEEMBNB','4h','0.048290000000000','0.046720000000000','0.715352222245119','0.692094757160736','14.813672028269185','14.813672028269185','test'),('2019-01-13 03:59:59','2019-01-13 07:59:59','STEEMBNB','4h','0.047240000000000','0.046400000000000','0.715352222245119','0.702632157327975','15.142934425171868','15.142934425171868','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','STEEMBNB','4h','0.047040000000000','0.047560000000000','0.715352222245119','0.723260027422999','15.207317649768687','15.207317649768687','test'),('2019-02-16 03:59:59','2019-02-16 07:59:59','STEEMBNB','4h','0.036060000000000','0.035110000000000','0.715352222245119','0.696506281836554','19.837832009016054','19.837832009016054','test'),('2019-02-25 19:59:59','2019-03-01 19:59:59','STEEMBNB','4h','0.034240000000000','0.036030000000000','0.715352222245119','0.752749432461788','20.892296210429876','20.892296210429876','test'),('2019-03-02 07:59:59','2019-03-02 11:59:59','STEEMBNB','4h','0.035440000000000','0.034370000000000','0.715352222245119','0.693754398379366','20.18488211752593','20.184882117525930','test'),('2019-03-03 03:59:59','2019-03-03 07:59:59','STEEMBNB','4h','0.035740000000000','0.034730000000000','0.715352222245119','0.695136616636065','20.015451098072717','20.015451098072717','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','STEEMBNB','4h','0.035470000000000','0.034600000000000','0.715352222245119','0.697806227507221','20.16781004356129','20.167810043561289','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','STEEMBNB','4h','0.033700000000000','0.031970000000000','0.715352222245119','0.678629393031942','21.22706890935071','21.227068909350709','test'),('2019-03-10 03:59:59','2019-03-10 07:59:59','STEEMBNB','4h','0.035890000000000','0.034380000000000','0.715352222245119','0.685255207600646','19.93179777779657','19.931797777796572','test'),('2019-03-13 23:59:59','2019-03-14 03:59:59','STEEMBNB','4h','0.033680000000000','0.033100000000000','0.715352222245119','0.703033211291967','21.239674057159114','21.239674057159114','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','STEEMBNB','4h','0.032020000000000','0.031670000000000','0.715352222245119','0.707532944362989','22.34079394894188','22.340793948941879','test'),('2019-04-05 15:59:59','2019-04-06 11:59:59','STEEMBNB','4h','0.026560000000000','0.026550000000000','0.715352222245119','0.715082887824093','26.93344210260237','26.933442102602370','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','STEEMBNB','4h','0.026660000000000','0.026540000000000','0.715352222245119','0.712132332272523','26.832416438301536','26.832416438301536','test'),('2019-04-08 03:59:59','2019-04-08 07:59:59','STEEMBNB','4h','0.027110000000000','0.026820000000000','0.715352222245119','0.707699985267949','26.387024059207636','26.387024059207636','test'),('2019-04-08 15:59:59','2019-04-09 11:59:59','STEEMBNB','4h','0.027160000000000','0.026060000000000','0.715352222245119','0.686379930475250','26.3384470635169','26.338447063516899','test'),('2019-05-09 19:59:59','2019-05-10 03:59:59','STEEMBNB','4h','0.015740000000000','0.015700000000000','0.715352222245119','0.713534300460506','45.448044615318864','45.448044615318864','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','STEEMBNB','4h','0.015310000000000','0.015240000000000','0.715352222245119','0.712081506663332','46.72450831124225','46.724508311242253','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','STEEMBNB','4h','0.012690000000000','0.012330000000000','0.715352222245119','0.695058542181428','56.37133351025366','56.371333510253663','test'),('2019-05-28 15:59:59','2019-05-29 07:59:59','STEEMBNB','4h','0.012650000000000','0.012650000000000','0.715352222245119','0.715352222245119','56.549582786175414','56.549582786175414','test'),('2019-05-30 11:59:59','2019-05-30 19:59:59','STEEMBNB','4h','0.012680000000000','0.012670000000000','0.715352222245119','0.714788064341140','56.415790397880045','56.415790397880045','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','STEEMBNB','4h','0.012390000000000','0.012600000000000','0.715352222245119','0.727476836181477','57.73625683979976','57.736256839799758','test'),('2019-06-08 07:59:59','2019-06-08 19:59:59','STEEMBNB','4h','0.012310000000000','0.012150000000000','0.715352222245119','0.706054386700097','58.1114721563866','58.111472156386597','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','STEEMBNB','4h','0.012780000000000','0.012780000000000','0.715352222245119','0.715352222245119','55.97435228835047','55.974352288350467','test'),('2019-06-16 07:59:59','2019-06-17 07:59:59','STEEMBNB','4h','0.012460000000000','0.012320000000000','0.715352222245119','0.707314556826634','57.411895846317734','57.411895846317734','test'),('2019-06-25 23:59:59','2019-06-26 03:59:59','STEEMBNB','4h','0.011660000000000','0.011740000000000','0.715352222245119','0.720260299241655','61.35096245669974','61.350962456699740','test'),('2019-07-04 07:59:59','2019-07-04 11:59:59','STEEMBNB','4h','0.011040000000000','0.010140000000000','0.715352222245119','0.657035464996876','64.79639694249266','64.796396942492663','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:13:35
