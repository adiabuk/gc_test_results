-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-15 15:59:59','2018-07-15 19:59:59','INSBTC','4h','0.000095400000000','0.000092300000000','0.001467500000000','0.001419813941300','15.382599580712789','15.382599580712789','test'),('2018-07-17 11:59:59','2018-07-17 15:59:59','INSBTC','4h','0.000096900000000','0.000094800000000','0.001467500000000','0.001435696594427','15.144478844169248','15.144478844169248','test'),('2018-08-17 03:59:59','2018-08-17 11:59:59','INSBTC','4h','0.000046100000000','0.000046800000000','0.001467500000000','0.001489783080260','31.83297180043384','31.832971800433839','test'),('2018-08-19 15:59:59','2018-08-19 19:59:59','INSBTC','4h','0.000046400000000','0.000046000000000','0.001467500000000','0.001454849137931','31.627155172413794','31.627155172413794','test'),('2018-08-19 23:59:59','2018-08-20 03:59:59','INSBTC','4h','0.000046600000000','0.000047200000000','0.001467500000000','0.001486394849785','31.491416309012877','31.491416309012877','test'),('2018-08-26 23:59:59','2018-08-27 03:59:59','INSBTC','4h','0.000045400000000','0.000044700000000','0.001467500000000','0.001444873348018','32.32378854625551','32.323788546255507','test'),('2018-08-27 07:59:59','2018-08-29 15:59:59','INSBTC','4h','0.000046000000000','0.000045400000000','0.001467500000000','0.001448358695652','31.90217391304348','31.902173913043480','test'),('2018-08-31 19:59:59','2018-09-01 15:59:59','INSBTC','4h','0.000046000000000','0.000047700000000','0.001467500000000','0.001521733695652','31.90217391304348','31.902173913043480','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','INSBTC','4h','0.000047300000000','0.000045300000000','0.001467500000000','0.001405449260042','31.025369978858354','31.025369978858354','test'),('2018-09-04 03:59:59','2018-09-04 07:59:59','INSBTC','4h','0.000046500000000','0.000045400000000','0.001467500000000','0.001432784946237','31.55913978494624','31.559139784946240','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','INSBTC','4h','0.000046400000000','0.000045500000000','0.001467500000000','0.001439035560345','31.627155172413794','31.627155172413794','test'),('2018-09-04 19:59:59','2018-09-04 23:59:59','INSBTC','4h','0.000046600000000','0.000046300000000','0.001467500000000','0.001458052575107','31.491416309012877','31.491416309012877','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','INSBTC','4h','0.000040600000000','0.000041400000000','0.001467500000000','0.001496416256158','36.14532019704434','36.145320197044342','test'),('2018-11-01 11:59:59','2018-11-07 19:59:59','INSBTC','4h','0.000071700000000','0.000089100000000','0.001467500000000','0.001823629707113','20.467224546722456','20.467224546722456','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','INSBTC','4h','0.000077600000000','0.000078500000000','0.001520467912007','0.001538102204801','19.593658659880795','19.593658659880795','test'),('2018-11-18 19:59:59','2018-11-18 23:59:59','INSBTC','4h','0.000078800000000','0.000077400000000','0.001524876485205','0.001497784771001','19.3512244315387','19.351224431538700','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','INSBTC','4h','0.000067600000000','0.000061300000000','0.001524876485205','0.001382765215134','22.557344455695265','22.557344455695265','test'),('2018-12-01 11:59:59','2018-12-01 15:59:59','INSBTC','4h','0.000061300000000','0.000061300000000','0.001524876485205','0.001524876485205','24.875635973980422','24.875635973980422','test'),('2018-12-03 07:59:59','2018-12-03 11:59:59','INSBTC','4h','0.000062400000000','0.000061400000000','0.001524876485205','0.001500439362045','24.43712316033654','24.437123160336540','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','INSBTC','4h','0.000061100000000','0.000061500000000','0.001524876485205','0.001534859309985','24.957061950982','24.957061950981998','test'),('2018-12-08 07:59:59','2018-12-08 11:59:59','INSBTC','4h','0.000063100000000','0.000062300000000','0.001524876485205','0.001505543661304','24.166029876465927','24.166029876465927','test'),('2018-12-13 07:59:59','2018-12-13 15:59:59','INSBTC','4h','0.000061400000000','0.000063200000000','0.001524876485205','0.001569579704641','24.83512190887622','24.835121908876221','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','INSBTC','4h','0.000065100000000','0.000065300000000','0.001524876485205','0.001529561205590','23.42360192327189','23.423601923271889','test'),('2018-12-25 23:59:59','2018-12-26 11:59:59','INSBTC','4h','0.000070500000000','0.000075500000000','0.001524876485205','0.001633023753659','21.62945369085106','21.629453690851062','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','INSBTC','4h','0.000071800000000','0.000073800000000','0.001524876485205','0.001567352153317','21.237834055779945','21.237834055779945','test'),('2019-01-11 19:59:59','2019-01-11 23:59:59','INSBTC','4h','0.000078200000000','0.000077300000000','0.001524876485205','0.001507326755836','19.499699299296672','19.499699299296672','test'),('2019-01-12 11:59:59','2019-01-12 15:59:59','INSBTC','4h','0.000077400000000','0.000078000000000','0.001524876485205','0.001536697233152','19.70124657887597','19.701246578875971','test'),('2019-02-04 15:59:59','2019-02-04 19:59:59','INSBTC','4h','0.000080800000000','0.000080100000000','0.001524876485205','0.001511665921596','18.872233727784653','18.872233727784653','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','INSBTC','4h','0.000071600000000','0.000070400000000','0.001524876485205','0.001499319896067','21.29715761459497','21.297157614594969','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','INSBTC','4h','0.000071200000000','0.000071400000000','0.001524876485205','0.001529159846118','21.416804567485954','21.416804567485954','test'),('2019-03-01 07:59:59','2019-03-04 07:59:59','INSBTC','4h','0.000071800000000','0.000073000000000','0.001524876485205','0.001550361886072','21.237834055779945','21.237834055779945','test'),('2019-03-12 11:59:59','2019-03-14 15:59:59','INSBTC','4h','0.000072300000000','0.000072300000000','0.001524876485205','0.001524876485205','21.090961067842326','21.090961067842326','test'),('2019-03-17 23:59:59','2019-03-18 03:59:59','INSBTC','4h','0.000072400000000','0.000071700000000','0.001524876485205','0.001510133204271','21.06182990614641','21.061829906146411','test'),('2019-03-19 15:59:59','2019-03-19 19:59:59','INSBTC','4h','0.000073000000000','0.000072200000000','0.001524876485205','0.001508165510025','20.88871897541096','20.888718975410960','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','INSBTC','4h','0.000073500000000','0.000074200000000','0.001524876485205','0.001539399118397','20.74661884632653','20.746618846326530','test'),('2019-03-26 15:59:59','2019-03-27 07:59:59','INSBTC','4h','0.000073300000000','0.000073200000000','0.001524876485205','0.001522796162579','20.80322626473397','20.803226264733969','test'),('2019-04-06 19:59:59','2019-04-07 03:59:59','INSBTC','4h','0.000073800000000','0.000073800000000','0.001524876485205','0.001524876485205','20.66228299735772','20.662282997357721','test'),('2019-04-19 15:59:59','2019-04-19 19:59:59','INSBTC','4h','0.000066300000000','0.000065600000000','0.001524876485205','0.001508776733476','22.999645327375564','22.999645327375564','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','INSBTC','4h','0.000066200000000','0.000065200000000','0.001524876485205','0.001501842097211','23.034387994033235','23.034387994033235','test'),('2019-04-20 15:59:59','2019-04-20 19:59:59','INSBTC','4h','0.000067200000000','0.000066400000000','0.001524876485205','0.001506723193714','22.691614363169645','22.691614363169645','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','INSBTC','4h','0.000043500000000','0.000041000000000','0.001524876485205','0.001437239905596','35.0546318437931','35.054631843793103','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','INSBTC','4h','0.000042900000000','0.000043300000000','0.001524876485205','0.001539094447771','35.544906415034966','35.544906415034966','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','INSBTC','4h','0.000043600000000','0.000042800000000','0.001524876485205','0.001496897100155','34.97423131204128','34.974231312041283','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','INSBTC','4h','0.000043700000000','0.000042300000000','0.001524876485205','0.001476024606960','34.89419874610984','34.894198746109844','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','INSBTC','4h','0.000043500000000','0.000042900000000','0.001524876485205','0.001503843706099','35.0546318437931','35.054631843793103','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','INSBTC','4h','0.000043600000000','0.000042600000000','0.001524876485205','0.001489902253893','34.97423131204128','34.974231312041283','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','INSBTC','4h','0.000043100000000','0.000042000000000','0.001524876485205','0.001485958523866','35.379964853944315','35.379964853944315','test'),('2019-06-04 23:59:59','2019-06-08 19:59:59','INSBTC','4h','0.000043100000000','0.000044200000000','0.001524876485205','0.001563794446544','35.379964853944315','35.379964853944315','test'),('2019-06-19 15:59:59','2019-06-19 19:59:59','INSBTC','4h','0.000044100000000','0.000043800000000','0.001524876485205','0.001514503175782','34.57769807721088','34.577698077210883','test'),('2019-06-21 07:59:59','2019-06-21 15:59:59','INSBTC','4h','0.000044000000000','0.000044600000000','0.001524876485205','0.001545670255458','34.65628375465909','34.656283754659093','test'),('2019-06-21 23:59:59','2019-06-22 03:59:59','INSBTC','4h','0.000046500000000','0.000040900000000','0.001524876485205','0.001341235446127','32.79304269258065','32.793042692580649','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:36:02
