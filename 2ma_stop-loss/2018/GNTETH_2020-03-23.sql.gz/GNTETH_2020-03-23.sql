-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-15 19:59:59','2018-10-15 23:59:59','GNTETH','4h','0.000724750000000','0.000711280000000','0.072144500000000','0.070803642580200','99.54398068299413','99.543980682994132','test'),('2018-10-16 03:59:59','2018-10-16 23:59:59','GNTETH','4h','0.000724240000000','0.000718390000000','0.072144500000000','0.071561757642494','99.61407820611952','99.614078206119515','test'),('2018-10-17 07:59:59','2018-10-29 11:59:59','GNTETH','4h','0.000728690000000','0.000810810000000','0.072144500000000','0.080274852193663','99.00575004460057','99.005750044600575','test'),('2018-10-30 03:59:59','2018-11-03 15:59:59','GNTETH','4h','0.000856790000000','0.000854230000000','0.073696188104089','0.073475991508019','86.01429533968563','86.014295339685631','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','GNTETH','4h','0.000821000000000','0.000801000000000','0.073696188104089','0.071900909465743','89.76393191728258','89.763931917282576','test'),('2018-11-22 03:59:59','2018-11-22 11:59:59','GNTETH','4h','0.000740270000000','0.000732180000000','0.073696188104089','0.072890803363708','99.55311994824726','99.553119948247257','test'),('2018-11-25 03:59:59','2018-11-25 11:59:59','GNTETH','4h','0.000732040000000','0.000741350000000','0.073696188104089','0.074633447695435','100.6723513798276','100.672351379827603','test'),('2018-11-27 15:59:59','2018-11-27 19:59:59','GNTETH','4h','0.000727530000000','0.000715770000000','0.073696188104089','0.072504942145704','101.29642503276703','101.296425032767033','test'),('2018-11-28 15:59:59','2018-11-28 19:59:59','GNTETH','4h','0.000733630000000','0.000727060000000','0.073696188104089','0.073036204248680','100.4541636848125','100.454163684812499','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','GNTETH','4h','0.000813570000000','0.000779780000000','0.073696188104089','0.070635364578102','90.58370896676253','90.583708966762529','test'),('2018-12-10 15:59:59','2018-12-10 19:59:59','GNTETH','4h','0.000765190000000','0.000741900000000','0.073696188104089','0.071453105705019','96.31096603992341','96.310966039923414','test'),('2019-01-09 11:59:59','2019-01-09 15:59:59','GNTETH','4h','0.000490090000000','0.000497120000000','0.073696188104089','0.074753308637811','150.3727643985574','150.372764398557393','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GNTETH','4h','0.000503830000000','0.000500830000000','0.073696188104089','0.073257372304489','146.271933199867','146.271933199866993','test'),('2019-02-04 07:59:59','2019-02-04 11:59:59','GNTETH','4h','0.000548810000000','0.000544780000000','0.073696188104089','0.073155025155055','134.28361018219235','134.283610182192348','test'),('2019-02-04 19:59:59','2019-02-04 23:59:59','GNTETH','4h','0.000534580000000','0.000531890000000','0.073696188104089','0.073325349789898','137.85810936452728','137.858109364527280','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','GNTETH','4h','0.000540250000000','0.000539470000000','0.073696188104089','0.073589787314230','136.41126904967885','136.411269049678850','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','GNTETH','4h','0.000501980000000','0.000515740000000','0.073696188104089','0.075716307527796','146.81100462984384','146.811004629843836','test'),('2019-02-26 07:59:59','2019-02-28 03:59:59','GNTETH','4h','0.000469930000000','0.000470630000000','0.073696188104089','0.073805964733955','156.82375695122462','156.823756951224624','test'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GNTETH','4h','0.000491160000000','0.000489070000000','0.073696188104089','0.073382593688547','150.04517490041735','150.045174900417351','test'),('2019-03-17 03:59:59','2019-03-18 03:59:59','GNTETH','4h','0.000540100000000','0.000536790000000','0.073696188104089','0.073244541404173','136.44915405311795','136.449154053117951','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','GNTETH','4h','0.000617860000000','0.000602510000000','0.073696188104089','0.071865293585270','119.27651588400123','119.276515884001228','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GNTETH','4h','0.000617040000000','0.000599380000000','0.073696188104089','0.071586965554630','119.43502545068228','119.435025450682275','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','GNTETH','4h','0.000624370000000','0.000598590000000','0.073696188104089','0.070653300506473','118.03287810767493','118.032878107674932','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','GNTETH','4h','0.000613180000000','0.000612820000000','0.073696188104089','0.073652920829035','120.18687514936724','120.186875149367239','test'),('2019-04-14 19:59:59','2019-04-14 23:59:59','GNTETH','4h','0.000564390000000','0.000551500000000','0.073696188104089','0.072013054340802','130.57670778023885','130.576707780238848','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','GNTETH','4h','0.000567750000000','0.000560240000000','0.073696188104089','0.072721360499225','129.80394205916159','129.803942059161585','test'),('2019-04-21 19:59:59','2019-04-22 03:59:59','GNTETH','4h','0.000547250000000','0.000537890000000','0.073696188104089','0.072435710588046','134.66640128659478','134.666401286594777','test'),('2019-05-21 07:59:59','2019-05-21 11:59:59','GNTETH','4h','0.000393840000000','0.000367150000000','0.073696188104089','0.068701897883446','187.12215139165397','187.122151391653972','test'),('2019-05-24 07:59:59','2019-05-24 11:59:59','GNTETH','4h','0.000378620000000','0.000371650000000','0.073696188104089','0.072339518009838','194.6442029055227','194.644202905522690','test'),('2019-05-28 23:59:59','2019-05-30 03:59:59','GNTETH','4h','0.000377410000000','0.000369130000000','0.073696188104089','0.072079367040784','195.26824436048062','195.268244360480622','test'),('2019-05-31 07:59:59','2019-05-31 11:59:59','GNTETH','4h','0.000387160000000','0.000367010000000','0.073696188104089','0.069860620921794','190.35072864988376','190.350728649883763','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','GNTETH','4h','0.000365360000000','0.000365360000000','0.073696188104089','0.073696188104089','201.70841937839117','201.708419378391170','test'),('2019-06-29 15:59:59','2019-06-29 19:59:59','GNTETH','4h','0.000327640000000','0.000318770000000','0.073696188104089','0.071701055676781','224.93037511930473','224.930375119304728','test'),('2019-06-30 23:59:59','2019-07-01 03:59:59','GNTETH','4h','0.000322570000000','0.000320540000000','0.073696188104089','0.073232402687431','228.4657224915181','228.465722491518108','test'),('2019-07-01 15:59:59','2019-07-01 19:59:59','GNTETH','4h','0.000321490000000','0.000321550000000','0.073696188104089','0.073709942097327','229.23322064166535','229.233220641665355','test'),('2019-07-02 19:59:59','2019-07-02 23:59:59','GNTETH','4h','0.000323000000000','0.000318080000000','0.073696188104089','0.072573633164547','228.16157307767492','228.161573077674916','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','GNTETH','4h','0.000324820000000','0.000319410000000','0.073696188104089','0.072468750207275','226.8831602243981','226.883160224398097','test'),('2019-07-06 07:59:59','2019-07-07 11:59:59','GNTETH','4h','0.000323060000000','0.000317980000000','0.073696188104089','0.072537342578277','228.11919799445613','228.119197994456130','test'),('2019-07-19 19:59:59','2019-07-20 03:59:59','GNTETH','4h','0.000284290000000','0.000284000000000','0.073696188104089','0.073621011718883','259.22891450310954','259.228914503109536','test'),('2019-07-24 03:59:59','2019-07-24 07:59:59','GNTETH','4h','0.000289840000000','0.000289730000000','0.073696188104089','0.073668218946307','254.2650707427857','254.265070742785696','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','GNTETH','4h','0.000289040000000','0.000288640000000','0.073696188104089','0.073594200575575','254.9688212845592','254.968821284559198','test'),('2019-07-25 23:59:59','2019-07-26 03:59:59','GNTETH','4h','0.000291310000000','0.000289160000000','0.073696188104089','0.073152276791660','252.9820057810889','252.982005781088901','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','GNTETH','4h','0.000290000000000','0.000287480000000','0.073696188104089','0.073055793641943','254.12478656582414','254.124786565824138','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','GNTETH','4h','0.000290330000000','0.000289880000000','0.073696188104089','0.073581961931641','253.8359387734268','253.835938773426790','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','GNTETH','4h','0.000292110000000','0.000289000000000','0.073696188104089','0.072911568799705','252.28916539690184','252.289165396901836','test'),('2019-07-30 15:59:59','2019-08-01 19:59:59','GNTETH','4h','0.000306810000000','0.000286900000000','0.073696188104089','0.068913778452668','240.20138882073266','240.201388820732660','test'),('2019-08-09 15:59:59','2019-08-09 19:59:59','GNTETH','4h','0.000274140000000','0.000265920000000','0.073696188104089','0.071486431533667','268.8268333847268','268.826833384726797','test'),('2019-08-12 15:59:59','2019-08-12 19:59:59','GNTETH','4h','0.000270400000000','0.000267260000000','0.073696188104089','0.072840396570632','272.54507434944156','272.545074349441563','test'),('2019-08-13 15:59:59','2019-08-13 19:59:59','GNTETH','4h','0.000268740000000','0.000267010000000','0.073696188104089','0.073221772663812','274.22857819486865','274.228578194868646','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','GNTETH','4h','0.000269560000000','0.000267250000000','0.073696188104089','0.073064647094590','273.3943764063251','273.394376406325080','test'),('2019-08-14 19:59:59','2019-08-15 01:59:59','GNTETH','4h','0.000273000000000','0.000269070000000','0.073696188104089','0.072635286934678','269.94940697468496','269.949406974684962','test'),('2019-08-17 03:59:59','2019-08-17 11:59:59','GNTETH','4h','0.000280020000000','0.000274000000000','0.073696188104089','0.072111833228057','263.18187309509676','263.181873095096762','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','GNTETH','4h','0.000277990000000','0.000268210000000','0.073696188104089','0.071103473547242','265.10373791895034','265.103737918950344','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','GNTETH','4h','0.000275930000000','0.000263790000000','0.073696188104089','0.070453801543789','267.0829127100677','267.082912710067717','test'),('2019-08-21 15:59:59','2019-08-21 19:59:59','GNTETH','4h','0.000268840000000','0.000268770000000','0.073696188104089','0.073676999243922','274.12657381375163','274.126573813751634','test'),('2019-09-04 03:59:59','2019-09-04 11:59:59','GNTETH','4h','0.000338870000000','0.000332650000000','0.073696188104089','0.072343485622289','217.47628324752557','217.476283247525572','test'),('2019-09-06 19:59:59','2019-09-07 03:59:59','GNTETH','4h','0.000335200000000','0.000334120000000','0.073696188104089','0.073458742151964','219.85736307902445','219.857363079024452','test'),('2019-09-09 07:59:59','2019-09-09 11:59:59','GNTETH','4h','0.000335620000000','0.000327560000000','0.073696188104089','0.071926355328572','219.58223021300577','219.582230213005772','test'),('2019-09-09 15:59:59','2019-09-09 19:59:59','GNTETH','4h','0.000330890000000','0.000335690000000','0.073696188104089','0.074765249432324','222.7211100489256','222.721110048925595','test'),('2019-09-13 03:59:59','2019-09-14 03:59:59','GNTETH','4h','0.000332680000000','0.000330480000000','0.073696188104089','0.073208838056509','221.5227489001112','221.522748900111196','test'),('2019-10-05 07:59:59','2019-10-05 15:59:59','GNTETH','4h','0.000278900000000','0.000275360000000','0.073696188104089','0.072760782919835','264.2387526141592','264.238752614159182','test'),('2019-10-11 15:59:59','2019-10-11 23:59:59','GNTETH','4h','0.000279720000000','0.000283020000000','0.073696188104089','0.074565619752679','263.4641359362541','263.464135936254081','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:27:27
