-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-04 19:59:59','2018-10-04 23:59:59','ADAUSDT','4h','0.082410000000000','0.081640000000000','15.000000000000000','14.859847105933747','182.01674554058974','182.016745540589739','test'),('2018-10-05 19:59:59','2018-10-06 11:59:59','ADAUSDT','4h','0.082160000000000','0.082280000000000','15.000000000000000','15.021908471275561','182.57059396299903','182.570593962999027','test'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADAUSDT','4h','0.083570000000000','0.078050000000000','15.000000000000000','14.009213832715087','179.49024769654181','179.490247696541815','test'),('2018-10-17 03:59:59','2018-10-17 07:59:59','ADAUSDT','4h','0.079000000000000','0.078110000000000','15.000000000000000','14.831012658227849','189.873417721519','189.873417721518990','test'),('2018-10-17 15:59:59','2018-10-18 15:59:59','ADAUSDT','4h','0.079440000000000','0.078020000000000','15.000000000000000','14.731873111782480','188.82175226586102','188.821752265861022','test'),('2018-10-20 11:59:59','2018-10-20 15:59:59','ADAUSDT','4h','0.078370000000000','0.078000000000000','15.000000000000000','14.929182084981498','191.39977032027562','191.399770320275621','test'),('2018-10-21 03:59:59','2018-10-21 07:59:59','ADAUSDT','4h','0.078650000000000','0.078490000000000','15.000000000000000','14.969485060394152','190.71837253655437','190.718372536554369','test'),('2018-11-04 07:59:59','2018-11-09 11:59:59','ADAUSDT','4h','0.074360000000000','0.075900000000000','15.000000000000000','15.310650887573964','201.72135556750942','201.721355567509420','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','ADAUSDT','4h','0.076060000000000','0.075480000000000','15.000000000000000','14.885616618459112','197.2127267946358','197.212726794635813','test'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADAUSDT','4h','0.076870000000000','0.075100000000000','15.000000000000000','14.654611682060622','195.1346429036035','195.134642903603492','test'),('2018-11-11 19:59:59','2018-11-12 07:59:59','ADAUSDT','4h','0.076750000000000','0.075770000000000','15.000000000000000','14.808469055374594','195.4397394136808','195.439739413680797','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ADAUSDT','4h','0.033040000000000','0.032410000000000','15.000000000000000','14.713983050847459','453.9951573849879','453.995157384987920','test'),('2018-12-28 15:59:59','2019-01-01 03:59:59','ADAUSDT','4h','0.039220000000000','0.040200000000000','15.000000000000000','15.374808771035186','382.45792962774095','382.457929627740953','test'),('2019-01-16 15:59:59','2019-01-17 11:59:59','ADAUSDT','4h','0.044130000000000','0.044340000000000','15.000000000000000','15.071380013596192','339.9048266485384','339.904826648538403','test'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ADAUSDT','4h','0.039880000000000','0.040140000000000','15.000000000000000','15.097793380140423','376.1283851554664','376.128385155466390','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ADAUSDT','4h','0.043160000000000','0.042920000000000','15.000000000000000','14.916589434661725','347.54402224281745','347.544022242817448','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','ADAUSDT','4h','0.042840000000000','0.042540000000000','15.000000000000000','14.894957983193276','350.14005602240894','350.140056022408942','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ADAUSDT','4h','0.043000000000000','0.042640000000000','15.000000000000000','14.874418604651163','348.8372093023256','348.837209302325618','test'),('2019-03-07 15:59:59','2019-03-07 23:59:59','ADAUSDT','4h','0.042840000000000','0.042750000000000','15.000000000000000','14.968487394957982','350.14005602240894','350.140056022408942','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','ADAUSDT','4h','0.043070000000000','0.042430000000000','15.000000000000000','14.777107035059206','348.27025771999075','348.270257719990752','test'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAUSDT','4h','0.083750000000000','0.082970000000000','15.000000000000000','14.860298507462685','179.1044776119403','179.104477611940297','test'),('2019-04-12 11:59:59','2019-04-12 23:59:59','ADAUSDT','4h','0.083440000000000','0.082500000000000','15.000000000000000','14.831016299137104','179.76989453499522','179.769894534995217','test'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ADAUSDT','4h','0.084160000000000','0.082360000000000','15.000000000000000','14.679182509505704','178.2319391634981','178.231939163498112','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','ADAUSDT','4h','0.082710000000000','0.082160000000000','15.000000000000000','14.900253899165758','181.35654697134567','181.356546971345665','test'),('2019-04-17 19:59:59','2019-04-17 23:59:59','ADAUSDT','4h','0.082710000000000','0.082440000000000','15.000000000000000','14.951033732317736','181.35654697134567','181.356546971345665','test'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ADAUSDT','4h','0.069500000000000','0.069000000000000','15.000000000000000','14.892086330935253','215.82733812949638','215.827338129496383','test'),('2019-05-24 07:59:59','2019-05-24 23:59:59','ADAUSDT','4h','0.080360000000000','0.080620000000000','15.000000000000000','15.048531607765057','186.66002986560477','186.660029865604770','test'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.082760000000000','0.083920000000000','15.000000000000000','15.210246495891734','181.24697921701306','181.246979217013063','test'),('2019-05-31 19:59:59','2019-06-01 15:59:59','ADAUSDT','4h','0.086540000000000','0.087350000000000','15.000000000000000','15.140397504044373','173.33025190663275','173.330251906632753','test'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADAUSDT','4h','0.085080000000000','0.083640000000000','15.000000000000000','14.746121297602258','176.30465444287728','176.304654442877279','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ADAUSDT','4h','0.088420000000000','0.087420000000000','15.000000000000000','14.830355123275277','169.6448767247229','169.644876724722906','test'),('2019-06-14 23:59:59','2019-06-18 07:59:59','ADAUSDT','4h','0.090080000000000','0.089290000000000','15.000000000000000','14.868450266429841','166.51865008880995','166.518650088809949','test'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ADAUSDT','4h','0.089430000000000','0.089960000000000','15.000000000000000','15.088896343508889','167.7289500167729','167.728950016772899','test'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAUSDT','4h','0.064740000000000','0.062620000000000','15.000000000000000','14.508804448563483','231.69601482854492','231.696014828544918','test'),('2019-07-26 11:59:59','2019-07-26 15:59:59','ADAUSDT','4h','0.061410000000000','0.061230000000000','15.000000000000000','14.956033219345384','244.2598925256473','244.259892525647302','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ADAUSDT','4h','0.061570000000000','0.060820000000000','15.000000000000000','14.817281143414000','243.62514211466623','243.625142114666232','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','ADAUSDT','4h','0.060900000000000','0.060470000000000','15.000000000000000','14.894088669950738','246.30541871921181','246.305418719211815','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','15.000000000000000','14.903289799966936','247.97487187964953','247.974871879649527','test'),('2019-08-11 19:59:59','2019-08-11 23:59:59','ADAUSDT','4h','0.055350000000000','0.054720000000000','15.000000000000000','14.829268292682926','271.00271002710025','271.002710027100250','test'),('2019-08-19 07:59:59','2019-08-19 11:59:59','ADAUSDT','4h','0.050730000000000','0.050250000000000','15.000000000000000','14.858072146658783','295.68302779420463','295.683027794204634','test'),('2019-08-23 23:59:59','2019-08-24 03:59:59','ADAUSDT','4h','0.049640000000000','0.049530000000000','15.000000000000000','14.966760676873490','302.17566478646256','302.175664786462562','test'),('2019-08-24 19:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.050280000000000','0.049780000000000','15.000000000000000','14.850835322195703','298.32935560859187','298.329355608591868','test'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ADAUSDT','4h','0.049990000000000','0.049930000000000','15.000000000000000','14.981996399279856','300.06001200240047','300.060012002400470','test'),('2019-09-07 23:59:59','2019-09-09 03:59:59','ADAUSDT','4h','0.045970000000000','0.045700000000000','15.000000000000000','14.911899064607352','326.2997607135088','326.299760713508817','test'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','15.000000000000000','14.931788653096577','324.81593763534','324.815937635339992','test'),('2019-09-14 19:59:59','2019-09-15 03:59:59','ADAUSDT','4h','0.046780000000000','0.046190000000000','15.000000000000000','14.810816588285592','320.6498503634032','320.649850363403175','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:18:20
