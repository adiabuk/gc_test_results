-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 03:59:59','2018-07-06 07:59:59','GTOETH','4h','0.000297330000000','0.000315200000000','0.072144500000000','0.076480497763428','242.64117310732183','242.641173107321833','test'),('2018-07-06 11:59:59','2018-07-06 15:59:59','GTOETH','4h','0.000324000000000','0.000333100000000','0.073228499440857','0.075285225814042','226.01388716313886','226.013887163138861','test'),('2018-07-10 19:59:59','2018-07-10 23:59:59','GTOETH','4h','0.000334730000000','0.000329110000000','0.073742681034153','0.072504567129179','220.30496529786168','220.304965297861685','test'),('2018-07-12 11:59:59','2018-07-12 15:59:59','GTOETH','4h','0.000327100000000','0.000323850000000','0.073742681034153','0.073009988544514','225.44384296592176','225.443842965921760','test'),('2018-07-12 19:59:59','2018-07-13 03:59:59','GTOETH','4h','0.000334160000000','0.000328500000000','0.073742681034153','0.072493627961812','220.68075483047943','220.680754830479430','test'),('2018-07-21 07:59:59','2018-07-21 11:59:59','GTOETH','4h','0.000370000000000','0.000368890000000','0.073742681034153','0.073521452991051','199.30454333554866','199.304543335548658','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','GTOETH','4h','0.000289660000000','0.000284570000000','0.073742681034153','0.072446850589964','254.58358432007526','254.583584320075261','test'),('2018-08-19 07:59:59','2018-08-22 19:59:59','GTOETH','4h','0.000285870000000','0.000282460000000','0.073742681034153','0.072863041539535','257.95879607567423','257.958796075674229','test'),('2018-08-23 19:59:59','2018-08-30 11:59:59','GTOETH','4h','0.000290400000000','0.000296100000000','0.073742681034153','0.075190109690815','253.93485204598142','253.934852045981415','test'),('2018-08-31 07:59:59','2018-08-31 11:59:59','GTOETH','4h','0.000304100000000','0.000299080000000','0.073742681034153','0.072525356934214','242.4948406252976','242.494840625297599','test'),('2018-08-31 19:59:59','2018-09-01 15:59:59','GTOETH','4h','0.000302940000000','0.000301380000000','0.073742681034153','0.073362940549525','243.42338758220438','243.423387582204384','test'),('2018-09-03 15:59:59','2018-09-05 11:59:59','GTOETH','4h','0.000305390000000','0.000299160000000','0.073742681034153','0.072238319716354','241.47051650071384','241.470516500713842','test'),('2018-09-06 15:59:59','2018-09-06 19:59:59','GTOETH','4h','0.000306790000000','0.000308260000000','0.073742681034153','0.074096022867721','240.3685942636755','240.368594263675504','test'),('2018-09-16 23:59:59','2018-09-17 03:59:59','GTOETH','4h','0.000300630000000','0.000293630000000','0.073742681034153','0.072025624295840','245.29381975901606','245.293819759016060','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','GTOETH','4h','0.000299270000000','0.000294150000000','0.073742681034153','0.072481069356087','246.40853087229925','246.408530872299252','test'),('2018-09-18 03:59:59','2018-09-18 07:59:59','GTOETH','4h','0.000299900000000','0.000294240000000','0.073742681034153','0.072350938537810','245.8909004139813','245.890900413981313','test'),('2018-09-20 11:59:59','2018-09-20 15:59:59','GTOETH','4h','0.000297430000000','0.000290370000000','0.073742681034153','0.071992274793689','247.93289524981677','247.932895249816767','test'),('2018-09-20 19:59:59','2018-09-20 23:59:59','GTOETH','4h','0.000296880000000','0.000283270000000','0.073742681034153','0.070362062976774','248.39221582509094','248.392215825090943','test'),('2018-09-24 23:59:59','2018-09-25 03:59:59','GTOETH','4h','0.000288740000000','0.000290400000000','0.073742681034153','0.074166636324437','255.3947531833241','255.394753183324099','test'),('2018-10-02 07:59:59','2018-10-03 03:59:59','GTOETH','4h','0.000298920000000','0.000296140000000','0.073742681034153','0.073056863245865','246.69704614663792','246.697046146637916','test'),('2018-10-15 19:59:59','2018-10-25 03:59:59','GTOETH','4h','0.000319300000000','0.000344540000000','0.073742681034153','0.079571886387432','230.95108372738179','230.951083727381786','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','GTOETH','4h','0.000348150000000','0.000344420000000','0.073742681034153','0.072952618703958','211.8129571568376','211.812957156837598','test'),('2018-11-01 15:59:59','2018-11-02 03:59:59','GTOETH','4h','0.000348060000000','0.000342590000000','0.073742681034153','0.072583764567863','211.86772692683158','211.867726926831580','test'),('2018-11-28 03:59:59','2018-11-30 11:59:59','GTOETH','4h','0.000260990000000','0.000258210000000','0.073742681034153','0.072957192497140','282.5498334578068','282.549833457806812','test'),('2018-12-14 11:59:59','2018-12-14 15:59:59','GTOETH','4h','0.000252460000000','0.000260810000000','0.073742681034153','0.076181686764309','292.09649462945816','292.096494629458164','test'),('2018-12-18 07:59:59','2018-12-18 11:59:59','GTOETH','4h','0.000249960000000','0.000247410000000','0.073742681034153','0.072990385320290','295.0179270049328','295.017927004932801','test'),('2018-12-18 19:59:59','2018-12-18 23:59:59','GTOETH','4h','0.000250330000000','0.000244240000000','0.073742681034153','0.071948677408946','294.58187606021255','294.581876060212551','test'),('2019-01-08 03:59:59','2019-01-08 07:59:59','GTOETH','4h','0.000182300000000','0.000178840000000','0.073742681034153','0.072343066791815','404.51278680281405','404.512786802814048','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','GTOETH','4h','0.000182870000000','0.000179270000000','0.073742681034153','0.072290974074439','403.25193325396737','403.251933253967366','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','GTOETH','4h','0.000183940000000','0.000180840000000','0.073742681034153','0.072499871905057','400.906170676052','400.906170676052000','test'),('2019-01-11 11:59:59','2019-01-11 19:59:59','GTOETH','4h','0.000188000000000','0.000185930000000','0.073742681034153','0.072930727046171','392.24830337315433','392.248303373154329','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','GTOETH','4h','0.000203220000000','0.000200770000000','0.073742681034153','0.072853646645148','362.8711791858725','362.871179185872506','test'),('2019-01-29 03:59:59','2019-01-29 07:59:59','GTOETH','4h','0.000237280000000','0.000230600000000','0.073742681034153','0.071666648038080','310.7833826456212','310.783382645621202','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','GTOETH','4h','0.000243200000000','0.000234280000000','0.073742681034153','0.071037974147539','303.21826083122124','303.218260831221244','test'),('2019-02-06 11:59:59','2019-02-06 15:59:59','GTOETH','4h','0.000239080000000','0.000223000000000','0.073742681034153','0.068782908945190','308.44353787080894','308.443537870808939','test'),('2019-02-08 03:59:59','2019-02-08 19:59:59','GTOETH','4h','0.000229500000000','0.000234440000000','0.073742681034153','0.075329996259899','321.3188716085098','321.318871608509824','test'),('2019-02-09 07:59:59','2019-02-10 07:59:59','GTOETH','4h','0.000233680000000','0.000228960000000','0.073742681034153','0.072253184909191','315.5712129157523','315.571212915752312','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','GTOETH','4h','0.000228540000000','0.000221480000000','0.073742681034153','0.071464640743171','322.66859645643217','322.668596456432169','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','GTOETH','4h','0.000226150000000','0.000213240000000','0.073742681034153','0.069533005985951','326.0786249575636','326.078624957563591','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','GTOETH','4h','0.000240200000000','0.000233750000000','0.073742681034153','0.071762496635026','307.0053331979725','307.005333197972504','test'),('2019-02-26 03:59:59','2019-03-05 03:59:59','GTOETH','4h','0.000212470000000','0.000226280000000','0.073742681034153','0.078535764411014','347.0733799320045','347.073379932004514','test'),('2019-03-07 19:59:59','2019-03-08 07:59:59','GTOETH','4h','0.000223060000000','0.000223630000000','0.073742681034153','0.073931120593866','330.5957187938358','330.595718793835772','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','GTOETH','4h','0.000251290000000','0.000247840000000','0.073742681034153','0.072730256148293','293.4564886551515','293.456488655151475','test'),('2019-03-17 11:59:59','2019-03-17 15:59:59','GTOETH','4h','0.000256460000000','0.000253130000000','0.073742681034153','0.072785170592588','287.54067314260703','287.540673142607034','test'),('2019-03-24 11:59:59','2019-03-24 19:59:59','GTOETH','4h','0.000256530000000','0.000254550000000','0.073742681034153','0.073173505856015','287.4622111805754','287.462211180575423','test'),('2019-03-25 07:59:59','2019-03-25 11:59:59','GTOETH','4h','0.000268840000000','0.000259410000000','0.073742681034153','0.071156036627993','274.29951284835965','274.299512848359655','test'),('2019-03-28 15:59:59','2019-03-28 19:59:59','GTOETH','4h','0.000255590000000','0.000256920000000','0.073742681034153','0.074126411875639','288.51942968877114','288.519429688771140','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','GTOETH','4h','0.000257560000000','0.000253830000000','0.073742681034153','0.072674734923509','286.3126301993827','286.312630199382681','test'),('2019-04-14 15:59:59','2019-04-14 19:59:59','GTOETH','4h','0.000222180000000','0.000218480000000','0.073742681034153','0.072514632065630','331.9051266277478','331.905126627747791','test'),('2019-04-19 03:59:59','2019-04-19 15:59:59','GTOETH','4h','0.000228360000000','0.000225400000000','0.073742681034153','0.072786829151770','322.92293323766427','322.922933237664267','test'),('2019-04-22 23:59:59','2019-04-23 03:59:59','GTOETH','4h','0.000215640000000','0.000210050000000','0.073742681034153','0.071831061728918','341.9712531726628','341.971253172662784','test'),('2019-04-23 19:59:59','2019-04-23 23:59:59','GTOETH','4h','0.000220060000000','0.000215830000000','0.073742681034153','0.072325196980829','335.10261307894666','335.102613078946661','test'),('2019-05-21 03:59:59','2019-05-21 23:59:59','GTOETH','4h','0.000139170000000','0.000132590000000','0.073742681034153','0.070256104608165','529.8748367762664','529.874836776266420','test'),('2019-05-28 03:59:59','2019-05-28 07:59:59','GTOETH','4h','0.000144250000000','0.000139870000000','0.073742681034153','0.071503561845733','511.2144265799168','511.214426579916790','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:36:18
