-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-17 19:59:59','2018-05-17 23:59:59','DGDBTC','4h','0.025870000000000','0.024885000000000','0.001467500000000','0.001411624951681','0.056725937379203714','0.056725937379204','test'),('2018-06-04 07:59:59','2018-06-10 03:59:59','DGDBTC','4h','0.019800000000000','0.019845000000000','0.001467500000000','0.001470835227273','0.07411616161616161','0.074116161616162','test'),('2018-07-02 15:59:59','2018-07-03 11:59:59','DGDBTC','4h','0.016313000000000','0.015810000000000','0.001467500000000','0.001422250658984','0.08995892846196285','0.089958928461963','test'),('2018-07-03 23:59:59','2018-07-04 00:22:27','DGDBTC','4h','0.015901000000000','0.015861000000000','0.001467500000000','0.001463808408276','0.09228979309477392','0.092289793094774','test'),('2018-07-04 19:59:59','2018-07-04 23:59:59','DGDBTC','4h','0.016026000000000','0.016024000000000','0.001467500000000','0.001467316860102','0.09156994883314615','0.091569948833146','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','DGDBTC','4h','0.014941000000000','0.015041000000000','0.001467500000000','0.001477321966401','0.09821966401177967','0.098219664011780','test'),('2018-07-18 19:59:59','2018-07-18 23:59:59','DGDBTC','4h','0.014938000000000','0.014148000000000','0.001467500000000','0.001389890882314','0.09823938947650289','0.098239389476503','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','DGDBTC','4h','0.009697000000000','0.009408000000000','0.001467500000000','0.001423764050737','0.15133546457667318','0.151335464576673','test'),('2018-09-21 19:59:59','2018-09-22 03:59:59','DGDBTC','4h','0.005804000000000','0.005805000000000','0.001467500000000','0.001467752842867','0.25284286698828395','0.252842866988284','test'),('2018-09-22 15:59:59','2018-09-23 15:59:59','DGDBTC','4h','0.005976000000000','0.005876000000000','0.001467500000000','0.001442943440428','0.24556559571619813','0.245565595716198','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','DGDBTC','4h','0.005803000000000','0.005795000000000','0.001467500000000','0.001465476908496','0.25288643804928485','0.252886438049285','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','DGDBTC','4h','0.005724000000000','0.005684000000000','0.001467500000000','0.001457244933613','0.2563766596785465','0.256376659678547','test'),('2018-09-29 15:59:59','2018-09-29 23:59:59','DGDBTC','4h','0.005762000000000','0.005738000000000','0.001467500000000','0.001461387539049','0.25468587296077755','0.254685872960778','test'),('2018-10-03 11:59:59','2018-10-03 15:59:59','DGDBTC','4h','0.005771000000000','0.005881000000000','0.001467500000000','0.001495471755328','0.254288684803327','0.254288684803327','test'),('2018-10-03 23:59:59','2018-10-04 07:59:59','DGDBTC','4h','0.005772000000000','0.005713000000000','0.001467500000000','0.001452499566875','0.25424462924462926','0.254244629244629','test'),('2018-10-04 15:59:59','2018-10-04 19:59:59','DGDBTC','4h','0.005804000000000','0.005785000000000','0.001467500000000','0.001462695985527','0.25284286698828395','0.252842866988284','test'),('2018-10-12 11:59:59','2018-10-12 15:59:59','DGDBTC','4h','0.006326000000000','0.006029000000000','0.001467500000000','0.001398602197281','0.23197913373379703','0.231979133733797','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','DGDBTC','4h','0.006452000000000','0.006261000000000','0.001467500000000','0.001424057269064','0.22744885306881588','0.227448853068816','test'),('2018-10-30 03:59:59','2018-10-30 07:59:59','DGDBTC','4h','0.006495000000000','0.006345000000000','0.001467500000000','0.001433608545035','0.22594303310238648','0.225943033102386','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','DGDBTC','4h','0.006375000000000','0.006371000000000','0.001467500000000','0.001466579215686','0.23019607843137257','0.230196078431373','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','DGDBTC','4h','0.006569000000000','0.006353000000000','0.001467500000000','0.001419246080073','0.22339777743948852','0.223397777439489','test'),('2018-11-05 03:59:59','2018-11-05 07:59:59','DGDBTC','4h','0.006410000000000','0.006386000000000','0.001467500000000','0.001462005460218','0.22893915756630268','0.228939157566303','test'),('2018-11-07 23:59:59','2018-11-08 03:59:59','DGDBTC','4h','0.006374000000000','0.006345000000000','0.001467500000000','0.001460823266395','0.2302321932852212','0.230232193285221','test'),('2018-12-02 03:59:59','2018-12-02 07:59:59','DGDBTC','4h','0.004664000000000','0.004562000000000','0.001467500000000','0.001435406303602','0.3146440823327616','0.314644082332762','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','DGDBTC','4h','0.004057000000000','0.004031000000000','0.001467500000000','0.001458095267439','0.3617204831156027','0.361720483115603','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','DGDBTC','4h','0.004029000000000','0.004050000000000','0.001467500000000','0.001475148920328','0.36423430131546297','0.364234301315463','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','DGDBTC','4h','0.004778000000000','0.004630000000000','0.001467500000000','0.001422043742152','0.30713687735454165','0.307136877354542','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','DGDBTC','4h','0.005008000000000','0.004943000000000','0.001467500000000','0.001448452975240','0.2930311501597444','0.293031150159744','test'),('2019-01-17 15:59:59','2019-01-18 07:59:59','DGDBTC','4h','0.004939000000000','0.004903000000000','0.001467500000000','0.001456803502733','0.29712492407369917','0.297124924073699','test'),('2019-01-19 07:59:59','2019-01-20 15:59:59','DGDBTC','4h','0.004960000000000','0.004930000000000','0.001467500000000','0.001458623991935','0.295866935483871','0.295866935483871','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','DGDBTC','4h','0.004200000000000','0.004123000000000','0.001467500000000','0.001440595833333','0.34940476190476194','0.349404761904762','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','DGDBTC','4h','0.004121000000000','0.004112000000000','0.001467500000000','0.001464295074011','0.356102887648629','0.356102887648629','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','DGDBTC','4h','0.004177000000000','0.004100000000000','0.001467500000000','0.001440447689729','0.3513287048120661','0.351328704812066','test'),('2019-03-01 19:59:59','2019-03-02 19:59:59','DGDBTC','4h','0.004298000000000','0.004154000000000','0.001467500000000','0.001418332945556','0.34143787808282927','0.341437878082829','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','DGDBTC','4h','0.004233000000000','0.004062000000000','0.001467500000000','0.001408217576187','0.34668084101110325','0.346680841011103','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','DGDBTC','4h','0.004072000000000','0.004037000000000','0.001467500000000','0.001454886419450','0.36038801571709234','0.360388015717092','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','DGDBTC','4h','0.004060000000000','0.004012000000000','0.001467500000000','0.001450150246305','0.36145320197044334','0.361453201970443','test'),('2019-03-11 11:59:59','2019-03-12 01:59:59','DGDBTC','4h','0.004056000000000','0.004105000000000','0.001467500000000','0.001485228673570','0.3618096646942801','0.361809664694280','test'),('2019-03-19 07:59:59','2019-03-19 11:59:59','DGDBTC','4h','0.004219000000000','0.004172000000000','0.001467500000000','0.001451151931737','0.34783123963024415','0.347831239630244','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','DGDBTC','4h','0.004420000000000','0.004254000000000','0.001467500000000','0.001412385746606','0.33201357466063347','0.332013574660633','test'),('2019-03-21 19:59:59','2019-03-26 11:59:59','DGDBTC','4h','0.004247000000000','0.004493000000000','0.001467500000000','0.001552502354603','0.3455380268424771','0.345538026842477','test'),('2019-04-18 19:59:59','2019-04-19 11:59:59','DGDBTC','4h','0.004591000000000','0.004544000000000','0.001467500000000','0.001452476584622','0.3196471357002832','0.319647135700283','test'),('2019-04-26 11:59:59','2019-04-29 15:59:59','DGDBTC','4h','0.005146000000000','0.005405000000000','0.001467500000000','0.001541359794015','0.285172949863972','0.285172949863972','test'),('2019-05-03 19:59:59','2019-05-03 23:59:59','DGDBTC','4h','0.005513000000000','0.005240000000000','0.001467500000000','0.001394830400871','0.2661890077997461','0.266189007799746','test'),('2019-05-08 07:59:59','2019-05-08 15:59:59','DGDBTC','4h','0.005670000000000','0.005362000000000','0.001467500000000','0.001387783950617','0.2588183421516755','0.258818342151675','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:12:56
