-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-23 03:59:59','2018-11-23 11:59:59','THETABTC','4h','0.000012940000000','0.000012750000000','0.001467500000000','0.001445952472952','113.4080370942813','113.408037094281298','test'),('2018-11-30 07:59:59','2018-11-30 15:59:59','THETABTC','4h','0.000014470000000','0.000020150000000','0.001467500000000','0.002043546993780','101.41672425708363','101.416724257083629','test'),('2018-12-22 03:59:59','2018-12-22 11:59:59','THETABTC','4h','0.000015130000000','0.000014300000000','0.001606124866683','0.001518016232225','106.15498127448778','106.154981274487781','test'),('2018-12-28 03:59:59','2018-12-28 07:59:59','THETABTC','4h','0.000014200000000','0.000013580000000','0.001606124866683','0.001535998287997','113.10738497767605','113.107384977676048','test'),('2018-12-29 03:59:59','2018-12-29 07:59:59','THETABTC','4h','0.000013590000000','0.000013200000000','0.001606124866683','0.001560032983092','118.18431690088299','118.184316900882990','test'),('2019-01-03 03:59:59','2019-01-03 11:59:59','THETABTC','4h','0.000013290000000','0.000012940000000','0.001606124866683','0.001563826619630','120.85213443814898','120.852134438148980','test'),('2019-01-06 15:59:59','2019-01-06 19:59:59','THETABTC','4h','0.000013100000000','0.000012850000000','0.001606124866683','0.001575473628769','122.60495165519083','122.604951655190831','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','THETABTC','4h','0.000012770000000','0.000012670000000','0.001606124866683','0.001593547538048','125.77328634949099','125.773286349490988','test'),('2019-01-13 07:59:59','2019-01-13 11:59:59','THETABTC','4h','0.000012850000000','0.000012710000000','0.001606124866683','0.001588626230003','124.99026199867703','124.990261998677028','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','THETABTC','4h','0.000012980000000','0.000012580000000','0.001606124866683','0.001556629493288','123.73843348867489','123.738433488674886','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','THETABTC','4h','0.000012710000000','0.000012900000000','0.001606124866683','0.001630134601118','126.36702334248622','126.367023342486220','test'),('2019-01-19 15:59:59','2019-01-20 07:59:59','THETABTC','4h','0.000013360000000','0.000013130000000','0.001606124866683','0.001578474513439','120.21892714693112','120.218927146931122','test'),('2019-02-19 03:59:59','2019-02-19 07:59:59','THETABTC','4h','0.000023020000000','0.000022740000000','0.001606124866683','0.001586589029903','69.7708456421807','69.770845642180703','test'),('2019-02-19 23:59:59','2019-02-20 03:59:59','THETABTC','4h','0.000023240000000','0.000023630000000','0.001606124866683','0.001633077908766','69.11036431510327','69.110364315103268','test'),('2019-02-25 03:59:59','2019-02-28 07:59:59','THETABTC','4h','0.000025470000000','0.000035800000000','0.001606124866683','0.002257529259020','63.05947650895171','63.059476508951711','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','THETABTC','4h','0.000033250000000','0.000033260000000','0.001680708131288','0.001681213607418','50.54761297106016','50.547612971060161','test'),('2019-03-09 19:59:59','2019-03-09 23:59:59','THETABTC','4h','0.000033280000000','0.000035450000000','0.001680834500320','0.001790432182582','50.50584436058445','50.505844360584447','test'),('2019-04-10 03:59:59','2019-04-10 07:59:59','THETABTC','4h','0.000025140000000','0.000023720000000','0.001708233920886','0.001611746563382','67.9488433128779','67.948843312877898','test'),('2019-04-14 07:59:59','2019-04-14 11:59:59','THETABTC','4h','0.000023730000000','0.000023920000000','0.001708233920886','0.001721911310054','71.98625878154235','71.986258781542347','test'),('2019-04-16 03:59:59','2019-04-16 07:59:59','THETABTC','4h','0.000024310000000','0.000023910000000','0.001708233920886','0.001680126410876','70.26877502616207','70.268775026162075','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','THETABTC','4h','0.000014470000000','0.000014390000000','0.001708233920886','0.001698789642125','118.05348451181756','118.053484511817558','test'),('2019-05-16 15:59:59','2019-05-16 19:59:59','THETABTC','4h','0.000014590000000','0.000014030000000','0.001708233920886','0.001642667711448','117.08251685305004','117.082516853050038','test'),('2019-05-17 11:59:59','2019-05-19 23:59:59','THETABTC','4h','0.000014650000000','0.000014300000000','0.001708233920886','0.001667422871582','116.60299801269625','116.602998012696247','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','THETABTC','4h','0.000014970000000','0.000014710000000','0.001708233920886','0.001678565195473','114.11048235711422','114.110482357114222','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','THETABTC','4h','0.000014680000000','0.000014750000000','0.001708233920886','0.001716379450482','116.36470850722071','116.364708507220712','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETABTC','4h','0.000017350000000','0.000016410000000','0.001708233920886','0.001615684071570','98.4572865063977','98.457286506397693','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','THETABTC','4h','0.000015090000000','0.000015050000000','0.001708233920886','0.001703705799161','113.20304313359841','113.203043133598413','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','THETABTC','4h','0.000015500000000','0.000015140000000','0.001708233920886','0.001668558810465','110.20864005716129','110.208640057161290','test'),('2019-06-02 03:59:59','2019-06-03 07:59:59','THETABTC','4h','0.000016140000000','0.000015740000000','0.001708233920886','0.001665898507729','105.83853289256506','105.838532892565055','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETABTC','4h','0.000011620000000','0.000011470000000','0.001708233920886','0.001686182708482','147.00808269242685','147.008082692426854','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','THETABTC','4h','0.000010890000000','0.000010720000000','0.001708233920886','0.001681567275656','156.86261899779615','156.862618997796147','test'),('2019-07-13 11:59:59','2019-07-13 23:59:59','THETABTC','4h','0.000010210000000','0.000010120000000','0.001708233920886','0.001693176031280','167.30988451380998','167.309884513809976','test'),('2019-07-17 03:59:59','2019-07-17 07:59:59','THETABTC','4h','0.000011120000000','0.000010670000000','0.001708233920886','0.001639105749627','153.61815835305757','153.618158353057567','test'),('2019-08-12 07:59:59','2019-08-12 11:59:59','THETABTC','4h','0.000011160000000','0.000010950000000','0.001708233920886','0.001676089734203','153.06755563494625','153.067555634946245','test'),('2019-08-13 19:59:59','2019-08-13 23:59:59','THETABTC','4h','0.000011160000000','0.000011020000000','0.001708233920886','0.001686804463097','153.06755563494625','153.067555634946245','test'),('2019-08-17 03:59:59','2019-08-17 19:59:59','THETABTC','4h','0.000010930000000','0.000010980000000','0.001708233920886','0.001716048348703','156.2885563482159','156.288556348215906','test'),('2019-08-27 15:59:59','2019-08-28 15:59:59','THETABTC','4h','0.000012160000000','0.000011920000000','0.001708233920886','0.001674518777711','140.4797632307566','140.479763230756589','test'),('2019-08-29 19:59:59','2019-08-30 03:59:59','THETABTC','4h','0.000012070000000','0.000011870000000','0.001708233920886','0.001679928470664','141.52725110903066','141.527251109030658','test'),('2019-09-11 03:59:59','2019-09-11 07:59:59','THETABTC','4h','0.000010910000000','0.000010810000000','0.001708233920886','0.001692576414737','156.57506149275892','156.575061492758920','test'),('2019-09-16 19:59:59','2019-09-16 23:59:59','THETABTC','4h','0.000010650000000','0.000010280000000','0.001708233920886','0.001648886826921','160.3975512569014','160.397551256901409','test'),('2019-09-18 03:59:59','2019-09-19 23:59:59','THETABTC','4h','0.000010580000000','0.000010570000000','0.001708233920886','0.001706619333059','161.45878269243855','161.458782692438547','test'),('2019-09-26 23:59:59','2019-09-27 03:59:59','THETABTC','4h','0.000010540000000','0.000010380000000','0.001708233920886','0.001682302476167','162.07152949582542','162.071529495825416','test'),('2019-09-27 11:59:59','2019-09-27 15:59:59','THETABTC','4h','0.000010370000000','0.000010260000000','0.001708233920886','0.001690113792506','164.7284398154291','164.728439815429113','test'),('2019-09-27 23:59:59','2019-09-28 03:59:59','THETABTC','4h','0.000010420000000','0.000010330000000','0.001708233920886','0.001693479501224','163.9379962462572','163.937996246257200','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','THETABTC','4h','0.000010180000000','0.000009970000000','0.001708233920886','0.001672995303658','167.80293918330057','167.802939183300566','test'),('2019-10-03 19:59:59','2019-10-03 23:59:59','THETABTC','4h','0.000010190000000','0.000010240000000','0.001708233920886','0.001716615834139','167.6382650526006','167.638265052600588','test'),('2019-10-10 19:59:59','2019-10-10 23:59:59','THETABTC','4h','0.000010490000000','0.000010330000000','0.001708233920886','0.001682178875382','162.84403440285988','162.844034402859876','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETABTC','4h','0.000010560000000','0.000010290000000','0.001708233920886','0.001664557485409','161.76457584147727','161.764575841477267','test'),('2019-10-13 23:59:59','2019-10-14 03:59:59','THETABTC','4h','0.000010420000000','0.000010230000000','0.001708233920886','0.001677085701599','163.9379962462572','163.937996246257200','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','THETABTC','4h','0.000010350000000','0.000010480000000','0.001708233920886','0.001729689999119','165.04675564115945','165.046755641159450','test'),('2019-10-16 19:59:59','2019-10-16 23:59:59','THETABTC','4h','0.000010620000000','0.000010490000000','0.001708233920886','0.001687323336167','160.8506516841808','160.850651684180804','test'),('2019-10-20 03:59:59','2019-10-20 07:59:59','THETABTC','4h','0.000010480000000','0.000010430000000','0.001708233920886','0.001700083949889','162.99941993187025','162.999419931870250','test'),('2019-10-21 23:59:59','2019-10-22 03:59:59','THETABTC','4h','0.000010540000000','0.000010430000000','0.001708233920886','0.001690406052641','162.07152949582542','162.071529495825416','test'),('2019-10-29 03:59:59','2019-10-29 11:59:59','THETABTC','4h','0.000011180000000','0.000010730000000','0.001708233920886','0.001639476741602','152.79373174293383','152.793731742933829','test'),('2019-10-29 19:59:59','2019-10-29 23:59:59','THETABTC','4h','0.000011140000000','0.000010750000000','0.001708233920886','0.001648430399419','153.34236273662478','153.342362736624779','test'),('2019-11-09 11:59:59','2019-11-09 19:59:59','THETABTC','4h','0.000010320000000','0.000010200000000','0.001708233920886','0.001688370735759','165.52654272151165','165.526542721511646','test'),('2019-11-12 19:59:59','2019-11-12 23:59:59','THETABTC','4h','0.000010200000000','0.000010220000000','0.001708233920886','0.001711583399162','167.47391381235295','167.473913812352947','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:12:21
