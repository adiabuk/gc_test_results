-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-06 15:59:59','2018-05-06 19:59:59','AMBETH','4h','0.001041200000000','0.001026950000000','0.072144500000000','0.071157120894161','69.28976181329236','69.289761813292358','test'),('2018-05-07 15:59:59','2018-05-07 19:59:59','AMBETH','4h','0.001027500000000','0.001014150000000','0.072144500000000','0.071207148102190','70.21362530413626','70.213625304136258','test'),('2018-05-08 07:59:59','2018-05-08 11:59:59','AMBETH','4h','0.001027570000000','0.001010570000000','0.072144500000000','0.070950949682260','70.20884221999475','70.208842219994750','test'),('2018-05-30 07:59:59','2018-05-30 11:59:59','AMBETH','4h','0.000676680000000','0.000664650000000','0.072144500000000','0.070861916895726','106.6153868889283','106.615386888928299','test'),('2018-05-31 07:59:59','2018-05-31 11:59:59','AMBETH','4h','0.000677000000000','0.000665360000000','0.072144500000000','0.070904083485968','106.56499261447563','106.564992614475628','test'),('2018-05-31 15:59:59','2018-05-31 19:59:59','AMBETH','4h','0.000674370000000','0.000692370000000','0.072144500000000','0.074070150607233','106.98058929074544','106.980589290745442','test'),('2018-06-07 03:59:59','2018-06-07 07:59:59','AMBETH','4h','0.000687660000000','0.000680280000000','0.072144500000000','0.071370241776459','104.91303842014949','104.913038420149491','test'),('2018-06-16 19:59:59','2018-06-16 23:59:59','AMBETH','4h','0.000649800000000','0.000639070000000','0.072144500000000','0.070953194236688','111.02570021545091','111.025700215450911','test'),('2018-06-26 15:59:59','2018-06-26 19:59:59','AMBETH','4h','0.000590870000000','0.000599150000000','0.072144500000000','0.073155477812378','122.09876961091273','122.098769610912726','test'),('2018-06-27 23:59:59','2018-06-28 07:59:59','AMBETH','4h','0.000590930000000','0.000579460000000','0.072144500000000','0.070744169309394','122.08637232836377','122.086372328363765','test'),('2018-06-28 15:59:59','2018-06-28 19:59:59','AMBETH','4h','0.000582510000000','0.000644130000000','0.072144500000000','0.079776204331256','123.85109268510413','123.851092685104135','test'),('2018-07-17 19:59:59','2018-07-18 03:59:59','AMBETH','4h','0.000661650000000','0.000670150000000','0.072534789283428','0.073466619871970','109.62712806382264','109.627128063822639','test'),('2018-07-23 15:59:59','2018-07-23 19:59:59','AMBETH','4h','0.000641130000000','0.000632500000000','0.072767746930564','0.071788248769488','113.49920754069183','113.499207540691827','test'),('2018-08-17 15:59:59','2018-08-17 23:59:59','AMBETH','4h','0.000442000000000','0.000420500000000','0.072767746930564','0.069228139331000','164.63291160761085','164.632911607610851','test'),('2018-08-18 11:59:59','2018-08-18 15:59:59','AMBETH','4h','0.000448710000000','0.000436500000000','0.072767746930564','0.070787639088033','162.17099447430186','162.170994474301864','test'),('2018-08-19 15:59:59','2018-08-21 03:59:59','AMBETH','4h','0.000435930000000','0.000438780000000','0.072767746930564','0.073243484041458','166.92530206813936','166.925302068139359','test'),('2018-08-23 11:59:59','2018-08-30 07:59:59','AMBETH','4h','0.000456830000000','0.000549120000000','0.072767746930564','0.087468478853209','159.28845945004488','159.288459450044883','test'),('2018-09-13 15:59:59','2018-09-13 19:59:59','AMBETH','4h','0.000635330000000','0.000617180000000','0.074937060788156','0.072796271508089','117.94982259322832','117.949822593228319','test'),('2018-09-17 11:59:59','2018-09-17 15:59:59','AMBETH','4h','0.000611830000000','0.000577680000000','0.074937060788156','0.070754361956919','122.48020003621268','122.480200036212679','test'),('2018-09-17 19:59:59','2018-09-17 23:59:59','AMBETH','4h','0.000602140000000','0.000588610000000','0.074937060788156','0.073253235710161','124.45122527677283','124.451225276772831','test'),('2018-09-18 11:59:59','2018-09-18 15:59:59','AMBETH','4h','0.000602320000000','0.000590400000000','0.074937060788156','0.073454045506255','124.41403371655598','124.414033716555977','test'),('2018-09-19 11:59:59','2018-09-19 15:59:59','AMBETH','4h','0.000619990000000','0.000606380000000','0.074937060788156','0.073292044905115','120.86817656438976','120.868176564389756','test'),('2018-09-22 19:59:59','2018-09-22 23:59:59','AMBETH','4h','0.000617710000000','0.000608140000000','0.074937060788156','0.073776082866894','121.31430734188534','121.314307341885339','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','AMBETH','4h','0.000642620000000','0.000644980000000','0.074937060788156','0.075212264584272','116.61177801524384','116.611778015243843','test'),('2018-10-05 07:59:59','2018-10-06 15:59:59','AMBETH','4h','0.000636220000000','0.000633990000000','0.074937060788156','0.074674400630416','117.78482409882746','117.784824098827457','test'),('2018-10-26 11:59:59','2018-10-26 15:59:59','AMBETH','4h','0.000936240000000','0.000921060000000','0.074937060788156','0.073722046921237','80.0404391909724','80.040439190972407','test'),('2018-10-28 15:59:59','2018-10-29 07:59:59','AMBETH','4h','0.000938750000000','0.000928200000000','0.074937060788156','0.074094891955863','79.82642960123142','79.826429601231425','test'),('2018-10-31 03:59:59','2018-11-01 15:59:59','AMBETH','4h','0.000950710000000','0.000954890000000','0.074937060788156','0.075266537615048','78.82220739043031','78.822207390430307','test'),('2018-11-03 03:59:59','2018-11-03 07:59:59','AMBETH','4h','0.000943780000000','0.000936970000000','0.074937060788156','0.074396340086332','79.40098411510733','79.400984115107335','test'),('2018-11-10 07:59:59','2018-11-10 11:59:59','AMBETH','4h','0.000904380000000','0.000911850000000','0.074937060788156','0.075556026094872','82.86014815470931','82.860148154709307','test'),('2018-11-12 03:59:59','2018-11-14 01:59:59','AMBETH','4h','0.000924620000000','0.000912070000000','0.074937060788156','0.073919929303988','81.0463333998356','81.046333399835603','test'),('2018-11-28 15:59:59','2018-11-28 23:59:59','AMBETH','4h','0.000713520000000','0.000684470000000','0.074937060788156','0.071886099895825','105.02447133669132','105.024471336691320','test'),('2018-11-29 03:59:59','2018-11-30 03:59:59','AMBETH','4h','0.000713820000000','0.000708770000000','0.074937060788156','0.074406910110142','104.980332280065','104.980332280064999','test'),('2018-12-01 03:59:59','2018-12-01 11:59:59','AMBETH','4h','0.000709180000000','0.000714490000000','0.074937060788156','0.075498153589398','105.66719420761443','105.667194207614429','test'),('2018-12-02 15:59:59','2018-12-02 19:59:59','AMBETH','4h','0.000710590000000','0.000716040000000','0.074937060788156','0.075511804284821','105.45752232392238','105.457522323922376','test'),('2018-12-03 07:59:59','2018-12-03 15:59:59','AMBETH','4h','0.000711820000000','0.000676190000000','0.074937060788156','0.071186102012227','105.27529542321935','105.275295423219347','test'),('2018-12-04 11:59:59','2018-12-04 19:59:59','AMBETH','4h','0.000726050000000','0.000717010000000','0.074937060788156','0.074004024455224','103.21198373136285','103.211983731362849','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','AMBETH','4h','0.000710200000000','0.000686290000000','0.074937060788156','0.072414186775984','105.51543338236553','105.515433382365529','test'),('2018-12-15 03:59:59','2018-12-15 07:59:59','AMBETH','4h','0.000654950000000','0.000646640000000','0.074937060788156','0.073986260001608','114.4164604750836','114.416460475083596','test'),('2018-12-15 15:59:59','2018-12-16 15:59:59','AMBETH','4h','0.000659500000000','0.000645350000000','0.074937060788156','0.073329237573368','113.62708231714328','113.627082317143277','test'),('2018-12-17 03:59:59','2018-12-17 11:59:59','AMBETH','4h','0.000654750000000','0.000657510000000','0.074937060788156','0.075252946680138','114.45141013845895','114.451410138458954','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','AMBETH','4h','0.000657740000000','0.000646200000000','0.074937060788156','0.073622295559501','113.93112899953782','113.931128999537819','test'),('2019-01-01 23:59:59','2019-01-02 03:59:59','AMBETH','4h','0.000535880000000','0.000518000000000','0.074937060788156','0.072436734881438','139.83925652787192','139.839256527871925','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','AMBETH','4h','0.000503280000000','0.000497590000000','0.074937060788156','0.074089834838616','148.8973549279844','148.897354927984395','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','AMBETH','4h','0.000501410000000','0.000494110000000','0.074937060788156','0.073846056333212','149.45266506084045','149.452665060840445','test'),('2019-01-09 07:59:59','2019-01-09 15:59:59','AMBETH','4h','0.000507680000000','0.000501700000000','0.074937060788156','0.074054371646348','147.60687990103213','147.606879901032130','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','AMBETH','4h','0.000522990000000','0.000516560000000','0.074937060788156','0.074015732845236','143.28583871231956','143.285838712319560','test'),('2019-03-01 11:59:59','2019-03-02 03:59:59','AMBETH','4h','0.000385690000000','0.000390360000000','0.074937060788156','0.075844411442518','194.29350200460473','194.293502004604733','test'),('2019-03-08 15:59:59','2019-03-09 03:59:59','AMBETH','4h','0.000395600000000','0.000415440000000','0.074937060788156','0.078695279408068','189.42634172941354','189.426341729413537','test'),('2019-03-16 19:59:59','2019-03-16 23:59:59','AMBETH','4h','0.000427200000000','0.000425230000000','0.074937060788156','0.074591494285926','175.4144681370693','175.414468137069292','test'),('2019-03-18 19:59:59','2019-03-18 23:59:59','AMBETH','4h','0.000429650000000','0.000425560000000','0.074937060788156','0.074223706712458','174.41419943711392','174.414199437113922','test'),('2019-03-19 11:59:59','2019-03-19 15:59:59','AMBETH','4h','0.000428070000000','0.000425620000000','0.074937060788156','0.074508168787009','175.0579596518233','175.057959651823296','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','AMBETH','4h','0.000426000000000','0.000421420000000','0.074937060788156','0.074131399430387','175.90859339942722','175.908593399427218','test'),('2019-03-20 15:59:59','2019-03-20 23:59:59','AMBETH','4h','0.000434140000000','0.000427190000000','0.074937060788156','0.073737418800600','172.61035792176716','172.610357921767161','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','AMBETH','4h','0.000424410000000','0.000439580000000','0.074937060788156','0.077615591482900','176.5676133648029','176.567613364802895','test'),('2019-04-03 15:59:59','2019-04-03 19:59:59','AMBETH','4h','0.000477540000000','0.000422120000000','0.074937060788156','0.066240382166722','156.9231075682791','156.923107568279107','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:14:15
