-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJBNB','4h','0.005429000000000','0.005116000000000','0.711908500000000','0.670864594953030','131.1306870510223','131.130687051022306','test'),('2018-12-07 07:59:59','2018-12-11 03:59:59','ENJBNB','4h','0.005093000000000','0.006552000000000','0.711908500000000','0.915850086785784','139.78175927743962','139.781759277439619','test'),('2019-01-12 07:59:59','2019-01-12 11:59:59','ENJBNB','4h','0.006394000000000','0.006273000000000','0.752632920434704','0.738390101640115','117.70924623626892','117.709246236268925','test'),('2019-01-23 03:59:59','2019-01-23 07:59:59','ENJBNB','4h','0.005552000000000','0.005500000000000','0.752632920434704','0.745583764839854','135.56068451633718','135.560684516337176','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBNB','4h','0.005232000000000','0.005065000000000','0.752632920434704','0.728609660168535','143.85185788125077','143.851857881250766','test'),('2019-01-30 15:59:59','2019-01-30 19:59:59','ENJBNB','4h','0.005118000000000','0.005097000000000','0.752632920434704','0.749544743152733','147.0560610462493','147.056061046249312','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','ENJBNB','4h','0.003617000000000','0.003516000000000','0.752632920434704','0.731616629319441','208.0820902501255','208.082090250125503','test'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ENJBNB','4h','0.003562000000000','0.003524000000000','0.752632920434704','0.744603709043205','211.29503661838964','211.295036618389645','test'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJBNB','4h','0.003575000000000','0.003620000000000','0.752632920434704','0.762106621531085','210.52669103068644','210.526691030686436','test'),('2019-03-07 11:59:59','2019-03-07 19:59:59','ENJBNB','4h','0.006749000000000','0.006565000000000','0.752632920434704','0.732113664639774','111.51769453766543','111.517694537665434','test'),('2019-03-17 19:59:59','2019-03-18 03:59:59','ENJBNB','4h','0.010675000000000','0.010655000000000','0.752632920434704','0.751222835337871','70.50425484165845','70.504254841658451','test'),('2019-03-18 11:59:59','2019-03-18 15:59:59','ENJBNB','4h','0.013211000000000','0.013000000000000','0.752632920434704','0.740612214491799','56.970170345522966','56.970170345522966','test'),('2019-04-09 07:59:59','2019-04-09 11:59:59','ENJBNB','4h','0.008875000000000','0.008269000000000','0.752632920434704','0.701241872571782','84.80370934475539','84.803709344755390','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJBNB','4h','0.008592000000000','0.008274000000000','0.752632920434704','0.724777093072246','87.59694139137615','87.596941391376149','test'),('2019-04-13 19:59:59','2019-04-13 23:59:59','ENJBNB','4h','0.009085000000000','0.008937000000000','0.752632920434704','0.740372086948261','82.8434695029944','82.843469502994395','test'),('2019-04-17 11:59:59','2019-04-18 07:59:59','ENJBNB','4h','0.008369000000000','0.008102000000000','0.752632920434704','0.728621331265620','89.93104557709452','89.931045577094523','test'),('2019-04-19 07:59:59','2019-04-19 11:59:59','ENJBNB','4h','0.008866000000000','0.008457000000000','0.752632920434704','0.717912994373595','84.88979477043807','84.889794770438073','test'),('2019-04-20 19:59:59','2019-04-20 23:59:59','ENJBNB','4h','0.008436000000000','0.008080000000000','0.752632920434704','0.720871739818920','89.21679948253959','89.216799482539585','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','ENJBNB','4h','0.006727000000000','0.006688000000000','0.752632920434704','0.748269506744061','111.88240232417184','111.882402324171835','test'),('2019-06-02 19:59:59','2019-06-02 23:59:59','ENJBNB','4h','0.005154000000000','0.005097000000000','0.752632920434704','0.744309273468313','146.02889414720684','146.028894147206842','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','ENJBNB','4h','0.004997000000000','0.004919000000000','0.752632920434704','0.740884798002463','150.6169542594965','150.616954259496509','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','ENJBNB','4h','0.004935000000000','0.004787000000000','0.752632920434704','0.730061558281849','152.50920373550233','152.509203735502325','test'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJBNB','4h','0.004984000000000','0.004765000000000','0.752632920434704','0.719561770840964','151.0098154965297','151.009815496529711','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBNB','4h','0.004955000000000','0.004798000000000','0.752632920434704','0.728785621038488','151.8936267274882','151.893626727488197','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ENJBNB','4h','0.005064000000000','0.004996000000000','0.752632920434704','0.742526475215596','148.62419439863822','148.624194398638224','test'),('2019-06-30 23:59:59','2019-07-02 07:59:59','ENJBNB','4h','0.003767000000000','0.003785000000000','0.752632920434704','0.756229255069115','199.79636857836581','199.796368578365815','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','ENJBNB','4h','0.003759000000000','0.003733000000000','0.752632920434704','0.747427159346302','200.2215803231455','200.221580323145503','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','ENJBNB','4h','0.003710000000000','0.003713000000000','0.752632920434704','0.753241518483573','202.86601628967762','202.866016289677617','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','ENJBNB','4h','0.003723000000000','0.003705000000000','0.752632920434704','0.748994082785543','202.15764717558525','202.157647175585254','test'),('2019-07-14 15:59:59','2019-07-14 19:59:59','ENJBNB','4h','0.003737000000000','0.003607000000000','0.752632920434704','0.726450881457848','201.40029982197058','201.400299821970577','test'),('2019-07-26 15:59:59','2019-07-27 03:59:59','ENJBNB','4h','0.003090000000000','0.003076000000000','0.752632920434704','0.749222933092929','243.57052441252557','243.570524412525572','test'),('2019-07-29 11:59:59','2019-07-29 15:59:59','ENJBNB','4h','0.003134000000000','0.003079000000000','0.752632920434704','0.739424620937605','240.15089994725716','240.150899947257159','test'),('2019-07-30 03:59:59','2019-07-31 15:59:59','ENJBNB','4h','0.003147000000000','0.003118000000000','0.752632920434704','0.745697313605150','239.15885619151697','239.158856191516975','test'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ENJBNB','4h','0.002463000000000','0.002347000000000','0.752632920434704','0.717186140584754','305.5756883616338','305.575688361633809','test'),('2019-08-18 07:59:59','2019-08-18 11:59:59','ENJBNB','4h','0.002395000000000','0.002306000000000','0.752632920434704','0.724664515458216','314.2517413088534','314.251741308853411','test'),('2019-08-20 19:59:59','2019-08-20 23:59:59','ENJBNB','4h','0.002378000000000','0.002341000000000','0.752632920434704','0.740922483909858','316.4982844553003','316.498284455300279','test'),('2019-08-21 15:59:59','2019-08-26 07:59:59','ENJBNB','4h','0.002391000000000','0.002510000000000','0.752632920434704','0.790091438850317','314.777465677417','314.777465677417013','test'),('2019-09-11 19:59:59','2019-09-12 03:59:59','ENJBNB','4h','0.003505000000000','0.003411000000000','0.752632920434704','0.732448185906641','214.73121838365307','214.731218383653072','test'),('2019-09-15 07:59:59','2019-09-16 07:59:59','ENJBNB','4h','0.003491000000000','0.003448000000000','0.752632920434704','0.743362449057250','215.59235761521168','215.592357615211682','test'),('2019-09-16 23:59:59','2019-09-17 07:59:59','ENJBNB','4h','0.003431000000000','0.003362000000000','0.752632920434704','0.737496904255749','219.36255331818828','219.362553318188276','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','ENJBNB','4h','0.003402000000000','0.003406000000000','0.752632920434704','0.753517850382305','221.2324869002657','221.232486900265712','test'),('2019-09-23 07:59:59','2019-09-23 11:59:59','ENJBNB','4h','0.003406000000000','0.003365000000000','0.752632920434704','0.743573040887486','220.97267188335405','220.972671883354053','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','ENJBNB','4h','0.003427000000000','0.003444000000000','0.752632920434704','0.756366436526735','219.61859364887772','219.618593648877720','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','ENJBNB','4h','0.003408000000000','0.003406000000000','0.752632920434704','0.752191234448533','220.84299308530046','220.842993085300463','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','ENJBNB','4h','0.003385000000000','0.003324000000000','0.752632920434704','0.739069963818303','222.34355108853885','222.343551088538845','test'),('2019-11-01 03:59:59','2019-11-01 07:59:59','ENJBNB','4h','0.003324000000000','0.003284000000000','0.752632920434704','0.743575965916838','226.42386294666184','226.423862946661842','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','ENJBNB','4h','0.003271000000000','0.003213000000000','0.752632920434704','0.739287549176614','230.09260789810577','230.092607898105769','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','ENJBNB','4h','0.003284000000000','0.003217000000000','0.752632920434704','0.737277742094532','229.1817662712253','229.181766271225314','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','ENJBNB','4h','0.003283000000000','0.003224000000000','0.752632920434704','0.739107077514921','229.251574911576','229.251574911576000','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','ENJBNB','4h','0.003280000000000','0.003253000000000','0.752632920434704','0.746437466516491','229.4612562300927','229.461256230092687','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','ENJBNB','4h','0.003265000000000','0.003212000000000','0.752632920434704','0.740415601971292','230.51544270588175','230.515442705881753','test'),('2019-11-15 07:59:59','2019-11-15 11:59:59','ENJBNB','4h','0.003163000000000','0.003118000000000','0.752632920434704','0.741925212113628','237.9490738016769','237.949073801676889','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:32:30
