-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 07:59:59','2018-07-05 23:59:59','NAVBNB','4h','0.032650000000000','0.035460000000000','0.711908500000000','0.773178419908116','21.80424196018377','21.804241960183770','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','NAVBNB','4h','0.035630000000000','0.033940000000000','0.727225979977029','0.692732241381430','20.41049621041339','20.410496210413388','test'),('2018-07-09 19:59:59','2018-07-09 23:59:59','NAVBNB','4h','0.034040000000000','0.032750000000000','0.727225979977029','0.699666593544292','21.363865451734107','21.363865451734107','test'),('2018-07-11 07:59:59','2018-07-11 11:59:59','NAVBNB','4h','0.034490000000000','0.033020000000000','0.727225979977029','0.696230845428863','21.085125542969816','21.085125542969816','test'),('2018-07-12 15:59:59','2018-07-12 19:59:59','NAVBNB','4h','0.033820000000000','0.032660000000000','0.727225979977029','0.702282687937604','21.502837965021552','21.502837965021552','test'),('2018-07-12 23:59:59','2018-07-13 03:59:59','NAVBNB','4h','0.033780000000000','0.033080000000000','0.727225979977029','0.712156169853171','21.528300176939876','21.528300176939876','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','NAVBNB','4h','0.034070000000000','0.033350000000000','0.727225979977029','0.711857541304195','21.345053712269706','21.345053712269706','test'),('2018-07-14 19:59:59','2018-07-14 23:59:59','NAVBNB','4h','0.033260000000000','0.032720000000000','0.727225979977029','0.715418943621419','21.864882140018914','21.864882140018914','test'),('2018-07-15 07:59:59','2018-07-15 15:59:59','NAVBNB','4h','0.033350000000000','0.032710000000000','0.727225979977029','0.713270219041938','21.80587646108033','21.805876461080331','test'),('2018-07-17 19:59:59','2018-07-22 15:59:59','NAVBNB','4h','0.034900000000000','0.035560000000000','0.727225979977029','0.740978677592640','20.8374206297143','20.837420629714298','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','NAVBNB','4h','0.036000000000000','0.034450000000000','0.727225979977029','0.695914861394685','20.200721666028585','20.200721666028585','test'),('2018-07-29 19:59:59','2018-07-29 23:59:59','NAVBNB','4h','0.035760000000000','0.034320000000000','0.727225979977029','0.697941712326947','20.336296979223405','20.336296979223405','test'),('2018-08-15 15:59:59','2018-08-15 19:59:59','NAVBNB','4h','0.025360000000000','0.024600000000000','0.727225979977029','0.705432141460367','28.676103311397043','28.676103311397043','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','NAVBNB','4h','0.025020000000000','0.024650000000000','0.727225979977029','0.716471638946194','29.0657865698253','29.065786569825299','test'),('2018-08-24 23:59:59','2018-08-25 03:59:59','NAVBNB','4h','0.026510000000000','0.025660000000000','0.727225979977029','0.703908662625823','27.43213806024251','27.432138060242512','test'),('2018-09-01 19:59:59','2018-09-01 23:59:59','NAVBNB','4h','0.026670000000000','0.026270000000000','0.727225979977029','0.716318953655664','27.26756580341316','27.267565803413159','test'),('2018-09-02 19:59:59','2018-09-03 03:59:59','NAVBNB','4h','0.026030000000000','0.024710000000000','0.727225979977029','0.690347828091909','27.93799385236377','27.937993852363771','test'),('2018-09-04 07:59:59','2018-09-04 19:59:59','NAVBNB','4h','0.026380000000000','0.025740000000000','0.727225979977029','0.709582893275539','27.567322971077672','27.567322971077672','test'),('2018-09-09 19:59:59','2018-09-09 23:59:59','NAVBNB','4h','0.024800000000000','0.024210000000000','0.727225979977029','0.709925039324350','29.323628224880203','29.323628224880203','test'),('2018-09-16 19:59:59','2018-09-16 23:59:59','NAVBNB','4h','0.024450000000000','0.024040000000000','0.727225979977029','0.715031188492752','29.743393864091164','29.743393864091164','test'),('2018-10-03 19:59:59','2018-10-03 23:59:59','NAVBNB','4h','0.034000000000000','0.032660000000000','0.727225979977029','0.698564720766170','21.388999411089085','21.388999411089085','test'),('2018-10-04 03:59:59','2018-10-05 11:59:59','NAVBNB','4h','0.034850000000000','0.034230000000000','0.727225979977029','0.714288243747882','20.867316498623502','20.867316498623502','test'),('2018-10-09 07:59:59','2018-10-09 11:59:59','NAVBNB','4h','0.034110000000000','0.032170000000000','0.727225979977029','0.685865135615978','21.32002286652093','21.320022866520929','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','NAVBNB','4h','0.033630000000000','0.033320000000000','0.727225979977029','0.720522439870193','21.624322925275912','21.624322925275912','test'),('2018-10-13 03:59:59','2018-10-13 07:59:59','NAVBNB','4h','0.033420000000000','0.034300000000000','0.727225979977029','0.746374958504252','21.760202871844076','21.760202871844076','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','NAVBNB','4h','0.034670000000000','0.031900000000000','0.727225979977029','0.669123413939060','20.975655609374936','20.975655609374936','test'),('2018-10-16 03:59:59','2018-10-19 03:59:59','NAVBNB','4h','0.035230000000000','0.034090000000000','0.727225979977029','0.703693830752680','20.642236161709594','20.642236161709594','test'),('2018-10-19 11:59:59','2018-10-19 19:59:59','NAVBNB','4h','0.035210000000000','0.035020000000000','0.727225979977029','0.723301727315977','20.653961373957088','20.653961373957088','test'),('2018-10-28 15:59:59','2018-10-28 23:59:59','NAVBNB','4h','0.038080000000000','0.037790000000000','0.727225979977029','0.721687756915229','19.097320902758113','19.097320902758113','test'),('2018-10-30 19:59:59','2018-10-30 23:59:59','NAVBNB','4h','0.038550000000000','0.038000000000000','0.727225979977029','0.716850512039613','18.864487158937198','18.864487158937198','test'),('2018-10-31 15:59:59','2018-10-31 19:59:59','NAVBNB','4h','0.037590000000000','0.037990000000000','0.727225979977029','0.734964484685484','19.346261771136714','19.346261771136714','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','NAVBNB','4h','0.038770000000000','0.038050000000000','0.727225979977029','0.713720622598038','18.757440804153443','18.757440804153443','test'),('2018-11-08 11:59:59','2018-11-09 11:59:59','NAVBNB','4h','0.038510000000000','0.037610000000000','0.727225979977029','0.710230306594029','18.884081536666553','18.884081536666553','test'),('2018-11-20 19:59:59','2018-11-20 23:59:59','NAVBNB','4h','0.033500000000000','0.034380000000000','0.727225979977029','0.746329229600306','21.70823820826952','21.708238208269520','test'),('2018-11-24 11:59:59','2018-11-24 15:59:59','NAVBNB','4h','0.033070000000000','0.032500000000000','0.727225979977029','0.714691392478181','21.990504383944025','21.990504383944025','test'),('2018-11-24 19:59:59','2018-11-24 23:59:59','NAVBNB','4h','0.032920000000000','0.030180000000000','0.727225979977029','0.666697450659378','22.090704130529435','22.090704130529435','test'),('2018-11-27 19:59:59','2018-11-27 23:59:59','NAVBNB','4h','0.032850000000000','0.030180000000000','0.727225979977029','0.668118114937800','22.137777168250505','22.137777168250505','test'),('2018-11-28 11:59:59','2018-11-30 11:59:59','NAVBNB','4h','0.032440000000000','0.032240000000000','0.727225979977029','0.722742465920451','22.417570282892388','22.417570282892388','test'),('2018-12-01 07:59:59','2018-12-01 11:59:59','NAVBNB','4h','0.032500000000000','0.033460000000000','0.727225979977029','0.748707116616350','22.3761839992932','22.376183999293200','test'),('2018-12-03 03:59:59','2018-12-03 07:59:59','NAVBNB','4h','0.032930000000000','0.032600000000000','0.727225979977029','0.719938261380235','22.083995747859973','22.083995747859973','test'),('2018-12-03 19:59:59','2018-12-04 03:59:59','NAVBNB','4h','0.033110000000000','0.032060000000000','0.727225979977029','0.704163845305453','21.963937782453307','21.963937782453307','test'),('2018-12-14 19:59:59','2018-12-15 19:59:59','NAVBNB','4h','0.028520000000000','0.035470000000000','0.727225979977029','0.904442689683914','25.49880715206974','25.498807152069741','test'),('2018-12-19 07:59:59','2018-12-22 15:59:59','NAVBNB','4h','0.029810000000000','0.031960000000000','0.727225979977029','0.779676025497009','24.395370009293156','24.395370009293156','test'),('2018-12-23 19:59:59','2018-12-23 23:59:59','NAVBNB','4h','0.031110000000000','0.030370000000000','0.727225979977029','0.709927772803034','23.375955640534524','23.375955640534524','test'),('2018-12-24 23:59:59','2018-12-25 07:59:59','NAVBNB','4h','0.032020000000000','0.029600000000000','0.727225979977029','0.672263866562151','22.711617113586165','22.711617113586165','test'),('2019-01-07 15:59:59','2019-01-08 07:59:59','NAVBNB','4h','0.028790000000000','0.027980000000000','0.727225979977029','0.706765645007199','25.259672802258734','25.259672802258734','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','NAVBNB','4h','0.028100000000000','0.027610000000000','0.727225979977029','0.714544815201629','25.87992811306153','25.879928113061531','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','NAVBNB','4h','0.027570000000000','0.026920000000000','0.727225979977029','0.710080644939486','26.377438519297385','26.377438519297385','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','NAVBNB','4h','0.027970000000000','0.027090000000000','0.727225979977029','0.704345791833311','26.000213799679265','26.000213799679265','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','NAVBNB','4h','0.027220000000000','0.026760000000000','0.727225979977029','0.714936341814302','26.716604701580785','26.716604701580785','test'),('2019-01-20 07:59:59','2019-01-20 11:59:59','NAVBNB','4h','0.027010000000000','0.024970000000000','0.727225979977029','0.672300359867694','26.924323583007368','26.924323583007368','test'),('2019-01-22 03:59:59','2019-01-22 07:59:59','NAVBNB','4h','0.027680000000000','0.027050000000000','0.727225979977029','0.710674232600384','26.272614883563186','26.272614883563186','test'),('2019-01-23 11:59:59','2019-01-23 19:59:59','NAVBNB','4h','0.026810000000000','0.025640000000000','0.727225979977029','0.695489523558785','27.125176425849645','27.125176425849645','test'),('2019-02-26 03:59:59','2019-02-26 07:59:59','NAVBNB','4h','0.016070000000000','0.016020000000000','0.727225979977029','0.724963298023149','45.25363907759981','45.253639077599807','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','NAVBNB','4h','0.016420000000000','0.016240000000000','0.727225979977029','0.719253953399936','44.28903653940493','44.289036539404933','test'),('2019-03-12 19:59:59','2019-03-12 23:59:59','NAVBNB','4h','0.013520000000000','0.012560000000000','0.484817319984686','0.450392421524235','35.85926922963653','35.859269229636531','test'),('2019-03-13 07:59:59','2019-03-13 11:59:59','NAVBNB','4h','0.012880000000000','0.012300000000000','0.534996483255651','0.510905026711530','41.53699404158781','41.536994041587811','test'),('2019-03-17 11:59:59','2019-03-17 15:59:59','NAVBNB','4h','0.013030000000000','0.012920000000000','0.534996483255651','0.530480012560477','41.05882450158488','41.058824501584880','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','NAVBNB','4h','0.012950000000000','0.012650000000000','0.534996483255651','0.522602742330810','41.31246974947112','41.312469749471120','test'),('2019-03-23 11:59:59','2019-03-24 11:59:59','NAVBNB','4h','0.012990000000000','0.011440000000000','0.534996483255651','0.471159335523068','41.185256601666744','41.185256601666744','test'),('2019-03-26 23:59:59','2019-03-27 07:59:59','NAVBNB','4h','0.012730000000000','0.012390000000000','0.534996483255651','0.520707496271604','42.026432306021285','42.026432306021285','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','NAVBNB','4h','0.012970000000000','0.012790000000000','0.534996483255651','0.527571705538919','41.248765092956894','41.248765092956894','test'),('2019-04-03 11:59:59','2019-04-04 03:59:59','NAVBNB','4h','0.012840000000000','0.012880000000000','0.534996483255651','0.536663138966728','41.66639277691986','41.666392776919857','test'),('2019-04-05 07:59:59','2019-04-09 11:59:59','NAVBNB','4h','0.013090000000000','0.013010000000000','0.534996483255651','0.531726833243393','40.87062515322009','40.870625153220089','test'),('2019-04-10 07:59:59','2019-04-10 19:59:59','NAVBNB','4h','0.013260000000000','0.013070000000000','0.534996483255651','0.527330621127553','40.34664277946086','40.346642779460858','test'),('2019-05-03 19:59:59','2019-05-03 23:59:59','NAVBNB','4h','0.009070000000000','0.008940000000000','0.534996483255651','0.527328396946584','58.98527930051279','58.985279300512786','test'),('2019-05-04 11:59:59','2019-05-04 15:59:59','NAVBNB','4h','0.009050000000000','0.008800000000000','0.534996483255651','0.520217574878423','59.115633508911706','59.115633508911706','test'),('2019-05-04 19:59:59','2019-05-04 23:59:59','NAVBNB','4h','0.008910000000000','0.008940000000000','0.534996483255651','0.536797818216108','60.04449868189125','60.044498681891248','test'),('2019-05-05 15:59:59','2019-05-05 23:59:59','NAVBNB','4h','0.008920000000000','0.009100000000000','0.534996483255651','0.545792376415518','59.97718422148553','59.977184221485530','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','NAVBNB','4h','0.009210000000000','0.009090000000000','0.534996483255651','0.528025845037336','58.08865181928893','58.088651819288927','test'),('2019-05-16 19:59:59','2019-05-16 23:59:59','NAVBNB','4h','0.009040000000000','0.008300000000000','0.534996483255651','0.491202523343131','59.18102690881095','59.181026908810949','test'),('2019-05-17 07:59:59','2019-05-17 11:59:59','NAVBNB','4h','0.008670000000000','0.007940000000000','0.534996483255651','0.489950643258347','61.706630133293075','61.706630133293075','test'),('2019-05-18 07:59:59','2019-05-18 11:59:59','NAVBNB','4h','0.008510000000000','0.008330000000000','0.534996483255651','0.523680458932970','62.866801792673435','62.866801792673435','test'),('2019-05-18 15:59:59','2019-05-18 19:59:59','NAVBNB','4h','0.008840000000000','0.008410000000000','0.534996483255651','0.508972898662899','60.51996416919128','60.519964169191283','test'),('2019-05-31 23:59:59','2019-06-01 03:59:59','NAVBNB','4h','0.006920000000000','0.006840000000000','0.534996483255651','0.528811552813389','77.31163052827326','77.311630528273255','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','NAVBNB','4h','0.006950000000000','0.007170000000000','0.534996483255651','0.551931623732808','76.9779112598059','76.977911259805893','test'),('2019-06-05 07:59:59','2019-06-05 23:59:59','NAVBNB','4h','0.007100000000000','0.006970000000000','0.534996483255651','0.525200772998857','75.35161735995084','75.351617359950836','test'),('2019-06-07 15:59:59','2019-06-07 19:59:59','NAVBNB','4h','0.007200000000000','0.007090000000000','0.534996483255651','0.526822925872579','74.30506711884041','74.305067118840412','test'),('2019-06-09 11:59:59','2019-06-09 15:59:59','NAVBNB','4h','0.007070000000000','0.007100000000000','0.534996483255651','0.537266623920102','75.67135548170452','75.671355481704524','test'),('2019-06-10 15:59:59','2019-06-10 23:59:59','NAVBNB','4h','0.007130000000000','0.007110000000000','0.534996483255651','0.533495791858019','75.03456988157798','75.034569881577980','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','NAVBNB','4h','0.007190000000000','0.006950000000000','0.534996483255651','0.517138464343084','74.40841213569554','74.408412135695542','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:00:48
