-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-14 19:59:59','BATETH','4h','0.000560810000000','0.000563710000000','0.072144500000000','0.072517565833348','128.64339080972164','128.643390809721637','test'),('2018-05-16 11:59:59','2018-05-16 19:59:59','BATETH','4h','0.000565900000000','0.000559610000000','0.072237766458337','0.071434840939654','127.65111584791835','127.651115847918348','test'),('2018-05-24 03:59:59','2018-05-24 07:59:59','BATETH','4h','0.000539450000000','0.000516750000000','0.072237766458337','0.069198008744732','133.9100314363463','133.910031436346287','test'),('2018-05-24 19:59:59','2018-05-24 23:59:59','BATETH','4h','0.000529500000000','0.000525350000000','0.072237766458337','0.071671596995066','136.42637669185459','136.426376691854585','test'),('2018-05-30 07:59:59','2018-05-30 11:59:59','BATETH','4h','0.000510300000000','0.000506900000000','0.072237766458337','0.071756464467433','141.5594090894317','141.559409089431711','test'),('2018-06-03 07:59:59','2018-06-03 11:59:59','BATETH','4h','0.000503910000000','0.000501770000000','0.072237766458337','0.071930987826794','143.35450072103552','143.354500721035521','test'),('2018-06-15 11:59:59','2018-06-19 19:59:59','BATETH','4h','0.000465700000000','0.000467440000000','0.072237766458337','0.072507669214698','155.11652664448573','155.116526644485731','test'),('2018-06-20 15:59:59','2018-06-26 15:59:59','BATETH','4h','0.000478430000000','0.000536620000000','0.072237766458337','0.081023828432316','150.9892073204795','150.989207320479494','test'),('2018-06-27 11:59:59','2018-06-27 15:59:59','BATETH','4h','0.000528350000000','0.000525450000000','0.073202524311420','0.072800731332328','138.54930313508183','138.549303135081828','test'),('2018-06-28 03:59:59','2018-06-28 07:59:59','BATETH','4h','0.000529990000000','0.000516020000000','0.073202524311420','0.071272979858448','138.1205764475179','138.120576447517891','test'),('2018-06-30 11:59:59','2018-07-03 23:59:59','BATETH','4h','0.000522520000000','0.000545690000000','0.073202524311420','0.076448529226630','140.09516250367452','140.095162503674516','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','BATETH','4h','0.000569720000000','0.000556620000000','0.073431191182207','0.071742732633294','128.88996556590428','128.889965565904276','test'),('2018-07-29 03:59:59','2018-07-29 07:59:59','BATETH','4h','0.000704870000000','0.000701340000000','0.073431191182207','0.073063446626653','104.17692791891697','104.176927918916974','test'),('2018-08-02 03:59:59','2018-08-02 07:59:59','BATETH','4h','0.000687310000000','0.000676430000000','0.073431191182207','0.072268787957952','106.83853164104553','106.838531641045535','test'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BATETH','4h','0.000665000000000','0.000680360000000','0.073431191182207','0.075127286064250','110.42284388301805','110.422843883018047','test'),('2018-08-09 19:59:59','2018-08-09 23:59:59','BATETH','4h','0.000669450000000','0.000680000000000','0.073431191182207','0.074588408400778','109.6888358834969','109.688835883496907','test'),('2018-08-11 03:59:59','2018-08-11 07:59:59','BATETH','4h','0.000672420000000','0.000643900000000','0.073431191182207','0.070316683028796','109.20435320515007','109.204353205150070','test'),('2018-08-11 15:59:59','2018-08-12 03:59:59','BATETH','4h','0.000674950000000','0.000665040000000','0.073431191182207','0.072353032645107','108.79500878910586','108.795008789105864','test'),('2018-08-13 03:59:59','2018-08-13 19:59:59','BATETH','4h','0.000672310000000','0.000693070000000','0.073431191182207','0.075698644483426','109.22222067529415','109.222220675294153','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','BATETH','4h','0.000696410000000','0.000667080000000','0.073431191182207','0.070338563509752','105.44247093265032','105.442470932650323','test'),('2018-08-16 15:59:59','2018-08-18 15:59:59','BATETH','4h','0.000673430000000','0.000694910000000','0.073431191182207','0.075773382629861','109.04057018874568','109.040570188745676','test'),('2018-09-11 07:59:59','2018-09-11 19:59:59','BATETH','4h','0.000795750000000','0.000788750000000','0.073431191182207','0.072785236625782','92.2792223464744','92.279222346474398','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','BATETH','4h','0.000796010000000','0.000801000000000','0.073431191182207','0.073891514097747','92.24908127059585','92.249081270595852','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','BATETH','4h','0.000782710000000','0.000739460000000','0.073431191182207','0.069373623221365','93.8166002506765','93.816600250676501','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','BATETH','4h','0.000743400000000','0.000758140000000','0.073431191182207','0.074887171486250','98.77749688217246','98.777496882172457','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','BATETH','4h','0.000747070000000','0.000743160000000','0.073431191182207','0.073046868484839','98.29224996614374','98.292249966143743','test'),('2018-10-02 03:59:59','2018-10-06 19:59:59','BATETH','4h','0.000757580000000','0.000763050000000','0.073431191182207','0.073961390785901','96.92862956018772','96.928629560187716','test'),('2018-10-30 03:59:59','2018-11-08 23:59:59','BATETH','4h','0.001205800000000','0.001442080000000','0.073431191182207','0.087820245629488','60.898317450826845','60.898317450826845','test'),('2018-11-16 19:59:59','2018-11-16 23:59:59','BATETH','4h','0.001279030000000','0.001286040000000','0.075607883235637','0.076022268560048','59.11345569348449','59.113455693484489','test'),('2018-11-21 23:59:59','2018-11-24 23:59:59','BATETH','4h','0.001281700000000','0.001298070000000','0.075711479566740','0.076678474121244','59.07113955429524','59.071139554295243','test'),('2018-11-26 03:59:59','2018-11-26 11:59:59','BATETH','4h','0.001285250000000','0.001272750000000','0.075953228205366','0.075214527289150','59.09607329730886','59.096073297308862','test'),('2018-11-27 03:59:59','2018-11-27 11:59:59','BATETH','4h','0.001284300000000','0.001282410000000','0.075953228205366','0.075841454008287','59.13978681411353','59.139786814113528','test'),('2018-12-07 03:59:59','2018-12-07 19:59:59','BATETH','4h','0.001461700000000','0.001401440000000','0.075953228205366','0.072821982716103','51.96225504916604','51.962255049166039','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','BATETH','4h','0.001525090000000','0.001510200000000','0.075953228205366','0.075211669629821','49.80245638314198','49.802456383141980','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','BATETH','4h','0.001518360000000','0.001501140000000','0.075953228205366','0.075091828675810','50.023201484078875','50.023201484078875','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','BATETH','4h','0.000963000000000','0.000967160000000','0.075953228205366','0.076281333531778','78.87147269508411','78.871472695084108','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BATETH','4h','0.001004180000000','0.001030120000000','0.075953228205366','0.077915253678535','75.63706527252684','75.637065272526840','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','BATETH','4h','0.001117500000000','0.001095050000000','0.075953228205366','0.074427366931800','67.96709459093154','67.967094590931538','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BATETH','4h','0.001079190000000','0.001055870000000','0.075953228205366','0.074311970149093','70.37984803914603','70.379848039146026','test'),('2019-02-14 11:59:59','2019-02-14 15:59:59','BATETH','4h','0.001052000000000','0.001035810000000','0.075953228205366','0.074784328238974','72.19888612677377','72.198886126773772','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATETH','4h','0.001081560000000','0.001057330000000','0.075953228205366','0.074251661284052','70.2256261375846','70.225626137584598','test'),('2019-03-17 19:59:59','2019-03-17 23:59:59','BATETH','4h','0.001396580000000','0.001393260000000','0.075953228205366','0.075772669470713','54.38516104008793','54.385161040087930','test'),('2019-03-18 11:59:59','2019-03-19 03:59:59','BATETH','4h','0.001410000000000','0.001406240000000','0.075953228205366','0.075750686263485','53.867537734302125','53.867537734302125','test'),('2019-03-21 03:59:59','2019-03-30 03:59:59','BATETH','4h','0.001402330000000','0.001897560000000','0.075953228205366','0.102775956952625','54.16216454426989','54.162164544269892','test'),('2019-04-04 03:59:59','2019-04-04 11:59:59','BATETH','4h','0.001831660000000','0.001795180000000','0.080230101691642','0.078632210101657','43.801852795628946','43.801852795628946','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','BATETH','4h','0.001826250000000','0.001785780000000','0.080230101691642','0.078452189458672','43.93160941363012','43.931609413630120','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','BATETH','4h','0.001798000000000','0.001911530000000','0.080230101691642','0.085296021294007','44.62185856042381','44.621858560423810','test'),('2019-04-06 23:59:59','2019-04-07 07:59:59','BATETH','4h','0.001829790000000','0.001820710000000','0.080652630636494','0.080252406629269','44.077533835300336','44.077533835300336','test'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BATETH','4h','0.001743100000000','0.001750990000000','0.080652630636494','0.081017698191839','46.26965213498595','46.269652134985947','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:02:42
