-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-13 11:59:59','2018-07-13 15:59:59','PIVXBNB','4h','0.143230000000000','0.144910000000000','0.711908500000000','0.720258749808001','4.970386790476856','4.970386790476856','test'),('2018-07-13 23:59:59','2018-07-14 07:59:59','PIVXBNB','4h','0.146120000000000','0.141120000000000','0.713996062452000','0.689564223468562','4.886367796687656','4.886367796687656','test'),('2018-07-14 11:59:59','2018-07-14 15:59:59','PIVXBNB','4h','0.145770000000000','0.141800000000000','0.713996062452000','0.694550604758823','4.898100174603828','4.898100174603828','test'),('2018-07-14 19:59:59','2018-07-15 03:59:59','PIVXBNB','4h','0.144000000000000','0.144260000000000','0.713996062452000','0.715285222009205','4.95830598925','4.958305989250000','test'),('2018-07-16 03:59:59','2018-07-16 07:59:59','PIVXBNB','4h','0.144960000000000','0.132260000000000','0.713996062452000','0.651442599475038','4.925469525745033','4.925469525745033','test'),('2018-07-16 19:59:59','2018-07-17 15:59:59','PIVXBNB','4h','0.144400000000000','0.148480000000000','0.713996062452000','0.734169912416018','4.944571069612188','4.944571069612188','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','PIVXBNB','4h','0.154680000000000','0.154740000000000','0.713996062452000','0.714273019807489','4.615955924825446','4.615955924825446','test'),('2018-07-26 11:59:59','2018-07-26 15:59:59','PIVXBNB','4h','0.153700000000000','0.144200000000000','0.713996062452000','0.669864880973184','4.645387524085882','4.645387524085882','test'),('2018-07-27 03:59:59','2018-07-27 07:59:59','PIVXBNB','4h','0.155540000000000','0.143540000000000','0.713996062452000','0.658910857685226','4.5904337305644844','4.590433730564484','test'),('2018-07-27 15:59:59','2018-07-28 15:59:59','PIVXBNB','4h','0.154250000000000','0.151470000000000','0.713996062452000','0.701127932444761','4.628823743611021','4.628823743611021','test'),('2018-07-30 19:59:59','2018-07-30 23:59:59','PIVXBNB','4h','0.153560000000000','0.153990000000000','0.713996062452000','0.715995400214792','4.649622704167752','4.649622704167752','test'),('2018-08-15 11:59:59','2018-08-15 15:59:59','PIVXBNB','4h','0.107350000000000','0.105110000000000','0.713996062452000','0.699097588489331','6.651104447619934','6.651104447619934','test'),('2018-08-21 07:59:59','2018-08-22 23:59:59','PIVXBNB','4h','0.111240000000000','0.109200000000000','0.713996062452000','0.700902283528932','6.418519079935274','6.418519079935274','test'),('2018-08-23 11:59:59','2018-08-23 19:59:59','PIVXBNB','4h','0.114840000000000','0.113520000000000','0.713996062452000','0.705789211159448','6.217311585266458','6.217311585266458','test'),('2018-08-25 03:59:59','2018-08-25 15:59:59','PIVXBNB','4h','0.114830000000000','0.112220000000000','0.713996062452000','0.697767466066041','6.21785302144039','6.217853021440390','test'),('2018-08-26 03:59:59','2018-08-26 07:59:59','PIVXBNB','4h','0.113380000000000','0.111710000000000','0.713996062452000','0.703479450842414','6.297372221308873','6.297372221308873','test'),('2018-08-27 03:59:59','2018-08-27 07:59:59','PIVXBNB','4h','0.114320000000000','0.114640000000000','0.713996062452000','0.715994651850046','6.245591868894331','6.245591868894331','test'),('2018-09-02 23:59:59','2018-09-03 03:59:59','PIVXBNB','4h','0.109040000000000','0.104850000000000','0.713996062452000','0.686559860125570','6.548019648312546','6.548019648312546','test'),('2018-09-03 19:59:59','2018-09-03 23:59:59','PIVXBNB','4h','0.109800000000000','0.108520000000000','0.713996062452000','0.705672611086439','6.502696379344262','6.502696379344262','test'),('2018-09-04 07:59:59','2018-09-04 11:59:59','PIVXBNB','4h','0.109240000000000','0.109240000000000','0.713996062452000','0.713996062452000','6.536031329659465','6.536031329659465','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','PIVXBNB','4h','0.096180000000000','0.096160000000000','0.713996062452000','0.713847591655067','7.423539846662507','7.423539846662507','test'),('2018-09-20 03:59:59','2018-09-20 11:59:59','PIVXBNB','4h','0.095710000000000','0.094270000000000','0.713996062452000','0.703253670539651','7.459994383575384','7.459994383575384','test'),('2018-09-20 15:59:59','2018-09-20 19:59:59','PIVXBNB','4h','0.096760000000000','0.095990000000000','0.713996062452000','0.708314200441995','7.379041571434477','7.379041571434477','test'),('2018-09-21 19:59:59','2018-09-23 23:59:59','PIVXBNB','4h','0.096600000000000','0.094900000000000','0.713996062452000','0.701430914355018','7.391263586459627','7.391263586459627','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','PIVXBNB','4h','0.097240000000000','0.095300000000000','0.713996062452000','0.699751385763838','7.3426168495680795','7.342616849568079','test'),('2018-09-27 07:59:59','2018-09-27 11:59:59','PIVXBNB','4h','0.101130000000000','0.098320000000000','0.713996062452000','0.694156955011180','7.060180583921685','7.060180583921685','test'),('2018-10-03 15:59:59','2018-10-03 23:59:59','PIVXBNB','4h','0.103430000000000','0.103300000000000','0.713996062452000','0.713098648857117','6.903181499100842','6.903181499100842','test'),('2018-10-05 15:59:59','2018-10-05 19:59:59','PIVXBNB','4h','0.107680000000000','0.106240000000000','0.713996062452000','0.704447823875376','6.6307212337667165','6.630721233766717','test'),('2018-10-06 15:59:59','2018-10-06 19:59:59','PIVXBNB','4h','0.108370000000000','0.107190000000000','0.713996062452000','0.706221628995385','6.588502929334687','6.588502929334687','test'),('2018-10-07 07:59:59','2018-10-07 15:59:59','PIVXBNB','4h','0.104840000000000','0.102120000000000','0.713996062452000','0.695471937214787','6.810340160740175','6.810340160740175','test'),('2018-10-08 07:59:59','2018-10-08 11:59:59','PIVXBNB','4h','0.107690000000000','0.105450000000000','0.713996062452000','0.699144626107934','6.630105510743801','6.630105510743801','test'),('2018-10-09 03:59:59','2018-10-09 07:59:59','PIVXBNB','4h','0.106380000000000','0.103390000000000','0.713996062452000','0.693927927212937','6.7117509160744495','6.711750916074450','test'),('2018-10-09 15:59:59','2018-10-09 23:59:59','PIVXBNB','4h','0.106560000000000','0.106850000000000','0.713996062452000','0.715939182366706','6.700413498986486','6.700413498986486','test'),('2018-11-04 15:59:59','2018-11-04 19:59:59','PIVXBNB','4h','0.143530000000000','0.141610000000000','0.713996062452000','0.704444941153959','4.974542342729743','4.974542342729743','test'),('2018-11-11 15:59:59','2018-11-14 11:59:59','PIVXBNB','4h','0.141690000000000','0.141120000000000','0.713996062452000','0.711123751381369','5.03914222917637','5.039142229176370','test'),('2018-11-21 23:59:59','2018-11-22 03:59:59','PIVXBNB','4h','0.135830000000000','0.134670000000000','0.713996062452000','0.707898474051468','5.256541724596922','5.256541724596922','test'),('2018-11-27 03:59:59','2018-11-27 11:59:59','PIVXBNB','4h','0.138000000000000','0.134370000000000','0.713996062452000','0.695214861678806','5.173884510521739','5.173884510521739','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','PIVXBNB','4h','0.141460000000000','0.139400000000000','0.713996062452000','0.703598551575066','5.047335377152551','5.047335377152551','test'),('2018-12-02 23:59:59','2018-12-03 03:59:59','PIVXBNB','4h','0.144630000000000','0.142350000000000','0.713996062452000','0.702740368457735','4.936707892221531','4.936707892221531','test'),('2018-12-20 11:59:59','2018-12-20 15:59:59','PIVXBNB','4h','0.115820000000000','0.124930000000000','0.713996062452000','0.770156519445073','6.164704390018994','6.164704390018994','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','PIVXBNB','4h','0.114140000000000','0.106000000000000','0.713996062452000','0.663076770807009','6.255441234028385','6.255441234028385','test'),('2018-12-23 15:59:59','2018-12-23 19:59:59','PIVXBNB','4h','0.125950000000000','0.115300000000000','0.713996062452000','0.653622437480870','5.668884973815006','5.668884973815006','test'),('2018-12-29 11:59:59','2018-12-29 15:59:59','PIVXBNB','4h','0.142330000000000','0.136180000000000','0.713996062452000','0.683144690400572','5.016483260394857','5.016483260394857','test'),('2019-01-24 07:59:59','2019-01-25 03:59:59','PIVXBNB','4h','0.127140000000000','0.120000000000000','0.713996062452000','0.673899067911279','5.615825565927324','5.615825565927324','test'),('2019-01-30 03:59:59','2019-01-30 07:59:59','PIVXBNB','4h','0.118870000000000','0.114020000000000','0.713996062452000','0.684864398424977','6.006528665365525','6.006528665365525','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','PIVXBNB','4h','0.084190000000000','0.082550000000000','0.713996062452000','0.700087598947768','8.480770429409668','8.480770429409668','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','PIVXBNB','4h','0.085980000000000','0.081380000000000','0.713996062452000','0.675796691816047','8.304211007815772','8.304211007815772','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','PIVXBNB','4h','0.083540000000000','0.082780000000000','0.713996062452000','0.707500527289640','8.546756792578405','8.546756792578405','test'),('2019-02-26 15:59:59','2019-02-27 07:59:59','PIVXBNB','4h','0.078030000000000','0.076790000000000','0.713996062452000','0.702649719796092','9.150276335409457','9.150276335409457','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','PIVXBNB','4h','0.060560000000000','0.059710000000000','0.713996062452000','0.703974651403714','11.789895350924702','11.789895350924702','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','PIVXBNB','4h','0.056120000000000','0.054480000000000','0.475997374968000','0.462087259234794','8.481777886101211','8.481777886101211','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','PIVXBNB','4h','0.056020000000000','0.055440000000000','0.530877856799638','0.525381442002355','9.476577236694707','9.476577236694707','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','PIVXBNB','4h','0.056120000000000','0.053780000000000','0.530877856799638','0.508742179948049','9.459690962217355','9.459690962217355','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','PIVXBNB','4h','0.056190000000000','0.050140000000000','0.530877856799638','0.473718023490547','9.447906332081118','9.447906332081118','test'),('2019-03-28 19:59:59','2019-03-28 23:59:59','PIVXBNB','4h','0.057040000000000','0.054880000000000','0.530877856799638','0.510774487748319','9.30711530153643','9.307115301536429','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','PIVXBNB','4h','0.055480000000000','0.052610000000000','0.530877856799638','0.503415357718618','9.568815010808182','9.568815010808182','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','PIVXBNB','4h','0.056180000000000','0.054770000000000','0.530877856799638','0.517553937645357','9.449588052681344','9.449588052681344','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','PIVXBNB','4h','0.054980000000000','0.055010000000000','0.530877856799638','0.531167531876102','9.655835882132374','9.655835882132374','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','PIVXBNB','4h','0.058200000000000','0.053640000000000','0.530877856799638','0.489283303071006','9.121612659787594','9.121612659787594','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','PIVXBNB','4h','0.054860000000000','0.055790000000000','0.530877856799638','0.539877426738093','9.676956923070323','9.676956923070323','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','PIVXBNB','4h','0.054680000000000','0.051760000000000','0.530877856799638','0.502528124871054','9.708812304309399','9.708812304309399','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','PIVXBNB','4h','0.054310000000000','0.054530000000000','0.530877856799638','0.533028347105216','9.774955934443712','9.774955934443712','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','PIVXBNB','4h','0.029110000000000','0.028290000000000','0.530877856799638','0.515923550974296','18.2369583235877','18.236958323587700','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','PIVXBNB','4h','0.029110000000000','0.029850000000000','0.530877856799638','0.544373205959093','18.2369583235877','18.236958323587700','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','PIVXBNB','4h','0.029730000000000','0.029330000000000','0.530877856799638','0.523735201477746','17.856638304730506','17.856638304730506','test'),('2019-05-29 03:59:59','2019-05-29 07:59:59','PIVXBNB','4h','0.022640000000000','0.021720000000000','0.530877856799638','0.509305081700006','23.448668586556447','23.448668586556447','test'),('2019-05-30 11:59:59','2019-05-30 19:59:59','PIVXBNB','4h','0.022490000000000','0.023020000000000','0.530877856799638','0.543388539952320','23.605062552229345','23.605062552229345','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','PIVXBNB','4h','0.022510000000000','0.022280000000000','0.530877856799638','0.525453516192623','23.584089595719146','23.584089595719146','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','PIVXBNB','4h','0.022190000000000','0.022470000000000','0.530877856799638','0.537576631017930','23.924193636757003','23.924193636757003','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','PIVXBNB','4h','0.022600000000000','0.022310000000000','0.530877856799638','0.524065707309731','23.490170654851237','23.490170654851237','test'),('2019-06-08 07:59:59','2019-06-08 11:59:59','PIVXBNB','4h','0.021970000000000','0.021550000000000','0.530877856799638','0.520729076651443','24.163762257607555','24.163762257607555','test'),('2019-06-09 03:59:59','2019-06-10 11:59:59','PIVXBNB','4h','0.022370000000000','0.021780000000000','0.530877856799638','0.516876160978816','23.73168783190156','23.731687831901560','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','PIVXBNB','4h','0.022460000000000','0.022150000000000','0.530877856799638','0.523550513273018','23.636592021355206','23.636592021355206','test'),('2019-06-14 23:59:59','2019-06-15 07:59:59','PIVXBNB','4h','0.022160000000000','0.021610000000000','0.530877856799638','0.517701736707589','23.95658198554323','23.956581985543231','test'),('2019-06-15 19:59:59','2019-06-16 03:59:59','PIVXBNB','4h','0.022320000000000','0.021880000000000','0.530877856799638','0.520412522705021','23.784850215037544','23.784850215037544','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','PIVXBNB','4h','0.020410000000000','0.019340000000000','0.530877856799638','0.503046435595541','26.01067402252023','26.010674022520231','test'),('2019-07-05 23:59:59','2019-07-06 03:59:59','PIVXBNB','4h','0.019340000000000','0.019950000000000','0.530877856799638','0.547622194578737','27.449734064097104','27.449734064097104','test'),('2019-07-10 03:59:59','2019-07-10 07:59:59','PIVXBNB','4h','0.019810000000000','0.019570000000000','0.530877856799638','0.524446221987325','26.79847838463594','26.798478384635938','test'),('2019-07-10 19:59:59','2019-07-10 19:59:59','PIVXBNB','4h','0.019690000000000','0.019690000000000','0.530877856799638','0.530877856799638','26.961800751632197','26.961800751632197','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:26:52
