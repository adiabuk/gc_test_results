-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 07:59:59','ICXBNB','4h','0.114430000000000','0.114210000000000','0.711908500000000','0.710539804116054','6.221344927029626','6.221344927029626','test'),('2018-07-07 23:59:59','2018-07-10 03:59:59','ICXBNB','4h','0.120840000000000','0.118220000000000','0.711908500000000','0.696473211436610','5.891331512744125','5.891331512744125','test'),('2018-07-17 19:59:59','2018-07-19 19:59:59','ICXBNB','4h','0.117070000000000','0.116670000000000','0.711908500000000','0.709476080080294','6.081049799265398','6.081049799265398','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','ICXBNB','4h','0.116000000000000','0.113930000000000','0.711908500000000','0.699204615560345','6.13714224137931','6.137142241379310','test'),('2018-07-22 15:59:59','2018-07-22 23:59:59','ICXBNB','4h','0.115480000000000','0.112920000000000','0.711908500000000','0.696126669726360','6.164777450640804','6.164777450640804','test'),('2018-07-23 03:59:59','2018-07-23 07:59:59','ICXBNB','4h','0.114810000000000','0.115710000000000','0.711908500000000','0.717489178076823','6.200753418691752','6.200753418691752','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','ICXBNB','4h','0.064670000000000','0.061740000000000','0.711908500000000','0.679654102211226','11.008326890366476','11.008326890366476','test'),('2018-08-23 07:59:59','2018-08-23 11:59:59','ICXBNB','4h','0.063440000000000','0.062570000000000','0.711908500000000','0.702145568174653','11.221760718789408','11.221760718789408','test'),('2018-08-23 15:59:59','2018-08-24 19:59:59','ICXBNB','4h','0.063570000000000','0.066500000000000','0.711908500000000','0.744721020135284','11.198812332861413','11.198812332861413','test'),('2018-09-21 07:59:59','2018-09-22 07:59:59','ICXBNB','4h','0.065220000000000','0.065000000000000','0.711908500000000','0.709507091383011','10.915493713584791','10.915493713584791','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','ICXBNB','4h','0.065740000000000','0.067570000000000','0.711908500000000','0.731725849482811','10.829152722847581','10.829152722847581','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','ICXBNB','4h','0.066050000000000','0.065240000000000','0.711908500000000','0.703178055109765','10.778327024981076','10.778327024981076','test'),('2018-10-01 03:59:59','2018-10-02 23:59:59','ICXBNB','4h','0.066370000000000','0.066860000000000','0.711908500000000','0.717164416302546','10.726359801114963','10.726359801114963','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','ICXBNB','4h','0.066340000000000','0.065870000000000','0.711908500000000','0.706864831097377','10.731210431112453','10.731210431112453','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','ICXBNB','4h','0.066590000000000','0.065710000000000','0.711908500000000','0.702500488586875','10.690922060369425','10.690922060369425','test'),('2018-10-14 15:59:59','2018-10-14 19:59:59','ICXBNB','4h','0.065450000000000','0.066060000000000','0.711908500000000','0.718543552482811','10.877135217723454','10.877135217723454','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','ICXBNB','4h','0.066060000000000','0.066290000000000','0.711908500000000','0.714387139948532','10.776695428398428','10.776695428398428','test'),('2018-10-24 15:59:59','2018-10-24 23:59:59','ICXBNB','4h','0.069680000000000','0.068860000000000','0.711908500000000','0.703530701923077','10.216826923076923','10.216826923076923','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','ICXBNB','4h','0.068830000000000','0.067520000000000','0.711908500000000','0.698359173616156','10.342997239575768','10.342997239575768','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','ICXBNB','4h','0.052890000000000','0.052000000000000','0.711908500000000','0.699928946870864','13.460172055208925','13.460172055208925','test'),('2018-12-01 11:59:59','2018-12-02 11:59:59','ICXBNB','4h','0.052520000000000','0.051970000000000','0.711908500000000','0.704453251047220','13.554998095963445','13.554998095963445','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','ICXBNB','4h','0.051070000000000','0.048470000000000','0.711908500000000','0.675664871646759','13.939857058938713','13.939857058938713','test'),('2018-12-20 19:59:59','2018-12-22 15:59:59','ICXBNB','4h','0.044010000000000','0.042760000000000','0.711908500000000','0.691688422176778','16.1760622585776','16.176062258577598','test'),('2018-12-26 19:59:59','2018-12-26 23:59:59','ICXBNB','4h','0.043520000000000','0.043260000000000','0.711908500000000','0.707655370174632','16.35819163602941','16.358191636029410','test'),('2018-12-27 11:59:59','2018-12-27 15:59:59','ICXBNB','4h','0.043530000000000','0.043180000000000','0.711908500000000','0.706184448196646','16.3544337238686','16.354433723868599','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','ICXBNB','4h','0.041850000000000','0.041410000000000','0.711908500000000','0.704423679450418','17.010955794504184','17.010955794504184','test'),('2019-01-03 03:59:59','2019-01-08 03:59:59','ICXBNB','4h','0.043140000000000','0.042830000000000','0.711908500000000','0.706792792188225','16.502283263792307','16.502283263792307','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','ICXBNB','4h','0.043760000000000','0.043000000000000','0.711908500000000','0.699544458409506','16.268475776965268','16.268475776965268','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ICXBNB','4h','0.026000000000000','0.025410000000000','0.711908500000000','0.695753653269231','27.38109615384616','27.381096153846158','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','ICXBNB','4h','0.025460000000000','0.024790000000000','0.711908500000000','0.693174065789474','27.96184210526316','27.961842105263159','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','ICXBNB','4h','0.025470000000000','0.024680000000000','0.711908500000000','0.689827317628583','27.950863761287792','27.950863761287792','test'),('2019-02-23 15:59:59','2019-02-24 15:59:59','ICXBNB','4h','0.025100000000000','0.024610000000000','0.711908500000000','0.698010684661355','28.36288844621514','28.362888446215141','test'),('2019-02-25 15:59:59','2019-03-01 19:59:59','ICXBNB','4h','0.024660000000000','0.026600000000000','0.711908500000000','0.767914278183293','28.86895782643958','28.868957826439580','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','ICXBNB','4h','0.023680000000000','0.022400000000000','0.711908500000000','0.673426959459460','30.0637035472973','30.063703547297301','test'),('2019-03-09 07:59:59','2019-03-11 03:59:59','ICXBNB','4h','0.023950000000000','0.023960000000000','0.711908500000000','0.712205747807933','29.724780793319418','29.724780793319418','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','ICXBNB','4h','0.022610000000000','0.022110000000000','0.711908500000000','0.696165277974348','31.486444051304733','31.486444051304733','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','ICXBNB','4h','0.022230000000000','0.022120000000000','0.711908500000000','0.708385785874944','32.02467386414755','32.024673864147552','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXBNB','4h','0.022680000000000','0.021800000000000','0.711908500000000','0.684285947971781','31.38926366843034','31.389263668430338','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','ICXBNB','4h','0.020860000000000','0.020660000000000','0.711908500000000','0.705082915148610','34.127924256951104','34.127924256951104','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','ICXBNB','4h','0.020540000000000','0.020150000000000','0.711908500000000','0.698391250000000','34.659615384615385','34.659615384615385','test'),('2019-04-03 03:59:59','2019-04-03 23:59:59','ICXBNB','4h','0.021100000000000','0.021820000000000','0.711908500000000','0.736201112322275','33.739739336492896','33.739739336492896','test'),('2019-05-07 03:59:59','2019-05-07 07:59:59','ICXBNB','4h','0.015470000000000','0.015160000000000','0.711908500000000','0.697642718810601','46.01864899806077','46.018648998060769','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','ICXBNB','4h','0.015400000000000','0.015240000000000','0.711908500000000','0.704512048051948','46.227824675324676','46.227824675324676','test'),('2019-05-08 07:59:59','2019-05-08 15:59:59','ICXBNB','4h','0.015400000000000','0.015260000000000','0.711908500000000','0.705436604545455','46.227824675324676','46.227824675324676','test'),('2019-05-09 07:59:59','2019-05-09 11:59:59','ICXBNB','4h','0.015510000000000','0.015180000000000','0.711908500000000','0.696761510638298','45.89996776273372','45.899967762733723','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','ICXBNB','4h','0.015430000000000','0.015460000000000','0.711908500000000','0.713292638366818','46.13794556059624','46.137945560596243','test'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ICXBNB','4h','0.015560000000000','0.014380000000000','0.711908500000000','0.657920580334190','45.75247429305913','45.752474293059130','test'),('2019-05-30 07:59:59','2019-05-30 23:59:59','ICXBNB','4h','0.012450000000000','0.012120000000000','0.711908500000000','0.693038636144578','57.18140562248997','57.181405622489969','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ICXBNB','4h','0.012430000000000','0.013410000000000','0.711908500000000','0.768036442880129','57.27341110217217','57.273411102172169','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:55:16
