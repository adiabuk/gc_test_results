-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-20 07:59:59','2018-10-20 11:59:59','LOOMBTC','4h','0.000018770000000','0.000018550000000','0.001467500000000','0.001450299680341','78.18327117741076','78.183271177410759','test'),('2018-10-31 11:59:59','2018-10-31 15:59:59','LOOMBTC','4h','0.000018630000000','0.000018450000000','0.001467500000000','0.001453321256039','78.77079978529254','78.770799785292539','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','LOOMBTC','4h','0.000018490000000','0.000018420000000','0.001467500000000','0.001461944294213','79.36722552731206','79.367225527312058','test'),('2018-11-09 07:59:59','2018-11-09 11:59:59','LOOMBTC','4h','0.000017760000000','0.000017390000000','0.001467500000000','0.001436927083333','82.62950450450451','82.629504504504510','test'),('2018-11-12 03:59:59','2018-11-12 07:59:59','LOOMBTC','4h','0.000017810000000','0.000017630000000','0.001467500000000','0.001452668444694','82.39752947782145','82.397529477821450','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','LOOMBTC','4h','0.000013910000000','0.000013470000000','0.001467500000000','0.001421080158160','105.49964054636952','105.499640546369520','test'),('2018-12-01 07:59:59','2018-12-01 23:59:59','LOOMBTC','4h','0.000013490000000','0.000013220000000','0.001467500000000','0.001438128243143','108.78428465530023','108.784284655300226','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','LOOMBTC','4h','0.000013470000000','0.000012910000000','0.001467500000000','0.001406490348924','108.94580549368969','108.945805493689690','test'),('2018-12-07 19:59:59','2018-12-07 23:59:59','LOOMBTC','4h','0.000014460000000','0.000013680000000','0.001467500000000','0.001388340248963','101.48686030428769','101.486860304287688','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','LOOMBTC','4h','0.000012240000000','0.000012070000000','0.001467500000000','0.001447118055556','119.89379084967321','119.893790849673209','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','LOOMBTC','4h','0.000012200000000','0.000012200000000','0.001467500000000','0.001467500000000','120.28688524590164','120.286885245901644','test'),('2018-12-23 03:59:59','2018-12-23 07:59:59','LOOMBTC','4h','0.000012480000000','0.000012340000000','0.001467500000000','0.001451037660256','117.58814102564102','117.588141025641022','test'),('2018-12-31 11:59:59','2018-12-31 19:59:59','LOOMBTC','4h','0.000011930000000','0.000012030000000','0.001467500000000','0.001479800922045','123.00922045264042','123.009220452640420','test'),('2019-01-01 15:59:59','2019-01-01 19:59:59','LOOMBTC','4h','0.000011930000000','0.000011780000000','0.001467500000000','0.001449048616932','123.00922045264042','123.009220452640420','test'),('2019-01-02 07:59:59','2019-01-06 07:59:59','LOOMBTC','4h','0.000012020000000','0.000012440000000','0.001467500000000','0.001518777038270','122.08818635607321','122.088186356073209','test'),('2019-01-07 15:59:59','2019-01-07 19:59:59','LOOMBTC','4h','0.000012990000000','0.000012740000000','0.001467500000000','0.001439257120862','112.97151655119323','112.971516551193233','test'),('2019-01-08 11:59:59','2019-01-08 19:59:59','LOOMBTC','4h','0.000012650000000','0.000012440000000','0.001467500000000','0.001443138339921','116.00790513833994','116.007905138339936','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','LOOMBTC','4h','0.000012390000000','0.000012360000000','0.001467500000000','0.001463946731235','118.44229217110573','118.442292171105734','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','LOOMBTC','4h','0.000012020000000','0.000011970000000','0.001467500000000','0.001461395590682','122.08818635607321','122.088186356073209','test'),('2019-01-16 03:59:59','2019-01-17 11:59:59','LOOMBTC','4h','0.000012480000000','0.000012330000000','0.001467500000000','0.001449861778846','117.58814102564102','117.588141025641022','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','LOOMBTC','4h','0.000012330000000','0.000012260000000','0.001467500000000','0.001459168694242','119.01865369018654','119.018653690186540','test'),('2019-01-21 23:59:59','2019-01-22 03:59:59','LOOMBTC','4h','0.000012430000000','0.000012310000000','0.001467500000000','0.001453332662912','118.0611423974256','118.061142397425598','test'),('2019-01-31 03:59:59','2019-01-31 07:59:59','LOOMBTC','4h','0.000012270000000','0.000012040000000','0.001467500000000','0.001439991850041','119.60065199674003','119.600651996740027','test'),('2019-02-04 03:59:59','2019-02-04 07:59:59','LOOMBTC','4h','0.000012640000000','0.000012420000000','0.001467500000000','0.001441958069620','116.09968354430382','116.099683544303815','test'),('2019-02-07 03:59:59','2019-02-07 07:59:59','LOOMBTC','4h','0.000011900000000','0.000011640000000','0.001467500000000','0.001435436974790','123.31932773109244','123.319327731092443','test'),('2019-02-07 11:59:59','2019-02-07 19:59:59','LOOMBTC','4h','0.000012000000000','0.000011790000000','0.001467500000000','0.001441818750000','122.29166666666667','122.291666666666671','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','LOOMBTC','4h','0.000011450000000','0.000011420000000','0.001467500000000','0.001463655021834','128.16593886462883','128.165938864628828','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LOOMBTC','4h','0.000011740000000','0.000011820000000','0.001467500000000','0.001477500000000','125.00000000000001','125.000000000000014','test'),('2019-03-27 07:59:59','2019-03-27 11:59:59','LOOMBTC','4h','0.000017320000000','0.000017260000000','0.001467500000000','0.001462416281755','84.72863741339492','84.728637413394921','test'),('2019-03-27 15:59:59','2019-03-27 19:59:59','LOOMBTC','4h','0.000017350000000','0.000017340000000','0.001467500000000','0.001466654178674','84.58213256484149','84.582132564841487','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','LOOMBTC','4h','0.000018560000000','0.000017990000000','0.001467500000000','0.001422431303879','79.06788793103449','79.067887931034491','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','LOOMBTC','4h','0.000014050000000','0.000013920000000','0.001467500000000','0.001453921708185','104.44839857651246','104.448398576512460','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','LOOMBTC','4h','0.000009870000000','0.000009560000000','0.001467500000000','0.001421408308004','148.68287740628165','148.682877406281648','test'),('2019-05-17 15:59:59','2019-05-17 19:59:59','LOOMBTC','4h','0.000009650000000','0.000009510000000','0.001467500000000','0.001446209844560','152.07253886010363','152.072538860103634','test'),('2019-05-22 03:59:59','2019-05-22 07:59:59','LOOMBTC','4h','0.000009180000000','0.000009210000000','0.001467500000000','0.001472295751634','159.85838779956427','159.858387799564269','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','LOOMBTC','4h','0.000009480000000','0.000009070000000','0.001467500000000','0.001404032172996','154.79957805907173','154.799578059071735','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','LOOMBTC','4h','0.000009340000000','0.000008520000000','0.001467500000000','0.001338661670236','157.1199143468951','157.119914346895087','test'),('2019-05-29 07:59:59','2019-05-29 11:59:59','LOOMBTC','4h','0.000009400000000','0.000009180000000','0.001467500000000','0.001433154255319','156.11702127659575','156.117021276595750','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','LOOMBTC','4h','0.000009280000000','0.000009100000000','0.001467500000000','0.001439035560345','158.13577586206898','158.135775862068982','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','LOOMBTC','4h','0.000009110000000','0.000009200000000','0.001467500000000','0.001481997804610','161.08671789242592','161.086717892425924','test'),('2019-06-03 11:59:59','2019-06-06 19:59:59','LOOMBTC','4h','0.000009210000000','0.000009410000000','0.001467500000000','0.001499367535288','159.33767643865363','159.337676438653631','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','LOOMBTC','4h','0.000006660000000','0.000006530000000','0.001467500000000','0.001438855105105','220.34534534534535','220.345345345345351','test'),('2019-07-20 15:59:59','2019-07-20 19:59:59','LOOMBTC','4h','0.000004500000000','0.000004290000000','0.001467500000000','0.001399016666667','326.11111111111114','326.111111111111143','test'),('2019-07-23 03:59:59','2019-07-23 07:59:59','LOOMBTC','4h','0.000004530000000','0.000004480000000','0.001467500000000','0.001451302428256','323.95143487858724','323.951434878587236','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','LOOMBTC','4h','0.000004450000000','0.000004490000000','0.001467500000000','0.001480691011236','329.7752808988764','329.775280898876417','test'),('2019-07-25 23:59:59','2019-07-27 11:59:59','LOOMBTC','4h','0.000004470000000','0.000004440000000','0.001467500000000','0.001457651006711','328.29977628635345','328.299776286353449','test'),('2019-08-21 23:59:59','2019-08-26 03:59:59','LOOMBTC','4h','0.000003120000000','0.000003190000000','0.001467500000000','0.001500424679487','470.3525641025641','470.352564102564088','test'),('2019-09-20 23:59:59','2019-09-21 07:59:59','LOOMBTC','4h','0.000002420000000','0.000002410000000','0.001467500000000','0.001461435950413','606.404958677686','606.404958677685954','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','LOOMBTC','4h','0.000002510000000','0.000002480000000','0.001467500000000','0.001449960159363','584.6613545816733','584.661354581673322','test'),('2019-10-01 19:59:59','2019-10-02 03:59:59','LOOMBTC','4h','0.000003370000000','0.000003310000000','0.001467500000000','0.001441372403561','435.459940652819','435.459940652819000','test'),('2019-10-03 03:59:59','2019-10-03 07:59:59','LOOMBTC','4h','0.000003310000000','0.000003320000000','0.001467500000000','0.001471933534743','443.3534743202417','443.353474320241673','test'),('2019-10-03 23:59:59','2019-10-04 03:59:59','LOOMBTC','4h','0.000003390000000','0.000003340000000','0.001467500000000','0.001445855457227','432.89085545722713','432.890855457227133','test'),('2019-10-08 23:59:59','2019-10-09 03:59:59','LOOMBTC','4h','0.000003240000000','0.000003210000000','0.001467500000000','0.001453912037037','452.93209876543216','452.932098765432158','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:21:51
