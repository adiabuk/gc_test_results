-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 23:59:59','2019-01-04 07:59:59','ARDRBNB','4h','0.009180000000000','0.009110000000000','0.711908500000000','0.706480003812636','77.54994553376906','77.549945533769062','test'),('2019-01-04 19:59:59','2019-01-05 03:59:59','ARDRBNB','4h','0.009360000000000','0.009240000000000','0.711908500000000','0.702781467948718','76.05860042735043','76.058600427350427','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','ARDRBNB','4h','0.009780000000000','0.009000000000000','0.711908500000000','0.655130521472393','72.79228016359919','72.792280163599187','test'),('2019-01-09 23:59:59','2019-01-10 03:59:59','ARDRBNB','4h','0.009460000000000','0.009340000000000','0.711908500000000','0.702877948202960','75.25459830866808','75.254598308668079','test'),('2019-01-17 03:59:59','2019-01-17 07:59:59','ARDRBNB','4h','0.009240000000000','0.008840000000000','0.711908500000000','0.681089950216450','77.04637445887447','77.046374458874467','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','ARDRBNB','4h','0.009020000000000','0.008800000000000','0.711908500000000','0.694544878048781','78.92555432372507','78.925554323725066','test'),('2019-01-19 11:59:59','2019-01-19 19:59:59','ARDRBNB','4h','0.009040000000000','0.008590000000000','0.711908500000000','0.676470576880531','78.75094026548673','78.750940265486733','test'),('2019-01-22 07:59:59','2019-01-23 03:59:59','ARDRBNB','4h','0.009000000000000','0.008790000000000','0.711908500000000','0.695297301666667','79.10094444444445','79.100944444444451','test'),('2019-01-23 15:59:59','2019-01-23 19:59:59','ARDRBNB','4h','0.008790000000000','0.008670000000000','0.711908500000000','0.702189612627987','80.99072810011378','80.990728100113785','test'),('2019-01-29 23:59:59','2019-01-31 15:59:59','ARDRBNB','4h','0.008420000000000','0.008390000000000','0.711908500000000','0.709372008907364','84.54970308788599','84.549703087885987','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ARDRBNB','4h','0.006260000000000','0.006000000000000','0.711908500000000','0.682340415335463','113.72340255591055','113.723402555910553','test'),('2019-02-17 19:59:59','2019-02-17 23:59:59','ARDRBNB','4h','0.006310000000000','0.006190000000000','0.711908500000000','0.698369828050713','112.82226624405706','112.822266244057062','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','ARDRBNB','4h','0.006260000000000','0.006160000000000','0.711908500000000','0.700536159744409','113.72340255591055','113.723402555910553','test'),('2019-02-26 03:59:59','2019-02-26 11:59:59','ARDRBNB','4h','0.005750000000000','0.005750000000000','0.711908500000000','0.711908500000000','123.81017391304349','123.810173913043485','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','ARDRBNB','4h','0.005780000000000','0.005700000000000','0.711908500000000','0.702055095155709','123.16756055363322','123.167560553633223','test'),('2019-03-12 11:59:59','2019-03-12 15:59:59','ARDRBNB','4h','0.005220000000000','0.004490000000000','0.711908500000000','0.612350414750958','136.38093869731802','136.380938697318015','test'),('2019-03-15 15:59:59','2019-03-15 19:59:59','ARDRBNB','4h','0.004490000000000','0.004520000000000','0.711908500000000','0.716665126948775','158.5542316258352','158.554231625835200','test'),('2019-03-19 03:59:59','2019-03-19 07:59:59','ARDRBNB','4h','0.004450000000000','0.004350000000000','0.711908500000000','0.695910556179775','159.9794382022472','159.979438202247195','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','ARDRBNB','4h','0.004490000000000','0.004420000000000','0.711908500000000','0.700809703786192','158.5542316258352','158.554231625835200','test'),('2019-03-20 15:59:59','2019-03-24 11:59:59','ARDRBNB','4h','0.004610000000000','0.004070000000000','0.711908500000000','0.628517916485900','154.42700650759218','154.427006507592182','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','ARDRBNB','4h','0.004710000000000','0.004520000000000','0.711908500000000','0.683190322717622','151.14830148619959','151.148301486199585','test'),('2019-03-26 11:59:59','2019-03-26 19:59:59','ARDRBNB','4h','0.004660000000000','0.004610000000000','0.711908500000000','0.704269996781116','152.77006437768242','152.770064377682417','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','ARDRBNB','4h','0.004740000000000','0.004650000000000','0.711908500000000','0.698391250000000','150.19166666666666','150.191666666666663','test'),('2019-03-31 19:59:59','2019-04-01 03:59:59','ARDRBNB','4h','0.004740000000000','0.004740000000000','0.711908500000000','0.711908500000000','150.19166666666666','150.191666666666663','test'),('2019-04-03 15:59:59','2019-04-03 23:59:59','ARDRBNB','4h','0.004670000000000','0.004670000000000','0.711908500000000','0.711908500000000','152.4429336188437','152.442933618843711','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ARDRBNB','4h','0.004830000000000','0.004550000000000','0.711908500000000','0.670638442028986','147.39306418219462','147.393064182194621','test'),('2019-04-04 15:59:59','2019-04-04 19:59:59','ARDRBNB','4h','0.004670000000000','0.004540000000000','0.711908500000000','0.692090918629550','152.4429336188437','152.442933618843711','test'),('2019-04-05 07:59:59','2019-04-05 11:59:59','ARDRBNB','4h','0.004660000000000','0.004700000000000','0.711908500000000','0.718019302575107','152.77006437768242','152.770064377682417','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','ARDRBNB','4h','0.004680000000000','0.004770000000000','0.711908500000000','0.725599048076923','152.11720085470085','152.117200854700855','test'),('2019-04-10 19:59:59','2019-04-10 23:59:59','ARDRBNB','4h','0.004710000000000','0.004620000000000','0.711908500000000','0.698305152866242','151.14830148619959','151.148301486199585','test'),('2019-05-06 19:59:59','2019-05-07 07:59:59','ARDRBNB','4h','0.003150000000000','0.003090000000000','0.711908500000000','0.698348338095238','226.00269841269844','226.002698412698436','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','ARDRBNB','4h','0.003400000000000','0.003290000000000','0.711908500000000','0.688876166176471','209.3848529411765','209.384852941176490','test'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ARDRBNB','4h','0.003360000000000','0.003070000000000','0.711908500000000','0.650464016369048','211.87752976190478','211.877529761904782','test'),('2019-05-16 03:59:59','2019-05-16 07:59:59','ARDRBNB','4h','0.003370000000000','0.003420000000000','0.711908500000000','0.722470940652819','211.24881305637982','211.248813056379817','test'),('2019-05-28 07:59:59','2019-05-29 07:59:59','ARDRBNB','4h','0.002680000000000','0.002590000000000','0.711908500000000','0.688001125000000','265.6375','265.637499999999989','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','ARDRBNB','4h','0.002770000000000','0.002680000000000','0.711908500000000','0.688777898916968','257.006678700361','257.006678700361022','test'),('2019-06-06 23:59:59','2019-06-07 03:59:59','ARDRBNB','4h','0.002660000000000','0.002640000000000','0.711908500000000','0.706555804511278','267.63477443609025','267.634774436090254','test'),('2019-06-07 07:59:59','2019-06-07 11:59:59','ARDRBNB','4h','0.003740000000000','0.003620000000000','0.711908500000000','0.689066516042781','190.34986631016045','190.349866310160451','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','ARDRBNB','4h','0.003030000000000','0.002960000000000','0.474605666666667','0.463641179317932','156.63553355335534','156.635533553355344','test'),('2019-06-14 07:59:59','2019-06-15 11:59:59','ARDRBNB','4h','0.003060000000000','0.003040000000000','0.526681684578448','0.523239320626955','172.11819757465634','172.118197574656335','test'),('2019-06-18 07:59:59','2019-06-18 11:59:59','ARDRBNB','4h','0.003090000000000','0.003260000000000','0.526681684578448','0.555657699587618','170.44714711276634','170.447147112766345','test'),('2019-06-23 03:59:59','2019-06-23 07:59:59','ARDRBNB','4h','0.003200000000000','0.003170000000000','0.533065097342868','0.528067612055279','166.5828429196461','166.582842919646112','test'),('2019-06-24 15:59:59','2019-06-24 19:59:59','ARDRBNB','4h','0.003180000000000','0.003140000000000','0.533065097342868','0.526359875992643','167.63053375561887','167.630533755618870','test'),('2019-06-25 03:59:59','2019-06-25 07:59:59','ARDRBNB','4h','0.003330000000000','0.003260000000000','0.533065097342868','0.521859524726051','160.07960881167207','160.079608811672074','test'),('2019-06-28 11:59:59','2019-07-01 11:59:59','ARDRBNB','4h','0.003280000000000','0.003370000000000','0.533065097342868','0.547691883550447','162.5198467508744','162.519846750874393','test'),('2019-07-02 11:59:59','2019-07-04 11:59:59','ARDRBNB','4h','0.003350000000000','0.003350000000000','0.533065097342868','0.533065097342868','159.12390965458746','159.123909654587465','test'),('2019-07-06 15:59:59','2019-07-06 19:59:59','ARDRBNB','4h','0.003380000000000','0.003310000000000','0.533065097342868','0.522025287634584','157.71156726120356','157.711567261203555','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','ARDRBNB','4h','0.003370000000000','0.003330000000000','0.533065097342868','0.526737915178561','158.17955410767595','158.179554107675955','test'),('2019-07-22 15:59:59','2019-07-22 19:59:59','ARDRBNB','4h','0.002519000000000','0.002444000000000','0.533065097342868','0.517193766536709','211.61774408212307','211.617744082123068','test'),('2019-07-23 11:59:59','2019-07-23 15:59:59','ARDRBNB','4h','0.002434000000000','0.002356000000000','0.533065097342868','0.515982485349136','219.00784607348726','219.007846073487258','test'),('2019-07-26 07:59:59','2019-07-26 11:59:59','ARDRBNB','4h','0.002443000000000','0.002404000000000','0.533065097342868','0.524555257475340','218.20102224431764','218.201022244317642','test'),('2019-08-03 23:59:59','2019-08-04 07:59:59','ARDRBNB','4h','0.002428000000000','0.002432000000000','0.533065097342868','0.533943293549364','219.54905162391597','219.549051623915972','test'),('2019-08-20 11:59:59','2019-08-20 19:59:59','ARDRBNB','4h','0.002071000000000','0.002034000000000','0.533065097342868','0.523541481407723','257.3950252741999','257.395025274199895','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','ARDRBNB','4h','0.002039000000000','0.002020000000000','0.533065097342868','0.528097840427952','261.434574469283','261.434574469283007','test'),('2019-09-06 15:59:59','2019-09-06 19:59:59','ARDRBNB','4h','0.002476000000000','0.002435000000000','0.533065097342868','0.524238090480567','215.29285030002748','215.292850300027482','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','ARDRBNB','4h','0.002497000000000','0.002494000000000','0.533065097342868','0.532424650690073','213.48221759826512','213.482217598265123','test'),('2019-09-18 15:59:59','2019-09-18 19:59:59','ARDRBNB','4h','0.002735000000000','0.002797000000000','0.533065097342868','0.545149205582450','194.90497160616746','194.904971606167464','test'),('2019-09-19 15:59:59','2019-09-20 07:59:59','ARDRBNB','4h','0.002777000000000','0.002868000000000','0.533065097342868','0.550533201000845','191.9571830546878','191.957183054687789','test'),('2019-10-09 15:59:59','2019-10-09 19:59:59','ARDRBNB','4h','0.003574000000000','0.003452000000000','0.533065097342868','0.514868695027303','149.1508386521735','149.150838652173491','test'),('2019-10-23 23:59:59','2019-10-24 03:59:59','ARDRBNB','4h','0.002941000000000','0.002896000000000','0.533065097342868','0.524908711970400','181.25300827707173','181.253008277071729','test'),('2019-11-01 15:59:59','2019-11-02 03:59:59','ARDRBNB','4h','0.002824000000000','0.002748000000000','0.533065097342868','0.518719152796813','188.76242823755948','188.762428237559476','test'),('2019-11-03 15:59:59','2019-11-04 03:59:59','ARDRBNB','4h','0.002860000000000','0.002752000000000','0.533065097342868','0.512935366394256','186.38639767233147','186.386397672331469','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ARDRBNB','4h','0.002800000000000','0.002753000000000','0.533065097342868','0.524117218923184','190.38039190816716','190.380391908167155','test'),('2019-11-10 03:59:59','2019-11-10 07:59:59','ARDRBNB','4h','0.002750000000000','0.002720000000000','0.533065097342868','0.527249841735491','193.84185357922473','193.841853579224733','test'),('2019-11-12 15:59:59','2019-11-12 19:59:59','ARDRBNB','4h','0.002730000000000','0.002690000000000','0.533065097342868','0.525254619726123','195.26194041863297','195.261940418632975','test'),('2019-11-16 19:59:59','2019-11-17 15:59:59','ARDRBNB','4h','0.002660000000000','0.002646000000000','0.533065097342868','0.530259491567379','200.4004125349128','200.400412534912789','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:35:20
