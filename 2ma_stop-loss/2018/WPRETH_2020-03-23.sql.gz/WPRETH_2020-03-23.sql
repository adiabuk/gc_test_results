-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 23:59:59','2018-09-17 07:59:59','WPRETH','4h','0.000094620000000','0.000090390000000','0.072144500000000','0.068919270291693','762.4656520820123','762.465652082012298','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WPRETH','4h','0.000092520000000','0.000097860000000','0.072144500000000','0.076308482166018','779.7719412019022','779.771941201902223','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','WPRETH','4h','0.000131500000000','0.000129970000000','0.072379188114428','0.071537057636747','550.4120769158004','550.412076915800412','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','WPRETH','4h','0.000141090000000','0.000136140000000','0.072379188114428','0.069839837478902','513.0001283891701','513.000128389170072','test'),('2018-11-09 19:59:59','2018-11-09 23:59:59','WPRETH','4h','0.000173400000000','0.000171590000000','0.072379188114428','0.071623672944375','417.41169616163785','417.411696161637849','test'),('2018-11-26 19:59:59','2018-11-27 07:59:59','WPRETH','4h','0.000137870000000','0.000130230000000','0.072379188114428','0.068368330080090','524.9814181071154','524.981418107115360','test'),('2018-12-07 07:59:59','2018-12-07 11:59:59','WPRETH','4h','0.000142330000000','0.000143710000000','0.072379188114428','0.073080960612130','508.5307954361555','508.530795436155472','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','WPRETH','4h','0.000142820000000','0.000143660000000','0.072379188114428','0.072804888422621','506.78608118210343','506.786081182103430','test'),('2018-12-11 23:59:59','2018-12-12 07:59:59','WPRETH','4h','0.000143090000000','0.000140450000000','0.072379188114428','0.071043797404930','505.8298142038438','505.829814203843796','test'),('2018-12-14 23:59:59','2018-12-15 03:59:59','WPRETH','4h','0.000146500000000','0.000144910000000','0.072379188114428','0.071593639246838','494.05589156606146','494.055891566061462','test'),('2018-12-15 15:59:59','2018-12-15 19:59:59','WPRETH','4h','0.000141430000000','0.000141920000000','0.072379188114428','0.072629953879655','511.7668678104221','511.766867810422127','test'),('2018-12-16 23:59:59','2018-12-17 03:59:59','WPRETH','4h','0.000151000000000','0.000143930000000','0.072379188114428','0.068990308247084','479.3323716187285','479.332371618728473','test'),('2018-12-19 07:59:59','2018-12-19 11:59:59','WPRETH','4h','0.000142910000000','0.000143670000000','0.072379188114428','0.072764102976698','506.46692403910157','506.466924039101571','test'),('2019-01-10 11:59:59','2019-01-10 19:59:59','WPRETH','4h','0.000094300000000','0.000093110000000','0.072379188114428','0.071465813418180','767.541761552789','767.541761552789012','test'),('2019-01-11 11:59:59','2019-01-11 15:59:59','WPRETH','4h','0.000096880000000','0.000094670000000','0.072379188114428','0.070728093918176','747.1014462678366','747.101446267836650','test'),('2019-02-02 07:59:59','2019-02-03 15:59:59','WPRETH','4h','0.000112620000000','0.000111440000000','0.072379188114428','0.071620819778653','642.6850303181318','642.685030318131794','test'),('2019-03-01 15:59:59','2019-03-06 11:59:59','WPRETH','4h','0.000079250000000','0.000083870000000','0.072379188114428','0.076598643623433','913.3020582262209','913.302058226220879','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','WPRETH','4h','0.000086120000000','0.000085410000000','0.072379188114428','0.071782471630902','840.4457514448213','840.445751444821326','test'),('2019-03-20 03:59:59','2019-03-21 15:59:59','WPRETH','4h','0.000090520000000','0.000089230000000','0.072379188114428','0.071347712720398','799.593328705568','799.593328705567956','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','WPRETH','4h','0.000090490000000','0.000088640000000','0.072379188114428','0.070899450043794','799.8584165590453','799.858416559045281','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','WPRETH','4h','0.000090380000000','0.000090260000000','0.072379188114428','0.072283088285110','800.8319109806152','800.831910980615248','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','WPRETH','4h','0.000090620000000','0.000090720000000','0.072379188114428','0.072459059211442','798.7109701437653','798.710970143765280','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','WPRETH','4h','0.000093820000000','0.000095880000000','0.072379188114428','0.073968413519626','771.4686433002345','771.468643300234476','test'),('2019-04-07 11:59:59','2019-04-07 23:59:59','WPRETH','4h','0.000097690000000','0.000099770000000','0.072379188114428','0.073920274318523','740.9068288916778','740.906828891677833','test'),('2019-04-19 23:59:59','2019-04-20 03:59:59','WPRETH','4h','0.000088400000000','0.000085320000000','0.072379188114428','0.069857379297771','818.7690963170589','818.769096317058938','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WPRETH','4h','0.000048530000000','0.000047310000000','0.072379188114428','0.070559641246519','1491.4318589414386','1491.431858941438577','test'),('2019-05-26 03:59:59','2019-05-26 19:59:59','WPRETH','4h','0.000050860000000','0.000048810000000','0.072379188114428','0.069461820131051','1423.1063333548566','1423.106333354856588','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','WPRETH','4h','0.000050190000000','0.000050640000000','0.072379188114428','0.073028134810015','1442.103767970273','1442.103767970273111','test'),('2019-06-03 15:59:59','2019-06-03 19:59:59','WPRETH','4h','0.000048620000000','0.000049090000000','0.072379188114428','0.073078863524008','1488.6710842128343','1488.671084212834330','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','WPRETH','4h','0.000048350000000','0.000047760000000','0.072379188114428','0.071495967411480','1496.9842422839297','1496.984242283929689','test'),('2019-06-13 15:59:59','2019-06-13 19:59:59','WPRETH','4h','0.000053430000000','0.000052430000000','0.072379188114428','0.071024533648502','1354.6544659260342','1354.654465926034163','test'),('2019-06-13 23:59:59','2019-06-14 15:59:59','WPRETH','4h','0.000053970000000','0.000052150000000','0.072379188114428','0.069938385402398','1341.1003912252734','1341.100391225273370','test'),('2019-07-14 19:59:59','2019-07-14 23:59:59','WPRETH','4h','0.000036870000000','0.000033770000000','0.072379188114428','0.066293604085279','1963.091622306157','1963.091622306156978','test'),('2019-07-22 07:59:59','2019-07-22 11:59:59','WPRETH','4h','0.000033200000000','0.000032520000000','0.072379188114428','0.070896722815699','2180.096027543012','2180.096027543012042','test'),('2019-07-22 19:59:59','2019-07-22 23:59:59','WPRETH','4h','0.000033380000000','0.000032820000000','0.072379188114428','0.071164917732640','2168.3399674783705','2168.339967478370454','test'),('2019-07-25 03:59:59','2019-07-25 07:59:59','WPRETH','4h','0.000033170000000','0.000032700000000','0.072379188114428','0.071353616259928','2182.0677755329516','2182.067775532951600','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','WPRETH','4h','0.000033040000000','0.000032340000000','0.072379188114428','0.070845730739122','2190.6533932938255','2190.653393293825502','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','WPRETH','4h','0.000033180000000','0.000032470000000','0.072379188114428','0.070830386922106','2181.410130030983','2181.410130030983055','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','WPRETH','4h','0.000033180000000','0.000032410000000','0.072379188114428','0.070699502314304','2181.410130030983','2181.410130030983055','test'),('2019-07-28 19:59:59','2019-07-29 03:59:59','WPRETH','4h','0.000033180000000','0.000032660000000','0.072379188114428','0.071244854846812','2181.410130030983','2181.410130030983055','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','WPRETH','4h','0.000034150000000','0.000033700000000','0.072379188114428','0.071425436001646','2119.4491395147293','2119.449139514729268','test'),('2019-08-12 19:59:59','2019-08-12 23:59:59','WPRETH','4h','0.000037480000000','0.000029190000000','0.072379188114428','0.056370024041093','1931.1416252515476','1931.141625251547566','test'),('2019-08-17 15:59:59','2019-08-18 23:59:59','WPRETH','4h','0.000029300000000','0.000029850000000','0.072379188114428','0.073737841816235','2470.2794578303074','2470.279457830307365','test'),('2019-08-21 11:59:59','2019-08-21 19:59:59','WPRETH','4h','0.000030910000000','0.000030630000000','0.072379188114428','0.071723537105951','2341.6107445625366','2341.610744562536638','test'),('2019-08-24 07:59:59','2019-08-29 15:59:59','WPRETH','4h','0.000031820000000','0.000032770000000','0.072379188114428','0.074540100393143','2274.6445039103714','2274.644503910371441','test'),('2019-08-30 07:59:59','2019-08-30 11:59:59','WPRETH','4h','0.000035090000000','0.000033850000000','0.072379188114428','0.069821473857891','2062.672787530009','2062.672787530008918','test'),('2019-09-02 03:59:59','2019-09-02 07:59:59','WPRETH','4h','0.000033170000000','0.000032340000000','0.072379188114428','0.070568071860736','2182.0677755329516','2182.067775532951600','test'),('2019-09-08 23:59:59','2019-09-09 07:59:59','WPRETH','4h','0.000032000000000','0.000031000000000','0.072379188114428','0.070117338485852','2261.849628575875','2261.849628575875158','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','WPRETH','4h','0.000033240000000','0.000032250000000','0.072379188114428','0.070223490273475','2177.4725666193744','2177.472566619374447','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:51:43
