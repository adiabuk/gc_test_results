-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-19 19:59:59','2018-09-20 07:59:59','QLCBNB','4h','0.005537000000000','0.005676000000000','0.711908500000000','0.729780141954127','128.57296369875385','128.572963698753853','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','QLCBNB','4h','0.006109000000000','0.005937000000000','0.716376410488532','0.696206703072584','117.26574079039642','117.265740790396421','test'),('2018-09-26 11:59:59','2018-09-26 23:59:59','QLCBNB','4h','0.005827000000000','0.005700000000000','0.716376410488532','0.700762920848573','122.94086330676711','122.940863306767113','test'),('2018-09-30 15:59:59','2018-09-30 19:59:59','QLCBNB','4h','0.005813000000000','0.005812000000000','0.716376410488532','0.716253173535068','123.23695346439567','123.236953464395668','test'),('2018-10-08 19:59:59','2018-10-10 11:59:59','QLCBNB','4h','0.005567000000000','0.005644000000000','0.716376410488532','0.726284975893169','128.6826675926948','128.682667592694798','test'),('2018-10-16 15:59:59','2018-10-16 19:59:59','QLCBNB','4h','0.005342000000000','0.005278000000000','0.716376410488532','0.707793840239324','134.10266014386596','134.102660143865961','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','QLCBNB','4h','0.005300000000000','0.005190000000000','0.716376410488532','0.701508220836883','135.16536046953433','135.165360469534335','test'),('2018-10-21 07:59:59','2018-10-21 11:59:59','QLCBNB','4h','0.005249000000000','0.005251000000000','0.716376410488532','0.716649367779631','136.4786455493488','136.478645549348812','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','QLCBNB','4h','0.005217000000000','0.005263000000000','0.716376410488532','0.722692936247105','137.31577736027063','137.315777360270630','test'),('2018-10-23 15:59:59','2018-10-23 19:59:59','QLCBNB','4h','0.005221000000000','0.005198000000000','0.716376410488532','0.713220567270521','137.21057469613714','137.210574696137144','test'),('2018-10-23 23:59:59','2018-10-24 07:59:59','QLCBNB','4h','0.005308000000000','0.005228000000000','0.716376410488532','0.705579478906188','134.96164477930142','134.961644779301423','test'),('2018-10-25 03:59:59','2018-10-25 07:59:59','QLCBNB','4h','0.005224000000000','0.005217000000000','0.716376410488532','0.715416488039562','137.13177842429783','137.131778424297835','test'),('2018-10-25 19:59:59','2018-10-31 15:59:59','QLCBNB','4h','0.005238000000000','0.005666000000000','0.716376410488532','0.774911940020623','136.76525591610005','136.765255916100045','test'),('2018-11-07 07:59:59','2018-11-07 11:59:59','QLCBNB','4h','0.005647000000000','0.005779000000000','0.716567332195244','0.733317268063806','126.89345354971555','126.893453549715545','test'),('2018-11-10 23:59:59','2018-11-11 07:59:59','QLCBNB','4h','0.005596000000000','0.005629000000000','0.720754816162384','0.725005157287001','128.79821589749537','128.798215897495368','test'),('2018-11-18 19:59:59','2018-11-19 03:59:59','QLCBNB','4h','0.005341000000000','0.005261000000000','0.721817401443538','0.711005682268199','135.14648969173157','135.146489691731574','test'),('2018-11-28 11:59:59','2018-12-02 15:59:59','QLCBNB','4h','0.004852000000000','0.005991000000000','0.721817401443538','0.891262995063527','148.76698298506554','148.766982985065539','test'),('2018-12-16 07:59:59','2018-12-16 11:59:59','QLCBNB','4h','0.004304000000000','0.004086000000000','0.761475870054701','0.722906692621633','176.92283226177994','176.922832261779945','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','QLCBNB','4h','0.004120000000000','0.004106000000000','0.761475870054701','0.758888330690437','184.82424030453905','184.824240304539046','test'),('2018-12-19 11:59:59','2018-12-19 15:59:59','QLCBNB','4h','0.004195000000000','0.003946000000000','0.761475870054701','0.716277421510334','181.51987367215756','181.519873672157559','test'),('2018-12-20 15:59:59','2018-12-22 15:59:59','QLCBNB','4h','0.004100000000000','0.004066000000000','0.761475870054701','0.755161192107906','185.7258219645612','185.725821964561192','test'),('2018-12-23 15:59:59','2018-12-23 23:59:59','QLCBNB','4h','0.004157000000000','0.004127000000000','0.761475870054701','0.755980494519064','183.17918452121745','183.179184521217451','test'),('2019-01-02 07:59:59','2019-01-02 23:59:59','QLCBNB','4h','0.004330000000000','0.004291000000000','0.761475870054701','0.754617311409866','175.86047807267923','175.860478072679228','test'),('2019-01-03 07:59:59','2019-01-03 19:59:59','QLCBNB','4h','0.004356000000000','0.004357000000000','0.761475870054701','0.761650680860499','174.81080579768158','174.810805797681581','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','QLCBNB','4h','0.004359000000000','0.004337000000000','0.761475870054701','0.757632679152842','174.69049553904588','174.690495539045884','test'),('2019-01-09 15:59:59','2019-01-10 07:59:59','QLCBNB','4h','0.004537000000000','0.004533000000000','0.761475870054701','0.760804522582755','167.83686798648907','167.836867986489068','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','QLCBNB','4h','0.004767000000000','0.005425000000000','0.761475870054701','0.866584139930093','159.7390119686807','159.739011968680700','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','QLCBNB','4h','0.003889000000000','0.003797000000000','0.761475870054701','0.743462041295371','195.80248651445126','195.802486514451260','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','QLCBNB','4h','0.002625000000000','0.002565000000000','0.761475870054701','0.744070707310593','290.0860457351242','290.086045735124173','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','QLCBNB','4h','0.002578000000000','0.002486000000000','0.761475870054701','0.734301401456938','295.3746586713347','295.374658671334714','test'),('2019-02-26 03:59:59','2019-02-27 23:59:59','QLCBNB','4h','0.002578000000000','0.002531000000000','0.761475870054701','0.747593261097148','295.3746586713347','295.374658671334714','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','QLCBNB','4h','0.002591000000000','0.002510000000000','0.761475870054701','0.737670564970011','293.8926553665384','293.892655366538406','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','QLCBNB','4h','0.002594000000000','0.002447000000000','0.761475870054701','0.718323613733174','293.5527640920204','293.552764092020425','test'),('2019-03-02 07:59:59','2019-03-02 11:59:59','QLCBNB','4h','0.002672000000000','0.002591000000000','0.761475870054701','0.738392207826246','284.9834843019091','284.983484301909073','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','QLCBNB','4h','0.002694000000000','0.002663000000000','0.761475870054701','0.752713527080798','282.65622496462544','282.656224964625437','test'),('2019-03-10 19:59:59','2019-03-10 23:59:59','QLCBNB','4h','0.002469000000000','0.002433000000000','0.761475870054701','0.750372941208217','308.41469018011384','308.414690180113837','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','QLCBNB','4h','0.002379000000000','0.002266000000000','0.761475870054701','0.725306566432935','320.0823329359819','320.082332935981924','test'),('2019-03-15 11:59:59','2019-03-15 19:59:59','QLCBNB','4h','0.002388000000000','0.002350000000000','0.761475870054701','0.749358582340263','318.87599248521815','318.875992485218148','test'),('2019-03-20 07:59:59','2019-03-20 11:59:59','QLCBNB','4h','0.002335000000000','0.002285000000000','0.761475870054701','0.745170176905778','326.11386297845866','326.113862978458656','test'),('2019-03-26 03:59:59','2019-03-26 15:59:59','QLCBNB','4h','0.002500000000000','0.002413000000000','0.761475870054701','0.734976509776797','304.5903480218804','304.590348021880402','test'),('2019-05-06 07:59:59','2019-05-10 03:59:59','QLCBNB','4h','0.001496000000000','0.001548000000000','0.761475870054701','0.787944282650185','509.00793452854344','509.007934528543444','test'),('2019-05-21 07:59:59','2019-05-21 15:59:59','QLCBNB','4h','0.001420000000000','0.001308000000000','0.761475870054701','0.701415801430668','536.2506127145781','536.250612714578097','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','QLCBNB','4h','0.001451000000000','0.001428000000000','0.761475870054701','0.749405611604489','524.7938456614066','524.793845661406635','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','QLCBNB','4h','0.001298000000000','0.001283000000000','0.761475870054701','0.752676071864547','586.6532126769654','586.653212676965381','test'),('2019-06-06 15:59:59','2019-06-06 19:59:59','QLCBNB','4h','0.001309000000000','0.001303000000000','0.761475870054701','0.757985529932219','581.7233537469067','581.723353746906696','test'),('2019-06-10 15:59:59','2019-06-11 03:59:59','QLCBNB','4h','0.001311000000000','0.001318000000000','0.761475870054701','0.765541721382224','580.8359039318848','580.835903931884786','test'),('2019-06-26 03:59:59','2019-06-26 07:59:59','QLCBNB','4h','0.001097000000000','0.001078000000000','0.761475870054701','0.748287135751110','694.1439107153153','694.143910715315315','test'),('2019-07-01 11:59:59','2019-07-01 15:59:59','QLCBNB','4h','0.001024000000000','0.000995000000000','0.761475870054701','0.739910635453542','743.6287793502939','743.628779350293939','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','QLCBNB','4h','0.001024000000000','0.001019000000000','0.761475870054701','0.757757726157949','743.6287793502939','743.628779350293939','test'),('2019-07-07 03:59:59','2019-07-07 07:59:59','QLCBNB','4h','0.000974000000000','0.000963000000000','0.761475870054701','0.752876039900079','781.8027413292617','781.802741329261721','test'),('2019-07-07 11:59:59','2019-07-07 23:59:59','QLCBNB','4h','0.000972000000000','0.000965000000000','0.761475870054701','0.755991990332085','783.4113889451656','783.411388945165641','test'),('2019-07-26 23:59:59','2019-07-27 15:59:59','QLCBNB','4h','0.000806000000000','0.000782000000000','0.761475870054701','0.738801650598978','944.7591439884628','944.759143988462824','test'),('2019-07-30 23:59:59','2019-07-31 11:59:59','QLCBNB','4h','0.000792000000000','0.000785000000000','0.761475870054701','0.754745654031490','961.4594318872488','961.459431887248797','test'),('2019-08-20 15:59:59','2019-08-20 19:59:59','QLCBNB','4h','0.000520000000000','0.000506000000000','0.761475870054701','0.740974596630152','1464.3766731821174','1464.376673182117429','test'),('2019-08-21 19:59:59','2019-08-25 11:59:59','QLCBNB','4h','0.000520000000000','0.000646000000000','0.761475870054701','0.945987330875648','1464.3766731821174','1464.376673182117429','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','QLCBNB','4h','0.000643000000000','0.000622000000000','0.761475870054701','0.736606518155558','1184.2548523401258','1184.254852340125808','test'),('2019-09-03 23:59:59','2019-09-04 07:59:59','QLCBNB','4h','0.000659000000000','0.000648000000000','0.761475870054701','0.748765347185806','1155.5020789904415','1155.502078990441532','test'),('2019-09-07 23:59:59','2019-09-08 07:59:59','QLCBNB','4h','0.000657000000000','0.000647000000000','0.761475870054701','0.749885674163457','1159.0195891243545','1159.019589124354525','test'),('2019-09-09 11:59:59','2019-09-12 11:59:59','QLCBNB','4h','0.000655000000000','0.000663000000000','0.761475870054701','0.770776338696590','1162.5585802361848','1162.558580236184753','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:54:00
