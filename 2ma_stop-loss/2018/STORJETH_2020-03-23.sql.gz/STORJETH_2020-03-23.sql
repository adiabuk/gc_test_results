-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 11:59:59','2018-04-26 15:59:59','STORJETH','4h','0.001916500000000','0.001810500000000','0.072144500000000','0.068154248499870','37.64388207670232','37.643882076702319','test'),('2018-05-28 03:59:59','2018-05-28 07:59:59','STORJETH','4h','0.001281900000000','0.001319900000000','0.072144500000000','0.074283115336610','56.27935096341368','56.279350963413677','test'),('2018-05-30 15:59:59','2018-05-30 19:59:59','STORJETH','4h','0.001289200000000','0.001294200000000','0.072144500000000','0.072424303366429','55.96067328575862','55.960673285758617','test'),('2018-06-05 23:59:59','2018-06-06 03:59:59','STORJETH','4h','0.001334600000000','0.001320000000000','0.072144500000000','0.071355267495879','54.0570208302113','54.057020830211300','test'),('2018-06-14 15:59:59','2018-06-14 19:59:59','STORJETH','4h','0.001264900000000','0.001198200000000','0.072144500000000','0.068340216538857','57.03573405012254','57.035734050122542','test'),('2018-06-30 19:59:59','2018-07-01 03:59:59','STORJETH','4h','0.001065300000000','0.001057200000000','0.072144500000000','0.071595949873275','67.72223786726744','67.722237867267438','test'),('2018-07-01 23:59:59','2018-07-04 15:59:59','STORJETH','4h','0.001069100000000','0.001113700000000','0.072144500000000','0.075154176082686','67.48152651763166','67.481526517631664','test'),('2018-07-06 19:59:59','2018-07-07 07:59:59','STORJETH','4h','0.001078400000000','0.001059000000000','0.072144500000000','0.070846648275223','66.8995734421365','66.899573442136500','test'),('2018-07-18 07:59:59','2018-07-18 11:59:59','STORJETH','4h','0.001041700000000','0.001015300000000','0.072144500000000','0.070316128299894','69.25650379187866','69.256503791878657','test'),('2018-07-21 23:59:59','2018-07-22 03:59:59','STORJETH','4h','0.001017600000000','0.001012900000000','0.072144500000000','0.071811285426494','70.8967177672956','70.896717767295598','test'),('2018-07-22 11:59:59','2018-07-23 11:59:59','STORJETH','4h','0.001034200000000','0.001020000000000','0.072144500000000','0.071153925739702','69.75875072519821','69.758750725198212','test'),('2018-07-24 11:59:59','2018-07-24 15:59:59','STORJETH','4h','0.001039700000000','0.001029900000000','0.072144500000000','0.071464480667500','69.38972780609791','69.389727806097909','test'),('2018-08-02 11:59:59','2018-08-02 15:59:59','STORJETH','4h','0.001047800000000','0.001029300000000','0.072144500000000','0.070870713733537','68.85331170070624','68.853311700706243','test'),('2018-08-02 19:59:59','2018-08-02 23:59:59','STORJETH','4h','0.001058300000000','0.001040200000000','0.072144500000000','0.070910619767552','68.170178588302','68.170178588301994','test'),('2018-08-04 11:59:59','2018-08-04 15:59:59','STORJETH','4h','0.001031500000000','0.001005400000000','0.072144500000000','0.070319030828890','69.94134755210858','69.941347552108581','test'),('2018-08-05 15:59:59','2018-08-08 15:59:59','STORJETH','4h','0.001064400000000','0.001161700000000','0.072144500000000','0.078739445368283','67.77950018789929','67.779500187899288','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','STORJETH','4h','0.001034700000000','0.001038100000000','0.072144500000000','0.072381565139654','69.72504107470765','69.725041074707647','test'),('2018-08-25 03:59:59','2018-08-25 19:59:59','STORJETH','4h','0.001027200000000','0.001034400000000','0.072144500000000','0.072650185747664','70.2341316199377','70.234131619937699','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','STORJETH','4h','0.001100400000000','0.001092600000000','0.072144500000000','0.071633115866957','65.56206833878589','65.562068338785892','test'),('2018-09-03 23:59:59','2018-09-04 03:59:59','STORJETH','4h','0.001099200000000','0.001100400000000','0.072144500000000','0.072223260371179','65.63364264919942','65.633642649199416','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','STORJETH','4h','0.001186400000000','0.001177300000000','0.072144500000000','0.071591132712407','60.80959204315577','60.809592043155767','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','STORJETH','4h','0.001282600000000','0.001269900000000','0.072144500000000','0.071430142328084','56.24863558397006','56.248635583970056','test'),('2018-09-25 19:59:59','2018-09-25 23:59:59','STORJETH','4h','0.001251000000000','0.001234700000000','0.072144500000000','0.071204487729816','57.66946442845724','57.669464428457239','test'),('2018-10-05 15:59:59','2018-10-06 03:59:59','STORJETH','4h','0.001194200000000','0.001201700000000','0.072144500000000','0.072597593074862','60.412409981577625','60.412409981577625','test'),('2018-10-08 07:59:59','2018-10-08 15:59:59','STORJETH','4h','0.001192300000000','0.001208000000000','0.072144500000000','0.073094486287008','60.50868070116581','60.508680701165808','test'),('2018-10-27 15:59:59','2018-10-27 19:59:59','STORJETH','4h','0.001648400000000','0.001618200000000','0.072144500000000','0.070822755338510','43.7663795195341','43.766379519534098','test'),('2018-10-31 19:59:59','2018-10-31 23:59:59','STORJETH','4h','0.001864400000000','0.001737800000000','0.072144500000000','0.067245608292212','38.69582707573482','38.695827075734819','test'),('2018-11-21 19:59:59','2018-11-21 23:59:59','STORJETH','4h','0.001336400000000','0.001311500000000','0.072144500000000','0.070800293138282','53.98421131397785','53.984211313977852','test'),('2018-11-23 15:59:59','2018-11-23 23:59:59','STORJETH','4h','0.001321100000000','0.001301400000000','0.072144500000000','0.071068694497010','54.609416395428056','54.609416395428056','test'),('2018-11-24 07:59:59','2018-11-24 19:59:59','STORJETH','4h','0.001319100000000','0.001301900000000','0.072144500000000','0.071203793912516','54.69221438859829','54.692214388598288','test'),('2018-11-26 23:59:59','2018-11-27 07:59:59','STORJETH','4h','0.001302200000000','0.001277000000000','0.072144500000000','0.070748369298111','55.40201197972661','55.402011979726609','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','STORJETH','4h','0.001307100000000','0.001365900000000','0.072144500000000','0.075389926210695','55.19432331114681','55.194323311146810','test'),('2018-12-06 19:59:59','2018-12-06 23:59:59','STORJETH','4h','0.001464000000000','0.001464400000000','0.072144500000000','0.072164211612022','49.27903005464481','49.279030054644807','test'),('2018-12-09 11:59:59','2018-12-09 15:59:59','STORJETH','4h','0.001500000000000','0.001420900000000','0.072144500000000','0.068340080033333','48.096333333333334','48.096333333333334','test'),('2018-12-11 07:59:59','2018-12-11 11:59:59','STORJETH','4h','0.001480600000000','0.001446600000000','0.072144500000000','0.070487797987302','48.726529785222205','48.726529785222205','test'),('2018-12-14 19:59:59','2018-12-14 23:59:59','STORJETH','4h','0.001510600000000','0.001462000000000','0.072144500000000','0.069823420495167','47.758837547994176','47.758837547994176','test'),('2018-12-17 03:59:59','2018-12-17 15:59:59','STORJETH','4h','0.001471100000000','0.001449100000000','0.072144500000000','0.071065593739379','49.04119366460472','49.041193664604720','test'),('2019-01-08 19:59:59','2019-01-08 23:59:59','STORJETH','4h','0.001037800000000','0.001027000000000','0.072144500000000','0.071393718924648','69.51676623626904','69.516766236269035','test'),('2019-01-12 19:59:59','2019-01-12 23:59:59','STORJETH','4h','0.001030300000000','0.001044800000000','0.072144500000000','0.073159830728914','70.02280889061439','70.022808890614385','test'),('2019-01-15 19:59:59','2019-01-28 23:59:59','STORJETH','4h','0.001060000000000','0.001199400000000','0.072144500000000','0.081632182358491','68.06084905660377','68.060849056603772','test'),('2019-02-03 07:59:59','2019-02-06 11:59:59','STORJETH','4h','0.001225200000000','0.001256300000000','0.072144500000000','0.073975787912178','58.883855697029055','58.883855697029055','test'),('2019-02-07 11:59:59','2019-02-07 23:59:59','STORJETH','4h','0.001428700000000','0.001382000000000','0.072144500000000','0.069786308532232','50.49660530552251','50.496605305522507','test'),('2019-02-16 07:59:59','2019-02-16 11:59:59','STORJETH','4h','0.001196800000000','0.001650500000000','0.072144500000000','0.099494065215575','60.28116644385027','60.281166443850267','test'),('2019-02-24 19:59:59','2019-02-25 03:59:59','STORJETH','4h','0.001608400000000','0.001552000000000','0.075378115696222','0.072734913927217','46.865279592279435','46.865279592279435','test'),('2019-03-07 23:59:59','2019-03-08 03:59:59','STORJETH','4h','0.001648500000000','0.001641100000000','0.075378115696222','0.075039748661856','45.725274914299064','45.725274914299064','test'),('2019-04-17 07:59:59','2019-04-17 11:59:59','STORJETH','4h','0.001775400000000','0.001739900000000','0.075378115696222','0.073870893038108','42.45697628490594','42.456976284905942','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:00:35
