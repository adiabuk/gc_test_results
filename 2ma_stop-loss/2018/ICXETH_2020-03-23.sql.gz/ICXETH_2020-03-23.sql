-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-14 03:59:59','2018-06-14 19:59:59','ICXETH','4h','0.004286000000000','0.004385000000000','0.072144500000000','0.073810926854876','16.83259449370042','16.832594493700419','test'),('2018-07-01 23:59:59','2018-07-02 03:59:59','ICXETH','4h','0.003652000000000','0.003637000000000','0.072561106713719','0.072263073690525','19.86886821295701','19.868868212957011','test'),('2018-07-02 15:59:59','2018-07-03 11:59:59','ICXETH','4h','0.003735000000000','0.003653000000000','0.072561106713719','0.070968065013445','19.42733780822463','19.427337808224632','test'),('2018-07-04 15:59:59','2018-07-04 19:59:59','ICXETH','4h','0.003774000000000','0.003721000000000','0.072561106713719','0.071542098060877','19.226578355516427','19.226578355516427','test'),('2018-07-08 19:59:59','2018-07-08 23:59:59','ICXETH','4h','0.003642000000000','0.003543000000000','0.072561106713719','0.070588687832704','19.923423040559857','19.923423040559857','test'),('2018-07-17 23:59:59','2018-07-18 23:59:59','ICXETH','4h','0.003277000000000','0.003233000000000','0.072561106713719','0.071586834911643','22.14254095627678','22.142540956276779','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','ICXETH','4h','0.003316000000000','0.003265000000000','0.072561106713719','0.071445118643032','21.882119033087758','21.882119033087758','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','ICXETH','4h','0.002162000000000','0.002105000000000','0.072561106713719','0.070648071060305','33.56202900727059','33.562029007270588','test'),('2018-08-22 23:59:59','2018-08-27 07:59:59','ICXETH','4h','0.002196000000000','0.003218000000000','0.072561106713719','0.106330437798155','33.04239832136567','33.042398321365667','test'),('2018-09-12 07:59:59','2018-09-12 11:59:59','ICXETH','4h','0.003162000000000','0.003136000000000','0.078781990038953','0.078134193789423','24.915240366525143','24.915240366525143','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','ICXETH','4h','0.002980000000000','0.002931000000000','0.078781990038953','0.077486581477910','26.43690940904463','26.436909409044631','test'),('2018-09-25 07:59:59','2018-09-25 11:59:59','ICXETH','4h','0.002927000000000','0.002988000000000','0.078781990038953','0.080423842239970','26.9156098527342','26.915609852734200','test'),('2018-09-28 19:59:59','2018-09-28 23:59:59','ICXETH','4h','0.002957000000000','0.002916000000000','0.078781990038953','0.077689645909228','26.64253974939229','26.642539749392292','test'),('2018-10-01 11:59:59','2018-10-01 15:59:59','ICXETH','4h','0.002937000000000','0.002917000000000','0.078781990038953','0.078245510706035','26.823966645881175','26.823966645881175','test'),('2018-10-02 03:59:59','2018-10-02 07:59:59','ICXETH','4h','0.002923000000000','0.002936000000000','0.078781990038953','0.079132371794172','26.952442709186798','26.952442709186798','test'),('2018-10-15 15:59:59','2018-10-23 11:59:59','ICXETH','4h','0.003128000000000','0.003307000000000','0.078781990038953','0.083290294456144','25.18605819659623','25.186058196596228','test'),('2018-10-24 15:59:59','2018-10-24 23:59:59','ICXETH','4h','0.003334000000000','0.003319000000000','0.079514117564005','0.079156375583363','23.849465376126346','23.849465376126346','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','ICXETH','4h','0.003275000000000','0.003236000000000','0.079514117564005','0.078567231889197','24.279119866871756','24.279119866871756','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','ICXETH','4h','0.002323000000000','0.002260000000000','0.079514117564005','0.077357686480694','34.22906481446621','34.229064814466213','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','ICXETH','4h','0.002291000000000','0.002262000000000','0.079514117564005','0.078507609746739','34.70716611261676','34.707166112616761','test'),('2018-12-01 11:59:59','2018-12-03 03:59:59','ICXETH','4h','0.002323000000000','0.002310000000000','0.079514117564005','0.079069139721417','34.22906481446621','34.229064814466213','test'),('2018-12-04 11:59:59','2018-12-04 19:59:59','ICXETH','4h','0.002297000000000','0.002301000000000','0.079514117564005','0.079652583593720','34.61650742882238','34.616507428822381','test'),('2018-12-06 07:59:59','2018-12-06 15:59:59','ICXETH','4h','0.002321000000000','0.002268000000000','0.079514117564005','0.077698413888481','34.25855991555579','34.258559915555793','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','ICXETH','4h','0.002318000000000','0.002380000000000','0.079514117564005','0.081640897240005','34.30289800000216','34.302898000002159','test'),('2018-12-08 07:59:59','2018-12-08 11:59:59','ICXETH','4h','0.002312000000000','0.002303000000000','0.079514117564005','0.079204590289751','34.391919361593864','34.391919361593864','test'),('2018-12-09 07:59:59','2018-12-09 15:59:59','ICXETH','4h','0.002323000000000','0.002307000000000','0.079514117564005','0.078966452526974','34.22906481446621','34.229064814466213','test'),('2018-12-09 23:59:59','2018-12-10 07:59:59','ICXETH','4h','0.002336000000000','0.002312000000000','0.079514117564005','0.078697191698621','34.038577724317214','34.038577724317214','test'),('2018-12-12 19:59:59','2018-12-13 03:59:59','ICXETH','4h','0.002304000000000','0.002271000000000','0.079514117564005','0.078375243484312','34.51133574826606','34.511335748266063','test'),('2018-12-21 15:59:59','2018-12-21 19:59:59','ICXETH','4h','0.002277000000000','0.002247000000000','0.079514117564005','0.078466500731805','34.92056107334432','34.920561073344317','test'),('2018-12-22 07:59:59','2018-12-22 11:59:59','ICXETH','4h','0.002272000000000','0.002198000000000','0.079514117564005','0.076924309157431','34.997410899650085','34.997410899650085','test'),('2019-01-06 23:59:59','2019-01-08 03:59:59','ICXETH','4h','0.001827000000000','0.001805000000000','0.079514117564005','0.078556640505216','43.52168449042419','43.521684490424192','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ICXETH','4h','0.001847000000000','0.001878000000000','0.079514117564005','0.080848680446779','43.05041557336492','43.050415573364923','test'),('2019-01-27 23:59:59','2019-01-28 03:59:59','ICXETH','4h','0.001958000000000','0.001915000000000','0.079514117564005','0.077767893327410','40.60986596731614','40.609865967316139','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ICXETH','4h','0.001960000000000','0.001943000000000','0.079514117564005','0.078824454299419','40.56842732857398','40.568427328573982','test'),('2019-02-07 03:59:59','2019-02-08 19:59:59','ICXETH','4h','0.001885000000000','0.001884000000000','0.079514117564005','0.079471935008268','42.18255573687268','42.182555736872679','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','ICXETH','4h','0.001916000000000','0.001844000000000','0.079514117564005','0.076526113146151','41.500061359084036','41.500061359084036','test'),('2019-02-11 23:59:59','2019-02-12 03:59:59','ICXETH','4h','0.001902000000000','0.001860000000000','0.079514117564005','0.077758285314958','41.805529739224504','41.805529739224504','test'),('2019-02-15 19:59:59','2019-02-15 23:59:59','ICXETH','4h','0.001861000000000','0.001838000000000','0.079514117564005','0.078531406814960','42.72655430628963','42.726554306289628','test'),('2019-02-17 03:59:59','2019-02-17 11:59:59','ICXETH','4h','0.001844000000000','0.001797000000000','0.079514117564005','0.077487456216116','43.12045421041486','43.120454210414863','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','ICXETH','4h','0.001786000000000','0.001730000000000','0.079514117564005','0.077020953743409','44.5207825106411','44.520782510641098','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','ICXETH','4h','0.001746000000000','0.001757000000000','0.079514117564005','0.080015065612805','45.540731709052125','45.540731709052125','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','ICXETH','4h','0.001739000000000','0.001763000000000','0.079514117564005','0.080611494689673','45.72404690282059','45.724046902820589','test'),('2019-03-19 03:59:59','2019-03-20 07:59:59','ICXETH','4h','0.002467000000000','0.002425000000000','0.079514117564005','0.078160411468469','32.231097512770575','32.231097512770575','test'),('2019-03-24 15:59:59','2019-03-25 03:59:59','ICXETH','4h','0.002509000000000','0.002424000000000','0.079514117564005','0.076820335183399','31.691557418893986','31.691557418893986','test'),('2019-03-30 15:59:59','2019-03-30 19:59:59','ICXETH','4h','0.002372000000000','0.002370000000000','0.079514117564005','0.079447073620022','33.52197199157041','33.521971991570410','test'),('2019-03-31 07:59:59','2019-04-02 07:59:59','ICXETH','4h','0.002379000000000','0.002514000000000','0.079514117564005','0.084026267993236','33.423336512822615','33.423336512822615','test'),('2019-04-03 07:59:59','2019-04-03 23:59:59','ICXETH','4h','0.002461000000000','0.002510000000000','0.079514117564005','0.081097291786125','32.309678002440066','32.309678002440066','test'),('2019-04-22 11:59:59','2019-04-23 15:59:59','ICXETH','4h','0.002299000000000','0.002253000000000','0.079514117564005','0.077923143484864','34.58639302479557','34.586393024795569','test'),('2019-04-24 23:59:59','2019-04-25 19:59:59','ICXETH','4h','0.002353000000000','0.002314000000000','0.079514117564005','0.078196204013220','33.79265514832342','33.792655148323419','test'),('2019-04-27 23:59:59','2019-04-28 03:59:59','ICXETH','4h','0.002279000000000','0.002275000000000','0.079514117564005','0.079374557901760','34.88991556121325','34.889915561213250','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','ICXETH','4h','0.001539000000000','0.001501000000000','0.079514117564005','0.077550806019215','51.66609328395387','51.666093283953870','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','ICXETH','4h','0.001533000000000','0.001528000000000','0.079514117564005','0.079254776019439','51.86830891324527','51.868308913245272','test'),('2019-06-02 11:59:59','2019-06-02 15:59:59','ICXETH','4h','0.001531000000000','0.001658000000000','0.079514117564005','0.086109997988975','51.93606633834422','51.936066338344219','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:53:39
