-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-28 11:59:59','2018-07-28 15:59:59','VIABNB','4h','0.100370000000000','0.096320000000000','0.711908500000000','0.683182491979675','7.0928414864999505','7.092841486499950','test'),('2018-07-28 19:59:59','2018-07-28 23:59:59','VIABNB','4h','0.102790000000000','0.099450000000000','0.711908500000000','0.688776148701235','6.925853682264812','6.925853682264812','test'),('2018-07-30 19:59:59','2018-07-30 23:59:59','VIABNB','4h','0.098540000000000','0.101290000000000','0.711908500000000','0.731776049979704','7.224563628983154','7.224563628983154','test'),('2018-08-13 19:59:59','2018-08-13 23:59:59','VIABNB','4h','0.082000000000000','0.082190000000000','0.711908500000000','0.713558044085366','8.681810975609757','8.681810975609757','test'),('2018-08-25 15:59:59','2018-08-26 19:59:59','VIABNB','4h','0.084670000000000','0.084070000000000','0.711908500000000','0.706863677748908','8.40803708515413','8.408037085154129','test'),('2018-08-28 15:59:59','2018-08-28 19:59:59','VIABNB','4h','0.088950000000000','0.085450000000000','0.711908500000000','0.683896361157954','8.0034682405846','8.003468240584599','test'),('2018-09-02 07:59:59','2018-09-02 15:59:59','VIABNB','4h','0.085090000000000','0.083010000000000','0.711908500000000','0.694506106299213','8.366535433070867','8.366535433070867','test'),('2018-09-02 19:59:59','2018-09-02 23:59:59','VIABNB','4h','0.086010000000000','0.084420000000000','0.711908500000000','0.698748001046390','8.277043367050343','8.277043367050343','test'),('2018-09-03 07:59:59','2018-09-04 03:59:59','VIABNB','4h','0.084330000000000','0.083050000000000','0.711908500000000','0.701102821356575','8.441936440175501','8.441936440175501','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','VIABNB','4h','0.085440000000000','0.087060000000000','0.711908500000000','0.725406765098315','8.332262406367041','8.332262406367041','test'),('2018-09-05 19:59:59','2018-09-05 23:59:59','VIABNB','4h','0.089600000000000','0.087100000000000','0.711908500000000','0.692044981584822','7.9454073660714295','7.945407366071430','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','VIABNB','4h','0.062510000000000','0.067440000000000','0.711908500000000','0.768054859062550','11.388713805791076','11.388713805791076','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','VIABNB','4h','0.078940000000000','0.072930000000000','0.711908500000000','0.657708220230555','9.018349379275401','9.018349379275401','test'),('2018-10-10 11:59:59','2018-10-11 03:59:59','VIABNB','4h','0.062120000000000','0.060950000000000','0.711908500000000','0.698500049500966','11.460214101738572','11.460214101738572','test'),('2018-10-12 15:59:59','2018-10-12 23:59:59','VIABNB','4h','0.062070000000000','0.060930000000000','0.711908500000000','0.698833331802803','11.469445787014662','11.469445787014662','test'),('2018-10-16 03:59:59','2018-10-22 23:59:59','VIABNB','4h','0.062910000000000','0.068400000000000','0.711908500000000','0.774034992846924','11.316301065013514','11.316301065013514','test'),('2018-11-09 11:59:59','2018-11-09 19:59:59','VIABNB','4h','0.078080000000000','0.078290000000000','0.711908500000000','0.713823212922644','9.117680584016394','9.117680584016394','test'),('2018-11-10 19:59:59','2018-11-10 23:59:59','VIABNB','4h','0.077280000000000','0.078530000000000','0.711908500000000','0.723423583139234','9.212066511387164','9.212066511387164','test'),('2018-11-11 11:59:59','2018-11-13 19:59:59','VIABNB','4h','0.079920000000000','0.079370000000000','0.711908500000000','0.707009229792292','8.907764014014013','8.907764014014013','test'),('2018-11-28 15:59:59','2018-11-28 23:59:59','VIABNB','4h','0.068390000000000','0.069720000000000','0.711908500000000','0.725753189355169','10.409540868548033','10.409540868548033','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','VIABNB','4h','0.067360000000000','0.065950000000000','0.711908500000000','0.697006614830760','10.568712885985748','10.568712885985748','test'),('2018-12-01 07:59:59','2018-12-02 11:59:59','VIABNB','4h','0.067080000000000','0.066140000000000','0.711908500000000','0.701932441711389','10.612827966607037','10.612827966607037','test'),('2018-12-03 19:59:59','2018-12-04 03:59:59','VIABNB','4h','0.067880000000000','0.064920000000000','0.711908500000000','0.680864758691809','10.487750441956395','10.487750441956395','test'),('2018-12-20 15:59:59','2018-12-21 19:59:59','VIABNB','4h','0.058730000000000','0.057120000000000','0.711908500000000','0.692392533969011','12.121718031670357','12.121718031670357','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','VIABNB','4h','0.057800000000000','0.057790000000000','0.711908500000000','0.711785332439446','12.316756055363323','12.316756055363323','test'),('2018-12-24 15:59:59','2018-12-25 03:59:59','VIABNB','4h','0.059200000000000','0.058220000000000','0.711908500000000','0.700123528209459','12.02548141891892','12.025481418918920','test'),('2018-12-27 15:59:59','2018-12-27 19:59:59','VIABNB','4h','0.058810000000000','0.058050000000000','0.711908500000000','0.702708526186023','12.105228702601599','12.105228702601599','test'),('2019-01-05 23:59:59','2019-01-06 03:59:59','VIABNB','4h','0.059370000000000','0.054310000000000','0.711908500000000','0.651233798804110','11.991047667171973','11.991047667171973','test'),('2019-01-07 07:59:59','2019-01-07 11:59:59','VIABNB','4h','0.053630000000000','0.051970000000000','0.711908500000000','0.689872920846541','13.274445273168006','13.274445273168006','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','VIABNB','4h','0.050480000000000','0.050180000000000','0.711908500000000','0.707677665015848','14.102783280507133','14.102783280507133','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','VIABNB','4h','0.050810000000000','0.050570000000000','0.711908500000000','0.708545814701830','14.01118874237355','14.011188742373550','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','VIABNB','4h','0.051760000000000','0.048750000000000','0.711908500000000','0.670508875096600','13.754028207109739','13.754028207109739','test'),('2019-01-19 23:59:59','2019-01-20 03:59:59','VIABNB','4h','0.050490000000000','0.048780000000000','0.711908500000000','0.687797516934046','14.099990097048922','14.099990097048922','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','VIABNB','4h','0.050920000000000','0.048790000000000','0.711908500000000','0.682129138157895','13.98092105263158','13.980921052631579','test'),('2019-01-25 15:59:59','2019-01-25 23:59:59','VIABNB','4h','0.049710000000000','0.048200000000000','0.711908500000000','0.690283437940052','14.321233152283245','14.321233152283245','test'),('2019-01-30 11:59:59','2019-01-31 11:59:59','VIABNB','4h','0.047080000000000','0.047200000000000','0.711908500000000','0.713723050127443','15.121251062022091','15.121251062022091','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','VIABNB','4h','0.035870000000000','0.035200000000000','0.711908500000000','0.698611073320323','19.846905492054645','19.846905492054645','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','VIABNB','4h','0.035990000000000','0.035570000000000','0.711908500000000','0.703600593081411','19.780730758544042','19.780730758544042','test'),('2019-02-25 19:59:59','2019-02-26 03:59:59','VIABNB','4h','0.033930000000000','0.034560000000000','0.711908500000000','0.725126960212202','20.98168287651046','20.981682876510462','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','VIABNB','4h','0.053330000000000','0.034760000000000','0.711908500000000','0.464015365835365','13.349118694918433','13.349118694918433','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','VIABNB','4h','0.030970000000000','0.030410000000000','0.711908500000000','0.699035759928963','22.987035841136585','22.987035841136585','test'),('2019-03-20 15:59:59','2019-03-20 19:59:59','VIABNB','4h','0.033760000000000','0.033050000000000','0.711908500000000','0.696936490669431','21.08733708530806','21.087337085308061','test'),('2019-03-25 03:59:59','2019-03-25 07:59:59','VIABNB','4h','0.033390000000000','0.031680000000000','0.711908500000000','0.675449574123989','21.32100928421683','21.321009284216832','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIABNB','4h','0.033200000000000','0.031000000000000','0.711908500000000','0.664733840361446','21.443027108433736','21.443027108433736','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','VIABNB','4h','0.032490000000000','0.032350000000000','0.474605666666667','0.472560582230430','14.607745973119936','14.607745973119936','test'),('2019-04-02 03:59:59','2019-04-02 07:59:59','VIABNB','4h','0.032630000000000','0.032740000000000','0.531178161112612','0.532968832204319','16.278828106423894','16.278828106423894','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','VIABNB','4h','0.032910000000000','0.032340000000000','0.531625828885538','0.522418088913956','16.153929774704906','16.153929774704906','test'),('2019-04-05 11:59:59','2019-04-05 15:59:59','VIABNB','4h','0.033080000000000','0.031570000000000','0.531625828885538','0.507358749030122','16.0709138115338','16.070913811533799','test'),('2019-04-07 11:59:59','2019-04-07 15:59:59','VIABNB','4h','0.032440000000000','0.032290000000000','0.531625828885538','0.529167633005981','16.387972530380335','16.387972530380335','test'),('2019-04-17 19:59:59','2019-04-17 23:59:59','VIABNB','4h','0.031740000000000','0.029600000000000','0.531625828885538','0.495782121455952','16.749395995133522','16.749395995133522','test'),('2019-04-30 23:59:59','2019-05-01 03:59:59','VIABNB','4h','0.022620000000000','0.022820000000000','0.531625828885538','0.536326322509636','23.502468120492395','23.502468120492395','test'),('2019-05-02 19:59:59','2019-05-10 03:59:59','VIABNB','4h','0.023520000000000','0.033910000000000','0.531625828885538','0.766472442921284','22.603138983228657','22.603138983228657','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','VIABNB','4h','0.029400000000000','0.028980000000000','0.573568425016464','0.565374590373372','19.509130102600825','19.509130102600825','test'),('2019-06-10 15:59:59','2019-06-10 19:59:59','VIABNB','4h','0.018820000000000','0.018560000000000','0.573568425016464','0.565644525414749','30.476536929673962','30.476536929673962','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','VIABNB','4h','0.018490000000000','0.017490000000000','0.573568425016464','0.542547958547212','31.020466469251705','31.020466469251705','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','VIABNB','4h','0.018030000000000','0.016880000000000','0.573568425016464','0.536984748434715','31.811892679781696','31.811892679781696','test'),('2019-06-16 19:59:59','2019-06-16 23:59:59','VIABNB','4h','0.017630000000000','0.017010000000000','0.573568425016464','0.553397555844019','32.533659955556665','32.533659955556665','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','VIABNB','4h','0.016020000000000','0.014920000000000','0.573568425016464','0.534184825296232','35.80327247293783','35.803272472937827','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','VIABNB','4h','0.014670000000000','0.013740000000000','0.573568425016464','0.537207236518488','39.09805214836155','39.098052148361553','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','VIABNB','4h','0.014000000000000','0.014040000000000','0.573568425016464','0.575207191945083','40.969173215461716','40.969173215461716','test'),('2019-07-04 19:59:59','2019-07-04 23:59:59','VIABNB','4h','0.014790000000000','0.014110000000000','0.573568425016464','0.547197462946741','38.7808265731213','38.780826573121303','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','VIABNB','4h','0.013930000000000','0.014150000000000','0.573568425016464','0.582626935677169','41.175048457750464','41.175048457750464','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','VIABNB','4h','0.014290000000000','0.013570000000000','0.573568425016464','0.544669246149294','40.13774842662449','40.137748426624491','test'),('2019-07-08 19:59:59','2019-07-09 07:59:59','VIABNB','4h','0.014230000000000','0.013770000000000','0.573568425016464','0.555027210996255','40.30698700045425','40.306987000454249','test'),('2019-07-09 15:59:59','2019-07-10 19:59:59','VIABNB','4h','0.014360000000000','0.014540000000000','0.573568425016464','0.580758001374609','39.94209087858385','39.942090878583848','test'),('2019-07-20 15:59:59','2019-07-20 23:59:59','VIABNB','4h','0.012220000000000','0.011210000000000','0.573568425016464','0.526162196762239','46.93685965764845','46.936859657648448','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:36:41
