-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-18 15:59:59','2018-07-18 19:59:59','PIVXBTC','4h','0.000292600000000','0.000289300000000','0.001467500000000','0.001450949248120','5.015379357484621','5.015379357484621','test'),('2018-07-19 15:59:59','2018-07-19 19:59:59','PIVXBTC','4h','0.000298500000000','0.000274200000000','0.001467500000000','0.001348035175879','4.916247906197655','4.916247906197655','test'),('2018-07-27 03:59:59','2018-07-27 07:59:59','PIVXBTC','4h','0.000269000000000','0.000248000000000','0.001467500000000','0.001352936802974','5.455390334572491','5.455390334572491','test'),('2018-07-27 15:59:59','2018-07-29 11:59:59','PIVXBTC','4h','0.000261800000000','0.000259000000000','0.001467500000000','0.001451804812834','5.605423987776929','5.605423987776929','test'),('2018-07-29 19:59:59','2018-07-29 23:59:59','PIVXBTC','4h','0.000262100000000','0.000264900000000','0.001467500000000','0.001483177222434','5.599008012209081','5.599008012209081','test'),('2018-08-18 03:59:59','2018-08-18 07:59:59','PIVXBTC','4h','0.000185200000000','0.000182300000000','0.001467500000000','0.001444520788337','7.923866090712743','7.923866090712743','test'),('2018-08-27 03:59:59','2018-08-27 07:59:59','PIVXBTC','4h','0.000181300000000','0.000179200000000','0.001467500000000','0.001450501930502','8.094318808604523','8.094318808604523','test'),('2018-09-01 19:59:59','2018-09-01 23:59:59','PIVXBTC','4h','0.000170400000000','0.000173000000000','0.001467500000000','0.001489891431925','8.612089201877934','8.612089201877934','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','PIVXBTC','4h','0.000170100000000','0.000167900000000','0.001467500000000','0.001448519988242','8.627278071722516','8.627278071722516','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','PIVXBTC','4h','0.000170600000000','0.000172800000000','0.001467500000000','0.001486424384525','8.601992966002346','8.601992966002346','test'),('2018-09-19 15:59:59','2018-09-19 19:59:59','PIVXBTC','4h','0.000146800000000','0.000141400000000','0.001467500000000','0.001413518392371','9.996594005449593','9.996594005449593','test'),('2018-09-20 15:59:59','2018-09-20 19:59:59','PIVXBTC','4h','0.000144600000000','0.000144000000000','0.001467500000000','0.001461410788382','10.14868603042877','10.148686030428770','test'),('2018-09-21 11:59:59','2018-09-21 15:59:59','PIVXBTC','4h','0.000145000000000','0.000145600000000','0.001467500000000','0.001473572413793','10.120689655172415','10.120689655172415','test'),('2018-09-27 07:59:59','2018-09-27 11:59:59','PIVXBTC','4h','0.000152500000000','0.000148300000000','0.001467500000000','0.001427083606557','9.622950819672132','9.622950819672132','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','PIVXBTC','4h','0.000171200000000','0.000174700000000','0.001467500000000','0.001497501460280','8.571845794392525','8.571845794392525','test'),('2018-10-30 03:59:59','2018-11-04 07:59:59','PIVXBTC','4h','0.000208100000000','0.000214200000000','0.001467500000000','0.001510516578568','7.05189812590101','7.051898125901010','test'),('2018-11-11 19:59:59','2018-11-13 15:59:59','PIVXBTC','4h','0.000209600000000','0.000207200000000','0.001467500000000','0.001450696564885','7.001431297709924','7.001431297709924','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','PIVXBTC','4h','0.000181800000000','0.000180500000000','0.001467500000000','0.001457006325633','8.072057205720572','8.072057205720572','test'),('2018-12-01 03:59:59','2018-12-01 19:59:59','PIVXBTC','4h','0.000184400000000','0.000182100000000','0.001467500000000','0.001449196041215','7.95824295010846','7.958242950108460','test'),('2018-12-03 11:59:59','2018-12-03 15:59:59','PIVXBTC','4h','0.000182200000000','0.000180100000000','0.001467500000000','0.001450585894621','8.054335894621294','8.054335894621294','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','PIVXBTC','4h','0.000182500000000','0.000183900000000','0.001467500000000','0.001478757534247','8.04109589041096','8.041095890410960','test'),('2018-12-20 11:59:59','2018-12-21 07:59:59','PIVXBTC','4h','0.000160400000000','0.000164300000000','0.001467500000000','0.001503181109726','9.149002493765586','9.149002493765586','test'),('2018-12-22 07:59:59','2018-12-22 15:59:59','PIVXBTC','4h','0.000162200000000','0.000159100000000','0.001467500000000','0.001439452836005','9.047472256473489','9.047472256473489','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','PIVXBTC','4h','0.000162200000000','0.000158500000000','0.001467500000000','0.001434024352651','9.047472256473489','9.047472256473489','test'),('2019-01-09 03:59:59','2019-01-09 07:59:59','PIVXBTC','4h','0.000230200000000','0.000223900000000','0.001467500000000','0.001427338184188','6.374891398783666','6.374891398783666','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','PIVXBTC','4h','0.000215700000000','0.000207200000000','0.001467500000000','0.001409670839128','6.803430690774223','6.803430690774223','test'),('2019-01-17 03:59:59','2019-01-17 15:59:59','PIVXBTC','4h','0.000214500000000','0.000211200000000','0.001467500000000','0.001444923076923','6.841491841491841','6.841491841491841','test'),('2019-01-17 19:59:59','2019-01-17 23:59:59','PIVXBTC','4h','0.000215300000000','0.000214300000000','0.001467500000000','0.001460683929401','6.816070599163957','6.816070599163957','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','PIVXBTC','4h','0.000213000000000','0.000212200000000','0.001467500000000','0.001461988262911','6.889671361502348','6.889671361502348','test'),('2019-01-19 19:59:59','2019-01-20 03:59:59','PIVXBTC','4h','0.000214600000000','0.000211200000000','0.001467500000000','0.001444249767008','6.838303821062442','6.838303821062442','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','PIVXBTC','4h','0.000210400000000','0.000209700000000','0.001467500000000','0.001462617633080','6.97480988593156','6.974809885931560','test'),('2019-01-26 11:59:59','2019-01-27 07:59:59','PIVXBTC','4h','0.000213700000000','0.000207700000000','0.001467500000000','0.001426297379504','6.8671034160037445','6.867103416003745','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','PIVXBTC','4h','0.000194400000000','0.000192900000000','0.001467500000000','0.001456176697531','7.548868312757201','7.548868312757201','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','PIVXBTC','4h','0.000194500000000','0.000193800000000','0.001467500000000','0.001462218508997','7.544987146529563','7.544987146529563','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','PIVXBTC','4h','0.000194700000000','0.000193000000000','0.001467500000000','0.001454686697483','7.537236774524911','7.537236774524911','test'),('2019-02-15 03:59:59','2019-02-15 11:59:59','PIVXBTC','4h','0.000199900000000','0.000197000000000','0.001467500000000','0.001446210605303','7.341170585292646','7.341170585292646','test'),('2019-02-16 15:59:59','2019-02-16 19:59:59','PIVXBTC','4h','0.000198400000000','0.000195300000000','0.001467500000000','0.001444570312500','7.396673387096775','7.396673387096775','test'),('2019-02-16 23:59:59','2019-02-17 03:59:59','PIVXBTC','4h','0.000196900000000','0.000202800000000','0.001467500000000','0.001511472828847','7.453021838496699','7.453021838496699','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','PIVXBTC','4h','0.000201300000000','0.000196600000000','0.001467500000000','0.001433236462991','7.290114257327373','7.290114257327373','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','PIVXBTC','4h','0.000196700000000','0.000194000000000','0.001467500000000','0.001447356380275','7.460599898322318','7.460599898322318','test'),('2019-03-03 07:59:59','2019-03-06 07:59:59','PIVXBTC','4h','0.000197100000000','0.000200000000000','0.001467500000000','0.001489091831558','7.445459157787925','7.445459157787925','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','PIVXBTC','4h','0.000200800000000','0.000198800000000','0.001467500000000','0.001452883466135','7.308266932270916','7.308266932270916','test'),('2019-03-09 07:59:59','2019-03-09 11:59:59','PIVXBTC','4h','0.000199700000000','0.000199000000000','0.001467500000000','0.001462356034051','7.348522784176264','7.348522784176264','test'),('2019-03-10 15:59:59','2019-03-11 07:59:59','PIVXBTC','4h','0.000200200000000','0.000200300000000','0.001467500000000','0.001468233016983','7.330169830169831','7.330169830169831','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','PIVXBTC','4h','0.000209400000000','0.000209200000000','0.001467500000000','0.001466098376313','7.008118433619867','7.008118433619867','test'),('2019-03-21 03:59:59','2019-03-21 11:59:59','PIVXBTC','4h','0.000209500000000','0.000207800000000','0.001467500000000','0.001455591885442','7.004773269689738','7.004773269689738','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','PIVXBTC','4h','0.000207900000000','0.000205900000000','0.001467500000000','0.001453382635883','7.0586820586820584','7.058682058682058','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','PIVXBTC','4h','0.000208100000000','0.000207200000000','0.001467500000000','0.001461153291687','7.05189812590101','7.051898125901010','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','PIVXBTC','4h','0.000209700000000','0.000211100000000','0.001467500000000','0.001477297329518','6.998092513113972','6.998092513113972','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','PIVXBTC','4h','0.000235100000000','0.000213000000000','0.001467500000000','0.001329551254785','6.242024670353041','6.242024670353041','test'),('2019-05-22 15:59:59','2019-05-22 19:59:59','PIVXBTC','4h','0.000089800000000','0.000087800000000','0.001467500000000','0.001434816258352','16.34187082405345','16.341870824053451','test'),('2019-05-23 03:59:59','2019-05-23 07:59:59','PIVXBTC','4h','0.000087100000000','0.000083800000000','0.001467500000000','0.001411900114811','16.84845005740528','16.848450057405280','test'),('2019-05-24 03:59:59','2019-05-24 11:59:59','PIVXBTC','4h','0.000088800000000','0.000087300000000','0.001467500000000','0.001442711148649','16.5259009009009','16.525900900900901','test'),('2019-05-30 07:59:59','2019-05-30 15:59:59','PIVXBTC','4h','0.000087100000000','0.000085400000000','0.001467500000000','0.001438857634902','16.84845005740528','16.848450057405280','test'),('2019-06-02 15:59:59','2019-06-02 19:59:59','PIVXBTC','4h','0.000085800000000','0.000084700000000','0.001467500000000','0.001448685897436','17.103729603729604','17.103729603729604','test'),('2019-06-04 23:59:59','2019-06-05 03:59:59','PIVXBTC','4h','0.000085200000000','0.000084900000000','0.001467500000000','0.001462332746479','17.224178403755868','17.224178403755868','test'),('2019-06-05 15:59:59','2019-06-05 19:59:59','PIVXBTC','4h','0.000085500000000','0.000084200000000','0.001467500000000','0.001445187134503','17.16374269005848','17.163742690058481','test'),('2019-06-06 07:59:59','2019-06-06 11:59:59','PIVXBTC','4h','0.000084600000000','0.000084900000000','0.001467500000000','0.001472703900709','17.346335697399528','17.346335697399528','test'),('2019-06-08 03:59:59','2019-06-10 11:59:59','PIVXBTC','4h','0.000084500000000','0.000086500000000','0.001467500000000','0.001502233727811','17.366863905325445','17.366863905325445','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','PIVXBTC','4h','0.000063300000000','0.000056700000000','0.001467500000000','0.001314490521327','23.183254344391788','23.183254344391788','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','PIVXBTC','4h','0.000060000000000','0.000057700000000','0.001467500000000','0.001411245833333','24.458333333333332','24.458333333333332','test'),('2019-07-07 03:59:59','2019-07-07 15:59:59','PIVXBTC','4h','0.000059300000000','0.000059900000000','0.001467500000000','0.001482348229342','24.747048903878586','24.747048903878586','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:22:56
