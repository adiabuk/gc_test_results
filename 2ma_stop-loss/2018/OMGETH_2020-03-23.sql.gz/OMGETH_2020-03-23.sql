-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-04 19:59:59','2018-03-04 23:59:59','OMGETH','4h','0.020884000000000','0.020660000000000','0.072144500000000','0.071370684255890','3.454534571921088','3.454534571921088','test'),('2018-03-09 23:59:59','2018-03-10 03:59:59','OMGETH','4h','0.020501000000000','0.020000000000000','0.072144500000000','0.070381444807570','3.5190722403785184','3.519072240378518','test'),('2018-03-11 19:59:59','2018-03-12 03:59:59','OMGETH','4h','0.020294000000000','0.019904000000000','0.072144500000000','0.070758062875727','3.554966985315857','3.554966985315857','test'),('2018-03-18 23:59:59','2018-03-19 03:59:59','OMGETH','4h','0.019404000000000','0.019137000000000','0.072144500000000','0.071151788110699','3.7180220573077714','3.718022057307771','test'),('2018-03-26 23:59:59','2018-03-27 03:59:59','OMGETH','4h','0.021139000000000','0.020676000000000','0.072144500000000','0.070564344670987','3.412862481668953','3.412862481668953','test'),('2018-04-01 19:59:59','2018-04-09 11:59:59','OMGETH','4h','0.021572000000000','0.023037000000000','0.072144500000000','0.077043985096421','3.344358427591322','3.344358427591322','test'),('2018-04-12 03:59:59','2018-04-12 07:59:59','OMGETH','4h','0.023100000000000','0.022622000000000','0.072144500000000','0.070651639783550','3.1231385281385284','3.123138528138528','test'),('2018-04-12 11:59:59','2018-04-17 11:59:59','OMGETH','4h','0.023264000000000','0.028755000000000','0.072144500000000','0.089172760380846','3.1011219050894083','3.101121905089408','test'),('2018-04-26 03:59:59','2018-04-26 07:59:59','OMGETH','4h','0.026017000000000','0.031600000000000','0.075629177495423','0.091858477489925','2.906913844617846','2.906913844617846','test'),('2018-04-29 19:59:59','2018-04-29 23:59:59','OMGETH','4h','0.026505000000000','0.026355000000000','0.079686502494048','0.079235531908343','3.0064705713657047','3.006470571365705','test'),('2018-05-25 03:59:59','2018-05-25 07:59:59','OMGETH','4h','0.018881000000000','0.018297000000000','0.079686502494048','0.077221753939600','4.220459853506065','4.220459853506065','test'),('2018-05-28 07:59:59','2018-05-28 11:59:59','OMGETH','4h','0.018771000000000','0.018680000000000','0.079686502494048','0.079300190005264','4.245192184435992','4.245192184435992','test'),('2018-05-31 15:59:59','2018-05-31 19:59:59','OMGETH','4h','0.018698000000000','0.018633000000000','0.079686502494048','0.079409487697700','4.261766097660071','4.261766097660071','test'),('2018-06-02 03:59:59','2018-06-04 03:59:59','OMGETH','4h','0.019059000000000','0.018887000000000','0.079686502494048','0.078967363062337','4.1810432076209665','4.181043207620966','test'),('2018-06-04 15:59:59','2018-06-04 19:59:59','OMGETH','4h','0.018932000000000','0.018717000000000','0.079686502494048','0.078781548023510','4.209090560640608','4.209090560640608','test'),('2018-06-07 03:59:59','2018-06-07 11:59:59','OMGETH','4h','0.019171000000000','0.018972000000000','0.079686502494048','0.078859335731943','4.156616895000156','4.156616895000156','test'),('2018-06-11 23:59:59','2018-06-12 03:59:59','OMGETH','4h','0.018716000000000','0.018344000000000','0.079686502494048','0.078102650232465','4.257667369846549','4.257667369846549','test'),('2018-06-13 11:59:59','2018-06-13 19:59:59','OMGETH','4h','0.019227000000000','0.018643000000000','0.079686502494048','0.077266108389064','4.144510453739429','4.144510453739429','test'),('2018-06-15 11:59:59','2018-06-15 15:59:59','OMGETH','4h','0.018592000000000','0.018356000000000','0.079686502494048','0.078674991382355','4.286064032597246','4.286064032597246','test'),('2018-06-16 11:59:59','2018-06-16 15:59:59','OMGETH','4h','0.018812000000000','0.018414000000000','0.079686502494048','0.078000598390676','4.235939958220711','4.235939958220711','test'),('2018-07-01 03:59:59','2018-07-01 15:59:59','OMGETH','4h','0.017275000000000','0.017708000000000','0.079686502494048','0.081683854481308','4.612822141478901','4.612822141478901','test'),('2018-07-04 11:59:59','2018-07-04 15:59:59','OMGETH','4h','0.017356000000000','0.017660000000000','0.079686502494048','0.081082255937133','4.591294220675732','4.591294220675732','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','OMGETH','4h','0.015900000000000','0.016074000000000','0.079686502494048','0.080558543464738','5.0117297166067925','5.011729716606792','test'),('2018-08-11 11:59:59','2018-08-11 15:59:59','OMGETH','4h','0.013635000000000','0.013330000000000','0.079686502494048','0.077904002804962','5.84426127569109','5.844261275691090','test'),('2018-08-17 03:59:59','2018-08-17 07:59:59','OMGETH','4h','0.013235000000000','0.013046000000000','0.079686502494048','0.078548553950688','6.020891763811711','6.020891763811711','test'),('2018-08-24 15:59:59','2018-08-25 07:59:59','OMGETH','4h','0.013400000000000','0.013271000000000','0.079686502494048','0.078919371238695','5.9467539174662685','5.946753917466268','test'),('2018-08-25 11:59:59','2018-08-25 15:59:59','OMGETH','4h','0.013494000000000','0.013455000000000','0.079686502494048','0.079456194683372','5.905328478883059','5.905328478883059','test'),('2018-09-25 11:59:59','2018-09-25 19:59:59','OMGETH','4h','0.015650000000000','0.015650000000000','0.079686502494048','0.079686502494048','5.091789296744281','5.091789296744281','test'),('2018-10-02 07:59:59','2018-10-02 11:59:59','OMGETH','4h','0.015732000000000','0.015742000000000','0.079686502494048','0.079737154987370','5.06524933219222','5.065249332192220','test'),('2018-10-05 03:59:59','2018-10-05 07:59:59','OMGETH','4h','0.015696000000000','0.015639000000000','0.079686502494048','0.079397121082086','5.07686687653211','5.076866876532110','test'),('2018-10-10 03:59:59','2018-10-10 07:59:59','OMGETH','4h','0.015578000000000','0.015387000000000','0.079686502494048','0.078709475791239','5.115323051357556','5.115323051357556','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','OMGETH','4h','0.015558000000000','0.015459000000000','0.079686502494048','0.079179434506716','5.121898861939067','5.121898861939067','test'),('2018-10-11 11:59:59','2018-10-11 15:59:59','OMGETH','4h','0.015548000000000','0.015419000000000','0.079686502494048','0.079025352582694','5.125193111271418','5.125193111271418','test'),('2018-10-11 23:59:59','2018-10-12 03:59:59','OMGETH','4h','0.015705000000000','0.015433000000000','0.079686502494048','0.078306386054801','5.073957497233238','5.073957497233238','test'),('2018-10-12 07:59:59','2018-10-12 11:59:59','OMGETH','4h','0.015586000000000','0.015494000000000','0.079686502494048','0.079216134328422','5.112697452460414','5.112697452460414','test'),('2018-10-15 19:59:59','2018-10-15 23:59:59','OMGETH','4h','0.015500000000000','0.015172000000000','0.079686502494048','0.078000233279980','5.141064677035355','5.141064677035355','test'),('2018-10-17 15:59:59','2018-10-26 11:59:59','OMGETH','4h','0.015442000000000','0.016209000000000','0.079686502494048','0.083644509708977','5.160374465357337','5.160374465357337','test'),('2018-10-30 23:59:59','2018-10-31 07:59:59','OMGETH','4h','0.016214000000000','0.016194000000000','0.079686502494048','0.079588209040867','4.914672659063032','4.914672659063032','test'),('2018-11-02 23:59:59','2018-11-03 03:59:59','OMGETH','4h','0.016178000000000','0.016141000000000','0.079686502494048','0.079504254960837','4.925609005689702','4.925609005689702','test'),('2018-11-05 23:59:59','2018-11-06 03:59:59','OMGETH','4h','0.016142000000000','0.016335000000000','0.079686502494048','0.080639265161707','4.936594132948086','4.936594132948086','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','OMGETH','4h','0.016500000000000','0.015876000000000','0.079686502494048','0.076672903854273','4.829484999639273','4.829484999639273','test'),('2018-11-16 03:59:59','2018-11-16 07:59:59','OMGETH','4h','0.015949000000000','0.015348000000000','0.079686502494048','0.076683706832946','4.996332214812715','4.996332214812715','test'),('2018-11-18 19:59:59','2018-11-18 23:59:59','OMGETH','4h','0.015900000000000','0.015640000000000','0.079686502494048','0.078383452767730','5.0117297166067925','5.011729716606792','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','OMGETH','4h','0.014113000000000','0.013787000000000','0.079686502494048','0.077845802443523','5.6463191733896405','5.646319173389641','test'),('2018-12-01 23:59:59','2018-12-02 03:59:59','OMGETH','4h','0.013790000000000','0.013819000000000','0.079686502494048','0.079854081070721','5.778571609430602','5.778571609430602','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','OMGETH','4h','0.013896000000000','0.013695000000000','0.079686502494048','0.078533869578007','5.734492119606218','5.734492119606218','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','OMGETH','4h','0.014019000000000','0.013588000000000','0.079686502494048','0.077236621434419','5.684178792641986','5.684178792641986','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','OMGETH','4h','0.013695000000000','0.013586000000000','0.079686502494048','0.079052268921806','5.818656626071413','5.818656626071413','test'),('2018-12-07 23:59:59','2018-12-08 03:59:59','OMGETH','4h','0.014066000000000','0.013858000000000','0.079686502494048','0.078508143861973','5.66518573112811','5.665185731128110','test'),('2018-12-20 03:59:59','2018-12-20 23:59:59','OMGETH','4h','0.013851000000000','0.014118000000000','0.079686502494048','0.081222586254492','5.7531226982923975','5.753122698292398','test'),('2019-01-11 15:59:59','2019-01-11 19:59:59','OMGETH','4h','0.010232000000000','0.010295000000000','0.079686502494048','0.080177144563744','7.787969360247068','7.787969360247068','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','OMGETH','4h','0.010215000000000','0.010256000000000','0.079686502494048','0.080006340634259','7.800930249050221','7.800930249050221','test'),('2019-01-16 03:59:59','2019-01-16 07:59:59','OMGETH','4h','0.010224000000000','0.010235000000000','0.079686502494048','0.079772237189611','7.794063232985915','7.794063232985915','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','OMGETH','4h','0.010628000000000','0.010578000000000','0.079686502494048','0.079311613039334','7.497789094283779','7.497789094283779','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','OMGETH','4h','0.010394000000000','0.010219000000000','0.079686502494048','0.078344849815920','7.666586732157783','7.666586732157783','test'),('2019-02-16 19:59:59','2019-02-16 23:59:59','OMGETH','4h','0.010050000000000','0.009896000000000','0.079686502494048','0.078465435689662','7.9290052232883586','7.929005223288359','test'),('2019-02-24 15:59:59','2019-02-24 19:59:59','OMGETH','4h','0.009217000000000','0.009268000000000','0.079686502494048','0.080127428134408','8.645600791368993','8.645600791368993','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:18:51
