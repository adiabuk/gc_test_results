-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-03-13 03:59:59','2019-03-13 07:59:59','POLYBNB','4h','0.007300000000000','0.006980000000000','0.711908500000000','0.680701552054795','97.52171232876714','97.521712328767137','test'),('2019-03-19 23:59:59','2019-03-20 03:59:59','POLYBNB','4h','0.006720000000000','0.006600000000000','0.711908500000000','0.699195848214286','105.93876488095239','105.938764880952391','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','POLYBNB','4h','0.006710000000000','0.006700000000000','0.711908500000000','0.710847533532042','106.09664679582714','106.096646795827141','test'),('2019-03-24 03:59:59','2019-03-26 03:59:59','POLYBNB','4h','0.006810000000000','0.007010000000000','0.711908500000000','0.732816238619677','104.53869309838474','104.538693098384741','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','POLYBNB','4h','0.007100000000000','0.007040000000000','0.711908500000000','0.705892371830986','100.26880281690141','100.268802816901413','test'),('2019-04-07 11:59:59','2019-04-09 15:59:59','POLYBNB','4h','0.006710000000000','0.006760000000000','0.711908500000000','0.717213332339792','106.09664679582714','106.096646795827141','test'),('2019-05-07 23:59:59','2019-05-08 03:59:59','POLYBNB','4h','0.003960000000000','0.003860000000000','0.711908500000000','0.693931012626263','179.77487373737375','179.774873737373753','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','POLYBNB','4h','0.003920000000000','0.003850000000000','0.711908500000000','0.699195848214286','181.60931122448983','181.609311224489829','test'),('2019-05-09 15:59:59','2019-05-09 19:59:59','POLYBNB','4h','0.003900000000000','0.003950000000000','0.711908500000000','0.721035532051282','182.54064102564104','182.540641025641037','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','POLYBNB','4h','0.004070000000000','0.003830000000000','0.711908500000000','0.669928637592138','174.91609336609338','174.916093366093378','test'),('2019-05-28 23:59:59','2019-05-29 07:59:59','POLYBNB','4h','0.003270000000000','0.003150000000000','0.711908500000000','0.685783417431193','217.70902140672786','217.709021406727857','test'),('2019-05-29 11:59:59','2019-05-29 15:59:59','POLYBNB','4h','0.003220000000000','0.003200000000000','0.711908500000000','0.707486708074534','221.08959627329193','221.089596273291932','test'),('2019-05-30 11:59:59','2019-05-30 23:59:59','POLYBNB','4h','0.003240000000000','0.003110000000000','0.711908500000000','0.683344270061728','219.72484567901236','219.724845679012361','test'),('2019-06-07 11:59:59','2019-06-07 15:59:59','POLYBNB','4h','0.003070000000000','0.003050000000000','0.711908500000000','0.707270659609121','231.892019543974','231.892019543973987','test'),('2019-06-08 23:59:59','2019-06-09 15:59:59','POLYBNB','4h','0.003090000000000','0.003010000000000','0.711908500000000','0.693477211974110','230.3911003236246','230.391100323624613','test'),('2019-06-10 03:59:59','2019-06-10 07:59:59','POLYBNB','4h','0.003100000000000','0.003040000000000','0.711908500000000','0.698129625806452','229.6479032258065','229.647903225806488','test'),('2019-06-10 19:59:59','2019-06-12 03:59:59','POLYBNB','4h','0.003130000000000','0.003070000000000','0.711908500000000','0.698261691693291','227.4468051118211','227.446805111821106','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','POLYBNB','4h','0.003090000000000','0.003040000000000','0.711908500000000','0.700388944983819','230.3911003236246','230.391100323624613','test'),('2019-06-16 15:59:59','2019-06-16 19:59:59','POLYBNB','4h','0.003050000000000','0.003030000000000','0.711908500000000','0.707240247540984','233.41262295081967','233.412622950819667','test'),('2019-06-30 19:59:59','2019-06-30 23:59:59','POLYBNB','4h','0.002550000000000','0.002590000000000','0.711908500000000','0.723075692156863','279.17980392156863','279.179803921568634','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','POLYBNB','4h','0.002570000000000','0.002560000000000','0.711908500000000','0.709138428015564','277.0071984435798','277.007198443579796','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','POLYBNB','4h','0.002560000000000','0.002550000000000','0.711908500000000','0.709127607421875','278.0892578125','278.089257812500023','test'),('2019-07-07 19:59:59','2019-07-08 03:59:59','POLYBNB','4h','0.002520000000000','0.002490000000000','0.711908500000000','0.703433398809524','282.503373015873','282.503373015873024','test'),('2019-07-10 03:59:59','2019-07-10 07:59:59','POLYBNB','4h','0.002510000000000','0.002450000000000','0.711908500000000','0.694890766932271','283.6288844621514','283.628884462151404','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','POLYBNB','4h','0.002000000000000','0.001950000000000','0.711908500000000','0.694110787500000','355.95425','355.954250000000002','test'),('2019-07-28 07:59:59','2019-07-28 11:59:59','POLYBNB','4h','0.001982000000000','0.001962000000000','0.711908500000000','0.704724761352170','359.1869323915238','359.186932391523783','test'),('2019-07-29 23:59:59','2019-07-31 11:59:59','POLYBNB','4h','0.001975000000000','0.001966000000000','0.711908500000000','0.708664360000000','360.46','360.459999999999980','test'),('2019-08-22 03:59:59','2019-08-22 07:59:59','POLYBNB','4h','0.001439000000000','0.001441000000000','0.711908500000000','0.712897948922863','494.72446143154974','494.724461431549742','test'),('2019-08-22 19:59:59','2019-08-26 07:59:59','POLYBNB','4h','0.001441000000000','0.001492000000000','0.711908500000000','0.737104428868841','494.0378209576683','494.037820957668316','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','POLYBNB','4h','0.001603000000000','0.001589000000000','0.711908500000000','0.705690958515284','444.1101060511541','444.110106051154105','test'),('2019-09-03 23:59:59','2019-09-05 07:59:59','POLYBNB','4h','0.001607000000000','0.001588000000000','0.711908500000000','0.703491411325451','443.0046670815184','443.004667081518392','test'),('2019-09-09 03:59:59','2019-09-09 07:59:59','POLYBNB','4h','0.001585000000000','0.001550000000000','0.711908500000000','0.696188123028391','449.1536277602524','449.153627760252391','test'),('2019-09-09 19:59:59','2019-09-10 15:59:59','POLYBNB','4h','0.001571000000000','0.001554000000000','0.711908500000000','0.704204843411840','453.1562698917887','453.156269891788725','test'),('2019-09-10 19:59:59','2019-09-10 23:59:59','POLYBNB','4h','0.001575000000000','0.001571000000000','0.711908500000000','0.710100478412698','452.0053968253969','452.005396825396872','test'),('2019-09-13 19:59:59','2019-09-13 23:59:59','POLYBNB','4h','0.001583000000000','0.001571000000000','0.711908500000000','0.706511846809855','449.7210991787745','449.721099178774523','test'),('2019-09-15 11:59:59','2019-09-17 07:59:59','POLYBNB','4h','0.001587000000000','0.001557000000000','0.711908500000000','0.698450872400756','448.5875866414619','448.587586641461883','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','POLYBNB','4h','0.001571000000000','0.001582000000000','0.711908500000000','0.716893218968810','453.1562698917887','453.156269891788725','test'),('2019-09-19 23:59:59','2019-09-24 19:59:59','POLYBNB','4h','0.001587000000000','0.001584000000000','0.711908500000000','0.710562737240076','448.5875866414619','448.587586641461883','test'),('2019-09-27 15:59:59','2019-09-27 23:59:59','POLYBNB','4h','0.001649000000000','0.001613000000000','0.711908500000000','0.696366531534263','431.72134627046694','431.721346270466938','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','POLYBNB','4h','0.001635000000000','0.001636000000000','0.711908500000000','0.712343918042813','435.4180428134557','435.418042813455713','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','POLYBNB','4h','0.001632000000000','0.001615000000000','0.711908500000000','0.704492786458333','436.218443627451','436.218443627450995','test'),('2019-10-01 19:59:59','2019-10-02 03:59:59','POLYBNB','4h','0.001652000000000','0.001630000000000','0.711908500000000','0.702427878329298','430.9373486682809','430.937348668280890','test'),('2019-11-01 23:59:59','2019-11-02 03:59:59','POLYBNB','4h','0.001389000000000','0.001387000000000','0.711908500000000','0.710883433765299','512.533117350612','512.533117350611974','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','POLYBNB','4h','0.001341000000000','0.001343000000000','0.711908500000000','0.712970257643550','530.878821774795','530.878821774795028','test'),('2019-11-05 23:59:59','2019-11-06 03:59:59','POLYBNB','4h','0.001364000000000','0.001350000000000','0.711908500000000','0.704601521260997','521.9270527859238','521.927052785923820','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','POLYBNB','4h','0.001354000000000','0.001332000000000','0.711908500000000','0.700341301329395','525.7817577548007','525.781757754800651','test'),('2019-11-07 03:59:59','2019-11-07 07:59:59','POLYBNB','4h','0.001343000000000','0.001353000000000','0.711908500000000','0.717209382352941','530.0882352941177','530.088235294117680','test'),('2019-11-11 23:59:59','2019-11-12 03:59:59','POLYBNB','4h','0.001343000000000','0.001291000000000','0.711908500000000','0.684343911764706','530.0882352941177','530.088235294117680','test'),('2019-11-14 19:59:59','2019-11-16 03:59:59','POLYBNB','4h','0.001317000000000','0.001307000000000','0.711908500000000','0.706502968488990','540.5531511009871','540.553151100987066','test'),('2019-11-23 03:59:59','2019-11-23 07:59:59','POLYBNB','4h','0.001349000000000','0.001340000000000','0.711908500000000','0.707158925129726','527.7305411415864','527.730541141586400','test'),('2019-11-26 23:59:59','2019-11-29 15:59:59','POLYBNB','4h','0.001381000000000','0.001372000000000','0.711908500000000','0.707268980448950','515.5021723388849','515.502172338884861','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','POLYBNB','4h','0.001378000000000','0.001350000000000','0.711908500000000','0.697443015239477','516.6244557329463','516.624455732946330','test'),('2019-11-30 15:59:59','2019-11-30 19:59:59','POLYBNB','4h','0.001378000000000','0.001355000000000','0.711908500000000','0.700026137518142','516.6244557329463','516.624455732946330','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','POLYBNB','4h','0.001363000000000','0.001348000000000','0.711908500000000','0.704073850330154','522.3099779897285','522.309977989728509','test'),('2019-12-01 11:59:59','2019-12-02 15:59:59','POLYBNB','4h','0.001399000000000','0.001385000000000','0.711908500000000','0.704784326304503','508.8695496783417','508.869549678341684','test'),('2019-12-05 07:59:59','2019-12-05 11:59:59','POLYBNB','4h','0.001392000000000','0.001354000000000','0.711908500000000','0.692474216235632','511.42852011494256','511.428520114942557','test'),('2019-12-05 23:59:59','2019-12-06 03:59:59','POLYBNB','4h','0.001386000000000','0.001368000000000','0.711908500000000','0.702662935064935','513.6424963924964','513.642496392496355','test'),('2019-12-06 07:59:59','2019-12-06 11:59:59','POLYBNB','4h','0.001380000000000','0.001386000000000','0.711908500000000','0.715003754347826','515.8757246376812','515.875724637681174','test'),('2019-12-14 07:59:59','2019-12-14 11:59:59','POLYBNB','4h','0.001598000000000','0.001548000000000','0.711908500000000','0.689633515644556','445.4996871088861','445.499687108886121','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','POLYBNB','4h','0.001613000000000','0.001581000000000','0.711908500000000','0.697785082765034','441.35678859268444','441.356788592684438','test'),('2020-01-02 07:59:59','2020-01-02 11:59:59','POLYBNB','4h','0.001363000000000','0.001331000000000','0.711908500000000','0.695194580704329','522.3099779897285','522.309977989728509','test'),('2020-01-04 15:59:59','2020-01-04 23:59:59','POLYBNB','4h','0.001291000000000','0.001260000000000','0.711908500000000','0.694813872966693','551.4395817195972','551.439581719597186','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:13:30
