-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-17 11:59:59','2018-08-17 15:59:59','POABNB','4h','0.007430000000000','0.007460000000000','0.711908500000000','0.714782962314939','95.81541049798116','95.815410497981162','test'),('2018-08-19 15:59:59','2018-08-19 19:59:59','POABNB','4h','0.007470000000000','0.007380000000000','0.712627115578735','0.704041246716341','95.39854291549328','95.398542915493280','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','POABNB','4h','0.007420000000000','0.007210000000000','0.712627115578735','0.692458423628393','96.0413902397217','96.041390239721693','test'),('2018-08-23 23:59:59','2018-08-24 03:59:59','POABNB','4h','0.007560000000000','0.007280000000000','0.712627115578735','0.686233518705449','94.26284597602316','94.262845976023158','test'),('2018-09-01 11:59:59','2018-09-01 15:59:59','POABNB','4h','0.008580000000000','0.009020000000000','0.712627115578735','0.749172095864824','83.05677337747494','83.056773377474940','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','POABNB','4h','0.007710000000000','0.007250000000000','0.712627115578735','0.670109803884025','92.428938466762','92.428938466762006','test'),('2018-09-25 15:59:59','2018-10-02 23:59:59','POABNB','4h','0.007320000000000','0.007680000000000','0.712627115578735','0.747674350771132','97.35343108999112','97.353431089991119','test'),('2018-10-06 15:59:59','2018-10-07 15:59:59','POABNB','4h','0.007910000000000','0.008040000000000','0.712627115578735','0.724339065645137','90.09192358770353','90.091923587703533','test'),('2018-10-11 15:59:59','2018-10-11 23:59:59','POABNB','4h','0.008150000000000','0.007750000000000','0.712627115578735','0.677651551623951','87.43890988696137','87.438909886961369','test'),('2018-10-13 15:59:59','2018-10-16 19:59:59','POABNB','4h','0.008260000000000','0.011510000000000','0.712627115578735','0.993019140473516','86.27446919839407','86.274469198394073','test'),('2018-10-28 23:59:59','2018-10-29 03:59:59','POABNB','4h','0.010620000000000','0.010420000000000','0.770390904854773','0.755882601561840','72.5415164646679','72.541516464667893','test'),('2018-10-30 23:59:59','2018-10-31 03:59:59','POABNB','4h','0.010610000000000','0.010820000000000','0.770390904854773','0.785638981199684','72.60988735671754','72.609887356717536','test'),('2018-11-25 19:59:59','2018-11-25 23:59:59','POABNB','4h','0.007720000000000','0.007520000000000','0.770575848117767','0.750612743244250','99.81552436758646','99.815524367586463','test'),('2018-11-28 11:59:59','2018-11-28 15:59:59','POABNB','4h','0.008240000000000','0.007960000000000','0.770575848117767','0.744391231919590','93.5164864220591','93.516486422059103','test'),('2018-12-01 07:59:59','2018-12-02 11:59:59','POABNB','4h','0.007710000000000','0.007570000000000','0.770575848117767','0.756583549967769','99.9449867857026','99.944986785702596','test'),('2018-12-22 03:59:59','2018-12-22 07:59:59','POABNB','4h','0.005610000000000','0.005480000000000','0.770575848117767','0.752719366788835','137.35754868409393','137.357548684093928','test'),('2018-12-22 11:59:59','2018-12-22 15:59:59','POABNB','4h','0.005720000000000','0.005320000000000','0.770575848117767','0.716689425172469','134.71605736324597','134.716057363245966','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','POABNB','4h','0.004780000000000','0.004620000000000','0.770575848117767','0.744782514289557','161.2083364263111','161.208336426311092','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','POABNB','4h','0.004540000000000','0.004490000000000','0.770575848117767','0.762089329966690','169.7303630215346','169.730363021534600','test'),('2019-01-17 03:59:59','2019-01-17 19:59:59','POABNB','4h','0.004640000000000','0.004560000000000','0.770575848117767','0.757290057632978','166.07238105986357','166.072381059863574','test'),('2019-01-19 03:59:59','2019-01-19 07:59:59','POABNB','4h','0.004660000000000','0.004600000000000','0.770575848117767','0.760654270674191','165.35962405960666','165.359624059606659','test'),('2019-01-20 23:59:59','2019-01-21 03:59:59','POABNB','4h','0.004590000000000','0.004580000000000','0.770575848117767','0.768897033633850','167.88144839167038','167.881448391670375','test'),('2019-01-21 15:59:59','2019-01-21 23:59:59','POABNB','4h','0.004620000000000','0.004500000000000','0.770575848117767','0.750560891023799','166.7913091163998','166.791309116399788','test'),('2019-01-22 15:59:59','2019-01-23 23:59:59','POABNB','4h','0.004680000000000','0.004550000000000','0.770575848117767','0.749170963447829','164.65295899952287','164.652958999522866','test'),('2019-01-26 15:59:59','2019-01-26 19:59:59','POABNB','4h','0.004680000000000','0.004550000000000','0.770575848117767','0.749170963447829','164.65295899952287','164.652958999522866','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','POABNB','4h','0.004660000000000','0.004500000000000','0.770575848117767','0.744118308268230','165.35962405960666','165.359624059606659','test'),('2019-02-26 03:59:59','2019-02-26 11:59:59','POABNB','4h','0.002920000000000','0.002870000000000','0.770575848117767','0.757381056197942','263.89583839649555','263.895838396495549','test'),('2019-03-15 03:59:59','2019-03-15 07:59:59','POABNB','4h','0.002310000000000','0.002260000000000','0.770575848117767','0.753896717206127','333.5826182327996','333.582618232799575','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','POABNB','4h','0.002160000000000','0.002140000000000','0.770575848117767','0.763440886561121','356.74807783229954','356.748077832299543','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','POABNB','4h','0.002200000000000','0.002150000000000','0.770575848117767','0.753062760660545','350.26174914443953','350.261749144439534','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','POABNB','4h','0.002200000000000','0.002170000000000','0.770575848117767','0.760067995643434','350.26174914443953','350.261749144439534','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','POABNB','4h','0.002170000000000','0.002170000000000','0.770575848117767','0.770575848117767','355.10407747362535','355.104077473625352','test'),('2019-03-26 15:59:59','2019-03-26 19:59:59','POABNB','4h','0.002130000000000','0.002140000000000','0.770575848117767','0.774193575104235','361.772698646839','361.772698646838990','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','POABNB','4h','0.002160000000000','0.002150000000000','0.770575848117767','0.767008367339444','356.74807783229954','356.748077832299543','test'),('2019-04-08 23:59:59','2019-04-09 03:59:59','POABNB','4h','0.002180000000000','0.002180000000000','0.770575848117767','0.770575848117767','353.4751596870491','353.475159687049086','test'),('2019-04-09 23:59:59','2019-04-10 03:59:59','POABNB','4h','0.002170000000000','0.002200000000000','0.770575848117767','0.781228970441976','355.10407747362535','355.104077473625352','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','POABNB','4h','0.002230000000000','0.002200000000000','0.770575848117767','0.760209356887483','345.54970767612866','345.549707676128662','test'),('2019-04-17 11:59:59','2019-04-17 19:59:59','POABNB','4h','0.002210000000000','0.002160000000000','0.770575848117767','0.753142005400171','348.67685435193073','348.676854351930729','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','POABNB','4h','0.001400000000000','0.001340000000000','0.770575848117767','0.737551168912720','550.4113200841193','550.411320084119325','test'),('2019-05-10 23:59:59','2019-05-11 03:59:59','POABNB','4h','0.001350000000000','0.001340000000000','0.770575848117767','0.764867878872450','570.7969245316792','570.796924531679224','test'),('2019-05-11 07:59:59','2019-05-11 11:59:59','POABNB','4h','0.001410000000000','0.001360000000000','0.770575848117767','0.743250463432740','546.507693700544','546.507693700543996','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','POABNB','4h','0.001170000000000','0.001060000000000','0.770575848117767','0.698128546157977','658.6118359980915','658.611835998091465','test'),('2019-05-26 23:59:59','2019-05-28 07:59:59','POABNB','4h','0.001240000000000','0.001220000000000','0.770575848117767','0.758147205406190','621.4321355788444','621.432135578844395','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','POABNB','4h','0.001160000000000','0.001140000000000','0.770575848117767','0.757290057632978','664.2895242394543','664.289524239454295','test'),('2019-06-13 11:59:59','2019-06-13 15:59:59','POABNB','4h','0.001130000000000','0.001130000000000','0.770575848117767','0.770575848117767','681.9255293077584','681.925529307758438','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','POABNB','4h','0.001090000000000','0.001110000000000','0.770575848117767','0.784714854505249','706.9503193740982','706.950319374098171','test'),('2019-06-20 07:59:59','2019-06-20 11:59:59','POABNB','4h','0.001090000000000','0.001000000000000','0.770575848117767','0.706950319374098','706.9503193740982','706.950319374098171','test'),('2019-06-23 11:59:59','2019-06-23 15:59:59','POABNB','4h','0.001050000000000','0.001040000000000','0.770575848117767','0.763237030516645','733.8817601121591','733.881760112159100','test'),('2019-06-23 23:59:59','2019-06-24 03:59:59','POABNB','4h','0.001050000000000','0.001030000000000','0.770575848117767','0.755898212915524','733.8817601121591','733.881760112159100','test'),('2019-06-27 11:59:59','2019-06-27 15:59:59','POABNB','4h','0.001050000000000','0.000990000000000','0.770575848117767','0.726542942511038','733.8817601121591','733.881760112159100','test'),('2019-07-02 07:59:59','2019-07-02 11:59:59','POABNB','4h','0.001020000000000','0.001020000000000','0.770575848117767','0.770575848117767','755.4665177625167','755.466517762516673','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','POABNB','4h','0.000980000000000','0.000960000000000','0.770575848117767','0.754849810401078','786.3018858344561','786.301885834456129','test'),('2019-07-25 11:59:59','2019-07-25 15:59:59','POABNB','4h','0.000749000000000','0.000735000000000','0.770575848117767','0.756172561237061','1028.806205764709','1028.806205764708920','test'),('2019-07-26 07:59:59','2019-07-26 15:59:59','POABNB','4h','0.000739000000000','0.000739000000000','0.770575848117767','0.770575848117767','1042.7278053014438','1042.727805301443823','test'),('2019-07-29 03:59:59','2019-07-31 07:59:59','POABNB','4h','0.000740000000000','0.000736000000000','0.770575848117767','0.766410573263076','1041.318713672658','1041.318713672658077','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:47:43
