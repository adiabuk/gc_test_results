-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-21 15:59:59','2018-04-21 19:59:59','VIBBTC','4h','0.000021150000000','0.000021330000000','0.001467500000000','0.001479989361702','69.38534278959811','69.385342789598113','test'),('2018-04-26 15:59:59','2018-04-27 15:59:59','VIBBTC','4h','0.000022490000000','0.000022940000000','0.001470622340426','0.001500047865246','65.39005515453535','65.390055154535347','test'),('2018-05-04 07:59:59','2018-05-04 11:59:59','VIBBTC','4h','0.000023600000000','0.000023050000000','0.001477978721631','0.001443534302271','62.626217018241526','62.626217018241526','test'),('2018-05-05 07:59:59','2018-05-05 11:59:59','VIBBTC','4h','0.000023240000000','0.000022530000000','0.001477978721631','0.001432825326951','63.59633053489672','63.596330534896722','test'),('2018-05-14 11:59:59','2018-05-14 23:59:59','VIBBTC','4h','0.000022330000000','0.000021850000000','0.001477978721631','0.001446208466979','66.18803052534706','66.188030525347060','test'),('2018-07-03 03:59:59','2018-07-03 11:59:59','VIBBTC','4h','0.000012050000000','0.000011560000000','0.001477978721631','0.001417878342079','122.65383582','122.653835819999998','test'),('2018-07-03 23:59:59','2018-07-04 00:22:26','VIBBTC','4h','0.000011980000000','0.000011770000000','0.001477978721631','0.001452070914324','123.3705109875626','123.370510987562596','test'),('2018-08-10 15:59:59','2018-08-10 19:59:59','VIBBTC','4h','0.000007500000000','0.000007530000000','0.001477978721631','0.001483890636518','197.0638295508','197.063829550799994','test'),('2018-08-24 19:59:59','2018-08-24 23:59:59','VIBBTC','4h','0.000006080000000','0.000005910000000','0.001477978721631','0.001436653658691','243.08860553141446','243.088605531414458','test'),('2018-08-26 07:59:59','2018-08-26 11:59:59','VIBBTC','4h','0.000005770000000','0.000005690000000','0.001477978721631','0.001457486815612','256.1488252393414','256.148825239341420','test'),('2018-08-26 15:59:59','2018-08-26 23:59:59','VIBBTC','4h','0.000005760000000','0.000005750000000','0.001477978721631','0.001475412786350','256.5935280609375','256.593528060937501','test'),('2018-08-27 07:59:59','2018-08-27 11:59:59','VIBBTC','4h','0.000005820000000','0.000005760000000','0.001477978721631','0.001462741827594','253.94823395721647','253.948233957216473','test'),('2018-09-01 11:59:59','2018-09-02 03:59:59','VIBBTC','4h','0.000005820000000','0.000005790000000','0.001477978721631','0.001470360274612','253.94823395721647','253.948233957216473','test'),('2018-09-04 19:59:59','2018-09-05 11:59:59','VIBBTC','4h','0.000005740000000','0.000005400000000','0.001477978721631','0.001390432943695','257.48758216567944','257.487582165679441','test'),('2018-09-15 23:59:59','2018-09-16 03:59:59','VIBBTC','4h','0.000005220000000','0.000005000000000','0.001477978721631','0.001415688430681','283.13768613620687','283.137686136206867','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','VIBBTC','4h','0.000005470000000','0.000005640000000','0.001477978721631','0.001523912246801','270.1972068795247','270.197206879524686','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','VIBBTC','4h','0.000006600000000','0.000006570000000','0.001477978721631','0.001471260636533','223.9361699440909','223.936169944090892','test'),('2018-10-15 03:59:59','2018-10-15 07:59:59','VIBBTC','4h','0.000006640000000','0.000006260000000','0.001477978721631','0.001393395602020','222.58715687213856','222.587156872138564','test'),('2018-10-16 07:59:59','2018-10-16 11:59:59','VIBBTC','4h','0.000006710000000','0.000006540000000','0.001477978721631','0.001440533657149','220.26508519090908','220.265085190909076','test'),('2018-10-30 15:59:59','2018-11-04 15:59:59','VIBBTC','4h','0.000007430000000','0.000007870000000','0.001477978721631','0.001565503706492','198.92042013876178','198.920420138761784','test'),('2018-11-06 03:59:59','2018-11-06 07:59:59','VIBBTC','4h','0.000008030000000','0.000007910000000','0.001477978721631','0.001455891866513','184.05712598144459','184.057125981444585','test'),('2018-11-07 11:59:59','2018-11-07 15:59:59','VIBBTC','4h','0.000007880000000','0.000008000000000','0.001477978721631','0.001500486011808','187.5607514760152','187.560751476015213','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','VIBBTC','4h','0.000006660000000','0.000006560000000','0.001477978721631','0.001455786848934','221.91872697162162','221.918726971621624','test'),('2018-12-03 19:59:59','2018-12-04 03:59:59','VIBBTC','4h','0.000006270000000','0.000006160000000','0.001477978721631','0.001452049270374','235.72228415167464','235.722284151674643','test'),('2018-12-08 19:59:59','2018-12-08 23:59:59','VIBBTC','4h','0.000006190000000','0.000006060000000','0.001477978721631','0.001446938780789','238.76877570775443','238.768775707754429','test'),('2018-12-09 07:59:59','2018-12-09 11:59:59','VIBBTC','4h','0.000006080000000','0.000006210000000','0.001477978721631','0.001509580240350','243.08860553141446','243.088605531414458','test'),('2018-12-12 03:59:59','2018-12-12 07:59:59','VIBBTC','4h','0.000006110000000','0.000006180000000','0.001477978721631','0.001494911374743','241.89504445679214','241.895044456792135','test'),('2018-12-15 19:59:59','2018-12-15 23:59:59','VIBBTC','4h','0.000006200000000','0.000006160000000','0.001477978721631','0.001468443375040','238.38366477919354','238.383664779193538','test'),('2018-12-16 19:59:59','2018-12-16 23:59:59','VIBBTC','4h','0.000006130000000','0.000006070000000','0.001477978721631','0.001463512371990','241.10582734600328','241.105827346003281','test'),('2018-12-17 03:59:59','2018-12-17 07:59:59','VIBBTC','4h','0.000006140000000','0.000006190000000','0.001477978721631','0.001490014378973','240.71314684543975','240.713146845439752','test'),('2018-12-22 03:59:59','2018-12-25 03:59:59','VIBBTC','4h','0.000006160000000','0.000006150000000','0.001477978721631','0.001475579405524','239.9316106543831','239.931610654383093','test'),('2018-12-26 19:59:59','2018-12-26 23:59:59','VIBBTC','4h','0.000006320000000','0.000006220000000','0.001477978721631','0.001454592982365','233.8573926631329','233.857392663132913','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','VIBBTC','4h','0.000006380000000','0.000006220000000','0.001477978721631','0.001440913424537','231.65810683871473','231.658106838714730','test'),('2019-01-02 11:59:59','2019-01-10 07:59:59','VIBBTC','4h','0.000006290000000','0.000006300000000','0.001477978721631','0.001480328449328','234.9727697346582','234.972769734658186','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','VIBBTC','4h','0.000006340000000','0.000006320000000','0.001477978721631','0.001473316328187','233.11967218154572','233.119672181545724','test'),('2019-01-21 15:59:59','2019-01-24 07:59:59','VIBBTC','4h','0.000006600000000','0.000006860000000','0.001477978721631','0.001536202125816','223.9361699440909','223.936169944090892','test'),('2019-02-01 23:59:59','2019-02-02 07:59:59','VIBBTC','4h','0.000006580000000','0.000006590000000','0.001477978721631','0.001480224889901','224.6168269955927','224.616826995592703','test'),('2019-02-08 07:59:59','2019-02-08 11:59:59','VIBBTC','4h','0.000006540000000','0.000006530000000','0.001477978721631','0.001475718815329','225.99063021880733','225.990630218807325','test'),('2019-02-09 19:59:59','2019-02-09 23:59:59','VIBBTC','4h','0.000006540000000','0.000006500000000','0.001477978721631','0.001468939096422','225.99063021880733','225.990630218807325','test'),('2019-02-18 03:59:59','2019-02-18 07:59:59','VIBBTC','4h','0.000006380000000','0.000006310000000','0.001477978721631','0.001461762654152','231.65810683871473','231.658106838714730','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','VIBBTC','4h','0.000006220000000','0.000006130000000','0.001477978721631','0.001456593177427','237.61715781848875','237.617157818488749','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','VIBBTC','4h','0.000006460000000','0.000006390000000','0.001477978721631','0.001461963472325','228.78927579427244','228.789275794272442','test'),('2019-02-26 11:59:59','2019-02-26 19:59:59','VIBBTC','4h','0.000006250000000','0.000006290000000','0.001477978721631','0.001487437785449','236.47659546096','236.476595460959999','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','VIBBTC','4h','0.000006370000000','0.000006300000000','0.001477978721631','0.001461737197217','232.02177733610674','232.021777336106737','test'),('2019-03-04 19:59:59','2019-03-21 15:59:59','VIBBTC','4h','0.000006330000000','0.000006840000000','0.001477978721631','0.001597057575980','233.48794970473932','233.487949704739322','test'),('2019-03-26 15:59:59','2019-03-27 15:59:59','VIBBTC','4h','0.000007190000000','0.000011040000000','0.001477978721631','0.002269385964785','205.56032289721836','205.560322897218356','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','VIBBTC','4h','0.000008190000000','0.000007440000000','0.001570002393592','0.001426229280626','191.69748395506718','191.697483955067185','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','VIBBTC','4h','0.000008120000000','0.000008380000000','0.001570002393592','0.001620273406195','193.35004847192118','193.350048471921184','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:55:18
