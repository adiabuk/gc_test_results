-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 07:59:59','2018-07-02 23:59:59','AIONETH','4h','0.002435000000000','0.002364000000000','0.072144500000000','0.070040902669405','29.628131416837782','29.628131416837782','test'),('2018-07-05 03:59:59','2018-07-05 07:59:59','AIONETH','4h','0.002420000000000','0.002468000000000','0.072144500000000','0.073575465289256','29.811776859504135','29.811776859504135','test'),('2018-07-14 23:59:59','2018-07-15 03:59:59','AIONETH','4h','0.002186000000000','0.002161000000000','0.072144500000000','0.071319425663312','33.00297346752058','33.002973467520583','test'),('2018-07-16 15:59:59','2018-07-16 23:59:59','AIONETH','4h','0.002181000000000','0.002173000000000','0.072144500000000','0.071879870930766','33.078633654287025','33.078633654287025','test'),('2018-08-17 03:59:59','2018-08-22 23:59:59','AIONETH','4h','0.001508000000000','0.001605000000000','0.072144500000000','0.076785094496021','47.841180371352785','47.841180371352785','test'),('2018-08-30 23:59:59','2018-09-02 11:59:59','AIONETH','4h','0.002074000000000','0.002073000000000','0.072864064762190','0.072828932619103','35.132143086880426','35.132143086880426','test'),('2018-09-04 07:59:59','2018-09-04 15:59:59','AIONETH','4h','0.002100000000000','0.002069000000000','0.072864064762190','0.071788452377605','34.697173696280956','34.697173696280956','test'),('2018-09-07 15:59:59','2018-09-12 03:59:59','AIONETH','4h','0.002075000000000','0.002117000000000','0.072864064762190','0.074338903663401','35.11521193358554','35.115211933585542','test'),('2018-09-20 15:59:59','2018-09-20 23:59:59','AIONETH','4h','0.002107000000000','0.002024000000000','0.072955088355575','0.070081204950965','34.625101260358214','34.625101260358214','test'),('2018-09-21 03:59:59','2018-09-21 07:59:59','AIONETH','4h','0.002070000000000','0.002083000000000','0.072955088355575','0.073413260408050','35.244004036509665','35.244004036509665','test'),('2018-10-02 11:59:59','2018-10-02 15:59:59','AIONETH','4h','0.001912000000000','0.001847000000000','0.072955088355575','0.070474920602901','38.15642696421286','38.156426964212862','test'),('2018-10-04 15:59:59','2018-10-07 19:59:59','AIONETH','4h','0.001913000000000','0.001952000000000','0.072955088355575','0.074442411118705','38.136481105893886','38.136481105893886','test'),('2018-10-08 11:59:59','2018-10-08 15:59:59','AIONETH','4h','0.001951000000000','0.001920000000000','0.072955088355575','0.071795883978833','37.39368957230907','37.393689572309071','test'),('2018-10-08 23:59:59','2018-10-09 07:59:59','AIONETH','4h','0.001969000000000','0.001949000000000','0.072955088355575','0.072214051399195','37.05184781898172','37.051847818981720','test'),('2018-10-13 15:59:59','2018-10-15 03:59:59','AIONETH','4h','0.002186000000000','0.002149000000000','0.072955088355575','0.071720258406281','33.3737824133463','33.373782413346298','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','AIONETH','4h','0.002096000000000','0.002062000000000','0.072955088355575','0.071771656578815','34.806816963537685','34.806816963537685','test'),('2018-10-23 11:59:59','2018-10-23 15:59:59','AIONETH','4h','0.002103000000000','0.002123000000000','0.072955088355575','0.073648907550588','34.69095975063006','34.690959750630057','test'),('2018-10-24 11:59:59','2018-10-24 15:59:59','AIONETH','4h','0.002104000000000','0.002118000000000','0.072955088355575','0.073440530958701','34.67447165188926','34.674471651889263','test'),('2018-10-25 19:59:59','2018-10-25 23:59:59','AIONETH','4h','0.002086000000000','0.002099000000000','0.072955088355575','0.073409746144943','34.97367610526126','34.973676105261262','test'),('2018-11-01 15:59:59','2018-11-02 23:59:59','AIONETH','4h','0.002129000000000','0.002107000000000','0.072955088355575','0.072201207686800','34.26730312615078','34.267303126150779','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','AIONETH','4h','0.001484000000000','0.001390000000000','0.072955088355575','0.068333943944912','49.16111075173517','49.161110751735173','test'),('2018-11-30 15:59:59','2018-11-30 19:59:59','AIONETH','4h','0.001382000000000','0.001359000000000','0.072955088355575','0.071740929866300','52.78949953370116','52.789499533701161','test'),('2018-12-01 07:59:59','2018-12-03 03:59:59','AIONETH','4h','0.001347000000000','0.001344000000000','0.072955088355575','0.072792604862578','54.161164332275426','54.161164332275426','test'),('2018-12-03 19:59:59','2018-12-03 23:59:59','AIONETH','4h','0.001375000000000','0.001351000000000','0.072955088355575','0.071681690449732','53.05824607678182','53.058246076781820','test'),('2018-12-04 07:59:59','2018-12-06 15:59:59','AIONETH','4h','0.001373000000000','0.001400000000000','0.072955088355575','0.074389747776988','53.13553412642025','53.135534126420247','test'),('2018-12-07 03:59:59','2018-12-07 07:59:59','AIONETH','4h','0.001399000000000','0.001409000000000','0.072955088355575','0.073476568615443','52.14802598682988','52.148025986829879','test'),('2018-12-12 23:59:59','2018-12-13 03:59:59','AIONETH','4h','0.001356000000000','0.001372000000000','0.072955088355575','0.073815915356821','53.80168757785767','53.801687577857670','test'),('2018-12-13 15:59:59','2018-12-13 19:59:59','AIONETH','4h','0.001371000000000','0.001375000000000','0.072955088355575','0.073167940546255','53.21304767000365','53.213047670003647','test'),('2018-12-17 15:59:59','2018-12-17 19:59:59','AIONETH','4h','0.001361000000000','0.001312000000000','0.072955088355575','0.070328490758644','53.60403259042983','53.604032590429831','test'),('2018-12-19 19:59:59','2018-12-19 23:59:59','AIONETH','4h','0.001391000000000','0.001359000000000','0.072955088355575','0.071276754187798','52.44794274304457','52.447942743044571','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','AIONETH','4h','0.001080000000000','0.001072000000000','0.072955088355575','0.072414680293682','67.55100773664351','67.551007736643513','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','AIONETH','4h','0.001064000000000','0.001049000000000','0.072955088355575','0.071926586170111','68.56681236426222','68.566812364262219','test'),('2019-01-16 11:59:59','2019-01-16 15:59:59','AIONETH','4h','0.001054000000000','0.001072000000000','0.072955088355575','0.074201000680433','69.21735138100095','69.217351381000952','test'),('2019-01-27 19:59:59','2019-01-27 23:59:59','AIONETH','4h','0.001139000000000','0.001138000000000','0.072955088355575','0.072891036478178','64.05187739734416','64.051877397344157','test'),('2019-01-28 15:59:59','2019-01-28 19:59:59','AIONETH','4h','0.001171000000000','0.001151000000000','0.072955088355575','0.071709057811500','62.30152720373613','62.301527203736129','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','AIONETH','4h','0.001092000000000','0.001070000000000','0.072955088355575','0.071485297198228','66.80868897030678','66.808688970306775','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','AIONETH','4h','0.001028000000000','0.001008000000000','0.072955088355575','0.071535728659941','70.96798478168775','70.967984781687747','test'),('2019-02-14 07:59:59','2019-02-14 11:59:59','AIONETH','4h','0.001027000000000','0.001005000000000','0.072955088355575','0.071392272441434','71.03708700640215','71.037087006402146','test'),('2019-02-26 23:59:59','2019-02-27 03:59:59','AIONETH','4h','0.000845000000000','0.000834000000000','0.072955088355575','0.072005377146212','86.33738266931952','86.337382669319524','test'),('2019-03-01 03:59:59','2019-03-01 19:59:59','AIONETH','4h','0.000861000000000','0.000854000000000','0.072955088355575','0.072361957555936','84.73297137697445','84.732971376974447','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','AIONETH','4h','0.000861000000000','0.000870000000000','0.072955088355575','0.073717685097968','84.73297137697445','84.732971376974447','test'),('2019-03-07 19:59:59','2019-03-08 03:59:59','AIONETH','4h','0.000862000000000','0.000904000000000','0.072955088355575','0.076509744632761','84.6346732663283','84.634673266328306','test'),('2019-03-17 23:59:59','2019-03-18 03:59:59','AIONETH','4h','0.000998000000000','0.000988000000000','0.072955088355575','0.072224075446201','73.1012909374499','73.101290937449903','test'),('2019-03-18 07:59:59','2019-03-18 15:59:59','AIONETH','4h','0.000998000000000','0.000995000000000','0.072955088355575','0.072735784482763','73.1012909374499','73.101290937449903','test'),('2019-03-19 19:59:59','2019-03-20 15:59:59','AIONETH','4h','0.001024000000000','0.001037000000000','0.072955088355575','0.073881276000714','71.24520347224122','71.245203472241215','test'),('2019-03-27 11:59:59','2019-04-06 15:59:59','AIONETH','4h','0.001036000000000','0.001314000000000','0.072955088355575','0.092531839864117','70.41996945518822','70.419969455188223','test'),('2019-04-17 11:59:59','2019-04-18 03:59:59','AIONETH','4h','0.001174000000000','0.001155000000000','0.073167255505219','0.071983117639291','62.32304557514395','62.323045575143951','test'),('2019-04-23 07:59:59','2019-04-23 19:59:59','AIONETH','4h','0.001135000000000','0.001128000000000','0.073167255505219','0.072716003709152','64.46454229534714','64.464542295347144','test'),('2019-04-26 11:59:59','2019-04-26 15:59:59','AIONETH','4h','0.001113000000000','0.001082000000000','0.073167255505219','0.071129353510015','65.7387740388311','65.738774038831096','test'),('2019-04-27 15:59:59','2019-04-29 03:59:59','AIONETH','4h','0.001124000000000','0.001118000000000','0.073167255505219','0.072776682966935','65.09542304734786','65.095423047347865','test'),('2019-05-01 11:59:59','2019-05-01 19:59:59','AIONETH','4h','0.001127000000000','0.001105000000000','0.073167255505219','0.071738968352500','64.92214330542947','64.922143305429472','test'),('2019-05-02 19:59:59','2019-05-02 23:59:59','AIONETH','4h','0.001145000000000','0.001104000000000','0.073167255505219','0.070547292644333','63.90153319233101','63.901533192331009','test'),('2019-05-03 07:59:59','2019-05-03 11:59:59','AIONETH','4h','0.001116000000000','0.001144000000000','0.073167255505219','0.075002993098540','65.5620569043181','65.562056904318098','test'),('2019-05-11 23:59:59','2019-05-12 03:59:59','AIONETH','4h','0.001091000000000','0.001077000000000','0.073167255505219','0.072228353968030','67.0643955134913','67.064395513491306','test'),('2019-05-13 07:59:59','2019-05-13 15:59:59','AIONETH','4h','0.001099000000000','0.001030000000000','0.073167255505219','0.068573496970314','66.57621065079073','66.576210650790728','test'),('2019-05-31 19:59:59','2019-06-01 03:59:59','AIONETH','4h','0.000857000000000','0.000805000000000','0.073167255505219','0.068727702078998','85.37602742732673','85.376027427326733','test'),('2019-06-07 19:59:59','2019-06-07 23:59:59','AIONETH','4h','0.000810000000000','0.000803000000000','0.073167255505219','0.072534945889742','90.32994506817161','90.329945068171611','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:12:00
