-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-04 11:59:59','2018-06-04 15:59:59','DGDETH','4h','0.316390000000000','0.282110000000000','0.072144500000000','0.064327838727520','0.2280239577736338','0.228023957773634','test'),('2018-06-14 15:59:59','2018-06-14 19:59:59','DGDETH','4h','0.248260000000000','0.227010000000000','0.072144500000000','0.065969237674213','0.2906005800370579','0.290600580037058','test'),('2018-06-27 23:59:59','2018-06-28 03:59:59','DGDETH','4h','0.218510000000000','0.219160000000000','0.072144500000000','0.072359107683859','0.33016566747517273','0.330165667475173','test'),('2018-06-29 15:59:59','2018-06-29 19:59:59','DGDETH','4h','0.218330000000000','0.224050000000000','0.072144500000000','0.074034604612284','0.33043786928044705','0.330437869280447','test'),('2018-07-01 15:59:59','2018-07-01 19:59:59','DGDETH','4h','0.218600000000000','0.217720000000000','0.072144500000000','0.071854073833486','0.33002973467520585','0.330029734675206','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','DGDETH','4h','0.217320000000000','0.221670000000000','0.072144500000000','0.073588585104914','0.3319735873366464','0.331973587336646','test'),('2018-07-10 15:59:59','2018-07-10 19:59:59','DGDETH','4h','0.229160000000000','0.222150000000000','0.072144500000000','0.069937601130215','0.31482152208064235','0.314821522080642','test'),('2018-07-17 11:59:59','2018-07-17 15:59:59','DGDETH','4h','0.211670000000000','0.212160000000000','0.072144500000000','0.072311509047102','0.340834790003307','0.340834790003307','test'),('2018-07-23 19:59:59','2018-07-24 03:59:59','DGDETH','4h','0.215740000000000','0.211820000000000','0.072144500000000','0.070833633030500','0.33440483915824604','0.334404839158246','test'),('2018-08-07 23:59:59','2018-08-08 03:59:59','DGDETH','4h','0.196220000000000','0.188450000000000','0.072144500000000','0.069287692513505','0.3676714911833656','0.367671491183366','test'),('2018-08-13 07:59:59','2018-08-13 11:59:59','DGDETH','4h','0.193030000000000','0.178870000000000','0.072144500000000','0.066852233927369','0.37374760399937834','0.373747603999378','test'),('2018-08-17 07:59:59','2018-08-17 11:59:59','DGDETH','4h','0.181530000000000','0.180600000000000','0.072144500000000','0.071774895058668','0.39742466809893684','0.397424668098937','test'),('2018-08-19 11:59:59','2018-08-19 15:59:59','DGDETH','4h','0.206530000000000','0.201930000000000','0.072144500000000','0.070537640463855','0.3493172904662761','0.349317290466276','test'),('2018-09-06 11:59:59','2018-09-06 15:59:59','DGDETH','4h','0.208580000000000','0.182640000000000','0.072144500000000','0.063172267139707','0.34588407325726345','0.345884073257263','test'),('2018-09-12 15:59:59','2018-09-12 19:59:59','DGDETH','4h','0.189920000000000','0.186500000000000','0.072144500000000','0.070845351990312','0.3798678390901432','0.379867839090143','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','DGDETH','4h','0.169790000000000','0.169430000000000','0.072144500000000','0.071991534454326','0.4249042935390777','0.424904293539078','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','DGDETH','4h','0.168000000000000','0.166060000000000','0.072144500000000','0.071311402797619','0.4294315476190476','0.429431547619048','test'),('2018-09-25 19:59:59','2018-09-25 23:59:59','DGDETH','4h','0.167460000000000','0.165650000000000','0.072144500000000','0.071364722471038','0.43081631434372386','0.430816314343724','test'),('2018-09-26 03:59:59','2018-09-26 07:59:59','DGDETH','4h','0.167620000000000','0.166780000000000','0.072144500000000','0.071782959730342','0.4304050829256652','0.430405082925665','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','DGDETH','4h','0.168620000000000','0.169100000000000','0.072144500000000','0.072349869232594','0.4278525679041632','0.427852567904163','test'),('2018-09-30 19:59:59','2018-10-01 11:59:59','DGDETH','4h','0.167620000000000','0.167070000000000','0.072144500000000','0.071907777204391','0.4304050829256652','0.430405082925665','test'),('2018-10-30 03:59:59','2018-10-30 07:59:59','DGDETH','4h','0.207500000000000','0.204460000000000','0.072144500000000','0.071087539614458','0.34768433734939763','0.347684337349398','test'),('2018-10-31 07:59:59','2018-10-31 11:59:59','DGDETH','4h','0.204630000000000','0.202230000000000','0.072144500000000','0.071298354273567','0.3525607193471143','0.352560719347114','test'),('2018-10-31 23:59:59','2018-11-01 11:59:59','DGDETH','4h','0.203810000000000','0.203200000000000','0.072144500000000','0.071928572690251','0.353979196310289','0.353979196310289','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','DGDETH','4h','0.208900000000000','0.202170000000000','0.072144500000000','0.069820265988511','0.34535423647678315','0.345354236476783','test'),('2018-12-01 23:59:59','2018-12-02 07:59:59','DGDETH','4h','0.160740000000000','0.162430000000000','0.072144500000000','0.072903018134876','0.4488272987433122','0.448827298743312','test'),('2018-12-06 03:59:59','2018-12-06 11:59:59','DGDETH','4h','0.158840000000000','0.157450000000000','0.072144500000000','0.071513167495593','0.4541960463359355','0.454196046335936','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','DGDETH','4h','0.154470000000000','0.151690000000000','0.072144500000000','0.070846113840875','0.4670453809801256','0.467045380980126','test'),('2018-12-23 07:59:59','2018-12-23 11:59:59','DGDETH','4h','0.176630000000000','0.172460000000000','0.072144500000000','0.070441264054804','0.40844986695351865','0.408449866953519','test'),('2019-01-03 11:59:59','2019-01-03 15:59:59','DGDETH','4h','0.140860000000000','0.132310000000000','0.072144500000000','0.067765432308675','0.5121716598040608','0.512171659804061','test'),('2019-01-06 03:59:59','2019-01-06 07:59:59','DGDETH','4h','0.136240000000000','0.135920000000000','0.072144500000000','0.071975047269524','0.5295397827363476','0.529539782736348','test'),('2019-01-06 19:59:59','2019-01-06 23:59:59','DGDETH','4h','0.137360000000000','0.139220000000000','0.072144500000000','0.073121413002330','0.5252220442632498','0.525222044263250','test'),('2019-01-10 07:59:59','2019-01-10 19:59:59','DGDETH','4h','0.138310000000000','0.137900000000000','0.072144500000000','0.071930638059432','0.5216144891909479','0.521614489190948','test'),('2019-01-16 03:59:59','2019-01-16 11:59:59','DGDETH','4h','0.139810000000000','0.140230000000000','0.072144500000000','0.072361227630355','0.5160181675130535','0.516018167513054','test'),('2019-02-08 03:59:59','2019-02-08 07:59:59','DGDETH','4h','0.147700000000000','0.147720000000000','0.072144500000000','0.072154269058903','0.4884529451591063','0.488452945159106','test'),('2019-02-26 15:59:59','2019-02-26 19:59:59','DGDETH','4h','0.118020000000000','0.116830000000000','0.072144500000000','0.071417064353499','0.6112904592441959','0.611290459244196','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','DGDETH','4h','0.116520000000000','0.114650000000000','0.072144500000000','0.070986671172331','0.6191598008925506','0.619159800892551','test'),('2019-03-01 19:59:59','2019-03-03 15:59:59','DGDETH','4h','0.120890000000000','0.119050000000000','0.072144500000000','0.071046428364629','0.5967780627016296','0.596778062701630','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','DGDETH','4h','0.116390000000000','0.113630000000000','0.072144500000000','0.070433710241430','0.619851361800842','0.619851361800842','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DGDETH','4h','0.115890000000000','0.115960000000000','0.072144500000000','0.072188076796963','0.622525670894814','0.622525670894814','test'),('2019-03-10 15:59:59','2019-03-16 07:59:59','DGDETH','4h','0.115930000000000','0.121530000000000','0.072144500000000','0.075629440912620','0.622310877253515','0.622310877253515','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','DGDETH','4h','0.121400000000000','0.121650000000000','0.072144500000000','0.072293067751236','0.5942710049423394','0.594271004942339','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','DGDETH','4h','0.121960000000000','0.123240000000000','0.072144500000000','0.072901674155461','0.5915423089537554','0.591542308953755','test'),('2019-04-06 03:59:59','2019-04-06 07:59:59','DGDETH','4h','0.135200000000000','0.134050000000000','0.072144500000000','0.071530844859467','0.5336131656804735','0.533613165680473','test'),('2019-04-07 15:59:59','2019-04-07 19:59:59','DGDETH','4h','0.133730000000000','0.132550000000000','0.072144500000000','0.071507915015329','0.5394788005683093','0.539478800568309','test'),('2019-04-18 19:59:59','2019-04-23 07:59:59','DGDETH','4h','0.136990000000000','0.186980000000000','0.072144500000000','0.098471265128842','0.5266406307029711','0.526640630702971','test'),('2019-05-03 15:59:59','2019-05-03 23:59:59','DGDETH','4h','0.184950000000000','0.180630000000000','0.072144500000000','0.070459372992701','0.39007569613409027','0.390075696134090','test'),('2019-05-08 07:59:59','2019-05-08 15:59:59','DGDETH','4h','0.196660000000000','0.188590000000000','0.072144500000000','0.069184029568799','0.36684887623309265','0.366848876233093','test'),('2019-05-12 03:59:59','2019-05-12 07:59:59','DGDETH','4h','0.198320000000000','0.187120000000000','0.072144500000000','0.068070183743445','0.3637782371924163','0.363778237192416','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:31:30
