-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-08-23 03:59:59','2019-08-23 07:59:59','BTTBNB','4h','0.000023320000000','0.000023030000000','0.711908500000000','0.703055435463122','30527.80874785592','30527.808747855920956','test'),('2019-08-23 11:59:59','2019-08-24 11:59:59','BTTBNB','4h','0.000023320000000','0.000023320000000','0.711908500000000','0.711908500000000','30527.80874785592','30527.808747855920956','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','BTTBNB','4h','0.000023880000000','0.000023910000000','0.711908500000000','0.712802857412060','29811.913735343387','29811.913735343387089','test'),('2019-09-03 19:59:59','2019-09-04 03:59:59','BTTBNB','4h','0.000024090000000','0.000024130000000','0.711908500000000','0.713090581361561','29552.034039020342','29552.034039020341879','test'),('2019-09-08 03:59:59','2019-09-08 11:59:59','BTTBNB','4h','0.000024120000000','0.000023830000000','0.711908500000000','0.703349069444445','29515.27777777778','29515.277777777781012','test'),('2019-09-21 11:59:59','2019-09-21 15:59:59','BTTBNB','4h','0.000027250000000','0.000027660000000','0.711908500000000','0.722619783853211','26125.08256880734','26125.082568807338248','test'),('2019-09-22 11:59:59','2019-09-22 15:59:59','BTTBNB','4h','0.000027370000000','0.000027120000000','0.711908500000000','0.705405864815492','26010.540738034346','26010.540738034345850','test'),('2019-09-24 19:59:59','2019-09-24 23:59:59','BTTBNB','4h','0.000027410000000','0.000026970000000','0.711908500000000','0.700480563480482','25972.58299890551','25972.582998905509157','test'),('2019-09-25 15:59:59','2019-09-25 19:59:59','BTTBNB','4h','0.000027440000000','0.000026510000000','0.711908500000000','0.687780405794461','25944.187317784257','25944.187317784257175','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','BTTBNB','4h','0.000027250000000','0.000027200000000','0.711908500000000','0.710602245871560','26125.08256880734','26125.082568807338248','test'),('2019-10-02 07:59:59','2019-10-02 11:59:59','BTTBNB','4h','0.000027480000000','0.000026850000000','0.711908500000000','0.695587453602620','25906.42285298399','25906.422852983989287','test'),('2019-10-02 23:59:59','2019-10-03 07:59:59','BTTBNB','4h','0.000027670000000','0.000027130000000','0.711908500000000','0.698015092338273','25728.532706902784','25728.532706902784412','test'),('2019-10-04 11:59:59','2019-10-04 15:59:59','BTTBNB','4h','0.000027270000000','0.000027190000000','0.711908500000000','0.709820026219289','26105.922258892555','26105.922258892554964','test'),('2019-10-05 07:59:59','2019-10-05 15:59:59','BTTBNB','4h','0.000027380000000','0.000027280000000','0.711908500000000','0.709308395909423','26001.04090577064','26001.040905770638346','test'),('2019-10-27 15:59:59','2019-10-27 19:59:59','BTTBNB','4h','0.000024270000000','0.000023410000000','0.711908500000000','0.686682240832303','29332.8594973218','29332.859497321798699','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','BTTBNB','4h','0.000023290000000','0.000023210000000','0.711908500000000','0.709463129454702','30567.131816230147','30567.131816230146796','test'),('2019-10-29 23:59:59','2019-10-30 07:59:59','BTTBNB','4h','0.000023920000000','0.000023480000000','0.711908500000000','0.698813193143813','29762.0610367893','29762.061036789298669','test'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BTTBNB','4h','0.000023460000000','0.000023020000000','0.711908500000000','0.698556422421142','30345.63086104007','30345.630861040070158','test'),('2019-11-19 11:59:59','2019-11-20 03:59:59','BTTBNB','4h','0.000021550000000','0.000021510000000','0.711908500000000','0.710587092111369','33035.19721577727','33035.197215777268866','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','BTTBNB','4h','0.000020630000000','0.000020110000000','0.711908500000000','0.693964126757150','34508.41008240427','34508.410082404268906','test'),('2019-11-28 19:59:59','2019-11-29 03:59:59','BTTBNB','4h','0.000020510000000','0.000020490000000','0.711908500000000','0.711214293759142','34710.312042905905','34710.312042905905400','test'),('2019-11-29 19:59:59','2019-11-30 03:59:59','BTTBNB','4h','0.000020340000000','0.000020110000000','0.711908500000000','0.703858403883973','35000.41789577188','35000.417895771883195','test'),('2019-12-03 03:59:59','2019-12-03 07:59:59','BTTBNB','4h','0.000020470000000','0.000020170000000','0.711908500000000','0.701475058378114','34778.13873961896','34778.138739618960244','test'),('2019-12-07 03:59:59','2019-12-07 11:59:59','BTTBNB','4h','0.000020140000000','0.000020190000000','0.711908500000000','0.713675899453823','35347.98907646475','35347.989076464749814','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','BTTBNB','4h','0.000019970000000','0.000020720000000','0.711908500000000','0.738645173760641','35648.89834752128','35648.898347521280812','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','BTTBNB','4h','0.000020140000000','0.000019410000000','0.711908500000000','0.686104467974181','35347.98907646475','35347.989076464749814','test'),('2019-12-13 23:59:59','2019-12-20 03:59:59','BTTBNB','4h','0.000020270000000','0.000020930000000','0.711908500000000','0.735088549827331','35121.28761716823','35121.287617168229190','test'),('2019-12-20 15:59:59','2019-12-21 03:59:59','BTTBNB','4h','0.000021220000000','0.000021020000000','0.711908500000000','0.705198712064090','33548.9396795476','33548.939679547598644','test'),('2019-12-23 19:59:59','2019-12-23 23:59:59','BTTBNB','4h','0.000021300000000','0.000021310000000','0.711908500000000','0.712242729342723','33422.934272300474','33422.934272300473822','test'),('2019-12-25 15:59:59','2019-12-26 03:59:59','BTTBNB','4h','0.000021460000000','0.000021070000000','0.711908500000000','0.698970740680335','33173.74184529357','33173.741845293567167','test'),('2019-12-30 03:59:59','2019-12-31 11:59:59','BTTBNB','4h','0.000021340000000','0.000021130000000','0.711908500000000','0.704902839971884','33360.28584817245','33360.285848172447004','test'),('2020-01-01 07:59:59','2020-01-01 11:59:59','BTTBNB','4h','0.000021140000000','0.000020980000000','0.711908500000000','0.706520356196783','33675.89877010407','33675.898770104067808','test'),('2020-01-01 15:59:59','2020-01-01 23:59:59','BTTBNB','4h','0.000021120000000','0.000020770000000','0.711908500000000','0.700110773910985','33707.788825757576','33707.788825757575978','test'),('2020-01-03 03:59:59','2020-01-03 07:59:59','BTTBNB','4h','0.000021140000000','0.000021040000000','0.711908500000000','0.708540910122990','33675.89877010407','33675.898770104067808','test'),('2020-01-04 03:59:59','2020-01-04 11:59:59','BTTBNB','4h','0.000021150000000','0.000020980000000','0.711908500000000','0.706186304018913','33659.97635933806','33659.976359338063048','test'),('2020-01-05 07:59:59','2020-01-05 15:59:59','BTTBNB','4h','0.000021320000000','0.000020990000000','0.711908500000000','0.700889278377111','33391.58067542214','33391.580675422141212','test'),('2020-01-12 15:59:59','2020-01-13 03:59:59','BTTBNB','4h','0.000020640000000','0.000020560000000','0.711908500000000','0.709149164728682','34491.69089147287','34491.690891472870135','test'),('2020-01-17 07:59:59','2020-01-17 19:59:59','BTTBNB','4h','0.000020950000000','0.000021080000000','0.711908500000000','0.716326070644391','33981.312649164676','33981.312649164676259','test'),('2020-01-22 15:59:59','2020-01-23 03:59:59','BTTBNB','4h','0.000020950000000','0.000020770000000','0.711908500000000','0.705791863723150','33981.312649164676','33981.312649164676259','test'),('2020-01-28 19:59:59','2020-01-28 23:59:59','BTTBNB','4h','0.000020790000000','0.000020570000000','0.711908500000000','0.704375076719577','34242.8330928331','34242.833092833097908','test'),('2020-01-29 19:59:59','2020-01-29 23:59:59','BTTBNB','4h','0.000020690000000','0.000020360000000','0.711908500000000','0.700553748670856','34408.33736104399','34408.337361043988494','test'),('2020-01-30 07:59:59','2020-01-30 11:59:59','BTTBNB','4h','0.000020560000000','0.000020350000000','0.711908500000000','0.704637061040856','34625.89980544747','34625.899805447472318','test'),('2020-01-31 15:59:59','2020-01-31 19:59:59','BTTBNB','4h','0.000020570000000','0.000020570000000','0.711908500000000','0.711908500000000','34609.06660184735','34609.066601847349375','test'),('2020-02-14 03:59:59','2020-02-16 15:59:59','BTTBNB','4h','0.000020450000000','0.000022630000000','0.711908500000000','0.787798990464548','34812.15158924206','34812.151589242057526','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:35:38
