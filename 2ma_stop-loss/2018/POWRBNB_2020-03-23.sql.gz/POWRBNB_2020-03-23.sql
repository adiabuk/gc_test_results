-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-26 19:59:59','2018-04-27 15:59:59','POWRBNB','4h','0.036990000000000','0.036870000000000','0.711908500000000','0.709598983373885','19.245971884293052','19.245971884293052','test'),('2018-04-28 03:59:59','2018-04-28 07:59:59','POWRBNB','4h','0.037110000000000','0.036450000000000','0.711908500000000','0.699247233225546','19.18373753705201','19.183737537052011','test'),('2018-04-29 11:59:59','2018-05-05 03:59:59','POWRBNB','4h','0.037120000000000','0.039290000000000','0.711908500000000','0.753525995824354','19.178569504310346','19.178569504310346','test'),('2018-05-08 11:59:59','2018-05-08 15:59:59','POWRBNB','4h','0.038130000000000','0.038540000000000','0.718570178105946','0.726296739160849','18.845270865616214','18.845270865616214','test'),('2018-05-14 11:59:59','2018-05-14 23:59:59','POWRBNB','4h','0.035630000000000','0.035230000000000','0.720501818369672','0.712413108648991','20.221774301702837','20.221774301702837','test'),('2018-06-30 03:59:59','2018-07-07 23:59:59','POWRBNB','4h','0.016850000000000','0.019760000000000','0.720501818369672','0.844932696200874','42.75975183202801','42.759751832028009','test'),('2018-07-24 15:59:59','2018-07-24 19:59:59','POWRBNB','4h','0.027300000000000','0.027230000000000','0.749587360397302','0.747665341524488','27.457412468765646','27.457412468765646','test'),('2018-08-14 03:59:59','2018-08-14 07:59:59','POWRBNB','4h','0.017680000000000','0.017260000000000','0.749587360397302','0.731780420840353','42.397475135594','42.397475135594000','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','POWRBNB','4h','0.017610000000000','0.017680000000000','0.749587360397302','0.752566980796383','42.56600570115287','42.566005701152868','test'),('2018-08-25 03:59:59','2018-08-25 07:59:59','POWRBNB','4h','0.019170000000000','0.019120000000000','0.749587360397302','0.747632255127617','39.10210539370381','39.102105393703809','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','POWRBNB','4h','0.019130000000000','0.018830000000000','0.749587360397302','0.737832200537438','39.18386619954532','39.183866199545321','test'),('2018-08-25 23:59:59','2018-08-26 03:59:59','POWRBNB','4h','0.019280000000000','0.019350000000000','0.749587360397302','0.752308891270114','38.87901246873973','38.879012468739731','test'),('2018-08-29 11:59:59','2018-08-29 15:59:59','POWRBNB','4h','0.019290000000000','0.018620000000000','0.749587360397302','0.723551925899314','38.858857459683875','38.858857459683875','test'),('2018-09-16 15:59:59','2018-09-16 19:59:59','POWRBNB','4h','0.016850000000000','0.016140000000000','0.749587360397302','0.718002373698069','44.4858967594838','44.485896759483801','test'),('2018-09-18 03:59:59','2018-09-18 07:59:59','POWRBNB','4h','0.015540000000000','0.015220000000000','0.749587360397302','0.734151842036482','48.23599487756126','48.235994877561261','test'),('2018-09-18 19:59:59','2018-09-19 07:59:59','POWRBNB','4h','0.015640000000000','0.015910000000000','0.749587360397302','0.762527807156079','47.92758058806278','47.927580588062781','test'),('2018-09-25 15:59:59','2018-09-27 03:59:59','POWRBNB','4h','0.016800000000000','0.017250000000000','0.749587360397302','0.769665593265087','44.61829526174417','44.618295261744173','test'),('2018-09-29 15:59:59','2018-09-29 19:59:59','POWRBNB','4h','0.016810000000000','0.016870000000000','0.749587360397302','0.752262865550415','44.59175255189185','44.591752551891851','test'),('2018-10-02 15:59:59','2018-10-02 19:59:59','POWRBNB','4h','0.016700000000000','0.016390000000000','0.749587360397302','0.735672864485735','44.885470682473176','44.885470682473176','test'),('2018-10-08 11:59:59','2018-10-08 23:59:59','POWRBNB','4h','0.016330000000000','0.016050000000000','0.749587360397302','0.736734668363545','45.90247154913055','45.902471549130553','test'),('2018-10-16 07:59:59','2018-10-21 23:59:59','POWRBNB','4h','0.017020000000000','0.018360000000000','0.749587360397302','0.808603051521414','44.04156054038202','44.041560540382022','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','POWRBNB','4h','0.018020000000000','0.017870000000000','0.749587360397302','0.743347731981120','41.597522774545055','41.597522774545055','test'),('2018-10-24 11:59:59','2018-10-25 03:59:59','POWRBNB','4h','0.018000000000000','0.017930000000000','0.749587360397302','0.746672298440202','41.64374224429456','41.643742244294558','test'),('2018-10-31 23:59:59','2018-11-01 03:59:59','POWRBNB','4h','0.017600000000000','0.017340000000000','0.749587360397302','0.738513910755069','42.590190931664885','42.590190931664885','test'),('2018-11-09 19:59:59','2018-11-09 23:59:59','POWRBNB','4h','0.016870000000000','0.016910000000000','0.749587360397302','0.751364686681587','44.43315710713112','44.433157107131123','test'),('2018-11-11 07:59:59','2018-11-11 11:59:59','POWRBNB','4h','0.016850000000000','0.016950000000000','0.749587360397302','0.754035950073250','44.4858967594838','44.485896759483801','test'),('2018-11-22 19:59:59','2018-11-22 23:59:59','POWRBNB','4h','0.016010000000000','0.015500000000000','0.749587360397302','0.725709187142922','46.81994755760787','46.819947557607868','test'),('2018-11-23 11:59:59','2018-11-24 23:59:59','POWRBNB','4h','0.016110000000000','0.015180000000000','0.749587360397302','0.706315091919990','46.52932094334587','46.529320943345873','test'),('2018-11-28 03:59:59','2018-11-28 07:59:59','POWRBNB','4h','0.016080000000000','0.015250000000000','0.749587360397302','0.710895973013610','46.61612937794167','46.616129377941668','test'),('2018-11-28 15:59:59','2018-11-30 11:59:59','POWRBNB','4h','0.015840000000000','0.016000000000000','0.749587360397302','0.757158949896265','47.32243436851654','47.322434368516539','test'),('2018-12-09 11:59:59','2018-12-09 15:59:59','POWRBNB','4h','0.015830000000000','0.015330000000000','0.749587360397302','0.725911196139649','47.3523285153065','47.352328515306503','test'),('2018-12-19 07:59:59','2018-12-19 11:59:59','POWRBNB','4h','0.014340000000000','0.014030000000000','0.749587360397302','0.733382891657890','52.27247980455383','52.272479804553832','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','POWRBNB','4h','0.014580000000000','0.014410000000000','0.749587360397302','0.740847315728746','51.41202746209205','51.412027462092048','test'),('2018-12-24 11:59:59','2018-12-24 19:59:59','POWRBNB','4h','0.014820000000000','0.014610000000000','0.749587360397302','0.738965677152806','50.579444021410396','50.579444021410396','test'),('2019-01-15 03:59:59','2019-01-15 07:59:59','POWRBNB','4h','0.013250000000000','0.012660000000000','0.749587360397302','0.716209508123007','56.57263097338129','56.572630973381287','test'),('2019-01-16 03:59:59','2019-01-17 11:59:59','POWRBNB','4h','0.012980000000000','0.016120000000000','0.749587360397302','0.930920512296187','57.749411432765946','57.749411432765946','test'),('2019-01-23 11:59:59','2019-01-23 19:59:59','POWRBNB','4h','0.015680000000000','0.015300000000000','0.749587360397302','0.731421340183592','47.805316351868754','47.805316351868754','test'),('2019-02-17 03:59:59','2019-02-18 03:59:59','POWRBNB','4h','0.009890000000000','0.009990000000000','0.749587360397302','0.757166605699600','75.79245302298301','75.792453022983011','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','POWRBNB','4h','0.009360000000000','0.009160000000000','0.749587360397302','0.733570536457189','80.08411970056645','80.084119700566447','test'),('2019-02-26 15:59:59','2019-02-27 15:59:59','POWRBNB','4h','0.009400000000000','0.009410000000000','0.749587360397302','0.750384793759427','79.74333621247894','79.743336212478937','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','POWRBNB','4h','0.007120000000000','0.007050000000000','0.749587360397302','0.742217821741711','105.27912365130646','105.279123651306463','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','POWRBNB','4h','0.007230000000000','0.007140000000000','0.749587360397302','0.740256397404804','103.67736658330594','103.677366583305940','test'),('2019-03-24 03:59:59','2019-03-24 11:59:59','POWRBNB','4h','0.007120000000000','0.006910000000000','0.749587360397302','0.727478744430528','105.27912365130646','105.279123651306463','test'),('2019-03-27 19:59:59','2019-03-27 23:59:59','POWRBNB','4h','0.007140000000000','0.007000000000000','0.749587360397302','0.734889569016963','104.9842241452804','104.984224145280393','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','POWRBNB','4h','0.007270000000000','0.007030000000000','0.749587360397302','0.724841697880747','103.10692715231113','103.106927152311130','test'),('2019-04-03 19:59:59','2019-04-03 23:59:59','POWRBNB','4h','0.007030000000000','0.006800000000000','0.749587360397302','0.725063165106921','106.62693604513542','106.626936045135423','test'),('2019-04-07 03:59:59','2019-04-08 11:59:59','POWRBNB','4h','0.006930000000000','0.006780000000000','0.749587360397302','0.733362525756668','108.16556427089495','108.165564270894947','test'),('2019-04-08 15:59:59','2019-04-09 11:59:59','POWRBNB','4h','0.006930000000000','0.006780000000000','0.749587360397302','0.733362525756668','108.16556427089495','108.165564270894947','test'),('2019-04-10 11:59:59','2019-04-10 15:59:59','POWRBNB','4h','0.006910000000000','0.006860000000000','0.749587360397302','0.744163428701229','108.47863392146193','108.478633921461935','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:42:02
