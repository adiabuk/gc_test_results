-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-20 03:59:59','2018-11-20 07:59:59','THETAETH','4h','0.000426540000000','0.000429700000000','0.072144500000000','0.072678978876541','169.13888498147887','169.138884981478867','test'),('2018-11-21 23:59:59','2018-11-22 03:59:59','THETAETH','4h','0.000417440000000','0.000401860000000','0.072278119719135','0.069580503043148','173.14612811214846','173.146128112148460','test'),('2018-11-22 07:59:59','2018-11-22 11:59:59','THETAETH','4h','0.000408340000000','0.000403450000000','0.072278119719135','0.071412566490388','177.00475025502035','177.004750255020355','test'),('2018-11-22 15:59:59','2018-11-22 19:59:59','THETAETH','4h','0.000414020000000','0.000421090000000','0.072278119719135','0.073512374843077','174.57639659710884','174.576396597108840','test'),('2018-12-06 07:59:59','2018-12-06 11:59:59','THETAETH','4h','0.000549690000000','0.000548460000000','0.072278119719135','0.072116388402839','131.48887503708454','131.488875037084540','test'),('2018-12-06 19:59:59','2018-12-06 23:59:59','THETAETH','4h','0.000555630000000','0.000543190000000','0.072278119719135','0.070659884905849','130.0831843477404','130.083184347740399','test'),('2018-12-22 03:59:59','2018-12-22 11:59:59','THETAETH','4h','0.000540040000000','0.000499000000000','0.072278119719135','0.066785389489387','133.8384558905544','133.838455890554400','test'),('2018-12-28 03:59:59','2018-12-28 07:59:59','THETAETH','4h','0.000448190000000','0.000417920000000','0.072278119719135','0.067396576882619','161.2666943018251','161.266694301825112','test'),('2019-01-10 15:59:59','2019-01-10 23:59:59','THETAETH','4h','0.000353100000000','0.000349670000000','0.072278119719135','0.071576012807108','204.69589271915888','204.695892719158877','test'),('2019-02-20 19:59:59','2019-02-20 23:59:59','THETAETH','4h','0.000678530000000','0.000659270000000','0.072278119719135','0.070226513178834','106.52162722228199','106.521627222281992','test'),('2019-02-24 23:59:59','2019-02-28 07:59:59','THETAETH','4h','0.000662050000000','0.001010000000000','0.072278119719135','0.110264936056682','109.17320401651689','109.173204016516891','test'),('2019-03-14 19:59:59','2019-03-14 23:59:59','THETAETH','4h','0.001090000000000','0.001005040000000','0.077465606946280','0.071427553766320','71.06936417089953','71.069364170899533','test'),('2019-03-15 03:59:59','2019-03-15 07:59:59','THETAETH','4h','0.001059960000000','0.001041890000000','0.077465606946280','0.076144987755443','73.08351913872222','73.083519138722224','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','THETAETH','4h','0.000789050000000','0.000751450000000','0.077465606946280','0.073774197249581','98.17578980581713','98.175789805817132','test'),('2019-04-13 23:59:59','2019-04-14 03:59:59','THETAETH','4h','0.000716000000000','0.000740530000000','0.077465606946280','0.080119561329509','108.19218847245811','108.192188472458113','test'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','0.077465606946280','0.076490920546729','104.58008578872195','104.580085788721945','test'),('2019-05-18 07:59:59','2019-05-18 11:59:59','THETAETH','4h','0.000490570000000','0.000483100000000','0.077465606946280','0.076286023841140','157.9093848916159','157.909384891615900','test'),('2019-05-18 15:59:59','2019-05-19 03:59:59','THETAETH','4h','0.000493020000000','0.000467220000000','0.077465606946280','0.073411790348142','157.12467434643625','157.124674346436251','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETAETH','4h','0.000559060000000','0.000520000000000','0.077465606946280','0.072053295911111','138.56403059829','138.564030598290003','test'),('2019-05-27 07:59:59','2019-05-27 11:59:59','THETAETH','4h','0.000485290000000','0.000479720000000','0.077465606946280','0.076576482029857','159.62745357678915','159.627453576789151','test'),('2019-05-28 11:59:59','2019-05-28 15:59:59','THETAETH','4h','0.000490040000000','0.000482800000000','0.077465606946280','0.076321106508987','158.08017089682477','158.080170896824768','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','THETAETH','4h','0.000502690000000','0.000497190000000','0.077465606946280','0.076618045152322','154.10214435592513','154.102144355925134','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETAETH','4h','0.000417370000000','0.000407050000000','0.077465606946280','0.075550172047544','185.60415685430195','185.604156854301948','test'),('2019-07-04 03:59:59','2019-07-04 07:59:59','THETAETH','4h','0.000418760000000','0.000399980000000','0.077465606946280','0.073991530868213','184.98807657436242','184.988076574362424','test'),('2019-07-04 23:59:59','2019-07-05 03:59:59','THETAETH','4h','0.000411150000000','0.000401410000000','0.077465606946280','0.075630473754849','188.41203197441325','188.412031974413253','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','THETAETH','4h','0.000410170000000','0.000399890000000','0.077465606946280','0.075524103571075','188.86219603159665','188.862196031596653','test'),('2019-07-06 23:59:59','2019-07-07 15:59:59','THETAETH','4h','0.000413470000000','0.000411970000000','0.077465606946280','0.077184574681740','187.35484302677344','187.354843026773437','test'),('2019-07-10 15:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000405870000000','0.000393520000000','0.077465606946280','0.075108447644566','190.86310135333974','190.863101353339744','test'),('2019-07-12 15:59:59','2019-07-20 03:59:59','THETAETH','4h','0.000407000000000','0.000534010000000','0.077465606946280','0.101639824976371','190.33318660019657','190.333186600196569','test'),('2019-08-10 19:59:59','2019-08-11 03:59:59','THETAETH','4h','0.000558450000000','0.000558500000000','0.077465606946280','0.077472542715547','138.71538534565315','138.715385345653146','test'),('2019-08-11 15:59:59','2019-08-11 19:59:59','THETAETH','4h','0.000567510000000','0.000560310000000','0.077465606946280','0.076482800704957','136.50086685041674','136.500866850416742','test'),('2019-08-12 03:59:59','2019-08-13 11:59:59','THETAETH','4h','0.000584130000000','0.000572330000000','0.077465606946280','0.075900725563769','132.61706631448482','132.617066314484816','test'),('2019-08-14 19:59:59','2019-08-14 23:59:59','THETAETH','4h','0.000587410000000','0.000575650000000','0.077465606946280','0.075914738664010','131.87655461480057','131.876554614800568','test'),('2019-08-29 11:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000658320000000','0.000646440000000','0.077465606946280','0.076067667630261','117.67165959758174','117.671659597581737','test'),('2019-09-01 07:59:59','2019-09-01 11:59:59','THETAETH','4h','0.000656700000000','0.000664220000000','0.077465606946280','0.078352680745939','117.96194144400793','117.961941444007934','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','THETAETH','4h','0.000663670000000','0.000644730000000','0.077465606946280','0.075254871798447','116.72308066701825','116.723080667018252','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','THETAETH','4h','0.000649300000000','0.000638850000000','0.077465606946280','0.076218855687095','119.30634059183737','119.306340591837369','test'),('2019-09-05 11:59:59','2019-09-06 07:59:59','THETAETH','4h','0.000656210000000','0.000643900000000','0.077465606946280','0.076012411137760','118.05002506252573','118.050025062525734','test'),('2019-09-07 03:59:59','2019-09-07 07:59:59','THETAETH','4h','0.000650230000000','0.000638750000000','0.077465606946280','0.076097929097298','119.13570113079987','119.135701130799873','test'),('2019-10-06 03:59:59','2019-10-06 07:59:59','THETAETH','4h','0.000496230000000','0.000484490000000','0.077465606946280','0.075632895853542','156.10827025024687','156.108270250246875','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000494630000000','0.000460740000000','0.077465606946280','0.072157984239591','156.61324009113883','156.613240091138834','test'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETAETH','4h','0.000484660000000','0.000473120000000','0.077465606946280','0.075621111621392','159.8349501635786','159.834950163578611','test'),('2019-10-15 03:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000486730000000','0.000477830000000','0.077465606946280','0.076049125731188','159.1551927070039','159.155192707003891','test'),('2019-10-16 19:59:59','2019-10-16 23:59:59','THETAETH','4h','0.000485140000000','0.000479990000000','0.077465606946280','0.076643271381756','159.6768086455044','159.676808645504394','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','THETAETH','4h','0.000483560000000','0.000478020000000','0.077465606946280','0.076578107023866','160.19854195193977','160.198541951939774','test'),('2019-10-26 19:59:59','2019-10-26 23:59:59','THETAETH','4h','0.000523300000000','0.000518110000000','0.077465606946280','0.076697316290726','148.03288160955478','148.032881609554778','test'),('2019-10-27 03:59:59','2019-10-27 11:59:59','THETAETH','4h','0.000527950000000','0.000521190000000','0.077465606946280','0.076473718504274','146.729059468283','146.729059468282998','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:09:57
