-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-31 19:59:59','2018-03-31 23:59:59','SUBBTC','4h','0.000051060000000','0.000050050000000','0.001467500000000','0.001438471895809','28.74069721895809','28.740697218958090','test'),('2018-04-03 07:59:59','2018-04-03 11:59:59','SUBBTC','4h','0.000050740000000','0.000050030000000','0.001467500000000','0.001446965411904','28.921955065037448','28.921955065037448','test'),('2018-04-04 23:59:59','2018-04-13 23:59:59','SUBBTC','4h','0.000049910000000','0.000064820000000','0.001467500000000','0.001905897615708','29.40292526547786','29.402925265477862','test'),('2018-04-26 03:59:59','2018-05-03 19:59:59','SUBBTC','4h','0.000078970000000','0.000086990000000','0.001564708730855','0.001723616721503','19.813963921175763','19.813963921175763','test'),('2018-06-02 03:59:59','2018-06-02 07:59:59','SUBBTC','4h','0.000057260000000','0.000059090000000','0.001604435728517','0.001655712665003','28.020183872114043','28.020183872114043','test'),('2018-07-02 15:59:59','2018-07-03 11:59:59','SUBBTC','4h','0.000036240000000','0.000034910000000','0.001617254962639','0.001557902062520','44.626240690914734','44.626240690914734','test'),('2018-07-04 11:59:59','2018-07-06 07:59:59','SUBBTC','4h','0.000035480000000','0.000034450000000','0.001617254962639','0.001570305339992','45.58215790978016','45.582157909780157','test'),('2018-07-07 07:59:59','2018-07-07 11:59:59','SUBBTC','4h','0.000035250000000','0.000034750000000','0.001617254962639','0.001594315175935','45.87957340819858','45.879573408198581','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','SUBBTC','4h','0.000035530000000','0.000034540000000','0.001617254962639','0.001572192130863','45.5180118952716','45.518011895271599','test'),('2018-07-08 15:59:59','2018-07-08 19:59:59','SUBBTC','4h','0.000035390000000','0.000035690000000','0.001617254962639','0.001630964385888','45.69807749756994','45.698077497569940','test'),('2018-07-16 11:59:59','2018-07-20 07:59:59','SUBBTC','4h','0.000034950000000','0.000034570000000','0.001617254962639','0.001599671074633','46.27338948895565','46.273389488955651','test'),('2018-08-17 19:59:59','2018-08-18 07:59:59','SUBBTC','4h','0.000020560000000','0.000020030000000','0.001617254962639','0.001575565024400','78.66026082874514','78.660260828745137','test'),('2018-08-21 19:59:59','2018-08-21 23:59:59','SUBBTC','4h','0.000019850000000','0.000019600000000','0.001617254962639','0.001596886512228','81.4738016442821','81.473801644282105','test'),('2018-08-23 15:59:59','2018-08-27 11:59:59','SUBBTC','4h','0.000020540000000','0.000028270000000','0.001617254962639','0.002225890837089','78.73685309829601','78.736853098296010','test'),('2018-08-31 07:59:59','2018-08-31 11:59:59','SUBBTC','4h','0.000024140000000','0.000023390000000','0.001709354432588','0.001656246900507','70.8100427749793','70.810042774979294','test'),('2018-09-15 03:59:59','2018-09-15 07:59:59','SUBBTC','4h','0.000017750000000','0.000017540000000','0.001709354432588','0.001689131084371','96.30165817397183','96.301658173971830','test'),('2018-09-16 03:59:59','2018-09-16 07:59:59','SUBBTC','4h','0.000018130000000','0.000017420000000','0.001709354432588','0.001642413359938','94.2832009149476','94.283200914947599','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','SUBBTC','4h','0.000017790000000','0.000017920000000','0.001709354432588','0.001721845499268','96.08512830736369','96.085128307363689','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','SUBBTC','4h','0.000017870000000','0.000017600000000','0.001709354432588','0.001683527588895','95.65497664174595','95.654976641745947','test'),('2018-09-21 19:59:59','2018-09-21 23:59:59','SUBBTC','4h','0.000017790000000','0.000017490000000','0.001709354432588','0.001680528894096','96.08512830736369','96.085128307363689','test'),('2018-09-24 03:59:59','2018-09-24 07:59:59','SUBBTC','4h','0.000017740000000','0.000017430000000','0.001709354432588','0.001679484090192','96.35594321240136','96.355943212401357','test'),('2018-09-24 15:59:59','2018-09-24 19:59:59','SUBBTC','4h','0.000018490000000','0.000018250000000','0.001709354432588','0.001687167030543','92.44750852287723','92.447508522877229','test'),('2018-09-25 19:59:59','2018-09-25 23:59:59','SUBBTC','4h','0.000017430000000','0.000017520000000','0.001709354432588','0.001718180703324','98.06967484727481','98.069674847274811','test'),('2018-09-26 11:59:59','2018-09-26 15:59:59','SUBBTC','4h','0.000017650000000','0.000017830000000','0.001709354432588','0.001726786942382','96.84727663388104','96.847276633881037','test'),('2018-10-18 11:59:59','2018-10-18 15:59:59','SUBBTC','4h','0.000017210000000','0.000016740000000','0.001709354432588','0.001662672469583','99.32332554259152','99.323325542591519','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','SUBBTC','4h','0.000017130000000','0.000017810000000','0.001709354432588','0.001777209716544','99.78718228768243','99.787182287682427','test'),('2018-10-23 07:59:59','2018-10-23 11:59:59','SUBBTC','4h','0.000017220000000','0.000017110000000','0.001709354432588','0.001698435211474','99.26564649175377','99.265646491753770','test'),('2018-10-23 19:59:59','2018-10-23 23:59:59','SUBBTC','4h','0.000017200000000','0.000017150000000','0.001709354432588','0.001704385379005','99.38107166209302','99.381071662093021','test'),('2018-10-24 03:59:59','2018-10-24 07:59:59','SUBBTC','4h','0.000017300000000','0.000017320000000','0.001709354432588','0.001711330564880','98.80661460046242','98.806614600462424','test'),('2018-10-28 23:59:59','2018-10-29 03:59:59','SUBBTC','4h','0.000017290000000','0.000017150000000','0.001709354432588','0.001695513506008','98.86376128328514','98.863761283285143','test'),('2018-10-29 07:59:59','2018-10-29 11:59:59','SUBBTC','4h','0.000017250000000','0.000016920000000','0.001709354432588','0.001676653739095','99.09301058481161','99.093010584811609','test'),('2018-10-30 19:59:59','2018-10-31 15:59:59','SUBBTC','4h','0.000017330000000','0.000017510000000','0.001709354432588','0.001727108835235','98.63557025897289','98.635570258972891','test'),('2018-11-03 19:59:59','2018-11-03 23:59:59','SUBBTC','4h','0.000017630000000','0.000017820000000','0.001709354432588','0.001727776289774','96.95714308496882','96.957143084968820','test'),('2018-11-05 07:59:59','2018-11-05 11:59:59','SUBBTC','4h','0.000017550000000','0.000017390000000','0.001709354432588','0.001693770574513','97.39911296797722','97.399112967977217','test'),('2018-11-08 19:59:59','2018-11-08 23:59:59','SUBBTC','4h','0.000017700000000','0.000017460000000','0.001709354432588','0.001686176745366','96.57369675638418','96.573696756384180','test'),('2018-11-12 15:59:59','2018-11-12 19:59:59','SUBBTC','4h','0.000017370000000','0.000017180000000','0.001709354432588','0.001690656830850','98.40843020080598','98.408430200805981','test'),('2018-11-28 23:59:59','2018-11-29 03:59:59','SUBBTC','4h','0.000012210000000','0.000011770000000','0.001709354432588','0.001647756074657','139.99626802522522','139.996268025225220','test'),('2018-11-29 15:59:59','2018-11-29 23:59:59','SUBBTC','4h','0.000012260000000','0.000012400000000','0.001709354432588','0.001728873977495','139.42532076574227','139.425320765742271','test'),('2018-12-01 11:59:59','2018-12-03 07:59:59','SUBBTC','4h','0.000012450000000','0.000012380000000','0.001709354432588','0.001699743604453','137.29754478618474','137.297544786184744','test'),('2018-12-04 23:59:59','2018-12-05 03:59:59','SUBBTC','4h','0.000012270000000','0.000012060000000','0.001709354432588','0.001680098977752','139.31168969747353','139.311689697473525','test'),('2018-12-05 15:59:59','2018-12-05 19:59:59','SUBBTC','4h','0.000012250000000','0.000012090000000','0.001709354432588','0.001687028170611','139.53913735412246','139.539137354122460','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','SUBBTC','4h','0.000012390000000','0.000012200000000','0.001709354432588','0.001683141572040','137.96242393769168','137.962423937691682','test'),('2018-12-15 19:59:59','2018-12-15 23:59:59','SUBBTC','4h','0.000012850000000','0.000012720000000','0.001709354432588','0.001692061352725','133.02369125198445','133.023691251984445','test'),('2018-12-19 11:59:59','2018-12-19 23:59:59','SUBBTC','4h','0.000012550000000','0.000012060000000','0.001709354432588','0.001642614697770','136.20354044525897','136.203540445258966','test'),('2018-12-20 23:59:59','2018-12-21 07:59:59','SUBBTC','4h','0.000012410000000','0.000012200000000','0.001709354432588','0.001680429015115','137.7400832061241','137.740083206124098','test'),('2018-12-22 03:59:59','2018-12-25 03:59:59','SUBBTC','4h','0.000012430000000','0.000012450000000','0.001709354432588','0.001712104801747','137.5184579716814','137.518457971681414','test'),('2018-12-25 23:59:59','2018-12-26 11:59:59','SUBBTC','4h','0.000012850000000','0.000012560000000','0.001709354432588','0.001670777562125','133.02369125198445','133.023691251984445','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','SUBBTC','4h','0.000012800000000','0.000012670000000','0.001709354432588','0.001691993801632','133.5433150459375','133.543315045937504','test'),('2019-01-01 19:59:59','2019-01-01 23:59:59','SUBBTC','4h','0.000013150000000','0.000012960000000','0.001709354432588','0.001684656535843','129.9889302348289','129.988930234828899','test'),('2019-01-02 19:59:59','2019-01-03 07:59:59','SUBBTC','4h','0.000013230000000','0.000013050000000','0.001709354432588','0.001686097909696','129.2029049575208','129.202904957520786','test'),('2019-01-03 19:59:59','2019-01-03 23:59:59','SUBBTC','4h','0.000013110000000','0.000012930000000','0.001709354432588','0.001685885035344','130.38554024317315','130.385540243173153','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','SUBBTC','4h','0.000013040000000','0.000012940000000','0.001709354432588','0.001696245886326','131.08546262177913','131.085462621779129','test'),('2019-01-06 11:59:59','2019-01-08 03:59:59','SUBBTC','4h','0.000013080000000','0.000013180000000','0.001709354432588','0.001722422891553','130.68458964740063','130.684589647400628','test'),('2019-01-08 23:59:59','2019-01-09 03:59:59','SUBBTC','4h','0.000013120000000','0.000013060000000','0.001709354432588','0.001701537262927','130.28616102042685','130.286161020426846','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','SUBBTC','4h','0.000012740000000','0.000012530000000','0.001709354432588','0.001681178260622','134.17224745588697','134.172247455886975','test'),('2019-01-21 07:59:59','2019-01-21 11:59:59','SUBBTC','4h','0.000012690000000','0.000012690000000','0.001709354432588','0.001709354432588','134.70090091315998','134.700900913159984','test'),('2019-01-21 23:59:59','2019-01-22 07:59:59','SUBBTC','4h','0.000012920000000','0.000012650000000','0.001709354432588','0.001673632629430','132.30297465851393','132.302974658513932','test'),('2019-01-22 23:59:59','2019-01-23 03:59:59','SUBBTC','4h','0.000012690000000','0.000012830000000','0.001709354432588','0.001728212558716','134.70090091315998','134.700900913159984','test'),('2019-02-01 19:59:59','2019-02-02 15:59:59','SUBBTC','4h','0.000012700000000','0.000012230000000','0.001709354432588','0.001646094859099','134.59483721165356','134.594837211653555','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','SUBBTC','4h','0.000012550000000','0.000012310000000','0.001709354432588','0.001676665582881','136.20354044525897','136.203540445258966','test'),('2019-02-09 11:59:59','2019-02-09 15:59:59','SUBBTC','4h','0.000012330000000','0.000012050000000','0.001709354432588','0.001670536975887','138.6337739325223','138.633773932522303','test'),('2019-02-10 19:59:59','2019-02-10 23:59:59','SUBBTC','4h','0.000012100000000','0.000012290000000','0.001709354432588','0.001736195535248','141.2689613709091','141.268961370909096','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','SUBBTC','4h','0.000012120000000','0.000012120000000','0.001709354432588','0.001709354432588','141.0358442729373','141.035844272937311','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','SUBBTC','4h','0.000012160000000','0.000012100000000','0.001709354432588','0.001700920117954','140.57191057467105','140.571910574671051','test'),('2019-02-12 19:59:59','2019-02-12 23:59:59','SUBBTC','4h','0.000012120000000','0.000012040000000','0.001709354432588','0.001698071565046','141.0358442729373','141.035844272937311','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:30:10
