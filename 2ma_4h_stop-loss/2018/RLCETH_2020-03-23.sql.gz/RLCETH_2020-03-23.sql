-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-03 11:59:59','RLCETH','4h','0.001714000000000','0.001692000000000','0.072144500000000','0.071218491248541','42.091306884480744','42.091306884480744','test'),('2018-07-04 15:59:59','2018-07-05 15:59:59','RLCETH','4h','0.001744000000000','0.001718000000000','0.072144500000000','0.071068951261468','41.367259174311926','41.367259174311926','test'),('2018-07-07 07:59:59','2018-07-07 19:59:59','RLCETH','4h','0.001739000000000','0.001716000000000','0.072144500000000','0.071190317423807','41.486198964922366','41.486198964922366','test'),('2018-07-09 11:59:59','2018-07-09 15:59:59','RLCETH','4h','0.001694000000000','0.001705000000000','0.072144500000000','0.072612970779221','42.58825265643448','42.588252656434477','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','RLCETH','4h','0.001637000000000','0.001614000000000','0.072144500000000','0.071130863164325','44.071166768478925','44.071166768478925','test'),('2018-07-18 03:59:59','2018-07-18 07:59:59','RLCETH','4h','0.001684000000000','0.001667000000000','0.072144500000000','0.071416200415677','42.84115201900238','42.841152019002379','test'),('2018-07-30 23:59:59','2018-07-31 03:59:59','RLCETH','4h','0.001458000000000','0.001464000000000','0.072144500000000','0.072441390946502','49.4818244170096','49.481824417009598','test'),('2018-08-13 07:59:59','2018-08-13 19:59:59','RLCETH','4h','0.001152000000000','0.001114000000000','0.072144500000000','0.069764733506944','62.62543402777778','62.625434027777779','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','RLCETH','4h','0.001147000000000','0.001088000000000','0.072144500000000','0.068433492589364','62.898430688753265','62.898430688753265','test'),('2018-08-17 15:59:59','2018-08-17 19:59:59','RLCETH','4h','0.001166000000000','0.001153000000000','0.072144500000000','0.071340144511149','61.87349914236707','61.873499142367073','test'),('2018-08-19 15:59:59','2018-08-25 15:59:59','RLCETH','4h','0.001138000000000','0.001666000000000','0.072144500000000','0.105617519332162','63.395869947275926','63.395869947275926','test'),('2018-08-30 19:59:59','2018-08-30 23:59:59','RLCETH','4h','0.001437000000000','0.001457000000000','0.077805893794790','0.078888787236610','54.144672091016005','54.144672091016005','test'),('2018-09-03 15:59:59','2018-09-03 19:59:59','RLCETH','4h','0.001469000000000','0.001438000000000','0.078076617155245','0.076428982620315','53.14950112678353','53.149501126783527','test'),('2018-09-05 19:59:59','2018-09-06 03:59:59','RLCETH','4h','0.001534000000000','0.001465000000000','0.078076617155245','0.074564696305368','50.89740362141134','50.897403621411343','test'),('2018-09-14 07:59:59','2018-09-14 11:59:59','RLCETH','4h','0.001689000000000','0.001680000000000','0.078076617155245','0.077660578342695','46.22653472779455','46.226534727794551','test'),('2018-09-17 15:59:59','2018-09-17 19:59:59','RLCETH','4h','0.001671000000000','0.001826000000000','0.078076617155245','0.085318912582572','46.72448662791442','46.724486627914423','test'),('2018-09-25 11:59:59','2018-09-25 15:59:59','RLCETH','4h','0.001692000000000','0.001678000000000','0.078493292462738','0.077843820775694','46.390834788851954','46.390834788851954','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','RLCETH','4h','0.001667000000000','0.001694000000000','0.078493292462738','0.079764629533220','47.0865581660096','47.086558166009603','test'),('2018-09-30 03:59:59','2018-09-30 11:59:59','RLCETH','4h','0.001694000000000','0.001689000000000','0.078648758808597','0.078416619614947','46.427838729986426','46.427838729986426','test'),('2018-10-06 19:59:59','2018-10-08 03:59:59','RLCETH','4h','0.001785000000000','0.001752000000000','0.078648758808597','0.077194748141547','44.06092930453613','44.060929304536131','test'),('2018-10-28 19:59:59','2018-10-28 23:59:59','RLCETH','4h','0.002291000000000','0.002274000000000','0.078648758808597','0.078065158241270','34.32944513688214','34.329445136882143','test'),('2018-11-01 07:59:59','2018-11-03 07:59:59','RLCETH','4h','0.002315000000000','0.002245000000000','0.078648758808597','0.076270610594082','33.973545921640174','33.973545921640174','test'),('2018-11-03 11:59:59','2018-11-03 15:59:59','RLCETH','4h','0.002312000000000','0.002232000000000','0.078648758808597','0.075927348469199','34.01762924247275','34.017629242472751','test'),('2018-11-16 07:59:59','2018-11-16 11:59:59','RLCETH','4h','0.002073000000000','0.002093000000000','0.078648758808597','0.079407550499949','37.93958456758176','37.939584567581761','test'),('2018-11-17 15:59:59','2018-11-17 19:59:59','RLCETH','4h','0.002034000000000','0.002003000000000','0.078648758808597','0.077450080577001','38.66703972890708','38.667039728907078','test'),('2018-11-21 07:59:59','2018-11-21 15:59:59','RLCETH','4h','0.002066000000000','0.002043000000000','0.078648758808597','0.077773191793787','38.06813107870135','38.068131078701349','test'),('2018-11-27 07:59:59','2018-11-28 19:59:59','RLCETH','4h','0.001994000000000','0.002142000000000','0.078648758808597','0.084486279522575','39.44270752687913','39.442707526879133','test'),('2018-12-01 07:59:59','2018-12-01 15:59:59','RLCETH','4h','0.002028000000000','0.002030000000000','0.078648758808597','0.078726321687106','38.78143925473225','38.781439254732248','test'),('2018-12-05 03:59:59','2018-12-05 07:59:59','RLCETH','4h','0.002044000000000','0.002001000000000','0.078648758808597','0.076994210555774','38.477866344714776','38.477866344714776','test'),('2018-12-06 11:59:59','2018-12-06 15:59:59','RLCETH','4h','0.002043000000000','0.001981000000000','0.078648758808597','0.076261963387093','38.49670034684141','38.496700346841408','test'),('2018-12-06 23:59:59','2018-12-07 03:59:59','RLCETH','4h','0.002017000000000','0.002059000000000','0.078648758808597','0.080286462264205','38.992939419235','38.992939419235000','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','RLCETH','4h','0.002021000000000','0.001969000000000','0.078648758808597','0.076625139086654','38.91576388352153','38.915763883521528','test'),('2018-12-13 07:59:59','2018-12-13 23:59:59','RLCETH','4h','0.001993000000000','0.001953000000000','0.078648758808597','0.077070258882684','39.46249814781585','39.462498147815850','test'),('2019-01-07 11:59:59','2019-01-07 15:59:59','RLCETH','4h','0.001391000000000','0.001396000000000','0.078648758808597','0.078931464627463','56.54116377325448','56.541163773254482','test'),('2019-01-09 07:59:59','2019-01-09 11:59:59','RLCETH','4h','0.001387000000000','0.001406000000000','0.078648758808597','0.079726139066249','56.70422408694809','56.704224086948088','test'),('2019-02-22 23:59:59','2019-02-23 03:59:59','RLCETH','4h','0.001989000000000','0.002034000000000','0.078648758808597','0.080428142492049','39.541859632276015','39.541859632276015','test'),('2019-02-24 23:59:59','2019-02-25 03:59:59','RLCETH','4h','0.002047000000000','0.001988000000000','0.078648758808597','0.076381891798481','38.42147474772691','38.421474747726911','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','RLCETH','4h','0.002423000000000','0.002391000000000','0.078648758808597','0.077610062860650','32.4592483733376','32.459248373337601','test'),('2019-03-12 15:59:59','2019-03-12 23:59:59','RLCETH','4h','0.002598000000000','0.003271000000000','0.078648758808597','0.099022359531532','30.272809395148958','30.272809395148958','test'),('2019-03-22 07:59:59','2019-03-23 19:59:59','RLCETH','4h','0.002933000000000','0.002877000000000','0.081506775987037','0.079950560693728','27.789558809081843','27.789558809081843','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','RLCETH','4h','0.002873000000000','0.002861000000000','0.081506775987037','0.081166336964467','28.36991854752419','28.369918547524190','test'),('2019-03-24 19:59:59','2019-03-24 23:59:59','RLCETH','4h','0.002879000000000','0.002871000000000','0.081506775987037','0.081280289634867','28.310794021200763','28.310794021200763','test'),('2019-03-25 19:59:59','2019-03-30 03:59:59','RLCETH','4h','0.002896000000000','0.002953000000000','0.081506775987037','0.083111018470207','28.144604967899514','28.144604967899514','test'),('2019-03-30 15:59:59','2019-04-03 03:59:59','RLCETH','4h','0.003011000000000','0.002959000000000','0.081506775987037','0.080099153153651','27.069669872812025','27.069669872812025','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','RLCETH','4h','0.003133000000000','0.003123000000000','0.081506775987037','0.081246620302431','26.01556846059272','26.015568460592721','test'),('2019-04-04 11:59:59','2019-04-07 15:59:59','RLCETH','4h','0.003191000000000','0.003243000000000','0.081506775987037','0.082834996717631','25.542706357579757','25.542706357579757','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','RLCETH','4h','0.003174000000000','0.003056000000000','0.081506775987037','0.078476593388905','25.679513543489914','25.679513543489914','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','RLCETH','4h','0.003121000000000','0.003030000000000','0.081506775987037','0.079130256725640','26.115596279089072','26.115596279089072','test'),('2019-04-19 11:59:59','2019-04-19 15:59:59','RLCETH','4h','0.003037000000000','0.003027000000000','0.081506775987037','0.081238396744406','26.837924263100756','26.837924263100756','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','RLCETH','4h','0.003119000000000','0.003020000000000','0.081506775987037','0.078919674088122','26.13234241328535','26.132342413285350','test'),('2019-04-30 19:59:59','2019-04-30 23:59:59','RLCETH','4h','0.003098000000000','0.002946000000000','0.081506775987037','0.077507734686188','26.3094822424264','26.309482242426402','test'),('2019-05-13 07:59:59','2019-05-13 15:59:59','RLCETH','4h','0.003717000000000','0.003589000000000','0.081506775987037','0.078699978212934','21.928107610179445','21.928107610179445','test'),('2019-05-14 19:59:59','2019-05-14 23:59:59','RLCETH','4h','0.003534000000000','0.003403000000000','0.081506775987037','0.078485443883386','23.063603844662424','23.063603844662424','test'),('2019-05-15 15:59:59','2019-05-15 19:59:59','RLCETH','4h','0.003511000000000','0.002993000000000','0.081506775987037','0.069481566655996','23.214689828264596','23.214689828264596','test'),('2019-06-09 03:59:59','2019-06-09 07:59:59','RLCETH','4h','0.001786000000000','0.001784000000000','0.081506775987037','0.081415503001609','45.63649271390649','45.636492713906492','test'),('2019-06-26 19:59:59','2019-06-26 23:59:59','RLCETH','4h','0.001392000000000','0.001268000000000','0.081506775987037','0.074246114907732','58.5537183814921','58.553718381492097','test'),('2019-06-27 15:59:59','2019-06-27 19:59:59','RLCETH','4h','0.001277000000000','0.001257000000000','0.081506775987037','0.080230240732737','63.826762714985904','63.826762714985904','test'),('2019-06-28 19:59:59','2019-06-28 23:59:59','RLCETH','4h','0.001350000000000','0.001243000000000','0.081506775987037','0.075046609297694','60.375389620027406','60.375389620027406','test'),('2019-06-29 07:59:59','2019-06-29 11:59:59','RLCETH','4h','0.001283000000000','0.001274000000000','0.081506775987037','0.080935021517915','63.528274346872166','63.528274346872166','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:52:54
