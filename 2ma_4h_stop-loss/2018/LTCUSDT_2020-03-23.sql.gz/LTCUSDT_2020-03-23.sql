-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 11:59:59','2018-06-02 15:59:59','LTCUSDT','4h','122.900000000000006','122.629999999999995','15.000000000000000','14.967046379170057','0.12205044751830756','0.122050447518308','test'),('2018-06-07 03:59:59','2018-06-07 07:59:59','LTCUSDT','4h','122.230000000000004','122.159999999999997','15.000000000000000','14.991409637568516','0.12271946330688047','0.122719463306880','test'),('2018-07-02 15:59:59','2018-07-03 23:59:59','LTCUSDT','4h','85.569999999999993','85.090000000000003','15.000000000000000','14.915858361575321','0.17529508005141992','0.175295080051420','test'),('2018-07-08 03:59:59','2018-07-08 07:59:59','LTCUSDT','4h','84.090000000000003','83.709999999999994','15.000000000000000','14.932215483410630','0.17838030681412773','0.178380306814128','test'),('2018-07-16 11:59:59','2018-07-17 11:59:59','LTCUSDT','4h','82.640000000000001','81.689999999999998','15.000000000000000','14.827565343659245','0.18151016456921587','0.181510164569216','test'),('2018-07-21 15:59:59','2018-07-21 23:59:59','LTCUSDT','4h','84.420000000000002','83.439999999999998','15.000000000000000','14.825870646766168','0.17768301350390903','0.177683013503909','test'),('2018-07-23 03:59:59','2018-07-23 11:59:59','LTCUSDT','4h','85.060000000000002','84.000000000000000','15.000000000000000','14.813073124853045','0.1763461086292029','0.176346108629203','test'),('2018-07-24 07:59:59','2018-07-25 11:59:59','LTCUSDT','4h','87.310000000000002','85.980000000000004','15.000000000000000','14.771503836902989','0.1718016263887298','0.171801626388730','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','LTCUSDT','4h','58.109999999999999','57.780000000000001','15.000000000000000','14.914816726897264','0.2581311306143521','0.258131130614352','test'),('2018-08-27 19:59:59','2018-08-27 23:59:59','LTCUSDT','4h','58.130000000000003','60.609999999999999','15.000000000000000','15.639944950971961','0.2580423189403062','0.258042318940306','test'),('2018-09-14 19:59:59','2018-09-14 23:59:59','LTCUSDT','4h','58.020000000000003','56.240000000000002','15.000000000000000','14.539813857290589','0.25853154084798347','0.258531540847983','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','LTCUSDT','4h','56.450000000000003','56.310000000000002','15.000000000000000','14.962798937112488','0.2657218777679362','0.265721877767936','test'),('2018-09-20 23:59:59','2018-09-24 11:59:59','LTCUSDT','4h','56.530000000000001','57.369999999999997','15.000000000000000','15.222890500619140','0.2653458340704051','0.265345834070405','test'),('2018-09-26 07:59:59','2018-09-26 11:59:59','LTCUSDT','4h','57.390000000000001','57.590000000000003','15.000000000000000','15.052273915316256','0.26136957658128596','0.261369576581286','test'),('2018-10-08 15:59:59','2018-10-09 15:59:59','LTCUSDT','4h','59.399999999999999','58.780000000000001','15.000000000000000','14.843434343434344','0.25252525252525254','0.252525252525253','test'),('2018-10-09 23:59:59','2018-10-10 03:59:59','LTCUSDT','4h','59.030000000000001','58.000000000000000','15.000000000000000','14.738268676943926','0.2541080806369643','0.254108080636964','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','LTCUSDT','4h','57.359999999999999','56.530000000000001','15.000000000000000','14.782949790794980','0.2615062761506276','0.261506276150628','test'),('2018-10-16 07:59:59','2018-10-16 15:59:59','LTCUSDT','4h','57.000000000000000','55.859999999999999','15.000000000000000','14.699999999999999','0.2631578947368421','0.263157894736842','test'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCUSDT','4h','51.950000000000003','51.780000000000001','15.000000000000000','14.950914340712222','0.28873917228103946','0.288739172281039','test'),('2018-11-04 07:59:59','2018-11-08 23:59:59','LTCUSDT','4h','51.859999999999999','52.719999999999999','15.000000000000000','15.248746625530273','0.28924026224450444','0.289240262244504','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LTCUSDT','4h','35.649999999999999','34.740000000000002','15.000000000000000','14.617110799438992','0.420757363253857','0.420757363253857','test'),('2018-12-01 19:59:59','2018-12-01 23:59:59','LTCUSDT','4h','34.890000000000001','34.170000000000002','15.000000000000000','14.690455717970766','0.42992261392949266','0.429922613929493','test'),('2018-12-16 11:59:59','2018-12-16 15:59:59','LTCUSDT','4h','26.230000000000000','26.079999999999998','15.000000000000000','14.914220358368279','0.5718642775447961','0.571864277544796','test'),('2018-12-17 03:59:59','2018-12-24 19:59:59','LTCUSDT','4h','25.899999999999999','33.030000000000001','15.000000000000000','19.129343629343630','0.5791505791505792','0.579150579150579','test'),('2018-12-25 19:59:59','2018-12-25 23:59:59','LTCUSDT','4h','30.199999999999999','30.500000000000000','15.498131496162770','15.652086444800148','0.513183162124595','0.513183162124595','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','LTCUSDT','4h','30.300000000000001','29.370000000000001','15.536620233322115','15.059753671705296','0.5127597436739971','0.512759743673997','test'),('2018-12-28 15:59:59','2018-12-29 23:59:59','LTCUSDT','4h','30.920000000000002','30.280000000000001','15.536620233322115','15.215034303525020','0.5024780153079597','0.502478015307960','test'),('2019-01-01 11:59:59','2019-01-01 15:59:59','LTCUSDT','4h','30.410000000000000','30.190000000000001','15.536620233322115','15.424221139230340','0.51090497314443','0.510904973144430','test'),('2019-01-01 19:59:59','2019-01-03 19:59:59','LTCUSDT','4h','30.480000000000000','30.850000000000001','15.536620233322115','15.725220938254177','0.509731634951513','0.509731634951513','test'),('2019-01-19 19:59:59','2019-01-19 23:59:59','LTCUSDT','4h','32.350000000000001','32.000000000000000','15.536620233322115','15.368526969592200','0.48026646779975624','0.480266467799756','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','LTCUSDT','4h','32.020000000000003','31.559999999999999','15.536620233322115','15.313420817103244','0.4852161222149317','0.485216122214932','test'),('2019-01-23 23:59:59','2019-01-24 03:59:59','LTCUSDT','4h','31.690000000000001','31.129999999999999','15.536620233322115','15.262069670663220','0.490268861890884','0.490268861890884','test'),('2019-01-24 15:59:59','2019-01-27 15:59:59','LTCUSDT','4h','31.980000000000000','32.340000000000003','15.536620233322115','15.711516521126867','0.485823021679866','0.485823021679866','test'),('2019-01-30 23:59:59','2019-01-31 11:59:59','LTCUSDT','4h','31.680000000000000','31.370000000000001','15.536620233322115','15.384588911594532','0.49042361847607685','0.490423618476077','test'),('2019-02-01 11:59:59','2019-02-06 03:59:59','LTCUSDT','4h','32.119999999999997','32.789999999999999','15.536620233322115','15.860702909421923','0.4837054867161306','0.483705486716131','test'),('2019-02-06 15:59:59','2019-02-06 19:59:59','LTCUSDT','4h','32.920000000000002','32.649999999999999','15.536620233322115','15.409193518164248','0.4719507968809877','0.471950796880988','test'),('2019-02-07 03:59:59','2019-02-08 03:59:59','LTCUSDT','4h','33.189999999999998','33.299999999999997','15.536620233322115','15.588112496825142','0.4681114863911454','0.468111486391145','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','LTCUSDT','4h','46.009999999999998','45.859999999999999','15.536620233322115','15.485968352535366','0.33767920524499273','0.337679205244993','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','LTCUSDT','4h','46.009999999999998','46.920000000000002','15.536620233322115','15.843908310095062','0.33767920524499273','0.337679205244993','test'),('2019-03-05 11:59:59','2019-03-14 15:59:59','LTCUSDT','4h','47.060000000000002','55.939999999999998','15.536620233322115','18.468307179176350','0.33014492633493653','0.330144926334937','test'),('2019-03-27 03:59:59','2019-03-30 19:59:59','LTCUSDT','4h','60.030000000000001','60.259999999999998','16.054430785617431','16.115942014681099','0.2674401263637753','0.267440126363775','test'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCUSDT','4h','83.280000000000001','80.340000000000003','16.069808592883348','15.502502669935737','0.19296119828150032','0.192961198281500','test'),('2019-04-16 23:59:59','2019-04-17 03:59:59','LTCUSDT','4h','80.269999999999996','80.140000000000001','16.069808592883348','16.043782990328534','0.20019694272933036','0.200196942729330','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','LTCUSDT','4h','80.620000000000005','79.799999999999997','16.069808592883348','15.906359783082252','0.19932781683060466','0.199327816830605','test'),('2019-05-02 07:59:59','2019-05-02 11:59:59','LTCUSDT','4h','74.010000000000005','73.700000000000003','16.069808592883348','16.002498220449976','0.21713023365603765','0.217130233656038','test'),('2019-05-03 03:59:59','2019-05-04 15:59:59','LTCUSDT','4h','74.750000000000000','75.950000000000003','16.069808592883348','16.327785453237329','0.21498071696165014','0.214980716961650','test'),('2019-05-06 19:59:59','2019-05-06 23:59:59','LTCUSDT','4h','76.010000000000005','74.939999999999998','16.069808592883348','15.843592368776186','0.21141703187584984','0.211417031875850','test'),('2019-05-09 03:59:59','2019-05-09 07:59:59','LTCUSDT','4h','75.299999999999997','74.280000000000001','16.069808592883348','15.852129910748674','0.21341047268105376','0.213410472681054','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','LTCUSDT','4h','77.000000000000000','76.180000000000007','16.069808592883348','15.898675566309786','0.20869881289458894','0.208698812894589','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','LTCUSDT','4h','89.019999999999996','94.090000000000003','16.069808592883348','16.985040333682257','0.18051908102542516','0.180519081025425','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  1:06:51
