-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-31 23:59:59','2018-02-01 11:59:59','ETHUSDT','4h','1124.809999999999945','1116.000000000000000','15.000000000000000','14.882513491167398','0.013335585565562184','0.013335585565562','test'),('2018-02-14 15:59:59','2018-02-18 11:59:59','ETHUSDT','4h','903.059999999999945','929.179999999999950','15.000000000000000','15.433858215400971','0.01661019201381968','0.016610192013820','test'),('2018-02-27 07:59:59','2018-02-27 15:59:59','ETHUSDT','4h','890.889999999999986','873.070000000000050','15.079092926642092','14.777473831183887','0.016925875166004887','0.016925875166005','test'),('2018-03-01 19:59:59','2018-03-01 23:59:59','ETHUSDT','4h','874.000000000000000','870.629999999999995','15.079092926642092','15.020950428744170','0.017252966735288436','0.017252966735288','test'),('2018-03-05 03:59:59','2018-03-05 07:59:59','ETHUSDT','4h','867.080000000000041','867.799999999999955','15.079092926642092','15.091614201388575','0.017390659370118203','0.017390659370118','test'),('2018-04-09 07:59:59','2018-04-09 11:59:59','ETHUSDT','4h','418.810000000000002','395.689999999999998','15.079092926642092','14.246666221300851','0.03600461528292565','0.036004615282926','test'),('2018-04-10 19:59:59','2018-04-25 03:59:59','ETHUSDT','4h','411.550000000000011','654.000000000000000','15.079092926642092','23.962402561107830','0.03663975926774898','0.036639759267749','test'),('2018-05-09 11:59:59','2018-05-10 23:59:59','ETHUSDT','4h','743.960000000000036','722.519999999999982','17.005003579270806','16.514940569512799','0.022857416499906993','0.022857416499907','test'),('2018-05-13 15:59:59','2018-05-14 03:59:59','ETHUSDT','4h','727.009999999999991','696.000000000000000','17.005003579270806','16.279669455953123','0.02339032967809357','0.023390329678094','test'),('2018-05-14 15:59:59','2018-05-15 15:59:59','ETHUSDT','4h','733.250000000000000','717.980000000000018','17.005003579270806','16.650872785332226','0.023191276616803008','0.023191276616803','test'),('2018-05-19 15:59:59','2018-05-19 19:59:59','ETHUSDT','4h','706.919999999999959','703.659999999999968','17.005003579270806','16.926584081069564','0.024055060797927356','0.024055060797927','test'),('2018-05-20 07:59:59','2018-05-20 11:59:59','ETHUSDT','4h','707.590000000000032','712.500000000000000','17.005003579270806','17.123002091932403','0.024032283637799863','0.024032283637800','test'),('2018-06-02 19:59:59','2018-06-02 23:59:59','ETHUSDT','4h','598.460000000000036','590.850000000000023','17.005003579270806','16.788768447034315','0.0284146034476336','0.028414603447634','test'),('2018-06-03 03:59:59','2018-06-03 07:59:59','ETHUSDT','4h','593.659999999999968','606.929999999999950','17.005003579270806','17.385114076014602','0.028644347908349573','0.028644347908350','test'),('2018-06-05 15:59:59','2018-06-06 19:59:59','ETHUSDT','4h','600.120000000000005','598.259999999999991','17.005003579270806','16.952298609169087','0.028336005431031805','0.028336005431032','test'),('2018-06-09 03:59:59','2018-06-09 15:59:59','ETHUSDT','4h','606.129999999999995','602.320000000000050','17.005003579270806','16.898113863142218','0.028055043603304252','0.028055043603304','test'),('2018-06-19 11:59:59','2018-06-20 03:59:59','ETHUSDT','4h','534.000000000000000','519.929999999999950','17.005003579270806','16.556950395075411','0.031844575991143834','0.031844575991144','test'),('2018-07-02 15:59:59','2018-07-03 15:59:59','ETHUSDT','4h','474.430000000000007','468.939999999999998','17.005003579270806','16.808225404091758','0.035843019158296914','0.035843019158297','test'),('2018-07-04 11:59:59','2018-07-04 23:59:59','ETHUSDT','4h','466.490000000000009','467.379999999999995','17.005003579270806','17.037446832471414','0.03645309348382775','0.036453093483828','test'),('2018-07-06 15:59:59','2018-07-07 15:59:59','ETHUSDT','4h','467.930000000000007','467.600000000000023','17.005003579270806','16.993011077868545','0.03634091334018081','0.036340913340181','test'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHUSDT','4h','452.959999999999980','450.189999999999998','17.005003579270806','16.901012366107217','0.03754195421068263','0.037541954210683','test'),('2018-07-16 07:59:59','2018-07-19 19:59:59','ETHUSDT','4h','452.819999999999993','467.850000000000023','17.005003579270806','17.569433603996835','0.0375535611926832','0.037553561192683','test'),('2018-07-21 15:59:59','2018-07-21 19:59:59','ETHUSDT','4h','466.199999999999989','465.980000000000018','17.005003579270806','16.996978910057081','0.036475769153305033','0.036475769153305','test'),('2018-07-22 11:59:59','2018-07-22 15:59:59','ETHUSDT','4h','463.899999999999977','468.610000000000014','17.005003579270806','17.177656234710270','0.03665661474298514','0.036656614742985','test'),('2018-07-23 03:59:59','2018-07-23 11:59:59','ETHUSDT','4h','465.980000000000018','462.699999999999989','17.005003579270806','16.885306571373452','0.03649299021260742','0.036492990212607','test'),('2018-07-24 07:59:59','2018-07-25 15:59:59','ETHUSDT','4h','472.329999999999984','467.800000000000011','17.005003579270806','16.841912803300414','0.03600237880141174','0.036002378801412','test'),('2018-07-27 19:59:59','2018-07-27 23:59:59','ETHUSDT','4h','467.360000000000014','470.089999999999975','17.005003579270806','17.104335271695078','0.03638523532024736','0.036385235320247','test'),('2018-07-28 23:59:59','2018-07-29 03:59:59','ETHUSDT','4h','469.290000000000020','466.569999999999993','17.005003579270806','16.906442753905644','0.0362355975607211','0.036235597560721','test'),('2018-08-28 15:59:59','2018-08-28 19:59:59','ETHUSDT','4h','288.589999999999975','293.139999999999986','17.005003579270806','17.273109772436481','0.05892443805839013','0.058924438058390','test'),('2018-09-01 03:59:59','2018-09-01 07:59:59','ETHUSDT','4h','288.430000000000007','286.540000000000020','17.005003579270806','16.893574612919103','0.05895712505381134','0.058957125053811','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','ETHUSDT','4h','288.769999999999982','289.329999999999984','17.005003579270806','17.037980696022515','0.05888770848519863','0.058887708485199','test'),('2018-09-15 15:59:59','2018-09-15 23:59:59','ETHUSDT','4h','224.039999999999992','221.289999999999992','17.005003579270806','16.796274067384559','0.0759016406859079','0.075901640685908','test'),('2018-09-16 11:59:59','2018-09-16 15:59:59','ETHUSDT','4h','219.370000000000005','217.550000000000011','17.005003579270806','16.863921815518822','0.07751745261098056','0.077517452610981','test'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHUSDT','4h','224.000000000000000','228.060000000000002','17.005003579270806','17.313219269145087','0.0759151945503161','0.075915194550316','test'),('2018-09-27 19:59:59','2018-09-28 11:59:59','ETHUSDT','4h','228.599999999999994','223.930000000000007','17.005003579270806','16.657613523648784','0.07438759221028349','0.074387592210283','test'),('2018-09-29 11:59:59','2018-10-01 07:59:59','ETHUSDT','4h','232.389999999999986','229.650000000000006','17.005003579270806','16.804505667109346','0.07317442049688372','0.073174420496884','test'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHUSDT','4h','228.370000000000005','225.270000000000010','17.005003579270806','16.774169795955398','0.07446251074690549','0.074462510746905','test'),('2018-10-06 23:59:59','2018-10-07 03:59:59','ETHUSDT','4h','225.400000000000006','225.939999999999998','17.005003579270806','17.045743161936318','0.0754436716027986','0.075443671602799','test'),('2018-10-07 23:59:59','2018-10-08 07:59:59','ETHUSDT','4h','226.139999999999986','224.979999999999990','17.005003579270806','16.917775295234570','0.07519679658296102','0.075196796582961','test'),('2018-10-10 19:59:59','2018-10-10 23:59:59','ETHUSDT','4h','226.849999999999994','226.740000000000009','17.005003579270806','16.996757820426993','0.07496144403469608','0.074961444034696','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','ETHUSDT','4h','221.750000000000000','216.699999999999989','17.005003579270806','16.617741941952577','0.07668547273628323','0.076685472736283','test'),('2018-10-15 23:59:59','2018-10-16 03:59:59','ETHUSDT','4h','214.389999999999986','212.349999999999994','17.005003579270806','16.843194692187861','0.07931808190340411','0.079318081903404','test'),('2018-10-16 07:59:59','2018-10-16 11:59:59','ETHUSDT','4h','216.039999999999992','215.370000000000005','17.005003579270806','16.952266343582455','0.07871229207216629','0.078712292072166','test'),('2018-10-17 15:59:59','2018-10-17 19:59:59','ETHUSDT','4h','213.770000000000010','212.580000000000013','17.005003579270806','16.910341305521765','0.07954812920087385','0.079548129200874','test'),('2018-10-18 03:59:59','2018-10-18 07:59:59','ETHUSDT','4h','214.000000000000000','213.050000000000011','17.005003579270806','16.929514077400210','0.07946263354799442','0.079462633547994','test'),('2018-11-04 15:59:59','2018-11-09 23:59:59','ETHUSDT','4h','205.840000000000003','210.770000000000010','17.005003579270806','17.412284319874210','0.0826127262887233','0.082612726288723','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ETHUSDT','4h','95.409999999999997','94.019999999999996','17.005003579270806','16.757262724274614','0.1782308309325103','0.178230830932510','test'),('2018-12-28 11:59:59','2018-12-28 15:59:59','ETHUSDT','4h','117.230000000000004','126.620000000000005','17.005003579270806','18.367086523989332','0.14505675662604117','0.145056756626041','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:10:16
