-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-17 23:59:59','2018-03-31 07:59:59','IOTAETH','4h','0.002078000000000','0.002776210000000','0.072144500000000','0.096385121436477','34.71823869104909','34.718238691049088','test'),('2018-04-12 11:59:59','2018-04-12 15:59:59','IOTAETH','4h','0.002582500000000','0.002629080000000','0.078204655359119','0.079615215996729','30.282538377200094','30.282538377200094','test'),('2018-04-26 23:59:59','2018-04-27 03:59:59','IOTAETH','4h','0.003094190000000','0.003026510000000','0.078557295518522','0.076838991936423','25.38864630760288','25.388646307602880','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','IOTAETH','4h','0.003100000000000','0.003021340000000','0.078557295518522','0.076563967497397','25.341063070490968','25.341063070490968','test'),('2018-05-02 11:59:59','2018-05-04 11:59:59','IOTAETH','4h','0.003004830000000','0.002987910000000','0.078557295518522','0.078114944556846','26.1436738579294','26.143673857929400','test'),('2018-05-04 19:59:59','2018-05-04 23:59:59','IOTAETH','4h','0.003099360000000','0.003125090000000','0.078557295518522','0.079209455710849','25.346295854151183','25.346295854151183','test'),('2018-05-08 07:59:59','2018-05-09 23:59:59','IOTAETH','4h','0.003060780000000','0.003026630000000','0.078557295518522','0.077680809249676','25.665776540137482','25.665776540137482','test'),('2018-05-28 07:59:59','2018-05-28 11:59:59','IOTAETH','4h','0.002652170000000','0.002618430000000','0.078557295518522','0.077557916462581','29.62000758568342','29.620007585683421','test'),('2018-06-04 11:59:59','2018-06-04 23:59:59','IOTAETH','4h','0.002901120000000','0.002909340000000','0.078557295518522','0.078779878855014','27.07826477998911','27.078264779989109','test'),('2018-06-05 11:59:59','2018-06-05 15:59:59','IOTAETH','4h','0.002910880000000','0.002872330000000','0.078557295518522','0.077516928432885','26.987473038573217','26.987473038573217','test'),('2018-06-05 19:59:59','2018-06-05 23:59:59','IOTAETH','4h','0.002906580000000','0.002860050000000','0.078557295518522','0.077299710672938','27.027398357699425','27.027398357699425','test'),('2018-07-01 07:59:59','2018-07-06 07:59:59','IOTAETH','4h','0.002281540000000','0.002410690000000','0.078557295518522','0.083004149273537','34.43169767723643','34.431697677236428','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','IOTAETH','4h','0.002267500000000','0.002238940000000','0.078557295518522','0.077567837366368','34.64489328269989','34.644893282699890','test'),('2018-07-16 23:59:59','2018-07-17 07:59:59','IOTAETH','4h','0.002278610000000','0.002272980000000','0.078557295518522','0.078363195793791','34.47597242113482','34.475972421134820','test'),('2018-07-19 11:59:59','2018-07-19 15:59:59','IOTAETH','4h','0.002271620000000','0.002215340000000','0.078557295518522','0.076611017271376','34.582058407005576','34.582058407005576','test'),('2018-07-26 11:59:59','2018-07-26 15:59:59','IOTAETH','4h','0.002175830000000','0.002178110000000','0.078557295518522','0.078639613821782','36.10451897368912','36.104518973689117','test'),('2018-07-28 03:59:59','2018-07-28 11:59:59','IOTAETH','4h','0.002182900000000','0.002162270000000','0.078557295518522','0.077814871675677','35.9875832692849','35.987583269284897','test'),('2018-07-28 23:59:59','2018-07-29 23:59:59','IOTAETH','4h','0.002195000000000','0.002165670000000','0.078557295518522','0.077507598262231','35.78920069180957','35.789200691809569','test'),('2018-07-31 11:59:59','2018-07-31 15:59:59','IOTAETH','4h','0.002187090000000','0.002189000000000','0.078557295518522','0.078625900118443','35.91863870189247','35.918638701892469','test'),('2018-08-03 15:59:59','2018-08-04 03:59:59','IOTAETH','4h','0.002230000000000','0.002199760000000','0.078557295518522','0.077492016318307','35.227486779606274','35.227486779606274','test'),('2018-08-05 07:59:59','2018-08-05 15:59:59','IOTAETH','4h','0.002250000000000','0.002223920000000','0.078557295518522','0.077646729177578','34.91435356378756','34.914353563787557','test'),('2018-08-06 15:59:59','2018-08-06 19:59:59','IOTAETH','4h','0.002196050000000','0.002148000000000','0.078557295518522','0.076838446653667','35.77208875869037','35.772088758690373','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','IOTAETH','4h','0.001776320000000','0.001761330000000','0.078557295518522','0.077894366620676','44.224743018443746','44.224743018443746','test'),('2018-08-19 11:59:59','2018-08-19 23:59:59','IOTAETH','4h','0.001815400000000','0.001794800000000','0.078557295518522','0.077665877490715','43.27271979647571','43.272719796475712','test'),('2018-09-17 23:59:59','2018-09-18 03:59:59','IOTAETH','4h','0.002728720000000','0.002701000000000','0.078557295518522','0.077759262656311','28.789064293339734','28.789064293339734','test'),('2018-09-25 19:59:59','2018-09-26 19:59:59','IOTAETH','4h','0.002604960000000','0.002569020000000','0.078557295518522','0.077473459605135','30.156814507140993','30.156814507140993','test'),('2018-09-27 15:59:59','2018-09-27 19:59:59','IOTAETH','4h','0.002611000000000','0.002575290000000','0.078557295518522','0.077482886854038','30.087053051904252','30.087053051904252','test'),('2018-09-28 23:59:59','2018-09-29 03:59:59','IOTAETH','4h','0.002580600000000','0.002564620000000','0.078557295518522','0.078070840592386','30.441484739410214','30.441484739410214','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','IOTAETH','4h','0.002514350000000','0.002486510000000','0.078557295518522','0.077687474249711','31.243580057876592','31.243580057876592','test'),('2018-10-04 15:59:59','2018-10-04 23:59:59','IOTAETH','4h','0.002540070000000','0.002503440000000','0.078557295518522','0.077424431567984','30.92721677690851','30.927216776908509','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','IOTAETH','4h','0.002555740000000','0.002510010000000','0.078557295518522','0.077151665398063','30.73759283750382','30.737592837503819','test'),('2018-10-18 03:59:59','2018-10-18 07:59:59','IOTAETH','4h','0.002497390000000','0.002470000000000','0.078557295518522','0.077695722306388','31.455758018780408','31.455758018780408','test'),('2018-10-25 15:59:59','2018-10-25 23:59:59','IOTAETH','4h','0.002448370000000','0.002458270000000','0.078557295518522','0.078874942453272','32.08554896462626','32.085548964626263','test'),('2018-10-26 15:59:59','2018-10-26 19:59:59','IOTAETH','4h','0.002440070000000','0.002418150000000','0.078557295518522','0.077851587929082','32.19468929929142','32.194689299291419','test'),('2018-11-01 23:59:59','2018-11-02 03:59:59','IOTAETH','4h','0.002382970000000','0.002381380000000','0.078557295518522','0.078504879374016','32.96612862038633','32.966128620386328','test'),('2018-11-05 07:59:59','2018-11-05 11:59:59','IOTAETH','4h','0.002401020000000','0.002379240000000','0.078557295518522','0.077844690918646','32.71830118804592','32.718301188045920','test'),('2018-11-05 19:59:59','2018-11-05 23:59:59','IOTAETH','4h','0.002388390000000','0.002411970000000','0.078557295518522','0.079332872802101','32.89131821793007','32.891318217930070','test'),('2018-11-12 11:59:59','2018-11-12 23:59:59','IOTAETH','4h','0.002366000000000','0.002341380000000','0.078557295518522','0.077739848090092','33.20257629692392','33.202576296923922','test'),('2018-11-16 15:59:59','2018-11-16 19:59:59','IOTAETH','4h','0.002344150000000','0.002326850000000','0.078557295518522','0.077977536880009','33.512060029657654','33.512060029657654','test'),('2018-11-16 23:59:59','2018-11-17 03:59:59','IOTAETH','4h','0.002349520000000','0.002356090000000','0.078557295518522','0.078776966528582','33.43546576259066','33.435465762590660','test'),('2018-11-19 07:59:59','2018-11-19 11:59:59','IOTAETH','4h','0.002367000000000','0.002345370000000','0.078557295518522','0.077839427203327','33.18854901500718','33.188549015007183','test'),('2018-11-19 23:59:59','2018-11-20 03:59:59','IOTAETH','4h','0.002359970000000','0.002334750000000','0.078557295518522','0.077717786968423','33.28741277156998','33.287412771569983','test'),('2018-11-21 07:59:59','2018-11-21 11:59:59','IOTAETH','4h','0.002347790000000','0.002340610000000','0.078557295518522','0.078317051978076','33.46010312614075','33.460103126140751','test'),('2018-11-21 19:59:59','2018-11-24 23:59:59','IOTAETH','4h','0.002362590000000','0.002458610000000','0.078557295518522','0.081750008395360','33.25049861318384','33.250498613183836','test'),('2018-11-26 19:59:59','2018-11-27 23:59:59','IOTAETH','4h','0.002459170000000','0.002437700000000','0.078557295518522','0.077871444139893','31.944638035809643','31.944638035809643','test'),('2018-12-04 15:59:59','2018-12-05 11:59:59','IOTAETH','4h','0.002513260000000','0.002479240000000','0.078557295518522','0.077493927942728','31.257130387831744','31.257130387831744','test'),('2018-12-06 03:59:59','2018-12-06 15:59:59','IOTAETH','4h','0.002517710000000','0.002477870000000','0.078557295518522','0.077314212457543','31.201884060722644','31.201884060722644','test'),('2018-12-10 07:59:59','2018-12-11 07:59:59','IOTAETH','4h','0.002505750000000','0.002534820000000','0.078557295518522','0.079468663604214','31.350811341323755','31.350811341323755','test'),('2018-12-13 19:59:59','2018-12-13 23:59:59','IOTAETH','4h','0.002517350000000','0.002530530000000','0.078557295518522','0.078968595160977','31.20634616502354','31.206346165023540','test'),('2018-12-14 19:59:59','2018-12-14 23:59:59','IOTAETH','4h','0.002506510000000','0.002525460000000','0.078557295518522','0.079151213256762','31.34130544802215','31.341305448022151','test'),('2018-12-27 19:59:59','2018-12-28 07:59:59','IOTAETH','4h','0.002715280000000','0.002676680000000','0.078557295518522','0.077440537170574','28.931563418329603','28.931563418329603','test'),('2018-12-31 19:59:59','2018-12-31 23:59:59','IOTAETH','4h','0.002644250000000','0.002651980000000','0.078557295518522','0.078786943961127','29.70872478718805','29.708724787188050','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','IOTAETH','4h','0.002491000000000','0.002476150000000','0.078557295518522','0.078088979244556','31.536449425340024','31.536449425340024','test'),('2019-01-11 15:59:59','2019-01-11 23:59:59','IOTAETH','4h','0.002485910000000','0.002472600000000','0.078557295518522','0.078136685921493','31.60102156494885','31.601021564948852','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','IOTAETH','4h','0.002478080000000','0.002464220000000','0.078557295518522','0.078117921440249','31.700871448267208','31.700871448267208','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','IOTAETH','4h','0.002452060000000','0.002431990000000','0.078557295518522','0.077914307614043','32.037264797159125','32.037264797159125','test'),('2019-01-17 15:59:59','2019-01-21 15:59:59','IOTAETH','4h','0.002469370000000','0.002582220000000','0.078557295518522','0.082147357274867','31.812687251615596','31.812687251615596','test'),('2019-01-31 07:59:59','2019-01-31 11:59:59','IOTAETH','4h','0.002456350000000','0.002413330000000','0.078557295518522','0.077181459480007','31.981311913417063','31.981311913417063','test'),('2019-02-07 15:59:59','2019-02-07 19:59:59','IOTAETH','4h','0.002429000000000','0.002403830000000','0.078557295518522','0.077743262118686','32.341414375678056','32.341414375678056','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','IOTAETH','4h','0.002110850000000','0.002152810000000','0.078557295518522','0.080118876928834','37.21595353460549','37.215953534605489','test'),('2019-03-09 15:59:59','2019-03-09 19:59:59','IOTAETH','4h','0.002093220000000','0.002062390000000','0.078557295518522','0.077400264045081','37.529402317253805','37.529402317253805','test'),('2019-03-11 03:59:59','2019-03-11 07:59:59','IOTAETH','4h','0.002090500000000','0.002085160000000','0.078557295518522','0.078356627755753','37.578232728305196','37.578232728305196','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:27:31
