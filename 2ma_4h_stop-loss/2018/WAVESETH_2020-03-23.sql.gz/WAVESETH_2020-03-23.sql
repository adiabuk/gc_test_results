-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-07 23:59:59','2018-06-09 03:59:59','WAVESETH','4h','0.007544000000000','0.007426000000000','0.072144500000000','0.071016046792153','9.563162778366914','9.563162778366914','test'),('2018-06-13 03:59:59','2018-06-13 07:59:59','WAVESETH','4h','0.007534000000000','0.007283000000000','0.072144500000000','0.069740960114149','9.575856118927529','9.575856118927529','test'),('2018-06-18 19:59:59','2018-06-18 23:59:59','WAVESETH','4h','0.007108000000000','0.007038000000000','0.072144500000000','0.071434016741699','10.149760832864379','10.149760832864379','test'),('2018-06-30 11:59:59','2018-06-30 15:59:59','WAVESETH','4h','0.006394000000000','0.006296000000000','0.072144500000000','0.071038750703785','11.283156083828588','11.283156083828588','test'),('2018-07-01 23:59:59','2018-07-05 07:59:59','WAVESETH','4h','0.006370000000000','0.006379000000000','0.072144500000000','0.072246431004710','11.325667189952904','11.325667189952904','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','WAVESETH','4h','0.006375000000000','0.006331000000000','0.072144500000000','0.071646561490196','11.31678431372549','11.316784313725490','test'),('2018-07-14 03:59:59','2018-07-14 07:59:59','WAVESETH','4h','0.006259000000000','0.006200000000000','0.072144500000000','0.071464435213293','11.526521808595623','11.526521808595623','test'),('2018-07-14 11:59:59','2018-07-14 15:59:59','WAVESETH','4h','0.006233000000000','0.006246000000000','0.072144500000000','0.072294969837959','11.574602919942244','11.574602919942244','test'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESETH','4h','0.006405000000000','0.006188000000000','0.072144500000000','0.069700260109290','11.263778298204528','11.263778298204528','test'),('2018-07-20 11:59:59','2018-07-20 19:59:59','WAVESETH','4h','0.006569000000000','0.006409000000000','0.072144500000000','0.070387288856751','10.982569645303698','10.982569645303698','test'),('2018-08-10 11:59:59','2018-08-11 03:59:59','WAVESETH','4h','0.005050000000000','0.005474000000000','0.072144500000000','0.078201780792079','14.286039603960397','14.286039603960397','test'),('2018-08-29 11:59:59','2018-08-29 15:59:59','WAVESETH','4h','0.007810000000000','0.007593000000000','0.072144500000000','0.070139972919334','9.237451984635083','9.237451984635083','test'),('2018-08-31 15:59:59','2018-08-31 19:59:59','WAVESETH','4h','0.007679000000000','0.007477000000000','0.072144500000000','0.070246702239875','9.395038416460476','9.395038416460476','test'),('2018-09-03 19:59:59','2018-09-10 15:59:59','WAVESETH','4h','0.007723000000000','0.011922000000000','0.072144500000000','0.111369510423411','9.341512365661012','9.341512365661012','test'),('2018-09-17 19:59:59','2018-09-18 07:59:59','WAVESETH','4h','0.010738000000000','0.010499000000000','0.079870671809671','0.078092958030335','7.438132967933601','7.438132967933601','test'),('2018-09-19 03:59:59','2018-09-20 11:59:59','WAVESETH','4h','0.010698000000000','0.010516000000000','0.079870671809671','0.078511869952374','7.465944270861002','7.465944270861002','test'),('2018-09-25 15:59:59','2018-09-25 23:59:59','WAVESETH','4h','0.010102000000000','0.009886000000000','0.079870671809671','0.078162884726827','7.906421679832806','7.906421679832806','test'),('2018-09-29 03:59:59','2018-09-29 07:59:59','WAVESETH','4h','0.010027000000000','0.009993000000000','0.079870671809671','0.079599842763942','7.965560168512118','7.965560168512118','test'),('2018-10-05 19:59:59','2018-10-05 23:59:59','WAVESETH','4h','0.009863000000000','0.009644000000000','0.079870671809671','0.078097207637886','8.098009916827639','8.098009916827639','test'),('2018-10-11 23:59:59','2018-10-12 07:59:59','WAVESETH','4h','0.009728000000000','0.009578000000000','0.079870671809671','0.078639113342211','8.210389783066509','8.210389783066509','test'),('2018-10-14 03:59:59','2018-10-14 07:59:59','WAVESETH','4h','0.009630000000000','0.009533000000000','0.079870671809671','0.079066159331422','8.29394307473219','8.293943074732191','test'),('2018-10-14 23:59:59','2018-10-15 07:59:59','WAVESETH','4h','0.009629000000000','0.009420000000000','0.079870671809671','0.078137057684817','8.294804425139786','8.294804425139786','test'),('2018-10-15 15:59:59','2018-10-16 03:59:59','WAVESETH','4h','0.009652000000000','0.009541000000000','0.079870671809671','0.078952142533783','8.275038521515851','8.275038521515851','test'),('2018-10-17 03:59:59','2018-10-19 15:59:59','WAVESETH','4h','0.009564000000000','0.009649000000000','0.079870671809671','0.080580521987821','8.351178566464974','8.351178566464974','test'),('2018-10-20 19:59:59','2018-10-20 23:59:59','WAVESETH','4h','0.009663000000000','0.009590000000000','0.079870671809671','0.079267281657326','8.265618525268653','8.265618525268653','test'),('2018-10-21 11:59:59','2018-10-22 03:59:59','WAVESETH','4h','0.009694000000000','0.009657000000000','0.079870671809671','0.079565821917268','8.23918628117093','8.239186281170930','test'),('2018-10-23 11:59:59','2018-10-23 19:59:59','WAVESETH','4h','0.009829000000000','0.009670000000000','0.079870671809671','0.078578634286247','8.126022159901416','8.126022159901416','test'),('2018-11-02 03:59:59','2018-11-02 07:59:59','WAVESETH','4h','0.009398000000000','0.009479000000000','0.079870671809671','0.080559065554785','8.49868821128655','8.498688211286550','test'),('2018-11-16 15:59:59','2018-11-16 19:59:59','WAVESETH','4h','0.008531000000000','0.008474000000000','0.079870671809671','0.079337014759718','9.362404385144883','9.362404385144883','test'),('2018-11-22 11:59:59','2018-12-03 03:59:59','WAVESETH','4h','0.008648000000000','0.012307000000000','0.079870671809671','0.113664241207403','9.235739108426342','9.235739108426342','test'),('2019-01-13 19:59:59','2019-01-14 15:59:59','WAVESETH','4h','0.022350000000000','0.021652000000000','0.085090938914528','0.082433512723819','3.8072008462876172','3.807200846287617','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','WAVESETH','4h','0.021283000000000','0.021303000000000','0.085090938914528','0.085170900328722','3.9980707096991965','3.998070709699197','test'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','0.085090938914528','0.084826045656269','4.0135342160524505','4.013534216052451','test'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021002000000000','0.085090938914528','0.082685416142272','3.937025813840189','3.937025813840189','test'),('2019-01-20 23:59:59','2019-01-21 11:59:59','WAVESETH','4h','0.021255000000000','0.021424000000000','0.085090938914528','0.085767502954827','4.0033375165621266','4.003337516562127','test'),('2019-01-27 11:59:59','2019-01-27 15:59:59','WAVESETH','4h','0.025120000000000','0.024396000000000','0.085090938914528','0.082638477140081','3.3873781415019106','3.387378141501911','test'),('2019-02-03 07:59:59','2019-02-03 11:59:59','WAVESETH','4h','0.025466000000000','0.026232000000000','0.085090938914528','0.087650416618468','3.3413547048821175','3.341354704882117','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019465000000000','0.085090938914528','0.083448968458852','4.287129127092301','4.287129127092301','test'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','0.085090938914528','0.084605808939889','4.293185616272855','4.293185616272855','test'),('2019-03-01 19:59:59','2019-03-01 23:59:59','WAVESETH','4h','0.019806000000000','0.019825000000000','0.085090938914528','0.085172567099895','4.296220282466323','4.296220282466323','test'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019552000000000','0.085090938914528','0.082927825623410','4.241398610035291','4.241398610035291','test'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','0.085090938914528','0.084295735816484','4.207423799175633','4.207423799175633','test'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','0.085090938914528','0.084578494717294','4.200362272412281','4.200362272412281','test'),('2019-03-26 07:59:59','2019-03-26 11:59:59','WAVESETH','4h','0.020136000000000','0.020017000000000','0.085090938914528','0.084588067354594','4.225811428015891','4.225811428015891','test'),('2019-03-29 19:59:59','2019-03-29 23:59:59','WAVESETH','4h','0.020161000000000','0.019766000000000','0.085090938914528','0.083423813232705','4.2205713463879775','4.220571346387977','test'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.019784000000000','0.085090938914528','0.082695836099868','4.179935104117895','4.179935104117895','test'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.012338000000000','0.085090938914528','0.077559988499368','6.286269127846336','6.286269127846336','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','WAVESETH','4h','0.013637000000000','0.013044000000000','0.085090938914528','0.081390790291201','6.2397110005520275','6.239711000552028','test'),('2019-05-10 15:59:59','2019-05-10 19:59:59','WAVESETH','4h','0.013270000000000','0.012860000000000','0.085090938914528','0.082461904630055','6.412278742617031','6.412278742617031','test'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','0.085090938914528','0.104555981346404','7.842482849265253','7.842482849265253','test'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','0.085090938914528','0.085035592643166','7.90661019462256','7.906610194622560','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:43:45
