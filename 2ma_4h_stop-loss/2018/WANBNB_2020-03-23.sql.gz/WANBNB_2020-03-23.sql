-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 19:59:59','2018-09-16 23:59:59','WANBNB','4h','0.099590000000000','0.097150000000000','0.711908500000000','0.694466420072296','7.148393412993273','7.148393412993273','test'),('2018-09-20 11:59:59','2018-09-20 15:59:59','WANBNB','4h','0.096420000000000','0.097290000000000','0.711908500000000','0.718332067672682','7.383411118025306','7.383411118025306','test'),('2018-09-23 07:59:59','2018-09-24 07:59:59','WANBNB','4h','0.099320000000000','0.098360000000000','0.711908500000000','0.705027386830447','7.1678262182843335','7.167826218284334','test'),('2018-09-28 07:59:59','2018-09-28 11:59:59','WANBNB','4h','0.097040000000000','0.093500000000000','0.711908500000000','0.685938218775763','7.336237633965376','7.336237633965376','test'),('2018-09-30 19:59:59','2018-09-30 23:59:59','WANBNB','4h','0.095520000000000','0.098100000000000','0.711908500000000','0.731137184359297','7.452978433835847','7.452978433835847','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','WANBNB','4h','0.099470000000000','0.097570000000000','0.711908500000000','0.698310167336886','7.157017191112899','7.157017191112899','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','WANBNB','4h','0.102190000000000','0.099890000000000','0.711908500000000','0.695885508024269','6.966518250318035','6.966518250318035','test'),('2018-10-13 23:59:59','2018-10-14 07:59:59','WANBNB','4h','0.101230000000000','0.099510000000000','0.711908500000000','0.699812455151635','7.0325842141657615','7.032584214165762','test'),('2018-10-14 15:59:59','2018-10-14 23:59:59','WANBNB','4h','0.101220000000000','0.100000000000000','0.711908500000000','0.703327899624580','7.0332789962458016','7.033278996245802','test'),('2018-10-16 15:59:59','2018-10-16 23:59:59','WANBNB','4h','0.100730000000000','0.099880000000000','0.711908500000000','0.705901131539760','7.067492306164996','7.067492306164996','test'),('2018-10-22 07:59:59','2018-10-22 11:59:59','WANBNB','4h','0.102040000000000','0.101090000000000','0.711908500000000','0.705280578841631','6.976759114072912','6.976759114072912','test'),('2018-10-22 19:59:59','2018-10-22 23:59:59','WANBNB','4h','0.101860000000000','0.101000000000000','0.711908500000000','0.705897884351070','6.989087963871981','6.989087963871981','test'),('2018-10-23 03:59:59','2018-10-23 07:59:59','WANBNB','4h','0.101840000000000','0.101160000000000','0.711908500000000','0.707154986842105','6.99046052631579','6.990460526315790','test'),('2018-10-24 07:59:59','2018-10-24 11:59:59','WANBNB','4h','0.102380000000000','0.102380000000000','0.711908500000000','0.711908500000000','6.953589568275055','6.953589568275055','test'),('2018-11-28 19:59:59','2018-11-28 23:59:59','WANBNB','4h','0.086180000000000','0.082970000000000','0.711908500000000','0.685391601821768','8.260715943374333','8.260715943374333','test'),('2018-12-01 15:59:59','2018-12-01 19:59:59','WANBNB','4h','0.083360000000000','0.082410000000000','0.711908500000000','0.703795339311420','8.540169145873321','8.540169145873321','test'),('2018-12-20 19:59:59','2018-12-20 23:59:59','WANBNB','4h','0.068550000000000','0.067330000000000','0.711908500000000','0.699238501896426','10.385244347191831','10.385244347191831','test'),('2018-12-21 11:59:59','2018-12-22 15:59:59','WANBNB','4h','0.068050000000000','0.067670000000000','0.711908500000000','0.707933110874357','10.461550330639236','10.461550330639236','test'),('2019-01-05 23:59:59','2019-01-06 07:59:59','WANBNB','4h','0.060640000000000','0.059140000000000','0.711908500000000','0.694298626154354','11.739915897097626','11.739915897097626','test'),('2019-01-07 03:59:59','2019-01-07 07:59:59','WANBNB','4h','0.060630000000000','0.060420000000000','0.711908500000000','0.709442711034142','11.741852218373742','11.741852218373742','test'),('2019-01-17 03:59:59','2019-01-17 11:59:59','WANBNB','4h','0.055190000000000','0.056200000000000','0.711908500000000','0.724936722232289','12.89922993295887','12.899229932958869','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','WANBNB','4h','0.054310000000000','0.051960000000000','0.711908500000000','0.681104136623090','13.108239734855461','13.108239734855461','test'),('2019-02-24 07:59:59','2019-02-24 11:59:59','WANBNB','4h','0.030960000000000','0.030230000000000','0.711908500000000','0.695122543766150','22.994460594315246','22.994460594315246','test'),('2019-02-26 03:59:59','2019-02-27 19:59:59','WANBNB','4h','0.030460000000000','0.031110000000000','0.711908500000000','0.727100244090611','23.371913985554826','23.371913985554826','test'),('2019-03-09 07:59:59','2019-03-10 11:59:59','WANBNB','4h','0.026510000000000','0.027100000000000','0.711908500000000','0.727752559411543','26.85433798566579','26.854337985665790','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WANBNB','4h','0.027600000000000','0.026290000000000','0.711908500000000','0.678118640036232','25.79378623188406','25.793786231884059','test'),('2019-03-23 15:59:59','2019-03-24 11:59:59','WANBNB','4h','0.026980000000000','0.023820000000000','0.711908500000000','0.628527074499629','26.38652705707932','26.386527057079320','test'),('2019-03-28 23:59:59','2019-03-29 07:59:59','WANBNB','4h','0.025490000000000','0.024930000000000','0.711908500000000','0.696268297567674','27.92893291486858','27.928932914868579','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','WANBNB','4h','0.025870000000000','0.025600000000000','0.711908500000000','0.704478453807499','27.51868960185543','27.518689601855431','test'),('2019-04-03 11:59:59','2019-04-03 15:59:59','WANBNB','4h','0.025400000000000','0.024980000000000','0.711908500000000','0.700136784645669','28.027893700787406','28.027893700787406','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','WANBNB','4h','0.024820000000000','0.024190000000000','0.711908500000000','0.693838300362611','28.682856567284453','28.682856567284453','test'),('2019-04-08 15:59:59','2019-04-09 07:59:59','WANBNB','4h','0.024830000000000','0.024400000000000','0.711908500000000','0.699579838904551','28.671304873137334','28.671304873137334','test'),('2019-04-10 15:59:59','2019-04-10 23:59:59','WANBNB','4h','0.024710000000000','0.023710000000000','0.711908500000000','0.683097957709429','28.810542290570623','28.810542290570623','test'),('2019-05-01 07:59:59','2019-05-01 15:59:59','WANBNB','4h','0.017440000000000','0.017050000000000','0.711908500000000','0.695988527809633','40.820441513761466','40.820441513761466','test'),('2019-05-08 15:59:59','2019-05-08 19:59:59','WANBNB','4h','0.016200000000000','0.015660000000000','0.711908500000000','0.688178216666667','43.944969135802474','43.944969135802474','test'),('2019-05-10 03:59:59','2019-05-10 07:59:59','WANBNB','4h','0.016070000000000','0.016710000000000','0.711908500000000','0.740260798693217','44.30046670815184','44.300466708151838','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','WANBNB','4h','0.015970000000000','0.015810000000000','0.711908500000000','0.704776041640576','44.5778647463995','44.577864746399499','test'),('2019-05-16 23:59:59','2019-05-17 03:59:59','WANBNB','4h','0.016140000000000','0.015640000000000','0.711908500000000','0.689854333333333','44.108333333333334','44.108333333333334','test'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WANBNB','4h','0.014480000000000','0.014400000000000','0.711908500000000','0.707975303867403','49.164951657458566','49.164951657458566','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','WANBNB','4h','0.013330000000000','0.013080000000000','0.711908500000000','0.698556877719430','53.406489122280576','53.406489122280576','test'),('2019-06-02 07:59:59','2019-06-06 03:59:59','WANBNB','4h','0.013110000000000','0.013710000000000','0.711908500000000','0.744490124713959','54.30270785659802','54.302707856598019','test'),('2019-06-06 23:59:59','2019-06-09 23:59:59','WANBNB','4h','0.013700000000000','0.014200000000000','0.711908500000000','0.737890562043796','51.964124087591244','51.964124087591244','test'),('2019-06-14 03:59:59','2019-06-14 15:59:59','WANBNB','4h','0.014340000000000','0.013990000000000','0.711908500000000','0.694532769525802','49.64494421199442','49.644944211994421','test'),('2019-06-15 03:59:59','2019-06-15 07:59:59','WANBNB','4h','0.014280000000000','0.013820000000000','0.711908500000000','0.688975873249300','49.85353641456583','49.853536414565831','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','WANBNB','4h','0.011250000000000','0.011250000000000','0.711908500000000','0.711908500000000','63.280755555555565','63.280755555555565','test'),('2019-07-01 23:59:59','2019-07-02 03:59:59','WANBNB','4h','0.011150000000000','0.010940000000000','0.711908500000000','0.698500357847534','63.84829596412556','63.848295964125562','test'),('2019-07-02 11:59:59','2019-07-02 15:59:59','WANBNB','4h','0.011130000000000','0.010990000000000','0.711908500000000','0.702953676100629','63.963027852650505','63.963027852650505','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','WANBNB','4h','0.011740000000000','0.011190000000000','0.711908500000000','0.678556738926746','60.639565587734246','60.639565587734246','test'),('2019-07-09 15:59:59','2019-07-09 19:59:59','WANBNB','4h','0.011080000000000','0.010750000000000','0.711908500000000','0.690705449007220','64.25166967509026','64.251669675090255','test'),('2019-07-24 07:59:59','2019-07-24 19:59:59','WANBNB','4h','0.009050000000000','0.009040000000000','0.711908500000000','0.711121860773481','78.6639226519337','78.663922651933703','test'),('2019-08-04 23:59:59','2019-08-05 03:59:59','WANBNB','4h','0.010140000000000','0.009540000000000','0.711908500000000','0.669783736686391','70.20793885601579','70.207938856015787','test'),('2019-08-22 15:59:59','2019-08-23 23:59:59','WANBNB','4h','0.008160000000000','0.014720000000000','0.711908500000000','1.284227098039216','87.2436887254902','87.243688725490202','test'),('2019-08-30 15:59:59','2019-08-30 19:59:59','WANBNB','4h','0.016950000000000','0.016550000000000','0.719042670204049','0.702074111615163','42.42139647221527','42.421396472215271','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  3:00:52
