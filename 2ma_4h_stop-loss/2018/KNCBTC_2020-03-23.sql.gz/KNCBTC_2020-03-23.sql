-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-03-20 07:59:59','KNCBTC','4h','0.000144700000000','0.000140840000000','0.001467500000000','0.001428353144437','10.141672425708363','10.141672425708363','test'),('2018-03-23 15:59:59','2018-03-26 15:59:59','KNCBTC','4h','0.000151560000000','0.000163260000000','0.001467500000000','0.001580786817102','9.682633940353655','9.682633940353655','test'),('2018-03-27 11:59:59','2018-03-27 15:59:59','KNCBTC','4h','0.000151840000000','0.000151910000000','0.001486034990385','0.001486720069740','9.786847934567637','9.786847934567637','test'),('2018-03-29 03:59:59','2018-03-29 07:59:59','KNCBTC','4h','0.000151020000000','0.000147870000000','0.001486206260223','0.001455206725594','9.841122104512648','9.841122104512648','test'),('2018-04-07 19:59:59','2018-04-07 23:59:59','KNCBTC','4h','0.000140890000000','0.000142260000000','0.001486206260223','0.001500657978418','10.548699412470722','10.548699412470722','test'),('2018-05-05 07:59:59','2018-05-05 11:59:59','KNCBTC','4h','0.000268020000000','0.000249500000000','0.001486206260223','0.001383510416856','5.5451319312849785','5.545131931284978','test'),('2018-05-10 03:59:59','2018-05-10 19:59:59','KNCBTC','4h','0.000266790000000','0.000259160000000','0.001486206260223','0.001443701841896','5.570697028460587','5.570697028460587','test'),('2018-05-12 23:59:59','2018-05-13 11:59:59','KNCBTC','4h','0.000254550000000','0.000250460000000','0.001486206260223','0.001462326536773','5.838563190819093','5.838563190819093','test'),('2018-05-14 11:59:59','2018-05-14 23:59:59','KNCBTC','4h','0.000261350000000','0.000258350000000','0.001486206260223','0.001469146306978','5.686651081779224','5.686651081779224','test'),('2018-06-01 11:59:59','2018-06-04 07:59:59','KNCBTC','4h','0.000189980000000','0.000191330000000','0.001486206260223','0.001496767258493','7.822961681350669','7.822961681350669','test'),('2018-06-04 15:59:59','2018-06-04 19:59:59','KNCBTC','4h','0.000193130000000','0.000195000000000','0.001486206260223','0.001500596596818','7.695367163169886','7.695367163169886','test'),('2018-07-02 03:59:59','2018-07-02 07:59:59','KNCBTC','4h','0.000143050000000','0.000139720000000','0.001486206260223','0.001451609497926','10.389418107116391','10.389418107116391','test'),('2018-07-04 11:59:59','2018-07-04 23:59:59','KNCBTC','4h','0.000144770000000','0.000142580000000','0.001486206260223','0.001463723758946','10.265982318318711','10.265982318318711','test'),('2018-07-13 11:59:59','2018-07-13 15:59:59','KNCBTC','4h','0.000142690000000','0.000146050000000','0.001486206260223','0.001521202777389','10.415630108788282','10.415630108788282','test'),('2018-07-14 07:59:59','2018-07-14 11:59:59','KNCBTC','4h','0.000142830000000','0.000141350000000','0.001486206260223','0.001470806237363','10.405420851522788','10.405420851522788','test'),('2018-07-14 15:59:59','2018-07-14 19:59:59','KNCBTC','4h','0.000141960000000','0.000138880000000','0.001486206260223','0.001453961153985','10.469190336876585','10.469190336876585','test'),('2018-07-16 15:59:59','2018-07-17 03:59:59','KNCBTC','4h','0.000143160000000','0.000142460000000','0.001486206260223','0.001478939255598','10.381435178981558','10.381435178981558','test'),('2018-07-18 03:59:59','2018-07-18 11:59:59','KNCBTC','4h','0.000143400000000','0.000140500000000','0.001486206260223','0.001456150485086','10.36406039207113','10.364060392071130','test'),('2018-07-19 03:59:59','2018-07-19 07:59:59','KNCBTC','4h','0.000141910000000','0.000144030000000','0.001486206260223','0.001508408763723','10.472879009393276','10.472879009393276','test'),('2018-08-21 23:59:59','2018-08-22 03:59:59','KNCBTC','4h','0.000076720000000','0.000074330000000','0.001486206260223','0.001439907603263','19.371822995607403','19.371822995607403','test'),('2018-08-24 07:59:59','2018-08-24 11:59:59','KNCBTC','4h','0.000075560000000','0.000076000000000','0.001486206260223','0.001494860717006','19.669219960600845','19.669219960600845','test'),('2018-08-31 19:59:59','2018-08-31 23:59:59','KNCBTC','4h','0.000078030000000','0.000077400000000','0.001486206260223','0.001474206901721','19.046600797424066','19.046600797424066','test'),('2018-09-01 03:59:59','2018-09-01 07:59:59','KNCBTC','4h','0.000077670000000','0.000077530000000','0.001486206260223','0.001483527376788','19.134881681769023','19.134881681769023','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','KNCBTC','4h','0.000077860000000','0.000075350000000','0.001486206260223','0.001438294910195','19.088187262047263','19.088187262047263','test'),('2018-09-21 19:59:59','2018-09-22 03:59:59','KNCBTC','4h','0.000060590000000','0.000059220000000','0.001486206260223','0.001452601662492','24.528903453094568','24.528903453094568','test'),('2018-09-23 07:59:59','2018-09-23 11:59:59','KNCBTC','4h','0.000059850000000','0.000061180000000','0.001486206260223','0.001519233066006','24.83218479904762','24.832184799047621','test'),('2018-09-30 07:59:59','2018-09-30 23:59:59','KNCBTC','4h','0.000058300000000','0.000059050000000','0.001486206260223','0.001505325551735','25.492388683070324','25.492388683070324','test'),('2018-10-03 23:59:59','2018-10-04 03:59:59','KNCBTC','4h','0.000058700000000','0.000058350000000','0.001486206260223','0.001477344723748','25.318675642640546','25.318675642640546','test'),('2018-10-04 07:59:59','2018-10-04 11:59:59','KNCBTC','4h','0.000058480000000','0.000057950000000','0.001486206260223','0.001472736880642','25.413923738423392','25.413923738423392','test'),('2018-10-06 03:59:59','2018-10-06 15:59:59','KNCBTC','4h','0.000059030000000','0.000058640000000','0.001486206260223','0.001476387177697','25.177134681060476','25.177134681060476','test'),('2018-10-14 19:59:59','2018-10-14 23:59:59','KNCBTC','4h','0.000060710000000','0.000059690000000','0.001486206260223','0.001461236232461','24.480419374452314','24.480419374452314','test'),('2018-10-15 11:59:59','2018-10-15 15:59:59','KNCBTC','4h','0.000062900000000','0.000062210000000','0.001486206260223','0.001469902884713','23.628080448696345','23.628080448696345','test'),('2018-11-01 15:59:59','2018-11-01 19:59:59','KNCBTC','4h','0.000067980000000','0.000068810000000','0.001486206260223','0.001504352055986','21.862404534024712','21.862404534024712','test'),('2018-11-29 15:59:59','2018-11-29 19:59:59','KNCBTC','4h','0.000046210000000','0.000045210000000','0.001486206260223','0.001454044255024','32.16200519850682','32.162005198506819','test'),('2018-12-01 03:59:59','2018-12-01 11:59:59','KNCBTC','4h','0.000053580000000','0.000051520000000','0.001486206260223','0.001429065817967','27.73807876489362','27.738078764893618','test'),('2018-12-04 19:59:59','2018-12-04 23:59:59','KNCBTC','4h','0.000046020000000','0.000045400000000','0.001486206260223','0.001466183490094','32.29479053070404','32.294790530704041','test'),('2018-12-19 07:59:59','2018-12-19 15:59:59','KNCBTC','4h','0.000039000000000','0.000039170000000','0.001486206260223','0.001492684595203','38.10785282623077','38.107852826230769','test'),('2018-12-20 07:59:59','2018-12-20 11:59:59','KNCBTC','4h','0.000043040000000','0.000039570000000','0.001486206260223','0.001366384333574','34.53081459625929','34.530814596259290','test'),('2018-12-26 03:59:59','2018-12-27 07:59:59','KNCBTC','4h','0.000041360000000','0.000040730000000','0.001486206260223','0.001463568205486','35.93342021815764','35.933420218157643','test'),('2018-12-28 07:59:59','2018-12-30 11:59:59','KNCBTC','4h','0.000041320000000','0.000041250000000','0.001486206260223','0.001483688485823','35.96820571691675','35.968205716916749','test'),('2018-12-31 19:59:59','2018-12-31 23:59:59','KNCBTC','4h','0.000041070000000','0.000041040000000','0.001486206260223','0.001485120645716','36.18715023674215','36.187150236742148','test'),('2019-01-04 19:59:59','2019-01-04 23:59:59','KNCBTC','4h','0.000041670000000','0.000041200000000','0.001486206260223','0.001469443194653','35.66609695759539','35.666096957595393','test'),('2019-01-05 15:59:59','2019-01-05 19:59:59','KNCBTC','4h','0.000041430000000','0.000041480000000','0.001486206260223','0.001487999895584','35.87270722237509','35.872707222375091','test'),('2019-01-19 19:59:59','2019-01-20 11:59:59','KNCBTC','4h','0.000038770000000','0.000038610000000','0.001486206260223','0.001480072832273','38.33392468978591','38.333924689785910','test'),('2019-01-24 07:59:59','2019-01-24 11:59:59','KNCBTC','4h','0.000038590000000','0.000038700000000','0.001486206260223','0.001490442660550','38.51273024677377','38.512730246773771','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','KNCBTC','4h','0.000038670000000','0.000038750000000','0.001486206260223','0.001489280904671','38.43305560442203','38.433055604422030','test'),('2019-02-07 11:59:59','2019-02-07 15:59:59','KNCBTC','4h','0.000035100000000','0.000035570000000','0.001486206260223','0.001506107027810','42.342058695811964','42.342058695811964','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','KNCBTC','4h','0.000041000000000','0.000038340000000','0.001486206260223','0.001389784097974','36.24893317617073','36.248933176170731','test'),('2019-02-22 11:59:59','2019-02-23 19:59:59','KNCBTC','4h','0.000038630000000','0.000038410000000','0.001486206260223','0.001477742232854','38.47285167545949','38.472851675459488','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','KNCBTC','4h','0.000038690000000','0.000038360000000','0.001486206260223','0.001473529908042','38.41318842654433','38.413188426544330','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  7:15:19
