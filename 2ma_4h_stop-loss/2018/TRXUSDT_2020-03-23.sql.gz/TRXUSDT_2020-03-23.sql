-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-11-28 19:59:59','2018-11-28 23:59:59','TRXUSDT','4h','0.015230000000000','0.014670000000000','15.000000000000000','14.448456992777412','984.898227183191','984.898227183191011','test'),('2018-11-29 07:59:59','2018-11-30 03:59:59','TRXUSDT','4h','0.014980000000000','0.015220000000000','15.000000000000000','15.240320427236314','1001.3351134846462','1001.335113484646172','test'),('2018-12-01 11:59:59','2018-12-02 07:59:59','TRXUSDT','4h','0.015210000000000','0.015010000000000','15.000000000000000','14.802761341222881','986.1932938856016','986.193293885601634','test'),('2018-12-04 15:59:59','2018-12-04 19:59:59','TRXUSDT','4h','0.014880000000000','0.014420000000000','15.000000000000000','14.536290322580646','1008.0645161290322','1008.064516129032199','test'),('2018-12-17 15:59:59','2018-12-24 19:59:59','TRXUSDT','4h','0.013630000000000','0.020720000000000','15.000000000000000','22.802641232575201','1100.5135730007337','1100.513573000733686','test'),('2018-12-28 07:59:59','2018-12-28 11:59:59','TRXUSDT','4h','0.018290000000000','0.018510000000000','16.707617579098113','16.908584001591365','913.4837386056923','913.483738605692338','test'),('2019-01-01 07:59:59','2019-01-01 15:59:59','TRXUSDT','4h','0.019030000000000','0.018820000000000','16.757859184721426','16.572932730239479','880.6021641997597','880.602164199759727','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','TRXUSDT','4h','0.023710000000000','0.022870000000000','16.757859184721426','16.164160251142096','706.7844447373019','706.784444737301897','test'),('2019-01-14 15:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024100000000000','0.023950000000000','16.757859184721426','16.653557156600751','695.3468541378185','695.346854137818468','test'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXUSDT','4h','0.025160000000000','0.025900000000000','16.757859184721426','17.250737396036765','666.0516369126163','666.051636912616345','test'),('2019-01-28 23:59:59','2019-01-29 07:59:59','TRXUSDT','4h','0.026730000000000','0.025940000000000','16.757859184721426','16.262583885210393','626.9307588747259','626.930758874725939','test'),('2019-01-29 11:59:59','2019-01-31 11:59:59','TRXUSDT','4h','0.026620000000000','0.025860000000000','16.757859184721426','16.279422934519008','629.5213818452827','629.521381845282690','test'),('2019-02-04 11:59:59','2019-02-05 03:59:59','TRXUSDT','4h','0.027060000000000','0.026530000000000','16.757859184721426','16.429637995959329','619.2852618152781','619.285261815278091','test'),('2019-02-08 15:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.026640000000000','0.026400000000000','16.757859184721426','16.606887480354565','629.0487681952487','629.048768195248726','test'),('2019-02-18 19:59:59','2019-02-20 03:59:59','TRXUSDT','4h','0.024840000000000','0.024640000000000','16.757859184721426','16.622932782267952','674.6320122673682','674.632012267368168','test'),('2019-02-22 03:59:59','2019-02-22 07:59:59','TRXUSDT','4h','0.024750000000000','0.024770000000000','16.757859184721426','16.771400889113121','677.0852195847041','677.085219584704078','test'),('2019-03-05 19:59:59','2019-03-05 23:59:59','TRXUSDT','4h','0.023600000000000','0.023750000000000','16.757859184721426','16.864371001573470','710.0787790136197','710.078779013619737','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','TRXUSDT','4h','0.023420000000000','0.023320000000000','16.757859184721426','16.686305558825946','715.5362589548004','715.536258954800360','test'),('2019-03-15 15:59:59','2019-03-15 19:59:59','TRXUSDT','4h','0.022740000000000','0.022910000000000','16.757859184721426','16.883137815389965','736.9331215796582','736.933121579658177','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','TRXUSDT','4h','0.022790000000000','0.022690000000000','16.757859184721426','16.684327551616018','735.3163310540335','735.316331054033526','test'),('2019-03-23 11:59:59','2019-03-24 07:59:59','TRXUSDT','4h','0.023960000000000','0.023610000000000','16.757859184721426','16.513065749218402','699.409815722931','699.409815722930944','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','TRXUSDT','4h','0.022980000000000','0.022530000000000','16.757859184721426','16.429702673271269','729.2366921114632','729.236692111463185','test'),('2019-03-27 11:59:59','2019-03-28 03:59:59','TRXUSDT','4h','0.023200000000000','0.022920000000000','16.757859184721426','16.555609160078237','722.3215165828201','722.321516582820095','test'),('2019-04-15 11:59:59','2019-04-15 15:59:59','TRXUSDT','4h','0.026830000000000','0.027130000000000','16.757859184721426','16.945237408926289','624.5940806828709','624.594080682870867','test'),('2019-04-18 03:59:59','2019-04-18 11:59:59','TRXUSDT','4h','0.026920000000000','0.026690000000000','16.757859184721426','16.614682824673654','622.5059132511674','622.505913251167385','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','TRXUSDT','4h','0.026790000000000','0.026720000000000','16.757859184721426','16.714072318617262','625.5266586308855','625.526658630885549','test'),('2019-05-03 23:59:59','2019-05-04 07:59:59','TRXUSDT','4h','0.023810000000000','0.023740000000000','16.757859184721426','16.708592064060756','703.8160094381111','703.816009438111109','test'),('2019-05-06 15:59:59','2019-05-07 15:59:59','TRXUSDT','4h','0.023890000000000','0.023830000000000','16.757859184721426','16.715771635492320','701.4591538183937','701.459153818393702','test'),('2019-05-11 11:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.024500000000000','0.024020000000000','16.757859184721426','16.429541943551374','683.9942524376091','683.994252437609134','test'),('2019-05-13 03:59:59','2019-05-13 07:59:59','TRXUSDT','4h','0.024470000000000','0.024120000000000','16.757859184721426','16.518167696586875','684.8328232415785','684.832823241578467','test'),('2019-05-17 19:59:59','2019-05-20 15:59:59','TRXUSDT','4h','0.026250000000000','0.027310000000000','16.757859184721426','17.434557498466368','638.3946356084352','638.394635608435237','test'),('2019-05-24 03:59:59','2019-05-24 07:59:59','TRXUSDT','4h','0.027000000000000','0.027590000000000','16.757859184721426','17.124049440980151','620.6614512859787','620.661451285978728','test'),('2019-06-12 15:59:59','2019-06-12 19:59:59','TRXUSDT','4h','0.032820000000000','0.032420000000000','16.757859184721426','16.553619584663881','510.5990001438582','510.599000143858177','test'),('2019-06-15 19:59:59','2019-06-15 23:59:59','TRXUSDT','4h','0.032450000000000','0.032640000000000','16.757859184721426','16.855979161457853','516.4209301917234','516.420930191723414','test'),('2019-06-21 03:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033030000000000','0.036770000000000','16.757859184721426','18.655358226527607','507.35268497491455','507.352684974914553','test'),('2019-07-07 19:59:59','2019-07-08 11:59:59','TRXUSDT','4h','0.034810000000000','0.033570000000000','16.757859184721426','16.160911601008284','481.40934170414897','481.409341704148972','test'),('2019-07-19 23:59:59','2019-07-21 15:59:59','TRXUSDT','4h','0.028060000000000','0.027870000000000','16.757859184721426','16.644388292166290','597.2152239743915','597.215223974391506','test'),('2019-08-05 15:59:59','2019-08-05 19:59:59','TRXUSDT','4h','0.023330000000000','0.023090000000000','16.757859184721426','16.585468005795871','718.2965788564692','718.296578856469182','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','TRXUSDT','4h','0.022860000000000','0.022340000000000','16.757859184721426','16.376665537474921','733.064706243282','733.064706243281989','test'),('2019-09-08 03:59:59','2019-09-08 07:59:59','TRXUSDT','4h','0.016060000000000','0.015630000000000','16.757859184721426','16.309174287496631','1043.453249359989','1043.453249359989059','test'),('2019-09-08 23:59:59','2019-09-09 03:59:59','TRXUSDT','4h','0.015760000000000','0.015410000000000','16.757859184721426','16.385698606380529','1063.3159381168418','1063.315938116841835','test'),('2019-09-09 11:59:59','2019-09-09 15:59:59','TRXUSDT','4h','0.015800000000000','0.015680000000000','16.757859184721426','16.630584304837463','1060.6239990330016','1060.623999033001610','test'),('2019-09-10 03:59:59','2019-09-10 11:59:59','TRXUSDT','4h','0.015980000000000','0.015770000000000','16.757859184721426','16.537637005197549','1048.6770453517788','1048.677045351778816','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','TRXUSDT','4h','0.015510000000000','0.015290000000000','16.757859184721426','16.520159054441688','1080.455137635166','1080.455137635166011','test'),('2019-09-14 15:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015680000000000','0.015470000000000','16.757859184721426','16.533423570640334','1068.7410194337644','1068.741019433764450','test'),('2019-09-16 23:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015650000000000','0.016580000000000','16.757859184721426','17.753693628286342','1070.7897242633499','1070.789724263349854','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','TRXUSDT','4h','0.014630000000000','0.014530000000000','16.757859184721426','16.643314692686417','1145.4449203500633','1145.444920350063285','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','TRXUSDT','4h','0.014420000000000','0.014710000000000','16.757859184721426','17.094875770267141','1162.1261570541903','1162.126157054190344','test'),('2019-10-19 15:59:59','2019-10-19 19:59:59','TRXUSDT','4h','0.015650000000000','0.015460000000000','16.757859184721426','16.554409137111389','1070.7897242633499','1070.789724263349854','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','TRXUSDT','4h','0.015630000000000','0.015420000000000','16.757859184721426','16.532705606423821','1072.1598966552415','1072.159896655241482','test'),('2019-10-22 03:59:59','2019-10-22 07:59:59','TRXUSDT','4h','0.015570000000000','0.015540000000000','16.757859184721426','16.725570438700768','1076.2915340219283','1076.291534021928328','test'),('2019-10-25 11:59:59','2019-10-28 23:59:59','TRXUSDT','4h','0.015410000000000','0.019980000000000','16.757859184721426','21.727581214194295','1087.4665272369516','1087.466527236951606','test'),('2019-11-10 07:59:59','2019-11-10 11:59:59','TRXUSDT','4h','0.019330000000000','0.019170000000000','17.346644452557758','17.203061259986146','897.394953572569','897.394953572568966','test'),('2019-11-10 19:59:59','2019-11-11 03:59:59','TRXUSDT','4h','0.019420000000000','0.019190000000000','17.346644452557758','17.141200156775664','893.2360686178042','893.236068617804222','test'),('2019-11-12 11:59:59','2019-11-12 15:59:59','TRXUSDT','4h','0.019600000000000','0.019410000000000','17.346644452557758','17.178488205313577','885.0328802325387','885.032880232538673','test'),('2019-11-14 23:59:59','2019-11-15 03:59:59','TRXUSDT','4h','0.019410000000000','0.019030000000000','17.346644452557758','17.007039872858016','893.6962623677362','893.696262367736153','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:26:31
