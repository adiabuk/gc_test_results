-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-27 11:59:59','2018-05-27 15:59:59','XLMETH','4h','0.000481440000000','0.000478980000000','0.072144500000000','0.071775865341476','149.8514872050515','149.851487205051512','test'),('2018-05-29 07:59:59','2018-06-03 11:59:59','XLMETH','4h','0.000481000000000','0.000491920000000','0.072144500000000','0.073782375135135','149.98856548856548','149.988565488565484','test'),('2018-06-06 23:59:59','2018-06-07 03:59:59','XLMETH','4h','0.000492990000000','0.000489040000000','0.072461810119153','0.071881221973408','146.98434069484725','146.984340694847248','test'),('2018-06-07 07:59:59','2018-06-07 15:59:59','XLMETH','4h','0.000493870000000','0.000488080000000','0.072461810119153','0.071612287207071','146.72243731984733','146.722437319847330','test'),('2018-06-07 19:59:59','2018-06-07 23:59:59','XLMETH','4h','0.000493140000000','0.000484590000000','0.072461810119153','0.071205476265645','146.93963198919778','146.939631989197778','test'),('2018-06-14 11:59:59','2018-06-14 19:59:59','XLMETH','4h','0.000481630000000','0.000463950000000','0.072461810119153','0.069801832952227','150.45119722432779','150.451197224327785','test'),('2018-06-15 19:59:59','2018-06-15 23:59:59','XLMETH','4h','0.000478920000000','0.000470490000000','0.072461810119153','0.071186329748101','151.30253511891965','151.302535118919650','test'),('2018-06-28 11:59:59','2018-06-28 15:59:59','XLMETH','4h','0.000438360000000','0.000438610000000','0.072461810119153','0.072503135633638','165.30205794131078','165.302057941310778','test'),('2018-06-30 03:59:59','2018-06-30 07:59:59','XLMETH','4h','0.000439830000000','0.000435840000000','0.072461810119153','0.071804459273655','164.74958533786463','164.749585337864630','test'),('2018-07-01 23:59:59','2018-07-02 07:59:59','XLMETH','4h','0.000441700000000','0.000431460000000','0.072461810119153','0.070781916671971','164.05209445133121','164.052094451331214','test'),('2018-07-06 23:59:59','2018-07-07 03:59:59','XLMETH','4h','0.000440700000000','0.000444240000000','0.072461810119153','0.073043872310716','164.42434789914455','164.424347899144550','test'),('2018-07-09 03:59:59','2018-07-09 07:59:59','XLMETH','4h','0.000443070000000','0.000440950000000','0.072461810119153','0.072115095068591','163.54483517086013','163.544835170860125','test'),('2018-07-10 11:59:59','2018-07-10 15:59:59','XLMETH','4h','0.000439750000000','0.000437690000000','0.072461810119153','0.072122364232068','164.77955683718704','164.779556837187044','test'),('2018-07-13 23:59:59','2018-07-14 03:59:59','XLMETH','4h','0.000475090000000','0.000460690000000','0.072461810119153','0.070265489283699','152.5222802398556','152.522280239855604','test'),('2018-07-31 15:59:59','2018-07-31 23:59:59','XLMETH','4h','0.000641060000000','0.000641670000000','0.072461810119153','0.072530761081891','113.03436514390695','113.034365143906953','test'),('2018-08-09 23:59:59','2018-08-10 03:59:59','XLMETH','4h','0.000609120000000','0.000610330000000','0.072461810119153','0.072605753496885','118.96146920008043','118.961469200080430','test'),('2018-08-10 15:59:59','2018-08-15 11:59:59','XLMETH','4h','0.000607100000000','0.000775950000000','0.072461810119153','0.092615288357695','119.35728894605995','119.357288946059953','test'),('2018-09-02 07:59:59','2018-09-02 11:59:59','XLMETH','4h','0.000778310000000','0.000777320000000','0.074748843061644','0.074653763524402','96.0399366083492','96.039936608349194','test'),('2018-09-04 11:59:59','2018-09-04 15:59:59','XLMETH','4h','0.000780150000000','0.000777020000000','0.074748843061644','0.074448947043208','95.81342442048837','95.813424420488374','test'),('2018-09-17 15:59:59','2018-09-22 03:59:59','XLMETH','4h','0.000966740000000','0.000984750000000','0.074748843061644','0.076141385693107','77.32052367921469','77.320523679214688','test'),('2018-10-03 11:59:59','2018-10-03 15:59:59','XLMETH','4h','0.001111940000000','0.001102130000000','0.074998234830591','0.074336569017968','67.44809506861027','67.448095068610272','test'),('2018-10-05 07:59:59','2018-10-05 11:59:59','XLMETH','4h','0.001115190000000','0.001094440000000','0.074998234830591','0.073602765562812','67.25153097731418','67.251530977314175','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','XLMETH','4h','0.001095870000000','0.001078980000000','0.074998234830591','0.073842331131896','68.43716392509238','68.437163925092378','test'),('2018-10-12 07:59:59','2018-10-12 23:59:59','XLMETH','4h','0.001095030000000','0.001097110000000','0.074998234830591','0.075140693328027','68.4896622289718','68.489662228971795','test'),('2018-10-16 23:59:59','2018-10-25 11:59:59','XLMETH','4h','0.001100650000000','0.001165150000000','0.074998234830591','0.079393261538966','68.13994896705674','68.139948967056739','test'),('2018-11-02 23:59:59','2018-11-04 19:59:59','XLMETH','4h','0.001180130000000','0.001161000000000','0.075329346437269','0.074108251814350','63.83139691158518','63.831396911585180','test'),('2018-11-29 11:59:59','2018-11-29 23:59:59','XLMETH','4h','0.001403520000000','0.001399620000000','0.075329346437269','0.075120026690414','53.671729962714466','53.671729962714466','test'),('2018-12-03 15:59:59','2018-12-03 19:59:59','XLMETH','4h','0.001392430000000','0.001385320000000','0.075329346437269','0.074944701138641','54.09919811930869','54.099198119308689','test'),('2019-01-08 15:59:59','2019-01-08 19:59:59','XLMETH','4h','0.000826140000000','0.000821090000000','0.075329346437269','0.074868875815452','91.1823013499758','91.182301349975802','test'),('2019-01-09 23:59:59','2019-01-10 19:59:59','XLMETH','4h','0.000827690000000','0.000838510000000','0.075329346437269','0.076314091364055','91.01154591365005','91.011545913650053','test'),('2019-01-15 23:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000871000000000','0.000857130000000','0.075329346437269','0.074129784973337','86.48604642625602','86.486046426256024','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','XLMETH','4h','0.000871260000000','0.000872500000000','0.075329346437269','0.075436557131645','86.46023740016643','86.460237400166434','test'),('2019-01-24 19:59:59','2019-01-24 23:59:59','XLMETH','4h','0.000866910000000','0.000868620000000','0.075329346437269','0.075477935313170','86.89407947453485','86.894079474534848','test'),('2019-01-26 07:59:59','2019-01-26 15:59:59','XLMETH','4h','0.000877000000000','0.000868340000000','0.075329346437269','0.074585501351583','85.89435169585975','85.894351695859754','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMETH','4h','0.000624170000000','0.000625000000000','0.075329346437269','0.075429516835627','120.68722693700275','120.687226937002748','test'),('2019-02-26 19:59:59','2019-02-26 23:59:59','XLMETH','4h','0.000622740000000','0.000618020000000','0.075329346437269','0.074758394651317','120.96436143056333','120.964361430563329','test'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XLMETH','4h','0.000623190000000','0.000616450000000','0.075329346437269','0.074514635362016','120.87701413255829','120.877014132558287','test'),('2019-02-28 23:59:59','2019-03-01 03:59:59','XLMETH','4h','0.000623030000000','0.000619640000000','0.075329346437269','0.074919468125755','120.90805649369854','120.908056493698538','test'),('2019-03-08 07:59:59','2019-03-14 15:59:59','XLMETH','4h','0.000639150000000','0.000804840000000','0.075329346437269','0.094857343638538','117.85863480758664','117.858634807586640','test'),('2019-03-27 11:59:59','2019-03-27 15:59:59','XLMETH','4h','0.000768430000000','0.000768550000000','0.079042904958303','0.079055248501105','102.86285667959672','102.862856679596717','test'),('2019-03-28 19:59:59','2019-03-28 23:59:59','XLMETH','4h','0.000770470000000','0.000771460000000','0.079045990844003','0.079147559407264','102.5945083442613','102.594508344261300','test'),('2019-03-31 23:59:59','2019-04-01 03:59:59','XLMETH','4h','0.000765480000000','0.000771150000000','0.079071382984818','0.079657073978082','103.29647147517669','103.296471475176688','test'),('2019-04-05 07:59:59','2019-04-05 15:59:59','XLMETH','4h','0.000772350000000','0.000766430000000','0.079217805733134','0.078610607688284','102.56723730579951','102.567237305799509','test'),('2019-04-07 07:59:59','2019-04-07 15:59:59','XLMETH','4h','0.000773750000000','0.000764260000000','0.079217805733134','0.078246203825015','102.38165522860614','102.381655228606135','test'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XLMETH','4h','0.000569580000000','0.000566480000000','0.079217805733134','0.078786654362347','139.0810873505636','139.081087350563593','test'),('2019-05-18 03:59:59','2019-05-18 07:59:59','XLMETH','4h','0.000570740000000','0.000558190000000','0.079217805733134','0.077475885661033','138.7984121195886','138.798412119588590','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:47:31
