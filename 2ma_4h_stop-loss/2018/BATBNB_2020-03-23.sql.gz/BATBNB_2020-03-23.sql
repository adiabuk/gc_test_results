-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-13 23:59:59','2018-05-15 19:59:59','BATBNB','4h','0.029910000000000','0.029260000000000','0.711908500000000','0.696437402540956','23.801688398528924','23.801688398528924','test'),('2018-06-20 15:59:59','2018-06-22 11:59:59','BATBNB','4h','0.016120000000000','0.016070000000000','0.711908500000000','0.709700347084367','44.163058312655096','44.163058312655096','test'),('2018-06-30 15:59:59','2018-06-30 19:59:59','BATBNB','4h','0.016730000000000','0.016270000000000','0.711908500000000','0.692334207710700','42.55280932456665','42.552809324566653','test'),('2018-08-07 07:59:59','2018-08-07 19:59:59','BATBNB','4h','0.021520000000000','0.020850000000000','0.711908500000000','0.689744062500000','33.081250000000004','33.081250000000004','test'),('2018-08-14 15:59:59','2018-08-14 19:59:59','BATBNB','4h','0.020040000000000','0.019150000000000','0.711908500000000','0.680291805139721','35.524376247504996','35.524376247504996','test'),('2018-08-14 23:59:59','2018-08-15 03:59:59','BATBNB','4h','0.020160000000000','0.019480000000000','0.711908500000000','0.687895713293651','35.31292162698413','35.312921626984128','test'),('2018-08-25 15:59:59','2018-08-25 19:59:59','BATBNB','4h','0.021000000000000','0.020720000000000','0.711908500000000','0.702416386666667','33.90040476190476','33.900404761904760','test'),('2018-08-26 15:59:59','2018-08-26 19:59:59','BATBNB','4h','0.020900000000000','0.020570000000000','0.711908500000000','0.700667839473684','34.0626076555024','34.062607655502397','test'),('2018-08-28 11:59:59','2018-08-28 15:59:59','BATBNB','4h','0.021030000000000','0.020650000000000','0.711908500000000','0.699044723014741','33.852044698050406','33.852044698050406','test'),('2018-08-31 11:59:59','2018-08-31 15:59:59','BATBNB','4h','0.020650000000000','0.020260000000000','0.711908500000000','0.698463254721550','34.47498789346247','34.474987893462469','test'),('2018-09-02 19:59:59','2018-09-03 03:59:59','BATBNB','4h','0.020730000000000','0.020470000000000','0.711908500000000','0.702979594548963','34.34194404245056','34.341944042450557','test'),('2018-09-04 15:59:59','2018-09-04 19:59:59','BATBNB','4h','0.020640000000000','0.020400000000000','0.711908500000000','0.703630494186047','34.49169089147287','34.491690891472871','test'),('2018-09-05 03:59:59','2018-09-05 07:59:59','BATBNB','4h','0.020560000000000','0.021040000000000','0.711908500000000','0.728528931906615','34.625899805447474','34.625899805447474','test'),('2018-09-20 15:59:59','2018-09-20 19:59:59','BATBNB','4h','0.016300000000000','0.016250000000000','0.711908500000000','0.709724731595092','43.67536809815952','43.675368098159517','test'),('2018-09-21 07:59:59','2018-09-21 11:59:59','BATBNB','4h','0.016570000000000','0.017360000000000','0.711908500000000','0.745849822570911','42.96369945684973','42.963699456849731','test'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BATBNB','4h','0.016680000000000','0.016260000000000','0.711908500000000','0.693982746402878','42.680365707434056','42.680365707434056','test'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BATBNB','4h','0.016900000000000','0.016600000000000','0.711908500000000','0.699271071005917','42.12476331360948','42.124763313609478','test'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BATBNB','4h','0.016860000000000','0.016980000000000','0.711908500000000','0.716975464412811','42.2247034400949','42.224703440094899','test'),('2018-10-05 15:59:59','2018-10-05 19:59:59','BATBNB','4h','0.017010000000000','0.017220000000000','0.711908500000000','0.720697493827160','41.85235155790711','41.852351557907113','test'),('2018-10-07 19:59:59','2018-10-07 23:59:59','BATBNB','4h','0.017010000000000','0.016760000000000','0.711908500000000','0.701445412110523','41.85235155790711','41.852351557907113','test'),('2018-10-08 15:59:59','2018-10-08 19:59:59','BATBNB','4h','0.016850000000000','0.016730000000000','0.711908500000000','0.706838528486647','42.24976261127597','42.249762611275969','test'),('2018-10-08 23:59:59','2018-10-09 03:59:59','BATBNB','4h','0.016850000000000','0.017000000000000','0.711908500000000','0.718245964391691','42.24976261127597','42.249762611275969','test'),('2018-10-11 19:59:59','2018-10-11 23:59:59','BATBNB','4h','0.017720000000000','0.017490000000000','0.711908500000000','0.702668152652370','40.175423250564336','40.175423250564336','test'),('2018-10-30 07:59:59','2018-10-30 15:59:59','BATBNB','4h','0.026410000000000','0.026000000000000','0.711908500000000','0.700856531616812','26.95602044680046','26.956020446800459','test'),('2018-11-16 19:59:59','2018-11-16 23:59:59','BATBNB','4h','0.028160000000000','0.028540000000000','0.711908500000000','0.721515219815341','25.28084161931818','25.280841619318181','test'),('2018-11-18 03:59:59','2018-11-18 07:59:59','BATBNB','4h','0.028300000000000','0.027370000000000','0.711908500000000','0.688513627031802','25.155777385159013','25.155777385159013','test'),('2018-11-20 15:59:59','2018-11-20 19:59:59','BATBNB','4h','0.028160000000000','0.027790000000000','0.711908500000000','0.702554588600852','25.28084161931818','25.280841619318181','test'),('2018-11-25 07:59:59','2018-11-25 11:59:59','BATBNB','4h','0.028600000000000','0.028790000000000','0.711908500000000','0.716637962062937','24.891905594405596','24.891905594405596','test'),('2018-11-26 03:59:59','2018-11-26 11:59:59','BATBNB','4h','0.028580000000000','0.028600000000000','0.711908500000000','0.712406686494052','24.909324702589224','24.909324702589224','test'),('2018-11-27 23:59:59','2018-12-04 03:59:59','BATBNB','4h','0.028740000000000','0.030790000000000','0.711908500000000','0.762688333855254','24.770650661099513','24.770650661099513','test'),('2018-12-07 15:59:59','2018-12-07 19:59:59','BATBNB','4h','0.030150000000000','0.029250000000000','0.711908500000000','0.690657500000000','23.612222222222226','23.612222222222226','test'),('2018-12-09 03:59:59','2018-12-10 03:59:59','BATBNB','4h','0.029830000000000','0.029840000000000','0.711908500000000','0.712147155212873','23.865521287294673','23.865521287294673','test'),('2018-12-10 19:59:59','2018-12-10 23:59:59','BATBNB','4h','0.029470000000000','0.029300000000000','0.711908500000000','0.707801800135731','24.157058025110285','24.157058025110285','test'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBNB','4h','0.029480000000000','0.029380000000000','0.711908500000000','0.709493613636364','24.14886363636364','24.148863636363640','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','BATBNB','4h','0.018960000000000','0.018850000000000','0.711908500000000','0.707778229166667','37.547916666666666','37.547916666666666','test'),('2019-02-14 11:59:59','2019-02-14 19:59:59','BATBNB','4h','0.014710000000000','0.014470000000000','0.711908500000000','0.700293405506458','48.3962270564242','48.396227056424202','test'),('2019-02-17 03:59:59','2019-02-19 03:59:59','BATBNB','4h','0.014450000000000','0.014340000000000','0.711908500000000','0.706489127335640','49.26702422145329','49.267024221453291','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','BATBNB','4h','0.013770000000000','0.015320000000000','0.711908500000000','0.792043443718228','51.699963689179384','51.699963689179384','test'),('2019-03-02 07:59:59','2019-03-02 19:59:59','BATBNB','4h','0.016330000000000','0.016050000000000','0.711908500000000','0.699701863135334','43.59513165952235','43.595131659522352','test'),('2019-03-04 19:59:59','2019-03-04 23:59:59','BATBNB','4h','0.015060000000000','0.014670000000000','0.711908500000000','0.693472622509960','47.2714807436919','47.271480743691903','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','BATBNB','4h','0.014060000000000','0.013610000000000','0.711908500000000','0.689123377311522','50.63360597439545','50.633605974395451','test'),('2019-03-09 19:59:59','2019-03-10 23:59:59','BATBNB','4h','0.014000000000000','0.013660000000000','0.711908500000000','0.694619293571429','50.85060714285714','50.850607142857143','test'),('2019-03-21 07:59:59','2019-03-22 15:59:59','BATBNB','4h','0.012990000000000','0.013160000000000','0.711908500000000','0.721225239414935','54.80434949961509','54.804349499615093','test'),('2019-03-26 11:59:59','2019-03-26 15:59:59','BATBNB','4h','0.013180000000000','0.013460000000000','0.711908500000000','0.727032504552352','54.01430197268589','54.014301972685892','test'),('2019-04-05 07:59:59','2019-04-05 19:59:59','BATBNB','4h','0.015290000000000','0.016220000000000','0.711908500000000','0.755209671026815','46.56039895356442','46.560398953564423','test'),('2019-04-11 15:59:59','2019-04-11 23:59:59','BATBNB','4h','0.015970000000000','0.015270000000000','0.711908500000000','0.680703994677520','44.5778647463995','44.577864746399499','test'),('2019-04-12 23:59:59','2019-04-13 03:59:59','BATBNB','4h','0.015620000000000','0.016010000000000','0.711908500000000','0.729683424135723','45.57672855313701','45.576728553137009','test'),('2019-04-15 07:59:59','2019-04-15 11:59:59','BATBNB','4h','0.016050000000000','0.015400000000000','0.711908500000000','0.683077314641745','44.355669781931475','44.355669781931475','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','BATBNB','4h','0.016070000000000','0.016050000000000','0.711908500000000','0.711022490665837','44.30046670815184','44.300466708151838','test'),('2019-04-20 15:59:59','2019-04-20 23:59:59','BATBNB','4h','0.017200000000000','0.016570000000000','0.711908500000000','0.685832781686047','41.390029069767444','41.390029069767444','test'),('2019-04-23 15:59:59','2019-04-25 23:59:59','BATBNB','4h','0.017100000000000','0.017320000000000','0.711908500000000','0.721067556725146','41.63207602339182','41.632076023391818','test'),('2019-04-27 19:59:59','2019-04-28 11:59:59','BATBNB','4h','0.017550000000000','0.017800000000000','0.711908500000000','0.722049646723647','40.564586894586895','40.564586894586895','test'),('2019-04-30 11:59:59','2019-04-30 19:59:59','BATBNB','4h','0.017610000000000','0.017670000000000','0.711908500000000','0.714334082623509','40.42637705848949','40.426377058489493','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  2:50:41
