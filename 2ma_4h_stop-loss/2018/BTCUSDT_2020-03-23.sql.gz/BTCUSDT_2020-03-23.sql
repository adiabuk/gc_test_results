-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-12 19:59:59','2018-02-12 23:59:59','BTCUSDT','4h','8792.760000000000218','8903.000000000000000','15.000000000000000','15.188063816139643','0.0017059489853015436','0.001705948985302','test'),('2018-02-14 07:59:59','2018-02-21 03:59:59','BTCUSDT','4h','8870.170000000000073','10915.340000000000146','15.047015954034912','18.516363849138791','0.0016963616203561952','0.001696361620356','test'),('2018-02-23 15:59:59','2018-02-23 19:59:59','BTCUSDT','4h','10292.000000000000000','10033.000000000000000','15.914352927810882','15.513865422145994','0.0015462838056559348','0.001546283805656','test'),('2018-02-24 03:59:59','2018-02-24 07:59:59','BTCUSDT','4h','10400.000000000000000','10119.159999999999854','15.914352927810882','15.484604189710264','0.0015302262430587387','0.001530226243059','test'),('2018-02-26 15:59:59','2018-03-06 15:59:59','BTCUSDT','4h','10260.920000000000073','10966.000000000000000','15.914352927810882','17.007909057508890','0.0015509674500737635','0.001550967450074','test'),('2018-03-20 19:59:59','2018-03-22 11:59:59','BTCUSDT','4h','8950.000000000000000','8642.010000000000218','15.980182899294007','15.430268203075732','0.0017854952960105037','0.001785495296011','test'),('2018-03-23 23:59:59','2018-03-24 11:59:59','BTCUSDT','4h','8898.030000000000655','8723.000000000000000','15.980182899294007','15.665842375283249','0.0017959236931426401','0.001795923693143','test'),('2018-04-12 11:59:59','2018-05-01 03:59:59','BTCUSDT','4h','7690.000000000000000','8938.010000000000218','15.980182899294007','18.573606574215717','0.0020780471910655405','0.002078047191066','test'),('2018-05-01 19:59:59','2018-05-07 03:59:59','BTCUSDT','4h','8979.520000000000437','9350.020000000000437','16.412475012967175','17.089662879613090','0.001827767521311515','0.001827767521312','test'),('2018-05-10 03:59:59','2018-05-10 07:59:59','BTCUSDT','4h','9344.889999999999418','9369.000000000000000','16.581771979628655','16.624553277474735','0.0017744213125706837','0.001774421312571','test'),('2018-05-21 07:59:59','2018-05-21 11:59:59','BTCUSDT','4h','8540.000000000000000','8469.979999999999563','16.592467304090174','16.456424615491532','0.001942911862305641','0.001942911862306','test'),('2018-06-02 11:59:59','2018-06-02 15:59:59','BTCUSDT','4h','7652.279999999999745','7623.100000000000364','16.592467304090174','16.529196201107361','0.0021683037348463694','0.002168303734846','test'),('2018-06-05 23:59:59','2018-06-06 03:59:59','BTCUSDT','4h','7625.000000000000000','7595.000000000000000','16.592467304090174','16.527185465516705','0.002176061285782318','0.002176061285782','test'),('2018-06-06 23:59:59','2018-06-08 07:59:59','BTCUSDT','4h','7658.840000000000146','7627.880000000000109','16.592467304090174','16.525394119673912','0.0021664465250730105','0.002166446525073','test'),('2018-06-08 19:59:59','2018-06-08 23:59:59','BTCUSDT','4h','7641.130000000000109','7603.439999999999600','16.592467304090174','16.510624684910660','0.0021714677415631163','0.002171467741563','test'),('2018-06-09 03:59:59','2018-06-09 11:59:59','BTCUSDT','4h','7661.149999999999636','7635.010000000000218','16.592467304090174','16.535853467351707','0.002165793295274231','0.002165793295274','test'),('2018-06-21 03:59:59','2018-06-21 07:59:59','BTCUSDT','4h','6772.409999999999854','6758.720000000000255','16.592467304090174','16.558926677135666','0.002450009273521564','0.002450009273522','test'),('2018-06-30 03:59:59','2018-07-01 15:59:59','BTCUSDT','4h','6366.000000000000000','6316.579999999999927','16.592467304090174','16.463658046445165','0.0026064196204979855','0.002606419620498','test'),('2018-07-16 11:59:59','2018-07-31 15:59:59','BTCUSDT','4h','6635.569999999999709','7758.439999999999600','16.592467304090174','19.400241732171519','0.0025005338356901027','0.002500533835690','test'),('2018-08-17 23:59:59','2018-08-18 03:59:59','BTCUSDT','4h','6584.489999999999782','6524.989999999999782','17.136292122338340','16.981441954553269','0.0026025238283205443','0.002602523828321','test'),('2018-08-22 03:59:59','2018-08-22 07:59:59','BTCUSDT','4h','6726.010000000000218','6653.550000000000182','17.136292122338340','16.951681078467661','0.002547764889189629','0.002547764889190','test'),('2018-08-23 23:59:59','2018-08-24 03:59:59','BTCUSDT','4h','6525.010000000000218','6495.000000000000000','17.136292122338340','17.057478430621181','0.0026262476413581493','0.002626247641358','test'),('2018-09-14 03:59:59','2018-09-14 11:59:59','BTCUSDT','4h','6542.369999999999891','6459.279999999999745','17.136292122338340','16.918656233135330','0.002619278965013954','0.002619278965014','test'),('2018-09-15 11:59:59','2018-09-15 15:59:59','BTCUSDT','4h','6523.510000000000218','6542.220000000000255','17.136292122338340','17.185440514171717','0.002626851514344017','0.002626851514344','test'),('2018-09-17 03:59:59','2018-09-17 07:59:59','BTCUSDT','4h','6517.159999999999854','6480.010000000000218','17.136292122338340','17.038609504089766','0.002629410989194425','0.002629410989194','test'),('2018-09-20 23:59:59','2018-09-24 23:59:59','BTCUSDT','4h','6492.000000000000000','6581.390000000000327','17.136292122338340','17.372246089192288','0.0026396013743589554','0.002639601374359','test'),('2018-09-27 19:59:59','2018-09-28 19:59:59','BTCUSDT','4h','6669.359999999999673','6684.000000000000000','17.136292122338340','17.173908222934354','0.002569405778416271','0.002569405778416','test'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BTCUSDT','4h','6584.960000000000036','6589.010000000000218','17.136292122338340','17.146831591537161','0.0026023380737830357','0.002602338073783','test'),('2018-10-04 03:59:59','2018-10-04 23:59:59','BTCUSDT','4h','6598.510000000000218','6593.789999999999964','17.136292122338340','17.124034309768920','0.0025969941884362285','0.002596994188436','test'),('2018-10-07 15:59:59','2018-10-07 19:59:59','BTCUSDT','4h','6582.069999999999709','6584.000000000000000','17.136292122338340','17.141316840063329','0.0026034806865223767','0.002603480686522','test'),('2018-10-10 19:59:59','2018-10-11 03:59:59','BTCUSDT','4h','6635.960000000000036','6340.520000000000437','17.136292122338340','16.373366163679211','0.002582338067489608','0.002582338067490','test'),('2018-10-15 07:59:59','2018-10-15 19:59:59','BTCUSDT','4h','6860.250000000000000','6741.000000000000000','17.136292122338340','16.838416267145185','0.0024979107353723757','0.002497910735372','test'),('2018-10-21 03:59:59','2018-10-21 23:59:59','BTCUSDT','4h','6616.619999999999891','6590.109999999999673','17.136292122338340','17.067634242006207','0.0025898860932527996','0.002589886093253','test'),('2018-10-24 07:59:59','2018-10-24 15:59:59','BTCUSDT','4h','6610.939999999999600','6581.000000000000000','17.136292122338340','17.058684310719599','0.0025921112765111072','0.002592111276511','test'),('2018-11-04 15:59:59','2018-11-05 11:59:59','BTCUSDT','4h','6479.989999999999782','6452.840000000000146','17.136292122338340','17.064494120933787','0.002644493606060864','0.002644493606061','test'),('2018-11-13 19:59:59','2018-11-13 23:59:59','BTCUSDT','4h','6461.300000000000182','6457.659999999999854','17.136292122338340','17.126638321504867','0.0026521430861186353','0.002652143086119','test'),('2018-11-14 01:59:59','2018-11-14 11:59:59','BTCUSDT','4h','6472.000000000000000','6381.880000000000109','17.136292122338340','16.897676138706522','0.002647758362536826','0.002647758362537','test'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BTCUSDT','4h','3535.610000000000127','3490.849999999999909','17.136292122338340','16.919350651023382','0.004846771030271534','0.004846771030272','test'),('2018-12-26 03:59:59','2018-12-26 07:59:59','BTCUSDT','4h','3795.230000000000018','3743.449999999999818','17.136292122338340','16.902494116395438','0.0045152183457493585','0.004515218345749','test'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BTCUSDT','4h','3777.739999999999782','3711.590000000000146','17.136292122338340','16.836227606545119','0.004536122687728203','0.004536122687728','test'),('2018-12-28 19:59:59','2018-12-29 23:59:59','BTCUSDT','4h','3819.539999999999964','3695.320000000000164','17.136292122338340','16.578981501835120','0.004486480602988407','0.004486480602988','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','BTCUSDT','4h','3785.929999999999836','3768.000000000000000','17.136292122338340','17.055135387334385','0.004526309816171545','0.004526309816172','test'),('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','17.136292122338340','16.950629476791164','0.004512947145045571','0.004512947145046','test'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','17.136292122338340','17.041166068035945','0.004519052460921342','0.004519052460921','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3580.000000000000000','17.136292122338340','16.601249613834369','0.004637220562523567','0.004637220562524','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','17.136292122338340','16.991224935989834','0.004733024024421043','0.004733024024421','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:15:37
