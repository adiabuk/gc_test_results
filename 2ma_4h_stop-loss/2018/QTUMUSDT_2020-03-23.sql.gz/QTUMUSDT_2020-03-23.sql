-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-20 23:59:59','2018-09-21 03:59:59','QTUMUSDT','4h','3.555000000000000','3.553000000000000','15.000000000000000','14.991561181434598','4.219409282700422','4.219409282700422','test'),('2018-09-26 15:59:59','2018-09-26 19:59:59','QTUMUSDT','4h','3.714000000000000','3.677000000000000','15.000000000000000','14.850565428109855','4.038772213247173','4.038772213247173','test'),('2018-09-27 15:59:59','2018-09-29 03:59:59','QTUMUSDT','4h','3.870000000000000','3.758000000000000','15.000000000000000','14.565891472868216','3.875968992248062','3.875968992248062','test'),('2018-10-04 03:59:59','2018-10-04 07:59:59','QTUMUSDT','4h','3.813000000000000','3.761000000000000','15.000000000000000','14.795436664044059','3.9339103068450036','3.933910306845004','test'),('2018-10-04 15:59:59','2018-10-04 23:59:59','QTUMUSDT','4h','3.813000000000000','3.783000000000000','15.000000000000000','14.881982690794649','3.9339103068450036','3.933910306845004','test'),('2018-10-05 23:59:59','2018-10-06 03:59:59','QTUMUSDT','4h','3.831000000000000','3.783000000000000','15.000000000000000','14.812059514487078','3.9154267815191854','3.915426781519185','test'),('2018-10-07 03:59:59','2018-10-07 07:59:59','QTUMUSDT','4h','3.793000000000000','3.745000000000000','15.000000000000000','14.810176641181123','3.9546533087266016','3.954653308726602','test'),('2018-10-07 19:59:59','2018-10-09 15:59:59','QTUMUSDT','4h','3.804000000000000','3.825000000000000','15.000000000000000','15.082807570977920','3.9432176656151423','3.943217665615142','test'),('2018-10-10 15:59:59','2018-10-11 03:59:59','QTUMUSDT','4h','3.918000000000000','3.650000000000000','15.000000000000000','13.973966309341501','3.8284839203675345','3.828483920367534','test'),('2018-10-15 11:59:59','2018-10-15 19:59:59','QTUMUSDT','4h','3.775000000000000','3.662000000000000','15.000000000000000','14.550993377483444','3.9735099337748347','3.973509933774835','test'),('2018-10-27 03:59:59','2018-10-27 15:59:59','QTUMUSDT','4h','4.117000000000000','4.058000000000000','15.000000000000000','14.785037648773377','3.643429681807141','3.643429681807141','test'),('2018-11-02 15:59:59','2018-11-02 19:59:59','QTUMUSDT','4h','3.969000000000000','3.969000000000000','15.000000000000000','15.000000000000000','3.779289493575208','3.779289493575208','test'),('2018-11-04 15:59:59','2018-11-05 03:59:59','QTUMUSDT','4h','3.967000000000000','3.963000000000000','15.000000000000000','14.984875220569700','3.7811948575749934','3.781194857574993','test'),('2018-11-06 11:59:59','2018-11-08 03:59:59','QTUMUSDT','4h','3.974000000000000','3.990000000000000','15.000000000000000','15.060392551585304','3.7745344740815296','3.774534474081530','test'),('2018-12-13 07:59:59','2018-12-13 19:59:59','QTUMUSDT','4h','1.858000000000000','1.795000000000000','15.000000000000000','14.491388589881591','8.073196986006458','8.073196986006458','test'),('2018-12-17 15:59:59','2018-12-24 11:59:59','QTUMUSDT','4h','1.946000000000000','2.771000000000000','15.000000000000000','21.359198355601233','7.708119218910586','7.708119218910586','test'),('2018-12-28 19:59:59','2018-12-29 11:59:59','QTUMUSDT','4h','2.313000000000000','2.262000000000000','15.749083304283412','15.401827252178588','6.80894219813377','6.808942198133770','test'),('2018-12-30 11:59:59','2018-12-30 15:59:59','QTUMUSDT','4h','2.269000000000000','2.271000000000000','15.749083304283412','15.762965264005125','6.940979860856506','6.940979860856506','test'),('2019-01-02 19:59:59','2019-01-03 07:59:59','QTUMUSDT','4h','2.286000000000000','2.257000000000000','15.749083304283412','15.549291783800376','6.889362775277083','6.889362775277083','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','QTUMUSDT','4h','2.243000000000000','2.205000000000000','15.749083304283412','15.482268696364212','7.021437050505311','7.021437050505311','test'),('2019-01-06 15:59:59','2019-01-07 11:59:59','QTUMUSDT','4h','2.261000000000000','2.261000000000000','15.749083304283412','15.749083304283412','6.965538834269531','6.965538834269531','test'),('2019-01-08 11:59:59','2019-01-08 19:59:59','QTUMUSDT','4h','2.283000000000000','2.249000000000000','15.749083304283412','15.514537166593691','6.898415814403597','6.898415814403597','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','QTUMUSDT','4h','2.228000000000000','2.165000000000000','15.749083304283412','15.303754647115612','7.068708843933308','7.068708843933308','test'),('2019-01-19 15:59:59','2019-01-19 19:59:59','QTUMUSDT','4h','2.135000000000000','2.136000000000000','15.749083304283412','15.756459924098065','7.376619814652653','7.376619814652653','test'),('2019-01-20 03:59:59','2019-01-20 07:59:59','QTUMUSDT','4h','2.135000000000000','2.115000000000000','15.749083304283412','15.601550907990362','7.376619814652653','7.376619814652653','test'),('2019-02-08 15:59:59','2019-02-10 11:59:59','QTUMUSDT','4h','1.880000000000000','1.886000000000000','15.749083304283412','15.799346336105595','8.377171970363518','8.377171970363518','test'),('2019-02-14 15:59:59','2019-02-14 23:59:59','QTUMUSDT','4h','1.903000000000000','1.886000000000000','15.749083304283412','15.608392596888340','8.275923964415876','8.275923964415876','test'),('2019-02-15 03:59:59','2019-02-15 07:59:59','QTUMUSDT','4h','1.896000000000000','1.902000000000000','15.749083304283412','15.798922175499499','8.306478536014458','8.306478536014458','test'),('2019-02-25 19:59:59','2019-02-25 23:59:59','QTUMUSDT','4h','2.110000000000000','2.079000000000000','15.749083304283412','15.517698668059344','7.464020523357068','7.464020523357068','test'),('2019-02-27 07:59:59','2019-02-27 11:59:59','QTUMUSDT','4h','2.094000000000000','2.077000000000000','15.749083304283412','15.621225416903844','7.521052198798191','7.521052198798191','test'),('2019-03-01 03:59:59','2019-03-01 11:59:59','QTUMUSDT','4h','2.163000000000000','2.122000000000000','15.749083304283412','15.450556991072308','7.281129590514754','7.281129590514754','test'),('2019-03-05 23:59:59','2019-03-06 03:59:59','QTUMUSDT','4h','2.061000000000000','2.022000000000000','15.749083304283412','15.451065716283869','7.641476615372834','7.641476615372834','test'),('2019-03-06 11:59:59','2019-03-06 15:59:59','QTUMUSDT','4h','2.060000000000000','2.050000000000000','15.749083304283412','15.672631443583004','7.6451860700404906','7.645186070040491','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','QTUMUSDT','4h','2.073000000000000','2.059000000000000','15.749083304283412','15.642721911972767','7.597242307903238','7.597242307903238','test'),('2019-03-07 15:59:59','2019-03-08 11:59:59','QTUMUSDT','4h','2.077000000000000','2.059000000000000','15.749083304283412','15.612596304053707','7.582611123872611','7.582611123872611','test'),('2019-03-12 11:59:59','2019-03-13 11:59:59','QTUMUSDT','4h','2.111000000000000','2.123000000000000','15.749083304283412','15.838609121266547','7.460484748594699','7.460484748594699','test'),('2019-03-27 03:59:59','2019-04-03 23:59:59','QTUMUSDT','4h','2.514000000000000','3.196000000000000','15.749083304283412','20.021507653337228','6.264551831457204','6.264551831457204','test'),('2019-05-02 15:59:59','2019-05-02 19:59:59','QTUMUSDT','4h','2.637000000000000','2.590000000000000','16.105649277159376','15.818593715526273','6.107565141129835','6.107565141129835','test'),('2019-05-11 11:59:59','2019-05-12 03:59:59','QTUMUSDT','4h','2.486000000000000','2.509000000000000','16.105649277159376','16.254655686400994','6.478539532244318','6.478539532244318','test'),('2019-05-13 11:59:59','2019-05-16 07:59:59','QTUMUSDT','4h','2.474000000000000','3.320000000000000','16.105649277159376','21.613078253908295','6.509963329490451','6.509963329490451','test'),('2019-05-24 07:59:59','2019-05-25 07:59:59','QTUMUSDT','4h','2.936000000000000','2.882000000000000','17.447994233248732','17.127084257569091','5.942777327400794','5.942777327400794','test'),('2019-05-26 07:59:59','2019-05-26 11:59:59','QTUMUSDT','4h','2.916000000000000','2.830000000000000','17.447994233248732','16.933410041184469','5.983537117026314','5.983537117026314','test'),('2019-05-26 19:59:59','2019-05-30 23:59:59','QTUMUSDT','4h','2.974000000000000','3.114000000000000','17.447994233248732','18.269352401592649','5.866844059599439','5.866844059599439','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','QTUMUSDT','4h','3.238000000000000','3.183000000000000','17.447994233248732','17.151626202727211','5.38850964584581','5.388509645845810','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','QTUMUSDT','4h','3.149000000000000','3.156000000000000','17.447994233248732','17.486779866666563','5.540804773975463','5.540804773975463','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','QTUMUSDT','4h','5.181000000000000','5.113000000000000','17.447994233248732','17.218991413742671','3.367688522147989','3.367688522147989','test'),('2019-07-06 03:59:59','2019-07-06 07:59:59','QTUMUSDT','4h','4.833000000000000','4.857000000000000','17.447994233248732','17.534638524909806','3.610178819211407','3.610178819211407','test'),('2019-07-07 23:59:59','2019-07-08 07:59:59','QTUMUSDT','4h','4.842000000000000','4.812000000000000','17.447994233248732','17.339890179758964','3.60346844965897','3.603468449658970','test'),('2019-07-31 15:59:59','2019-07-31 19:59:59','QTUMUSDT','4h','3.072000000000000','2.997000000000000','17.447994233248732','17.022017811538557','5.679685622802322','5.679685622802322','test'),('2019-07-31 23:59:59','2019-08-01 03:59:59','QTUMUSDT','4h','3.057000000000000','2.999000000000000','17.447994233248732','17.116956069843948','5.707554541461803','5.707554541461803','test'),('2019-08-02 07:59:59','2019-08-02 19:59:59','QTUMUSDT','4h','3.061000000000000','2.994000000000000','17.447994233248732','17.066087792991411','5.700096123243624','5.700096123243624','test'),('2019-08-03 03:59:59','2019-08-03 11:59:59','QTUMUSDT','4h','3.090000000000000','3.035000000000000','17.447994233248732','17.137431229097057','5.6466000754850265','5.646600075485027','test'),('2019-08-05 03:59:59','2019-08-06 03:59:59','QTUMUSDT','4h','3.056000000000000','3.035000000000000','17.447994233248732','17.328096367117116','5.709422196743695','5.709422196743695','test'),('2019-08-18 15:59:59','2019-08-18 23:59:59','QTUMUSDT','4h','2.615000000000000','2.545000000000000','17.447994233248732','16.980935114194271','6.672273129349419','6.672273129349419','test'),('2019-08-19 03:59:59','2019-08-19 11:59:59','QTUMUSDT','4h','2.733000000000000','2.690000000000000','17.447994233248732','17.173474016626084','6.384191084247615','6.384191084247615','test'),('2019-08-23 15:59:59','2019-08-23 23:59:59','QTUMUSDT','4h','2.592000000000000','2.603000000000000','17.447994233248732','17.522040505071935','6.731479256654604','6.731479256654604','test'),('2019-08-25 03:59:59','2019-08-25 07:59:59','QTUMUSDT','4h','2.587000000000000','2.586000000000000','17.447994233248732','17.441249743788642','6.744489460088415','6.744489460088415','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  4:12:34
