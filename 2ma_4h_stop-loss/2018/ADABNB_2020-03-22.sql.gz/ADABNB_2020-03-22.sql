-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-10-08 15:59:59','2018-10-11 03:59:59','ADABNB','4h','0.008230000000000','0.007920000000000','0.711908500000000','0.685092991494532','86.50164034021873','86.501640340218728','test'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ADABNB','4h','0.007920000000000','0.007830000000000','0.711908500000000','0.703818630681818','89.88743686868688','89.887436868686876','test'),('2018-10-19 19:59:59','2018-10-19 23:59:59','ADABNB','4h','0.007790000000000','0.007780000000000','0.711908500000000','0.710994625160462','91.38748395378691','91.387483953786912','test'),('2018-11-02 19:59:59','2018-11-02 23:59:59','ADABNB','4h','0.007560000000000','0.007590000000000','0.711908500000000','0.714733533730159','94.16779100529101','94.167791005291008','test'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABNB','4h','0.007560000000000','0.007780000000000','0.711908500000000','0.732625414021164','94.16779100529101','94.167791005291008','test'),('2018-11-10 07:59:59','2018-11-10 11:59:59','ADABNB','4h','0.007820000000000','0.007820000000000','0.711908500000000','0.711908500000000','91.0368925831202','91.036892583120206','test'),('2018-11-17 23:59:59','2018-11-18 03:59:59','ADABNB','4h','0.007820000000000','0.007980000000000','0.711908500000000','0.726474402813299','91.0368925831202','91.036892583120206','test'),('2018-11-20 11:59:59','2018-11-20 15:59:59','ADABNB','4h','0.008000000000000','0.007870000000000','0.712480649475358','0.700902838921383','89.06008118441981','89.060081184419815','test'),('2018-11-21 11:59:59','2018-11-21 15:59:59','ADABNB','4h','0.007830000000000','0.007740000000000','0.712480649475358','0.704291216722768','90.99369725100358','90.993697251003582','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','ADABNB','4h','0.007830000000000','0.007770000000000','0.712480649475358','0.707021027640298','90.99369725100358','90.993697251003582','test'),('2018-11-24 03:59:59','2018-11-24 07:59:59','ADABNB','4h','0.007820000000000','0.007820000000000','0.712480649475358','0.712480649475358','91.11005747766727','91.110057477667269','test'),('2018-11-28 19:59:59','2018-11-29 03:59:59','ADABNB','4h','0.007890000000000','0.007750000000000','0.712480649475358','0.699838407279344','90.30172997152827','90.301729971528275','test'),('2018-11-30 23:59:59','2018-12-01 03:59:59','ADABNB','4h','0.007670000000000','0.007600000000000','0.712480649475358','0.705978218515348','92.89187085728267','92.891870857282669','test'),('2018-12-01 11:59:59','2018-12-02 19:59:59','ADABNB','4h','0.007710000000000','0.007870000000000','0.712480649475358','0.727266240125949','92.4099415661943','92.409941566194306','test'),('2018-12-17 19:59:59','2018-12-17 23:59:59','ADABNB','4h','0.006550000000000','0.006410000000000','0.712480649475358','0.697252055440770','108.77567167562718','108.775671675627180','test'),('2018-12-19 03:59:59','2018-12-19 07:59:59','ADABNB','4h','0.006570000000000','0.006530000000000','0.712480649475358','0.708142867743392','108.44454329914124','108.444543299141245','test'),('2018-12-20 15:59:59','2018-12-27 19:59:59','ADABNB','4h','0.006500000000000','0.006980000000000','0.712480649475358','0.765094605128923','109.61240761159355','109.612407611593554','test'),('2018-12-28 19:59:59','2018-12-28 23:59:59','ADABNB','4h','0.007070000000000','0.006980000000000','0.713346057535347','0.704265273210286','100.89760361178875','100.897603611788753','test'),('2018-12-29 03:59:59','2018-12-29 07:59:59','ADABNB','4h','0.007060000000000','0.007010000000000','0.713346057535347','0.708294031632122','101.04051806449674','101.040518064496737','test'),('2018-12-29 11:59:59','2018-12-29 15:59:59','ADABNB','4h','0.007020000000000','0.007290000000000','0.713346057535347','0.740782444363629','101.61624751215768','101.616247512157685','test'),('2019-01-02 07:59:59','2019-01-04 15:59:59','ADABNB','4h','0.007080000000000','0.007080000000000','0.716671951685346','0.716671951685346','101.22485193295842','101.224851932958416','test'),('2019-01-08 23:59:59','2019-01-09 03:59:59','ADABNB','4h','0.007340000000000','0.007530000000000','0.716671951685346','0.735223405475566','97.63923047484278','97.639230474842776','test'),('2019-01-09 11:59:59','2019-01-10 15:59:59','ADABNB','4h','0.007510000000000','0.007430000000000','0.721309815132901','0.713626088740007','96.04657991117185','96.046579911171847','test'),('2019-01-16 07:59:59','2019-01-16 11:59:59','ADABNB','4h','0.007380000000000','0.007340000000000','0.721309815132901','0.717400276839498','97.73845733508143','97.738457335081435','test'),('2019-01-17 03:59:59','2019-01-17 07:59:59','ADABNB','4h','0.007400000000000','0.007300000000000','0.721309815132901','0.711562385198673','97.47429934228393','97.474299342283928','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','ADABNB','4h','0.006490000000000','0.006450000000000','0.721309815132901','0.716864146010356','111.14172806362112','111.141728063621116','test'),('2019-02-18 15:59:59','2019-02-18 23:59:59','ADABNB','4h','0.004740000000000','0.004740000000000','0.721309815132901','0.721309815132901','152.17506648373438','152.175066483734383','test'),('2019-02-24 03:59:59','2019-02-24 11:59:59','ADABNB','4h','0.004570000000000','0.004500000000000','0.721309815132901','0.710261305929552','157.83584576212274','157.835845762122744','test'),('2019-02-25 23:59:59','2019-02-26 03:59:59','ADABNB','4h','0.004500000000000','0.004470000000000','0.721309815132901','0.716501083032015','160.29107002953359','160.291070029533586','test'),('2019-02-26 07:59:59','2019-02-26 11:59:59','ADABNB','4h','0.004500000000000','0.004520000000000','0.721309815132901','0.724515636533492','160.29107002953359','160.291070029533586','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','ADABNB','4h','0.003310000000000','0.003310000000000','0.721309815132901','0.721309815132901','217.91837315193385','217.918373151933849','test'),('2019-03-19 15:59:59','2019-03-24 11:59:59','ADABNB','4h','0.003300000000000','0.003600000000000','0.721309815132901','0.786883434690437','218.57873185845486','218.578731858454859','test'),('2019-03-25 11:59:59','2019-03-25 15:59:59','ADABNB','4h','0.003640000000000','0.003510000000000','0.728093774110606','0.702090425035227','200.02576211829833','200.025762118298331','test'),('2019-03-26 03:59:59','2019-04-01 11:59:59','ADABNB','4h','0.003610000000000','0.003860000000000','0.728093774110606','0.778515780627961','201.68802606941998','201.688026069419976','test'),('2019-04-01 19:59:59','2019-04-12 19:59:59','ADABNB','4h','0.003990000000000','0.004570000000000','0.734198438471100','0.840924026018278','184.0096337020301','184.009633702030101','test'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ADABNB','4h','0.004610000000000','0.004600000000000','0.760879835357894','0.759229336799634','165.04985582600747','165.049855826007473','test'),('2019-05-08 03:59:59','2019-05-08 07:59:59','ADABNB','4h','0.003080000000000','0.003060000000000','0.760879835357894','0.755939057206219','247.03890758373186','247.038907583731856','test'),('2019-05-08 11:59:59','2019-05-08 15:59:59','ADABNB','4h','0.003200000000000','0.003110000000000','0.760879835357894','0.739480089988453','237.77494854934187','237.774948549341872','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','ADABNB','4h','0.003130000000000','0.003070000000000','0.760879835357894','0.746294279408541','243.09259915587668','243.092599155876684','test'),('2019-05-13 15:59:59','2019-05-13 19:59:59','ADABNB','4h','0.003270000000000','0.003160000000000','0.760879835357894','0.735284489214356','232.68496494125202','232.684964941252019','test'),('2019-05-14 03:59:59','2019-05-14 11:59:59','ADABNB','4h','0.003260000000000','0.003270000000000','0.760879835357894','0.763213822582918','233.3987225024215','233.398722502421492','test'),('2019-05-27 23:59:59','2019-05-28 03:59:59','ADABNB','4h','0.002700000000000','0.002620000000000','0.760879835357894','0.738335247643586','281.80734642884966','281.807346428849655','test'),('2019-05-28 15:59:59','2019-05-29 07:59:59','ADABNB','4h','0.002710000000000','0.002670000000000','0.760879835357894','0.749649136681025','280.7674669217321','280.767466921732080','test'),('2019-05-29 15:59:59','2019-05-29 23:59:59','ADABNB','4h','0.002750000000000','0.002700000000000','0.760879835357894','0.747045656533205','276.6835764937797','276.683576493779697','test'),('2019-06-01 03:59:59','2019-06-01 07:59:59','ADABNB','4h','0.002730000000000','0.002670000000000','0.760879835357894','0.744157201613765','278.71056240215904','278.710562402159042','test'),('2019-06-02 03:59:59','2019-06-04 11:59:59','ADABNB','4h','0.002820000000000','0.002770000000000','0.760879835357894','0.747389058135236','269.8155444531539','269.815544453153905','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ADABNB','4h','0.002780000000000','0.002740000000000','0.760879835357894','0.749931924057780','273.6977825028396','273.697782502839573','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','ADABNB','4h','0.002800000000000','0.002750000000000','0.760879835357894','0.747292695440789','271.742798342105','271.742798342105004','test'),('2019-06-14 11:59:59','2019-06-14 15:59:59','ADABNB','4h','0.002780000000000','0.002780000000000','0.760879835357894','0.760879835357894','273.6977825028396','273.697782502839573','test'),('2019-06-23 15:59:59','2019-06-23 19:59:59','ADABNB','4h','0.002670000000000','0.002600000000000','0.760879835357894','0.740931674880346','284.9737211078255','284.973721107825497','test'),('2019-07-01 07:59:59','2019-07-01 11:59:59','ADABNB','4h','0.002600000000000','0.002510000000000','0.760879835357894','0.734541687210890','292.64609052226695','292.646090522266945','test'),('2019-07-26 07:59:59','2019-08-01 07:59:59','ADABNB','4h','0.002077000000000','0.002114000000000','0.760879835357894','0.774434266705146','366.335982358158','366.335982358157992','test'),('2019-08-18 19:59:59','2019-08-19 07:59:59','ADABNB','4h','0.001800000000000','0.001753000000000','0.760879835357894','0.741012417434660','422.7110196432745','422.711019643274483','test'),('2019-08-22 03:59:59','2019-08-22 11:59:59','ADABNB','4h','0.001795000000000','0.001792000000000','0.760879835357894','0.759608169894900','423.88848766456493','423.888487664564934','test'),('2019-09-06 23:59:59','2019-09-07 03:59:59','ADABNB','4h','0.002010000000000','0.001981000000000','0.760879835357894','0.749901967086561','378.54718177009653','378.547181770096529','test'),('2019-09-07 15:59:59','2019-09-18 11:59:59','ADABNB','4h','0.002020000000000','0.002256000000000','0.760879835357894','0.849774707211589','376.6731858207396','376.673185820739604','test'),('2019-09-24 23:59:59','2019-09-29 07:59:59','ADABNB','4h','0.002354000000000','0.002406000000000','0.760879835357894','0.777687716172937','323.2284772123594','323.228477212359394','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  0:11:24
