-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-02 19:59:59','2018-03-02 23:59:59','STRATETH','4h','0.009554000000000','0.009377000000000','0.072144500000000','0.070807931389994','7.5512350847812435','7.551235084781244','test'),('2018-03-18 19:59:59','2018-03-18 23:59:59','STRATETH','4h','0.008200000000000','0.008006000000000','0.072144500000000','0.070437666707317','8.79810975609756','8.798109756097560','test'),('2018-04-02 15:59:59','2018-04-02 23:59:59','STRATETH','4h','0.009551000000000','0.009450000000000','0.072144500000000','0.071381585697833','7.553606952151607','7.553606952151607','test'),('2018-04-06 23:59:59','2018-04-08 11:59:59','STRATETH','4h','0.009535000000000','0.009465000000000','0.072144500000000','0.071614860251704','7.56628211851075','7.566282118510750','test'),('2018-04-11 11:59:59','2018-04-11 15:59:59','STRATETH','4h','0.009473000000000','0.009518000000000','0.072144500000000','0.072487211126359','7.615802807980576','7.615802807980576','test'),('2018-04-13 11:59:59','2018-04-13 15:59:59','STRATETH','4h','0.009538000000000','0.009638000000000','0.072144500000000','0.072900890228559','7.563902285594464','7.563902285594464','test'),('2018-04-14 07:59:59','2018-04-14 11:59:59','STRATETH','4h','0.009350000000000','0.009343000000000','0.072144500000000','0.072090488074866','7.715989304812834','7.715989304812834','test'),('2018-04-14 23:59:59','2018-04-15 03:59:59','STRATETH','4h','0.009350000000000','0.009489000000000','0.072144500000000','0.073217022513369','7.715989304812834','7.715989304812834','test'),('2018-04-24 11:59:59','2018-04-24 15:59:59','STRATETH','4h','0.009744000000000','0.009410000000000','0.072144500000000','0.069671566605090','7.403992200328408','7.403992200328408','test'),('2018-04-27 07:59:59','2018-04-27 11:59:59','STRATETH','4h','0.009730000000000','0.009375000000000','0.072144500000000','0.069512300873587','7.414645426515929','7.414645426515929','test'),('2018-04-29 03:59:59','2018-05-03 19:59:59','STRATETH','4h','0.009616000000000','0.010191000000000','0.072144500000000','0.076458465006240','7.502547836938437','7.502547836938437','test'),('2018-05-04 23:59:59','2018-05-05 03:59:59','STRATETH','4h','0.010210000000000','0.010045000000000','0.072144500000000','0.070978599657199','7.066062683643486','7.066062683643486','test'),('2018-05-05 15:59:59','2018-05-05 23:59:59','STRATETH','4h','0.010303000000000','0.010044000000000','0.072144500000000','0.070330909249733','7.0022808890614385','7.002280889061439','test'),('2018-05-07 15:59:59','2018-05-07 19:59:59','STRATETH','4h','0.010029000000000','0.009961000000000','0.072144500000000','0.071655335975671','7.193588593080068','7.193588593080068','test'),('2018-05-07 23:59:59','2018-05-08 03:59:59','STRATETH','4h','0.010060000000000','0.010037000000000','0.072144500000000','0.071979557306163','7.1714214711729625','7.171421471172962','test'),('2018-05-08 23:59:59','2018-05-09 03:59:59','STRATETH','4h','0.010020000000000','0.009616000000000','0.072144500000000','0.069235679840319','7.200049900199601','7.200049900199601','test'),('2018-05-22 07:59:59','2018-05-22 11:59:59','STRATETH','4h','0.008740000000000','0.008652000000000','0.072144500000000','0.071418102288330','8.254519450800915','8.254519450800915','test'),('2018-06-30 11:59:59','2018-06-30 15:59:59','STRATETH','4h','0.005566000000000','0.005472000000000','0.072144500000000','0.070926105641394','12.961642112827883','12.961642112827883','test'),('2018-06-30 19:59:59','2018-07-05 11:59:59','STRATETH','4h','0.005572000000000','0.005682000000000','0.072144500000000','0.073568745333812','12.947684852835607','12.947684852835607','test'),('2018-07-15 19:59:59','2018-07-15 23:59:59','STRATETH','4h','0.005481000000000','0.005425000000000','0.072144500000000','0.071407391443167','13.162652800583835','13.162652800583835','test'),('2018-07-16 15:59:59','2018-07-16 19:59:59','STRATETH','4h','0.005530000000000','0.005453000000000','0.072144500000000','0.071139956329114','13.046021699819168','13.046021699819168','test'),('2018-07-25 19:59:59','2018-07-26 11:59:59','STRATETH','4h','0.006215000000000','0.006057000000000','0.072144500000000','0.070310416170555','11.608125502815769','11.608125502815769','test'),('2018-07-27 11:59:59','2018-07-27 15:59:59','STRATETH','4h','0.006161000000000','0.005965000000000','0.072144500000000','0.069849365768544','11.70986852783639','11.709868527836390','test'),('2018-08-12 15:59:59','2018-08-12 19:59:59','STRATETH','4h','0.005116000000000','0.004958000000000','0.072144500000000','0.069916425136826','14.10173964034402','14.101739640344020','test'),('2018-08-13 15:59:59','2018-08-13 19:59:59','STRATETH','4h','0.005146000000000','0.005128000000000','0.072144500000000','0.071892148464827','14.019529731830547','14.019529731830547','test'),('2018-08-17 15:59:59','2018-08-17 23:59:59','STRATETH','4h','0.005009000000000','0.004943000000000','0.072144500000000','0.071193903673388','14.402974645637851','14.402974645637851','test'),('2018-08-19 11:59:59','2018-08-22 15:59:59','STRATETH','4h','0.004975000000000','0.004931000000000','0.072144500000000','0.071506438090452','14.501407035175879','14.501407035175879','test'),('2018-08-23 19:59:59','2018-08-23 23:59:59','STRATETH','4h','0.004960000000000','0.005039000000000','0.072144500000000','0.073293575705645','14.545262096774193','14.545262096774193','test'),('2018-08-31 03:59:59','2018-09-05 15:59:59','STRATETH','4h','0.005507000000000','0.006804000000000','0.072144500000000','0.089135859451607','13.100508443798802','13.100508443798802','test'),('2018-09-14 15:59:59','2018-09-14 19:59:59','STRATETH','4h','0.006893000000000','0.006628000000000','0.072144500000000','0.069370919193385','10.466342666473235','10.466342666473235','test'),('2018-09-14 23:59:59','2018-09-15 03:59:59','STRATETH','4h','0.006826000000000','0.006729000000000','0.072144500000000','0.071119299809552','10.569074128332845','10.569074128332845','test'),('2018-09-23 07:59:59','2018-09-23 15:59:59','STRATETH','4h','0.006500000000000','0.006400000000000','0.072144500000000','0.071034584615385','11.099153846153847','11.099153846153847','test'),('2018-09-23 19:59:59','2018-09-23 23:59:59','STRATETH','4h','0.006472000000000','0.006436000000000','0.072144500000000','0.071743201792336','11.147172435105068','11.147172435105068','test'),('2018-09-24 03:59:59','2018-09-24 11:59:59','STRATETH','4h','0.006508000000000','0.006592000000000','0.072144500000000','0.073075682851875','11.085510141364475','11.085510141364475','test'),('2018-10-01 03:59:59','2018-10-01 07:59:59','STRATETH','4h','0.006887000000000','0.006964000000000','0.072144500000000','0.072951110498040','10.475461013503702','10.475461013503702','test'),('2018-10-02 11:59:59','2018-10-02 15:59:59','STRATETH','4h','0.006861000000000','0.006889000000000','0.072144500000000','0.072438924427926','10.515158140212797','10.515158140212797','test'),('2018-10-05 03:59:59','2018-10-05 11:59:59','STRATETH','4h','0.006904000000000','0.006761000000000','0.072144500000000','0.070650197639050','10.449666859791424','10.449666859791424','test'),('2018-10-11 03:59:59','2018-10-11 07:59:59','STRATETH','4h','0.006784000000000','0.006803000000000','0.072144500000000','0.072346555645637','10.63450766509434','10.634507665094340','test'),('2018-10-12 23:59:59','2018-10-13 03:59:59','STRATETH','4h','0.006771000000000','0.006818000000000','0.072144500000000','0.072645281494609','10.654925417220499','10.654925417220499','test'),('2018-10-15 15:59:59','2018-10-15 23:59:59','STRATETH','4h','0.007055000000000','0.006936000000000','0.072144500000000','0.070927604819277','10.226009922041106','10.226009922041106','test'),('2018-10-19 11:59:59','2018-10-19 15:59:59','STRATETH','4h','0.006851000000000','0.006941000000000','0.072144500000000','0.073092245584586','10.53050649540213','10.530506495402131','test'),('2018-10-20 15:59:59','2018-10-22 07:59:59','STRATETH','4h','0.006933000000000','0.007053000000000','0.072144500000000','0.073393214842060','10.405957017164287','10.405957017164287','test'),('2018-10-30 15:59:59','2018-10-30 19:59:59','STRATETH','4h','0.007854000000000','0.007781000000000','0.072144500000000','0.071473943786606','9.185701553348613','9.185701553348613','test'),('2018-10-31 03:59:59','2018-10-31 07:59:59','STRATETH','4h','0.007791000000000','0.007776000000000','0.072144500000000','0.072005600308048','9.259979463483507','9.259979463483507','test'),('2018-11-01 07:59:59','2018-11-03 23:59:59','STRATETH','4h','0.007758000000000','0.007945000000000','0.072144500000000','0.073883481889662','9.299368393915957','9.299368393915957','test'),('2018-11-23 15:59:59','2018-11-23 19:59:59','STRATETH','4h','0.006286000000000','0.006538000000000','0.072144500000000','0.075036707126949','11.477012408526885','11.477012408526885','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','STRATETH','4h','0.006253000000000','0.006231000000000','0.072144500000000','0.071890673196866','11.537581960658883','11.537581960658883','test'),('2018-12-08 15:59:59','2018-12-08 19:59:59','STRATETH','4h','0.007062000000000','0.007087000000000','0.072144500000000','0.072399896842254','10.215873690172756','10.215873690172756','test'),('2018-12-09 23:59:59','2018-12-10 03:59:59','STRATETH','4h','0.007292000000000','0.007146000000000','0.072144500000000','0.070700027015908','9.89365057597367','9.893650575973670','test'),('2018-12-15 19:59:59','2018-12-16 19:59:59','STRATETH','4h','0.007134000000000','0.007332000000000','0.072144500000000','0.074146828427250','10.112769834594898','10.112769834594898','test'),('2018-12-27 07:59:59','2018-12-27 11:59:59','STRATETH','4h','0.010177000000000','0.010454000000000','0.072144500000000','0.074108146113786','7.088975140021617','7.088975140021617','test'),('2019-01-15 11:59:59','2019-01-15 15:59:59','STRATETH','4h','0.007598000000000','0.007623000000000','0.072490282980678','0.072728800626705','9.540705841099994','9.540705841099994','test'),('2019-01-22 15:59:59','2019-01-25 11:59:59','STRATETH','4h','0.008259000000000','0.008289000000000','0.072549912392185','0.072813442767747','8.784345852062538','8.784345852062538','test'),('2019-02-02 19:59:59','2019-02-02 23:59:59','STRATETH','4h','0.007847000000000','0.007566000000000','0.072615794986075','0.070015433269357','9.25395628725309','9.253956287253089','test'),('2019-02-14 11:59:59','2019-02-14 15:59:59','STRATETH','4h','0.007398000000000','0.007318000000000','0.072615794986075','0.071830547135455','9.815598132748715','9.815598132748715','test'),('2019-02-26 15:59:59','2019-02-27 03:59:59','STRATETH','4h','0.006378000000000','0.006422000000000','0.072615794986075','0.073116750611567','11.385355124815772','11.385355124815772','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','STRATETH','4h','0.006415000000000','0.006427000000000','0.072615794986075','0.072751631235464','11.319687449115355','11.319687449115355','test'),('2019-02-28 11:59:59','2019-02-28 15:59:59','STRATETH','4h','0.006391000000000','0.006343000000000','0.072615794986075','0.072070409575446','11.362196054776247','11.362196054776247','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','STRATETH','4h','0.006385000000000','0.006444000000000','0.072615794986075','0.073286794501216','11.372873137991386','11.372873137991386','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  6:06:05
