-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 23:59:59','2018-03-22 03:59:59','LINKBTC','4h','0.000049890000000','0.000048990000000','0.001467500000000','0.001441026758870','29.41471236720786','29.414712367207859','test'),('2018-03-22 07:59:59','2018-03-22 11:59:59','LINKBTC','4h','0.000049800000000','0.000047100000000','0.001467500000000','0.001387936746988','29.46787148594378','29.467871485943778','test'),('2018-03-26 07:59:59','2018-03-26 11:59:59','LINKBTC','4h','0.000048650000000','0.000046520000000','0.001467500000000','0.001403249743063','30.164439876670095','30.164439876670095','test'),('2018-04-05 23:59:59','2018-04-06 03:59:59','LINKBTC','4h','0.000042200000000','0.000042610000000','0.001467500000000','0.001481757701422','34.774881516587676','34.774881516587676','test'),('2018-04-07 07:59:59','2018-04-07 11:59:59','LINKBTC','4h','0.000042230000000','0.000042610000000','0.001467500000000','0.001480705067488','34.75017759886337','34.750177598863367','test'),('2018-04-29 03:59:59','2018-05-04 11:59:59','LINKBTC','4h','0.000053030000000','0.000056750000000','0.001467500000000','0.001570443616821','27.673015274372997','27.673015274372997','test'),('2018-05-07 03:59:59','2018-05-07 07:59:59','LINKBTC','4h','0.000058030000000','0.000058530000000','0.001467500000000','0.001480144321902','25.288643804928487','25.288643804928487','test'),('2018-05-13 19:59:59','2018-05-13 23:59:59','LINKBTC','4h','0.000058130000000','0.000057860000000','0.001467500000000','0.001460683812145','25.24514020299329','25.245140202993291','test'),('2018-05-14 23:59:59','2018-05-16 03:59:59','LINKBTC','4h','0.000059590000000','0.000058820000000','0.001467500000000','0.001448537506293','24.626615203893273','24.626615203893273','test'),('2018-05-17 07:59:59','2018-05-17 11:59:59','LINKBTC','4h','0.000058430000000','0.000056890000000','0.001467500000000','0.001428822094814','25.11552284785213','25.115522847852130','test'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKBTC','4h','0.000048210000000','0.000048110000000','0.001467500000000','0.001464456025721','30.43974279195188','30.439742791951879','test'),('2018-06-03 11:59:59','2018-06-03 15:59:59','LINKBTC','4h','0.000048120000000','0.000047880000000','0.001467500000000','0.001460180798005','30.49667497921862','30.496674979218621','test'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKBTC','4h','0.000032010000000','0.000034750000000','0.001467500000000','0.001593115432677','45.84504842236801','45.845048422368009','test'),('2018-07-06 03:59:59','2018-07-06 07:59:59','LINKBTC','4h','0.000034420000000','0.000033670000000','0.001473389906552','0.001441285245602','42.80621460058832','42.806214600588319','test'),('2018-07-06 19:59:59','2018-07-09 23:59:59','LINKBTC','4h','0.000034850000000','0.000035090000000','0.001473389906552','0.001483536637616','42.278046099053086','42.278046099053086','test'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LINKBTC','4h','0.000033330000000','0.000032930000000','0.001473389906552','0.001455707459429','44.206117808340835','44.206117808340835','test'),('2018-07-25 19:59:59','2018-07-25 23:59:59','LINKBTC','4h','0.000030390000000','0.000030030000000','0.001473389906552','0.001455936126810','48.48272150549523','48.482721505495228','test'),('2018-08-05 19:59:59','2018-08-05 23:59:59','LINKBTC','4h','0.000036050000000','0.000035980000000','0.001473389906552','0.001470528955277','40.870732497975034','40.870732497975034','test'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKBTC','4h','0.000035950000000','0.000035650000000','0.001473389906552','0.001461094580489','40.984420210069544','40.984420210069544','test'),('2018-08-28 23:59:59','2018-08-29 07:59:59','LINKBTC','4h','0.000047340000000','0.000046860000000','0.001473389906552','0.001458450591910','31.123572170511196','31.123572170511196','test'),('2018-09-01 03:59:59','2018-09-01 07:59:59','LINKBTC','4h','0.000046360000000','0.000046230000000','0.001473389906552','0.001469258312767','31.781490650388264','31.781490650388264','test'),('2018-09-02 03:59:59','2018-09-02 07:59:59','LINKBTC','4h','0.000046500000000','0.000045650000000','0.001473389906552','0.001446456972776','31.685804441978494','31.685804441978494','test'),('2018-09-12 03:59:59','2018-09-12 07:59:59','LINKBTC','4h','0.000041910000000','0.000039980000000','0.001473389906552','0.001405538736911','35.156046446003344','35.156046446003344','test'),('2018-09-13 11:59:59','2018-09-13 15:59:59','LINKBTC','4h','0.000042520000000','0.000041580000000','0.001473389906552','0.001440817316896','34.651691123047975','34.651691123047975','test'),('2018-09-14 11:59:59','2018-09-14 15:59:59','LINKBTC','4h','0.000042330000000','0.000041540000000','0.001473389906552','0.001445892197453','34.80722670805575','34.807226708055751','test'),('2018-09-16 11:59:59','2018-09-20 23:59:59','LINKBTC','4h','0.000042300000000','0.000054820000000','0.001473389906552','0.001909485453361','34.83191268444445','34.831912684444447','test'),('2018-10-01 07:59:59','2018-10-01 11:59:59','LINKBTC','4h','0.000050090000000','0.000049520000000','0.001520869857082','0.001503563092887','30.36274420208624','30.362744202086240','test'),('2018-10-01 15:59:59','2018-10-01 19:59:59','LINKBTC','4h','0.000050000000000','0.000049970000000','0.001520869857082','0.001519957335168','30.41739714164','30.417397141639999','test'),('2018-10-05 15:59:59','2018-10-06 19:59:59','LINKBTC','4h','0.000052120000000','0.000051230000000','0.001520869857082','0.001494899516084','29.18015842444359','29.180158424443590','test'),('2018-10-09 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000051030000000','0.000051180000000','0.001520869857082','0.001525340374005','29.803446150930824','29.803446150930824','test'),('2018-10-13 15:59:59','2018-10-13 19:59:59','LINKBTC','4h','0.000050850000000','0.000050660000000','0.001520869857082','0.001515187157518','29.908945075358897','29.908945075358897','test'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LINKBTC','4h','0.000051370000000','0.000050740000000','0.001520869857082','0.001502217958893','29.606187601362663','29.606187601362663','test'),('2018-11-06 19:59:59','2018-11-06 23:59:59','LINKBTC','4h','0.000076320000000','0.000074620000000','0.001520869857082','0.001486993038987','19.92754005610587','19.927540056105869','test'),('2018-11-07 15:59:59','2018-11-07 19:59:59','LINKBTC','4h','0.000074340000000','0.000074750000000','0.001520869857082','0.001529257759172','20.45829778157116','20.458297781571162','test'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKBTC','4h','0.000080690000000','0.000077810000000','0.001520869857082','0.001466586734162','18.848306569364233','18.848306569364233','test'),('2018-11-28 07:59:59','2018-11-28 11:59:59','LINKBTC','4h','0.000078660000000','0.000080750000000','0.001520869857082','0.001561279442657','19.334729940020342','19.334729940020342','test'),('2018-11-29 07:59:59','2018-11-29 11:59:59','LINKBTC','4h','0.000079640000000','0.000078620000000','0.001520869857082','0.001501391112052','19.096808853365143','19.096808853365143','test'),('2018-12-02 07:59:59','2018-12-02 11:59:59','LINKBTC','4h','0.000079860000000','0.000079200000000','0.001520869857082','0.001508300684709','19.0442005645129','19.044200564512899','test'),('2018-12-18 03:59:59','2018-12-18 11:59:59','LINKBTC','4h','0.000066590000000','0.000068670000000','0.001520869857082','0.001568375628260','22.839313066256196','22.839313066256196','test'),('2018-12-29 03:59:59','2018-12-29 11:59:59','LINKBTC','4h','0.000076970000000','0.000075330000000','0.001520869857082','0.001488464678888','19.759254996518123','19.759254996518123','test'),('2019-01-26 07:59:59','2019-01-26 11:59:59','LINKBTC','4h','0.000134290000000','0.000133370000000','0.001520869857082','0.001510450613143','11.325265150659023','11.325265150659023','test'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.001520869857082','0.001520869857082','11.51040533627488','11.510405336274880','test'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.001520869857082','0.001502868438422','12.500985180683873','12.500985180683873','test'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.001520869857082','0.001510880564096','12.486616232200328','12.486616232200328','test'),('2019-02-09 11:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000121430000000','0.000122400000000','0.001520869857082','0.001533018780424','12.524663238754838','12.524663238754838','test'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000119920000000','0.001520869857082','0.001488838475602','12.415264139444899','12.415264139444899','test'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.001520869857082','0.001518098225467','12.598325522548045','12.598325522548045','test'),('2019-02-17 11:59:59','2019-02-17 15:59:59','LINKBTC','4h','0.000123660000000','0.000121560000000','0.001520869857082','0.001495042372852','12.298802014248746','12.298802014248746','test'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LINKBTC','4h','0.000121500000000','0.000117220000000','0.001520869857082','0.001467295182281','12.517447383390946','12.517447383390946','test'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000116640000000','0.001520869857082','0.001477054622232','12.663362673455453','12.663362673455453','test'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.001520869857082','0.001625542920338','13.523651583514138','13.523651583514138','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-23  5:38:54
