-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010600000000','0.000010494000000','0.033333333333333','0.033000000000000','3144.6540880503144','3144.654088050314385','test','test','1.0'),('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJBTC','4h','0.000010340000000','0.000010236600000','0.033259259259259','0.032926666666666','3216.5627910308835','3216.562791030883545','test','test','1.0'),('2019-01-22 15:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009650000000','0.000009553500000','0.033185349794239','0.032853496296297','3438.896351734577','3438.896351734576911','test','test','1.0'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009256500000','0.033111604572474','0.032780488526749','3541.3480826175155','3541.348082617515502','test','test','1.0'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008157600000','0.033038023228979','0.032707642996689','4009.4688384683645','4009.468838468364538','test','test','1.0'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.032964605399582','0.033438916268641','3952.5905754893947','3952.590575489394723','test','test','0.0'),('2019-02-17 11:59:59','2019-03-16 07:59:59','ENJBTC','4h','0.000008580000000','0.000041040000000','0.033070007814928','0.158181016401474','3854.313265143123','3854.313265143122862','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','ENJBTC','4h','0.000050800000000','0.000050292000000','0.060872454167494','0.060263729625819','1198.2766568404286','1198.276656840428586','test','test','1.0'),('2019-03-19 19:59:59','2019-03-19 23:59:59','ENJBTC','4h','0.000048000000000','0.000047520000000','0.060737182047122','0.060129810226651','1265.3579593150323','1265.357959315032303','test','test','1.0'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ENJBTC','4h','0.000047960000000','0.000047480400000','0.060602210531461','0.059996188426146','1263.599051948735','1263.599051948734996','test','test','1.0'),('2019-03-22 07:59:59','2019-03-22 11:59:59','ENJBTC','4h','0.000047730000000','0.000047252700000','0.060467538952502','0.059862863562977','1266.8665190132506','1266.866519013250581','test','test','1.0'),('2019-04-13 19:59:59','2019-04-14 15:59:59','ENJBTC','4h','0.000033070000000','0.000032739300000','0.060333166643719','0.059729834977282','1824.4078210982498','1824.407821098249769','test','test','1.0'),('2019-04-17 11:59:59','2019-04-23 03:59:59','ENJBTC','4h','0.000031460000000','0.000032990000000','0.060199092940066','0.063126766563661','1913.5121722843753','1913.512172284375310','test','test','0.0'),('2019-05-17 23:59:59','2019-05-18 03:59:59','ENJBTC','4h','0.000021930000000','0.000021710700000','0.060849687078643','0.060241190207857','2774.723532997863','2774.723532997863003','test','test','1.0'),('2019-05-21 23:59:59','2019-05-22 03:59:59','ENJBTC','4h','0.000021480000000','0.000022590000000','0.060714465551802','0.063851944916909','2826.557986582951','2826.557986582950889','test','test','0.0'),('2019-05-22 07:59:59','2019-05-22 11:59:59','ENJBTC','4h','0.000022940000000','0.000022710600000','0.061411683188492','0.060797566356607','2677.056808565485','2677.056808565484971','test','test','1.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ENJBTC','4h','0.000022440000000','0.000022215600000','0.061275212781407','0.060662460653593','2730.6244554994055','2730.624455499405485','test','test','1.0'),('2019-06-02 19:59:59','2019-06-02 23:59:59','ENJBTC','4h','0.000019680000000','0.000019483200000','0.061139045641892','0.060527655185473','3106.658823266892','3106.658823266891886','test','test','1.0'),('2019-06-06 23:59:59','2019-06-07 19:59:59','ENJBTC','4h','0.000019160000000','0.000019000000000','0.061003181096022','0.060493759959521','3183.882103132649','3183.882103132648808','test','test','0.8'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJBTC','4h','0.000019780000000','0.000019582200000','0.060889976399021','0.060281076635031','3078.360788625952','3078.360788625951955','test','test','1.0'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBTC','4h','0.000019850000000','0.000019651500000','0.060754665340357','0.060147118686953','3060.6884302446792','3060.688430244679239','test','test','1.0'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ENJBTC','4h','0.000019600000000','0.000019404000000','0.060619654972934','0.060013458423205','3092.8395394353975','3092.839539435397455','test','test','1.0'),('2019-07-01 15:59:59','2019-07-01 23:59:59','ENJBTC','4h','0.000012140000000','0.000012020000000','0.060484944628550','0.059887070381810','4982.285389501611','4982.285389501610553','test','test','1.0'),('2019-07-02 07:59:59','2019-07-02 11:59:59','ENJBTC','4h','0.000012400000000','0.000012276000000','0.060352083684830','0.059748562847982','4867.103522970126','4867.103522970125596','test','test','1.0'),('2019-07-14 15:59:59','2019-07-14 19:59:59','ENJBTC','4h','0.000010300000000','0.000010197000000','0.060217967943308','0.059615788263875','5846.404654690075','5846.404654690075404','test','test','1.0'),('2019-07-14 23:59:59','2019-07-15 03:59:59','ENJBTC','4h','0.000010240000000','0.000010137600000','0.060084150236767','0.059483308734399','5867.592796559288','5867.592796559288217','test','test','1.0'),('2019-07-25 19:59:59','2019-07-25 23:59:59','ENJBTC','4h','0.000008940000000','0.000008850600000','0.059950629902908','0.059351123603879','6705.887013748049','6705.887013748048957','test','test','1.0'),('2019-07-26 07:59:59','2019-07-27 03:59:59','ENJBTC','4h','0.000009010000000','0.000008919900000','0.059817406280901','0.059219232218092','6639.001806981256','6639.001806981255868','test','test','1.0'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJBTC','4h','0.000008900000000','0.000008880000000','0.059684478711388','0.059550356287317','6706.121203526743','6706.121203526742647','test','test','0.2'),('2019-07-28 19:59:59','2019-07-28 23:59:59','ENJBTC','4h','0.000008930000000','0.000008900000000','0.059654673728261','0.059454266089756','6680.2546168265535','6680.254616826553502','test','test','0.3'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJBTC','4h','0.000008970000000','0.000008880300000','0.059610138697482','0.059014037310507','6645.500412205376','6645.500412205376051','test','test','1.0'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ENJBTC','4h','0.000006580000000','0.000006514200000','0.059477671722599','0.058882895005373','9039.15983626123','9039.159836261229430','test','test','1.0'),('2019-08-21 15:59:59','2019-08-26 03:59:59','ENJBTC','4h','0.000006340000000','0.000006670000000','0.059345499118771','0.062434460429369','9360.488819995408','9360.488819995407539','test','test','0.8'),('2019-08-27 11:59:59','2019-08-28 15:59:59','ENJBTC','4h','0.000006830000000','0.000006761700000','0.060031934965570','0.059431615615914','8789.448750449552','8789.448750449551881','test','test','1.0'),('2019-08-28 23:59:59','2019-08-29 03:59:59','ENJBTC','4h','0.000006830000000','0.000006761700000','0.059898530665647','0.059299545358991','8769.91664211521','8769.916642115209470','test','test','1.0'),('2019-08-31 11:59:59','2019-08-31 15:59:59','ENJBTC','4h','0.000007010000000','0.000006939900000','0.059765422819723','0.059167768591526','8525.737920074656','8525.737920074656358','test','test','1.0'),('2019-08-31 19:59:59','2019-09-03 15:59:59','ENJBTC','4h','0.000006940000000','0.000006960000000','0.059632610769013','0.059804462673246','8592.595211673328','8592.595211673327867','test','test','0.0'),('2019-09-04 03:59:59','2019-09-09 15:59:59','ENJBTC','4h','0.000007540000000','0.000007464600000','0.059670800081065','0.059074092080254','7913.899214995315','7913.899214995314651','test','test','1.0'),('2019-09-10 19:59:59','2019-09-10 23:59:59','ENJBTC','4h','0.000007520000000','0.000007444800000','0.059538198303107','0.058942816320076','7917.313604136524','7917.313604136524191','test','test','1.0'),('2019-09-18 07:59:59','2019-09-19 03:59:59','ENJBTC','4h','0.000007140000000','0.000007090000000','0.059405891195766','0.058989883554339','8320.152828538718','8320.152828538717586','test','test','0.7'),('2019-09-28 11:59:59','2019-09-28 23:59:59','ENJBTC','4h','0.000006990000000','0.000006920100000','0.059313445053227','0.058720310602695','8485.47139531146','8485.471395311460583','test','test','1.0'),('2019-09-29 11:59:59','2019-09-29 15:59:59','ENJBTC','4h','0.000007020000000','0.000006949800000','0.059181637397553','0.058589821023577','8430.43267771415','8430.432677714150486','test','test','1.0'),('2019-09-30 11:59:59','2019-09-30 19:59:59','ENJBTC','4h','0.000006940000000','0.000006870600000','0.059050122647781','0.058459621421303','8508.663205732119','8508.663205732118513','test','test','1.0'),('2019-10-01 07:59:59','2019-10-01 15:59:59','ENJBTC','4h','0.000007040000000','0.000006969600000','0.058918900153008','0.058329711151478','8369.161953552273','8369.161953552273189','test','test','1.0'),('2019-10-03 07:59:59','2019-10-09 15:59:59','ENJBTC','4h','0.000007180000000','0.000007490000000','0.058787969263779','0.061326168493831','8187.739451779821','8187.739451779821138','test','test','0.0'),('2019-10-12 03:59:59','2019-10-12 15:59:59','ENJBTC','4h','0.000007650000000','0.000007573500000','0.059352013537124','0.058758493401753','7758.433142107715','7758.433142107714957','test','test','1.0'),('2019-10-13 07:59:59','2019-10-13 15:59:59','ENJBTC','4h','0.000007730000000','0.000007652700000','0.059220120173708','0.058627918971971','7661.076348474543','7661.076348474543011','test','test','1.0'),('2019-10-22 15:59:59','2019-10-23 03:59:59','ENJBTC','4h','0.000007430000000','0.000007355700000','0.059088519906656','0.058497634707589','7952.694469267236','7952.694469267235945','test','test','1.0'),('2019-10-23 11:59:59','2019-10-25 15:59:59','ENJBTC','4h','0.000007590000000','0.000007514100000','0.058957212084641','0.058367639963795','7767.748627752393','7767.748627752393077','test','test','1.0'),('2019-11-01 03:59:59','2019-11-01 11:59:59','ENJBTC','4h','0.000007260000000','0.000007187400000','0.058826196057786','0.058237934097208','8102.781826141323','8102.781826141323108','test','test','1.0'),('2019-11-02 19:59:59','2019-11-03 03:59:59','ENJBTC','4h','0.000007080000000','0.000007160000000','0.058695471177658','0.059358696840682','8290.32078780474','8290.320787804739666','test','test','0.0'),('2019-11-04 03:59:59','2019-11-04 23:59:59','ENJBTC','4h','0.000007190000000','0.000007140000000','0.058842854658330','0.058433655390887','8183.985348863639','8183.985348863639047','test','test','1.0'),('2019-11-05 19:59:59','2019-11-07 03:59:59','ENJBTC','4h','0.000007210000000','0.000007180000000','0.058751921487787','0.058507461342900','8148.671496225613','8148.671496225612827','test','test','0.8'),('2019-11-12 15:59:59','2019-11-12 19:59:59','ENJBTC','4h','0.000007090000000','0.000007100000000','0.058697597011145','0.058780386287606','8278.927646141765','8278.927646141764853','test','test','0.0'),('2019-11-14 07:59:59','2019-11-14 11:59:59','ENJBTC','4h','0.000007230000000','0.000007157700000','0.058715994628136','0.058128834681855','8121.161082729799','8121.161082729799091','test','test','1.0'),('2019-11-14 15:59:59','2019-11-18 15:59:59','ENJBTC','4h','0.000007270000000','0.000007600000000','0.058585514640074','0.061244829609981','8058.530211839615','8058.530211839614822','test','test','0.0'),('2019-11-19 19:59:59','2019-11-22 15:59:59','ENJBTC','4h','0.000007950000000','0.000007870500000','0.059176473522276','0.058584708787053','7443.581575129001','7443.581575129001067','test','test','1.0'),('2019-11-23 19:59:59','2019-11-23 23:59:59','ENJBTC','4h','0.000008610000000','0.000008523900000','0.059044970247782','0.058454520545304','6857.72012169356','6857.720121693560031','test','test','1.0'),('2019-11-27 11:59:59','2019-11-27 15:59:59','ENJBTC','4h','0.000007790000000','0.000007730000000','0.058913759202786','0.058459994690313','7562.741874555384','7562.741874555384129','test','test','0.8'),('2019-11-28 15:59:59','2019-11-29 15:59:59','ENJBTC','4h','0.000007910000000','0.000007830900000','0.058812922644459','0.058224793418014','7435.2620283766255','7435.262028376625494','test','test','1.0'),('2019-11-30 23:59:59','2019-12-01 03:59:59','ENJBTC','4h','0.000007990000000','0.000007910100000','0.058682227260805','0.058095404988197','7344.458981327242','7344.458981327242327','test','test','1.0'),('2019-12-01 19:59:59','2019-12-02 23:59:59','ENJBTC','4h','0.000008140000000','0.000008058600000','0.058551822311336','0.057966304088223','7193.09856404622','7193.098564046220417','test','test','1.0'),('2019-12-03 15:59:59','2019-12-04 15:59:59','ENJBTC','4h','0.000008170000000','0.000008400000000','0.058421707150644','0.060066381892951','7150.759749160886','7150.759749160885804','test','test','0.0'),('2019-12-04 19:59:59','2019-12-04 23:59:59','ENJBTC','4h','0.000011600000000','0.000011484000000','0.058787190426713','0.058199318522446','5067.861243682126','5067.861243682125860','test','test','1.0'),('2019-12-05 07:59:59','2019-12-10 03:59:59','ENJBTC','4h','0.000010670000000','0.000010563300000','0.058656552225764','0.058069986703506','5497.333854335938','5497.333854335937758','test','test','1.0'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ENJBTC','4h','0.000011250000000','0.000011137500000','0.058526204331929','0.057940942288610','5202.3292739492745','5202.329273949274466','test','test','1.0'),('2019-12-11 23:59:59','2019-12-12 23:59:59','ENJBTC','4h','0.000011590000000','0.000011474100000','0.058396146100081','0.057812184639080','5038.494055226977','5038.494055226977252','test','test','1.0'),('2019-12-15 19:59:59','2019-12-17 23:59:59','ENJBTC','4h','0.000011310000000','0.000011480000000','0.058266376886525','0.059142175654934','5151.757461231202','5151.757461231201887','test','test','0.0'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ENJBTC','4h','0.000011160000000','0.000011240000000','0.058460998835060','0.058880074095526','5238.440755829769','5238.440755829768932','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 19:59:59','ENJBTC','4h','0.000011460000000','0.000011345400000','0.058554126670719','0.057968585404012','5109.435137061025','5109.435137061024761','test','test','1.0'),('2019-12-28 19:59:59','2019-12-29 03:59:59','ENJBTC','4h','0.000011120000000','0.000011008800000','0.058424006389229','0.057839766325337','5253.957409103317','5253.957409103317332','test','test','1.0'),('2019-12-29 07:59:59','2019-12-29 19:59:59','ENJBTC','4h','0.000011090000000','0.000010979100000','0.058294175263920','0.057711233511281','5256.463053554514','5256.463053554513863','test','test','1.0'),('2019-12-30 15:59:59','2019-12-30 19:59:59','ENJBTC','4h','0.000011600000000','0.000011484000000','0.058164632652222','0.057582986325700','5014.1924700191375','5014.192470019137545','test','test','1.0'),('2019-12-31 11:59:59','2019-12-31 15:59:59','ENJBTC','4h','0.000011820000000','0.000011701800000','0.058035377912995','0.057455024133865','4909.930449491953','4909.930449491953368','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:41:33
