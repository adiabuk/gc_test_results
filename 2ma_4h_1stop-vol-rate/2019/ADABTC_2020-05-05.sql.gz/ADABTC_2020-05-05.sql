-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 19:59:59','ADABTC','4h','0.000011280000000','0.000011167200000','0.033333333333333','0.033000000000000','2955.082742316785','2955.082742316784788','test','test','1.0'),('2019-01-04 23:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000011370000000','0.000011970000000','0.033259259259259','0.035014365288771','2925.1767158539433','2925.176715853943278','test','test','0.4'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033649282821373','0.033592824293149','2822.926411189019','2822.926411189018836','test','test','0.2'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ADABTC','4h','0.000011830000000','0.000012010000000','0.033636736481768','0.034148538051229','2843.3420525585607','2843.342052558560681','test','test','0.0'),('2019-01-16 07:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012050000000','0.000012040000000','0.033750470163870','0.033722461474937','2800.8688932672385','2800.868893267238491','test','test','0.1'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.033744246010774','0.033494904291483','2770.463547682594','2770.463547682593799','test','test','0.7'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011246400000','0.033688836739820','0.033351948372422','2965.566614420814','2965.566614420813949','test','test','1.0'),('2019-02-09 11:59:59','2019-02-09 15:59:59','ADABTC','4h','0.000011450000000','0.000011335500000','0.033613972658176','0.033277832931594','2935.7181360852787','2935.718136085278729','test','test','1.0'),('2019-02-10 19:59:59','2019-02-12 11:59:59','ADABTC','4h','0.000011450000000','0.000011335500000','0.033539274941158','0.033203882191746','2929.194318005085','2929.194318005084824','test','test','1.0'),('2019-02-13 07:59:59','2019-02-13 15:59:59','ADABTC','4h','0.000011510000000','0.000011394900000','0.033464743219067','0.033130095786876','2907.4494543064','2907.449454306400185','test','test','1.0'),('2019-02-16 15:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.033390377123024','0.033243153238002','2944.477700443053','2944.477700443052981','test','test','0.4'),('2019-02-17 11:59:59','2019-02-17 15:59:59','ADABTC','4h','0.000011310000000','0.000011240000000','0.033357660704130','0.033151203033990','2949.3952877215247','2949.395287721524710','test','test','0.6'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ADABTC','4h','0.000011340000000','0.000011540000000','0.033311781221877','0.033899290590870','2937.5468449627083','2937.546844962708292','test','test','0.0'),('2019-02-18 07:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011490000000','0.000011460000000','0.033442338859431','0.033355022047788','2910.5603881141087','2910.560388114108719','test','test','0.3'),('2019-02-23 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011730000000','0.000011612700000','0.033422935123510','0.033088705772275','2849.355082993218','2849.355082993217820','test','test','1.0'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.033348661934347','0.049474592683045','2964.3255052752984','2964.325505275298383','test','test','0.0'),('2019-04-02 15:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016830000000','0.000016860000000','0.036932202100724','0.036998034903043','2194.42674395273','2194.426743952729794','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.036946831612351','0.036812601524749','3355.7521900409524','3355.752190040952428','test','test','0.4'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011375100000','0.036917002703995','0.036547832676955','3212.9680334199206','3212.968033419920630','test','test','1.0'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADABTC','4h','0.000010480000000','0.000010375200000','0.036834964920208','0.036466615271006','3514.786729027502','3514.786729027502133','test','test','1.0'),('2019-05-29 15:59:59','2019-05-30 19:59:59','ADABTC','4h','0.000010590000000','0.000010484100000','0.036753109442608','0.036385578348182','3470.5485781499315','3470.548578149931473','test','test','1.0'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADABTC','4h','0.000010580000000','0.000010710000000','0.036671435866069','0.037122030068582','3466.1092501010085','3466.109250101008456','test','test','0.0'),('2019-06-06 23:59:59','2019-06-08 07:59:59','ADABTC','4h','0.000010670000000','0.000010650000000','0.036771567911072','0.036702642760348','3446.2575361829013','3446.257536182901276','test','test','0.7'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADABTC','4h','0.000010660000000','0.000010553400000','0.036756251210911','0.036388688698802','3448.0535845131953','3448.053584513195347','test','test','1.0'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADABTC','4h','0.000010640000000','0.000010980000000','0.036674570652664','0.037846502421640','3446.858144047389','3446.858144047389032','test','test','0.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','ADABTC','4h','0.000005930000000','0.000005870700000','0.036934999934659','0.036565649935312','6228.4991458109425','6228.499145810942537','test','test','1.0'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADABTC','4h','0.000006030000000','0.000005969700000','0.036852922157026','0.036484392935456','6111.595714266371','6111.595714266371033','test','test','1.0'),('2019-07-25 15:59:59','2019-07-31 07:59:59','ADABTC','4h','0.000005920000000','0.000006180000000','0.036771026774455','0.038385970517928','6211.322090279579','6211.322090279579243','test','test','0.3'),('2019-08-14 03:59:59','2019-08-14 11:59:59','ADABTC','4h','0.000004990000000','0.000004940100000','0.037129903161894','0.036758604130275','7440.862357092897','7440.862357092896673','test','test','1.0'),('2019-08-14 15:59:59','2019-08-14 19:59:59','ADABTC','4h','0.000004980000000','0.000004930200000','0.037047392265978','0.036676918343318','7439.235394774742','7439.235394774742417','test','test','1.0'),('2019-08-18 15:59:59','2019-08-19 07:59:59','ADABTC','4h','0.000004760000000','0.000004730000000','0.036965064727609','0.036732091630586','7765.769900758263','7765.769900758263248','test','test','0.6'),('2019-08-22 03:59:59','2019-08-22 07:59:59','ADABTC','4h','0.000004810000000','0.000004761900000','0.036913292928271','0.036544159998988','7674.281274068791','7674.281274068791390','test','test','1.0'),('2019-08-22 11:59:59','2019-08-23 15:59:59','ADABTC','4h','0.000004790000000','0.000004770000000','0.036831263388430','0.036677479407685','7689.199037250568','7689.199037250567926','test','test','0.4'),('2019-08-24 11:59:59','2019-08-26 03:59:59','ADABTC','4h','0.000004880000000','0.000004831200000','0.036797089170487','0.036429118278782','7540.387125099772','7540.387125099771765','test','test','1.0'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ADABTC','4h','0.000004840000000','0.000004840000000','0.036715317861219','0.036715317861219','7585.8094754584945','7585.809475458494489','test','test','0.0'),('2019-08-28 03:59:59','2019-08-28 11:59:59','ADABTC','4h','0.000004880000000','0.000004831200000','0.036715317861219','0.036348164682607','7523.630709266212','7523.630709266211852','test','test','1.0'),('2019-09-08 07:59:59','2019-09-08 15:59:59','ADABTC','4h','0.000004470000000','0.000004570000000','0.036633728265972','0.037453274759618','8195.464936459059','8195.464936459058663','test','test','0.2'),('2019-09-10 03:59:59','2019-09-11 03:59:59','ADABTC','4h','0.000004610000000','0.000004563900000','0.036815849709004','0.036447691211914','7986.084535575801','7986.084535575801056','test','test','1.0'),('2019-09-14 19:59:59','2019-09-22 11:59:59','ADABTC','4h','0.000004520000000','0.000004880000000','0.036734036709651','0.039659756447588','8126.999272046705','8126.999272046705300','test','test','0.9'),('2019-09-23 15:59:59','2019-09-23 23:59:59','ADABTC','4h','0.000004970000000','0.000004920300000','0.037384196651415','0.037010354684901','7521.971157226336','7521.971157226335890','test','test','1.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ADABTC','4h','0.000004810000000','0.000004761900000','0.037301120658856','0.036928109452267','7754.910739886948','7754.910739886948249','test','test','1.0'),('2019-10-02 19:59:59','2019-10-02 23:59:59','ADABTC','4h','0.000004740000000','0.000004700000000','0.037218229279614','0.036904151395398','7851.947105403845','7851.947105403844944','test','test','0.8'),('2019-10-04 11:59:59','2019-10-09 15:59:59','ADABTC','4h','0.000004740000000','0.000004960000000','0.037148434194233','0.038872623123079','7837.222403846602','7837.222403846601992','test','test','0.0'),('2019-10-13 15:59:59','2019-10-15 19:59:59','ADABTC','4h','0.000004940000000','0.000004890600000','0.037531587289532','0.037156271416637','7597.48730557328','7597.487305573279627','test','test','1.0'),('2019-10-19 15:59:59','2019-10-19 19:59:59','ADABTC','4h','0.000004890000000','0.000004890000000','0.037448183762222','0.037448183762222','7658.115288797955','7658.115288797955145','test','test','0.0'),('2019-10-23 15:59:59','2019-10-23 19:59:59','ADABTC','4h','0.000004860000000','0.000004840000000','0.037448183762222','0.037294076010114','7705.387605395473','7705.387605395472747','test','test','0.4'),('2019-10-24 03:59:59','2019-10-25 15:59:59','ADABTC','4h','0.000004880000000','0.000004860000000','0.037413937595087','0.037260601785271','7666.790490796496','7666.790490796495760','test','test','0.4'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ADABTC','4h','0.000004620000000','0.000004600000000','0.037379862970683','0.037218045382065','8090.879430883839','8090.879430883838722','test','test','0.4'),('2019-11-05 03:59:59','2019-11-07 11:59:59','ADABTC','4h','0.000004730000000','0.000004690000000','0.037343903506546','0.037028098825730','7895.117020411418','7895.117020411417798','test','test','0.8'),('2019-11-08 15:59:59','2019-11-20 11:59:59','ADABTC','4h','0.000004730000000','0.000005100000000','0.037273724688587','0.040189428311161','7880.280061012029','7880.280061012029364','test','test','0.0'),('2019-11-22 15:59:59','2019-11-22 19:59:59','ADABTC','4h','0.000005100000000','0.000005180000000','0.037921658826937','0.038516508377163','7435.619377830719','7435.619377830718804','test','test','0.0'),('2019-11-24 19:59:59','2019-11-24 23:59:59','ADABTC','4h','0.000005090000000','0.000005070000000','0.038053847615876','0.037904323656678','7476.19795989701','7476.197959897010151','test','test','0.4'),('2019-11-25 03:59:59','2019-11-25 07:59:59','ADABTC','4h','0.000005080000000','0.000005060000000','0.038020620069387','0.037870932588799','7484.374029406956','7484.374029406955742','test','test','0.4'),('2019-11-25 11:59:59','2019-11-25 15:59:59','ADABTC','4h','0.000005100000000','0.000005080000000','0.037987356184812','0.037838386160558','7448.501212708279','7448.501212708279127','test','test','0.4'),('2019-11-26 15:59:59','2019-11-26 19:59:59','ADABTC','4h','0.000005120000000','0.000005070000000','0.037954251734978','0.037583604745379','7412.939791987891','7412.939791987891113','test','test','1.0'),('2019-11-27 11:59:59','2019-11-28 03:59:59','ADABTC','4h','0.000005200000000','0.000005148000000','0.037871885737289','0.037493166879916','7283.054949478718','7283.054949478718299','test','test','1.0'),('2019-11-28 23:59:59','2019-12-02 07:59:59','ADABTC','4h','0.000005260000000','0.000005230000000','0.037787725991206','0.037572206641446','7183.978325324421','7183.978325324421348','test','test','0.6'),('2019-12-13 11:59:59','2019-12-13 15:59:59','ADABTC','4h','0.000005150000000','0.000005120000000','0.037739832802371','0.037519989116144','7328.122874246774','7328.122874246773790','test','test','0.6'),('2019-12-13 23:59:59','2019-12-14 11:59:59','ADABTC','4h','0.000005140000000','0.000005088600000','0.037690978649876','0.037314068863377','7332.875223711286','7332.875223711285798','test','test','1.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADABTC','4h','0.000005130000000','0.000005130000000','0.037607220919543','0.037607220919543','7330.842284511285','7330.842284511284561','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:57:45
