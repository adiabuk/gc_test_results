-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.297777777777778','1.290878374387146','22998.011302104867','22998.011302104867355','test','test','0.5'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.296244577024304','1.610437842344446','22555.15185356367','22555.151853563671466','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.366065302651002','1.357881770671064','19484.599952232235','19484.599952232234500','test','test','0.6'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.364246739988794','1.372420543566473','19461.43708971175','19461.437089711751469','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000071379000000','1.366063140783833','1.352402509375995','18946.78419949838','18946.784199498379166','test','test','1.0'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDETH','4h','0.000073720000000','0.000072982800000','1.363027444915425','1.349397170466271','18489.24911713816','18489.249117138158908','test','test','1.0'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056687400000','1.359998495037835','1.346398510087457','23751.283531921683','23751.283531921682879','test','test','1.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDETH','4h','0.000057900000000','0.000057321000000','1.356976276159974','1.343406513398374','23436.5505381688','23436.550538168801722','test','test','1.0'),('2019-03-02 11:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000058620000000','0.000061610000000','1.353960773324062','1.423021549718449','23097.249630229657','23097.249630229656759','test','test','0.0'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.369307612522815','1.430137170157177','21418.858321958625','21418.858321958625311','test','test','0.7'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.382825291997118','1.518450164290307','21092.51513113358','21092.515131133579416','test','test','0.0'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000069418800000','1.412964152506715','1.398834510981648','20150.658193193318','20150.658193193317857','test','test','1.0'),('2019-04-05 15:59:59','2019-04-06 03:59:59','LENDETH','4h','0.000072970000000','0.000072240300000','1.409824232167812','1.395725989846134','19320.600687512837','19320.600687512836885','test','test','1.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000069577200000','1.406691289429661','1.392624376535365','20015.527738042983','20015.527738042983401','test','test','1.0'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.403565308786484','1.399999233424151','20976.91389607658','20976.913896076581295','test','test','0.4'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000066132000000','1.402772847594854','1.388745119118906','20999.59352686908','20999.593526869080961','test','test','1.0'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000066537900000','1.399655574600199','1.385659018854197','20825.108980809393','20825.108980809392961','test','test','1.0'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000039095100000','1.396545228878866','1.382579776590077','35364.528459834524','35364.528459834524256','test','test','1.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000040778100000','1.393441795036912','1.379507377086543','33829.613863484155','33829.613863484155445','test','test','1.0'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.390345257714608','1.404032594448586','36019.307194678964','36019.307194678964152','test','test','0.0'),('2019-06-08 07:59:59','2019-06-12 15:59:59','LENDETH','4h','0.000036130000000','0.000037870000000','1.393386888099936','1.460491598459579','38565.92549404751','38565.925494047507527','test','test','0.4'),('2019-06-16 07:59:59','2019-06-19 15:59:59','LENDETH','4h','0.000038670000000','0.000049770000000','1.408299045957635','1.812543147590160','36418.38753446173','36418.387534461733594','test','test','0.3'),('2019-07-22 11:59:59','2019-07-22 23:59:59','LENDETH','4h','0.000022800000000','0.000022572000000','1.498131068542641','1.483149757857215','65707.50300625617','65707.503006256170920','test','test','1.0'),('2019-07-25 19:59:59','2019-07-25 23:59:59','LENDETH','4h','0.000022300000000','0.000022800000000','1.494801888390324','1.528317625798179','67031.47481570959','67031.474815709589166','test','test','0.0'),('2019-07-28 19:59:59','2019-07-28 23:59:59','LENDETH','4h','0.000022500000000','0.000022300000000','1.502249830036514','1.488896498213967','66766.65911273395','66766.659112733948859','test','test','0.9'),('2019-07-29 03:59:59','2019-07-29 07:59:59','LENDETH','4h','0.000022390000000','0.000022200000000','1.499282422964836','1.486559615445260','66962.14483987658','66962.144839876578772','test','test','0.8'),('2019-08-13 15:59:59','2019-08-13 19:59:59','LENDETH','4h','0.000018590000000','0.000018404100000','1.496455132404931','1.481490581080882','80497.85542791452','80497.855427914517350','test','test','1.0'),('2019-08-14 19:59:59','2019-08-14 23:59:59','LENDETH','4h','0.000019000000000','0.000018810000000','1.493129676555142','1.478198379789591','78585.77245027064','78585.772450270640547','test','test','1.0'),('2019-08-15 23:59:59','2019-08-16 03:59:59','LENDETH','4h','0.000019200000000','0.000019008000000','1.489811610607242','1.474913494501170','77594.35471912718','77594.354719127179123','test','test','1.0'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDETH','4h','0.000019350000000','0.000019156500000','1.486500918139226','1.471635908957834','76821.7528754122','76821.752875412203139','test','test','1.0'),('2019-08-24 23:59:59','2019-08-28 19:59:59','LENDETH','4h','0.000020400000000','0.000022200000000','1.483197582765583','1.614067957715487','72705.763861058','72705.763861058003386','test','test','0.5'),('2019-08-31 11:59:59','2019-08-31 15:59:59','LENDETH','4h','0.000022380000000','0.000022156200000','1.512279888310006','1.497157089426906','67572.82789588948','67572.827895889480715','test','test','1.0'),('2019-09-02 03:59:59','2019-09-02 19:59:59','LENDETH','4h','0.000021800000000','0.000021582000000','1.508919266335984','1.493830073672624','69216.48010715522','69216.480107155221049','test','test','1.0'),('2019-09-07 23:59:59','2019-09-08 07:59:59','LENDETH','4h','0.000021100000000','0.000020889000000','1.505566112410793','1.490510451286685','71353.84419008499','71353.844190084986622','test','test','1.0'),('2019-09-08 11:59:59','2019-09-08 15:59:59','LENDETH','4h','0.000020900000000','0.000020691000000','1.502220409938769','1.487198205839381','71876.5746382186','71876.574638218604377','test','test','1.0'),('2019-09-09 19:59:59','2019-09-09 23:59:59','LENDETH','4h','0.000029340000000','0.000029046600000','1.498882142361127','1.483893320937516','51086.64425225382','51086.644252253820014','test','test','1.0'),('2019-09-13 15:59:59','2019-09-14 15:59:59','LENDETH','4h','0.000022600000000','0.000022374000000','1.495551293155881','1.480595780224322','66174.8359803487','66174.835980348696467','test','test','1.0'),('2019-09-15 07:59:59','2019-09-16 03:59:59','LENDETH','4h','0.000022010000000','0.000022100000000','1.492227845837756','1.498329640754857','67797.72130112477','67797.721301124765887','test','test','0.5'),('2019-09-16 19:59:59','2019-09-16 23:59:59','LENDETH','4h','0.000022650000000','0.000022423500000','1.493583800263778','1.478647962261140','65941.8896363699','65941.889636369902291','test','test','1.0'),('2019-09-17 11:59:59','2019-09-17 15:59:59','LENDETH','4h','0.000022800000000','0.000022572000000','1.490264725152081','1.475362077900561','65362.48794526673','65362.487945266730094','test','test','1.0'),('2019-09-17 23:59:59','2019-09-19 23:59:59','LENDETH','4h','0.000023900000000','0.000023661000000','1.486953025762854','1.472083495505226','62215.607772504365','62215.607772504365130','test','test','1.0'),('2019-09-20 07:59:59','2019-09-20 15:59:59','LENDETH','4h','0.000024910000000','0.000024660900000','1.483648685705604','1.468812198848548','59560.36474129281','59560.364741292811232','test','test','1.0'),('2019-09-22 15:59:59','2019-09-22 19:59:59','LENDETH','4h','0.000027500000000','0.000027225000000','1.480351688626258','1.465548171739995','53830.97049550029','53830.970495500288962','test','test','1.0'),('2019-09-26 11:59:59','2019-09-26 15:59:59','LENDETH','4h','0.000026600000000','0.000026334000000','1.477062018207088','1.462291398025017','55528.64730101836','55528.647301018361759','test','test','1.0'),('2019-09-28 19:59:59','2019-09-28 23:59:59','LENDETH','4h','0.000026040000000','0.000025779600000','1.473779658166628','1.459041861584962','56596.76106630677','56596.761066306768043','test','test','1.0'),('2019-09-30 15:59:59','2019-09-30 19:59:59','LENDETH','4h','0.000025500000000','0.000025245000000','1.470504592259591','1.455799546336995','57666.84675527809','57666.846755278093042','test','test','1.0'),('2019-10-02 11:59:59','2019-10-09 15:59:59','LENDETH','4h','0.000025000000000','0.000026220000000','1.467236804276792','1.538837960325499','58689.47217107169','58689.472171071691264','test','test','0.0'),('2019-10-10 23:59:59','2019-10-11 03:59:59','LENDETH','4h','0.000028000000000','0.000027950000000','1.483148172287616','1.480499693408531','52969.57758170058','52969.577581700577866','test','test','0.2'),('2019-10-11 11:59:59','2019-10-11 23:59:59','LENDETH','4h','0.000028800000000','0.000028512000000','1.482559621425597','1.467734025211341','51477.764632833234','51477.764632833233918','test','test','1.0'),('2019-10-12 11:59:59','2019-11-02 15:59:59','LENDETH','4h','0.000028400000000','0.000065490000000','1.479265044489096','3.411164357872919','52086.797341165344','52086.797341165343823','test','test','0.0'),('2019-11-02 23:59:59','2019-11-07 11:59:59','LENDETH','4h','0.000065720000000','0.000068070000000','1.908576003018834','1.976822406048266','29041.022565715677','29041.022565715677047','test','test','0.0'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDETH','4h','0.000069280000000','0.000092850000000','1.923741870358708','2.578225067303782','27767.636696863563','27767.636696863562975','test','test','0.0'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDETH','4h','0.000105360000000','0.000104306400000','2.069182580790947','2.048490754983038','19639.166484348392','19639.166484348392260','test','test','1.0'),('2019-11-28 19:59:59','2019-11-28 23:59:59','LENDETH','4h','0.000101200000000','0.000100188000000','2.064584397278078','2.043938553305297','20401.0315936569','20401.031593656898622','test','test','1.0'),('2019-11-29 03:59:59','2019-11-29 15:59:59','LENDETH','4h','0.000101490000000','0.000100475100000','2.059996431950793','2.039396467631285','20297.531106028113','20297.531106028112845','test','test','1.0'),('2019-12-04 23:59:59','2019-12-05 03:59:59','LENDETH','4h','0.000100910000000','0.000099900900000','2.055418662102014','2.034864475480994','20368.83026560315','20368.830265603148291','test','test','1.0'),('2019-12-05 15:59:59','2019-12-05 19:59:59','LENDETH','4h','0.000097100000000','0.000096840000000','2.050851065075121','2.045359599813334','21121.02023764285','21121.020237642849679','test','test','0.3'),('2019-12-06 11:59:59','2019-12-10 03:59:59','LENDETH','4h','0.000099800000000','0.000099370000000','2.049630739461390','2.040799665133049','20537.382158931763','20537.382158931763115','test','test','0.4'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDETH','4h','0.000075670000000','0.000153280000000','2.047668278499537','4.147833933241826','27060.503217913792','27060.503217913792469','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:56:58
