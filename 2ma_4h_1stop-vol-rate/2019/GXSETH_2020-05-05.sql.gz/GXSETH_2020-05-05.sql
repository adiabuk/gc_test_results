-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.297777777777778','1.344373086107599','328.13597415367326','328.135974153673260','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.308132290739960','1.321438552840003','316.8157642867426','316.815764286742592','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.311089237873303','1.533131017573951','306.6875410229948','306.687541022994822','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 15:59:59','GXSETH','4h','0.005179000000000','0.005127210000000','1.360431855584558','1.346827537028712','262.68234322930266','262.682343229302660','test','test','1.0'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.357408673683259','1.348741388640173','279.5898400995384','279.589840099538378','test','test','0.6'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004518360000000','1.355482610340351','1.341927784236947','296.99443697203134','296.994436972031338','test','test','1.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.352470426761817','1.459776322159842','297.2462476399598','297.246247639959790','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.376316181294712','1.380056170917796','287.6915094679581','287.691509467958099','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.377147290099841','2.050945873130471','278.7747550809395','278.774755080939485','test','test','0.2'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSETH','4h','0.007801000000000','0.007722990000000','1.526880308551092','1.511611505465581','195.72879227677123','195.728792276771230','test','test','1.0'),('2019-03-28 11:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007755000000000','0.008025000000000','1.523487241198757','1.576529350176663','196.4522554737275','196.452255473727490','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','GXSETH','4h','0.008023000000000','0.007942770000000','1.535274376527180','1.519921632761908','191.35913953972081','191.359139539720815','test','test','1.0'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007833870000000','1.531862655690453','1.516544029133549','193.58810257682967','193.588102576829669','test','test','1.0'),('2019-04-12 19:59:59','2019-04-13 03:59:59','GXSETH','4h','0.007573000000000','0.007497270000000','1.528458516455586','1.513173931291030','201.82999028860235','201.829990288602346','test','test','1.0'),('2019-04-13 07:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007798000000000','0.007720020000000','1.525061941974573','1.509811322554827','195.57090817832432','195.570908178324316','test','test','1.0'),('2019-04-21 19:59:59','2019-04-22 03:59:59','GXSETH','4h','0.007866000000000','0.007787340000000','1.521672915436852','1.506456186282483','193.44939174127276','193.449391741272763','test','test','1.0'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007744770000000','1.518291420069214','1.503108505868522','194.0804576337996','194.080457633799597','test','test','1.0'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSETH','4h','0.004618000000000','0.004571820000000','1.514917439135727','1.499768264744370','328.0462189553329','328.046218955332904','test','test','1.0'),('2019-06-04 11:59:59','2019-06-20 23:59:59','GXSETH','4h','0.004464000000000','0.008338000000000','1.511550955937648','2.823322551659523','338.6090851114802','338.609085111480226','test','test','0.0'),('2019-06-23 07:59:59','2019-06-23 15:59:59','GXSETH','4h','0.008574000000000','0.008488260000000','1.803055754986953','1.785025197437083','210.29341672346084','210.293416723460837','test','test','1.0'),('2019-06-23 19:59:59','2019-06-23 23:59:59','GXSETH','4h','0.008451000000000','0.008684000000000','1.799048964420315','1.848650006747842','212.88000998938767','212.880009989387673','test','test','0.0'),('2019-06-24 03:59:59','2019-06-24 07:59:59','GXSETH','4h','0.008826000000000','0.008737740000000','1.810071418270877','1.791970704088168','205.08400388294552','205.084003882945524','test','test','1.0'),('2019-07-15 23:59:59','2019-07-16 03:59:59','GXSETH','4h','0.006579000000000','0.006513210000000','1.806049037341386','1.787988546967972','274.5172575378304','274.517257537830403','test','test','1.0'),('2019-07-17 03:59:59','2019-07-17 11:59:59','GXSETH','4h','0.006630000000000','0.006563700000000','1.802035595036183','1.784015239085821','271.8002405786098','271.800240578609817','test','test','1.0'),('2019-07-18 11:59:59','2019-07-18 15:59:59','GXSETH','4h','0.006650000000000','0.006583500000000','1.798031071491658','1.780050760776742','270.3806122543847','270.380612254384687','test','test','1.0'),('2019-07-20 19:59:59','2019-07-21 15:59:59','GXSETH','4h','0.007088000000000','0.007017120000000','1.794035446888343','1.776095092419460','253.10883844361504','253.108838443615042','test','test','1.0'),('2019-07-22 19:59:59','2019-07-23 03:59:59','GXSETH','4h','0.007030000000000','0.006959700000000','1.790048701450814','1.772148214436306','254.62997175687258','254.629971756872578','test','test','1.0'),('2019-07-24 03:59:59','2019-07-24 23:59:59','GXSETH','4h','0.006780000000000','0.006805000000000','1.786070815447590','1.792656622289211','263.4322736648363','263.432273664836316','test','test','0.0'),('2019-07-25 03:59:59','2019-07-27 03:59:59','GXSETH','4h','0.006884000000000','0.006940000000000','1.787534328079062','1.802075571886794','259.6650679952152','259.665067995215225','test','test','0.0'),('2019-07-30 03:59:59','2019-07-30 07:59:59','GXSETH','4h','0.007134000000000','0.007062660000000','1.790765715591891','1.772858058435972','251.0184630770803','251.018463077080298','test','test','1.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','GXSETH','4h','0.007900000000000','0.007821000000000','1.786786236223908','1.768918373861669','226.17547293973522','226.175472939735215','test','test','1.0'),('2019-07-31 15:59:59','2019-08-06 03:59:59','GXSETH','4h','0.007779000000000','0.007957000000000','1.782815600143411','1.823610198012742','229.18313409736615','229.183134097366150','test','test','0.0'),('2019-09-27 19:59:59','2019-09-27 23:59:59','GXSETH','4h','0.002496000000000','0.002471040000000','1.791881066336596','1.773962255673230','717.9010682438284','717.901068243828377','test','test','1.0'),('2019-09-28 03:59:59','2019-09-28 11:59:59','GXSETH','4h','0.002581000000000','0.002555190000000','1.787899108411403','1.770020117327289','692.715656106704','692.715656106704046','test','test','1.0'),('2019-09-28 15:59:59','2019-09-28 19:59:59','GXSETH','4h','0.002900000000000','0.002871000000000','1.783925999281600','1.766086739288784','615.146896304','615.146896304000052','test','test','1.0'),('2019-10-03 11:59:59','2019-10-04 03:59:59','GXSETH','4h','0.002456000000000','0.002525000000000','1.779961719283196','1.829968787129507','724.7401137146566','724.740113714656559','test','test','0.0'),('2019-10-09 03:59:59','2019-10-09 15:59:59','GXSETH','4h','0.002489000000000','0.002464110000000','1.791074401026821','1.773163657016553','719.5959827347615','719.595982734761492','test','test','1.0'),('2019-10-10 03:59:59','2019-10-10 07:59:59','GXSETH','4h','0.002552000000000','0.002526480000000','1.787094235691206','1.769223293334294','700.2720359291559','700.272035929155891','test','test','1.0'),('2019-10-10 19:59:59','2019-10-11 03:59:59','GXSETH','4h','0.002551000000000','0.002525490000000','1.783122915167448','1.765291686015774','698.9897746638369','698.989774663836897','test','test','1.0'),('2019-10-14 23:59:59','2019-10-15 07:59:59','GXSETH','4h','0.002511000000000','0.002495000000000','1.779160419800409','1.767823674791724','708.5465630427753','708.546563042775347','test','test','0.6'),('2019-10-15 11:59:59','2019-10-16 07:59:59','GXSETH','4h','0.003024000000000','0.002993760000000','1.776641143131813','1.758874731700495','587.5136055330067','587.513605533006739','test','test','1.0'),('2019-10-22 15:59:59','2019-10-22 19:59:59','GXSETH','4h','0.002735000000000','0.002707650000000','1.772693051702631','1.754966121185604','648.1510243885305','648.151024388530459','test','test','1.0'),('2019-10-27 15:59:59','2019-10-28 15:59:59','GXSETH','4h','0.003022000000000','0.002991780000000','1.768753733809958','1.751066196471858','585.2924334248703','585.292433424870296','test','test','1.0'),('2019-10-31 15:59:59','2019-10-31 19:59:59','GXSETH','4h','0.002755000000000','0.002727450000000','1.764823169957047','1.747174938257476','640.5891723982022','640.589172398202209','test','test','1.0'),('2019-11-02 03:59:59','2019-11-02 07:59:59','GXSETH','4h','0.003074000000000','0.003043260000000','1.760901340690476','1.743292327283571','572.8371309988535','572.837130998853468','test','test','1.0'),('2019-11-02 11:59:59','2019-11-03 11:59:59','GXSETH','4h','0.002939000000000','0.002909610000000','1.756988226600052','1.739418344334051','597.8183826471767','597.818382647176691','test','test','1.0'),('2019-11-03 15:59:59','2019-11-04 15:59:59','GXSETH','4h','0.002883000000000','0.002854170000000','1.753083808318719','1.735552970235532','608.0762429131871','608.076242913187116','test','test','1.0'),('2019-11-05 23:59:59','2019-11-06 07:59:59','GXSETH','4h','0.002941000000000','0.002911590000000','1.749188066522455','1.731696185857230','594.7596281953264','594.759628195326400','test','test','1.0'),('2019-11-06 15:59:59','2019-11-11 11:59:59','GXSETH','4h','0.002969000000000','0.002976000000000','1.745300981930183','1.749415871412673','587.841354641355','587.841354641354997','test','test','0.8'),('2019-11-12 03:59:59','2019-11-12 07:59:59','GXSETH','4h','0.003008000000000','0.002977920000000','1.746215401815181','1.728753247797029','580.5237373055787','580.523737305578720','test','test','1.0'),('2019-11-12 11:59:59','2019-11-13 07:59:59','GXSETH','4h','0.003078000000000','0.003047220000000','1.742334923144480','1.724911573913035','566.0607287668876','566.060728766887564','test','test','1.0'),('2019-11-13 11:59:59','2019-11-18 03:59:59','GXSETH','4h','0.003068000000000','0.003151000000000','1.738463067759715','1.785494500166513','566.6437639373255','566.643763937325502','test','test','0.0'),('2019-11-22 11:59:59','2019-11-22 15:59:59','GXSETH','4h','0.003090000000000','0.003074000000000','1.748914497183447','1.739858629236866','565.9917466613098','565.991746661309776','test','test','0.5'),('2019-11-28 19:59:59','2019-11-28 23:59:59','GXSETH','4h','0.003122000000000','0.003090780000000','1.746902082084207','1.729433061263365','559.5458302639997','559.545830263999733','test','test','1.0'),('2019-11-29 23:59:59','2019-11-30 11:59:59','GXSETH','4h','0.003153000000000','0.003121470000000','1.743020077457353','1.725589876682780','552.8132183499376','552.813218349937642','test','test','1.0'),('2019-12-03 07:59:59','2019-12-04 03:59:59','GXSETH','4h','0.003061000000000','0.003043000000000','1.739146699507448','1.728919766939289','568.1629204532663','568.162920453266338','test','test','0.6'),('2019-12-04 15:59:59','2019-12-04 19:59:59','GXSETH','4h','0.003024000000000','0.003020000000000','1.736874047825635','1.734576595381421','574.3631110534507','574.363111053450666','test','test','0.1'),('2019-12-04 23:59:59','2019-12-05 11:59:59','GXSETH','4h','0.003026000000000','0.003060000000000','1.736363502838032','1.755873205117111','573.8147729140885','573.814772914088508','test','test','0.0'),('2019-12-05 23:59:59','2019-12-06 07:59:59','GXSETH','4h','0.003044000000000','0.003020000000000','1.740698992233383','1.726974690060715','571.8459238611639','571.845923861163897','test','test','0.8'),('2019-12-16 15:59:59','2019-12-17 07:59:59','GXSETH','4h','0.002992000000000','0.002962080000000','1.737649147306123','1.720272655833062','580.7650893402819','580.765089340281861','test','test','1.0'),('2019-12-17 15:59:59','2019-12-17 19:59:59','GXSETH','4h','0.002975000000000','0.002995000000000','1.733787704756554','1.745443420418783','582.7857831114467','582.785783111446676','test','test','0.0'),('2019-12-17 23:59:59','2019-12-22 19:59:59','GXSETH','4h','0.003056000000000','0.003066000000000','1.736377863792605','1.742059728530146','568.1864737541246','568.186473754124563','test','test','0.7'),('2019-12-23 23:59:59','2019-12-24 07:59:59','GXSETH','4h','0.003080000000000','0.003049200000000','1.737640500400947','1.720264095396937','564.1689936366713','564.168993636671303','test','test','1.0'),('2019-12-24 15:59:59','2019-12-24 23:59:59','GXSETH','4h','0.003088000000000','0.003057120000000','1.733779077066723','1.716441286296056','561.4569550086538','561.456955008653836','test','test','1.0'),('2019-12-28 03:59:59','2019-12-28 15:59:59','GXSETH','4h','0.003103000000000','0.003071970000000','1.729926234673242','1.712626972326510','557.50120356856','557.501203568559959','test','test','1.0'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GXSETH','4h','0.003084000000000','0.003053160000000','1.726081954151746','1.708821134610229','559.6893495952482','559.689349595248245','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:39:36
