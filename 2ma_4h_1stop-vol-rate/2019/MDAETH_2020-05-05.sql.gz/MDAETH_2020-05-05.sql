-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005828823000000','1.297777777777778','1.284800000000000','220.4218587526161','220.421858752616089','test','test','1.0'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','1.294893827160494','1.306251962294859','221.4061429700767','221.406142970076701','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','1.297417857190353','1.379882700531593','217.5853386312391','217.585338631239097','test','test','0.7'),('2019-01-31 15:59:59','2019-02-05 23:59:59','MDAETH','4h','0.006709000000000','0.006641910000000','1.315743377932850','1.302585944153521','196.1161690166717','196.116169016671705','test','test','1.0'),('2019-02-06 03:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006657500000000','0.006697800000000','1.312819503759666','1.320766424676153','197.19406740663405','197.194067406634048','test','test','0.0'),('2019-02-23 07:59:59','2019-02-23 15:59:59','MDAETH','4h','0.006221500000000','0.006159285000000','1.314585486185552','1.301439631323696','211.29719298972148','211.297192989721481','test','test','1.0'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','1.311664185105140','1.369986859915891','212.85647741149913','212.856477411499128','test','test','0.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','MDAETH','4h','0.006495600000000','0.006430644000000','1.324624779507529','1.311378531712454','203.92647015018306','203.926470150183064','test','test','1.0'),('2019-03-08 07:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006430000000000','0.006365700000000','1.321681168886401','1.308464357197537','205.54917089990684','205.549170899906841','test','test','1.0'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MDAETH','4h','0.006945000000000','0.006875550000000','1.318744099622209','1.305556658625987','189.8839596288278','189.883959628827796','test','test','1.0'),('2019-03-10 03:59:59','2019-03-10 07:59:59','MDAETH','4h','0.007412900000000','0.007338771000000','1.315813557178604','1.302655421606818','177.50321158771928','177.503211587719278','test','test','1.0'),('2019-03-10 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.007617800000000','0.007541622000000','1.312889527051541','1.299760631781026','172.34497191466573','172.344971914665734','test','test','1.0'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.008079786000000','1.309971994769204','1.296872274821512','160.50824549332273','160.508245493322733','test','test','1.0'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDAETH','4h','0.008747000000000','0.008659530000000','1.307060945891939','1.293990336433020','149.42962683113515','149.429626831135153','test','test','1.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.008016228000000','1.304156366012179','1.291114802352057','161.06263473943824','161.062634739438238','test','test','1.0'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDAETH','4h','0.007632700000000','0.008177000000000','1.301258240754374','1.394053039507450','170.484656904421','170.484656904421001','test','test','0.0'),('2019-03-29 15:59:59','2019-03-29 23:59:59','MDAETH','4h','0.008488100000000','0.008403219000000','1.321879307143947','1.308660514072507','155.73323913996617','155.733239139966173','test','test','1.0'),('2019-03-30 03:59:59','2019-03-30 23:59:59','MDAETH','4h','0.008653900000000','0.008567361000000','1.318941797572516','1.305752379596791','152.41010383440016','152.410103834400161','test','test','1.0'),('2019-03-31 07:59:59','2019-03-31 19:59:59','MDAETH','4h','0.008552600000000','0.008467074000000','1.316010815800132','1.302850707642131','153.87260199239208','153.872601992392077','test','test','1.0'),('2019-04-01 07:59:59','2019-04-02 07:59:59','MDAETH','4h','0.008627000000000','0.008540730000000','1.313086347320577','1.299955483847371','152.20660105721302','152.206601057213021','test','test','1.0'),('2019-05-23 15:59:59','2019-05-23 19:59:59','MDAETH','4h','0.004172600000000','0.004130874000000','1.310168377659864','1.297066693883266','313.9932842016642','313.993284201664210','test','test','1.0'),('2019-06-02 11:59:59','2019-06-03 03:59:59','MDAETH','4h','0.003860000000000','0.003821400000000','1.307256892376176','1.294184323452414','338.66758869849116','338.667588698491159','test','test','1.0'),('2019-06-03 15:59:59','2019-06-03 23:59:59','MDAETH','4h','0.003849800000000','0.003842300000000','1.304351877059784','1.301810799840721','338.81029587505435','338.810295875054351','test','test','0.2'),('2019-06-05 19:59:59','2019-06-06 11:59:59','MDAETH','4h','0.004007800000000','0.003967722000000','1.303787193233326','1.290749321300993','325.3124390521797','325.312439052179684','test','test','1.0'),('2019-06-06 19:59:59','2019-06-07 07:59:59','MDAETH','4h','0.003950200000000','0.003929700000000','1.300889888359474','1.294138776336951','329.3225376840347','329.322537684034728','test','test','0.5'),('2019-06-07 15:59:59','2019-06-07 19:59:59','MDAETH','4h','0.003972000000000','0.003932280000000','1.299389641243358','1.286395744830924','327.13737191423917','327.137371914239168','test','test','1.0'),('2019-06-09 03:59:59','2019-06-12 15:59:59','MDAETH','4h','0.004180400000000','0.004138596000000','1.296502108707261','1.283537087620188','310.1382902849635','310.138290284963489','test','test','1.0'),('2019-07-03 19:59:59','2019-07-03 23:59:59','MDAETH','4h','0.003031800000000','0.003001482000000','1.293620992910134','1.280684782981033','426.68414569237217','426.684145692372169','test','test','1.0'),('2019-07-07 07:59:59','2019-07-07 11:59:59','MDAETH','4h','0.002951500000000','0.002941000000000','1.290746279592556','1.286154432756804','437.31874626208906','437.318746262089064','test','test','0.4'),('2019-07-07 15:59:59','2019-07-07 19:59:59','MDAETH','4h','0.003012800000000','0.002982672000000','1.289725869184611','1.276828610492765','428.08213926732975','428.082139267329751','test','test','1.0'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDAETH','4h','0.003124000000000','0.003092760000000','1.286859811697534','1.273991213580559','411.92695636924907','411.926956369249069','test','test','1.0'),('2019-07-13 19:59:59','2019-07-13 23:59:59','MDAETH','4h','0.002919100000000','0.002889909000000','1.284000123227095','1.271160121994824','439.8616433925166','439.861643392516612','test','test','1.0'),('2019-07-14 15:59:59','2019-07-14 23:59:59','MDAETH','4h','0.002881100000000','0.002852289000000','1.281146789619924','1.268335321723725','444.6727949810572','444.672794981057223','test','test','1.0'),('2019-07-15 19:59:59','2019-07-16 03:59:59','MDAETH','4h','0.002959900000000','0.002930301000000','1.278299796754102','1.265516798786561','431.87262973549844','431.872629735498435','test','test','1.0'),('2019-07-17 23:59:59','2019-07-18 03:59:59','MDAETH','4h','0.003043300000000','0.003012867000000','1.275459130539093','1.262704539233702','419.1039761243035','419.103976124303472','test','test','1.0'),('2019-07-19 11:59:59','2019-07-19 19:59:59','MDAETH','4h','0.002984600000000','0.002954754000000','1.272624776915672','1.259898529146515','426.3970974052377','426.397097405237673','test','test','1.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','MDAETH','4h','0.002930000000000','0.002931600000000','1.269796721855860','1.270490126209092','433.3777207699181','433.377720769918085','test','test','0.0'),('2019-07-22 15:59:59','2019-07-24 23:59:59','MDAETH','4h','0.003016900000000','0.003019700000000','1.269950811712134','1.271129459420972','420.9456102993582','420.945610299358179','test','test','0.0'),('2019-07-26 11:59:59','2019-07-26 15:59:59','MDAETH','4h','0.003019400000000','0.003016000000000','1.270212733425209','1.268782408428969','420.6838224233982','420.683822423398226','test','test','0.1'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDAETH','4h','0.003285100000000','0.003252249000000','1.269894883426044','1.257195934591784','386.56201741987894','386.562017419878941','test','test','1.0'),('2019-07-28 07:59:59','2019-07-29 15:59:59','MDAETH','4h','0.003106300000000','0.003075237000000','1.267072894796209','1.254402165848247','407.9042252184942','407.904225218494219','test','test','1.0'),('2019-07-30 19:59:59','2019-07-31 07:59:59','MDAETH','4h','0.003187500000000','0.003155625000000','1.264257177252217','1.251614605479695','396.6297026673623','396.629702667362324','test','test','1.0'),('2019-08-01 19:59:59','2019-08-03 03:59:59','MDAETH','4h','0.003181000000000','0.003149190000000','1.261447716858324','1.248833239689741','396.55696851880657','396.556968518806571','test','test','1.0'),('2019-08-03 15:59:59','2019-08-03 23:59:59','MDAETH','4h','0.003350000000000','0.003316500000000','1.258644499709749','1.246058054712651','375.714776032761','375.714776032760994','test','test','1.0'),('2019-08-09 11:59:59','2019-08-09 15:59:59','MDAETH','4h','0.003191700000000','0.003165200000000','1.255847511932616','1.245420479609336','393.4729178596411','393.472917859641086','test','test','0.8'),('2019-08-14 19:59:59','2019-08-14 23:59:59','MDAETH','4h','0.003215700000000','0.003183543000000','1.253530393638554','1.240995089702168','389.8157146619878','389.815714661987784','test','test','1.0'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MDAETH','4h','0.003298300000000','0.003265317000000','1.250744770541580','1.238237322836164','379.20891687887075','379.208916878870752','test','test','1.0'),('2019-08-16 15:59:59','2019-08-16 19:59:59','MDAETH','4h','0.003210700000000','0.003178593000000','1.247965337718154','1.235485684340973','388.6894875628847','388.689487562884722','test','test','1.0'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDAETH','4h','0.003568200000000','0.003532518000000','1.245192081412114','1.232740160597993','348.9692509982942','348.969250998294228','test','test','1.0'),('2019-08-21 07:59:59','2019-08-22 03:59:59','MDAETH','4h','0.003528800000000','0.003493512000000','1.242424987897864','1.230000738018885','352.0814406874474','352.081440687447412','test','test','1.0'),('2019-08-23 19:59:59','2019-08-23 23:59:59','MDAETH','4h','0.003565500000000','0.003529845000000','1.239664043480314','1.227267403045511','347.6830860974095','347.683086097409500','test','test','1.0'),('2019-08-25 19:59:59','2019-08-25 23:59:59','MDAETH','4h','0.003591900000000','0.003555981000000','1.236909234494802','1.224540142149854','344.3607100684323','344.360710068432297','test','test','1.0'),('2019-08-26 15:59:59','2019-08-28 07:59:59','MDAETH','4h','0.003508200000000','0.003473118000000','1.234160547307036','1.221818941833966','351.79309825752114','351.793098257521137','test','test','1.0'),('2019-08-31 19:59:59','2019-08-31 23:59:59','MDAETH','4h','0.003523000000000','0.003487770000000','1.231417968313020','1.219103788629890','349.5367494501902','349.536749450190200','test','test','1.0'),('2019-09-01 11:59:59','2019-09-01 23:59:59','MDAETH','4h','0.003471000000000','0.003450000000000','1.228681483938991','1.221247801667968','353.9848700486866','353.984870048686616','test','test','0.6'),('2019-09-02 11:59:59','2019-09-02 15:59:59','MDAETH','4h','0.003446600000000','0.003412134000000','1.227029554545431','1.214759258999977','356.0115924521066','356.011592452106584','test','test','1.0'),('2019-09-04 19:59:59','2019-09-04 23:59:59','MDAETH','4h','0.003475900000000','0.003441141000000','1.224302822201996','1.212059793979976','352.2261348721184','352.226134872118394','test','test','1.0'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003538600000000','0.003503214000000','1.221582149263770','1.209366327771132','345.2162293742638','345.216229374263776','test','test','1.0'),('2019-09-24 19:59:59','2019-09-24 23:59:59','MDAETH','4h','0.003246700000000','0.003214233000000','1.218867522265406','1.206678847042752','375.4173537023457','375.417353702345679','test','test','1.0'),('2019-09-25 03:59:59','2019-10-07 23:59:59','MDAETH','4h','0.003250900000000','0.005117600000000','1.216158927771483','1.914489811671642','374.0991503188294','374.099150318829402','test','test','0.0'),('2019-10-11 19:59:59','2019-10-11 23:59:59','MDAETH','4h','0.005774200000000','0.005716458000000','1.371343568638185','1.357630132951803','237.49498954628947','237.494989546289474','test','test','1.0'),('2019-10-12 23:59:59','2019-10-13 11:59:59','MDAETH','4h','0.006224000000000','0.006161760000000','1.368296138485655','1.354613177100798','219.8419245638906','219.841924563890586','test','test','1.0'),('2019-10-13 15:59:59','2019-10-13 19:59:59','MDAETH','4h','0.006421900000000','0.006357681000000','1.365255480400132','1.351602925596131','212.5936997462015','212.593699746201509','test','test','1.0'),('2019-10-14 15:59:59','2019-10-15 15:59:59','MDAETH','4h','0.006517700000000','0.006452523000000','1.362221579332576','1.348599363539250','209.00341828138386','209.003418281383858','test','test','1.0'),('2019-10-25 23:59:59','2019-10-26 03:59:59','MDAETH','4h','0.004694400000000','0.004647456000000','1.359194420267392','1.345602476064718','289.5352803909748','289.535280390974776','test','test','1.0'),('2019-10-27 23:59:59','2019-10-28 03:59:59','MDAETH','4h','0.004637300000000','0.004590927000000','1.356173988222354','1.342612248340131','292.44905186689533','292.449051866895331','test','test','1.0'),('2019-11-09 23:59:59','2019-11-10 03:59:59','MDAETH','4h','0.004107700000000','0.004066623000000','1.353160268248526','1.339628665566041','329.4204221945435','329.420422194543505','test','test','1.0'),('2019-11-10 11:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004111100000000','0.004106300000000','1.350153245430196','1.348576846029047','328.4165419061069','328.416541906106886','test','test','0.6'),('2019-11-11 07:59:59','2019-11-11 11:59:59','MDAETH','4h','0.004107800000000','0.004066722000000','1.349802934452163','1.336304905107641','328.59509578172333','328.595095781723330','test','test','1.0'),('2019-11-22 15:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003867400000000','0.003828726000000','1.346803372375603','1.333335338651847','348.2451704958377','348.245170495837726','test','test','1.0'),('2019-11-25 19:59:59','2019-11-26 23:59:59','MDAETH','4h','0.003929600000000','0.003940800000000','1.343810475992546','1.347640554710766','341.9713141267675','341.971314126767481','test','test','0.9'),('2019-11-27 19:59:59','2019-11-28 03:59:59','MDAETH','4h','0.003971400000000','0.003931686000000','1.344661604596594','1.331214988550628','338.5862931451363','338.586293145136324','test','test','1.0'),('2019-11-29 19:59:59','2019-11-30 11:59:59','MDAETH','4h','0.003957800000000','0.003918222000000','1.341673467697491','1.328256733020516','338.9947616598845','338.994761659884489','test','test','1.0'),('2019-11-30 19:59:59','2019-11-30 23:59:59','MDAETH','4h','0.003917000000000','0.003908100000000','1.338691971102608','1.335650266087848','341.7646083999509','341.764608399950873','test','test','0.2'),('2019-12-01 03:59:59','2019-12-01 07:59:59','MDAETH','4h','0.003923400000000','0.003884166000000','1.338016036654883','1.324635876288334','341.0348260832144','341.034826083214398','test','test','1.0'),('2019-12-01 11:59:59','2019-12-01 15:59:59','MDAETH','4h','0.003940700000000','0.003901293000000','1.335042667684539','1.321692241007694','338.7831267755828','338.783126775582787','test','test','1.0'),('2019-12-09 15:59:59','2019-12-09 23:59:59','MDAETH','4h','0.003756300000000','0.003718737000000','1.332075906200796','1.318755147138788','354.62447253967883','354.624472539678834','test','test','1.0'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003787200000000','0.003749328000000','1.329115737520349','1.315824580145146','350.9494448458886','350.949444845888593','test','test','1.0'),('2019-12-16 19:59:59','2019-12-22 11:59:59','MDAETH','4h','0.003712800000000','0.003806900000000','1.326162146992526','1.359773399425191','357.18652957135487','357.186529571354868','test','test','0.3'),('2019-12-23 07:59:59','2019-12-23 11:59:59','MDAETH','4h','0.003826200000000','0.003787938000000','1.333631314199785','1.320295001057787','348.5524317076434','348.552431707643393','test','test','1.0'),('2019-12-24 07:59:59','2019-12-24 11:59:59','MDAETH','4h','0.003826200000000','0.003797200000000','1.330667689057119','1.320582130805418','347.77787074829314','347.777870748293140','test','test','0.8'),('2019-12-24 15:59:59','2019-12-24 19:59:59','MDAETH','4h','0.003834100000000','0.003834100000000','1.328426453890075','1.328426453890075','346.47673610236416','346.476736102364157','test','test','0.0'),('2019-12-26 11:59:59','2019-12-26 15:59:59','MDAETH','4h','0.004141100000000','0.004099689000000','1.328426453890075','1.315142189351174','320.79072079642475','320.790720796424750','test','test','1.0'),('2019-12-27 07:59:59','2019-12-28 15:59:59','MDAETH','4h','0.003994300000000','0.003954357000000','1.325474395103652','1.312219651152616','331.8414728747595','331.841472874759518','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:45:02
