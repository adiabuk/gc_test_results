-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.297777777777778','1.288978255786767','15171.589639674745','15171.589639674744831','test','test','0.7'),('2019-01-12 03:59:59','2019-01-12 07:59:59','RCNETH','4h','0.000086100000000','0.000085239000000','1.295822328446442','1.282864105161978','15050.201259540558','15050.201259540557658','test','test','1.0'),('2019-01-12 19:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000085960000000','0.000085100400000','1.292942723272117','1.280013296039396','15041.21362578079','15041.213625780790608','test','test','1.0'),('2019-01-13 11:59:59','2019-01-13 15:59:59','RCNETH','4h','0.000088320000000','0.000087436800000','1.290069517220401','1.277168822048197','14606.765367078815','14606.765367078814961','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000087740000000','0.000086862600000','1.287202696071022','1.274330669110312','14670.64846217258','14670.648462172579457','test','test','1.0'),('2019-01-14 23:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000086760000000','0.000100820000000','1.284342245635309','1.492477929978698','14803.391489572485','14803.391489572484716','test','test','0.6'),('2019-01-26 11:59:59','2019-01-27 07:59:59','RCNETH','4h','0.000103830000000','0.000102791700000','1.330594619933840','1.317288673734502','12815.126841315994','12815.126841315994170','test','test','1.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101811600000','1.327637743000653','1.314361365570646','12909.740791527163','12909.740791527163310','test','test','1.0'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.324687436905096','1.315065010002638','12829.902536611104','12829.902536611103642','test','test','0.7'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.322549119815661','1.315876060022297','12832.807294931703','12832.807294931702927','test','test','0.5'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000099227700000','1.321066217639358','1.307855555462964','13180.347377425505','13180.347377425505329','test','test','1.0'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.318130514933493','1.321843932220759','13262.204597378939','13262.204597378939070','test','test','0.0'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000101583900000','1.318955718775108','1.305766161587357','12854.066063493885','12854.066063493884940','test','test','1.0'),('2019-02-21 23:59:59','2019-02-23 19:59:59','RCNETH','4h','0.000108920000000','0.000107830800000','1.316024706066719','1.302864459006052','12082.489038438474','12082.489038438474381','test','test','1.0'),('2019-02-25 19:59:59','2019-02-26 23:59:59','RCNETH','4h','0.000142190000000','0.000140768100000','1.313100206719904','1.299969204652705','9234.828094239423','9234.828094239423081','test','test','1.0'),('2019-02-28 19:59:59','2019-03-01 07:59:59','RCNETH','4h','0.000164020000000','0.000162379800000','1.310182206260526','1.297080384197921','7987.9417525943545','7987.941752594354512','test','test','1.0'),('2019-03-04 03:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149450000000','0.000169370000000','1.307270690246614','1.481515134205882','8747.211042131908','8747.211042131908471','test','test','0.5'),('2019-03-14 03:59:59','2019-03-14 11:59:59','RCNETH','4h','0.000170940000000','0.000169230600000','1.345991677793118','1.332531761015187','7874.059189148929','7874.059189148929363','test','test','1.0'),('2019-03-14 15:59:59','2019-03-14 19:59:59','RCNETH','4h','0.000171780000000','0.000170062200000','1.343000585175800','1.329570579324042','7818.142887273256','7818.142887273255837','test','test','1.0'),('2019-03-14 23:59:59','2019-03-15 03:59:59','RCNETH','4h','0.000179620000000','0.000177823800000','1.340016139430965','1.326615978036655','7460.283595540389','7460.283595540388887','test','test','1.0'),('2019-03-15 15:59:59','2019-03-16 07:59:59','RCNETH','4h','0.000176760000000','0.000174992400000','1.337038325787785','1.323667942529907','7564.145314481698','7564.145314481697824','test','test','1.0'),('2019-03-18 07:59:59','2019-03-18 11:59:59','RCNETH','4h','0.000181490000000','0.000179675100000','1.334067129508256','1.320726458213173','7350.637112283079','7350.637112283078750','test','test','1.0'),('2019-03-18 15:59:59','2019-03-19 11:59:59','RCNETH','4h','0.000181430000000','0.000179615700000','1.331102535887127','1.317791510528255','7336.727861363207','7336.727861363207012','test','test','1.0'),('2019-03-24 15:59:59','2019-03-25 03:59:59','RCNETH','4h','0.000175890000000','0.000174131100000','1.328144530251822','1.314863084949304','7550.995112012177','7550.995112012176833','test','test','1.0'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000171675900000','1.325193097962373','1.311941166982749','7641.964696167311','7641.964696167310649','test','test','1.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','RCNETH','4h','0.000177820000000','0.000176041800000','1.322248224411346','1.309025742167233','7435.880240756641','7435.880240756640887','test','test','1.0'),('2019-03-28 07:59:59','2019-03-29 11:59:59','RCNETH','4h','0.000182860000000','0.000181031400000','1.319309895023765','1.306116796073527','7214.863256172838','7214.863256172838192','test','test','1.0'),('2019-03-29 19:59:59','2019-03-29 23:59:59','RCNETH','4h','0.000187130000000','0.000185258700000','1.316378095257046','1.303214314304476','7034.5647157433095','7034.564715743309534','test','test','1.0'),('2019-03-30 11:59:59','2019-03-31 11:59:59','RCNETH','4h','0.000233360000000','0.000231026400000','1.313452810600919','1.300318282494910','5628.440223692659','5628.440223692658947','test','test','1.0'),('2019-04-13 07:59:59','2019-04-13 11:59:59','RCNETH','4h','0.000187440000000','0.000185565600000','1.310534026577362','1.297428686311588','6991.752169106709','6991.752169106708607','test','test','1.0'),('2019-04-13 15:59:59','2019-04-13 19:59:59','RCNETH','4h','0.000191950000000','0.000190030500000','1.307621728740523','1.294545511453118','6812.303874657581','6812.303874657581218','test','test','1.0'),('2019-04-14 07:59:59','2019-04-14 15:59:59','RCNETH','4h','0.000194680000000','0.000192733200000','1.304715902676655','1.291668743649888','6701.848688497304','6701.848688497303556','test','test','1.0'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.301816534004040','1.301051414220216','6955.634398397308','6955.634398397308360','test','test','0.3'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000186298200000','1.301646507385412','1.288630042311558','6917.028947738401','6917.028947738401257','test','test','1.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','RCNETH','4h','0.000193870000000','0.000191931300000','1.298753959591223','1.285766419995311','6699.097124832221','6699.097124832221198','test','test','1.0'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000185941800000','1.295867839681020','1.282909161284210','6899.519964226493','6899.519964226493357','test','test','1.0'),('2019-05-02 07:59:59','2019-05-02 11:59:59','RCNETH','4h','0.000162370000000','0.000191310000000','1.292988133370618','1.523443738345340','7963.220628013904','7963.220628013904388','test','test','0.0'),('2019-05-02 15:59:59','2019-05-02 23:59:59','RCNETH','4h','0.000206320000000','0.000204256800000','1.344200490031667','1.330758485131350','6515.124515469501','6515.124515469500693','test','test','1.0'),('2019-05-10 15:59:59','2019-05-10 23:59:59','RCNETH','4h','0.000179030000000','0.000177239700000','1.341213377831597','1.327801244053281','7491.556598511964','7491.556598511963784','test','test','1.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','RCNETH','4h','0.000134020000000','0.000132679800000','1.338232903658638','1.324850574622052','9985.322367248453','9985.322367248452792','test','test','1.0'),('2019-05-24 07:59:59','2019-05-24 11:59:59','RCNETH','4h','0.000131330000000','0.000130016700000','1.335259052761619','1.321906462234003','10167.205153138038','10167.205153138038440','test','test','1.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','RCNETH','4h','0.000137390000000','0.000136016100000','1.332291810422148','1.318968892317926','9697.152707053994','9697.152707053994163','test','test','1.0'),('2019-05-28 07:59:59','2019-05-28 11:59:59','RCNETH','4h','0.000130730000000','0.000130940000000','1.329331161954543','1.331466552025762','10168.524148661696','10168.524148661696017','test','test','0.0'),('2019-06-02 03:59:59','2019-06-03 07:59:59','RCNETH','4h','0.000127600000000','0.000127150000000','1.329805693081481','1.325115939461679','10421.674710669915','10421.674710669914930','test','test','0.4'),('2019-06-07 11:59:59','2019-06-07 23:59:59','RCNETH','4h','0.000124930000000','0.000126490000000','1.328763525610414','1.345355786075892','10636.064400947842','10636.064400947841932','test','test','0.7'),('2019-06-08 07:59:59','2019-06-08 19:59:59','RCNETH','4h','0.000128340000000','0.000127056600000','1.332450694602742','1.319126187656714','10382.193350496667','10382.193350496667335','test','test','1.0'),('2019-06-10 07:59:59','2019-06-11 03:59:59','RCNETH','4h','0.000130490000000','0.000129185100000','1.329489693059181','1.316194796128589','10188.441206676225','10188.441206676225192','test','test','1.0'),('2019-06-11 19:59:59','2019-06-12 11:59:59','RCNETH','4h','0.000133950000000','0.000132610500000','1.326535271519049','1.313269918803859','9903.212180060089','9903.212180060088940','test','test','1.0'),('2019-06-14 03:59:59','2019-06-14 07:59:59','RCNETH','4h','0.000131500000000','0.000130185000000','1.323587415360118','1.310351541206517','10065.303538860213','10065.303538860212939','test','test','1.0'),('2019-06-20 07:59:59','2019-06-20 15:59:59','RCNETH','4h','0.000123180000000','0.000124260000000','1.320646109992651','1.332225082218597','10721.270579579892','10721.270579579892001','test','test','0.0'),('2019-06-20 23:59:59','2019-06-21 03:59:59','RCNETH','4h','0.000129480000000','0.000128185200000','1.323219214931750','1.309987022782433','10219.487294808081','10219.487294808081060','test','test','1.0'),('2019-06-21 11:59:59','2019-06-21 19:59:59','RCNETH','4h','0.000131100000000','0.000129789000000','1.320278727787457','1.307075940509583','10070.775955663292','10070.775955663291825','test','test','1.0'),('2019-07-10 23:59:59','2019-07-11 15:59:59','RCNETH','4h','0.000090450000000','0.000089545500000','1.317344775059041','1.304171327308451','14564.342455047441','14564.342455047441035','test','test','1.0'),('2019-07-22 15:59:59','2019-07-23 19:59:59','RCNETH','4h','0.000083100000000','0.000083890000000','1.314417342225577','1.326913006489815','15817.29653701055','15817.296537010550310','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 07:59:59','RCNETH','4h','0.000083110000000','0.000085720000000','1.317194156506518','1.358559536707240','15848.804674606166','15848.804674606166373','test','test','0.0'),('2019-07-24 11:59:59','2019-07-24 15:59:59','RCNETH','4h','0.000086570000000','0.000085704300000','1.326386463217790','1.313122598585612','15321.548610578606','15321.548610578605803','test','test','1.0'),('2019-07-26 11:59:59','2019-07-30 07:59:59','RCNETH','4h','0.000089270000000','0.000088377300000','1.323438937743973','1.310204548366533','14825.125324789655','14825.125324789654769','test','test','1.0'),('2019-08-09 07:59:59','2019-08-09 11:59:59','RCNETH','4h','0.000083070000000','0.000082239300000','1.320497962326764','1.307292982703496','15896.207563822845','15896.207563822845259','test','test','1.0'),('2019-08-10 19:59:59','2019-08-11 07:59:59','RCNETH','4h','0.000085660000000','0.000084803400000','1.317563522410482','1.304387887186377','15381.315928210157','15381.315928210156926','test','test','1.0'),('2019-08-18 11:59:59','2019-08-18 19:59:59','RCNETH','4h','0.000079940000000','0.000079140600000','1.314635603471792','1.301489247437074','16445.279002649386','16445.279002649385802','test','test','1.0'),('2019-08-20 19:59:59','2019-08-20 23:59:59','RCNETH','4h','0.000079750000000','0.000078952500000','1.311714191019632','1.298597049109435','16447.826846641157','16447.826846641157317','test','test','1.0'),('2019-08-21 07:59:59','2019-08-21 11:59:59','RCNETH','4h','0.000079880000000','0.000079081200000','1.308799270595144','1.295711277889192','16384.567734040364','16384.567734040363575','test','test','1.0'),('2019-08-22 03:59:59','2019-08-22 07:59:59','RCNETH','4h','0.000082200000000','0.000081378000000','1.305890827771599','1.292831919493883','15886.7497295815','15886.749729581499196','test','test','1.0'),('2019-08-24 07:59:59','2019-08-28 19:59:59','RCNETH','4h','0.000085060000000','0.000084209400000','1.302988848154329','1.289958959672786','15318.467530617554','15318.467530617554075','test','test','1.0'),('2019-08-29 03:59:59','2019-08-29 07:59:59','RCNETH','4h','0.000085240000000','0.000084387600000','1.300093317380653','1.287092384206846','15252.150602776313','15252.150602776313463','test','test','1.0'),('2019-08-29 19:59:59','2019-09-01 23:59:59','RCNETH','4h','0.000085250000000','0.000084950000000','1.297204221119807','1.292639279579209','15216.471801991871','15216.471801991870962','test','test','0.4'),('2019-09-16 11:59:59','2019-09-16 15:59:59','RCNETH','4h','0.000075610000000','0.000078610000000','1.296189789666341','1.347619089613425','17143.099982361335','17143.099982361334696','test','test','0.0'),('2019-09-17 07:59:59','2019-09-17 11:59:59','RCNETH','4h','0.000077910000000','0.000077130900000','1.307618522987915','1.294542337758036','16783.705852752082','16783.705852752082137','test','test','1.0'),('2019-09-19 03:59:59','2019-09-19 07:59:59','RCNETH','4h','0.000097280000000','0.000096307200000','1.304712704047942','1.291665577007463','13411.93157944019','13411.931579440190035','test','test','1.0'),('2019-09-19 11:59:59','2019-09-30 19:59:59','RCNETH','4h','0.000099630000000','0.000188800000000','1.301813342483391','2.466951310457334','13066.47939860876','13066.479398608760675','test','test','0.0'),('2019-10-01 11:59:59','2019-10-07 07:59:59','RCNETH','4h','0.000209760000000','0.000212630000000','1.560732890922045','1.582087312150812','7440.564888072297','7440.564888072297435','test','test','0.0'),('2019-10-07 19:59:59','2019-10-07 23:59:59','RCNETH','4h','0.000231010000000','0.000228699900000','1.565478317861771','1.549823534683153','6776.669052689369','6776.669052689368982','test','test','1.0'),('2019-10-08 11:59:59','2019-10-09 15:59:59','RCNETH','4h','0.000225390000000','0.000223136100000','1.561999477155411','1.546379482383857','6930.207538734688','6930.207538734687660','test','test','1.0'),('2019-10-09 19:59:59','2019-10-09 23:59:59','RCNETH','4h','0.000219850000000','0.000219190000000','1.558528367206177','1.553849592030575','7089.053296366509','7089.053296366509130','test','test','0.3'),('2019-10-15 15:59:59','2019-10-15 19:59:59','RCNETH','4h','0.000219030000000','0.000227200000000','1.557488639389377','1.615584252701760','7110.846182666194','7110.846182666194181','test','test','0.0'),('2019-10-21 07:59:59','2019-10-25 07:59:59','RCNETH','4h','0.000215740000000','0.000240460000000','1.570398775681017','1.750338785576422','7279.126613891803','7279.126613891802663','test','test','0.0'),('2019-10-29 23:59:59','2019-10-30 03:59:59','RCNETH','4h','0.000227020000000','0.000224749800000','1.610385444546663','1.594281590101196','7093.584021437154','7093.584021437153751','test','test','1.0'),('2019-11-01 15:59:59','2019-11-04 15:59:59','RCNETH','4h','0.000226350000000','0.000226800000000','1.606806810225448','1.610001257164266','7098.770975151085','7098.770975151084713','test','test','0.0'),('2019-11-06 19:59:59','2019-11-07 07:59:59','RCNETH','4h','0.000256040000000','0.000253479600000','1.607516687322963','1.591441520449733','6278.381062814259','6278.381062814259167','test','test','1.0'),('2019-11-10 07:59:59','2019-11-10 19:59:59','RCNETH','4h','0.000252840000000','0.000250730000000','1.603944428017801','1.590559193311593','6343.713130904133','6343.713130904133322','test','test','0.9'),('2019-11-10 23:59:59','2019-11-11 15:59:59','RCNETH','4h','0.000256440000000','0.000253875600000','1.600969931416421','1.584960232102257','6243.0585377336665','6243.058537733666526','test','test','1.0'),('2019-11-12 07:59:59','2019-11-12 15:59:59','RCNETH','4h','0.000257540000000','0.000254964600000','1.597412220457718','1.581438098253141','6202.579096286861','6202.579096286861386','test','test','1.0'),('2019-11-14 15:59:59','2019-11-15 19:59:59','RCNETH','4h','0.000258120000000','0.000255538800000','1.593862415523368','1.577923791368134','6174.889258962375','6174.889258962374697','test','test','1.0'),('2019-11-16 07:59:59','2019-11-16 11:59:59','RCNETH','4h','0.000257990000000','0.000255410100000','1.590320499044427','1.574417294053983','6164.271867298838','6164.271867298837606','test','test','1.0'),('2019-11-16 19:59:59','2019-11-16 23:59:59','RCNETH','4h','0.000269080000000','0.000266389200000','1.586786453490995','1.570918588956085','5897.08062097144','5897.080620971440112','test','test','1.0'),('2019-11-20 11:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000262860000000','0.000260231400000','1.583260261372126','1.567427658758405','6023.207263836742','6023.207263836741731','test','test','1.0'),('2019-11-21 19:59:59','2019-11-30 15:59:59','RCNETH','4h','0.000257850000000','0.000302910000000','1.579741905235744','1.855806168372927','6126.592612897977','6126.592612897977233','test','test','0.0'),('2019-12-01 07:59:59','2019-12-01 23:59:59','RCNETH','4h','0.000372200000000','0.000368478000000','1.641089519266229','1.624678624073567','4409.160449398788','4409.160449398787932','test','test','1.0'),('2019-12-06 11:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000326180000000','0.000324160000000','1.637442653667859','1.627302135670406','5020.058414580474','5020.058414580474164','test','test','0.6'),('2019-12-08 15:59:59','2019-12-08 19:59:59','RCNETH','4h','0.000328820000000','0.000325531800000','1.635189205223981','1.618837313171741','4972.900691028467','4972.900691028467008','test','test','1.0'),('2019-12-09 11:59:59','2019-12-09 15:59:59','RCNETH','4h','0.000347170000000','0.000343698300000','1.631555451434594','1.615239896920248','4699.586517943931','4699.586517943930630','test','test','1.0'),('2019-12-16 03:59:59','2019-12-16 07:59:59','RCNETH','4h','0.000313830000000','0.000310691700000','1.627929772653628','1.611650474927092','5187.298131643336','5187.298131643336092','test','test','1.0'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RCNETH','4h','0.000313580000000','0.000311500000000','1.624312150936620','1.613537964847111','5179.897158417693','5179.897158417693390','test','test','0.7'),('2019-12-18 03:59:59','2019-12-18 07:59:59','RCNETH','4h','0.000324620000000','0.000321373800000','1.621917887361174','1.605698708487562','4996.358472556139','4996.358472556138622','test','test','1.0'),('2019-12-19 19:59:59','2019-12-27 07:59:59','RCNETH','4h','0.000335480000000','0.000349810000000','1.618313625389260','1.687439755864484','4823.875120392454','4823.875120392453937','test','test','0.0'),('2019-12-27 15:59:59','2019-12-27 19:59:59','RCNETH','4h','0.000355150000000','0.000351598500000','1.633674987717088','1.617338237839917','4599.957729739795','4599.957729739794559','test','test','1.0'),('2019-12-30 03:59:59','2019-12-30 07:59:59','RCNETH','4h','0.000351600000000','0.000348084000000','1.630044598855495','1.613744152866940','4636.076788553739','4636.076788553738879','test','test','1.0'),('2019-12-31 19:59:59','2019-12-31 23:59:59','RCNETH','4h','0.000349810000000','0.000346420000000','1.626422277524704','1.610660659729876','4649.444777235369','4649.444777235368747','test','test','1.0'),('2020-01-01 07:59:59','2020-01-01 11:59:59','RCNETH','4h','0.000351600000000','0.000353400000000','1.622919695792520','1.631228158398967','4615.812559136861','4615.812559136860727','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:42:11
