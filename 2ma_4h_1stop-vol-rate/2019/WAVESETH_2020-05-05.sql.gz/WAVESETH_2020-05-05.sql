-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 15:59:59','WAVESETH','4h','0.022350000000000','0.022126500000000','1.297777777777778','1.284800000000000','58.06611981108625','58.066119811086253','test','test','1.0'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','1.294893827160494','1.293126511601963','60.94191581139372','60.941915811393720','test','test','0.1'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','1.294501090369709','1.290471229893109','61.05849206969997','61.058492069699973','test','test','0.3'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','1.293605565819353','1.288471967882526','61.114261152707215','61.114261152707215','test','test','0.4'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021396870000000','1.292464766277836','1.279540118615057','59.8003408262544','59.800340826254399','test','test','1.0'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','1.289592622352774','1.323447330117248','56.6132236864118','56.613223686411800','test','test','0.0'),('2019-01-27 11:59:59','2019-01-27 15:59:59','WAVESETH','4h','0.025120000000000','0.024868800000000','1.297115890744880','1.284144731837431','51.636779090162406','51.636779090162406','test','test','1.0'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.024754000000000','0.024506460000000','1.294233410987669','1.281291076877792','52.28380912125996','52.283809121259956','test','test','1.0'),('2019-01-28 07:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.025285000000000','0.025468000000000','1.291357336741030','1.300703525889680','51.07207185054497','51.072071850544972','test','test','0.9'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025969680000000','1.293434267662952','1.280499924986322','49.30749724241202','49.307497242412019','test','test','1.0'),('2019-02-04 11:59:59','2019-02-04 19:59:59','WAVESETH','4h','0.025830000000000','0.025571700000000','1.290559969290367','1.277654369597463','49.963607018597266','49.963607018597266','test','test','1.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019649520000000','1.287692058247500','1.274815137665025','64.87767322891473','64.877673228914730','test','test','1.0'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','1.284830520340283','1.277505300925628','64.82495057216362','64.824950572163615','test','test','0.6'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.020117790000000','1.283202693803693','1.270370666865656','63.14663125848596','63.146631258485961','test','test','1.0'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019861380000000','1.280351132261907','1.267547620939288','63.81971549506066','63.819715495060663','test','test','1.0'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','1.277505907523547','1.270110328396177','64.30938371626213','64.309383716262133','test','test','0.6'),('2019-03-10 11:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.020057000000000','0.019897000000000','1.275862445495243','1.265684552925106','63.61182856335659','63.611828563356589','test','test','0.8'),('2019-03-12 11:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020149000000000','0.019947510000000','1.273600691590768','1.260864684674861','63.2091265864692','63.209126586469203','test','test','1.0'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','1.270770467831678','1.258894695560110','62.834773923639126','62.834773923639126','test','test','0.9'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','1.268131407326885','1.271008974648167','62.55581133222597','62.555811332225971','test','test','0.0'),('2019-03-22 11:59:59','2019-03-22 15:59:59','WAVESETH','4h','0.020126000000000','0.020116000000000','1.268770866731614','1.268140452905353','63.041382626036665','63.041382626036665','test','test','0.0'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','1.268630774770223','1.260990684212322','62.623693097552696','62.623693097552696','test','test','0.6'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.020153430000000','1.266932976868467','1.254263647099782','62.23574086891325','62.235740868913247','test','test','1.0'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.013400640000000','1.264117570253203','1.251476394550671','93.3893004028667','93.389300402866695','test','test','1.0'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','1.261308420097085','1.549839986795791','116.24962397208158','116.249623972081579','test','test','0.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','1.325426546030131','1.324564439932546','123.15801394072952','123.158013940729518','test','test','0.1'),('2019-06-11 11:59:59','2019-06-11 15:59:59','WAVESETH','4h','0.009790000000000','0.009726000000000','1.325234966897334','1.316571530954389','135.3661866085122','135.366186608512209','test','test','0.7'),('2019-07-06 19:59:59','2019-07-06 23:59:59','WAVESETH','4h','0.006730000000000','0.006739000000000','1.323309758910013','1.325079415348377','196.62849315156217','196.628493151562168','test','test','0.0'),('2019-07-07 03:59:59','2019-07-07 15:59:59','WAVESETH','4h','0.007291000000000','0.007218090000000','1.323703015896317','1.310465985737354','181.55301274123119','181.553012741231186','test','test','1.0'),('2019-07-14 11:59:59','2019-07-15 11:59:59','WAVESETH','4h','0.006317000000000','0.006640000000000','1.320761453638769','1.388294451822293','209.0804897322731','209.080489732273094','test','test','0.7'),('2019-07-15 23:59:59','2019-07-18 07:59:59','WAVESETH','4h','0.006533000000000','0.006681000000000','1.335768786568441','1.366029582590503','204.4648379869036','204.464837986903603','test','test','0.0'),('2019-07-18 15:59:59','2019-07-18 19:59:59','WAVESETH','4h','0.006800000000000','0.006732000000000','1.342493407906677','1.329068473827610','197.42550116274666','197.425501162746656','test','test','1.0'),('2019-07-19 11:59:59','2019-07-19 15:59:59','WAVESETH','4h','0.006712000000000','0.006644880000000','1.339510089222440','1.326114988330216','199.56944118331944','199.569441183319441','test','test','1.0'),('2019-07-19 19:59:59','2019-07-19 23:59:59','WAVESETH','4h','0.006705000000000','0.006637950000000','1.336533400135279','1.323168066133926','199.33384043777465','199.333840437774654','test','test','1.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','WAVESETH','4h','0.006525000000000','0.006516000000000','1.333563325912756','1.331723928221842','204.37752121268292','204.377521212682922','test','test','0.1'),('2019-07-21 03:59:59','2019-07-21 11:59:59','WAVESETH','4h','0.006551000000000','0.006505000000000','1.333154570870331','1.323793387805145','203.50397967796226','203.503979677962263','test','test','0.7'),('2019-07-21 19:59:59','2019-07-21 23:59:59','WAVESETH','4h','0.006615000000000','0.006548850000000','1.331074307966956','1.317763564887287','201.22060589069633','201.220605890696334','test','test','1.0'),('2019-07-22 07:59:59','2019-07-22 11:59:59','WAVESETH','4h','0.006519000000000','0.006511000000000','1.328116365060363','1.326486524452834','203.73007594115097','203.730075941150972','test','test','0.1'),('2019-07-22 15:59:59','2019-07-22 23:59:59','WAVESETH','4h','0.006557000000000','0.006576000000000','1.327754178258690','1.331601567215060','202.49415559839716','202.494155598397157','test','test','0.0'),('2019-07-26 15:59:59','2019-07-26 19:59:59','WAVESETH','4h','0.006506000000000','0.006482000000000','1.328609153582328','1.323708043885744','204.2129040243357','204.212904024335700','test','test','0.4'),('2019-07-27 11:59:59','2019-07-27 15:59:59','WAVESETH','4h','0.006532000000000','0.006512000000000','1.327520018094198','1.323455351780376','203.23331569108976','203.233315691089757','test','test','0.3'),('2019-07-28 19:59:59','2019-07-28 23:59:59','WAVESETH','4h','0.006502000000000','0.006436980000000','1.326616758913349','1.313350591324216','204.03210687686078','204.032106876860780','test','test','1.0'),('2019-07-29 11:59:59','2019-07-29 23:59:59','WAVESETH','4h','0.006650000000000','0.006583500000000','1.323668721671319','1.310432034454606','199.0479280708751','199.047928070875088','test','test','1.0'),('2019-07-30 03:59:59','2019-07-30 11:59:59','WAVESETH','4h','0.006566000000000','0.006505000000000','1.320727235623161','1.308457305471926','201.14639592189477','201.146395921894765','test','test','0.9'),('2019-08-09 11:59:59','2019-08-09 15:59:59','WAVESETH','4h','0.006208000000000','0.006212000000000','1.318000584478442','1.318849811659162','212.3067951801614','212.306795180161402','test','test','0.0'),('2019-08-14 19:59:59','2019-08-15 11:59:59','WAVESETH','4h','0.006449000000000','0.006384510000000','1.318189301629713','1.305007408613416','204.40212461307382','204.402124613073823','test','test','1.0'),('2019-08-17 15:59:59','2019-08-17 19:59:59','WAVESETH','4h','0.006619000000000','0.006552810000000','1.315259992070536','1.302107392149831','198.70977369248163','198.709773692481633','test','test','1.0'),('2019-08-18 11:59:59','2019-08-18 15:59:59','WAVESETH','4h','0.006618000000000','0.006551820000000','1.312337192088157','1.299213820167275','198.29815534725856','198.298155347258557','test','test','1.0'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESETH','4h','0.006417000000000','0.006352830000000','1.309420887216850','1.296326678344682','204.05499255366212','204.054992553662117','test','test','1.0'),('2019-08-21 07:59:59','2019-08-22 03:59:59','WAVESETH','4h','0.006459000000000','0.006446000000000','1.306511063023035','1.303881454133222','202.27760690865998','202.277606908659976','test','test','1.0'),('2019-08-22 07:59:59','2019-08-23 07:59:59','WAVESETH','4h','0.006491000000000','0.006561000000000','1.305926705491965','1.320010031541023','201.1903721294046','201.190372129404608','test','test','0.0'),('2019-08-23 15:59:59','2019-08-23 19:59:59','WAVESETH','4h','0.006860000000000','0.006791400000000','1.309056333502867','1.295965770167838','190.82453841149663','190.824538411496633','test','test','1.0'),('2019-08-24 03:59:59','2019-08-24 23:59:59','WAVESETH','4h','0.006905000000000','0.006835950000000','1.306147319428416','1.293085846234132','189.1596407571928','189.159640757192790','test','test','1.0'),('2019-08-28 15:59:59','2019-08-28 19:59:59','WAVESETH','4h','0.006644000000000','0.006634000000000','1.303244769829686','1.301283233451255','196.15363784311955','196.153637843119554','test','test','0.2'),('2019-09-23 03:59:59','2019-09-23 07:59:59','WAVESETH','4h','0.005622000000000','0.005565780000000','1.302808872856702','1.289780784128135','231.7340577831202','231.734057783120193','test','test','1.0'),('2019-10-04 15:59:59','2019-10-07 19:59:59','WAVESETH','4h','0.005082000000000','0.005063000000000','1.299913742028131','1.295053773295637','255.78782802599983','255.787828025999829','test','test','0.9'),('2019-10-08 15:59:59','2019-10-08 19:59:59','WAVESETH','4h','0.005096000000000','0.005045040000000','1.298833748976466','1.285845411486702','254.87318465001297','254.873184650012973','test','test','1.0'),('2019-10-29 03:59:59','2019-10-29 07:59:59','WAVESETH','4h','0.004591000000000','0.004545090000000','1.295947451756518','1.282987977238953','282.27999384807634','282.279993848076344','test','test','1.0'),('2019-11-04 03:59:59','2019-11-04 07:59:59','WAVESETH','4h','0.004392000000000','0.004358000000000','1.293067568530393','1.283057482617362','294.41429155974333','294.414291559743333','test','test','0.8'),('2019-11-05 03:59:59','2019-11-05 07:59:59','WAVESETH','4h','0.004421000000000','0.004376790000000','1.290843104994164','1.277934673944222','291.97989255692465','291.979892556924653','test','test','1.0'),('2019-11-05 11:59:59','2019-11-05 15:59:59','WAVESETH','4h','0.004388000000000','0.004354000000000','1.287974564760843','1.277994816537992','293.522006554431','293.522006554431016','test','test','0.8'),('2019-11-15 15:59:59','2019-11-16 03:59:59','WAVESETH','4h','0.004301000000000','0.004258000000000','1.285756842933543','1.272902263941182','298.94369749675496','298.943697496754965','test','test','1.0'),('2019-11-22 03:59:59','2019-11-22 11:59:59','WAVESETH','4h','0.004218000000000','0.004195000000000','1.282900269824129','1.275904843981086','304.1489496975176','304.148949697517594','test','test','0.5'),('2019-12-11 15:59:59','2019-12-11 19:59:59','WAVESETH','4h','0.004428000000000','0.004383720000000','1.281345730747898','1.268532273440419','289.37347126194624','289.373471261946236','test','test','1.0'),('2019-12-12 03:59:59','2019-12-12 11:59:59','WAVESETH','4h','0.004396000000000','0.004352040000000','1.278498295790680','1.265713312832773','290.83218739551415','290.832187395514154','test','test','1.0'),('2019-12-12 15:59:59','2019-12-12 23:59:59','WAVESETH','4h','0.004371000000000','0.004327290000000','1.275657188466701','1.262900616582034','291.8456162129263','291.845616212926302','test','test','1.0'),('2019-12-13 15:59:59','2019-12-13 19:59:59','WAVESETH','4h','0.004450000000000','0.004405500000000','1.272822394714553','1.260094170767407','286.02750443023655','286.027504430236547','test','test','1.0'),('2019-12-14 23:59:59','2020-01-01 15:59:59','WAVESETH','4h','0.004788000000000','0.007925000000000','1.269993900504076','2.102068016185213','265.24517554387546','265.245175543875462','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  1:46:00
