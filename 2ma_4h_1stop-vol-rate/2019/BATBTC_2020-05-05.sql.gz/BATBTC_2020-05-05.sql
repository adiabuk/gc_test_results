-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.033333333333333','0.033314732142857','930.0595238095237','930.059523809523739','test','test','0.1'),('2019-01-05 19:59:59','2019-01-05 23:59:59','BATBTC','4h','0.000036380000000','0.000036016200000','0.033329199735450','0.032995907738096','916.1407293966403','916.140729396640268','test','test','1.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035690000000','0.000035333100000','0.033255134847149','0.032922583498678','931.7773843415213','931.777384341521270','test','test','1.0'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034927200000','0.033181234547489','0.032849422202014','940.5111833188396','940.511183318839585','test','test','1.0'),('2019-01-12 11:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035370000000','0.000035080000000','0.033107498470716','0.032836048808389','936.0333183691389','936.033318369138897','test','test','0.8'),('2019-01-18 03:59:59','2019-01-18 15:59:59','BATBTC','4h','0.000035280000000','0.000034927200000','0.033047176323533','0.032716704560298','936.7113470389077','936.711347038907661','test','test','1.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.032973738153925','0.032859740787792','949.9780511070263','949.978051107026317','test','test','0.3'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.032948405405895','0.032853698865493','947.0654040211364','947.065404021136374','test','test','0.3'),('2019-02-06 23:59:59','2019-02-07 03:59:59','BATBTC','4h','0.000034240000000','0.000033897600000','0.032927359508028','0.032598085912948','961.6635370335346','961.663537033534567','test','test','1.0'),('2019-02-07 07:59:59','2019-02-08 03:59:59','BATBTC','4h','0.000034090000000','0.000033749100000','0.032854187598010','0.032525645722030','963.7485361692708','963.748536169270778','test','test','1.0'),('2019-02-10 11:59:59','2019-02-10 15:59:59','BATBTC','4h','0.000034590000000','0.000034244100000','0.032781178292237','0.032453366509315','947.7068023196621','947.706802319662074','test','test','1.0'),('2019-02-14 03:59:59','2019-02-14 07:59:59','BATBTC','4h','0.000034840000000','0.000034491600000','0.032708331229366','0.032381247917072','938.8154773067034','938.815477306703428','test','test','1.0'),('2019-02-14 11:59:59','2019-02-14 23:59:59','BATBTC','4h','0.000035360000000','0.000035006400000','0.032635646048856','0.032309289588367','922.9537909744279','922.953790974427875','test','test','1.0'),('2019-02-15 03:59:59','2019-02-15 15:59:59','BATBTC','4h','0.000035530000000','0.000035174700000','0.032563122390969','0.032237491167059','916.4965491407073','916.496549140707316','test','test','1.0'),('2019-02-17 19:59:59','2019-02-17 23:59:59','BATBTC','4h','0.000038530000000','0.000038144700000','0.032490759896767','0.032165852297799','843.2587567289672','843.258756728967228','test','test','1.0'),('2019-02-18 03:59:59','2019-02-18 11:59:59','BATBTC','4h','0.000038650000000','0.000038263500000','0.032418558208108','0.032094372626027','838.7725280234813','838.772528023481300','test','test','1.0'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATBTC','4h','0.000039000000000','0.000038610000000','0.032346516967645','0.032023051797969','829.397870965259','829.397870965259017','test','test','1.0'),('2019-02-26 07:59:59','2019-02-26 11:59:59','BATBTC','4h','0.000047510000000','0.000047034900000','0.032274635818828','0.031951889460640','679.3230018696742','679.323001869674158','test','test','1.0'),('2019-02-26 23:59:59','2019-02-27 03:59:59','BATBTC','4h','0.000042660000000','0.000042233400000','0.032202914405898','0.031880885261839','754.8737554125069','754.873755412506853','test','test','1.0'),('2019-03-02 07:59:59','2019-03-03 03:59:59','BATBTC','4h','0.000047080000000','0.000046609200000','0.032131352373884','0.031810038850145','682.4841200910033','682.484120091003319','test','test','1.0'),('2019-03-04 07:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000043890000000','0.000048350000000','0.032059949368609','0.035317807062480','730.4613663387812','730.461366338781204','test','test','0.3'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.032783917745025','0.032669547418396','672.7666272321954','672.766627232195447','test','test','0.3'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000048024900000','0.032758502116885','0.032430917095716','675.2937975033003','675.293797503300311','test','test','1.0'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.032685705445514','0.032551527672749','670.8888638241833','670.888863824183318','test','test','0.4'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.032655888162678','0.044253619473633','670.0018088362237','670.001808836223745','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','BATBTC','4h','0.000065660000000','0.000065003400000','0.035233161787334','0.034880830169461','536.6000881409415','536.600088140941466','test','test','1.0'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BATBTC','4h','0.000062730000000','0.000062102700000','0.035154865872251','0.034803317213528','560.4155248246665','560.415524824666477','test','test','1.0'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.035076743948091','0.034932740893908','600.012725762755','600.012725762755053','test','test','0.4'),('2019-04-16 11:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000061730000000','0.000072750000000','0.035044743269383','0.041300908356514','567.7100805019169','567.710080501916877','test','test','0.5'),('2019-04-28 03:59:59','2019-04-28 11:59:59','BATBTC','4h','0.000077790000000','0.000077012100000','0.036435002177635','0.036070652155859','468.37642598836175','468.376425988361746','test','test','1.0'),('2019-04-28 19:59:59','2019-04-28 23:59:59','BATBTC','4h','0.000078000000000','0.000077220000000','0.036354035506129','0.035990495151068','466.0773782837037','466.077378283703695','test','test','1.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.036273248760560','0.036521220108390','495.94269565982745','495.942695659827450','test','test','0.0'),('2019-05-18 11:59:59','2019-05-18 15:59:59','BATBTC','4h','0.000052980000000','0.000052450200000','0.036328353504522','0.035965069969477','685.6993866463193','685.699386646319340','test','test','1.0'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BATBTC','4h','0.000043670000000','0.000043233300000','0.036247623830068','0.035885147591767','830.034894208096','830.034894208096034','test','test','1.0'),('2019-06-04 11:59:59','2019-06-04 19:59:59','BATBTC','4h','0.000043580000000','0.000043144200000','0.036167073554890','0.035805402819341','829.9007240681402','829.900724068140221','test','test','1.0'),('2019-07-01 07:59:59','2019-07-01 11:59:59','BATBTC','4h','0.000030760000000','0.000030452400000','0.036086702280323','0.035725835257520','1173.169775043014','1173.169775043013942','test','test','1.0'),('2019-07-01 15:59:59','2019-07-02 15:59:59','BATBTC','4h','0.000030370000000','0.000030066300000','0.036006509608589','0.035646444512503','1185.5946529005305','1185.594652900530491','test','test','1.0'),('2019-07-20 07:59:59','2019-07-20 11:59:59','BATBTC','4h','0.000024370000000','0.000024126300000','0.035926495142792','0.035567230191364','1474.209895067387','1474.209895067386924','test','test','1.0'),('2019-07-24 19:59:59','2019-07-24 23:59:59','BATBTC','4h','0.000024090000000','0.000023849100000','0.035846658486919','0.035488191902050','1488.0306553308146','1488.030655330814625','test','test','1.0'),('2019-07-26 11:59:59','2019-07-30 15:59:59','BATBTC','4h','0.000024400000000','0.000025260000000','0.035766999245837','0.037027639383190','1465.8606248293988','1465.860624829398830','test','test','0.2'),('2019-08-21 23:59:59','2019-08-22 03:59:59','BATBTC','4h','0.000018040000000','0.000018230000000','0.036047141498582','0.036426795427891','1998.1785753094478','1998.178575309447751','test','test','0.0'),('2019-08-22 07:59:59','2019-08-26 03:59:59','BATBTC','4h','0.000018610000000','0.000018430000000','0.036131509038429','0.035782037161647','1941.5104265679142','1941.510426567914237','test','test','1.0'),('2019-08-28 03:59:59','2019-08-28 19:59:59','BATBTC','4h','0.000018790000000','0.000018602100000','0.036053848621366','0.035693310135152','1918.7785322706873','1918.778532270687265','test','test','1.0'),('2019-09-01 19:59:59','2019-09-01 23:59:59','BATBTC','4h','0.000018960000000','0.000018770400000','0.035973728957763','0.035613991668185','1897.348573721683','1897.348573721682897','test','test','1.0'),('2019-09-10 11:59:59','2019-09-10 15:59:59','BATBTC','4h','0.000017190000000','0.000017260000000','0.035893787337857','0.036039951684201','2088.062090625764','2088.062090625764085','test','test','0.0'),('2019-09-10 19:59:59','2019-09-10 23:59:59','BATBTC','4h','0.000017660000000','0.000017483400000','0.035926268303711','0.035567005620674','2034.3300285227124','2034.330028522712382','test','test','1.0'),('2019-09-12 07:59:59','2019-09-12 11:59:59','BATBTC','4h','0.000017550000000','0.000017374500000','0.035846432151925','0.035487967830406','2042.5317465484388','2042.531746548438832','test','test','1.0'),('2019-09-16 03:59:59','2019-09-16 07:59:59','BATBTC','4h','0.000017070000000','0.000016930000000','0.035766773413810','0.035473431394013','2095.300141406548','2095.300141406547937','test','test','0.8'),('2019-09-16 15:59:59','2019-09-24 15:59:59','BATBTC','4h','0.000017220000000','0.000018800000000','0.035701586298299','0.038977341603253','2073.262851236894','2073.262851236894221','test','test','0.0'),('2019-09-27 23:59:59','2019-09-28 03:59:59','BATBTC','4h','0.000020450000000','0.000020245500000','0.036429531921622','0.036065236602406','1781.3952039913174','1781.395203991317430','test','test','1.0'),('2019-09-30 07:59:59','2019-10-10 11:59:59','BATBTC','4h','0.000019730000000','0.000022930000000','0.036348577406241','0.042243937147750','1842.2999192215464','1842.299919221546361','test','test','0.0'),('2019-10-13 11:59:59','2019-10-13 15:59:59','BATBTC','4h','0.000024270000000','0.000024027300000','0.037658657348799','0.037282070775311','1551.6546085207524','1551.654608520752390','test','test','1.0'),('2019-10-13 23:59:59','2019-10-22 03:59:59','BATBTC','4h','0.000024520000000','0.000026610000000','0.037574971443579','0.040777732060099','1532.4213476174189','1532.421347617418860','test','test','0.8'),('2019-10-22 07:59:59','2019-10-25 19:59:59','BATBTC','4h','0.000027020000000','0.000028720000000','0.038286696025028','0.040695555508468','1416.9761667293856','1416.976166729385568','test','test','0.0'),('2019-11-04 19:59:59','2019-11-04 23:59:59','BATBTC','4h','0.000026460000000','0.000026195400000','0.038821998132459','0.038433778151134','1467.1956966159903','1467.195696615990300','test','test','1.0'),('2019-11-05 11:59:59','2019-11-08 15:59:59','BATBTC','4h','0.000026590000000','0.000026530000000','0.038735727025498','0.038648320345486','1456.7780002067693','1456.778000206769320','test','test','0.2'),('2019-11-09 23:59:59','2019-11-10 19:59:59','BATBTC','4h','0.000028190000000','0.000027908100000','0.038716303318829','0.038329140285641','1373.405580660825','1373.405580660825080','test','test','1.0'),('2019-11-11 15:59:59','2019-11-11 23:59:59','BATBTC','4h','0.000027840000000','0.000027561600000','0.038630267089231','0.038243964418339','1387.5814328028493','1387.581432802849349','test','test','1.0'),('2019-11-13 11:59:59','2019-11-20 11:59:59','BATBTC','4h','0.000028020000000','0.000029750000000','0.038544422051255','0.040924216845997','1375.6039275965502','1375.603927596550193','test','test','0.0'),('2019-11-22 23:59:59','2019-11-23 03:59:59','BATBTC','4h','0.000030140000000','0.000029838600000','0.039073265338976','0.038682532685586','1296.3923470131315','1296.392347013131484','test','test','1.0'),('2019-11-23 11:59:59','2019-11-23 19:59:59','BATBTC','4h','0.000030500000000','0.000030195000000','0.038986435860445','0.038596571501841','1278.243798703104','1278.243798703103948','test','test','1.0'),('2019-11-25 07:59:59','2019-11-25 15:59:59','BATBTC','4h','0.000030300000000','0.000029997000000','0.038899799336310','0.038510801342947','1283.821760274272','1283.821760274272037','test','test','1.0'),('2019-12-13 15:59:59','2019-12-14 03:59:59','BATBTC','4h','0.000026070000000','0.000025809300000','0.038813355337785','0.038425221784407','1488.8130164091035','1488.813016409103511','test','test','1.0'),('2019-12-14 07:59:59','2019-12-14 11:59:59','BATBTC','4h','0.000026370000000','0.000026106300000','0.038727103437035','0.038339832402665','1468.6046051207684','1468.604605120768383','test','test','1.0'),('2019-12-15 19:59:59','2019-12-16 07:59:59','BATBTC','4h','0.000026050000000','0.000025789500000','0.038641043207175','0.038254632775103','1483.3413899107359','1483.341389910735870','test','test','1.0'),('2019-12-28 03:59:59','2020-01-01 15:59:59','BATBTC','4h','0.000023800000000','0.000026110000000','0.038555174222270','0.042297294073255','1619.9653034567134','1619.965303456713400','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:29:25
