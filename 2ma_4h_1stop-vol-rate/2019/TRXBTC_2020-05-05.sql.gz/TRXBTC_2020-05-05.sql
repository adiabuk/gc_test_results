-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 07:59:59','TRXBTC','4h','0.000005140000000','0.000005110000000','0.033333333333333','0.033138780804150','6485.08430609598','6485.084306095979628','test','test','0.6'),('2019-01-03 15:59:59','2019-01-03 19:59:59','TRXBTC','4h','0.000005360000000','0.000005306400000','0.033290099437959','0.032957198443579','6210.839447380472','6210.839447380471938','test','test','1.0'),('2019-01-04 07:59:59','2019-01-13 03:59:59','TRXBTC','4h','0.000005320000000','0.000006210000000','0.033216121439208','0.038772953785241','6243.6318494752295','6243.631849475229501','test','test','0.8'),('2019-01-14 03:59:59','2019-01-19 03:59:59','TRXBTC','4h','0.000006470000000','0.000006620000000','0.034450973071660','0.035249681875485','5324.725358834621','5324.725358834621147','test','test','0.0'),('2019-01-20 15:59:59','2019-01-20 19:59:59','TRXBTC','4h','0.000006590000000','0.000006680000000','0.034628463916954','0.035101386792906','5254.6986216926325','5254.698621692632514','test','test','0.0'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXBTC','4h','0.000007100000000','0.000007590000000','0.034733557889388','0.037130662588796','4892.0504069560875','4892.050406956087500','test','test','0.0'),('2019-02-04 11:59:59','2019-02-04 23:59:59','TRXBTC','4h','0.000007880000000','0.000007801200000','0.035266247822590','0.034913585344364','4475.412160227157','4475.412160227157074','test','test','1.0'),('2019-02-05 07:59:59','2019-02-05 15:59:59','TRXBTC','4h','0.000007800000000','0.000007722000000','0.035187878382984','0.034835999599154','4511.2664593569525','4511.266459356952510','test','test','1.0'),('2019-02-08 15:59:59','2019-02-08 19:59:59','TRXBTC','4h','0.000007590000000','0.000007514100000','0.035109683097689','0.034758586266712','4625.78169930022','4625.781699300219771','test','test','1.0'),('2019-03-23 11:59:59','2019-03-24 15:59:59','TRXBTC','4h','0.000005980000000','0.000005920200000','0.035031661579694','0.034681344963897','5858.137387908658','5858.137387908657729','test','test','1.0'),('2019-03-29 03:59:59','2019-03-29 07:59:59','TRXBTC','4h','0.000005750000000','0.000005800000000','0.034953813442850','0.035257759646701','6078.924077017391','6078.924077017391028','test','test','0.0'),('2019-04-01 15:59:59','2019-04-02 07:59:59','TRXBTC','4h','0.000005810000000','0.000005751900000','0.035021357043706','0.034671143473269','6027.772296679135','6027.772296679135252','test','test','1.0'),('2019-04-07 23:59:59','2019-04-08 03:59:59','TRXBTC','4h','0.000005590000000','0.000005534100000','0.034943531805831','0.034594096487773','6251.0790350323605','6251.079035032360480','test','test','1.0'),('2019-04-08 15:59:59','2019-04-08 23:59:59','TRXBTC','4h','0.000005960000000','0.000005900400000','0.034865879512929','0.034517220717800','5849.979784048509','5849.979784048508918','test','test','1.0'),('2019-04-09 11:59:59','2019-04-09 15:59:59','TRXBTC','4h','0.000005860000000','0.000005801400000','0.034788399780678','0.034440515782871','5936.5869932898','5936.586993289800375','test','test','1.0'),('2019-05-15 23:59:59','2019-05-16 07:59:59','TRXBTC','4h','0.000003790000000','0.000003830000000','0.034711092225610','0.035077436206883','9158.599531823222','9158.599531823221696','test','test','0.0'),('2019-05-21 15:59:59','2019-05-21 19:59:59','TRXBTC','4h','0.000003650000000','0.000003613500000','0.034792501999226','0.034444576979234','9532.19232855513','9532.192328555129279','test','test','1.0'),('2019-05-26 11:59:59','2019-05-26 19:59:59','TRXBTC','4h','0.000003670000000','0.000003633300000','0.034715185328117','0.034368033474836','9459.178563519588','9459.178563519588351','test','test','1.0'),('2019-05-27 03:59:59','2019-05-30 19:59:59','TRXBTC','4h','0.000003600000000','0.000003830000000','0.034638040471832','0.036851026390866','9621.677908842286','9621.677908842286342','test','test','0.0'),('2019-06-01 03:59:59','2019-06-06 19:59:59','TRXBTC','4h','0.000003940000000','0.000004140000000','0.035129815120506','0.036913054466725','8916.196731093009','8916.196731093008566','test','test','0.0'),('2019-06-12 23:59:59','2019-06-13 11:59:59','TRXBTC','4h','0.000004120000000','0.000004078800000','0.035526090530777','0.035170829625469','8622.837507470227','8622.837507470227138','test','test','1.0'),('2019-07-07 19:59:59','2019-07-08 11:59:59','TRXBTC','4h','0.000003040000000','0.000003009600000','0.035447143662931','0.035092672226302','11660.244625964182','11660.244625964181978','test','test','1.0'),('2019-07-19 19:59:59','2019-07-22 23:59:59','TRXBTC','4h','0.000002590000000','0.000002580000000','0.035368372232569','0.035231814810822','13655.74217473711','13655.742174737109963','test','test','0.4'),('2019-08-14 07:59:59','2019-08-14 11:59:59','TRXBTC','4h','0.000001910000000','0.000001900000000','0.035338026138848','0.035153010295189','18501.584365888775','18501.584365888775210','test','test','0.5'),('2019-08-22 19:59:59','2019-08-22 23:59:59','TRXBTC','4h','0.000001740000000','0.000001722600000','0.035296911506923','0.034943942391854','20285.58132581801','20285.581325818009645','test','test','1.0'),('2019-08-23 03:59:59','2019-08-23 15:59:59','TRXBTC','4h','0.000001770000000','0.000001752300000','0.035218473925797','0.034866289186539','19897.442895930446','19897.442895930445957','test','test','1.0'),('2019-08-23 19:59:59','2019-08-23 23:59:59','TRXBTC','4h','0.000001750000000','0.000001732500000','0.035140210650406','0.034788808543902','20080.1203716607','20080.120371660701494','test','test','1.0'),('2019-08-24 11:59:59','2019-08-24 15:59:59','TRXBTC','4h','0.000001780000000','0.000001762200000','0.035062121293405','0.034711500080471','19697.820951351314','19697.820951351313852','test','test','1.0'),('2019-09-10 03:59:59','2019-09-10 15:59:59','TRXBTC','4h','0.000001540000000','0.000001540000000','0.034984205468309','0.034984205468309','22717.016537862914','22717.016537862913538','test','test','0.6'),('2019-09-14 15:59:59','2019-09-14 19:59:59','TRXBTC','4h','0.000001520000000','0.000001530000000','0.034984205468309','0.035214364714811','23015.924650203215','23015.924650203214696','test','test','0.0'),('2019-09-16 03:59:59','2019-09-16 11:59:59','TRXBTC','4h','0.000001530000000','0.000001520000000','0.035035351967532','0.034806362738986','22898.922854595792','22898.922854595792160','test','test','0.7'),('2019-09-17 07:59:59','2019-09-22 19:59:59','TRXBTC','4h','0.000001580000000','0.000001660000000','0.034984465472299','0.036755830812669','22142.066754619696','22142.066754619696439','test','test','0.6'),('2019-09-29 15:59:59','2019-10-15 19:59:59','TRXBTC','4h','0.000001640000000','0.000001910000000','0.035378102214604','0.041202545871886','21572.013545489976','21572.013545489975513','test','test','0.0'),('2019-10-18 19:59:59','2019-10-20 07:59:59','TRXBTC','4h','0.000001940000000','0.000001920600000','0.036672423027333','0.036305698797060','18903.310838831385','18903.310838831384899','test','test','1.0'),('2019-10-23 19:59:59','2019-10-25 15:59:59','TRXBTC','4h','0.000001910000000','0.000001950000000','0.036590928753939','0.037357230926796','19157.554321433974','19157.554321433974110','test','test','0.0'),('2019-10-25 23:59:59','2019-10-26 03:59:59','TRXBTC','4h','0.000002040000000','0.000002019600000','0.036761218125685','0.036393605944428','18020.204963571025','18020.204963571024564','test','test','1.0'),('2019-10-27 15:59:59','2019-10-27 19:59:59','TRXBTC','4h','0.000002060000000','0.000002039400000','0.036679526529850','0.036312731264552','17805.5954028398','17805.595402839800954','test','test','1.0'),('2019-10-28 03:59:59','2019-11-04 03:59:59','TRXBTC','4h','0.000002140000000','0.000002118600000','0.036598016470895','0.036232036306186','17101.87685555836','17101.876855558359239','test','test','1.0'),('2019-11-04 11:59:59','2019-11-04 23:59:59','TRXBTC','4h','0.000002110000000','0.000002100000000','0.036516687545404','0.036343622675521','17306.486988343127','17306.486988343127450','test','test','0.5'),('2019-11-05 11:59:59','2019-11-06 03:59:59','TRXBTC','4h','0.000002120000000','0.000002120000000','0.036478228685430','0.036478228685430','17206.711644070754','17206.711644070754119','test','test','0.0'),('2019-11-06 07:59:59','2019-11-07 11:59:59','TRXBTC','4h','0.000002130000000','0.000002110000000','0.036478228685430','0.036135710106224','17125.928960295776','17125.928960295776051','test','test','0.9'),('2019-11-08 11:59:59','2019-11-08 15:59:59','TRXBTC','4h','0.000002130000000','0.000002110000000','0.036402113445606','0.036060309563488','17090.19410591852','17090.194105918519199','test','test','0.9'),('2019-11-10 03:59:59','2019-11-10 19:59:59','TRXBTC','4h','0.000002180000000','0.000002158200000','0.036326157027358','0.035962895457084','16663.374783191743','16663.374783191742608','test','test','1.0'),('2019-11-11 11:59:59','2019-11-15 15:59:59','TRXBTC','4h','0.000002170000000','0.000002180000000','0.036245432233964','0.036412461875595','16702.96416311695','16702.964163116950658','test','test','0.0'),('2019-11-26 15:59:59','2019-11-29 15:59:59','TRXBTC','4h','0.000002130000000','0.000002108700000','0.036282549932104','0.035919724432783','17034.061000987793','17034.061000987792795','test','test','1.0'),('2019-12-01 07:59:59','2019-12-01 11:59:59','TRXBTC','4h','0.000002100000000','0.000002100000000','0.036201922043366','0.036201922043366','17239.01049684095','17239.010496840950509','test','test','0.0'),('2019-12-01 15:59:59','2019-12-02 11:59:59','TRXBTC','4h','0.000002150000000','0.000002128500000','0.036201922043366','0.035839902822932','16838.103275984184','16838.103275984183711','test','test','1.0'),('2019-12-03 07:59:59','2019-12-03 11:59:59','TRXBTC','4h','0.000002100000000','0.000002090000000','0.036121473327714','0.035949466311868','17200.701584625713','17200.701584625712712','test','test','0.5'),('2019-12-03 15:59:59','2019-12-03 19:59:59','TRXBTC','4h','0.000002100000000','0.000002100000000','0.036083249546415','0.036083249546415','17182.49978400709','17182.499784007090057','test','test','0.0'),('2019-12-14 03:59:59','2019-12-14 11:59:59','TRXBTC','4h','0.000001990000000','0.000001980000000','0.036083249546415','0.035901926684373','18132.286204228585','18132.286204228585120','test','test','0.5'),('2019-12-22 03:59:59','2019-12-23 07:59:59','TRXBTC','4h','0.000001950000000','0.000001930500000','0.036042955577072','0.035682526021301','18483.566962601137','18483.566962601136765','test','test','1.0'),('2019-12-30 07:59:59','2019-12-30 11:59:59','TRXBTC','4h','0.000001890000000','0.000001871100000','0.035962860120234','0.035603231519032','19027.968317584244','19027.968317584243778','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:56:58
