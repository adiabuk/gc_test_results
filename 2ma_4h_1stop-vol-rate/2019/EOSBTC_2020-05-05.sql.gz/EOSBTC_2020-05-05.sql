-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 19:59:59','EOSBTC','4h','0.000705800000000','0.000698742000000','0.033333333333333','0.033000000000000','47.22773212430339','47.227732124303387','test','test','1.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','EOSBTC','4h','0.000715000000000','0.000707850000000','0.033259259259259','0.032926666666666','46.51644651644662','46.516446516446621','test','test','1.0'),('2019-01-04 23:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000705000000000','0.000697950000000','0.033185349794239','0.032853496296297','47.07141814785627','47.071418147856271','test','test','1.0'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000696366000000','0.033111604572474','0.032780488526749','47.07364880931728','47.073648809317277','test','test','1.0'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.033038023228979','0.033067503915977','49.13447832983243','49.134478329832433','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.033044574492757','0.032763838397755','48.402775000375954','48.402775000375954','test','test','0.8'),('2019-01-22 19:59:59','2019-01-22 23:59:59','EOSBTC','4h','0.000687900000000','0.000681021000000','0.032982188693867','0.032652366806928','47.94619667664971','47.946196676649713','test','test','1.0'),('2019-01-25 07:59:59','2019-01-26 07:59:59','EOSBTC','4h','0.000684100000000','0.000677259000000','0.032908894941214','0.032579805991802','48.105386553448646','48.105386553448646','test','test','1.0'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000670527000000','0.032835764063567','0.032507406422931','48.480383971013','48.480383971012998','test','test','1.0'),('2019-02-02 23:59:59','2019-02-03 15:59:59','EOSBTC','4h','0.000695900000000','0.000688941000000','0.032762795698981','0.032435167741991','47.07974665753891','47.079746657538912','test','test','1.0'),('2019-02-04 11:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000692000000000','0.000685080000000','0.032689989486317','0.032363089591454','47.23986919987989','47.239869199879891','test','test','1.0'),('2019-02-07 03:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000693000000000','0.000896200000000','0.032617345065236','0.042181334267626','47.06687599601186','47.066875996011859','test','test','0.5'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000926442000000','0.034742675999101','0.034395249239110','37.12617653248628','37.126176532486276','test','test','1.0'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000908424000000','0.034665470052436','0.034318815351912','37.77841112950741','37.778411129507411','test','test','1.0'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000916740000000','0.034588435674542','0.034242551317797','37.352522326718976','37.352522326718976','test','test','1.0'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000936837000000','0.034511572484154','0.034166456759312','36.470012135849096','36.470012135849096','test','test','1.0'),('2019-03-09 07:59:59','2019-03-10 03:59:59','EOSBTC','4h','0.000958500000000','0.000948915000000','0.034434880100856','0.034090531299847','35.92580083553028','35.925800835530282','test','test','1.0'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.034358358145076','0.034121378807276','36.45835966158319','36.458359661583188','test','test','0.7'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.034305696070009','0.034090738968466','36.43340704121636','36.433407041216363','test','test','0.6'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.034257927825222','0.034039959773708','36.943737544723376','36.943737544723376','test','test','0.6'),('2019-03-26 11:59:59','2019-04-02 07:59:59','EOSBTC','4h','0.000924700000000','0.000975800000000','0.034209490480441','0.036099946805250','36.99523140525695','36.995231405256952','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001033500000000','0.001056400000000','0.034629591885954','0.035396904565382','33.50710390513229','33.507103905132290','test','test','0.0'),('2019-04-06 15:59:59','2019-04-06 23:59:59','EOSBTC','4h','0.001086200000000','0.001075338000000','0.034800105814716','0.034452104756569','32.03839607320566','32.038396073205661','test','test','1.0'),('2019-04-08 03:59:59','2019-04-08 11:59:59','EOSBTC','4h','0.001049100000000','0.001038609000000','0.034722772246239','0.034375544523777','33.09767633804106','33.097676338041062','test','test','1.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','EOSBTC','4h','0.001046600000000','0.001040600000000','0.034645610530136','0.034446992468622','33.10301025237552','33.103010252375519','test','test','0.6'),('2019-04-09 11:59:59','2019-04-10 23:59:59','EOSBTC','4h','0.001072600000000','0.001100600000000','0.034601473183133','0.035504737446724','32.25943798539354','32.259437985393539','test','test','0.5'),('2019-04-14 23:59:59','2019-04-15 11:59:59','EOSBTC','4h','0.001080600000000','0.001069794000000','0.034802198575042','0.034454176589292','32.20636551456804','32.206365514568041','test','test','1.0'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSBTC','4h','0.001068400000000','0.001057716000000','0.034724860355987','0.034377611752427','32.50174125419942','32.501741254199423','test','test','1.0'),('2019-04-15 23:59:59','2019-04-16 15:59:59','EOSBTC','4h','0.001059900000000','0.001057700000000','0.034647693999640','0.034575776906707','32.68958769661289','32.689587696612890','test','test','0.2'),('2019-05-16 03:59:59','2019-05-18 07:59:59','EOSBTC','4h','0.000818900000000','0.000810711000000','0.034631712423433','0.034285395299199','42.2905268328644','42.290526832864401','test','test','1.0'),('2019-05-24 11:59:59','2019-05-25 15:59:59','EOSBTC','4h','0.000798600000000','0.000792100000000','0.034554753062492','0.034273503507137','43.26916236224864','43.269162362248643','test','test','0.8'),('2019-05-27 03:59:59','2019-05-27 07:59:59','EOSBTC','4h','0.000798400000000','0.000794200000000','0.034492253161302','0.034310805937758','43.201719891410036','43.201719891410036','test','test','0.5'),('2019-05-27 15:59:59','2019-05-30 23:59:59','EOSBTC','4h','0.000844500000000','0.000882500000000','0.034451931556070','0.036002166486953','40.79565607586711','40.795656075867107','test','test','0.0'),('2019-05-31 11:59:59','2019-06-01 23:59:59','EOSBTC','4h','0.000924500000000','0.000915255000000','0.034796428207377','0.034448463925303','37.63810514589195','37.638105145891949','test','test','1.0'),('2019-07-23 19:59:59','2019-07-28 23:59:59','EOSBTC','4h','0.000419500000000','0.000448200000000','0.034719102811361','0.037094402574617','82.76305795318393','82.763057953183932','test','test','0.0'),('2019-08-14 03:59:59','2019-08-14 15:59:59','EOSBTC','4h','0.000386600000000','0.000382734000000','0.035246947203195','0.034894477731163','91.17161718364027','91.171617183640265','test','test','1.0'),('2019-08-22 15:59:59','2019-08-23 15:59:59','EOSBTC','4h','0.000359600000000','0.000356600000000','0.035168620653855','0.034875222817477','97.79927879269988','97.799278792699880','test','test','0.8'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSBTC','4h','0.000360700000000','0.000361200000000','0.035103421134660','0.035152081269307','97.32026929487046','97.320269294870457','test','test','0.2'),('2019-09-07 19:59:59','2019-09-22 19:59:59','EOSBTC','4h','0.000338900000000','0.000376700000000','0.035114234497915','0.039030782340999','103.61237680116452','103.612376801164515','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 23:59:59','EOSBTC','4h','0.000387300000000','0.000383427000000','0.035984578463044','0.035624732678414','92.91138255369079','92.911382553690785','test','test','1.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','EOSBTC','4h','0.000362600000000','0.000358974000000','0.035904612733127','0.035545566605796','99.01989170746457','99.019891707464566','test','test','1.0'),('2019-10-01 03:59:59','2019-10-01 15:59:59','EOSBTC','4h','0.000360800000000','0.000357192000000','0.035824824704831','0.035466576457783','99.29275139919866','99.292751399198664','test','test','1.0'),('2019-10-02 19:59:59','2019-10-02 23:59:59','EOSBTC','4h','0.000363700000000','0.000360063000000','0.035745213983265','0.035387761843432','98.28213907963887','98.282139079638867','test','test','1.0'),('2019-10-04 11:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000364400000000','0.000369100000000','0.035665780174413','0.036125794353391','97.87535722945354','97.875357229453542','test','test','0.0'),('2019-10-07 03:59:59','2019-10-10 07:59:59','EOSBTC','4h','0.000377100000000','0.000373329000000','0.035768005547519','0.035410325492044','94.85018707907477','94.850187079074772','test','test','1.0'),('2019-10-13 23:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000374700000000','0.000374700000000','0.035688521090747','0.035688521090747','95.24558604416033','95.245586044160333','test','test','0.0'),('2019-10-24 15:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000369700000000','0.000366003000000','0.035688521090747','0.035331635879840','96.53373300174974','96.533733001749738','test','test','1.0'),('2019-11-01 23:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000362000000000','0.000358800000000','0.035609213266101','0.035294435690268','98.36799244779247','98.367992447792474','test','test','0.9'),('2019-11-04 11:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000363900000000','0.000391800000000','0.035539262693694','0.038264037162378','97.6621673363384','97.662167336338399','test','test','0.0'),('2019-11-16 15:59:59','2019-11-18 19:59:59','EOSBTC','4h','0.000396000000000','0.000392040000000','0.036144768131179','0.035783320449867','91.27466699792646','91.274666997926460','test','test','1.0'),('2019-12-01 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000368700000000','0.000368400000000','0.036064446424221','0.036035101878717','97.81515167947016','97.815151679470162','test','test','0.1'),('2019-12-03 15:59:59','2019-12-03 19:59:59','EOSBTC','4h','0.000369200000000','0.000370400000000','0.036057925414109','0.036175123438207','97.66502008155109','97.665020081551091','test','test','0.0'),('2019-12-14 15:59:59','2019-12-14 19:59:59','EOSBTC','4h','0.000362700000000','0.000363200000000','0.036083969419464','0.036133712967051','99.48709517359738','99.487095173597382','test','test','0.0'),('2019-12-24 19:59:59','2019-12-25 15:59:59','EOSBTC','4h','0.000350900000000','0.000347391000000','0.036095023541150','0.035734073305738','102.86413092376681','102.864130923766808','test','test','1.0'),('2019-12-26 19:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000352700000000','0.000363100000000','0.036014812377725','0.037076774523255','102.11174476247484','102.111744762474842','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:44:39
