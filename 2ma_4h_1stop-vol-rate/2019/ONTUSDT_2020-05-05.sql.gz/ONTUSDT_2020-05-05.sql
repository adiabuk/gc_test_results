-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 15:59:59','ONTUSDT','4h','0.619100000000000','0.612909000000000','222.222222222222200','219.999999999999943','358.9439867908613','358.943986790861288','test','test','1.0'),('2019-01-02 19:59:59','2019-01-03 03:59:59','ONTUSDT','4h','0.624900000000000','0.618651000000000','221.728395061728378','219.511111111111063','354.82220365134964','354.822203651349639','test','test','1.0'),('2019-01-05 23:59:59','2019-01-06 03:59:59','ONTUSDT','4h','0.616000000000000','0.609840000000000','221.235665294924530','219.023308641975262','359.1488072969554','359.148807296955397','test','test','1.0'),('2019-01-06 11:59:59','2019-01-08 03:59:59','ONTUSDT','4h','0.615300000000000','0.609147000000000','220.744030483158014','218.536590178326463','358.7583788122185','358.758378812218496','test','test','1.0'),('2019-01-08 15:59:59','2019-01-08 19:59:59','ONTUSDT','4h','0.643600000000000','0.637164000000000','220.253488193195466','218.050953311263498','342.2210817172086','342.221081717208619','test','test','1.0'),('2019-01-09 03:59:59','2019-01-10 07:59:59','ONTUSDT','4h','0.655700000000000','0.649143000000000','219.764035997210584','217.566395637238486','335.15942656277355','335.159426562773547','test','test','1.0'),('2019-01-11 23:59:59','2019-01-12 03:59:59','ONTUSDT','4h','0.628900000000000','0.627600000000000','219.275671472772359','218.822406449852025','348.6654022464181','348.665402246418125','test','test','0.2'),('2019-01-16 11:59:59','2019-01-16 15:59:59','ONTUSDT','4h','0.619000000000000','0.612810000000000','219.174945912123377','216.983196453002137','354.0790725559344','354.079072555934374','test','test','1.0'),('2019-01-19 11:59:59','2019-01-19 19:59:59','ONTUSDT','4h','0.620200000000000','0.613998000000000','218.687890476763101','216.501011571995434','352.6086592659837','352.608659265983704','test','test','1.0'),('2019-01-22 19:59:59','2019-01-23 03:59:59','ONTUSDT','4h','0.601500000000000','0.610700000000000','218.201917386814756','221.539336572115985','362.7629549240478','362.762954924047790','test','test','0.1'),('2019-01-25 15:59:59','2019-01-25 19:59:59','ONTUSDT','4h','0.616300000000000','0.610137000000000','218.943566094659445','216.754130433712845','355.2548533095237','355.254853309523696','test','test','1.0'),('2019-01-26 03:59:59','2019-01-26 11:59:59','ONTUSDT','4h','0.624400000000000','0.618156000000000','218.457024836671309','216.272454588304583','349.8671121663538','349.867112166353820','test','test','1.0'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ONTUSDT','4h','0.551900000000000','0.564300000000000','217.971564781478719','222.868914669665600','394.9475716279738','394.947571627973787','test','test','0.0'),('2019-02-15 11:59:59','2019-03-04 03:59:59','ONTUSDT','4h','0.619900000000000','0.834400000000000','219.059864756631356','294.859737301069856','353.37935918153147','353.379359181531470','test','test','0.0'),('2019-03-05 15:59:59','2019-03-11 07:59:59','ONTUSDT','4h','0.882200000000000','0.924000000000000','235.904280877617680','247.081790445385110','267.40453511405315','267.404535114053147','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','ONTUSDT','4h','0.943800000000000','0.953400000000000','238.388171892677150','240.812972115361760','252.5833565296431','252.583356529643112','test','test','0.0'),('2019-03-13 15:59:59','2019-03-13 19:59:59','ONTUSDT','4h','1.026900000000000','1.016631000000000','238.927016386607050','236.537746222740964','232.66824071146857','232.668240711468570','test','test','1.0'),('2019-03-14 15:59:59','2019-03-25 15:59:59','ONTUSDT','4h','0.986100000000000','1.165700000000000','238.396067461303460','281.815531730698126','241.75648256901275','241.756482569012746','test','test','0.2'),('2019-03-27 03:59:59','2019-04-08 11:59:59','ONTUSDT','4h','1.214500000000000','1.422600000000000','248.044837298946732','290.546385789610270','204.23617727373136','204.236177273731357','test','test','0.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','ONTUSDT','4h','1.482900000000000','1.468071000000000','257.489625852427537','254.914729593903246','173.63923788011837','173.639237880118372','test','test','1.0'),('2019-05-03 15:59:59','2019-05-03 19:59:59','ONTUSDT','4h','1.139100000000000','1.137100000000000','256.917426683866495','256.466338233890440','225.54422498803135','225.544224988031345','test','test','0.2'),('2019-05-04 03:59:59','2019-05-04 07:59:59','ONTUSDT','4h','1.166700000000000','1.155033000000000','256.817184806094076','254.249012958033092','220.12272632732842','220.122726327328422','test','test','1.0'),('2019-05-11 07:59:59','2019-05-17 11:59:59','ONTUSDT','4h','1.106100000000000','1.292100000000000','256.246479950969444','299.336476579556631','231.66664854079144','231.666648540791442','test','test','0.0'),('2019-05-20 15:59:59','2019-05-22 23:59:59','ONTUSDT','4h','1.352100000000000','1.338579000000000','265.822034757322115','263.163814409748852','196.59938965854752','196.599389658547523','test','test','1.0'),('2019-05-24 11:59:59','2019-05-24 23:59:59','ONTUSDT','4h','1.364400000000000','1.350756000000000','265.231319124528056','262.579005933282758','194.3941066582586','194.394106658258607','test','test','1.0'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ONTUSDT','4h','1.362100000000000','1.441700000000000','264.641916193140219','280.107371393913979','194.28963820067557','194.289638200675569','test','test','0.0'),('2019-06-10 03:59:59','2019-06-11 07:59:59','ONTUSDT','4h','1.412500000000000','1.398375000000000','268.078684015534407','265.397897175379057','189.79021877205975','189.790218772059745','test','test','1.0'),('2019-06-13 15:59:59','2019-06-13 23:59:59','ONTUSDT','4h','1.473200000000000','1.458468000000000','267.482953606610977','264.808124070544864','181.56594733003732','181.565947330037318','test','test','1.0'),('2019-06-14 23:59:59','2019-06-18 19:59:59','ONTUSDT','4h','1.417700000000000','1.431000000000000','266.888547043040774','269.392333228885775','188.25460043947294','188.254600439472938','test','test','0.0'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ONTUSDT','4h','1.435700000000000','1.437700000000000','267.444943973228533','267.817507801289082','186.28191403024903','186.281914030249027','test','test','0.0'),('2019-06-22 03:59:59','2019-06-27 07:59:59','ONTUSDT','4h','1.458800000000000','1.596900000000000','267.527735935019734','292.853743840576442','183.38890590555232','183.388905905552321','test','test','0.0'),('2019-06-29 19:59:59','2019-06-29 23:59:59','ONTUSDT','4h','1.558900000000000','1.557400000000000','273.155737691810089','272.892902611601130','175.2233868059594','175.223386805959393','test','test','0.1'),('2019-06-30 07:59:59','2019-06-30 15:59:59','ONTUSDT','4h','1.594900000000000','1.578951000000000','273.097329896208180','270.366356597246067','171.23163201216892','171.231632012168916','test','test','1.0'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ONTUSDT','4h','1.067900000000000','1.057221000000000','272.490446940883260','269.765542471474419','255.1647597536129','255.164759753612913','test','test','1.0'),('2019-07-24 23:59:59','2019-07-26 03:59:59','ONTUSDT','4h','1.022200000000000','1.014100000000000','271.884912614347911','269.730473373322468','265.98015321301887','265.980153213018866','test','test','1.0'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ONTUSDT','4h','1.037900000000000','1.027521000000000','271.406148338564492','268.692086855178900','261.49547002463095','261.495470024630947','test','test','1.0'),('2019-08-05 11:59:59','2019-08-05 15:59:59','ONTUSDT','4h','1.005700000000000','0.995643000000000','270.803023564478792','268.094993328833993','269.2681948538121','269.268194853812076','test','test','1.0'),('2019-08-05 19:59:59','2019-08-06 03:59:59','ONTUSDT','4h','1.009600000000000','0.999504000000000','270.201239067668837','267.499226676992123','267.63197213517117','267.631972135171168','test','test','1.0'),('2019-08-24 07:59:59','2019-08-24 11:59:59','ONTUSDT','4h','0.816600000000000','0.808434000000000','269.600791869740704','266.904783951043271','330.15036966659403','330.150369666594031','test','test','1.0'),('2019-08-24 15:59:59','2019-08-25 19:59:59','ONTUSDT','4h','0.816500000000000','0.808335000000000','269.001678998919033','266.311662208929818','329.4570471511562','329.457047151156189','test','test','1.0'),('2019-08-26 03:59:59','2019-08-26 07:59:59','ONTUSDT','4h','0.806000000000000','0.797940000000000','268.403897490032534','265.719858515132216','333.007316985152','333.007316985151988','test','test','1.0'),('2019-09-08 15:59:59','2019-09-08 23:59:59','ONTUSDT','4h','0.765900000000000','0.758241000000000','267.807444384499092','265.129369940654101','349.66372161443934','349.663721614439339','test','test','1.0'),('2019-09-09 11:59:59','2019-09-11 03:59:59','ONTUSDT','4h','0.755500000000000','0.747945000000000','267.212316730311329','264.540193563008188','353.6893669494525','353.689366949452506','test','test','1.0'),('2019-09-13 07:59:59','2019-09-13 19:59:59','ONTUSDT','4h','0.749600000000000','0.742104000000000','266.618511582021824','263.952326466201555','355.6810453335403','355.681045333540283','test','test','1.0'),('2019-09-14 15:59:59','2019-09-22 03:59:59','ONTUSDT','4h','0.756200000000000','0.783200000000000','266.026026000728393','275.524442692105936','351.79321079175935','351.793210791759350','test','test','0.3'),('2019-10-07 15:59:59','2019-10-08 11:59:59','ONTUSDT','4h','0.633800000000000','0.627462000000000','268.136785265478977','265.455417412824204','423.0621414728289','423.062141472828898','test','test','1.0'),('2019-10-08 19:59:59','2019-10-08 23:59:59','ONTUSDT','4h','0.629600000000000','0.636800000000000','267.540925742666786','270.600478896013669','424.93793796484556','424.937937964845560','test','test','0.0'),('2019-10-09 11:59:59','2019-10-10 03:59:59','ONTUSDT','4h','0.655100000000000','0.648549000000000','268.220826443410544','265.538618178976435','409.4349358012678','409.434935801267784','test','test','1.0'),('2019-10-11 03:59:59','2019-10-11 07:59:59','ONTUSDT','4h','0.655200000000000','0.648648000000000','267.624780162425225','264.948532360800982','408.4627291856307','408.462729185630678','test','test','1.0'),('2019-10-11 15:59:59','2019-10-12 19:59:59','ONTUSDT','4h','0.640800000000000','0.634392000000000','267.030058428730911','264.359757844443607','416.7135743269833','416.713574326983291','test','test','1.0'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ONTUSDT','4h','0.647300000000000','0.640827000000000','266.436658298889313','263.772291715900451','411.61232550423193','411.612325504231933','test','test','1.0'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ONTUSDT','4h','0.640900000000000','0.634491000000000','265.844576836002886','263.186131067642862','414.7988404368901','414.798840436890089','test','test','1.0'),('2019-10-15 15:59:59','2019-10-15 19:59:59','ONTUSDT','4h','0.646100000000000','0.639639000000000','265.253811109700621','262.601272998603577','410.5460626988092','410.546062698809180','test','test','1.0'),('2019-10-25 19:59:59','2019-11-08 11:59:59','ONTUSDT','4h','0.605800000000000','0.859400000000000','264.664358196123544','375.458153571721027','436.88405116560506','436.884051165605058','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 07:59:59','ONTUSDT','4h','0.854900000000000','0.846351000000000','289.285201612923004','286.392349596793792','338.3848422188829','338.384842218882909','test','test','1.0'),('2019-11-12 11:59:59','2019-11-14 07:59:59','ONTUSDT','4h','0.895200000000000','0.886248000000000','288.642345609338747','285.755922153245365','322.4333619407269','322.433361940726911','test','test','1.0'),('2019-11-29 15:59:59','2019-11-29 19:59:59','ONTUSDT','4h','0.693000000000000','0.686070000000000','288.000918174651247','285.120908992904731','415.5857405117623','415.585740511762310','test','test','1.0'),('2019-12-08 15:59:59','2019-12-08 23:59:59','ONTUSDT','4h','0.646800000000000','0.640332000000000','287.360916134263164','284.487306972920521','444.2809464042411','444.280946404241092','test','test','1.0'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTUSDT','4h','0.639900000000000','0.633501000000000','286.722336320631427','283.855112957425092','448.0736620106758','448.073662010675775','test','test','1.0'),('2019-12-13 15:59:59','2019-12-13 19:59:59','ONTUSDT','4h','0.623900000000000','0.617661000000000','286.085175573252229','283.224323817519689','458.54331715539706','458.543317155397062','test','test','1.0'),('2019-12-29 15:59:59','2019-12-30 03:59:59','ONTUSDT','4h','0.542600000000000','0.537174000000000','285.449430738645049','282.594936431258589','526.0770931416238','526.077093141623777','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:43:28
