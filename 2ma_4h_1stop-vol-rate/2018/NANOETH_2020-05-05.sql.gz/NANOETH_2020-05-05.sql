-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-15 07:59:59','2018-08-15 15:59:59','NANOETH','4h','0.003763000000000','0.004200000000000','1.297777777777778','1.448489680219683','344.8784952904007','344.878495290400679','test','test','0.3'),('2018-08-16 15:59:59','2018-09-06 07:59:59','NANOETH','4h','0.004186000000000','0.009849000000000','1.331269311653757','3.132267427252235','318.0289803281789','318.028980328178875','test','test','0.0'),('2018-09-06 15:59:59','2018-09-09 07:59:59','NANOETH','4h','0.010369000000000','0.010500000000000','1.731491115120085','1.753366448911263','166.9872808486918','166.987280848691796','test','test','0.0'),('2018-09-09 15:59:59','2018-09-09 19:59:59','NANOETH','4h','0.010327000000000','0.010310000000000','1.736352300407013','1.733493968935442','168.1371453865608','168.137145386560803','test','test','0.2'),('2018-09-12 19:59:59','2018-09-12 23:59:59','NANOETH','4h','0.010616000000000','0.011097000000000','1.735717115635554','1.814360666183849','163.5001050900107','163.500105090010692','test','test','0.0'),('2018-09-13 11:59:59','2018-09-13 19:59:59','NANOETH','4h','0.011601000000000','0.011484990000000','1.753193460201841','1.735661525599823','151.12433929849507','151.124339298495073','test','test','1.0'),('2018-09-13 23:59:59','2018-09-14 03:59:59','NANOETH','4h','0.011465000000000','0.011350350000000','1.749297474734726','1.731804499987379','152.57718924855874','152.577189248558739','test','test','1.0'),('2018-09-14 19:59:59','2018-09-14 23:59:59','NANOETH','4h','0.012317000000000','0.012193830000000','1.745410147013093','1.727956045542962','141.70740821734944','141.707408217349439','test','test','1.0'),('2018-09-18 15:59:59','2018-09-19 03:59:59','NANOETH','4h','0.011318000000000','0.011204820000000','1.741531457797509','1.724116143219534','153.87272113425593','153.872721134255926','test','test','1.0'),('2018-09-21 03:59:59','2018-09-21 11:59:59','NANOETH','4h','0.011578000000000','0.011462220000000','1.737661387891292','1.720284774012379','150.08303574808187','150.083035748081869','test','test','1.0'),('2018-10-17 03:59:59','2018-10-18 19:59:59','NANOETH','4h','0.009552000000000','0.009542000000000','1.733799918140422','1.731984800973190','181.51171672324355','181.511716723243552','test','test','0.1'),('2018-10-18 23:59:59','2018-10-22 03:59:59','NANOETH','4h','0.009794000000000','0.009780000000000','1.733396558769926','1.730918760952612','176.98555837961263','176.985558379612627','test','test','0.2'),('2018-10-23 03:59:59','2018-10-23 23:59:59','NANOETH','4h','0.010094000000000','0.009993060000000','1.732845937032746','1.715517477662418','171.67088736207108','171.670887362071085','test','test','1.0'),('2018-10-26 11:59:59','2018-10-27 19:59:59','NANOETH','4h','0.010066000000000','0.009965340000000','1.728995168283784','1.711705216600946','171.76586213826582','171.765862138265817','test','test','1.0'),('2018-10-31 11:59:59','2018-10-31 19:59:59','NANOETH','4h','0.010285000000000','0.010182150000000','1.725152956798709','1.707901427230722','167.73485238684574','167.734852386845745','test','test','1.0'),('2018-11-20 15:59:59','2018-11-20 19:59:59','NANOETH','4h','0.008681000000000','0.008594190000000','1.721319283561378','1.704106090725764','198.28582923181412','198.285829231814120','test','test','1.0'),('2018-11-20 23:59:59','2018-11-22 23:59:59','NANOETH','4h','0.008663000000000','0.008576370000000','1.717494129597908','1.700319188301929','198.25627722473837','198.256277224738369','test','test','1.0'),('2018-11-25 07:59:59','2018-11-25 11:59:59','NANOETH','4h','0.008691000000000','0.008863000000000','1.713677475976580','1.747592160807781','197.17840018140367','197.178400181403674','test','test','0.0'),('2018-11-26 19:59:59','2018-11-30 11:59:59','NANOETH','4h','0.008791000000000','0.008703090000000','1.721214072605735','1.704001931879678','195.79275083673477','195.792750836734768','test','test','1.0'),('2018-12-03 19:59:59','2018-12-04 03:59:59','NANOETH','4h','0.009039000000000','0.008948610000000','1.717389152444389','1.700215260919945','189.99769359933504','189.997693599335037','test','test','1.0'),('2018-12-04 07:59:59','2018-12-04 11:59:59','NANOETH','4h','0.009110000000000','0.009018900000000','1.713572732105624','1.696437004784568','188.09799474265907','188.097994742659068','test','test','1.0'),('2018-12-05 03:59:59','2018-12-05 07:59:59','NANOETH','4h','0.008934000000000','0.008844660000000','1.709764792700945','1.692667144773935','191.3772993844801','191.377299384480096','test','test','1.0'),('2018-12-05 11:59:59','2018-12-05 15:59:59','NANOETH','4h','0.008977000000000','0.009023000000000','1.705965315383832','1.714707033609036','190.03735272182595','190.037352721825954','test','test','0.0'),('2018-12-06 03:59:59','2018-12-06 15:59:59','NANOETH','4h','0.009044000000000','0.009003000000000','1.707907919433877','1.700165302815480','188.84430776579796','188.844307765797964','test','test','0.5'),('2018-12-06 23:59:59','2018-12-07 19:59:59','NANOETH','4h','0.009135000000000','0.009043650000000','1.706187337963122','1.689125464583491','186.7747496401885','186.774749640188503','test','test','1.0'),('2018-12-11 11:59:59','2018-12-13 15:59:59','NANOETH','4h','0.009268000000000','0.009175320000000','1.702395810545426','1.685371852439972','183.6853485698561','183.685348569856103','test','test','1.0'),('2018-12-14 19:59:59','2018-12-15 03:59:59','NANOETH','4h','0.009267000000000','0.009174330000000','1.698612708744214','1.681626581656772','183.29693630562366','183.296936305623660','test','test','1.0'),('2018-12-18 11:59:59','2018-12-18 15:59:59','NANOETH','4h','0.009194000000000','0.009102060000000','1.694838013835894','1.677889633697535','184.34174612093688','184.341746120936875','test','test','1.0'),('2018-12-18 23:59:59','2018-12-19 03:59:59','NANOETH','4h','0.009180000000000','0.009402000000000','1.691071707138480','1.731966905284966','184.21260426345103','184.212604263451027','test','test','0.0'),('2018-12-19 07:59:59','2018-12-19 15:59:59','NANOETH','4h','0.009579000000000','0.009483210000000','1.700159528948811','1.683157933659323','177.488206383632','177.488206383631990','test','test','1.0'),('2018-12-19 19:59:59','2018-12-19 23:59:59','NANOETH','4h','0.009495000000000','0.009400050000000','1.696381396662258','1.679417582695635','178.66049464584077','178.660494645840771','test','test','1.0'),('2018-12-20 11:59:59','2018-12-20 15:59:59','NANOETH','4h','0.009508000000000','0.009412920000000','1.692611660225231','1.675685543622979','178.01973708721397','178.019737087213969','test','test','1.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.688850300980286','1.711371678982570','253.04919103690227','253.049191036902272','test','test','0.0'),('2019-01-09 23:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006854000000000','0.006798000000000','1.693855051647460','1.680015558958190','247.13379802268165','247.133798022681646','test','test','0.8'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.690779608827622','1.973898070689589','240.33825285396193','240.338252853961933','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.753694822574726','1.745224186940601','273.24631077823716','273.246310778237159','test','test','0.5'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.751812459100476','1.748332923276441','267.6566018488122','267.656601848812215','test','test','0.4'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.751039228917357','1.744583784755450','268.9768400794711','268.976840079471117','test','test','0.4'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.749604685770267','1.765092639337831','267.0336821993692','267.033682199369196','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.753046453229725','1.910828562769624','264.2916407703491','264.291640770349090','test','test','0.0'),('2019-03-17 19:59:59','2019-03-18 11:59:59','NANOETH','4h','0.007329000000000','0.007255710000000','1.788109144238592','1.770228052796206','243.9772334886877','243.977233488687688','test','test','1.0'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007308000000000','0.007234920000000','1.784135568362506','1.766294212678881','244.13458789853664','244.134587898536637','test','test','1.0'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.780170822655034','1.767859821115234','246.2200307959936','246.220030795993608','test','test','0.7'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007176510000000','1.777435044535078','1.759660694089727','245.19727473238768','245.197274732387683','test','test','1.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.773485188880556','1.780393589727615','246.72860168065608','246.728601680656084','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007171560000000','1.775020389068791','1.757270185178103','245.03318457603413','245.033184576034131','test','test','1.0'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.771075899315305','1.784318505042670','245.23343939563898','245.233439395638982','test','test','0.4'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.774018700588053','1.901072320515472','236.59891979035115','236.598919790351147','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.802252838349702','1.965533864730103','220.0552916177902','220.055291617790203','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 03:59:59','NANOETH','4h','0.009923000000000','0.009823770000000','1.838537510878679','1.820152135769892','185.28041024676807','185.280410246768071','test','test','1.0'),('2019-04-13 19:59:59','2019-04-14 07:59:59','NANOETH','4h','0.009546000000000','0.009450540000000','1.834451871965616','1.816107353245960','192.16969117594968','192.169691175949680','test','test','1.0'),('2019-04-17 07:59:59','2019-04-18 07:59:59','NANOETH','4h','0.009745000000000','0.009647550000000','1.830375312250137','1.812071559127635','187.82712285788986','187.827122857889862','test','test','1.0'),('2019-04-19 15:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009496000000000','0.009556000000000','1.826307811556247','1.837847245917386','192.32390601898138','192.323906018981376','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.828872130303167','1.916717047964550','184.5481463474437','184.548146347443691','test','test','1.0'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.848393223116807','1.831854067464111','285.1578560809638','285.157856080963825','test','test','0.9'),('2019-06-08 19:59:59','2019-06-09 07:59:59','NANOETH','4h','0.006592000000000','0.006526080000000','1.844717855193987','1.826270676642047','279.84190764471884','279.841907644718844','test','test','1.0'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006407280000000','1.840618482182444','1.822212297360620','284.3971696820834','284.397169682083415','test','test','1.0'),('2019-06-13 23:59:59','2019-06-14 07:59:59','NANOETH','4h','0.006924000000000','0.006854760000000','1.836528218888706','1.818162936699819','265.24093282621396','265.240932826213964','test','test','1.0'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004427280000000','1.832447045068953','1.814122574618263','409.76007268983744','409.760072689837443','test','test','1.0'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004515390000000','1.828374940524355','1.810091191119112','400.87150636359473','400.871506363594733','test','test','1.0'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004443120000000','1.824311885100968','1.806068766249959','406.4866054146542','406.486605414654207','test','test','1.0'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004405500000000','1.820257858689633','1.802055280102737','409.046709817895','409.046709817895021','test','test','1.0'),('2019-07-14 15:59:59','2019-07-14 19:59:59','NANOETH','4h','0.004497000000000','0.004452030000000','1.816212841225878','1.798050712813619','403.87210167353294','403.872101673532939','test','test','1.0'),('2019-07-15 03:59:59','2019-07-15 19:59:59','NANOETH','4h','0.004533000000000','0.004487670000000','1.812176812689820','1.794055044562922','399.77428031983686','399.774280319836862','test','test','1.0'),('2019-07-16 11:59:59','2019-07-21 11:59:59','NANOETH','4h','0.004481000000000','0.005357000000000','1.808149753106065','2.161628705063421','403.5147853394477','403.514785339447712','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:24:46
