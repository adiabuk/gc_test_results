-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-15 15:59:59','TNTBTC','4h','0.000013190000000','0.000013058100000','0.033333333333333','0.033000000000000','2527.1670457417235','2527.167045741723541','test','test','1.0'),('2018-06-02 15:59:59','2018-06-02 19:59:59','TNTBTC','4h','0.000011330000000','0.000011216700000','0.033259259259259','0.032926666666666','2935.5039063776994','2935.503906377699423','test','test','1.0'),('2018-06-23 15:59:59','2018-06-23 19:59:59','TNTBTC','4h','0.000009220000000','0.000009127800000','0.033185349794239','0.032853496296297','3599.278719548663','3599.278719548663048','test','test','1.0'),('2018-07-02 15:59:59','2018-07-02 19:59:59','TNTBTC','4h','0.000007440000000','0.000007365600000','0.033111604572474','0.032780488526749','4450.48448554755','4450.484485547550321','test','test','1.0'),('2018-07-03 03:59:59','2018-07-03 07:59:59','TNTBTC','4h','0.000008300000000','0.000008217000000','0.033038023228979','0.032707642996689','3980.4847263830516','3980.484726383051566','test','test','1.0'),('2018-07-04 15:59:59','2018-07-05 15:59:59','TNTBTC','4h','0.000007650000000','0.000007573500000','0.032964605399582','0.032634959345586','4309.09874504334','4309.098745043340386','test','test','1.0'),('2018-08-28 03:59:59','2018-08-28 07:59:59','TNTBTC','4h','0.000002930000000','0.000002950000000','0.032891350720916','0.033115865060308','11225.71696959583','11225.716969595829141','test','test','0.0'),('2018-08-28 11:59:59','2018-09-02 11:59:59','TNTBTC','4h','0.000003020000000','0.000003110000000','0.032941242796336','0.033922935462452','10907.696290177557','10907.696290177556875','test','test','0.0'),('2018-09-02 15:59:59','2018-09-02 23:59:59','TNTBTC','4h','0.000003300000000','0.000003267000000','0.033159396722140','0.032827802754919','10048.302037012054','10048.302037012053916','test','test','1.0'),('2018-09-15 19:59:59','2018-09-25 03:59:59','TNTBTC','4h','0.000002780000000','0.000003930000000','0.033085709173868','0.046772243544353','11901.334235204476','11901.334235204476499','test','test','0.0'),('2018-09-25 19:59:59','2018-09-26 03:59:59','TNTBTC','4h','0.000004010000000','0.000003969900000','0.036127161256198','0.035765889643636','9009.26714618415','9009.267146184149169','test','test','1.0'),('2018-09-27 03:59:59','2018-09-27 07:59:59','TNTBTC','4h','0.000004040000000','0.000003999600000','0.036046878675629','0.035686409888873','8922.494721690373','8922.494721690372899','test','test','1.0'),('2018-09-28 07:59:59','2018-09-28 11:59:59','TNTBTC','4h','0.000004300000000','0.000004257000000','0.035966774500794','0.035607106755786','8364.366162975452','8364.366162975451516','test','test','1.0'),('2018-09-29 19:59:59','2018-09-29 23:59:59','TNTBTC','4h','0.000004230000000','0.000004187700000','0.035886848335237','0.035527979851885','8483.888495327921','8483.888495327921191','test','test','1.0'),('2018-09-30 03:59:59','2018-09-30 07:59:59','TNTBTC','4h','0.000004300000000','0.000004257000000','0.035807099783381','0.035449028785547','8327.232507763048','8327.232507763048488','test','test','1.0'),('2018-10-01 19:59:59','2018-10-03 03:59:59','TNTBTC','4h','0.000004360000000','0.000004316400000','0.035727528450529','0.035370253166024','8194.387259295667','8194.387259295666809','test','test','1.0'),('2018-10-04 11:59:59','2018-10-04 15:59:59','TNTBTC','4h','0.000004610000000','0.000004563900000','0.035648133942861','0.035291652603432','7732.783935544759','7732.783935544758606','test','test','1.0'),('2018-10-08 15:59:59','2018-10-09 15:59:59','TNTBTC','4h','0.000004420000000','0.000004390000000','0.035568915867433','0.035327497886432','8047.266033355807','8047.266033355806940','test','test','0.7'),('2018-10-10 11:59:59','2018-10-10 19:59:59','TNTBTC','4h','0.000004540000000','0.000004494600000','0.035515267427210','0.035160114752938','7822.746129341457','7822.746129341457163','test','test','1.0'),('2018-10-10 23:59:59','2018-10-11 03:59:59','TNTBTC','4h','0.000004630000000','0.000004583700000','0.035436344610705','0.035081981164598','7653.638144860763','7653.638144860762623','test','test','1.0'),('2018-10-13 19:59:59','2018-10-14 03:59:59','TNTBTC','4h','0.000004430000000','0.000004385700000','0.035357597178237','0.035004021206455','7981.398911565939','7981.398911565938761','test','test','1.0'),('2018-10-14 15:59:59','2018-10-14 19:59:59','TNTBTC','4h','0.000004590000000','0.000004544100000','0.035279024740063','0.034926234492662','7686.062034872185','7686.062034872184995','test','test','1.0'),('2018-10-15 11:59:59','2018-10-15 19:59:59','TNTBTC','4h','0.000004380000000','0.000004336200000','0.035200626907308','0.034848620638235','8036.672809887568','8036.672809887568292','test','test','1.0'),('2018-10-16 07:59:59','2018-10-27 15:59:59','TNTBTC','4h','0.000004550000000','0.000005140000000','0.035122403291958','0.039676736905640','7719.209514716045','7719.209514716045305','test','test','0.0'),('2018-10-30 15:59:59','2018-10-30 23:59:59','TNTBTC','4h','0.000005800000000','0.000005742000000','0.036134477428332','0.035773132654049','6230.082315229616','6230.082315229616142','test','test','1.0'),('2018-11-02 11:59:59','2018-11-02 15:59:59','TNTBTC','4h','0.000005870000000','0.000005811300000','0.036054178589602','0.035693636803706','6142.108788688625','6142.108788688625282','test','test','1.0'),('2018-11-08 19:59:59','2018-11-09 03:59:59','TNTBTC','4h','0.000005460000000','0.000005405400000','0.035974058192736','0.035614317610809','6588.655346655027','6588.655346655026733','test','test','1.0'),('2018-11-09 11:59:59','2018-11-09 23:59:59','TNTBTC','4h','0.000005570000000','0.000005514300000','0.035894115841197','0.035535174682785','6444.185967898942','6444.185967898942181','test','test','1.0'),('2018-11-10 11:59:59','2018-11-10 15:59:59','TNTBTC','4h','0.000005690000000','0.000005633100000','0.035814351139328','0.035456207627935','6294.262063150752','6294.262063150751601','test','test','1.0'),('2018-11-28 19:59:59','2018-11-28 23:59:59','TNTBTC','4h','0.000003820000000','0.000003880000000','0.035734763692352','0.036296042703227','9354.650181243862','9354.650181243861880','test','test','0.0'),('2018-11-30 07:59:59','2018-12-03 03:59:59','TNTBTC','4h','0.000003990000000','0.000003950100000','0.035859492361435','0.035500897437821','8987.341443968644','8987.341443968643944','test','test','1.0'),('2018-12-04 15:59:59','2018-12-04 19:59:59','TNTBTC','4h','0.000004060000000','0.000004019400000','0.035779804600632','0.035422006554626','8812.75975385019','8812.759753850190464','test','test','1.0'),('2018-12-05 11:59:59','2018-12-05 19:59:59','TNTBTC','4h','0.000004130000000','0.000004088700000','0.035700293923742','0.035343290984505','8644.138964586333','8644.138964586332804','test','test','1.0'),('2018-12-12 19:59:59','2018-12-13 19:59:59','TNTBTC','4h','0.000003840000000','0.000003801600000','0.035620959937244','0.035264750337872','9276.291650324074','9276.291650324073998','test','test','1.0'),('2018-12-17 15:59:59','2018-12-17 19:59:59','TNTBTC','4h','0.000003860000000','0.000003821400000','0.035541802248495','0.035186384226010','9207.72078976557','9207.720789765569862','test','test','1.0'),('2018-12-24 15:59:59','2018-12-24 23:59:59','TNTBTC','4h','0.000003570000000','0.000003570000000','0.035462820465721','0.035462820465721','9933.563155664053','9933.563155664052829','test','test','0.0'),('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003207600000','0.035462820465721','0.035108192261064','10945.314958555762','10945.314958555762132','test','test','1.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','TNTBTC','4h','0.000003410000000','0.000003375900000','0.035384014198019','0.035030174056039','10376.543753084781','10376.543753084781201','test','test','1.0'),('2019-01-12 15:59:59','2019-01-12 19:59:59','TNTBTC','4h','0.000003280000000','0.000003247200000','0.035305383055357','0.034952329224803','10763.836297364905','10763.836297364905477','test','test','1.0'),('2019-01-12 23:59:59','2019-01-13 03:59:59','TNTBTC','4h','0.000003410000000','0.000003375900000','0.035226926648567','0.034874657382081','10330.477023040206','10330.477023040206404','test','test','1.0'),('2019-01-14 19:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003300000000','0.000004210000000','0.035148644589348','0.044841149612471','10651.104421014545','10651.104421014544641','test','test','0.0'),('2019-01-21 15:59:59','2019-01-22 11:59:59','TNTBTC','4h','0.000004500000000','0.000004455000000','0.037302534594486','0.036929509248541','8289.452132108097','8289.452132108097430','test','test','1.0'),('2019-01-24 15:59:59','2019-01-24 23:59:59','TNTBTC','4h','0.000004500000000','0.000004455000000','0.037219640073165','0.036847443672433','8271.031127370072','8271.031127370071772','test','test','1.0'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004494600000','0.037136929761892','0.036765560464273','8179.940476187567','8179.940476187566674','test','test','1.0'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004187700000','0.037054403251310','0.036683859218797','8759.906205983345','8759.906205983344989','test','test','1.0'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004019400000','0.036972060132973','0.036602339531643','9106.418751963874','9106.418751963874456','test','test','1.0'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.036889899999344','0.036800793960698','8910.60386457595','8910.603864575950865','test','test','0.2'),('2019-02-10 11:59:59','2019-02-10 15:59:59','TNTBTC','4h','0.000004150000000','0.000004108500000','0.036870098657423','0.036501397670849','8884.361122270626','8884.361122270625856','test','test','1.0'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003979800000','0.036788165104851','0.036420283453802','9151.284851953013','9151.284851953012549','test','test','1.0'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003910500000','0.036706413626840','0.036339349490572','9292.762943503853','9292.762943503852512','test','test','1.0'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003920400000','0.036624843818781','0.036258595380593','9248.69793403552','9248.697934035519211','test','test','1.0'),('2019-02-20 23:59:59','2019-02-21 07:59:59','TNTBTC','4h','0.000004070000000','0.000004029300000','0.036543455276961','0.036178020724191','8978.735940285284','8978.735940285283505','test','test','1.0'),('2019-02-21 23:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004020000000','0.000004040000000','0.036462247598568','0.036643651815476','9070.210845414871','9070.210845414871073','test','test','0.2'),('2019-02-26 11:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004160000000','0.000004118400000','0.036502559646770','0.036137534050302','8774.65376124268','8774.653761242680048','test','test','1.0'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004059000000','0.036421442847554','0.036057228419078','8883.27874330596','8883.278743305960234','test','test','1.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.036340506307893','0.036161489035440','8950.863622633771','8950.863622633771229','test','test','0.5'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.036300724691792','0.037648523875893','8985.327894008029','8985.327894008029034','test','test','0.0'),('2019-03-04 23:59:59','2019-03-05 03:59:59','TNTBTC','4h','0.000004290000000','0.000004247100000','0.036600235621593','0.036234233265377','8531.523454916705','8531.523454916705305','test','test','1.0'),('2019-03-05 19:59:59','2019-03-06 03:59:59','TNTBTC','4h','0.000004210000000','0.000004167900000','0.036518901764656','0.036153712747009','8674.32345953819','8674.323459538189127','test','test','1.0'),('2019-03-08 11:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004250000000','0.000004270000000','0.036437748649623','0.036609220407974','8573.587917558378','8573.587917558377740','test','test','0.5'),('2019-03-11 23:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004710000000','0.000004662900000','0.036475853484812','0.036111094949964','7744.342565777541','7744.342565777540585','test','test','1.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.036394796032624','0.036079006045356','7894.7496816971325','7894.749681697132473','test','test','0.9'),('2019-03-26 03:59:59','2019-03-26 07:59:59','TNTBTC','4h','0.000004740000000','0.000004692600000','0.036324620479898','0.035961374275099','7663.422042172479','7663.422042172479451','test','test','1.0'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.036243899101053','0.036695067969531','7519.481141297373','7519.481141297373142','test','test','0.2'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.036344158849604','0.035986968099239','8929.76875911646','8929.768759116459478','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:54:39
