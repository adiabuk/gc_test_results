-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-23 15:59:59','BNBUSDT','4h','13.726500000000000','13.589235000000000','222.222222222222200','220.000000000000000','16.18928512164224','16.189285121642239','test','test','1.0'),('2018-04-23 19:59:59','2018-04-25 15:59:59','BNBUSDT','4h','13.534200000000000','13.590000000000000','221.728395061728406','222.642556552207651','16.38282241002264','16.382822410022641','test','test','0.0'),('2018-04-26 07:59:59','2018-04-26 11:59:59','BNBUSDT','4h','14.260300000000001','14.117697000000001','221.931542059612667','219.712226639016535','15.562894333191634','15.562894333191634','test','test','1.0'),('2018-04-26 23:59:59','2018-04-27 03:59:59','BNBUSDT','4h','14.630000000000001','14.483700000000001','221.438360855035739','219.223977246485390','15.13590983288009','15.135909832880090','test','test','1.0'),('2018-04-28 15:59:59','2018-04-29 11:59:59','BNBUSDT','4h','15.112500000000001','14.961375000000000','220.946275608691252','218.736812852604345','14.62010095012018','14.620100950120181','test','test','1.0'),('2018-05-02 07:59:59','2018-05-02 15:59:59','BNBUSDT','4h','14.219900000000001','14.138999999999999','220.455283885116359','219.201067437299827','15.50329354532144','15.503293545321441','test','test','0.6'),('2018-05-02 23:59:59','2018-05-03 11:59:59','BNBUSDT','4h','14.439000000000000','14.294610000000000','220.176569118934935','217.974803427745570','15.248740849015508','15.248740849015508','test','test','1.0'),('2018-05-03 15:59:59','2018-05-04 15:59:59','BNBUSDT','4h','14.490100000000000','14.345198999999999','219.687287854226156','217.490414975683905','15.161198877456068','15.161198877456068','test','test','1.0'),('2018-05-05 15:59:59','2018-05-06 11:59:59','BNBUSDT','4h','14.470100000000000','14.325399000000001','219.199093881216754','217.007102942404572','15.148415966801663','15.148415966801663','test','test','1.0'),('2018-05-09 19:59:59','2018-05-10 07:59:59','BNBUSDT','4h','14.570800000000000','14.425091999999999','218.711984783702974','216.524864935865935','15.010293517425465','15.010293517425465','test','test','1.0'),('2018-05-18 11:59:59','2018-05-18 15:59:59','BNBUSDT','4h','14.879799999999999','14.731002000000000','218.225958150850289','216.043698569341785','14.66592011659097','14.665920116590970','test','test','1.0'),('2018-05-18 19:59:59','2018-05-19 15:59:59','BNBUSDT','4h','14.990700000000000','14.840793000000000','217.741011577181752','215.563601461409945','14.525072983728695','14.525072983728695','test','test','1.0'),('2018-05-21 23:59:59','2018-05-22 03:59:59','BNBUSDT','4h','14.699600000000000','14.552604000000001','217.257142662565769','215.084571235940103','14.779799631457031','14.779799631457031','test','test','1.0'),('2018-05-31 07:59:59','2018-06-04 15:59:59','BNBUSDT','4h','13.856199999999999','13.891999999999999','216.774349012204510','217.334424768518431','15.644574198712816','15.644574198712816','test','test','0.5'),('2018-06-05 07:59:59','2018-06-05 11:59:59','BNBUSDT','4h','14.715600000000000','14.568444000000000','216.898810291385388','214.729822188471530','14.739379317960898','14.739379317960898','test','test','1.0'),('2018-06-05 19:59:59','2018-06-10 07:59:59','BNBUSDT','4h','15.100000000000000','14.949000000000000','216.416812935182293','214.252644805830471','14.332239267230616','14.332239267230616','test','test','1.0'),('2018-06-11 23:59:59','2018-06-12 15:59:59','BNBUSDT','4h','15.470000000000001','15.770000000000000','215.935886684215234','220.123395798970535','13.958363715851016','13.958363715851016','test','test','0.0'),('2018-06-13 03:59:59','2018-06-13 07:59:59','BNBUSDT','4h','15.630100000000001','15.473799000000000','216.866444265271980','214.697779822619253','13.874923657895469','13.874923657895469','test','test','1.0'),('2018-06-15 15:59:59','2018-06-15 23:59:59','BNBUSDT','4h','15.325400000000000','15.172146000000000','216.384518833571377','214.220673645235649','14.119339060224945','14.119339060224945','test','test','1.0'),('2018-06-16 11:59:59','2018-06-16 15:59:59','BNBUSDT','4h','15.670400000000001','15.513696000000001','215.903664347274542','213.744627703801797','13.777801737497098','13.777801737497098','test','test','1.0'),('2018-06-17 03:59:59','2018-06-20 03:59:59','BNBUSDT','4h','16.187700000000000','16.025822999999999','215.423878426502796','213.269639642237763','13.30787440010025','13.307874400100250','test','test','1.0'),('2018-06-21 15:59:59','2018-06-22 07:59:59','BNBUSDT','4h','16.594999999999999','16.429050000000000','214.945158696666141','212.795707109699492','12.95240486270962','12.952404862709621','test','test','1.0'),('2018-07-16 11:59:59','2018-07-17 07:59:59','BNBUSDT','4h','13.183100000000000','13.051269000000000','214.467502788451355','212.322827760566838','16.26836652899935','16.268366528999351','test','test','1.0'),('2018-07-17 15:59:59','2018-07-18 19:59:59','BNBUSDT','4h','13.183600000000000','13.170000000000000','213.990908337810311','213.770158591656440','16.23159898190254','16.231598981902540','test','test','0.1'),('2018-07-19 11:59:59','2018-07-19 15:59:59','BNBUSDT','4h','13.263400000000001','13.130766000000001','213.941852838665028','211.802434310278386','16.130242082623234','16.130242082623234','test','test','1.0'),('2018-07-25 07:59:59','2018-07-30 15:59:59','BNBUSDT','4h','13.042199999999999','13.390000000000001','213.466426499023527','219.158995477904426','16.36736336653506','16.367363366535059','test','test','0.8'),('2018-07-31 11:59:59','2018-08-01 07:59:59','BNBUSDT','4h','13.449999999999999','13.495799999999999','214.731441827663730','215.462646291285068','15.96516296116459','15.965162961164591','test','test','0.0'),('2018-08-02 11:59:59','2018-08-02 15:59:59','BNBUSDT','4h','13.612800000000000','13.516299999999999','214.893931708468500','213.370566610188405','15.786166821555337','15.786166821555337','test','test','0.7'),('2018-08-02 23:59:59','2018-08-03 03:59:59','BNBUSDT','4h','14.150000000000000','14.008500000000000','214.555406131072914','212.409852069762195','15.162926228344375','15.162926228344375','test','test','1.0'),('2018-08-03 07:59:59','2018-08-04 15:59:59','BNBUSDT','4h','13.967900000000000','13.828220999999999','214.078616339670560','211.937830176273820','15.32647114739299','15.326471147392990','test','test','1.0'),('2018-08-06 15:59:59','2018-08-06 19:59:59','BNBUSDT','4h','13.679600000000001','13.612399999999999','213.602886081137939','212.553578064481542','15.614702628815019','15.614702628815019','test','test','0.5'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BNBUSDT','4h','13.699800000000000','13.562802000000000','213.369706521880943','211.236009456662146','15.574658500261387','15.574658500261387','test','test','1.0'),('2018-08-26 23:59:59','2018-08-27 03:59:59','BNBUSDT','4h','10.215800000000000','10.313599999999999','212.895551618498985','214.933687148588547','20.839831596008047','20.839831596008047','test','test','0.0'),('2018-08-27 07:59:59','2018-08-30 11:59:59','BNBUSDT','4h','10.420000000000000','10.449999999999999','213.348470625185541','213.962717661534441','20.47490121163009','20.474901211630090','test','test','0.0'),('2018-08-30 23:59:59','2018-08-31 03:59:59','BNBUSDT','4h','10.789899999999999','10.682001000000000','213.484969966596395','211.350120266930418','19.785630076886385','19.785630076886385','test','test','1.0'),('2018-08-31 19:59:59','2018-09-05 11:59:59','BNBUSDT','4h','10.927800000000000','10.818522000000000','213.010558922226210','210.880453333003942','19.49253819819417','19.492538198194168','test','test','1.0'),('2018-09-14 19:59:59','2018-09-14 23:59:59','BNBUSDT','4h','10.026000000000000','9.926800000000000','212.537202124621246','210.434300623448081','21.198603842471698','21.198603842471698','test','test','1.0'),('2018-09-15 03:59:59','2018-09-16 03:59:59','BNBUSDT','4h','10.140000000000001','10.038600000000001','212.069890679916142','209.949191773116979','20.914190402358592','20.914190402358592','test','test','1.0'),('2018-09-20 23:59:59','2018-09-24 11:59:59','BNBUSDT','4h','10.038800000000000','9.938412000000000','211.598624256182944','209.482638013621113','21.07807947724658','21.078079477246579','test','test','1.0'),('2018-09-27 19:59:59','2018-09-28 11:59:59','BNBUSDT','4h','10.039500000000000','9.949999999999999','211.128405091169242','209.246240416069895','21.02977290613768','21.029772906137680','test','test','0.9'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BNBUSDT','4h','9.960900000000001','9.988099999999999','210.710146274480479','211.285527613382129','21.153725694915167','21.153725694915167','test','test','0.0'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBUSDT','4h','10.000000000000000','9.900000000000000','210.838008794236401','208.729628706294022','21.08380087942364','21.083800879423642','test','test','1.0'),('2018-09-30 19:59:59','2018-09-30 23:59:59','BNBUSDT','4h','9.980800000000000','10.017200000000001','210.369479885804736','211.136697851082403','21.07741662850721','21.077416628507208','test','test','0.0'),('2018-10-01 19:59:59','2018-10-01 23:59:59','BNBUSDT','4h','9.951900000000000','9.981100000000000','210.539972766977570','211.157720855764211','21.15575646529583','21.155756465295831','test','test','0.0'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBUSDT','4h','10.024100000000001','10.345700000000001','210.677250120041236','217.436341074701062','21.0170738639919','21.017073863991900','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','BNBUSDT','4h','10.340199999999999','10.236797999999999','212.179270332187912','210.057477628865996','20.519842008103126','20.519842008103126','test','test','1.0'),('2018-10-15 07:59:59','2018-10-16 15:59:59','BNBUSDT','4h','10.355100000000000','10.251549000000001','211.707760842560788','209.590683234135213','20.44478187970766','20.444781879707659','test','test','1.0'),('2018-10-16 23:59:59','2018-10-17 11:59:59','BNBUSDT','4h','10.277100000000001','10.174329000000000','211.237299151799562','209.124926160281575','20.554173760282527','20.554173760282527','test','test','1.0'),('2018-10-17 23:59:59','2018-10-18 15:59:59','BNBUSDT','4h','10.233800000000000','10.132400000000001','210.767882931462253','208.679522466214706','20.595270860429384','20.595270860429384','test','test','1.0'),('2018-11-04 15:59:59','2018-11-04 19:59:59','BNBUSDT','4h','9.700900000000001','9.826499999999999','210.303802828073884','213.026659226470514','21.67879298086506','21.678792980865062','test','test','0.0'),('2018-11-04 23:59:59','2018-11-05 07:59:59','BNBUSDT','4h','9.819000000000001','9.720810000000000','210.908882027717596','208.799793207440388','21.47967023400729','21.479670234007290','test','test','1.0'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BNBUSDT','4h','9.726699999999999','9.729699999999999','210.440195623211565','210.505101561183295','21.635312657243627','21.635312657243627','test','test','0.0'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBUSDT','4h','9.733300000000000','9.694200000000000','210.454619164983029','209.609194118046133','21.62212396258032','21.622123962580321','test','test','0.4'),('2018-11-06 07:59:59','2018-11-08 19:59:59','BNBUSDT','4h','9.742000000000001','9.742500000000000','210.266746932330392','210.277538697210872','21.583529761068608','21.583529761068608','test','test','0.1'),('2018-12-04 15:59:59','2018-12-06 07:59:59','BNBUSDT','4h','5.756200000000000','5.894800000000000','210.269145102303838','215.332086541305131','36.52915901155343','36.529159011553432','test','test','0.0'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BNBUSDT','4h','5.061900000000000','5.011280999999999','211.394243199859687','209.280300767861092','41.761837096714615','41.761837096714615','test','test','1.0'),('2018-12-18 15:59:59','2018-12-25 03:59:59','BNBUSDT','4h','5.085000000000000','5.365500000000000','210.924478214971117','222.559545302345640','41.47974006194122','41.479740061941222','test','test','0.0'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BNBUSDT','4h','5.602900000000000','5.546871000000000','213.510048678832135','211.374948192043831','38.10706039351624','38.107060393516242','test','test','1.0'),('2018-12-28 15:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.637000000000000','5.893500000000000','213.035581903990277','222.729324454704056','37.79236861876713','37.792368618767128','test','test','0.0'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','215.189746915260002','222.306610636353156','36.68486454171738','36.684864541717381','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.997717000000000','216.771272186614027','214.603559464747889','35.780874533551334','35.780874533551334','test','test','1.0'),('2019-01-16 23:59:59','2019-01-17 03:59:59','BNBUSDT','4h','6.091100000000000','6.030189000000000','216.289558248421571','214.126662665937346','35.50911300888535','35.509113008885350','test','test','1.0'),('2019-01-17 19:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.147800000000000','6.739800000000000','215.808914785647289','236.590149951577047','35.10343778028682','35.103437780286818','test','test','0.0'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','220.426967044742781','328.115786625390399','33.52807359526995','33.528073595269952','test','test','0.8'),('2019-02-28 11:59:59','2019-02-28 19:59:59','BNBUSDT','4h','10.347600000000000','10.244123999999999','244.357815840442214','241.914237682037793','23.61492673087887','23.614926730878871','test','test','1.0'),('2019-02-28 23:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.277900000000001','14.458200000000000','243.814798471907920','342.980873453384277','23.72223883010225','23.722238830102249','test','test','0.0'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.998697999999999','265.851704023347168','263.193186983113719','17.547735608991772','17.547735608991772','test','test','1.0'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBUSDT','4h','17.040199999999999','16.869797999999999','265.260922458850757','262.608313234262255','15.56677283475844','15.566772834758440','test','test','1.0'),('2019-03-27 23:59:59','2019-03-29 19:59:59','BNBUSDT','4h','16.600000000000001','16.434000000000001','264.671453742275560','262.024739204852779','15.944063478450333','15.944063478450333','test','test','1.0'),('2019-03-29 23:59:59','2019-03-30 03:59:59','BNBUSDT','4h','16.475300000000001','16.310547000000000','264.083294956181646','261.442462006619849','16.02904317106102','16.029043171061019','test','test','1.0'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','263.496443189612364','284.656272032511481','15.958842177312844','15.958842177312844','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.115416000000000','268.198627376923298','265.516641103154086','14.656944179650859','14.656944179650859','test','test','1.0'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','267.602630427196743','266.694640450662405','14.621416691374037','14.621416691374037','test','test','0.3'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','267.400854876855817','268.321443028825968','14.635741684739022','14.635741684739022','test','test','0.0'),('2019-04-13 19:59:59','2019-04-23 11:59:59','BNBUSDT','4h','18.371700000000001','23.763100000000001','267.605430021738073','346.137515534739009','14.566176783952386','14.566176783952386','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:40:47
