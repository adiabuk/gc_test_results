-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 23:59:59','2018-03-21 03:59:59','LINKETH','4h','0.000703000000000','0.000707100000000','1.297777777777778','1.305346609767663','1846.0565828986882','1846.056582898688248','test','test','0.0'),('2018-03-21 07:59:59','2018-03-21 11:59:59','LINKETH','4h','0.000713320000000','0.000722970000000','1.299459740442197','1.317039208977030','1821.7065839205356','1821.706583920535650','test','test','0.0'),('2018-03-21 15:59:59','2018-03-22 11:59:59','LINKETH','4h','0.000775000000000','0.000767250000000','1.303366289005493','1.290332626115438','1681.7629535554745','1681.762953555474496','test','test','1.0'),('2018-03-24 15:59:59','2018-03-25 03:59:59','LINKETH','4h','0.000789830000000','0.000781931700000','1.300469919474369','1.287465220279625','1646.5187691963706','1646.518769196370613','test','test','1.0'),('2018-03-26 23:59:59','2018-03-27 07:59:59','LINKETH','4h','0.000758480000000','0.000750895200000','1.297579986319982','1.284604186456782','1710.7636144921187','1710.763614492118677','test','test','1.0'),('2018-03-27 15:59:59','2018-03-29 11:59:59','LINKETH','4h','0.000770000000000','0.000762300000000','1.294696475239271','1.281749510486878','1681.423993817235','1681.423993817234987','test','test','1.0'),('2018-04-04 19:59:59','2018-04-04 23:59:59','LINKETH','4h','0.000743590000000','0.000767000000000','1.291819371960961','1.332488949950990','1737.2737287496623','1737.273728749662268','test','test','0.0'),('2018-04-08 03:59:59','2018-04-08 07:59:59','LINKETH','4h','0.000790850000000','0.000782941500000','1.300857055958746','1.287848485399159','1644.8846885739972','1644.884688573997209','test','test','1.0'),('2018-04-08 19:59:59','2018-04-09 07:59:59','LINKETH','4h','0.000804000000000','0.000795960000000','1.297966262501060','1.284986599876049','1614.3858986331586','1614.385898633158604','test','test','1.0'),('2018-04-10 03:59:59','2018-04-10 07:59:59','LINKETH','4h','0.000810000000000','0.000801900000000','1.295081893028835','1.282131074098547','1598.8665346035002','1598.866534603500213','test','test','1.0'),('2018-04-10 11:59:59','2018-04-10 15:59:59','LINKETH','4h','0.000823200000000','0.000814968000000','1.292203933266549','1.279281893933883','1569.7326691770515','1569.732669177051548','test','test','1.0'),('2018-04-10 19:59:59','2018-04-11 15:59:59','LINKETH','4h','0.000855530000000','0.000846974700000','1.289332368970401','1.276439045280697','1507.0568758201357','1507.056875820135701','test','test','1.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKETH','4h','0.000795000000000','0.000787050000000','1.286467185928244','1.273602514068961','1618.1977181487348','1618.197718148734793','test','test','1.0'),('2018-04-16 11:59:59','2018-04-16 15:59:59','LINKETH','4h','0.000794280000000','0.000795000000000','1.283608369959515','1.284771936996795','1616.065329555717','1616.065329555716971','test','test','0.0'),('2018-04-16 23:59:59','2018-04-20 11:59:59','LINKETH','4h','0.000801680000000','0.000806820000000','1.283866940412244','1.292098499230873','1601.4705872820123','1601.470587282012275','test','test','0.0'),('2018-04-29 15:59:59','2018-04-29 23:59:59','LINKETH','4h','0.000763650000000','0.000756013500000','1.285696175705272','1.272839213948219','1683.619689262453','1683.619689262452994','test','test','1.0'),('2018-04-30 07:59:59','2018-04-30 11:59:59','LINKETH','4h','0.000756820000000','0.000756230000000','1.282839073092594','1.281839000349901','1695.038546936648','1695.038546936647890','test','test','0.1'),('2018-04-30 15:59:59','2018-05-03 03:59:59','LINKETH','4h','0.000808720000000','0.000800632800000','1.282616834705329','1.269790666358276','1585.9838197464248','1585.983819746424842','test','test','1.0'),('2018-05-07 23:59:59','2018-05-08 23:59:59','LINKETH','4h','0.000765710000000','0.000758052900000','1.279766575072650','1.266968909321923','1671.3462996077499','1671.346299607749870','test','test','1.0'),('2018-05-15 15:59:59','2018-05-15 19:59:59','LINKETH','4h','0.000724110000000','0.000727950000000','1.276922649350267','1.283694248932520','1763.437391211648','1763.437391211647991','test','test','0.0'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKETH','4h','0.000622050000000','0.000622350000000','1.278427449257434','1.279044004574173','2055.184389128581','2055.184389128581188','test','test','0.7'),('2018-06-30 03:59:59','2018-06-30 11:59:59','LINKETH','4h','0.000455540000000','0.000450984600000','1.278564461550043','1.265778816934543','2806.700754159992','2806.700754159991902','test','test','1.0'),('2018-06-30 19:59:59','2018-07-05 15:59:59','LINKETH','4h','0.000484730000000','0.000484080000000','1.275723207191042','1.274012522717884','2631.8222663978763','2631.822266397876319','test','test','0.1'),('2018-07-06 23:59:59','2018-07-10 03:59:59','LINKETH','4h','0.000489000000000','0.000484350000000','1.275343055085896','1.263215559776797','2608.063507333122','2608.063507333121834','test','test','1.0'),('2018-07-17 15:59:59','2018-07-20 11:59:59','LINKETH','4h','0.000475000000000','0.000472210000000','1.272648056128319','1.265172923335481','2679.2590655333024','2679.259065533302419','test','test','0.6'),('2018-07-20 19:59:59','2018-07-20 23:59:59','LINKETH','4h','0.000486540000000','0.000481674600000','1.270986915507688','1.258277046352611','2612.2968625553667','2612.296862555366715','test','test','1.0'),('2018-07-25 03:59:59','2018-07-25 07:59:59','LINKETH','4h','0.000501930000000','0.000496910700000','1.268162500139893','1.255480875138494','2526.5724306972943','2526.572430697294294','test','test','1.0'),('2018-07-25 15:59:59','2018-08-04 15:59:59','LINKETH','4h','0.000498820000000','0.000627750000000','1.265344361250693','1.592397904605113','2536.6752761531084','2536.675276153108371','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKETH','4h','0.000630040000000','0.000623739600000','1.338022926440565','1.324642697176159','2123.711076186535','2123.711076186535138','test','test','1.0'),('2018-08-09 03:59:59','2018-08-29 19:59:59','LINKETH','4h','0.000685000000000','0.001090000000000','1.335049542159585','2.124385402852478','1948.9774338096138','1948.977433809613785','test','test','0.0'),('2018-08-31 07:59:59','2018-08-31 11:59:59','LINKETH','4h','0.001132470000000','0.001121145300000','1.510457511202451','1.495352936090426','1333.7726484608427','1333.772648460842674','test','test','1.0'),('2018-08-31 23:59:59','2018-09-01 03:59:59','LINKETH','4h','0.001158760000000','0.001147172400000','1.507100938955334','1.492029929565781','1300.6152602396817','1300.615260239681675','test','test','1.0'),('2018-09-05 19:59:59','2018-09-14 03:59:59','LINKETH','4h','0.001129500000000','0.001231530000000','1.503751825757655','1.639588743670053','1331.3429178907968','1331.342917890796798','test','test','0.0'),('2018-09-16 15:59:59','2018-09-16 19:59:59','LINKETH','4h','0.001263740000000','0.001251102600000','1.533937807515966','1.518598429440806','1213.8080677322598','1213.808067732259815','test','test','1.0'),('2018-09-17 19:59:59','2018-09-22 03:59:59','LINKETH','4h','0.001348770000000','0.001420980000000','1.530529056832597','1.612470012810178','1134.7591189250925','1134.759118925092480','test','test','0.0'),('2018-09-24 23:59:59','2018-09-28 19:59:59','LINKETH','4h','0.001470130000000','0.001509950000000','1.548738158160949','1.590687341878014','1053.4702088665279','1053.470208866527855','test','test','0.0'),('2018-10-04 23:59:59','2018-10-05 03:59:59','LINKETH','4h','0.001446960000000','0.001456510000000','1.558060198986963','1.568343465214313','1076.7818039109325','1076.781803910932467','test','test','0.0'),('2018-10-05 15:59:59','2018-10-06 15:59:59','LINKETH','4h','0.001535680000000','0.001520323200000','1.560345369259707','1.544741915567110','1016.0615292637186','1016.061529263718626','test','test','1.0'),('2018-10-09 19:59:59','2018-10-15 07:59:59','LINKETH','4h','0.001489320000000','0.001574720000000','1.556877935105797','1.646151815573416','1045.361597981493','1045.361597981493105','test','test','0.2'),('2018-10-15 15:59:59','2018-10-16 07:59:59','LINKETH','4h','0.001640010000000','0.001623609900000','1.576716575209712','1.560949409457615','961.406683623705','961.406683623705021','test','test','1.0'),('2018-10-16 11:59:59','2018-11-04 19:59:59','LINKETH','4h','0.001689650000000','0.002363900000000','1.573212760598135','2.200998813232285','931.0879534803865','931.087953480386545','test','test','0.0'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LINKETH','4h','0.002407460000000','0.002383385400000','1.712720772294613','1.695593564571667','711.4223174194433','711.422317419443289','test','test','1.0'),('2018-11-08 15:59:59','2018-11-08 23:59:59','LINKETH','4h','0.002398420000000','0.002374435800000','1.708914726133958','1.691825578872618','712.5168761659586','712.516876165958593','test','test','1.0'),('2018-11-10 03:59:59','2018-11-19 19:59:59','LINKETH','4h','0.002416070000000','0.002755250000000','1.705117137853660','1.944490016461152','705.7399569770993','705.739956977099268','test','test','0.1'),('2018-11-22 15:59:59','2018-11-22 23:59:59','LINKETH','4h','0.002800010000000','0.002772009900000','1.758311110877548','1.740727999768773','627.9660111490844','627.966011149084352','test','test','1.0'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKETH','4h','0.002893880000000','0.002864941200000','1.754403752853375','1.736859715324841','606.2461998608703','606.246199860870320','test','test','1.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKETH','4h','0.003130000000000','0.003098700000000','1.750505077847034','1.733000027068563','559.2667980341963','559.266798034196313','test','test','1.0'),('2018-11-30 03:59:59','2018-11-30 07:59:59','LINKETH','4h','0.003175000000000','0.003143250000000','1.746615066562930','1.729148915897301','550.1149815946236','550.114981594623600','test','test','1.0'),('2018-12-08 19:59:59','2018-12-08 23:59:59','LINKETH','4h','0.002741280000000','0.002713867200000','1.742733699748346','1.725306362750862','635.7372102624853','635.737210262485291','test','test','1.0'),('2018-12-12 07:59:59','2018-12-12 15:59:59','LINKETH','4h','0.002601070000000','0.002575059300000','1.738860958193349','1.721472348611415','668.5175555418921','668.517555541892079','test','test','1.0'),('2018-12-18 11:59:59','2018-12-22 03:59:59','LINKETH','4h','0.002571230000000','0.002650300000000','1.734996822730697','1.788351131280814','674.7730940953151','674.773094095315059','test','test','0.0'),('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.746853335741834','3.078701978567738','755.543061673335','755.543061673335046','test','test','0.0'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','2.042819700814257','2.087074589979945','507.8596415617149','507.859641561714909','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 03:59:59','LINKETH','4h','0.004291500000000','0.004248585000000','2.052654120628855','2.032127579422566','478.30691381308515','478.306913813085146','test','test','1.0'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','2.048092667027457','2.069856100526833','525.9408772203067','525.940877220306675','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003930240600000','2.052928985582875','2.032399695727046','517.1183911048718','517.118391104871762','test','test','1.0'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003906619200000','2.048366921170468','2.027883251958763','519.089050695999','519.089050695999049','test','test','1.0'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.004007708100000','2.043814994678978','2.023376844732188','504.87131154391903','504.871311543919035','test','test','1.0'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003939853500000','2.039273183579691','2.018880451743895','512.425259402131','512.425259402131019','test','test','1.0'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003314807100000','2.034741465393959','2.014394050740019','607.6957089720302','607.695708972030161','test','test','1.0'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKETH','4h','0.003429610000000','0.003395313900000','2.030219817693083','2.009917619516152','591.968129814493','591.968129814492954','test','test','1.0'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','2.025708218098210','2.049047679500779','633.1921161847366','633.192116184736619','test','test','0.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003230000000000','0.003198670000000','2.030894765076558','2.011195714615305','628.759989187789','628.759989187788960','test','test','1.0'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','2.026517198307391','2.044640880980202','629.2945372503775','629.294537250377516','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003231429300000','2.030544683345794','2.010239236512336','622.0898091480249','622.089809148024870','test','test','1.0'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003242121300000','2.026032361827247','2.005772038208975','618.6603931842324','618.660393184232362','test','test','1.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','LINKETH','4h','0.003401970000000','0.003367950300000','2.021530067689853','2.001314767012955','594.2233669579254','594.223366957925350','test','test','1.0'),('2019-03-08 03:59:59','2019-03-08 07:59:59','LINKETH','4h','0.003609580000000','0.003573484200000','2.017037778650542','1.996867400864037','558.8012396596121','558.801239659612065','test','test','1.0'),('2019-03-08 15:59:59','2019-03-08 19:59:59','LINKETH','4h','0.003562430000000','0.003526805700000','2.012555472475764','1.992429917751007','564.9389524778771','564.938952477877137','test','test','1.0'),('2019-03-10 15:59:59','2019-03-10 19:59:59','LINKETH','4h','0.003902250000000','0.003863227500000','2.008083126981373','1.988002295711559','514.5962270437244','514.596227043724411','test','test','1.0'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKETH','4h','0.003700000000000','0.003663000000000','2.003620720032525','1.983584512832200','541.5191135223041','541.519113522304110','test','test','1.0'),('2019-03-12 01:59:59','2019-03-15 19:59:59','LINKETH','4h','0.003540000000000','0.003569070000000','1.999168229543565','2.015585127970918','564.7367880066566','564.736788006656639','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:17:48
