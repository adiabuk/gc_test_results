-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-11 19:59:59','2018-01-11 23:59:59','EOSETH','4h','0.010079000000000','0.009978210000000','1.297777777777778','1.284800000000000','128.76056928046214','128.760569280462136','test','test','1.0'),('2018-01-12 07:59:59','2018-01-14 15:59:59','EOSETH','4h','0.010800000000000','0.010692000000000','1.294893827160494','1.281944888888889','119.8975765889346','119.897576588934598','test','test','1.0'),('2018-01-16 15:59:59','2018-01-16 19:59:59','EOSETH','4h','0.010560000000000','0.010454400000000','1.292016285322359','1.279096122469135','122.3500270191628','122.350027019162795','test','test','1.0'),('2018-01-18 03:59:59','2018-01-18 19:59:59','EOSETH','4h','0.010295000000000','0.010225000000000','1.289145138021643','1.280379702406149','125.22050879277734','125.220508792777338','test','test','0.7'),('2018-01-19 15:59:59','2018-01-28 07:59:59','EOSETH','4h','0.010424000000000','0.012165000000000','1.287197263440422','1.502182915363846','123.48400455107655','123.484004551076552','test','test','0.0'),('2018-02-28 03:59:59','2018-02-28 07:59:59','EOSETH','4h','0.009848000000000','0.009958000000000','1.334971852756738','1.349883195547481','135.55766173403111','135.557661734031115','test','test','0.0'),('2018-03-01 23:59:59','2018-03-02 03:59:59','EOSETH','4h','0.009811000000000','0.009712890000000','1.338285484488015','1.324902629643135','136.4066338281536','136.406633828153588','test','test','1.0'),('2018-03-19 03:59:59','2018-03-19 07:59:59','EOSETH','4h','0.008596000000000','0.008617000000000','1.335311516744708','1.338573678430567','155.34103265992417','155.341032659924167','test','test','0.0'),('2018-03-19 11:59:59','2018-04-09 03:59:59','EOSETH','4h','0.008896000000000','0.014617000000000','1.336036441563788','2.195238833895896','150.18395251391502','150.183952513915017','test','test','0.0'),('2018-04-10 11:59:59','2018-04-10 15:59:59','EOSETH','4h','0.015077000000000','0.014926230000000','1.526970306526478','1.511700603461213','101.2781260546845','101.278126054684506','test','test','1.0'),('2018-04-11 07:59:59','2018-04-15 03:59:59','EOSETH','4h','0.015150000000000','0.015906000000000','1.523577039178642','1.599605041925774','100.56614119991035','100.566141199910348','test','test','0.0'),('2018-04-17 03:59:59','2018-04-17 07:59:59','EOSETH','4h','0.017344000000000','0.017170560000000','1.540472150900227','1.525067429391225','88.81873563769757','88.818735637697571','test','test','1.0'),('2018-04-17 11:59:59','2018-04-19 19:59:59','EOSETH','4h','0.016958000000000','0.016788420000000','1.537048879453782','1.521678390659244','90.63857055394395','90.638570553943950','test','test','1.0'),('2018-04-20 03:59:59','2018-05-03 07:59:59','EOSETH','4h','0.016963000000000','0.024492000000000','1.533633215277218','2.214333827068893','90.41049432749028','90.410494327490284','test','test','0.0'),('2018-05-07 11:59:59','2018-05-07 19:59:59','EOSETH','4h','0.024099000000000','0.023858010000000','1.684900017897590','1.668051017718614','69.91576488226026','69.915764882260262','test','test','1.0'),('2018-05-08 03:59:59','2018-05-09 19:59:59','EOSETH','4h','0.023940000000000','0.023700600000000','1.681155795635595','1.664344237679239','70.22371744509589','70.223717445095886','test','test','1.0'),('2018-05-10 15:59:59','2018-05-10 19:59:59','EOSETH','4h','0.024220000000000','0.023977800000000','1.677419893867516','1.660645694928841','69.25763393342346','69.257633933423463','test','test','1.0'),('2018-05-10 23:59:59','2018-05-11 07:59:59','EOSETH','4h','0.023962000000000','0.023722380000000','1.673692294103366','1.656955371162332','69.84777122541384','69.847771225413837','test','test','1.0'),('2018-05-24 15:59:59','2018-05-24 19:59:59','EOSETH','4h','0.020631000000000','0.020424690000000','1.669972977894248','1.653273248115306','80.9448392174033','80.944839217403299','test','test','1.0'),('2018-05-24 23:59:59','2018-05-25 03:59:59','EOSETH','4h','0.021193000000000','0.020981070000000','1.666261926832260','1.649599307563937','78.62322119720002','78.623221197200024','test','test','1.0'),('2018-05-25 23:59:59','2018-05-26 03:59:59','EOSETH','4h','0.020730000000000','0.020522700000000','1.662559122550411','1.645933531324907','80.20063302220989','80.200633022209885','test','test','1.0'),('2018-05-27 23:59:59','2018-05-29 07:59:59','EOSETH','4h','0.021745000000000','0.021527550000000','1.658864546722521','1.642275901255296','76.2871716129005','76.287171612900494','test','test','1.0'),('2018-05-30 03:59:59','2018-05-31 23:59:59','EOSETH','4h','0.021447000000000','0.021232530000000','1.655178181063138','1.638626399252507','77.17527771078183','77.175277710781828','test','test','1.0'),('2018-06-01 23:59:59','2018-06-10 19:59:59','EOSETH','4h','0.021072000000000','0.023009000000000','1.651500007327442','1.803310728388246','78.37414613361057','78.374146133610566','test','test','0.0'),('2018-07-02 15:59:59','2018-07-06 07:59:59','EOSETH','4h','0.018815000000000','0.018626850000000','1.685235723118732','1.668383365887544','89.5687336231056','89.568733623105601','test','test','1.0'),('2018-07-16 23:59:59','2018-07-17 03:59:59','EOSETH','4h','0.016891000000000','0.016862000000000','1.681490754845134','1.678603819087008','99.54950890090193','99.549508900901927','test','test','0.2'),('2018-07-17 15:59:59','2018-07-21 03:59:59','EOSETH','4h','0.017077000000000','0.017092000000000','1.680849213565551','1.682325628521544','98.42766373283078','98.427663732830780','test','test','0.0'),('2018-07-22 11:59:59','2018-07-22 23:59:59','EOSETH','4h','0.017527000000000','0.017351730000000','1.681177305777994','1.664365532720214','95.91928486209811','95.919284862098110','test','test','1.0'),('2018-07-23 03:59:59','2018-07-23 19:59:59','EOSETH','4h','0.017408000000000','0.017470000000000','1.677441356209598','1.683415699275142','96.360372024908','96.360372024908003','test','test','0.2'),('2018-07-24 15:59:59','2018-07-27 03:59:59','EOSETH','4h','0.017750000000000','0.017617000000000','1.678768988001941','1.666190042908744','94.57853453532064','94.578534535320642','test','test','0.7'),('2018-07-30 11:59:59','2018-07-30 15:59:59','EOSETH','4h','0.017677000000000','0.017500230000000','1.675973666870120','1.659213930201419','94.81097849579227','94.810978495792270','test','test','1.0'),('2018-08-07 15:59:59','2018-08-07 23:59:59','EOSETH','4h','0.017403000000000','0.017355000000000','1.672249280943742','1.667636974704283','96.08971332205607','96.089713322056070','test','test','0.3'),('2018-08-15 03:59:59','2018-08-15 07:59:59','EOSETH','4h','0.016567000000000','0.016491000000000','1.671224324001640','1.663557694640614','100.87670211876862','100.876702118768620','test','test','0.5'),('2018-08-17 15:59:59','2018-08-22 23:59:59','EOSETH','4h','0.016541000000000','0.017455000000000','1.669520628588078','1.761772720633873','100.932267008529','100.932267008528996','test','test','0.0'),('2018-08-23 07:59:59','2018-09-14 07:59:59','EOSETH','4h','0.017404000000000','0.025149000000000','1.690021093487144','2.442101843260641','97.10532598753989','97.105325987539885','test','test','0.0'),('2018-09-17 19:59:59','2018-09-17 23:59:59','EOSETH','4h','0.024909000000000','0.024741000000000','1.857150148992365','1.844624506653021','74.55739487704706','74.557394877047059','test','test','0.7'),('2018-09-18 11:59:59','2018-09-18 15:59:59','EOSETH','4h','0.024630000000000','0.024383700000000','1.854366672916956','1.835823006187786','75.28894327718051','75.288943277180508','test','test','1.0'),('2018-09-19 19:59:59','2018-09-21 19:59:59','EOSETH','4h','0.025091000000000','0.024840090000000','1.850245858088251','1.831743399507368','73.74141557085215','73.741415570852155','test','test','1.0'),('2018-09-25 11:59:59','2018-09-25 15:59:59','EOSETH','4h','0.024872000000000','0.024623280000000','1.846134200625833','1.827672858619575','74.22540208370187','74.225402083701866','test','test','1.0'),('2018-09-25 19:59:59','2018-09-25 23:59:59','EOSETH','4h','0.025690000000000','0.025433100000000','1.842031680179997','1.823611363378197','71.70228416426615','71.702284164266146','test','test','1.0'),('2018-09-26 03:59:59','2018-09-29 11:59:59','EOSETH','4h','0.025288000000000','0.025035120000000','1.837938276446265','1.819558893681802','72.68025452571435','72.680254525714346','test','test','1.0'),('2018-10-03 23:59:59','2018-10-07 19:59:59','EOSETH','4h','0.025460000000000','0.025340000000000','1.833853969165272','1.825210509766221','72.0288283254231','72.028828325423106','test','test','0.9'),('2018-10-07 23:59:59','2018-10-14 23:59:59','EOSETH','4h','0.025507000000000','0.026467000000000','1.831933200409928','1.900881170472794','71.82080214881907','71.820802148819070','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','EOSETH','4h','0.026383000000000','0.026119170000000','1.847254971535009','1.828782421819659','70.01686584296742','70.016865842967420','test','test','1.0'),('2018-10-17 11:59:59','2018-10-26 11:59:59','EOSETH','4h','0.025990000000000','0.026482000000000','1.843149960487154','1.878041448773405','70.9176591183976','70.917659118397594','test','test','0.0'),('2018-10-31 15:59:59','2018-10-31 19:59:59','EOSETH','4h','0.026463000000000','0.026508000000000','1.850903624550765','1.854051062978184','69.94307616486282','69.943076164862816','test','test','0.0'),('2018-11-01 23:59:59','2018-11-03 23:59:59','EOSETH','4h','0.026416000000000','0.026584000000000','1.851603055312413','1.863378847002771','70.09399815689028','70.093998156890279','test','test','0.0'),('2018-11-04 07:59:59','2018-11-04 19:59:59','EOSETH','4h','0.026824000000000','0.026555760000000','1.854219897910271','1.835677698931168','69.12540627461493','69.125406274614932','test','test','1.0'),('2018-11-06 07:59:59','2018-11-06 11:59:59','EOSETH','4h','0.026514000000000','0.026543000000000','1.850099409248248','1.852122977282803','69.77820808811374','69.778208088113743','test','test','0.0'),('2018-11-19 03:59:59','2018-11-27 11:59:59','EOSETH','4h','0.026028000000000','0.028041000000000','1.850549091033705','1.993670165271097','71.09839753472049','71.098397534720490','test','test','0.0'),('2018-12-15 23:59:59','2018-12-16 03:59:59','EOSETH','4h','0.022515000000000','0.022289850000000','1.882353774197570','1.863530236455594','83.60443145447788','83.604431454477876','test','test','1.0'),('2018-12-17 15:59:59','2018-12-19 19:59:59','EOSETH','4h','0.024741000000000','0.024493590000000','1.878170765810464','1.859389058152359','75.91329234107207','75.913292341072065','test','test','1.0'),('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.019131750000000','1.873997052997551','1.855257082467576','96.97268062083062','96.972680620830616','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:14:02
