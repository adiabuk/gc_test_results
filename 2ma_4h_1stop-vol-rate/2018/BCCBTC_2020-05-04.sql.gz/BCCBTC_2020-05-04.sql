-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 11:59:59','2018-02-09 15:59:59','BCCBTC','4h','0.158400000000000','0.156816000000000','0.033333333333333','0.033000000000000','0.21043771043771042','0.210437710437710','test','test','1.0'),('2018-02-10 03:59:59','2018-02-10 07:59:59','BCCBTC','4h','0.151243000000000','0.149730570000000','0.033259259259259','0.032926666666666','0.21990610645953423','0.219906106459534','test','test','1.0'),('2018-02-11 04:00:00','2018-02-12 07:59:59','BCCBTC','4h','0.149063000000000','0.147572370000000','0.033185349794239','0.032853496296297','0.22262633781849736','0.222626337818497','test','test','1.0'),('2018-02-13 11:59:59','2018-02-13 19:59:59','BCCBTC','4h','0.142706000000000','0.143545000000000','0.033111604572474','0.033306274987427','0.23202671627313337','0.232026716273133','test','test','0.0'),('2018-02-14 03:59:59','2018-02-14 07:59:59','BCCBTC','4h','0.145434000000000','0.143979660000000','0.033154864664686','0.032823316018039','0.22797189559996667','0.227971895599967','test','test','1.0'),('2018-02-14 15:59:59','2018-02-14 19:59:59','BCCBTC','4h','0.147018000000000','0.145547820000000','0.033081187187653','0.032750375315776','0.22501453691148623','0.225014536911486','test','test','1.0'),('2018-02-16 03:59:59','2018-02-16 07:59:59','BCCBTC','4h','0.151163000000000','0.149651370000000','0.033007673438347','0.032677596703964','0.21835815271162182','0.218358152711622','test','test','1.0'),('2018-02-16 11:59:59','2018-02-16 15:59:59','BCCBTC','4h','0.149768000000000','0.148270320000000','0.032934323052928','0.032604979822399','0.2199022691958792','0.219902269195879','test','test','1.0'),('2018-02-16 23:59:59','2018-02-17 03:59:59','BCCBTC','4h','0.150449000000000','0.148944510000000','0.032861135668366','0.032532524311682','0.21842043262744482','0.218420432627445','test','test','1.0'),('2018-03-11 11:59:59','2018-03-11 15:59:59','BCCBTC','4h','0.120888000000000','0.119679120000000','0.032788110922437','0.032460229813213','0.2712271765802782','0.271227176580278','test','test','1.0'),('2018-03-11 19:59:59','2018-03-12 03:59:59','BCCBTC','4h','0.119147000000000','0.117955530000000','0.032715248453720','0.032388095969183','0.27457886857176617','0.274578868571766','test','test','1.0'),('2018-03-13 15:59:59','2018-03-13 23:59:59','BCCBTC','4h','0.116887000000000','0.115718130000000','0.032642547901601','0.032316122422585','0.279265854214762','0.279265854214762','test','test','1.0'),('2018-03-14 11:59:59','2018-03-14 15:59:59','BCCBTC','4h','0.116661000000000','0.115494390000000','0.032570008906264','0.032244308817201','0.27918506532829307','0.279185065328293','test','test','1.0'),('2018-03-14 19:59:59','2018-03-14 23:59:59','BCCBTC','4h','0.115755000000000','0.115179000000000','0.032497631108694','0.032335922020373','0.2807449450018958','0.280744945001896','test','test','0.5'),('2018-03-16 15:59:59','2018-03-16 23:59:59','BCCBTC','4h','0.117816000000000','0.117788000000000','0.032461695755734','0.032453980950604','0.2755287546320892','0.275528754632089','test','test','0.0'),('2018-03-17 11:59:59','2018-03-17 19:59:59','BCCBTC','4h','0.121016000000000','0.119805840000000','0.032459981354594','0.032135381541048','0.268228840439233','0.268228840439233','test','test','1.0'),('2018-03-20 03:59:59','2018-03-20 07:59:59','BCCBTC','4h','0.117147000000000','0.115975530000000','0.032387848062695','0.032063969582068','0.27647185214043135','0.276471852140431','test','test','1.0'),('2018-03-20 15:59:59','2018-03-21 07:59:59','BCCBTC','4h','0.119299000000000','0.118106010000000','0.032315875067000','0.031992716316330','0.2708813574883295','0.270881357488329','test','test','1.0'),('2018-03-23 11:59:59','2018-03-23 15:59:59','BCCBTC','4h','0.116654000000000','0.116618000000000','0.032244062011296','0.032234111334659','0.2764076843596943','0.276407684359694','test','test','0.0'),('2018-04-12 03:59:59','2018-04-12 07:59:59','BCCBTC','4h','0.097410000000000','0.096690000000000','0.032241850749821','0.032003537100916','0.33099117903522113','0.330991179035221','test','test','0.7'),('2018-04-17 11:59:59','2018-05-01 03:59:59','BCCBTC','4h','0.096478000000000','0.142845000000000','0.032188892161175','0.047658764700378','0.3336397122781912','0.333639712278191','test','test','0.5'),('2018-05-02 11:59:59','2018-05-02 23:59:59','BCCBTC','4h','0.159698000000000','0.158101020000000','0.035626641614332','0.035270375198189','0.22308758791175567','0.223087587911756','test','test','1.0'),('2018-05-03 03:59:59','2018-05-03 11:59:59','BCCBTC','4h','0.161996000000000','0.160376040000000','0.035547471299633','0.035191996586637','0.2194342533126319','0.219434253312632','test','test','1.0'),('2018-05-05 07:59:59','2018-05-11 07:59:59','BCCBTC','4h','0.164350000000000','0.162706500000000','0.035468476918967','0.035113792149777','0.2158106292605253','0.215810629260525','test','test','1.0'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BCCBTC','4h','0.169999000000000','0.168299010000000','0.035389658081370','0.035035761500556','0.2081756838650201','0.208175683865020','test','test','1.0'),('2018-05-14 19:59:59','2018-05-14 23:59:59','BCCBTC','4h','0.166330000000000','0.164666700000000','0.035311014396744','0.034957904252777','0.2122949221231541','0.212294922123154','test','test','1.0'),('2018-06-02 15:59:59','2018-06-10 03:59:59','BCCBTC','4h','0.140000000000000','0.141645000000000','0.035232545475863','0.035646527885204','0.25166103911330473','0.251661039113305','test','test','0.0'),('2018-07-03 03:59:59','2018-07-03 11:59:59','BCCBTC','4h','0.121932000000000','0.120712680000000','0.035324541566827','0.034971296151159','0.28970689865521215','0.289706898655212','test','test','1.0'),('2018-07-15 11:59:59','2018-07-18 19:59:59','BCCBTC','4h','0.114254000000000','0.114405000000000','0.035246042585568','0.035292624345773','0.308488478176412','0.308488478176412','test','test','0.6'),('2018-08-05 23:59:59','2018-08-06 03:59:59','BCCBTC','4h','0.100893000000000','0.100361000000000','0.035256394087836','0.035070490193069','0.34944341121619493','0.349443411216195','test','test','0.5'),('2018-08-07 07:59:59','2018-08-07 11:59:59','BCCBTC','4h','0.100692000000000','0.100183000000000','0.035215082111221','0.035037069192671','0.3497306847735735','0.349730684773573','test','test','0.5'),('2018-08-17 23:59:59','2018-08-18 07:59:59','BCCBTC','4h','0.091687000000000','0.090770130000000','0.035175523684876','0.034823768448027','0.38364788557675805','0.383647885576758','test','test','1.0'),('2018-09-01 15:59:59','2018-09-05 11:59:59','BCCBTC','4h','0.085559000000000','0.084703410000000','0.035097355854465','0.034746382295920','0.4102123196211426','0.410212319621143','test','test','1.0'),('2018-09-21 07:59:59','2018-09-21 15:59:59','BCCBTC','4h','0.072141000000000','0.071419590000000','0.035019361730344','0.034669168113041','0.4854293914742549','0.485429391474255','test','test','1.0'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BCCBTC','4h','0.074322000000000','0.073578780000000','0.034941540926499','0.034592125517234','0.47013725312154026','0.470137253121540','test','test','1.0'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BCCBTC','4h','0.074079000000000','0.073338210000000','0.034863893057774','0.034515254127196','0.4706312593011994','0.470631259301199','test','test','1.0'),('2018-09-26 15:59:59','2018-09-26 19:59:59','BCCBTC','4h','0.080390000000000','0.079586100000000','0.034786417739867','0.034438553562468','0.4327207082954015','0.432720708295401','test','test','1.0'),('2018-09-26 23:59:59','2018-10-04 19:59:59','BCCBTC','4h','0.079646000000000','0.078849540000000','0.034709114589334','0.034362023443441','0.43579231335326596','0.435792313353266','test','test','1.0'),('2018-10-07 23:59:59','2018-10-09 11:59:59','BCCBTC','4h','0.078806000000000','0.078645000000000','0.034631983223580','0.034561230371018','0.4394587115648583','0.439458711564858','test','test','0.2'),('2018-11-02 15:59:59','2018-11-09 23:59:59','BCCBTC','4h','0.071251000000000','0.085150000000000','0.034616260367455','0.041368887037218','0.4858354320283973','0.485835432028397','test','test','0.0'),('2018-11-10 19:59:59','2018-11-11 11:59:59','BCCBTC','4h','0.086532000000000','0.085666680000000','0.036116844071847','0.035755675631129','0.4173813626386436','0.417381362638644','test','test','1.0'),('2018-11-13 11:59:59','2018-11-13 15:59:59','BCCBTC','4h','0.085258000000000','0.084405420000000','0.036036584418354','0.035676218574170','0.42267686807518606','0.422676868075186','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 23:32:19
