-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 19:59:59','2018-04-29 03:59:59','RCNETH','4h','0.000226270000000','0.000224007300000','1.297777777777778','1.284800000000000','5735.527368974136','5735.527368974136152','test','test','1.0'),('2018-04-29 23:59:59','2018-04-30 11:59:59','RCNETH','4h','0.000225190000000','0.000222938100000','1.294893827160494','1.281944888888889','5750.227928240569','5750.227928240568872','test','test','1.0'),('2018-04-30 19:59:59','2018-05-01 03:59:59','RCNETH','4h','0.000230180000000','0.000227878200000','1.292016285322359','1.279096122469135','5613.069273274651','5613.069273274651096','test','test','1.0'),('2018-05-02 11:59:59','2018-05-02 15:59:59','RCNETH','4h','0.000223560000000','0.000221324400000','1.289145138021643','1.276253686641426','5766.439157370025','5766.439157370024986','test','test','1.0'),('2018-06-01 19:59:59','2018-06-01 23:59:59','RCNETH','4h','0.000161440000000','0.000159825600000','1.286280371048261','1.273417567337779','7967.54441927813','7967.544419278129681','test','test','1.0'),('2018-07-01 15:59:59','2018-07-01 23:59:59','RCNETH','4h','0.000103950000000','0.000102910500000','1.283421970223710','1.270587750521473','12346.531700083788','12346.531700083787655','test','test','1.0'),('2018-07-02 07:59:59','2018-07-02 11:59:59','RCNETH','4h','0.000102520000000','0.000106650000000','1.280569921400990','1.332157453349742','12490.927832627687','12490.927832627687167','test','test','0.0'),('2018-07-02 15:59:59','2018-07-03 11:59:59','RCNETH','4h','0.000111240000000','0.000110127600000','1.292033817389602','1.279113479215706','11614.831152369668','11614.831152369668416','test','test','1.0'),('2018-07-06 03:59:59','2018-07-06 11:59:59','RCNETH','4h','0.000110240000000','0.000109137600000','1.289162631128736','1.276271004817449','11694.145783098116','11694.145783098116226','test','test','1.0'),('2018-07-08 19:59:59','2018-07-08 23:59:59','RCNETH','4h','0.000108490000000','0.000107405100000','1.286297825281784','1.273434847028966','11856.372248887305','11856.372248887304522','test','test','1.0'),('2018-07-09 15:59:59','2018-07-09 23:59:59','RCNETH','4h','0.000110200000000','0.000109098000000','1.283439385670046','1.270604991813346','11646.455405354322','11646.455405354321556','test','test','1.0'),('2018-07-18 03:59:59','2018-07-19 19:59:59','RCNETH','4h','0.000105060000000','0.000104009400000','1.280587298146335','1.267781425164872','12189.104303696316','12189.104303696316492','test','test','1.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','RCNETH','4h','0.000104300000000','0.000103257000000','1.277741548594899','1.264964133108950','12250.638049807276','12250.638049807275820','test','test','1.0'),('2018-07-28 07:59:59','2018-07-28 15:59:59','RCNETH','4h','0.000100020000000','0.000099019800000','1.274902122931355','1.262153101702042','12746.471934926562','12746.471934926561516','test','test','1.0'),('2018-07-29 03:59:59','2018-07-29 07:59:59','RCNETH','4h','0.000106840000000','0.000105771600000','1.272069007102618','1.259348317031592','11906.299205378307','11906.299205378307306','test','test','1.0'),('2018-07-29 15:59:59','2018-07-29 23:59:59','RCNETH','4h','0.000104540000000','0.000103494600000','1.269242187086835','1.256549765215967','12141.2108961817','12141.210896181699354','test','test','1.0'),('2018-07-30 11:59:59','2018-07-30 15:59:59','RCNETH','4h','0.000108550000000','0.000107464500000','1.266421648893309','1.253757432404376','11666.712564655078','11666.712564655077585','test','test','1.0'),('2018-08-20 07:59:59','2018-08-20 11:59:59','RCNETH','4h','0.000072970000000','0.000072240300000','1.263607378562435','1.250971304776811','17316.806613162047','17316.806613162047142','test','test','1.0'),('2018-08-20 15:59:59','2018-08-20 19:59:59','RCNETH','4h','0.000074110000000','0.000073368900000','1.260799362165629','1.248191368543973','17012.54030718701','17012.540307187009603','test','test','1.0'),('2018-08-25 15:59:59','2018-08-25 19:59:59','RCNETH','4h','0.000072010000000','0.000071289900000','1.257997585805261','1.245417609947208','17469.76233585976','17469.762335859759332','test','test','1.0'),('2018-08-26 07:59:59','2018-08-29 07:59:59','RCNETH','4h','0.000076470000000','0.000075705300000','1.255202035614583','1.242650015258437','16414.30672962708','16414.306729627078312','test','test','1.0'),('2018-08-31 07:59:59','2018-09-02 15:59:59','RCNETH','4h','0.000074850000000','0.000074620000000','1.252412697757662','1.248564268626276','16732.300571244643','16732.300571244642924','test','test','0.3'),('2018-09-04 15:59:59','2018-09-05 11:59:59','RCNETH','4h','0.000079160000000','0.000078368400000','1.251557491284020','1.239041916371180','15810.478667054324','15810.478667054323523','test','test','1.0'),('2018-09-05 15:59:59','2018-09-14 03:59:59','RCNETH','4h','0.000080850000000','0.000093960000000','1.248776252414500','1.451267986108428','15445.59372188621','15445.593721886209096','test','test','0.0'),('2018-09-15 11:59:59','2018-09-15 15:59:59','RCNETH','4h','0.000101000000000','0.000099990000000','1.293774415457595','1.280836671303019','12809.647677797971','12809.647677797971483','test','test','1.0'),('2018-09-15 19:59:59','2018-09-21 23:59:59','RCNETH','4h','0.000104120000000','0.000114300000000','1.290899361201023','1.417112917645764','12398.188255868448','12398.188255868448323','test','test','1.0'),('2018-09-22 19:59:59','2018-09-24 11:59:59','RCNETH','4h','0.000120680000000','0.000119473200000','1.318946818188743','1.305757350006856','10929.290836830818','10929.290836830818080','test','test','1.0'),('2018-09-25 03:59:59','2018-09-25 07:59:59','RCNETH','4h','0.000124200000000','0.000122958000000','1.316015825259435','1.302855667006841','10595.940622056642','10595.940622056641587','test','test','1.0'),('2018-09-25 11:59:59','2018-09-25 23:59:59','RCNETH','4h','0.000125900000000','0.000124641000000','1.313091345647747','1.299960432191269','10429.637376074244','10429.637376074244457','test','test','1.0'),('2018-09-26 07:59:59','2018-09-26 23:59:59','RCNETH','4h','0.000127670000000','0.000126393300000','1.310173364879641','1.297071631230845','10262.186612983796','10262.186612983796294','test','test','1.0'),('2018-09-28 19:59:59','2018-09-29 11:59:59','RCNETH','4h','0.000129160000000','0.000127868400000','1.307261868513242','1.294189249828109','10121.25943413783','10121.259434137829885','test','test','1.0'),('2018-10-03 19:59:59','2018-10-03 23:59:59','RCNETH','4h','0.000125950000000','0.000124690500000','1.304356842138768','1.291313273717380','10356.148012217292','10356.148012217292489','test','test','1.0'),('2018-10-04 11:59:59','2018-10-08 03:59:59','RCNETH','4h','0.000124780000000','0.000127600000000','1.301458271378459','1.330870936270968','10430.023011527965','10430.023011527964627','test','test','0.0'),('2018-10-08 15:59:59','2018-10-08 19:59:59','RCNETH','4h','0.000129160000000','0.000127868400000','1.307994419132350','1.294914474941026','10126.93108650008','10126.931086500080710','test','test','1.0'),('2018-10-09 03:59:59','2018-10-11 07:59:59','RCNETH','4h','0.000130150000000','0.000131220000000','1.305087764867612','1.315817260898410','10027.566383923257','10027.566383923256581','test','test','0.3'),('2018-10-11 11:59:59','2018-10-11 15:59:59','RCNETH','4h','0.000136410000000','0.000135045900000','1.307472097318900','1.294397376345711','9584.869857920243','9584.869857920242794','test','test','1.0'),('2018-10-12 07:59:59','2018-10-12 11:59:59','RCNETH','4h','0.000135700000000','0.000134343000000','1.304566603769303','1.291520937731610','9613.607986509232','9613.607986509232433','test','test','1.0'),('2018-10-14 07:59:59','2018-10-14 11:59:59','RCNETH','4h','0.000136980000000','0.000135610200000','1.301667566872037','1.288650891203317','9502.610358242351','9502.610358242351140','test','test','1.0'),('2018-10-14 19:59:59','2018-10-15 03:59:59','RCNETH','4h','0.000140710000000','0.000139302900000','1.298774972278989','1.285787222556199','9230.154020886848','9230.154020886848230','test','test','1.0'),('2018-10-17 11:59:59','2018-10-18 19:59:59','RCNETH','4h','0.000135900000000','0.000134880000000','1.295888805673924','1.286162487927144','9535.605634098047','9535.605634098046721','test','test','0.8'),('2018-10-18 23:59:59','2018-10-20 03:59:59','RCNETH','4h','0.000138370000000','0.000136986300000','1.293727401730195','1.280790127712893','9349.7680258018','9349.768025801800832','test','test','1.0'),('2018-10-20 15:59:59','2018-10-26 11:59:59','RCNETH','4h','0.000142300000000','0.000143670000000','1.290852451948573','1.303280195161290','9071.345410741902','9071.345410741902015','test','test','0.5'),('2018-10-27 23:59:59','2018-10-28 23:59:59','RCNETH','4h','0.000168550000000','0.000166864500000','1.293614172662510','1.280678030935885','7674.958010456896','7674.958010456895863','test','test','1.0'),('2018-10-31 19:59:59','2018-11-03 19:59:59','RCNETH','4h','0.000166090000000','0.000164429100000','1.290739474501037','1.277832079756027','7771.3256336988225','7771.325633698822458','test','test','1.0'),('2018-11-06 03:59:59','2018-11-06 07:59:59','RCNETH','4h','0.000163210000000','0.000161577900000','1.287871164557702','1.274992452912125','7890.883919843773','7890.883919843772674','test','test','1.0'),('2018-11-06 11:59:59','2018-11-06 15:59:59','RCNETH','4h','0.000171790000000','0.000170072100000','1.285009228636463','1.272159136350098','7480.116587906529','7480.116587906529276','test','test','1.0'),('2018-11-07 03:59:59','2018-11-07 07:59:59','RCNETH','4h','0.000162030000000','0.000160409700000','1.282153652572826','1.269332116047098','7913.063337485811','7913.063337485810735','test','test','1.0'),('2018-11-27 11:59:59','2018-11-27 19:59:59','RCNETH','4h','0.000128720000000','0.000128040000000','1.279304422233775','1.272546132868339','9938.660831524048','9938.660831524048263','test','test','0.5'),('2018-11-28 03:59:59','2018-11-28 07:59:59','RCNETH','4h','0.000134010000000','0.000132669900000','1.277802580152567','1.265024554351041','9535.128573633068','9535.128573633068299','test','test','1.0'),('2018-11-28 15:59:59','2018-11-30 11:59:59','RCNETH','4h','0.000138700000000','0.000137313000000','1.274963018863339','1.262213388674706','9192.235175654934','9192.235175654934210','test','test','1.0'),('2018-12-03 11:59:59','2018-12-03 15:59:59','RCNETH','4h','0.000148340000000','0.000146856600000','1.272129767710310','1.259408470033207','8575.770309493797','8575.770309493796958','test','test','1.0'),('2018-12-04 03:59:59','2018-12-04 07:59:59','RCNETH','4h','0.000152000000000','0.000150480000000','1.269302812670954','1.256609784544245','8350.67639915101','8350.676399151010628','test','test','1.0'),('2018-12-04 19:59:59','2018-12-05 23:59:59','RCNETH','4h','0.000152040000000','0.000150519600000','1.266482139753907','1.253817318356368','8329.927254366663','8329.927254366662964','test','test','1.0'),('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.263667734998898','1.255099494569867','14772.828325916511','14772.828325916510948','test','test','0.7'),('2019-01-12 03:59:59','2019-01-12 07:59:59','RCNETH','4h','0.000086100000000','0.000085239000000','1.261763681570225','1.249146044754523','14654.63044797009','14654.630447970090245','test','test','1.0'),('2019-01-12 19:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000085960000000','0.000085100400000','1.258959762277847','1.246370164655068','14645.879039993562','14645.879039993562401','test','test','1.0'),('2019-01-13 11:59:59','2019-01-13 15:59:59','RCNETH','4h','0.000088320000000','0.000087436800000','1.256162073917229','1.243600453178057','14222.849568809208','14222.849568809207994','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000087740000000','0.000086862600000','1.253370602641857','1.240836896615438','14285.053597468172','14285.053597468171574','test','test','1.0'),('2019-01-14 23:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000086760000000','0.000100820000000','1.250585334635987','1.453250500668513','14414.307683678962','14414.307683678962348','test','test','0.6'),('2019-01-26 11:59:59','2019-01-27 07:59:59','RCNETH','4h','0.000103830000000','0.000102791700000','1.295622038198770','1.282665817816782','12478.301436952424','12478.301436952424410','test','test','1.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101811600000','1.292742878113884','1.279815449332745','12570.428608653092','12570.428608653091942','test','test','1.0'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.289870116162520','1.280500599580225','12492.688776392442','12492.688776392442378','test','test','0.7'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.287788001366454','1.281290332428839','12495.517187720301','12495.517187720301081','test','test','0.5'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000099227700000','1.286344074935873','1.273480634186514','12833.922727086432','12833.922727086432133','test','test','1.0'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.283485532547127','1.287101348515667','12913.628459071604','12913.628459071604084','test','test','0.0'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000101583900000','1.284289047206802','1.271446156734734','12516.217203067947','12516.217203067946684','test','test','1.0'),('2019-02-21 23:59:59','2019-02-23 19:59:59','RCNETH','4h','0.000108920000000','0.000107830800000','1.281435071546343','1.268620720830880','11764.919863627825','11764.919863627825180','test','test','1.0'),('2019-02-25 19:59:59','2019-02-26 23:59:59','RCNETH','4h','0.000142190000000','0.000140768100000','1.278587438054017','1.265801563673477','8992.105197651154','8992.105197651153503','test','test','1.0'),('2019-02-28 19:59:59','2019-03-01 07:59:59','RCNETH','4h','0.000164020000000','0.000162379800000','1.275746132636120','1.262988671309759','7777.9912976229725','7777.991297622972525','test','test','1.0'),('2019-03-04 03:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149450000000','0.000169370000000','1.272911141230262','1.442575844698357','8517.30439096863','8517.304390968629377','test','test','0.5'),('2019-03-14 03:59:59','2019-03-14 11:59:59','RCNETH','4h','0.000170940000000','0.000169230600000','1.310614408667616','1.297508264580940','7667.101957807512','7667.101957807512008','test','test','1.0'),('2019-03-14 15:59:59','2019-03-14 19:59:59','RCNETH','4h','0.000171780000000','0.000170062200000','1.307701932203911','1.294624912881872','7612.655327767554','7612.655327767553899','test','test','1.0'),('2019-03-14 23:59:59','2019-03-15 03:59:59','RCNETH','4h','0.000179620000000','0.000177823800000','1.304795927910124','1.291747968631023','7264.201803307672','7264.201803307671980','test','test','1.0'),('2019-03-15 15:59:59','2019-03-16 07:59:59','RCNETH','4h','0.000176760000000','0.000174992400000','1.301896381403657','1.288877417589620','7365.333680717679','7365.333680717679272','test','test','1.0'),('2019-03-18 07:59:59','2019-03-18 11:59:59','RCNETH','4h','0.000181490000000','0.000179675100000','1.299003278333871','1.286013245550532','7157.437204991301','7157.437204991300860','test','test','1.0'),('2019-03-18 15:59:59','2019-03-19 11:59:59','RCNETH','4h','0.000181430000000','0.000179615700000','1.296116604382018','1.283155438338198','7143.893536802172','7143.893536802172093','test','test','1.0'),('2019-03-24 15:59:59','2019-03-25 03:59:59','RCNETH','4h','0.000175890000000','0.000174131100000','1.293236345261169','1.280303981808557','7352.529110587123','7352.529110587122886','test','test','1.0'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000171675900000','1.290362486716144','1.277458861848982','7441.107702647737','7441.107702647736915','test','test','1.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','RCNETH','4h','0.000177820000000','0.000176041800000','1.287495014523441','1.274620064378207','7240.439852229453','7240.439852229453209','test','test','1.0'),('2019-03-28 07:59:59','2019-03-29 11:59:59','RCNETH','4h','0.000182860000000','0.000181031400000','1.284633914491167','1.271787575346255','7025.231950624343','7025.231950624342971','test','test','1.0'),('2019-03-29 19:59:59','2019-03-29 23:59:59','RCNETH','4h','0.000187130000000','0.000185258700000','1.281779172458965','1.268961380734376','6849.6722730666625','6849.672273066662456','test','test','1.0'),('2019-03-30 11:59:59','2019-03-31 11:59:59','RCNETH','4h','0.000233360000000','0.000231026400000','1.278930774297945','1.266141466554966','5480.5055463573235','5480.505546357323510','test','test','1.0'),('2019-04-13 07:59:59','2019-04-13 11:59:59','RCNETH','4h','0.000187440000000','0.000185565600000','1.276088705910616','1.263327818851510','6807.984986719035','6807.984986719035078','test','test','1.0'),('2019-04-13 15:59:59','2019-04-13 19:59:59','RCNETH','4h','0.000191950000000','0.000190030500000','1.273252953230815','1.260520423698507','6633.253207766683','6633.253207766682863','test','test','1.0'),('2019-04-14 07:59:59','2019-04-14 15:59:59','RCNETH','4h','0.000194680000000','0.000192733200000','1.270423502223635','1.257719267201398','6525.7011620281255','6525.701162028125509','test','test','1.0'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.267600338885360','1.266855329068747','6772.8165146685205','6772.816514668520540','test','test','0.3'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000186298200000','1.267434781148335','1.254760433336852','6735.225747413834','6735.225747413834142','test','test','1.0'),('2019-04-20 11:59:59','2019-04-20 15:59:59','RCNETH','4h','0.000193870000000','0.000191931300000','1.264618259412450','1.251972076818326','6523.021918875793','6523.021918875792835','test','test','1.0'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000185941800000','1.261807996613756','1.249189916647619','6718.17695992842','6718.176959928419819','test','test','1.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  0:14:26
