-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-07 23:59:59','2018-06-09 03:59:59','WAVESETH','4h','0.007544000000000','0.007468560000000','1.297777777777778','1.284800000000000','172.02780723459406','172.027807234594064','test','test','1.0'),('2018-06-09 11:59:59','2018-06-09 19:59:59','WAVESETH','4h','0.007555000000000','0.007479450000000','1.294893827160494','1.281944888888889','171.39560915426787','171.395609154267873','test','test','1.0'),('2018-06-13 03:59:59','2018-06-13 07:59:59','WAVESETH','4h','0.007534000000000','0.007458660000000','1.292016285322359','1.279096122469135','171.49141031621437','171.491410316214370','test','test','1.0'),('2018-06-13 11:59:59','2018-06-13 15:59:59','WAVESETH','4h','0.007408000000000','0.007333920000000','1.289145138021643','1.276253686641426','174.02067197916344','174.020671979163438','test','test','1.0'),('2018-06-18 19:59:59','2018-06-18 23:59:59','WAVESETH','4h','0.007108000000000','0.007038000000000','1.286280371048261','1.273613006673841','180.96234820600188','180.962348206001877','test','test','1.0'),('2018-06-30 11:59:59','2018-06-30 15:59:59','WAVESETH','4h','0.006394000000000','0.006330060000000','1.283465401187279','1.270630747175406','200.72965298518594','200.729652985185936','test','test','1.0'),('2018-07-02 15:59:59','2018-07-05 07:59:59','WAVESETH','4h','0.006500000000000','0.006435000000000','1.280613255851307','1.267807123292794','197.0174239771242','197.017423977124196','test','test','1.0'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESETH','4h','0.006405000000000','0.006340950000000','1.277767448616082','1.264989774129921','199.49530813678098','199.495308136780977','test','test','1.0'),('2018-07-18 03:59:59','2018-07-18 07:59:59','WAVESETH','4h','0.006263000000000','0.006246000000000','1.274927965396935','1.271467359391546','203.5650591404974','203.565059140497397','test','test','0.3'),('2018-07-18 15:59:59','2018-07-19 03:59:59','WAVESETH','4h','0.006382000000000','0.006318180000000','1.274158941840182','1.261417352421780','199.64884704484209','199.648847044842086','test','test','1.0'),('2018-07-20 11:59:59','2018-07-20 19:59:59','WAVESETH','4h','0.006569000000000','0.006503310000000','1.271327477524982','1.258614202749732','193.53440059750065','193.534400597500650','test','test','1.0'),('2018-08-10 11:59:59','2018-08-11 03:59:59','WAVESETH','4h','0.005050000000000','0.005474000000000','1.268502305352704','1.375006261287268','251.18857531736714','251.188575317367139','test','test','0.3'),('2018-08-11 07:59:59','2018-08-28 19:59:59','WAVESETH','4h','0.005511000000000','0.007710000000000','1.292169851115941','1.807771647995628','234.47103086843413','234.471030868434127','test','test','0.0'),('2018-08-29 11:59:59','2018-08-29 15:59:59','WAVESETH','4h','0.007810000000000','0.007731900000000','1.406748028200315','1.392680547918312','180.1213864533054','180.121386453305405','test','test','1.0'),('2018-08-31 15:59:59','2018-08-31 19:59:59','WAVESETH','4h','0.007679000000000','0.007602210000000','1.403621921470981','1.389585702256271','182.78707142479246','182.787071424792458','test','test','1.0'),('2018-09-03 19:59:59','2018-09-15 15:59:59','WAVESETH','4h','0.007723000000000','0.010380000000000','1.400502761645490','1.882327938091439','181.34180521112134','181.341805211121340','test','test','0.1'),('2018-09-19 03:59:59','2018-09-20 11:59:59','WAVESETH','4h','0.010698000000000','0.010591020000000','1.507575023077923','1.492499272847144','140.92120238155945','140.921202381559453','test','test','1.0'),('2018-09-26 19:59:59','2018-09-27 15:59:59','WAVESETH','4h','0.010327000000000','0.010223730000000','1.504224856359972','1.489182607796372','145.65942251960612','145.659422519606125','test','test','1.0'),('2018-10-05 19:59:59','2018-10-05 23:59:59','WAVESETH','4h','0.009863000000000','0.009764370000000','1.500882134456950','1.485873313112380','152.17298331713985','152.172983317139852','test','test','1.0'),('2018-10-06 03:59:59','2018-10-06 07:59:59','WAVESETH','4h','0.009701000000000','0.009675000000000','1.497546840824824','1.493533211522541','154.37035778010758','154.370357780107582','test','test','0.3'),('2018-10-11 23:59:59','2018-10-12 07:59:59','WAVESETH','4h','0.009728000000000','0.009630720000000','1.496654923202094','1.481688373970073','153.85021825679416','153.850218256794165','test','test','1.0'),('2018-10-14 23:59:59','2018-10-15 07:59:59','WAVESETH','4h','0.009629000000000','0.009532710000000','1.493329023372756','1.478395733139029','155.08661578281811','155.086615782818114','test','test','1.0'),('2018-10-16 15:59:59','2018-10-16 19:59:59','WAVESETH','4h','0.009594000000000','0.009570000000000','1.490010514431928','1.486283158548421','155.30649514612546','155.306495146125457','test','test','0.3'),('2018-10-17 07:59:59','2018-10-19 15:59:59','WAVESETH','4h','0.009749000000000','0.009651510000000','1.489182213124482','1.474290390993237','152.75230414652597','152.752304146525972','test','test','1.0'),('2018-10-20 19:59:59','2018-10-20 23:59:59','WAVESETH','4h','0.009663000000000','0.009590000000000','1.485872919317538','1.474647759107440','153.76931794655266','153.769317946552661','test','test','0.8'),('2018-10-23 11:59:59','2018-10-23 19:59:59','WAVESETH','4h','0.009829000000000','0.009730710000000','1.483378439270850','1.468544654878141','150.91855115178046','150.918551151780463','test','test','1.0'),('2018-10-24 19:59:59','2018-10-24 23:59:59','WAVESETH','4h','0.009695000000000','0.009692000000000','1.480082042739137','1.479624049327253','152.6644706280698','152.664470628069807','test','test','0.0'),('2018-11-18 15:59:59','2018-11-18 19:59:59','WAVESETH','4h','0.008547000000000','0.008618000000000','1.479980266425385','1.492274474792789','173.15786432963435','173.157864329634350','test','test','0.0'),('2018-11-19 03:59:59','2018-11-20 03:59:59','WAVESETH','4h','0.008747000000000','0.008659530000000','1.482712312729253','1.467885189601961','169.51095378178263','169.510953781782632','test','test','1.0'),('2018-11-24 11:59:59','2018-11-24 23:59:59','WAVESETH','4h','0.009025000000000','0.008934750000000','1.479417396478743','1.464623222513955','163.92436526080255','163.924365260802546','test','test','1.0'),('2018-11-25 03:59:59','2018-11-25 11:59:59','WAVESETH','4h','0.008990000000000','0.008900100000000','1.476129802264346','1.461368504241703','164.1968634331864','164.196863433186394','test','test','1.0'),('2018-11-25 15:59:59','2018-11-25 23:59:59','WAVESETH','4h','0.009199000000000','0.009107010000000','1.472849513814870','1.458121018676721','160.1097416909305','160.109741690930491','test','test','1.0'),('2018-11-26 19:59:59','2018-11-27 23:59:59','WAVESETH','4h','0.009165000000000','0.009073350000000','1.469576514895281','1.454880749746328','160.3465919143787','160.346591914378706','test','test','1.0'),('2018-11-28 15:59:59','2018-12-22 07:59:59','WAVESETH','4h','0.009458000000000','0.029594000000000','1.466310789306625','4.588073746959216','155.03391724536104','155.033917245361039','test','test','0.7'),('2018-12-22 15:59:59','2018-12-22 19:59:59','WAVESETH','4h','0.033614000000000','0.033277860000000','2.160035891007200','2.138435532097128','64.260007467341','64.260007467340998','test','test','1.0'),('2019-01-13 19:59:59','2019-01-14 15:59:59','WAVESETH','4h','0.022350000000000','0.022126500000000','2.155235811249406','2.133683453136912','96.43113249438059','96.431132494380591','test','test','1.0'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','2.150446398335519','2.147511395250441','101.2070029337123','101.207002933712303','test','test','0.1'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','2.149794175427723','2.143101735657041','101.40060258609138','101.400602586091381','test','test','0.3'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','2.148306966589794','2.139781536193727','101.49321900079343','101.493219000793431','test','test','0.4'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021396870000000','2.146412426501780','2.124948302236762','99.3111750567612','99.311175056761201','test','test','1.0'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','2.141642621109553','2.197865558351026','94.01828970145982','94.018289701459821','test','test','0.0'),('2019-01-27 11:59:59','2019-01-27 15:59:59','WAVESETH','4h','0.025120000000000','0.024868800000000','2.154136607163214','2.132595241091582','85.75384582656108','85.753845826561076','test','test','1.0'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.024754000000000','0.024506460000000','2.149349636925074','2.127856140555823','86.82837670376801','86.828376703768015','test','test','1.0'),('2019-01-28 07:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.025285000000000','0.025468000000000','2.144573304398573','2.160094637786152','84.81602944032325','84.816029440323248','test','test','0.9'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025969680000000','2.148022489595813','2.126542264699855','81.88557828590322','81.885578285903222','test','test','1.0'),('2019-02-04 11:59:59','2019-02-04 19:59:59','WAVESETH','4h','0.025830000000000','0.025571700000000','2.143249106285600','2.121816615222744','82.97518800950834','82.975188009508344','test','test','1.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019649520000000','2.138486330493854','2.117101467188915','107.74316457546625','107.743164575466253','test','test','1.0'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','2.133734138648312','2.121569055012224','107.65560739900667','107.655607399006669','test','test','0.6'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.020117790000000','2.131030786729182','2.109720478861890','104.8684014925044','104.868401492504404','test','test','1.0'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019861380000000','2.126295162758673','2.105032211131086','105.98620091509683','105.986200915096830','test','test','1.0'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','2.121570062396986','2.109288131504680','106.79939906352813','106.799399063528128','test','test','0.6'),('2019-03-10 11:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.020057000000000','0.019897000000000','2.118840744420919','2.101938190743533','105.6409604836675','105.640960483667499','test','test','0.8'),('2019-03-12 11:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020149000000000','0.019947510000000','2.115084621381500','2.093933775167685','104.97218826648962','104.972188266489624','test','test','1.0'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','2.110384433333985','2.090662189569145','104.35049611026429','104.350496110264288','test','test','0.9'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','2.106001712497354','2.110780524591616','103.88721944047722','103.887219440477224','test','test','0.0'),('2019-03-22 11:59:59','2019-03-22 15:59:59','WAVESETH','4h','0.020126000000000','0.020116000000000','2.107063670740523','2.106016734602820','104.69361377027343','104.693613770273430','test','test','0.0'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','2.106831018265478','2.094143024177790','103.99995153842818','103.999951538428178','test','test','0.6'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.020153430000000','2.104011464023769','2.082971349383531','103.35567441291789','103.355674412917892','test','test','1.0'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.013400640000000','2.099335882992606','2.078342524162680','155.09278095394546','155.092780953945464','test','test','1.0'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','2.094670692141511','2.573838679044298','193.05720664898715','193.057206648987147','test','test','0.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','2.201152467008797','2.199720756613976','204.53005640297312','204.530056402973116','test','test','0.1');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  3:43:16
