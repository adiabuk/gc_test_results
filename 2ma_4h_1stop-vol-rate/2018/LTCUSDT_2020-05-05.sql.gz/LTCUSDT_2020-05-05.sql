-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-03 11:59:59','2018-06-03 19:59:59','LTCUSDT','4h','126.930000000000007','125.660700000000006','222.222222222222200','219.999999999999972','1.7507462555914455','1.750746255591445','test','test','1.0'),('2018-06-07 03:59:59','2018-06-07 07:59:59','LTCUSDT','4h','122.230000000000004','122.159999999999997','221.728395061728406','221.601413243399662','1.8140259761247517','1.814025976124752','test','test','0.1'),('2018-07-02 15:59:59','2018-07-03 23:59:59','LTCUSDT','4h','85.569999999999993','85.090000000000003','221.700176879877546','220.456562471763277','2.590863350238139','2.590863350238139','test','test','0.6'),('2018-07-04 15:59:59','2018-07-04 23:59:59','LTCUSDT','4h','86.840000000000003','85.971600000000009','221.423818122518838','219.209579941293669','2.5497906278502858','2.549790627850286','test','test','1.0'),('2018-07-08 03:59:59','2018-07-08 07:59:59','LTCUSDT','4h','84.090000000000003','83.709999999999994','220.931765193357677','219.933381666499798','2.627325070678531','2.627325070678531','test','test','0.5'),('2018-07-08 15:59:59','2018-07-08 23:59:59','LTCUSDT','4h','84.519999999999996','83.674799999999991','220.709902187389275','218.502803165515360','2.611333438090266','2.611333438090266','test','test','1.0'),('2018-07-16 11:59:59','2018-07-17 11:59:59','LTCUSDT','4h','82.640000000000001','81.813599999999994','220.219435738083945','218.017241380703069','2.6648044014772982','2.664804401477298','test','test','1.0'),('2018-07-17 15:59:59','2018-07-20 07:59:59','LTCUSDT','4h','83.439999999999998','83.939999999999998','219.730059214221541','221.046754199925175','2.633389971407257','2.633389971407257','test','test','0.0'),('2018-07-22 15:59:59','2018-07-22 19:59:59','LTCUSDT','4h','83.250000000000000','83.370000000000005','220.022658099933437','220.339807877374767','2.6429148120112123','2.642914812011212','test','test','0.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','LTCUSDT','4h','84.400000000000006','83.556000000000012','220.093135828253736','217.892204469971233','2.6077385761641434','2.607738576164143','test','test','1.0'),('2018-07-24 07:59:59','2018-07-25 11:59:59','LTCUSDT','4h','87.310000000000002','86.436900000000009','219.604039970857656','217.407999571149105','2.5152220819019315','2.515222081901932','test','test','1.0'),('2018-08-27 19:59:59','2018-08-27 23:59:59','LTCUSDT','4h','58.130000000000003','60.609999999999999','219.116030993144619','228.464177507216505','3.7694139169644694','3.769413916964469','test','test','0.0'),('2018-08-28 03:59:59','2018-08-30 11:59:59','LTCUSDT','4h','60.090000000000003','59.489100000000001','221.193396885160610','218.981462916308999','3.6810350621594377','3.681035062159438','test','test','1.0'),('2018-08-31 19:59:59','2018-09-05 11:59:59','LTCUSDT','4h','62.039999999999999','62.299999999999997','220.701856003193569','221.626783188248851','3.5574122502126624','3.557412250212662','test','test','0.0'),('2018-09-14 19:59:59','2018-09-14 23:59:59','LTCUSDT','4h','58.020000000000003','57.439800000000005','220.907395377650317','218.698321423873807','3.8074352874465753','3.807435287446575','test','test','1.0'),('2018-09-15 11:59:59','2018-09-15 23:59:59','LTCUSDT','4h','57.649999999999999','57.073499999999996','220.416490054588849','218.212325154042958','3.823356288891394','3.823356288891394','test','test','1.0'),('2018-09-20 23:59:59','2018-09-24 11:59:59','LTCUSDT','4h','56.530000000000001','57.369999999999997','219.926675632245320','223.194646754323600','3.890441811997971','3.890441811997971','test','test','0.0'),('2018-09-26 11:59:59','2018-09-26 15:59:59','LTCUSDT','4h','57.590000000000003','58.299999999999997','220.652891437151624','223.373217065218597','3.8314445465732176','3.831444546573218','test','test','0.0'),('2018-09-26 19:59:59','2018-09-26 23:59:59','LTCUSDT','4h','58.450000000000003','57.865500000000004','221.257408243388710','219.044834160954821','3.7854133146858633','3.785413314685863','test','test','1.0'),('2018-09-27 11:59:59','2018-10-02 15:59:59','LTCUSDT','4h','58.270000000000003','60.090000000000003','220.765725113958979','227.661102146864522','3.788668699398644','3.788668699398644','test','test','0.0'),('2018-10-08 15:59:59','2018-10-09 15:59:59','LTCUSDT','4h','59.399999999999999','58.805999999999997','222.298031121271293','220.075050810058571','3.7423910963176987','3.742391096317699','test','test','1.0'),('2018-10-15 11:59:59','2018-10-15 19:59:59','LTCUSDT','4h','57.359999999999999','56.786400000000000','221.804035496557361','219.585995141591781','3.866876490525756','3.866876490525756','test','test','1.0'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCUSDT','4h','51.950000000000003','51.780000000000001','221.311137639898362','220.586924099979541','4.260079646581296','4.260079646581296','test','test','0.3'),('2018-11-04 07:59:59','2018-11-08 23:59:59','LTCUSDT','4h','51.859999999999999','52.719999999999999','221.150201297694167','224.817559051570328','4.264369481251334','4.264369481251334','test','test','0.0'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LTCUSDT','4h','35.649999999999999','35.293500000000002','221.965169687444444','219.745517990570022','6.226231968792271','6.226231968792271','test','test','1.0'),('2018-12-16 11:59:59','2018-12-16 15:59:59','LTCUSDT','4h','26.230000000000000','26.079999999999998','221.471913754805684','220.205394995247104','8.443458397057022','8.443458397057022','test','test','0.6'),('2018-12-17 07:59:59','2018-12-25 03:59:59','LTCUSDT','4h','27.350000000000001','29.870000000000001','221.190465141570456','241.570720065035090','8.087402747406598','8.087402747406598','test','test','0.0'),('2018-12-28 15:59:59','2018-12-29 23:59:59','LTCUSDT','4h','30.920000000000002','30.610800000000001','225.719410680118131','223.462216573316937','7.300110306601492','7.300110306601492','test','test','1.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','31.165199999999999','225.217811989717831','222.965633869820664','7.154314230931316','7.154314230931316','test','test','1.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LTCUSDT','4h','32.060000000000002','31.739400000000003','224.717327963074041','222.470154683443297','7.009274109890019','7.009274109890019','test','test','1.0'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','224.217956123156114','248.291735417235572','7.059759323776955','7.059759323776955','test','test','0.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','LTCUSDT','4h','32.020000000000003','31.699800000000003','229.567684855173752','227.272008006622002','7.169509208468886','7.169509208468886','test','test','1.0'),('2019-01-24 15:59:59','2019-01-27 15:59:59','LTCUSDT','4h','31.980000000000000','32.340000000000003','229.057534444384487','231.636043274902903','7.162524529217777','7.162524529217777','test','test','0.0'),('2019-01-31 03:59:59','2019-01-31 11:59:59','LTCUSDT','4h','32.020000000000003','31.699800000000003','229.630536406721916','227.334231042654693','7.171472092652151','7.171472092652151','test','test','1.0'),('2019-02-01 11:59:59','2019-02-06 03:59:59','LTCUSDT','4h','32.119999999999997','32.789999999999999','229.120246325818101','233.899529172589524','7.1332579802558564','7.133257980255856','test','test','0.0'),('2019-02-08 07:59:59','2019-02-24 15:59:59','LTCUSDT','4h','33.820000000000000','44.390000000000001','230.182309180656176','302.122788424876603','6.806100212319816','6.806100212319816','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','LTCUSDT','4h','46.009999999999998','45.859999999999999','246.169082346038493','245.366531545084229','5.35033867302844','5.350338673028440','test','test','0.3'),('2019-03-01 07:59:59','2019-03-04 07:59:59','LTCUSDT','4h','46.920000000000002','46.450800000000001','245.990737723604212','243.530830346368163','5.242769346197873','5.242769346197873','test','test','1.0'),('2019-03-05 15:59:59','2019-03-14 15:59:59','LTCUSDT','4h','52.140000000000001','55.939999999999998','245.444091639774001','263.332230270981142','4.707404902949252','4.707404902949252','test','test','0.8'),('2019-03-15 11:59:59','2019-03-20 11:59:59','LTCUSDT','4h','57.799999999999997','59.810000000000002','249.419233557820007','258.092808980851487','4.315211653249482','4.315211653249482','test','test','0.0'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','59.419800000000002','251.346694762938114','248.833227815308732','4.187715674157582','4.187715674157582','test','test','1.0'),('2019-03-22 15:59:59','2019-03-25 15:59:59','LTCUSDT','4h','59.259999999999998','58.667400000000001','250.788146552353766','248.280265086830212','4.231997073107556','4.231997073107556','test','test','1.0'),('2019-03-27 03:59:59','2019-03-30 19:59:59','LTCUSDT','4h','60.030000000000001','60.259999999999998','250.230839560015255','251.189578408904197','4.168429777778032','4.168429777778032','test','test','0.0'),('2019-04-01 03:59:59','2019-04-01 15:59:59','LTCUSDT','4h','60.659999999999997','60.369999999999997','250.443892637546128','249.246584215770838','4.12864973025958','4.128649730259580','test','test','0.5'),('2019-04-02 07:59:59','2019-04-11 11:59:59','LTCUSDT','4h','66.909999999999997','77.189999999999998','250.177824099373851','288.614949069356840','3.739019938714301','3.739019938714301','test','test','0.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCUSDT','4h','83.280000000000001','82.447199999999995','258.719407426036753','256.132213351776329','3.1066211266334864','3.106621126633486','test','test','1.0'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCUSDT','4h','81.739999999999995','80.922599999999989','258.144475409534436','255.563030655439064','3.15811690004324','3.158116900043240','test','test','1.0'),('2019-04-17 03:59:59','2019-04-17 07:59:59','LTCUSDT','4h','80.140000000000001','79.549999999999997','257.570821019735433','255.674554680808001','3.2140107439447894','3.214010743944789','test','test','0.7'),('2019-04-18 03:59:59','2019-04-18 11:59:59','LTCUSDT','4h','80.620000000000005','79.813800000000001','257.149428499973794','254.577934214974050','3.1896480836017584','3.189648083601758','test','test','1.0'),('2019-04-18 19:59:59','2019-04-19 03:59:59','LTCUSDT','4h','82.469999999999999','81.645299999999992','256.577985325529369','254.012205472274047','3.111167519407413','3.111167519407413','test','test','1.0'),('2019-04-19 15:59:59','2019-04-19 19:59:59','LTCUSDT','4h','82.750000000000000','81.922499999999999','256.007812024806015','253.447733904557964','3.0937499942574744','3.093749994257474','test','test','1.0'),('2019-05-02 15:59:59','2019-05-02 19:59:59','LTCUSDT','4h','73.909999999999997','73.200000000000003','255.438905775861969','252.985088659086671','3.4560804461623866','3.456080446162387','test','test','1.0'),('2019-05-03 03:59:59','2019-05-04 15:59:59','LTCUSDT','4h','74.750000000000000','75.950000000000003','254.893613083245214','258.985550684581597','3.4099480011136483','3.409948001113648','test','test','0.0'),('2019-05-04 23:59:59','2019-05-05 07:59:59','LTCUSDT','4h','77.769999999999996','76.992300000000000','255.802932550208880','253.244903224706803','3.2892237694510595','3.289223769451060','test','test','1.0'),('2019-05-06 19:59:59','2019-05-06 23:59:59','LTCUSDT','4h','76.010000000000005','75.249900000000011','255.234481588986199','252.682136773096374','3.357906612142957','3.357906612142957','test','test','1.0'),('2019-05-07 03:59:59','2019-05-07 07:59:59','LTCUSDT','4h','77.650000000000006','76.873500000000007','254.667293852121787','252.120620913600561','3.2796818268141887','3.279681826814189','test','test','1.0'),('2019-05-09 03:59:59','2019-05-09 07:59:59','LTCUSDT','4h','75.299999999999997','74.546999999999997','254.101366532450385','251.560352867125886','3.3745201398731792','3.374520139873179','test','test','1.0'),('2019-05-10 07:59:59','2019-05-10 11:59:59','LTCUSDT','4h','77.000000000000000','76.230000000000004','253.536696829044985','251.001329860754566','3.2926843744031817','3.292684374403182','test','test','1.0'),('2019-05-10 23:59:59','2019-05-17 07:59:59','LTCUSDT','4h','77.109999999999999','88.000000000000000','252.973281947202651','288.699893805652096','3.2806806114278646','3.280680611427865','test','test','0.0'),('2019-05-19 03:59:59','2019-05-20 15:59:59','LTCUSDT','4h','91.599999999999994','90.683999999999997','260.912529026858067','258.303403736589473','2.8483900548783634','2.848390054878363','test','test','1.0'),('2019-05-21 15:59:59','2019-05-22 11:59:59','LTCUSDT','4h','90.769999999999996','89.862299999999991','260.332723406798380','257.729396172730389','2.8680480710234484','2.868048071023448','test','test','1.0'),('2019-05-24 07:59:59','2019-05-30 19:59:59','LTCUSDT','4h','94.090000000000003','113.379999999999995','259.754206243672172','313.008097607689933','2.7606993967868227','2.760699396786823','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05  2:28:12
