-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-03 03:59:59','2019-05-03 11:59:59','BCHABCUSDT','4h','272.220000000000027','289.709999999999980','222.222222222222200','236.499889795018674','0.8163331945566901','0.816333194556690','test','test','0.0'),('2019-05-03 15:59:59','2019-05-04 15:59:59','BCHABCUSDT','4h','290.589999999999975','284.778199999999970','225.395037238399226','220.887136493631232','0.7756462274627456','0.775646227462746','test','test','2.00'),('2019-05-04 23:59:59','2019-05-06 07:59:59','BCHABCUSDT','4h','290.629999999999995','284.817399999999964','224.393281517339659','219.905415886992841','0.7720926315842812','0.772092631584281','test','test','2.00'),('2019-05-07 03:59:59','2019-05-07 15:59:59','BCHABCUSDT','4h','296.720000000000027','290.785600000000045','223.395978043929262','218.928058483050705','0.7528848006333555','0.752884800633355','test','test','1.99'),('2019-05-10 07:59:59','2019-05-10 11:59:59','BCHABCUSDT','4h','292.420000000000016','286.571599999999989','222.403107030400662','217.955044889792617','0.7605605192203018','0.760560519220302','test','test','2.00'),('2019-05-10 19:59:59','2019-05-17 11:59:59','BCHABCUSDT','4h','288.199999999999989','351.100000000000023','221.414648776932239','269.738664766068382','0.7682673448193347','0.768267344819335','test','test','0.41'),('2019-05-19 03:59:59','2019-05-23 07:59:59','BCHABCUSDT','4h','390.639999999999986','382.827200000000005','232.153318996740268','227.510252616805474','0.5942896759081002','0.594289675908100','test','test','1.99'),('2019-05-23 11:59:59','2019-05-26 11:59:59','BCHABCUSDT','4h','382.800000000000011','393.449999999999989','231.121526467865834','237.551631632136406','0.6037657431239964','0.603765743123996','test','test','0.0'),('2019-05-26 15:59:59','2019-05-30 23:59:59','BCHABCUSDT','4h','403.379999999999995','420.990000000000009','232.550438726592660','242.702685307918699','0.5765046326704166','0.576504632670417','test','test','0.0'),('2019-05-31 15:59:59','2019-06-03 07:59:59','BCHABCUSDT','4h','427.250000000000000','425.300000000000011','234.806493522442906','233.734819649139780','0.5495763452836581','0.549576345283658','test','test','0.45'),('2019-06-13 07:59:59','2019-06-13 11:59:59','BCHABCUSDT','4h','400.759999999999991','398.670000000000016','234.568343772819986','233.345048437743657','0.5853087727637988','0.585308772763799','test','test','0.52'),('2019-06-13 15:59:59','2019-06-14 03:59:59','BCHABCUSDT','4h','417.519999999999982','409.169600000000003','234.296500365025196','229.610570357724725','0.5611623404029153','0.561162340402915','test','test','1.99'),('2019-06-14 15:59:59','2019-06-14 19:59:59','BCHABCUSDT','4h','409.310000000000002','404.160000000000025','233.255182585625136','230.320330785483520','0.5698741359498305','0.569874135949830','test','test','1.25'),('2019-06-14 23:59:59','2019-06-18 07:59:59','BCHABCUSDT','4h','419.769999999999982','415.870000000000005','232.602993296704767','230.441924916741613','0.5541200974264592','0.554120097426459','test','test','0.92'),('2019-06-21 03:59:59','2019-06-26 23:59:59','BCHABCUSDT','4h','422.740000000000009','488.550000000000011','232.122755878935209','268.258438720380809','0.5490910627783867','0.549091062778387','test','test','0.0'),('2019-07-09 03:59:59','2019-07-09 11:59:59','BCHABCUSDT','4h','423.000000000000000','414.930000000000007','240.152907621478647','235.571267043451854','0.5677373702635429','0.567737370263543','test','test','1.90'),('2019-07-10 03:59:59','2019-07-10 07:59:59','BCHABCUSDT','4h','417.930000000000007','414.240000000000009','239.134765270806042','237.023389480962607','0.572188560933185','0.572188560933185','test','test','0.88'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BCHABCUSDT','4h','334.230000000000018','327.545400000000029','238.665570650840863','233.892259237824049','0.7140758479216134','0.714075847921613','test','test','1.99'),('2019-07-26 19:59:59','2019-07-26 23:59:59','BCHABCUSDT','4h','319.560000000000002','317.160000000000025','237.604834781281511','235.820344846761941','0.7435374727164898','0.743537472716490','test','test','0.75'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BCHABCUSDT','4h','320.790000000000020','318.850000000000023','237.208281462499400','235.773747761208057','0.7394503614903812','0.739450361490381','test','test','0.60'),('2019-07-30 15:59:59','2019-08-07 19:59:59','BCHABCUSDT','4h','319.509999999999991','336.759999999999991','236.889496195545803','249.678904381121100','0.7414149672797278','0.741414967279728','test','test','0.42'),('2019-08-11 19:59:59','2019-08-12 11:59:59','BCHABCUSDT','4h','338.730000000000018','331.955399999999997','239.731586903451415','234.936955165382386','0.7077365066674088','0.707736506667409','test','test','2.00'),('2019-08-13 11:59:59','2019-08-14 19:59:59','BCHABCUSDT','4h','339.509999999999991','332.719799999999964','238.666113183880498','233.892790920202856','0.702972263508823','0.702972263508823','test','test','2.00'),('2019-08-19 07:59:59','2019-08-19 11:59:59','BCHABCUSDT','4h','322.800000000000011','323.000000000000000','237.605374903063222','237.752590129149354','0.736076130430803','0.736076130430803','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BCHABCUSDT','4h','323.639999999999986','320.540000000000020','237.638089397749042','235.361862487808963','0.7342667451419758','0.734266745141976','test','test','0.95'),('2019-09-03 03:59:59','2019-09-03 11:59:59','BCHABCUSDT','4h','296.120000000000005','296.379999999999995','237.132261195540167','237.340468638167579','0.8007978562594225','0.800797856259422','test','test','0.48'),('2019-09-03 15:59:59','2019-09-04 11:59:59','BCHABCUSDT','4h','301.129999999999995','297.220000000000027','237.178529516123973','234.098902609445673','0.7876283648793676','0.787628364879368','test','test','1.29'),('2019-09-06 11:59:59','2019-09-06 19:59:59','BCHABCUSDT','4h','299.000000000000000','293.019999999999982','236.494167981306617','231.764284621680474','0.7909503945863098','0.790950394586310','test','test','2.00'),('2019-09-07 15:59:59','2019-09-07 19:59:59','BCHABCUSDT','4h','298.930000000000007','299.160000000000025','235.443082790278567','235.624235264241605','0.7876194520131087','0.787619452013109','test','test','0.0'),('2019-09-08 03:59:59','2019-09-08 11:59:59','BCHABCUSDT','4h','309.209999999999980','303.025799999999947','235.483338895603680','230.773672117691575','0.761564434835884','0.761564434835884','test','test','2.00'),('2019-09-08 15:59:59','2019-09-09 07:59:59','BCHABCUSDT','4h','305.680000000000007','299.566399999999987','234.436746278289917','229.748011352724120','0.766935181491396','0.766935181491396','test','test','2.00'),('2019-09-09 11:59:59','2019-09-10 15:59:59','BCHABCUSDT','4h','309.389999999999986','303.202200000000005','233.394805183719683','228.726909080045317','0.7543708755412899','0.754370875541290','test','test','1.99'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BCHABCUSDT','4h','299.290000000000020','299.829999999999984','232.357494938458757','232.776730620461990','0.7763623740801856','0.776362374080186','test','test','0.0'),('2019-09-14 15:59:59','2019-09-19 03:59:59','BCHABCUSDT','4h','303.959999999999980','310.240000000000009','232.450658423348358','237.253231574087351','0.7647409475699052','0.764740947569905','test','test','1.03'),('2019-09-19 19:59:59','2019-09-20 19:59:59','BCHABCUSDT','4h','320.029999999999973','313.629399999999976','233.517896901290328','228.847538963264526','0.7296750207833339','0.729675020783334','test','test','1.99'),('2019-10-07 15:59:59','2019-10-08 11:59:59','BCHABCUSDT','4h','233.599999999999994','233.139999999999986','232.480039581729073','232.022244983237670','0.9952056488943882','0.995205648894388','test','test','0.37'),('2019-10-09 15:59:59','2019-10-10 11:59:59','BCHABCUSDT','4h','237.879999999999995','233.122399999999999','232.378307448730993','227.730741299756374','0.9768719835578065','0.976871983557806','test','test','1.99'),('2019-10-20 19:59:59','2019-10-23 03:59:59','BCHABCUSDT','4h','225.120000000000005','220.617600000000010','231.345514971181075','226.718604671757447','1.0276542065173289','1.027654206517329','test','test','1.99'),('2019-10-25 15:59:59','2019-11-08 15:59:59','BCHABCUSDT','4h','235.370000000000005','279.550000000000011','230.317312682420265','273.548900711095655','0.9785330020071388','0.978533002007139','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 11:59:59','BCHABCUSDT','4h','293.430000000000007','287.561399999999992','239.924332244348108','235.125845599461144','0.8176544056311492','0.817654405631149','test','test','2.00'),('2019-11-12 07:59:59','2019-11-12 15:59:59','BCHABCUSDT','4h','290.189999999999998','286.949999999999989','238.858001878817703','236.191128705767738','0.823109004027767','0.823109004027767','test','test','1.11');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:32:51
