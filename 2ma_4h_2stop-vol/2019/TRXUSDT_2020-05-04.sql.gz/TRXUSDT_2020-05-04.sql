-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-12 03:59:59','TRXUSDT','4h','0.019280000000000','0.023730000000000','222.222222222222200','273.513139695712312','11526.04887044721','11526.048870447209993','test','test','0.98'),('2019-01-14 07:59:59','2019-01-14 11:59:59','TRXUSDT','4h','0.023710000000000','0.023235800000000','233.620203882997771','228.947799805337809','9853.235085744318','9853.235085744317985','test','test','2.00'),('2019-01-14 15:59:59','2019-01-15 23:59:59','TRXUSDT','4h','0.024100000000000','0.023950000000000','232.581891865740062','231.134286729646220','9650.70090729212','9650.700907292119155','test','test','0.62'),('2019-01-17 19:59:59','2019-01-18 11:59:59','TRXUSDT','4h','0.025250000000000','0.024745000000000','232.260201835496929','227.614997798786959','9198.423835069185','9198.423835069184861','test','test','2.00'),('2019-01-19 11:59:59','2019-01-19 23:59:59','TRXUSDT','4h','0.024740000000000','0.024245200000000','231.227934271783653','226.603375586347966','9346.319089401117','9346.319089401116798','test','test','2.00'),('2019-01-21 11:59:59','2019-01-28 15:59:59','TRXUSDT','4h','0.025160000000000','0.025900000000000','230.200254563909056','236.970850286376987','9149.453679010694','9149.453679010694032','test','test','0.07'),('2019-02-04 11:59:59','2019-02-05 19:59:59','TRXUSDT','4h','0.027060000000000','0.026518800000000','231.704831391124117','227.070734763301601','8562.632350004587','8562.632350004587352','test','test','2.00'),('2019-02-08 15:59:59','2019-02-09 15:59:59','TRXUSDT','4h','0.026640000000000','0.026400000000000','230.675032140496910','228.596878697789720','8658.97267794658','8658.972677946580006','test','test','0.90'),('2019-02-18 19:59:59','2019-02-20 03:59:59','TRXUSDT','4h','0.024840000000000','0.024640000000000','230.213220264339725','228.359651663177573','9267.843005810777','9267.843005810776958','test','test','0.80'),('2019-02-20 11:59:59','2019-02-21 11:59:59','TRXUSDT','4h','0.025060000000000','0.024600000000000','229.801316130748120','225.583095643112699','9170.044538337914','9170.044538337913764','test','test','1.83'),('2019-02-23 19:59:59','2019-02-24 15:59:59','TRXUSDT','4h','0.025040000000000','0.024539200000000','228.863933800162499','224.286655124159239','9139.933458472944','9139.933458472944039','test','test','1.99'),('2019-03-05 19:59:59','2019-03-05 23:59:59','TRXUSDT','4h','0.023600000000000','0.023750000000000','227.846760761050660','229.294939325209896','9654.52376106147','9654.523761061469486','test','test','0.0'),('2019-03-15 15:59:59','2019-03-15 19:59:59','TRXUSDT','4h','0.022740000000000','0.022910000000000','228.168578219752703','229.874323967217862','10033.798514500999','10033.798514500998863','test','test','0.0'),('2019-03-15 23:59:59','2019-03-17 03:59:59','TRXUSDT','4h','0.022950000000000','0.022800000000000','228.547632830300557','227.053857452324706','9958.502519838803','9958.502519838802982','test','test','0.65'),('2019-03-23 11:59:59','2019-03-24 19:59:59','TRXUSDT','4h','0.023960000000000','0.023480800000000','228.215682746305902','223.651369091379792','9524.861550346657','9524.861550346657168','test','test','1.99'),('2019-03-27 11:59:59','2019-03-28 07:59:59','TRXUSDT','4h','0.023200000000000','0.022870000000000','227.201390822988998','223.969646901799962','9793.16339754263','9793.163397542630264','test','test','1.42'),('2019-03-29 07:59:59','2019-03-29 11:59:59','TRXUSDT','4h','0.023560000000000','0.023088800000000','226.483225507169209','221.953560997025818','9613.040131883243','9613.040131883242793','test','test','2.00'),('2019-03-29 15:59:59','2019-03-30 07:59:59','TRXUSDT','4h','0.023210000000000','0.023160000000000','225.476633393804008','224.990901740650600','9714.633063067815','9714.633063067814874','test','test','0.64'),('2019-04-01 15:59:59','2019-04-11 03:59:59','TRXUSDT','4h','0.024080000000000','0.027180000000000','225.368693026436603','254.382104504092496','9359.164992792217','9359.164992792217163','test','test','0.0'),('2019-04-15 11:59:59','2019-04-15 15:59:59','TRXUSDT','4h','0.026830000000000','0.027130000000000','231.816117799248985','234.408172787686397','8640.18329479124','8640.183294791240769','test','test','0.0'),('2019-04-18 03:59:59','2019-04-18 11:59:59','TRXUSDT','4h','0.026920000000000','0.026690000000000','232.392130018901753','230.406610334490608','8632.694280048356','8632.694280048355722','test','test','0.85'),('2019-05-03 23:59:59','2019-05-04 07:59:59','TRXUSDT','4h','0.023810000000000','0.023740000000000','231.950903422365940','231.268981404744522','9741.743108877192','9741.743108877191844','test','test','0.29'),('2019-05-06 19:59:59','2019-05-07 15:59:59','TRXUSDT','4h','0.024010000000000','0.023830000000000','231.799365196227882','230.061594028576025','9654.284264732523','9654.284264732523297','test','test','0.91'),('2019-05-08 03:59:59','2019-05-09 07:59:59','TRXUSDT','4h','0.024630000000000','0.024137400000000','231.413193825638558','226.784929949125797','9395.582372133113','9395.582372133112585','test','test','1.99'),('2019-05-11 11:59:59','2019-05-12 11:59:59','TRXUSDT','4h','0.024500000000000','0.024020000000000','230.384690741969081','225.871031494779487','9403.45676497833','9403.456764978329375','test','test','1.95'),('2019-05-13 15:59:59','2019-05-13 23:59:59','TRXUSDT','4h','0.024840000000000','0.024343200000000','229.381655353704701','224.794022246630590','9234.36615755655','9234.366157556549297','test','test','2.00'),('2019-05-14 03:59:59','2019-05-17 03:59:59','TRXUSDT','4h','0.025740000000000','0.026060000000000','228.362181329910499','231.201182807205441','8871.87961654664','8871.879616546639227','test','test','0.03'),('2019-05-21 11:59:59','2019-05-22 11:59:59','TRXUSDT','4h','0.028560000000000','0.027988800000000','228.993070547087115','224.413209136145355','8017.964655010053','8017.964655010053320','test','test','2.00'),('2019-05-24 11:59:59','2019-05-25 19:59:59','TRXUSDT','4h','0.028030000000000','0.027469400000000','227.975323566877819','223.415817095540262','8133.261632781941','8133.261632781941444','test','test','2.00'),('2019-05-26 07:59:59','2019-05-30 23:59:59','TRXUSDT','4h','0.028750000000000','0.031020000000000','226.962099906580562','244.882237881813182','7894.333909794106','7894.333909794106148','test','test','0.0'),('2019-06-01 03:59:59','2019-06-03 23:59:59','TRXUSDT','4h','0.033700000000000','0.033750000000000','230.944352789965592','231.287000197665861','6852.948154004914','6852.948154004913704','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 19:59:59','TRXUSDT','4h','0.032820000000000','0.032420000000000','231.020496658343433','228.204890361471456','7039.015742179872','7039.015742179872177','test','test','1.21'),('2019-06-12 23:59:59','2019-06-13 19:59:59','TRXUSDT','4h','0.033490000000000','0.032820200000000','230.394806370149695','225.786910242746728','6879.510491793064','6879.510491793063920','test','test','1.99'),('2019-06-15 19:59:59','2019-06-15 23:59:59','TRXUSDT','4h','0.032450000000000','0.032640000000000','229.370829452949039','230.713832768698211','7068.43850394296','7068.438503942959869','test','test','0.0'),('2019-06-16 07:59:59','2019-06-16 23:59:59','TRXUSDT','4h','0.033120000000000','0.032810000000000','229.669274634226639','227.519592413918360','6934.4587751880035','6934.458775188003528','test','test','1.23'),('2019-06-17 03:59:59','2019-06-18 07:59:59','TRXUSDT','4h','0.033000000000000','0.032640000000000','229.191567474158120','226.691295828985488','6945.199014368428','6945.199014368427925','test','test','1.09'),('2019-06-21 03:59:59','2019-06-26 23:59:59','TRXUSDT','4h','0.033030000000000','0.036770000000000','228.635951553008653','254.524491026464688','6922.069377929418','6922.069377929417897','test','test','0.39'),('2019-07-07 19:59:59','2019-07-08 11:59:59','TRXUSDT','4h','0.034810000000000','0.034113800000000','234.388960324887762','229.701181118389997','6733.380072533403','6733.380072533403109','test','test','2.00'),('2019-07-09 11:59:59','2019-07-10 11:59:59','TRXUSDT','4h','0.034230000000000','0.033545400000000','233.347231612332706','228.680286980086038','6817.038609767243','6817.038609767242633','test','test','2.00'),('2019-07-20 03:59:59','2019-07-21 15:59:59','TRXUSDT','4h','0.027890000000000','0.027870000000000','232.310132805166774','232.143542534241561','8329.513546259117','8329.513546259116993','test','test','0.07'),('2019-08-05 15:59:59','2019-08-05 23:59:59','TRXUSDT','4h','0.023330000000000','0.022900000000000','232.273112744961168','227.992039513913880','9955.984258249515','9955.984258249514824','test','test','1.84'),('2019-08-06 07:59:59','2019-08-06 11:59:59','TRXUSDT','4h','0.022860000000000','0.022402800000000','231.321763138061783','226.695327875300535','10119.06225450839','10119.062254508389742','test','test','2.00'),('2019-09-08 03:59:59','2019-09-08 07:59:59','TRXUSDT','4h','0.016060000000000','0.015738800000000','230.293666413003734','225.687793084743646','14339.580723101102','14339.580723101102194','test','test','2.00'),('2019-09-09 11:59:59','2019-09-09 15:59:59','TRXUSDT','4h','0.015800000000000','0.015680000000000','229.270139006723667','227.528846811735860','14510.768291564787','14510.768291564787432','test','test','0.75'),('2019-09-10 03:59:59','2019-09-10 15:59:59','TRXUSDT','4h','0.015980000000000','0.015730000000000','228.883185185615304','225.302409447417318','14323.102952791945','14323.102952791945427','test','test','1.56'),('2019-09-14 19:59:59','2019-09-15 19:59:59','TRXUSDT','4h','0.015790000000000','0.015474200000000','228.087457243793523','223.525708098917647','14445.057456858363','14445.057456858363366','test','test','1.99'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TRXUSDT','4h','0.015680000000000','0.015620000000000','227.073735211598887','226.204830612574938','14481.743317066255','14481.743317066255258','test','test','0.38'),('2019-09-16 23:59:59','2019-09-22 19:59:59','TRXUSDT','4h','0.015650000000000','0.016580000000000','226.880645300704685','240.363009526241797','14497.165833910842','14497.165833910841684','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 19:59:59','TRXUSDT','4h','0.016960000000000','0.016630000000000','229.876726239712895','225.403888995661873','13554.052254700053','13554.052254700052799','test','test','1.94'),('2019-09-30 19:59:59','2019-09-30 23:59:59','TRXUSDT','4h','0.014630000000000','0.014530000000000','228.882762407701620','227.318286929863575','15644.754778380151','15644.754778380151038','test','test','0.68'),('2019-10-01 03:59:59','2019-10-01 07:59:59','TRXUSDT','4h','0.014600000000000','0.014550000000000','228.535101190404220','227.752446734272695','15653.089122630427','15653.089122630426573','test','test','0.34'),('2019-10-04 11:59:59','2019-10-05 15:59:59','TRXUSDT','4h','0.014420000000000','0.014710000000000','228.361177977930566','232.953739809664256','15836.42010942653','15836.420109426529962','test','test','0.0'),('2019-10-05 19:59:59','2019-10-06 19:59:59','TRXUSDT','4h','0.014990000000000','0.014690200000000','229.381747273871383','224.794112328393965','15302.318030278278','15302.318030278278457','test','test','2.00'),('2019-10-07 03:59:59','2019-10-15 19:59:59','TRXUSDT','4h','0.014800000000000','0.015610000000000','228.362272841543046','240.860478314627500','15429.883300104259','15429.883300104258524','test','test','0.0'),('2019-10-19 15:59:59','2019-10-19 19:59:59','TRXUSDT','4h','0.015650000000000','0.015460000000000','231.139651835561835','228.333483538516646','14769.306826553471','14769.306826553471183','test','test','1.21'),('2019-10-25 11:59:59','2019-11-04 07:59:59','TRXUSDT','4h','0.015410000000000','0.019090000000000','230.516058880662939','285.564669956642149','14958.861705429134','14958.861705429133508','test','test','0.0'),('2019-11-04 11:59:59','2019-11-07 11:59:59','TRXUSDT','4h','0.019530000000000','0.019340000000000','242.749083564213834','240.387469335990573','12429.548569596203','12429.548569596203379','test','test','0.97'),('2019-11-10 19:59:59','2019-11-11 03:59:59','TRXUSDT','4h','0.019420000000000','0.019190000000000','242.224280402386427','239.355506741596059','12472.928959958106','12472.928959958106134','test','test','1.18'),('2019-11-12 11:59:59','2019-11-12 15:59:59','TRXUSDT','4h','0.019600000000000','0.019410000000000','241.586775144433005','239.244862528236979','12325.85587471597','12325.855874715969549','test','test','0.96'),('2019-11-12 19:59:59','2019-11-14 11:59:59','TRXUSDT','4h','0.019680000000000','0.019286400000000','241.066350118611695','236.245023116239452','12249.306408466042','12249.306408466041830','test','test','2.00'),('2019-11-27 19:59:59','2019-11-28 03:59:59','TRXUSDT','4h','0.016240000000000','0.015915200000000','239.994944118084533','235.195045235722830','14778.013800374663','14778.013800374663333','test','test','2.00'),('2019-12-22 03:59:59','2019-12-23 19:59:59','TRXUSDT','4h','0.013870000000000','0.014040000000000','238.928299922004157','241.856765025590363','17226.26531521299','17226.265315212989663','test','test','0.0'),('2019-12-29 19:59:59','2019-12-30 03:59:59','TRXUSDT','4h','0.013770000000000','0.013600000000000','239.579069945023292','236.621303649405718','17398.625268338656','17398.625268338655587','test','test','1.23');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:25:40
