-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 15:59:59','NEOUSDT','4h','7.756000000000000','7.600880000000000','222.222222222222200','217.777777777777743','28.65165320038966','28.651653200389660','test','test','2.00'),('2019-01-05 15:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.737000000000000','8.327999999999999','221.234567901234556','238.133835011177609','28.594360592120275','28.594360592120275','test','test','1.95'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.742000000000000','224.989960592333006','220.490161380486342','28.479741847130757','28.479741847130757','test','test','2.00'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','223.990005211922636','220.337826047212531','30.950670887373583','30.950670887373583','test','test','1.63'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','223.178409841987076','283.300800838135444','30.106355030620136','30.106355030620136','test','test','0.0'),('2019-02-25 19:59:59','2019-02-26 07:59:59','NEOUSDT','4h','9.308999999999999','9.122819999999999','236.538941174464497','231.808162350975209','25.40970471312327','25.409704713123269','test','test','2.00'),('2019-03-01 23:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.946999999999999','8.768059999999998','235.487656991466906','230.777903851637546','26.32029249932569','26.320292499325689','test','test','2.00'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','234.441045182615909','234.039329889294123','26.7810195547882','26.781019554788202','test','test','0.17'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','234.351775117433277','233.090953982987344','26.825981583955272','26.825981583955272','test','test','0.53'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.669000000000000','234.071592643111984','231.112373191701380','26.659634697393166','26.659634697393166','test','test','1.26'),('2019-03-07 19:59:59','2019-03-08 03:59:59','NEOUSDT','4h','9.144000000000000','8.961119999999999','233.413988320576237','228.745708554164679','25.526464164542457','25.526464164542457','test','test','2.00'),('2019-03-09 15:59:59','2019-03-10 07:59:59','NEOUSDT','4h','9.010999999999999','8.830779999999999','232.376592816929275','227.729060960590687','25.78810263199748','25.788102631997479','test','test','2.00'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','231.343807959965147','231.896506477275665','26.31897701478557','26.318977014785570','test','test','0.0'),('2019-03-13 03:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.907000000000000','8.784000000000001','231.466629852700834','228.270223040992960','25.987047249657667','25.987047249657667','test','test','1.38'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.802359999999998','230.756317227876821','226.141190883319268','25.690972748594614','25.690972748594614','test','test','2.00'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','229.730733595752895','228.770468731971334','25.270127994252878','25.270127994252878','test','test','0.41'),('2019-03-19 15:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.125000000000000','9.029999999999999','229.517341403801453','227.127845794665973','25.152585359320707','25.152585359320707','test','test','1.04'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.183999999999999','9.000319999999999','228.986342379549143','224.406615531958124','24.93318187930631','24.933181879306311','test','test','2.00'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','227.968625302306663','227.694354835465845','24.93367880370848','24.933678803708482','test','test','0.12'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','227.907676309675367','226.933498385949235','24.97892112118318','24.978921121183181','test','test','0.42'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','9.082640000000001','227.691192326625128','223.137368480092647','24.56745709178087','24.567457091780870','test','test','1.99'),('2019-03-27 11:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.236000000000001','12.166000000000000','226.679231471840154','298.590247952187838','24.54300903766134','24.543009037661339','test','test','0.98'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.860759999999999','242.659457356361855','237.806268209234617','24.116423907410244','24.116423907410244','test','test','2.00'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','241.580970879222463','239.940844479483360','24.11950587851662','24.119505878516620','test','test','0.67'),('2019-05-04 03:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.968999999999999','9.769620000000000','241.216498345947116','236.392168379028163','24.196659478979548','24.196659478979548','test','test','1.99'),('2019-05-11 11:59:59','2019-05-12 11:59:59','NEOUSDT','4h','9.516000000000000','9.371000000000000','240.144425019965155','236.485225605516348','25.2358580306815','25.235858030681499','test','test','1.52'),('2019-05-13 15:59:59','2019-05-22 23:59:59','NEOUSDT','4h','9.846000000000000','11.154000000000000','239.331269594532074','271.125429723482682','24.307461872286417','24.307461872286417','test','test','1.41'),('2019-05-24 11:59:59','2019-05-25 19:59:59','NEOUSDT','4h','11.675000000000001','11.441500000000001','246.396638512076635','241.468705741835123','21.104637131655384','21.104637131655384','test','test','1.99'),('2019-05-26 19:59:59','2019-06-03 23:59:59','NEOUSDT','4h','11.573000000000000','12.417999999999999','245.301542340911851','263.212179451260965','21.196020248933884','21.196020248933884','test','test','0.0'),('2019-06-10 11:59:59','2019-06-10 15:59:59','NEOUSDT','4h','12.257999999999999','12.272000000000000','249.281683920989479','249.566391342664645','20.336244405367065','20.336244405367065','test','test','0.0'),('2019-06-12 11:59:59','2019-06-20 11:59:59','NEOUSDT','4h','12.625999999999999','13.260000000000000','249.344952236917266','261.865520882426949','19.74853098660837','19.748530986608369','test','test','0.0'),('2019-06-20 23:59:59','2019-06-27 19:59:59','NEOUSDT','4h','13.538000000000000','17.274999999999999','252.127300824808316','321.723971173627035','18.62367416345164','18.623674163451639','test','test','0.0'),('2019-07-02 15:59:59','2019-07-04 23:59:59','NEOUSDT','4h','17.689000000000000','17.335220000000000','267.593227568990244','262.241363017610411','15.127662816947835','15.127662816947835','test','test','2.00'),('2019-07-08 11:59:59','2019-07-09 11:59:59','NEOUSDT','4h','17.427000000000000','17.366000000000000','266.403924335350268','265.471426522504885','15.286849390907802','15.286849390907802','test','test','0.70'),('2019-07-10 07:59:59','2019-07-10 15:59:59','NEOUSDT','4h','17.251999999999999','16.906959999999998','266.196702599162393','260.872768547179135','15.429903929930582','15.429903929930582','test','test','2.00'),('2019-08-05 03:59:59','2019-08-05 15:59:59','NEOUSDT','4h','12.279000000000000','12.159000000000001','265.013606143166101','262.423685731310115','21.582670098800072','21.582670098800072','test','test','1.14'),('2019-08-06 07:59:59','2019-08-06 11:59:59','NEOUSDT','4h','12.113000000000000','11.870740000000000','264.438068273864815','259.149306908387530','21.830931088406242','21.830931088406242','test','test','1.99'),('2019-08-24 23:59:59','2019-08-25 03:59:59','NEOUSDT','4h','10.102000000000000','9.999000000000001','263.262787970425393','260.578560375795234','26.0604620837879','26.060462083787900','test','test','1.01'),('2019-09-03 15:59:59','2019-09-03 19:59:59','NEOUSDT','4h','9.340000000000000','9.282999999999999','262.666292949396507','261.063297371439774','28.122729437836885','28.122729437836885','test','test','0.61'),('2019-09-06 11:59:59','2019-09-06 15:59:59','NEOUSDT','4h','9.206000000000000','9.127000000000001','262.310071709850547','260.059094557441483','28.493381676064583','28.493381676064583','test','test','0.85'),('2019-09-08 15:59:59','2019-09-09 03:59:59','NEOUSDT','4h','9.255000000000001','9.069900000000001','261.809854564870705','256.573657473573292','28.28847699242255','28.288476992422549','test','test','2.00'),('2019-09-14 15:59:59','2019-09-16 15:59:59','NEOUSDT','4h','9.050000000000001','8.903000000000000','260.646255211249070','256.412553607265238','28.80069118356343','28.800691183563430','test','test','1.62'),('2019-09-16 23:59:59','2019-09-22 03:59:59','NEOUSDT','4h','9.082000000000001','9.090000000000000','259.705432632585996','259.934197602973597','28.595621298456944','28.595621298456944','test','test','0.0'),('2019-10-09 07:59:59','2019-10-10 11:59:59','NEOUSDT','4h','7.609000000000000','7.514000000000000','259.756269292672130','256.513156454874263','34.138029871556334','34.138029871556334','test','test','1.24'),('2019-10-14 23:59:59','2019-10-15 11:59:59','NEOUSDT','4h','7.529000000000000','7.499000000000000','259.035577550939308','258.003426225859187','34.40504416933714','34.405044169337138','test','test','0.39'),('2019-10-20 19:59:59','2019-10-21 03:59:59','NEOUSDT','4h','7.298000000000000','7.300000000000000','258.806210589810405','258.877135832504223','35.46262134691839','35.462621346918390','test','test','0.0'),('2019-10-21 11:59:59','2019-10-21 15:59:59','NEOUSDT','4h','7.389000000000000','7.257000000000000','258.821971754853450','254.198274330081375','35.02801079372763','35.028010793727631','test','test','1.78'),('2019-10-22 03:59:59','2019-10-22 23:59:59','NEOUSDT','4h','7.457000000000000','7.307860000000000','257.794483438237421','252.638593769472664','34.57080373316849','34.570803733168489','test','test','2.00'),('2019-10-25 15:59:59','2019-11-08 15:59:59','NEOUSDT','4h','7.474000000000000','10.574999999999999','256.648730178511926','363.133572603393588','34.338872113796086','34.338872113796086','test','test','0.0'),('2019-11-10 11:59:59','2019-11-11 11:59:59','NEOUSDT','4h','10.901000000000000','10.849000000000000','280.312028495152276','278.974882776250524','25.714340748110473','25.714340748110473','test','test','1.33'),('2019-11-11 15:59:59','2019-11-18 11:59:59','NEOUSDT','4h','11.146000000000001','11.728999999999999','280.014885002063068','294.661276349290972','25.1224551410428','25.122455141042799','test','test','0.0'),('2019-11-20 03:59:59','2019-11-20 07:59:59','NEOUSDT','4h','11.815000000000000','11.785000000000000','283.269638634780335','282.550375904433906','23.975424344881958','23.975424344881958','test','test','0.25'),('2019-11-20 15:59:59','2019-11-20 19:59:59','NEOUSDT','4h','11.811000000000000','11.574780000000001','283.109802472481135','277.447606423031516','23.970011216025835','23.970011216025835','test','test','1.99'),('2019-12-13 15:59:59','2019-12-13 23:59:59','NEOUSDT','4h','9.034000000000001','8.894000000000000','281.851536683714528','277.483680237431599','31.198974616306675','31.198974616306675','test','test','1.54'),('2019-12-14 03:59:59','2019-12-14 11:59:59','NEOUSDT','4h','9.100000000000000','8.917999999999999','280.880901917873928','275.263283879516450','30.866033177788346','30.866033177788346','test','test','2.00'),('2019-12-15 19:59:59','2019-12-16 03:59:59','NEOUSDT','4h','8.952000000000000','8.789999999999999','279.632542353794463','274.572167927820942','31.236879172675877','31.236879172675877','test','test','1.80'),('2019-12-22 07:59:59','2019-12-23 19:59:59','NEOUSDT','4h','8.699000000000000','8.686000000000000','278.508014703578112','278.091805462154241','32.016095494146235','32.016095494146235','test','test','0.14'),('2019-12-24 11:59:59','2019-12-24 15:59:59','NEOUSDT','4h','8.726000000000001','8.648999999999999','278.415523761039481','275.958728513549147','31.906431785587834','31.906431785587834','test','test','0.88'),('2019-12-26 19:59:59','2019-12-26 23:59:59','NEOUSDT','4h','8.725000000000000','8.550500000000000','277.869569261597178','272.312177876365240','31.847515101615723','31.847515101615723','test','test','2.00'),('2019-12-27 19:59:59','2019-12-31 15:59:59','NEOUSDT','4h','8.736000000000001','8.776999999999999','276.634593398212303','277.932901357155345','31.66604777909939','31.666047779099390','test','test','0.57');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:00:25
