-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-03 11:59:59','BNBBTC','4h','0.001568000000000','0.001536640000000','0.033333333333333','0.032666666666666','21.258503401360546','21.258503401360546','test','test','2.00'),('2019-01-04 11:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001569800000000','0.001570800000000','0.033185185185185','0.033206324938775','21.13975358974717','21.139753589747169','test','test','0.0'),('2019-01-07 19:59:59','2019-01-13 19:59:59','BNBBTC','4h','0.001555200000000','0.001596000000000','0.033189882908205','0.034060605144994','21.34123129385616','21.341231293856161','test','test','0.0'),('2019-01-14 15:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001627500000000','0.001624100000000','0.033383376738603','0.033313635736507','20.512059440001636','20.512059440001636','test','test','0.28'),('2019-01-16 07:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001643700000000','0.001800900000000','0.033367878738137','0.036559112258630','20.3004676876175','20.300467687617498','test','test','0.0'),('2019-02-01 11:59:59','2019-02-14 15:59:59','BNBBTC','4h','0.001899200000000','0.002378400000000','0.034077041742691','0.042675250674398','17.942840007735303','17.942840007735303','test','test','0.85'),('2019-02-16 19:59:59','2019-02-17 07:59:59','BNBBTC','4h','0.002516100000000','0.002465778000000','0.035987754838626','0.035267999741853','14.30299067550009','14.302990675500091','test','test','2.00'),('2019-02-17 19:59:59','2019-02-18 19:59:59','BNBBTC','4h','0.002498700000000','0.002485900000000','0.035827809261565','0.035644275440559','14.33857976610442','14.338579766104420','test','test','1.64'),('2019-02-19 15:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002630500000000','0.002635100000000','0.035787023968008','0.035849605344268','13.604647013118504','13.604647013118504','test','test','0.61'),('2019-02-24 11:59:59','2019-02-24 15:59:59','BNBBTC','4h','0.002630000000000','0.002591100000000','0.035800930940510','0.035271403863101','13.612521270156062','13.612521270156062','test','test','1.47'),('2019-02-24 19:59:59','2019-02-25 15:59:59','BNBBTC','4h','0.002628400000000','0.002585600000000','0.035683258256642','0.035102203830609','13.57603799141751','13.576037991417509','test','test','1.62'),('2019-02-27 15:59:59','2019-02-27 23:59:59','BNBBTC','4h','0.002584600000000','0.002582400000000','0.035554135050857','0.035523871529573','13.756146038403104','13.756146038403104','test','test','0.33'),('2019-02-28 11:59:59','2019-03-19 15:59:59','BNBBTC','4h','0.002699300000000','0.003857300000000','0.035547409823905','0.050797252589097','13.169121558887364','13.169121558887364','test','test','1.05'),('2019-03-22 23:59:59','2019-03-23 15:59:59','BNBBTC','4h','0.003800000000000','0.003779400000000','0.038936263771725','0.038725188236541','10.246385203085556','10.246385203085556','test','test','0.73'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBBTC','4h','0.004268000000000','0.004182640000000','0.038889358097240','0.038111570935295','9.111845852211756','9.111845852211756','test','test','2.00'),('2019-03-28 11:59:59','2019-03-29 11:59:59','BNBBTC','4h','0.004141200000000','0.004058376000000','0.038716516505696','0.037942186175582','9.349105695377292','9.349105695377292','test','test','2.00'),('2019-03-30 11:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004026000000000','0.004032700000000','0.038544443099004','0.038608588098697','9.573880551168514','9.573880551168514','test','test','0.0'),('2019-04-13 23:59:59','2019-04-14 03:59:59','BNBBTC','4h','0.003687700000000','0.003674800000000','0.038558697543381','0.038423814771380','10.456028837318836','10.456028837318836','test','test','0.34'),('2019-04-14 07:59:59','2019-04-16 07:59:59','BNBBTC','4h','0.003783100000000','0.003771400000000','0.038528723594047','0.038409565743065','10.184431707871086','10.184431707871086','test','test','0.85'),('2019-04-16 11:59:59','2019-04-17 19:59:59','BNBBTC','4h','0.003825700000000','0.003749186000000','0.038502244071607','0.037732199190175','10.064104365634174','10.064104365634174','test','test','2.00'),('2019-04-18 07:59:59','2019-04-23 19:59:59','BNBBTC','4h','0.003929900000000','0.004150000000000','0.038331122986844','0.040477915569201','9.753714594988168','9.753714594988168','test','test','0.0'),('2019-04-25 03:59:59','2019-04-25 11:59:59','BNBBTC','4h','0.004271200000000','0.004203400000000','0.038808188005146','0.038192156176445','9.086015172585116','9.086015172585116','test','test','1.58'),('2019-04-25 23:59:59','2019-04-29 11:59:59','BNBBTC','4h','0.004305500000000','0.004219390000000','0.038671292043212','0.037897866202348','8.981835336943908','8.981835336943908','test','test','2.00'),('2019-05-02 15:59:59','2019-05-03 03:59:59','BNBBTC','4h','0.004283300000000','0.004197634000000','0.038499419634131','0.037729431241448','8.988261301830622','8.988261301830622','test','test','1.99'),('2019-05-17 11:59:59','2019-05-17 15:59:59','BNBBTC','4h','0.003506400000000','0.003436272000000','0.038328311102424','0.037561744880376','10.930957991793228','10.930957991793228','test','test','2.00'),('2019-05-18 15:59:59','2019-05-19 03:59:59','BNBBTC','4h','0.003730000000000','0.003655400000000','0.038157963053080','0.037394803792018','10.230016904310933','10.230016904310933','test','test','2.00'),('2019-05-20 15:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003646600000000','0.003871200000000','0.037988372106177','0.040328137469816','10.417477131074731','10.417477131074731','test','test','1.50'),('2019-05-27 03:59:59','2019-05-27 07:59:59','BNBBTC','4h','0.003947800000000','0.003914600000000','0.038508319964764','0.038184474728726','9.75437457945275','9.754374579452749','test','test','0.84'),('2019-05-30 03:59:59','2019-05-30 11:59:59','BNBBTC','4h','0.003989700000000','0.003909906000000','0.038436354356755','0.037667627269620','9.63389587105675','9.633895871056749','test','test','2.00'),('2019-06-01 07:59:59','2019-06-01 15:59:59','BNBBTC','4h','0.003899300000000','0.003873900000000','0.038265526115170','0.038016264872556','9.813434748588094','9.813434748588094','test','test','0.92'),('2019-06-04 15:59:59','2019-06-04 19:59:59','BNBBTC','4h','0.003876400000000','0.003825000000000','0.038210134727922','0.037703478829404','9.857118648210195','9.857118648210195','test','test','1.32'),('2019-06-05 15:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.003900600000000','0.004064800000000','0.038097544528251','0.039701302106967','9.767098530546924','9.767098530546924','test','test','0.46'),('2019-06-19 15:59:59','2019-06-19 19:59:59','BNBBTC','4h','0.003874900000000','0.003878100000000','0.038453935101299','0.038485691428514','9.923852254587043','9.923852254587043','test','test','0.0'),('2019-06-20 11:59:59','2019-06-20 15:59:59','BNBBTC','4h','0.003921300000000','0.003859400000000','0.038460992062903','0.037853862945342','9.808224839441682','9.808224839441682','test','test','1.57'),('2019-07-02 07:59:59','2019-07-02 11:59:59','BNBBTC','4h','0.003251400000000','0.003186372000000','0.038326074481222','0.037559552991598','11.787560583509395','11.787560583509395','test','test','1.99'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002813600000000','0.002781700000000','0.038155736372417','0.037723134726739','13.56118011530321','13.561180115303211','test','test','1.13'),('2019-07-19 11:59:59','2019-07-19 15:59:59','BNBBTC','4h','0.002784300000000','0.002788500000000','0.038059602673378','0.038117013990847','13.669361302078642','13.669361302078642','test','test','0.0'),('2019-07-23 23:59:59','2019-07-24 03:59:59','BNBBTC','4h','0.002985600000000','0.002925888000000','0.038072360743926','0.037310913529047','12.751996497831666','12.751996497831666','test','test','1.99'),('2019-07-26 11:59:59','2019-07-27 07:59:59','BNBBTC','4h','0.002930500000000','0.002879000000000','0.037903150251731','0.037237048140158','12.934021583938199','12.934021583938199','test','test','1.75'),('2019-07-27 11:59:59','2019-07-28 23:59:59','BNBBTC','4h','0.002908400000000','0.002905500000000','0.037755127560270','0.037717481476538','12.98140818328642','12.981408183286421','test','test','0.30'),('2019-08-08 11:59:59','2019-08-08 15:59:59','BNBBTC','4h','0.002644900000000','0.002629300000000','0.037746761763885','0.037524125942676','14.271527000599395','14.271527000599395','test','test','0.58'),('2019-08-08 19:59:59','2019-08-08 23:59:59','BNBBTC','4h','0.002641700000000','0.002595600000000','0.037697287136950','0.037039436155759','14.270086359900821','14.270086359900821','test','test','1.74'),('2019-08-09 03:59:59','2019-08-09 07:59:59','BNBBTC','4h','0.002638800000000','0.002589600000000','0.037551098030019','0.036850963869387','14.230369118545802','14.230369118545802','test','test','1.86'),('2019-08-10 23:59:59','2019-08-16 19:59:59','BNBBTC','4h','0.002623000000000','0.002659600000000','0.037395512660989','0.037917310512073','14.256771887529291','14.256771887529291','test','test','1.12'),('2019-08-17 19:59:59','2019-08-18 11:59:59','BNBBTC','4h','0.002687400000000','0.002663700000000','0.037511467739008','0.037180656625882','13.95827481543797','13.958274815437971','test','test','0.88'),('2019-08-18 23:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002706300000000','0.002665700000000','0.037437954158313','0.036876308760971','13.83363047641183','13.833630476411830','test','test','1.50'),('2019-08-21 19:59:59','2019-08-21 23:59:59','BNBBTC','4h','0.002670600000000','0.002656200000000','0.037313144070015','0.037111949853506','13.971820590884112','13.971820590884112','test','test','0.53'),('2019-08-22 03:59:59','2019-08-22 07:59:59','BNBBTC','4h','0.002673100000000','0.002664800000000','0.037268434244124','0.037152715414216','13.942027699721006','13.942027699721006','test','test','0.31'),('2019-08-22 23:59:59','2019-08-23 07:59:59','BNBBTC','4h','0.002670000000000','0.002647900000000','0.037242718948589','0.036934455244932','13.948583875876071','13.948583875876071','test','test','0.82'),('2019-09-18 03:59:59','2019-09-19 07:59:59','BNBBTC','4h','0.002120800000000','0.002094900000000','0.037174215903332','0.036720230524279','17.52839301364202','17.528393013642020','test','test','1.22'),('2019-09-21 03:59:59','2019-09-21 15:59:59','BNBBTC','4h','0.002110700000000','0.002091000000000','0.037073330263542','0.036727310172486','17.564471627205403','17.564471627205403','test','test','0.93'),('2019-09-21 23:59:59','2019-09-22 03:59:59','BNBBTC','4h','0.002100000000000','0.002065600000000','0.036996436909974','0.036390400038687','17.61735090951164','17.617350909511639','test','test','1.63'),('2019-10-06 03:59:59','2019-10-06 07:59:59','BNBBTC','4h','0.001929600000000','0.001917100000000','0.036861762049688','0.036622970577040','19.103317811820297','19.103317811820297','test','test','0.64'),('2019-10-07 11:59:59','2019-10-07 15:59:59','BNBBTC','4h','0.001945000000000','0.001932500000000','0.036808697277989','0.036572137526845','18.924780091511','18.924780091511000','test','test','0.64'),('2019-10-08 15:59:59','2019-10-21 07:59:59','BNBBTC','4h','0.001943700000000','0.002195700000000','0.036756128444401','0.041521547165391','18.910391749962095','18.910391749962095','test','test','0.0'),('2019-10-22 03:59:59','2019-10-23 15:59:59','BNBBTC','4h','0.002236500000000','0.002218400000000','0.037815110382399','0.037509072601079','16.908164713793475','16.908164713793475','test','test','0.80'),('2019-10-24 03:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002235100000000','0.002231500000000','0.037747101986550','0.037686304005631','16.888328032996384','16.888328032996384','test','test','0.61'),('2019-10-28 23:59:59','2019-10-29 03:59:59','BNBBTC','4h','0.002165000000000','0.002187200000000','0.037733591324124','0.038120513138164','17.428910542320452','17.428910542320452','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBBTC','4h','0.002203600000000','0.002189900000000','0.037819573949466','0.037584445903038','17.162631126096386','17.162631126096386','test','test','0.62'),('2019-10-30 23:59:59','2019-10-31 07:59:59','BNBBTC','4h','0.002189600000000','0.002175700000000','0.037767323272482','0.037527569073776','17.248503504056448','17.248503504056448','test','test','0.63'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.037714044561658','0.037532386014065','17.300814056451415','17.300814056451415','test','test','0.48'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BNBBTC','4h','0.002173300000000','0.002180900000000','0.037673675995527','0.037805420318706','17.334779365723396','17.334779365723396','test','test','0.0'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.037702952511789','0.037533702850933','17.27037355677187','17.270373556771869','test','test','0.44'),('2019-11-03 23:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002193300000000','0.002195500000000','0.037665341476043','0.037703121876010','17.172909075841375','17.172909075841375','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 11:59:59','BNBBTC','4h','0.002201100000000','0.002190400000000','0.037673737120480','0.037490597332561','17.11586802983962','17.115868029839621','test','test','0.48'),('2019-11-09 03:59:59','2019-11-18 07:59:59','BNBBTC','4h','0.002238000000000','0.002326700000000','0.037633039389831','0.039124572273601','16.81547783281114','16.815477832811141','test','test','0.13'),('2019-12-29 15:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001910400000000','0.001910800000000','0.037964491141780','0.037972440155838','19.87253514540422','19.872535145404221','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:12:32
