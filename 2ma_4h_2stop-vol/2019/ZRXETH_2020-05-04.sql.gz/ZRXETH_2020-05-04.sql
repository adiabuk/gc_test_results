-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002264535000000','1.297777777777778','1.271822222222222','561.6262156346545','561.626215634654500','test','test','2.00'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.292009876543210','1.376481602256386','554.458324339852','554.458324339851970','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002306920000000','1.310781371146138','1.284565743723215','556.8315085582573','556.831508558257269','test','test','2.00'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.304955676163266','1.341624313279594','734.1068491757281','734.106849175728144','test','test','0.0'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZRXETH','4h','0.001827100000000','0.001790558000000','1.313104262189116','1.286842176945334','718.6822079739021','718.682207973902109','test','test','2.00'),('2019-02-27 07:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001824730000000','0.001813540000000','1.307268243246054','1.299251533024858','716.4173566752636','716.417356675263591','test','test','0.61'),('2019-03-03 19:59:59','2019-03-04 07:59:59','ZRXETH','4h','0.001843420000000','0.001806551600000','1.305486752085788','1.279377017044072','708.1873648358965','708.187364835896460','test','test','1.99'),('2019-03-09 03:59:59','2019-03-09 11:59:59','ZRXETH','4h','0.001800000000000','0.001792450000000','1.299684588743184','1.294233133940400','722.0469937462136','722.046993746213616','test','test','0.41'),('2019-03-09 15:59:59','2019-03-16 03:59:59','ZRXETH','4h','0.001849400000000','0.001927160000000','1.298473154342566','1.353068846178663','702.1050904847875','702.105090484787524','test','test','1.13'),('2019-03-19 15:59:59','2019-03-21 15:59:59','ZRXETH','4h','0.001946830000000','0.001907893400000','1.310605530306143','1.284393419700020','673.1997813399953','673.199781339995297','test','test','2.00'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ZRXETH','4h','0.001925130000000','0.001917860000000','1.304780616838116','1.299853284614104','677.7623416798428','677.762341679842848','test','test','0.37'),('2019-03-22 23:59:59','2019-03-24 03:59:59','ZRXETH','4h','0.002003360000000','0.001963292800000','1.303685654121669','1.277611941039236','650.7495677869522','650.749567786952184','test','test','2.00'),('2019-03-24 11:59:59','2019-04-03 03:59:59','ZRXETH','4h','0.002094000000000','0.002203380000000','1.297891495658906','1.365686802151347','619.8144678409292','619.814467840929183','test','test','1.81'),('2019-06-03 07:59:59','2019-06-03 11:59:59','ZRXETH','4h','0.001286320000000','0.001276680000000','1.312957119323893','1.303117494168191','1020.708003703505','1020.708003703505028','test','test','0.74'),('2019-06-06 07:59:59','2019-06-06 19:59:59','ZRXETH','4h','0.001328100000000','0.001301538000000','1.310770535955959','1.284555125236840','986.9516873397777','986.951687339777664','test','test','1.99'),('2019-06-07 19:59:59','2019-06-11 07:59:59','ZRXETH','4h','0.001328030000000','0.001318410000000','1.304944889129488','1.295492113338711','982.6170260683026','982.617026068302607','test','test','0.72'),('2019-06-15 15:59:59','2019-06-15 19:59:59','ZRXETH','4h','0.001333020000000','0.001326480000000','1.302844272287093','1.296452319022508','977.3628844931756','977.362884493175557','test','test','0.49'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ZRXETH','4h','0.001333000000000','0.001312990000000','1.301423838228296','1.281887835975522','976.3119566603872','976.311956660387182','test','test','1.50'),('2019-06-17 07:59:59','2019-06-17 11:59:59','ZRXETH','4h','0.001310000000000','0.001290820000000','1.297082504394347','1.278091632307108','990.1393163315623','990.139316331562327','test','test','1.46'),('2019-07-15 19:59:59','2019-07-18 15:59:59','ZRXETH','4h','0.001042710000000','0.001049060000000','1.292862310597182','1.300735713242493','1239.905928395414','1239.905928395414094','test','test','0.0'),('2019-07-20 23:59:59','2019-07-23 19:59:59','ZRXETH','4h','0.001084320000000','0.001065210000000','1.294611955629474','1.271795781001985','1193.9390176603526','1193.939017660352647','test','test','1.78'),('2019-07-24 03:59:59','2019-07-24 15:59:59','ZRXETH','4h','0.001064200000000','0.001057490000000','1.289541694601143','1.281410868843979','1211.7475047934063','1211.747504793406279','test','test','0.63'),('2019-07-26 15:59:59','2019-07-27 03:59:59','ZRXETH','4h','0.001084820000000','0.001068860000000','1.287734844432884','1.268789537269346','1187.0493210236575','1187.049321023657512','test','test','1.47'),('2019-07-27 11:59:59','2019-07-29 11:59:59','ZRXETH','4h','0.001075860000000','0.001079670000000','1.283524776174320','1.288070190444972','1193.0221182814864','1193.022118281486428','test','test','1.11'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ZRXETH','4h','0.001066440000000','0.001045111200000','1.284534868234465','1.258844170869776','1204.5073967916292','1204.507396791629162','test','test','1.99'),('2019-08-15 23:59:59','2019-08-17 23:59:59','ZRXETH','4h','0.000923980000000','0.000925320000000','1.278825824375645','1.280680438766285','1384.0405900297033','1384.040590029703253','test','test','0.0'),('2019-08-21 23:59:59','2019-08-22 15:59:59','ZRXETH','4h','0.000919420000000','0.000904640000000','1.279237960906898','1.258673760582559','1391.3532019174027','1391.353201917402657','test','test','1.60'),('2019-08-22 19:59:59','2019-08-23 03:59:59','ZRXETH','4h','0.000925950000000','0.000908900000000','1.274668138612601','1.251197009757539','1376.6057979508623','1376.605797950862325','test','test','1.84'),('2019-08-23 11:59:59','2019-08-23 15:59:59','ZRXETH','4h','0.000917310000000','0.000922330000000','1.269452332200365','1.276399439184531','1383.8858534196347','1383.885853419634714','test','test','0.0'),('2019-08-23 19:59:59','2019-08-23 23:59:59','ZRXETH','4h','0.000977140000000','0.000957597200000','1.270996133752402','1.245576211077354','1300.7308407724602','1300.730840772460169','test','test','2.00'),('2019-08-24 03:59:59','2019-08-24 23:59:59','ZRXETH','4h','0.000997000000000','0.000977060000000','1.265347262046836','1.240040316805899','1269.154726225512','1269.154726225511922','test','test','1.99'),('2019-08-30 19:59:59','2019-09-01 15:59:59','ZRXETH','4h','0.000951930000000','0.000932891400000','1.259723496437739','1.234529026508984','1323.3362709839364','1323.336270983936402','test','test','1.99'),('2019-09-01 23:59:59','2019-09-02 19:59:59','ZRXETH','4h','0.000940250000000','0.000940460000000','1.254124725342460','1.254404827647508','1333.8205002312786','1333.820500231278629','test','test','0.0'),('2019-09-02 23:59:59','2019-09-03 03:59:59','ZRXETH','4h','0.000971970000000','0.000952530600000','1.254186970299137','1.229103230893154','1290.3556388562786','1290.355638856278574','test','test','2.00'),('2019-09-03 23:59:59','2019-09-04 15:59:59','ZRXETH','4h','0.000954690000000','0.000939960000000','1.248612805986696','1.229347843923425','1307.8725093870223','1307.872509387022319','test','test','1.55'),('2019-09-05 11:59:59','2019-09-05 19:59:59','ZRXETH','4h','0.000956360000000','0.000937232800000','1.244331703305970','1.219445069239851','1301.1122415261718','1301.112241526171829','test','test','2.00'),('2019-09-18 15:59:59','2019-09-30 03:59:59','ZRXETH','4h','0.000897620000000','0.001142630000000','1.238801340180165','1.576938543403736','1380.095519462763','1380.095519462762923','test','test','0.0'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ZRXETH','4h','0.001153990000000','0.001145570000000','1.313942940896514','1.304355856465671','1138.6086022379','1138.608602237899959','test','test','0.72'),('2019-10-01 15:59:59','2019-10-02 15:59:59','ZRXETH','4h','0.001167000000000','0.001164530000000','1.311812477689660','1.309035976558646','1124.0895267263586','1124.089526726358599','test','test','0.21'),('2019-10-03 19:59:59','2019-10-25 15:59:59','ZRXETH','4h','0.001205310000000','0.001720930000000','1.311195477438324','1.872112264054836','1087.8491653087785','1087.849165308778538','test','test','1.09'),('2019-11-01 19:59:59','2019-11-01 23:59:59','ZRXETH','4h','0.001685000000000','0.001651300000000','1.435843652241993','1.407126779197153','852.132731300886','852.132731300886007','test','test','2.00'),('2019-11-07 11:59:59','2019-11-07 15:59:59','ZRXETH','4h','0.001654730000000','0.001621635400000','1.429462124898695','1.400872882400721','863.8642708470235','863.864270847023477','test','test','1.99'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZRXETH','4h','0.001637950000000','0.001605191000000','1.423108959899146','1.394646780701163','868.8354100547305','868.835410054730460','test','test','2.00'),('2019-11-09 11:59:59','2019-11-10 23:59:59','ZRXETH','4h','0.001670530000000','0.001637119400000','1.416784031188483','1.388448350564713','848.1045124532232','848.104512453223151','test','test','1.99'),('2019-11-11 15:59:59','2019-11-11 23:59:59','ZRXETH','4h','0.001671420000000','0.001637991600000','1.410487213272089','1.382277469006647','843.8855663280859','843.885566328085929','test','test','1.99'),('2019-11-21 19:59:59','2019-11-22 15:59:59','ZRXETH','4h','0.001584830000000','0.001596100000000','1.404218381213102','1.414204020780924','886.0372287331148','886.037228733114830','test','test','1.30'),('2019-11-24 07:59:59','2019-11-24 19:59:59','ZRXETH','4h','0.001702830000000','0.001668773400000','1.406437412228174','1.378308663983610','825.9411757064263','825.941175706426293','test','test','1.99'),('2019-11-25 07:59:59','2019-11-25 11:59:59','ZRXETH','4h','0.001704960000000','0.001670860800000','1.400186579284938','1.372182847699239','821.2430668666349','821.243066866634877','test','test','1.99'),('2019-11-26 07:59:59','2019-12-01 07:59:59','ZRXETH','4h','0.001676660000000','0.001696990000000','1.393963527821449','1.410865749214343','831.3930837626286','831.393083762628635','test','test','1.41'),('2019-12-01 23:59:59','2019-12-02 07:59:59','ZRXETH','4h','0.001727080000000','0.001692538400000','1.397719577019870','1.369765185479473','809.2963713434639','809.296371343463875','test','test','2.00'),('2019-12-02 11:59:59','2019-12-02 23:59:59','ZRXETH','4h','0.001718250000000','0.001683885000000','1.391507490010893','1.363677340210675','809.8399476274657','809.839947627465676','test','test','1.99'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ZRXETH','4h','0.001542410000000','0.001530360000000','1.385323012277511','1.374500246412440','898.1548435743485','898.154843574348547','test','test','0.78'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ZRXETH','4h','0.001482580000000','0.001493320000000','1.382917953196384','1.392935988524885','932.7779635475887','932.777963547588683','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:52:42
