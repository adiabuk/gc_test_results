-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000604000000000','0.000638000000000','0.033333333333333','0.035209713024282','55.187637969094915','55.187637969094915','test','test','1.65'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000628180000000','0.033750306597989','0.033075300466029','52.65258439623817','52.652584396238169','test','test','1.99'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.033600305235331','0.033332360217505','53.58900356512103','53.589003565121033','test','test','0.79'),('2019-01-18 23:59:59','2019-01-19 11:59:59','MCOBTC','4h','0.000631000000000','0.000635000000000','0.033540761898036','0.033753381624806','53.1549316926089','53.154931692608898','test','test','1.10'),('2019-01-19 15:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000638000000000','0.000626000000000','0.033588010726207','0.032956261308159','52.64578483731557','52.645784837315567','test','test','1.88'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.033447621966641','0.033181742618734','53.17586958130541','53.175869581305413','test','test','0.79'),('2019-02-08 15:59:59','2019-02-08 19:59:59','MCOBTC','4h','0.000584000000000','0.000578000000000','0.033388537667106','0.033045504745869','57.17215353956545','57.172153539565450','test','test','1.02'),('2019-02-09 03:59:59','2019-02-10 07:59:59','MCOBTC','4h','0.000582000000000','0.000572000000000','0.033312308129054','0.032739931700720','57.23764283342534','57.237642833425340','test','test','1.71'),('2019-02-10 11:59:59','2019-02-10 19:59:59','MCOBTC','4h','0.000586000000000','0.000580000000000','0.033185113367202','0.032845334049449','56.629886292152825','56.629886292152825','test','test','1.02'),('2019-02-11 19:59:59','2019-02-12 11:59:59','MCOBTC','4h','0.000587000000000','0.000579000000000','0.033109606852145','0.032658368598623','56.40478169019649','56.404781690196486','test','test','1.36'),('2019-02-12 19:59:59','2019-02-13 03:59:59','MCOBTC','4h','0.000583000000000','0.000579000000000','0.033009331684696','0.032782852565075','56.619779905138934','56.619779905138934','test','test','0.68'),('2019-02-15 03:59:59','2019-02-15 15:59:59','MCOBTC','4h','0.000684000000000','0.000670320000000','0.032959002991447','0.032299822931618','48.185676888080245','48.185676888080245','test','test','1.99'),('2019-02-15 23:59:59','2019-02-16 11:59:59','MCOBTC','4h','0.000729000000000','0.000714420000000','0.032812518533707','0.032156268163033','45.010313489310164','45.010313489310164','test','test','2.00'),('2019-02-16 15:59:59','2019-02-16 23:59:59','MCOBTC','4h','0.000758000000000','0.000742840000000','0.032666685118002','0.032013351415642','43.09589065699442','43.095890656994420','test','test','2.00'),('2019-02-18 03:59:59','2019-02-19 03:59:59','MCOBTC','4h','0.000724000000000','0.000709520000000','0.032521499850811','0.031871069853795','44.91919868896501','44.919198688965011','test','test','1.99'),('2019-02-20 11:59:59','2019-02-23 07:59:59','MCOBTC','4h','0.000761000000000','0.000745780000000','0.032376959851474','0.031729420654445','42.54528232782363','42.545282327823628','test','test','2.00'),('2019-02-24 11:59:59','2019-02-24 15:59:59','MCOBTC','4h','0.000726000000000','0.000714000000000','0.032233062252134','0.031700284363669','44.39815737208539','44.398157372085393','test','test','1.65'),('2019-03-06 11:59:59','2019-03-06 15:59:59','MCOBTC','4h','0.000693000000000','0.000684000000000','0.032114667165808','0.031697593566252','46.34151106177264','46.341511061772643','test','test','1.29'),('2019-03-09 15:59:59','2019-03-21 15:59:59','MCOBTC','4h','0.000708000000000','0.000801000000000','0.032021984143685','0.036228261721881','45.228791163396735','45.228791163396735','test','test','0.84'),('2019-03-24 15:59:59','2019-03-24 19:59:59','MCOBTC','4h','0.000801000000000','0.000800000000000','0.032956712494395','0.032915568034352','41.14446004294022','41.144460042940217','test','test','0.12'),('2019-03-25 11:59:59','2019-03-25 15:59:59','MCOBTC','4h','0.000808000000000','0.000823000000000','0.032947569281052','0.033559219700874','40.7766946547676','40.776694654767603','test','test','0.0'),('2019-03-26 07:59:59','2019-03-26 15:59:59','MCOBTC','4h','0.000808000000000','0.000812000000000','0.033083491596568','0.033247271257937','40.944915342287395','40.944915342287395','test','test','0.0'),('2019-03-26 19:59:59','2019-03-30 19:59:59','MCOBTC','4h','0.000822000000000','0.000837000000000','0.033119887076872','0.033724264578275','40.29183342685212','40.291833426852122','test','test','0.0'),('2019-03-31 15:59:59','2019-04-01 19:59:59','MCOBTC','4h','0.000868000000000','0.000850640000000','0.033254193188295','0.032589109324529','38.31128247499463','38.311282474994627','test','test','2.00'),('2019-04-11 07:59:59','2019-04-11 11:59:59','MCOBTC','4h','0.000788000000000','0.000772240000000','0.033106396774125','0.032444268838643','42.01319387579328','42.013193875793277','test','test','1.99'),('2019-04-12 07:59:59','2019-04-13 23:59:59','MCOBTC','4h','0.000790000000000','0.000782000000000','0.032959257232907','0.032625492602700','41.7205787758315','41.720578775831498','test','test','1.01'),('2019-04-14 23:59:59','2019-04-15 23:59:59','MCOBTC','4h','0.000798000000000','0.000790000000000','0.032885087315083','0.032555412254280','41.20938260035477','41.209382600354772','test','test','1.37'),('2019-04-16 11:59:59','2019-04-23 19:59:59','MCOBTC','4h','0.000810000000000','0.000866000000000','0.032811826190460','0.035080298124615','40.508427395629894','40.508427395629894','test','test','1.11'),('2019-04-25 11:59:59','2019-04-25 23:59:59','MCOBTC','4h','0.000878000000000','0.000860440000000','0.033315931064717','0.032649612443423','37.94525178213768','37.945251782137682','test','test','2.00'),('2019-04-26 03:59:59','2019-04-26 07:59:59','MCOBTC','4h','0.000896000000000','0.000878080000000','0.033167860259985','0.032504503054785','37.01770118301884','37.017701183018843','test','test','2.00'),('2019-04-30 03:59:59','2019-05-01 19:59:59','MCOBTC','4h','0.000897000000000','0.000881000000000','0.033020447547718','0.032431454057458','36.81209314126892','36.812093141268917','test','test','1.78'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MCOBTC','4h','0.000674000000000','0.000664000000000','0.032889560105438','0.032401584436218','48.79756692201516','48.797566922015157','test','test','1.48'),('2019-05-26 03:59:59','2019-05-26 11:59:59','MCOBTC','4h','0.000705000000000','0.000690900000000','0.032781121067834','0.032125498646477','46.49804406784933','46.498044067849328','test','test','1.99'),('2019-05-27 03:59:59','2019-05-28 15:59:59','MCOBTC','4h','0.000783000000000','0.000767340000000','0.032635427196421','0.031982718652493','41.6799836480474','41.679983648047397','test','test','2.00'),('2019-05-30 11:59:59','2019-06-03 15:59:59','MCOBTC','4h','0.000775000000000','0.000759500000000','0.032490380853326','0.031840573236259','41.92307206880774','41.923072068807741','test','test','1.99'),('2019-06-04 03:59:59','2019-06-05 23:59:59','MCOBTC','4h','0.000765000000000','0.000752000000000','0.032345979160644','0.031796308926542','42.28232570018882','42.282325700188821','test','test','1.69'),('2019-06-06 11:59:59','2019-06-06 15:59:59','MCOBTC','4h','0.000761000000000','0.000754000000000','0.032223830219733','0.031927421794584','42.34406073552285','42.344060735522852','test','test','0.91'),('2019-06-06 23:59:59','2019-06-07 03:59:59','MCOBTC','4h','0.000758000000000','0.000753000000000','0.032157961680811','0.031945837923022','42.424751557798004','42.424751557798004','test','test','0.65'),('2019-06-08 03:59:59','2019-06-09 19:59:59','MCOBTC','4h','0.000766000000000','0.000770000000000','0.032110823067969','0.032278503606183','41.92013455348418','41.920134553484182','test','test','0.65'),('2019-06-10 07:59:59','2019-06-14 07:59:59','MCOBTC','4h','0.000777000000000','0.000780000000000','0.032148085409794','0.032272209291685','41.37462729703247','41.374627297032468','test','test','1.02'),('2019-07-01 11:59:59','2019-07-02 15:59:59','MCOBTC','4h','0.000580000000000','0.000575000000000','0.032175668494659','0.031898292042119','55.47529050803258','55.475290508032579','test','test','0.86'),('2019-07-14 07:59:59','2019-07-14 11:59:59','MCOBTC','4h','0.000527000000000','0.000516460000000','0.032114029282983','0.031471748697323','60.937436969607845','60.937436969607845','test','test','1.99'),('2019-07-14 15:59:59','2019-07-14 19:59:59','MCOBTC','4h','0.000515000000000','0.000511000000000','0.031971300263948','0.031722979485199','62.08019468727723','62.080194687277228','test','test','0.77'),('2019-07-24 03:59:59','2019-07-24 07:59:59','MCOBTC','4h','0.000519000000000','0.000508620000000','0.031916117868670','0.031277795511297','61.49541015158038','61.495410151580380','test','test','2.00'),('2019-07-28 11:59:59','2019-07-28 15:59:59','MCOBTC','4h','0.000466000000000','0.000472000000000','0.031774268455921','0.032183379208572','68.18512544188984','68.185125441889838','test','test','0.0'),('2019-07-29 15:59:59','2019-07-29 19:59:59','MCOBTC','4h','0.000468000000000','0.000465000000000','0.031865181956510','0.031660917969609','68.0879956335679','68.087995633567900','test','test','0.64'),('2019-07-29 23:59:59','2019-07-30 07:59:59','MCOBTC','4h','0.000469000000000','0.000465000000000','0.031819789959421','0.031548405823307','67.84603402861548','67.846034028615477','test','test','0.85'),('2019-08-22 07:59:59','2019-08-22 11:59:59','MCOBTC','4h','0.000334000000000','0.000333000000000','0.031759482373618','0.031664394103038','95.08827057969327','95.088270579693273','test','test','0.29'),('2019-08-22 15:59:59','2019-08-25 15:59:59','MCOBTC','4h','0.000333000000000','0.000340000000000','0.031738351646822','0.032405524203962','95.31036530577175','95.310365305771754','test','test','0.0'),('2019-08-26 15:59:59','2019-08-27 03:59:59','MCOBTC','4h','0.000355000000000','0.000347900000000','0.031886612215075','0.031248879970774','89.82144285936714','89.821442859367139','test','test','2.00'),('2019-08-28 19:59:59','2019-08-29 07:59:59','MCOBTC','4h','0.000347000000000','0.000340060000000','0.031744893938564','0.031109996059793','91.48384420335445','91.483844203354451','test','test','1.99'),('2019-09-10 11:59:59','2019-09-10 15:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.031603805521059','0.031505043628806','98.76189225331039','98.761892253310393','test','test','0.31'),('2019-09-10 19:59:59','2019-09-11 03:59:59','MCOBTC','4h','0.000323000000000','0.000322000000000','0.031581858433892','0.031484081782394','97.77665149811764','97.776651498117644','test','test','1.23'),('2019-09-11 07:59:59','2019-09-11 11:59:59','MCOBTC','4h','0.000324000000000','0.000319000000000','0.031560130289115','0.031073091241443','97.4078095343045','97.407809534304505','test','test','1.54'),('2019-09-14 07:59:59','2019-09-15 03:59:59','MCOBTC','4h','0.000320000000000','0.000319000000000','0.031451899389632','0.031353612204039','98.28718559259998','98.287185592599982','test','test','0.31'),('2019-09-16 15:59:59','2019-09-19 07:59:59','MCOBTC','4h','0.000326000000000','0.000327800000000','0.031430057792834','0.031603597989236','96.41122022341581','96.411220223415810','test','test','1.19'),('2019-09-22 15:59:59','2019-09-23 03:59:59','MCOBTC','4h','0.000330000000000','0.000326100000000','0.031468622280923','0.031096720381239','95.35946145734208','95.359461457342078','test','test','1.18'),('2019-09-23 15:59:59','2019-09-24 19:59:59','MCOBTC','4h','0.000330600000000','0.000327200000000','0.031385977414326','0.031063193617566','94.93641081163472','94.936410811634715','test','test','1.02'),('2019-09-25 11:59:59','2019-10-26 03:59:59','MCOBTC','4h','0.000331500000000','0.000434400000000','0.031314247681713','0.041034416871602','94.46228561602747','94.462285616027472','test','test','0.0'),('2019-10-29 07:59:59','2019-11-04 23:59:59','MCOBTC','4h','0.000438500000000','0.000451800000000','0.033474285279466','0.034489582871751','76.33816483344634','76.338164833446342','test','test','0.0'),('2019-11-05 11:59:59','2019-11-29 23:59:59','MCOBTC','4h','0.000459900000000','0.000532400000000','0.033699906966641','0.039012460250141','73.27659701378705','73.276597013787054','test','test','0.0'),('2019-11-30 23:59:59','2019-12-01 03:59:59','MCOBTC','4h','0.000538700000000','0.000534200000000','0.034880474362974','0.034589102292001','64.74934910520511','64.749349105205113','test','test','0.83'),('2019-12-04 03:59:59','2019-12-16 15:59:59','MCOBTC','4h','0.000541000000000','0.000582600000000','0.034815725013869','0.037492867639704','64.35439004411994','64.354390044119938','test','test','0.51'),('2019-12-22 11:59:59','2019-12-22 15:59:59','MCOBTC','4h','0.000567600000000','0.000564700000000','0.035410645597388','0.035229724398952','62.38662015043653','62.386620150436528','test','test','0.51'),('2019-12-31 15:59:59','2020-01-01 15:59:59','MCOBTC','4h','0.000554300000000','0.000556200000000','0.035370440886624','0.035491681798918','63.811006470547035','63.811006470547035','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:50:06
