-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 07:59:59','2019-01-09 11:59:59','BQXBTC','4h','0.000032010000000','0.000031369800000','0.033333333333333','0.032666666666666','1041.3412475268144','1041.341247526814414','test','test','2.00'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.033185185185185','0.032613606514316','1120.7424919008818','1120.742491900881760','test','test','1.72'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.033058167702770','0.032889675512644','1123.2812675083173','1123.281267508317342','test','test','0.50'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.033020724993853','0.052676451464770','1119.346609961115','1119.346609961115064','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BQXBTC','4h','0.000050120000000','0.000049117600000','0.037388664209612','0.036640890925420','745.982925171832','745.982925171831994','test','test','2.00'),('2019-01-25 19:59:59','2019-01-26 07:59:59','BQXBTC','4h','0.000050100000000','0.000049098000000','0.037222492368681','0.036478042521307','742.9639195345441','742.963919534544061','test','test','2.00'),('2019-01-26 11:59:59','2019-01-26 19:59:59','BQXBTC','4h','0.000049760000000','0.000048764800000','0.037057059069264','0.036315917887879','744.7158173083646','744.715817308364649','test','test','2.00'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000046334400000','0.036892361028956','0.036154513808377','780.2952840303817','780.295284030381708','test','test','1.99'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040719000000','0.036728394979939','0.035993827080340','883.9565578805989','883.956557880598893','test','test','1.99'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.036565157668917','0.036249318449171','902.3977707037732','902.397770703773176','test','test','0.86'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039670400000','0.036494971175640','0.035765071752127','901.5556120464427','901.555612046442661','test','test','1.99'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.036332771303748','0.036028955705045','893.5752903036946','893.575290303694601','test','test','0.83'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040050000000','0.036265256726259','0.035826924812202','894.5549266467357','894.554926646735680','test','test','1.20'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.036167849634246','0.036383027718337','896.5753503779375','896.575350377937525','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000039317600000','0.036215666986266','0.035491353646541','902.6836237852996','902.683623785299574','test','test','1.99'),('2019-03-08 03:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000038300000000','0.000038190000000','0.036054708466327','0.035951157084309','941.3762001652045','941.376200165204523','test','test','0.28'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000038249400000','0.036031697048101','0.035311063107139','923.1795298001823','923.179529800182308','test','test','2.00'),('2019-03-09 03:59:59','2019-03-16 07:59:59','BQXBTC','4h','0.000038660000000','0.000040310000000','0.035871556172332','0.037402546024488','927.8726376702479','927.872637670247855','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BQXBTC','4h','0.000040980000000','0.000040410000000','0.036211776139478','0.035708098433292','883.6450985719267','883.645098571926724','test','test','1.39'),('2019-03-25 07:59:59','2019-03-25 11:59:59','BQXBTC','4h','0.000039990000000','0.000039600000000','0.036099847760325','0.035747786229279','902.721874476747','902.721874476746962','test','test','0.97'),('2019-03-26 15:59:59','2019-03-26 19:59:59','BQXBTC','4h','0.000042280000000','0.000041434400000','0.036021611864537','0.035301179627246','851.9775748471407','851.977574847140659','test','test','1.99'),('2019-03-27 07:59:59','2019-03-29 11:59:59','BQXBTC','4h','0.000041720000000','0.000040885600000','0.035861515811806','0.035144285495570','859.5761220471184','859.576122047118361','test','test','2.0'),('2019-03-31 11:59:59','2019-04-01 07:59:59','BQXBTC','4h','0.000042650000000','0.000041797000000','0.035702131297087','0.034988088671145','837.0956927804611','837.095692780461150','test','test','2.00'),('2019-04-01 11:59:59','2019-04-02 07:59:59','BQXBTC','4h','0.000044370000000','0.000050250000000','0.035543455157988','0.040253744009216','801.0695325217139','801.069532521713882','test','test','1.10'),('2019-04-02 15:59:59','2019-04-02 19:59:59','BQXBTC','4h','0.000047570000000','0.000046618600000','0.036590186013817','0.035858382293541','769.1861680432394','769.186168043239377','test','test','1.99'),('2019-04-03 07:59:59','2019-04-03 15:59:59','BQXBTC','4h','0.000043840000000','0.000042963200000','0.036427562964867','0.035699011705570','830.9206880672142','830.920688067214201','test','test','1.99'),('2019-05-21 19:59:59','2019-05-21 23:59:59','BQXBTC','4h','0.000017220000000','0.000017000000000','0.036265662685023','0.035802338306933','2106.0199004078327','2106.019900407832665','test','test','1.27'),('2019-05-22 15:59:59','2019-05-24 15:59:59','BQXBTC','4h','0.000017780000000','0.000017760000000','0.036162701712114','0.036122023757432','2033.8977340896513','2033.897734089651294','test','test','1.12'),('2019-05-26 11:59:59','2019-05-26 15:59:59','BQXBTC','4h','0.000018510000000','0.000018470000000','0.036153662166629','0.036075534317539','1953.1962272625126','1953.196227262512593','test','test','0.21'),('2019-06-07 11:59:59','2019-06-07 15:59:59','BQXBTC','4h','0.000016090000000','0.000016070000000','0.036136300422387','0.036091382708997','2245.885669508197','2245.885669508197225','test','test','0.12'),('2019-06-08 03:59:59','2019-06-13 19:59:59','BQXBTC','4h','0.000016140000000','0.000016310000000','0.036126318708300','0.036506831358883','2238.309709312281','2238.309709312281029','test','test','0.0'),('2019-07-03 19:59:59','2019-07-03 23:59:59','BQXBTC','4h','0.000010200000000','0.000009996000000','0.036210877075096','0.035486659533594','3550.085987754553','3550.085987754553116','test','test','2.00'),('2019-07-04 03:59:59','2019-07-04 07:59:59','BQXBTC','4h','0.000010680000000','0.000010466400000','0.036049939843652','0.035328941046779','3375.462532177112','3375.462532177111825','test','test','2.00'),('2019-07-04 11:59:59','2019-07-06 07:59:59','BQXBTC','4h','0.000010630000000','0.000010417400000','0.035889717888791','0.035171923531015','3376.266969782775','3376.266969782775050','test','test','2.00'),('2019-07-08 07:59:59','2019-07-08 11:59:59','BQXBTC','4h','0.000011700000000','0.000011466000000','0.035730208031507','0.035015603870877','3053.863934316866','3053.863934316866107','test','test','1.99'),('2019-07-08 15:59:59','2019-07-09 23:59:59','BQXBTC','4h','0.000012030000000','0.000011789400000','0.035571407106923','0.034859978964785','2956.8916963360675','2956.891696336067525','test','test','2.00'),('2019-07-12 15:59:59','2019-07-14 07:59:59','BQXBTC','4h','0.000011990000000','0.000012180000000','0.035413311964226','0.035974490385677','2953.5706392181446','2953.570639218144606','test','test','0.83'),('2019-07-16 19:59:59','2019-07-17 11:59:59','BQXBTC','4h','0.000012100000000','0.000011858000000','0.035538018280104','0.034827257914502','2937.0263041407907','2937.026304140790671','test','test','2.00'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BQXBTC','4h','0.000011930000000','0.000011691400000','0.035380071532192','0.034672470101548','2965.6388543329426','2965.638854332942628','test','test','1.99'),('2019-07-19 19:59:59','2019-07-20 19:59:59','BQXBTC','4h','0.000012050000000','0.000011809000000','0.035222826769827','0.034518370234430','2923.0561634710934','2923.056163471093441','test','test','1.99'),('2019-07-21 23:59:59','2019-07-28 19:59:59','BQXBTC','4h','0.000012410000000','0.000012700000000','0.035066280873072','0.035885718540533','2825.6471291758085','2825.647129175808459','test','test','0.32'),('2019-07-28 23:59:59','2019-07-29 07:59:59','BQXBTC','4h','0.000012850000000','0.000012593000000','0.035248378132508','0.034543410569858','2743.064446109538','2743.064446109538039','test','test','1.99'),('2019-07-29 15:59:59','2019-07-30 15:59:59','BQXBTC','4h','0.000012710000000','0.000012660000000','0.035091718674141','0.034953671000364','2760.953475542163','2760.953475542162778','test','test','0.39'),('2019-08-21 11:59:59','2019-08-23 07:59:59','BQXBTC','4h','0.000008590000000','0.000008630000000','0.035061041413302','0.035224305866915','4081.6113403145005','4081.611340314500467','test','test','0.0'),('2019-08-25 07:59:59','2019-08-25 11:59:59','BQXBTC','4h','0.000009100000000','0.000008918000000','0.035097322402993','0.034395375954933','3856.8486157135535','3856.848615713553500','test','test','2.00'),('2019-08-25 15:59:59','2019-08-25 19:59:59','BQXBTC','4h','0.000009080000000','0.000008898400000','0.034941334303424','0.034242507617356','3848.164570861724','3848.164570861723860','test','test','2.00'),('2019-08-29 19:59:59','2019-08-29 23:59:59','BQXBTC','4h','0.000008730000000','0.000008600000000','0.034786039484298','0.034268034314429','3984.6551528405757','3984.655152840575738','test','test','1.48'),('2019-09-28 11:59:59','2019-09-28 15:59:59','BQXBTC','4h','0.000007240000000','0.000007095200000','0.034670927224327','0.033977508679840','4788.802102807643','4788.802102807642768','test','test','1.99'),('2019-09-28 19:59:59','2019-09-28 23:59:59','BQXBTC','4h','0.000007050000000','0.000006909000000','0.034516834214441','0.033826497530152','4896.004853112246','4896.004853112245655','test','test','2.0'),('2019-09-29 07:59:59','2019-09-29 11:59:59','BQXBTC','4h','0.000006950000000','0.000006811000000','0.034363426062377','0.033676157541129','4944.377850701742','4944.377850701742318','test','test','1.99'),('2019-10-01 07:59:59','2019-10-01 11:59:59','BQXBTC','4h','0.000006750000000','0.000006840000000','0.034210699724322','0.034666842387313','5068.251811010668','5068.251811010667552','test','test','0.0'),('2019-10-01 19:59:59','2019-10-08 11:59:59','BQXBTC','4h','0.000007130000000','0.000007430000000','0.034312064760542','0.035755770150186','4812.351298813775','4812.351298813775429','test','test','1.68'),('2019-10-08 15:59:59','2019-10-09 15:59:59','BQXBTC','4h','0.000007530000000','0.000007379400000','0.034632888180463','0.033940230416854','4599.321139503733','4599.321139503733320','test','test','1.99'),('2019-11-08 07:59:59','2019-11-08 11:59:59','BQXBTC','4h','0.000005020000000','0.000004919600000','0.034478964232994','0.033789384948334','6868.319568325586','6868.319568325586260','test','test','1.99'),('2019-11-14 15:59:59','2019-11-14 19:59:59','BQXBTC','4h','0.000004770000000','0.000004674600000','0.034325724391959','0.033639209904120','7196.168635630795','7196.168635630794597','test','test','1.99'),('2019-11-18 11:59:59','2019-11-18 15:59:59','BQXBTC','4h','0.000004740000000','0.000004690000000','0.034173165616884','0.033812689186326','7209.528611156868','7209.528611156867555','test','test','1.05'),('2019-11-26 23:59:59','2019-11-27 07:59:59','BQXBTC','4h','0.000004180000000','0.000004210000000','0.034093059743426','0.034337746775077','8156.23438837948','8156.234388379480151','test','test','0.23');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:12:02
