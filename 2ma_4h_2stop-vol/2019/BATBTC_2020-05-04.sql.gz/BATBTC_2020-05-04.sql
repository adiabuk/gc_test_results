-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.033333333333333','0.033314732142857','930.0595238095237','930.059523809523739','test','test','0.05'),('2019-01-05 19:59:59','2019-01-05 23:59:59','BATBTC','4h','0.000036380000000','0.000035652400000','0.033329199735450','0.032662615740741','916.1407293966403','916.140729396640268','test','test','2.00'),('2019-01-09 11:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035690000000','0.000035120000000','0.033181069958848','0.032651139729749','929.7021563140312','929.702156314031186','test','test','1.59'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034730000000','0.033063307685715','0.032547864963857','937.1685851959937','937.168585195993728','test','test','1.55'),('2019-01-12 11:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035370000000','0.000035080000000','0.032948764858635','0.032678616659342','931.5455148044982','931.545514804498225','test','test','0.81'),('2019-01-18 03:59:59','2019-01-18 19:59:59','BATBTC','4h','0.000035280000000','0.000034590000000','0.032888731925459','0.032245499923515','932.2202926717372','932.220292671737184','test','test','1.95'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.032745791480582','0.032632582175550','943.4108752688691','943.410875268869063','test','test','0.34'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.032720633857242','0.032626582020918','940.5183632435183','940.518363243518252','test','test','0.28'),('2019-02-06 23:59:59','2019-02-08 03:59:59','BATBTC','4h','0.000034240000000','0.000033555200000','0.032699733449170','0.032045738780187','955.0155797070677','955.015579707067673','test','test','1.99'),('2019-02-10 11:59:59','2019-02-11 03:59:59','BATBTC','4h','0.000034590000000','0.000033898200000','0.032554401300507','0.031903313274497','941.1506591647039','941.150659164703939','test','test','1.99'),('2019-02-14 03:59:59','2019-02-14 07:59:59','BATBTC','4h','0.000034840000000','0.000034143200000','0.032409715072505','0.031761520771055','930.2444050661562','930.244405066156219','test','test','2.00'),('2019-02-14 11:59:59','2019-02-21 07:59:59','BATBTC','4h','0.000035360000000','0.000035460000000','0.032265671894405','0.032356920966505','912.4907209956133','912.490720995613287','test','test','1.61'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATBTC','4h','0.000039000000000','0.000038220000000','0.032285949465983','0.031640230476663','827.8448581021194','827.844858102119360','test','test','2.00'),('2019-02-26 07:59:59','2019-02-26 11:59:59','BATBTC','4h','0.000047510000000','0.000046559800000','0.032142456357245','0.031499607230100','676.5408620762973','676.540862076297344','test','test','2.00'),('2019-02-26 23:59:59','2019-02-27 03:59:59','BATBTC','4h','0.000042660000000','0.000041806800000','0.031999600995657','0.031359608975744','750.1078526876959','750.107852687695868','test','test','2.00'),('2019-03-02 07:59:59','2019-03-03 03:59:59','BATBTC','4h','0.000047080000000','0.000046138400000','0.031857380546788','0.031220232935852','676.6648374423863','676.664837442386329','test','test','1.99'),('2019-03-04 07:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000043890000000','0.000048350000000','0.031715792188802','0.034938677428311','722.6200088585502','722.620008858550250','test','test','0.27'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.032431988908693','0.032318846324772','665.544611300896','665.544611300896008','test','test','0.34'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000047990000000','0.032406846112266','0.032059462892757','668.0446529017888','668.044652901788822','test','test','1.07'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.032329649841264','0.032196933708911','663.5806617664979','663.580661766497883','test','test','0.41'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.032300157367408','0.043771550966707','662.7032697457438','662.703269745743796','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','BATBTC','4h','0.000065660000000','0.000064346800000','0.034849355945030','0.034152368826129','530.7547356842757','530.754735684275715','test','test','2.00'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BATBTC','4h','0.000062730000000','0.000061475400000','0.034694469918607','0.034000580520235','553.0761982880138','553.076198288013757','test','test','1.99'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.034540272274524','0.034398471635696','590.835995116737','590.835995116736967','test','test','0.41'),('2019-04-16 11:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000061730000000','0.000072750000000','0.034508761021452','0.040669242901517','559.0273938352756','559.027393835275575','test','test','0.51'),('2019-04-28 03:59:59','2019-04-29 03:59:59','BATBTC','4h','0.000077790000000','0.000076234200000','0.035877756994799','0.035160201854903','461.2129707520161','461.212970752016076','test','test','1.99'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.035718300297045','0.035962477903670','488.35521324917516','488.355213249175165','test','test','0.0'),('2019-05-18 11:59:59','2019-05-18 15:59:59','BATBTC','4h','0.000052980000000','0.000052450000000','0.035772561987406','0.035414701325773','675.2087955342728','675.208795534272781','test','test','1.00'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BATBTC','4h','0.000043670000000','0.000042796600000','0.035693037395932','0.034979176648013','817.335410944167','817.335410944167052','test','test','1.99'),('2019-06-04 11:59:59','2019-06-04 19:59:59','BATBTC','4h','0.000043580000000','0.000042708400000','0.035534401674172','0.034823713640689','815.3832417203305','815.383241720330489','test','test','2.00'),('2019-07-01 07:59:59','2019-07-01 11:59:59','BATBTC','4h','0.000030760000000','0.000030144800000','0.035376471000065','0.034668941580064','1150.0803316015824','1150.080331601582429','test','test','2.00'),('2019-07-01 15:59:59','2019-07-02 15:59:59','BATBTC','4h','0.000030370000000','0.000029762600000','0.035219242240064','0.034514857395263','1159.6721185401527','1159.672118540152724','test','test','2.00'),('2019-07-20 07:59:59','2019-07-20 19:59:59','BATBTC','4h','0.000024370000000','0.000023882600000','0.035062712274553','0.034361458029062','1438.7653785208497','1438.765378520849708','test','test','2.00'),('2019-07-24 19:59:59','2019-07-24 23:59:59','BATBTC','4h','0.000024090000000','0.000023730000000','0.034906877997777','0.034385231004037','1449.0194270559289','1449.019427055928873','test','test','1.49'),('2019-07-26 11:59:59','2019-07-30 15:59:59','BATBTC','4h','0.000024400000000','0.000025260000000','0.034790956443613','0.036017195072363','1425.8588706398725','1425.858870639872521','test','test','0.20'),('2019-08-21 23:59:59','2019-08-22 03:59:59','BATBTC','4h','0.000018040000000','0.000018230000000','0.035063453916668','0.035432747500048','1943.650438839714','1943.650438839714070','test','test','0.0'),('2019-08-22 07:59:59','2019-08-26 03:59:59','BATBTC','4h','0.000018610000000','0.000018430000000','0.035145519157420','0.034805583990932','1888.5287027092722','1888.528702709272238','test','test','0.96'),('2019-08-28 03:59:59','2019-08-28 19:59:59','BATBTC','4h','0.000018790000000','0.000018414200000','0.035069978009311','0.034368578449125','1866.4171372704154','1866.417137270415424','test','test','2.00'),('2019-09-01 19:59:59','2019-09-02 03:59:59','BATBTC','4h','0.000018960000000','0.000018580800000','0.034914111440381','0.034215829211573','1841.4615738597513','1841.461573859751297','test','test','2.00'),('2019-09-10 11:59:59','2019-09-10 15:59:59','BATBTC','4h','0.000017190000000','0.000017260000000','0.034758937611757','0.034900480696854','2022.0440728188992','2022.044072818899167','test','test','0.0'),('2019-09-10 19:59:59','2019-09-10 23:59:59','BATBTC','4h','0.000017660000000','0.000017306800000','0.034790391630667','0.034094583798054','1970.0108511136652','1970.010851113665240','test','test','2.00'),('2019-09-12 07:59:59','2019-09-12 11:59:59','BATBTC','4h','0.000017550000000','0.000017199000000','0.034635767667864','0.033943052314507','1973.548015262931','1973.548015262930903','test','test','2.00'),('2019-09-16 03:59:59','2019-09-16 07:59:59','BATBTC','4h','0.000017070000000','0.000016930000000','0.034481830922674','0.034199027388452','2020.0252444448738','2020.025244444873806','test','test','0.82'),('2019-09-16 15:59:59','2019-09-24 15:59:59','BATBTC','4h','0.000017220000000','0.000018800000000','0.034418985692847','0.037577057550843','1998.7796569597492','1998.779656959749218','test','test','0.0'),('2019-09-27 23:59:59','2019-09-28 07:59:59','BATBTC','4h','0.000020450000000','0.000020041000000','0.035120779439068','0.034418363850287','1717.397527582798','1717.397527582797920','test','test','1.99'),('2019-09-30 07:59:59','2019-10-10 11:59:59','BATBTC','4h','0.000019730000000','0.000022930000000','0.034964687086006','0.040635594266706','1772.1584939688685','1772.158493968868470','test','test','0.0'),('2019-10-13 11:59:59','2019-10-13 19:59:59','BATBTC','4h','0.000024270000000','0.000023784600000','0.036224888681717','0.035500390908083','1492.5788496793111','1492.578849679311134','test','test','2.00'),('2019-10-13 23:59:59','2019-10-22 03:59:59','BATBTC','4h','0.000024520000000','0.000026610000000','0.036063889176465','0.039137850366465','1470.7948277514226','1470.794827751422645','test','test','0.81'),('2019-10-22 07:59:59','2019-10-25 19:59:59','BATBTC','4h','0.000027020000000','0.000028720000000','0.036746991663132','0.039058978555335','1359.9922895311454','1359.992289531145389','test','test','0.0'),('2019-11-04 19:59:59','2019-11-04 23:59:59','BATBTC','4h','0.000026460000000','0.000025930800000','0.037260766528066','0.036515551197505','1408.192234620769','1408.192234620769113','test','test','2.00'),('2019-11-05 11:59:59','2019-11-08 15:59:59','BATBTC','4h','0.000026590000000','0.000026530000000','0.037095163121274','0.037011458353042','1395.0794705255441','1395.079470525544139','test','test','0.22'),('2019-11-09 23:59:59','2019-11-10 19:59:59','BATBTC','4h','0.000028190000000','0.000027626200000','0.037076562061667','0.036335030820434','1315.2381008040834','1315.238100804083388','test','test','1.99'),('2019-11-11 15:59:59','2019-11-20 11:59:59','BATBTC','4h','0.000027840000000','0.000029750000000','0.036911777341393','0.039444158617329','1325.8540711707294','1325.854071170729412','test','test','1.86'),('2019-11-22 23:59:59','2019-11-23 07:59:59','BATBTC','4h','0.000030140000000','0.000029537200000','0.037474528736046','0.036725038161325','1243.348664102374','1243.348664102373959','test','test','2.00'),('2019-11-23 11:59:59','2019-11-23 19:59:59','BATBTC','4h','0.000030500000000','0.000029930000000','0.037307975274996','0.036610744261660','1223.212304098244','1223.212304098243976','test','test','1.86'),('2019-11-25 07:59:59','2019-11-25 15:59:59','BATBTC','4h','0.000030300000000','0.000029890000000','0.037153035049811','0.036650304212503','1226.172773921144','1226.172773921143971','test','test','1.35'),('2019-12-13 15:59:59','2019-12-14 15:59:59','BATBTC','4h','0.000026070000000','0.000025548600000','0.037041317085964','0.036300490744245','1420.840701417892','1420.840701417891978','test','test','2.00'),('2019-12-15 19:59:59','2019-12-16 11:59:59','BATBTC','4h','0.000026050000000','0.000025529000000','0.036876689010027','0.036139155229826','1415.611862189132','1415.611862189131898','test','test','2.00'),('2019-12-28 03:59:59','2020-01-01 15:59:59','BATBTC','4h','0.000023800000000','0.000026110000000','0.036712792614427','0.040276093074063','1542.5543115305322','1542.554311530532232','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:35:24
