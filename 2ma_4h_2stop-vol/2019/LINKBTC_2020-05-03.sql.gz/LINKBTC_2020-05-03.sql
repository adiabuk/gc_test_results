-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079050000000','0.000092190000000','0.033333333333333','0.038874130297280','421.67404596247104','421.674045962471041','test','test','1.55'),('2019-01-08 11:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000093480000000','0.000093490000000','0.034564621547544','0.034568319089430','369.7541885702158','369.754188570215774','test','test','0.0'),('2019-01-10 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000095170000000','0.000137160000000','0.034565443223518','0.049816078517786','363.1968395872485','363.196839587248519','test','test','0.0'),('2019-01-25 19:59:59','2019-01-25 23:59:59','LINKBTC','4h','0.000133500000000','0.000132620000000','0.037954473288911','0.037704286498692','284.3031707034557','284.303170703455692','test','test','0.65'),('2019-01-26 07:59:59','2019-01-26 11:59:59','LINKBTC','4h','0.000134290000000','0.000133370000000','0.037898876224418','0.037639236890689','282.2166670967177','282.216667096717686','test','test','0.68'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.037841178594701','0.037841178594701','286.39354116930804','286.393541169308037','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.037841178594701','0.037393280376911','311.0404290210477','311.040429021047714','test','test','1.18'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.037741645657414','0.037493753075099','309.8657278933826','309.865727893382598','test','test','0.65'),('2019-02-08 23:59:59','2019-02-09 03:59:59','LINKBTC','4h','0.000119860000000','0.000119390000000','0.037686558416900','0.037538780321990','314.42147853245086','314.421478532450863','test','test','0.39'),('2019-02-09 11:59:59','2019-02-10 23:59:59','LINKBTC','4h','0.000121430000000','0.000122400000000','0.037653718840253','0.037954502067421','310.08580120442144','310.085801204421443','test','test','0.0'),('2019-02-11 03:59:59','2019-02-11 07:59:59','LINKBTC','4h','0.000120660000000','0.000122680000000','0.037720559557401','0.038352049117371','312.61859404443334','312.618594044433337','test','test','0.0'),('2019-02-11 11:59:59','2019-02-11 15:59:59','LINKBTC','4h','0.000122200000000','0.000119756000000','0.037860890570728','0.037103672759313','309.8272550796072','309.827255079607198','test','test','2.00'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000120050000000','0.037692619945969','0.036938767547050','307.69485670178864','307.694856701788638','test','test','2.00'),('2019-02-14 07:59:59','2019-02-14 11:59:59','LINKBTC','4h','0.000122150000000','0.000121410000000','0.037525097190654','0.037297765451636','307.2050527274153','307.205052727415307','test','test','0.60'),('2019-02-14 15:59:59','2019-02-14 19:59:59','LINKBTC','4h','0.000120100000000','0.000118900000000','0.037474579026428','0.037100145264299','312.0281351076399','312.028135107639912','test','test','0.99'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.037391371523732','0.037323229527913','309.73634462998854','309.736344629988537','test','test','0.36'),('2019-02-16 11:59:59','2019-02-16 15:59:59','LINKBTC','4h','0.000120740000000','0.000122290000000','0.037376228857995','0.037856046273349','309.5596228092982','309.559622809298219','test','test','0.0'),('2019-02-16 19:59:59','2019-02-16 23:59:59','LINKBTC','4h','0.000120700000000','0.000121120000000','0.037482854950296','0.037613284105881','310.54560853600293','310.545608536002931','test','test','0.0'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121186800000','0.037511839207092','0.036761602422950','303.34658909180195','303.346589091801945','test','test','2.00'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.037345119921727','0.036860795129177','306.53467882892005','306.534678828920050','test','test','1.29'),('2019-02-19 11:59:59','2019-02-19 15:59:59','LINKBTC','4h','0.000121500000000','0.000119070000000','0.037237492190050','0.036492742346249','306.48141720205393','306.481417202053933','test','test','2.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000117698000000','0.037071992224760','0.036330552380265','308.6760385075807','308.676038507580699','test','test','2.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000120814400000','0.036907227814873','0.036169083258576','299.37725352752','299.377253527519997','test','test','1.99'),('2019-02-26 07:59:59','2019-02-26 11:59:59','LINKBTC','4h','0.000115600000000','0.000115600000000','0.036743195691251','0.036743195691251','317.84771359213755','317.847713592137552','test','test','0.0'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.036743195691251','0.039272026694721','326.72235186956345','326.722351869563454','test','test','0.0'),('2019-03-07 23:59:59','2019-03-16 03:59:59','LINKBTC','4h','0.000116660000000','0.000121660000000','0.037305158136467','0.038904041992822','319.7767712709297','319.776771270929714','test','test','0.0'),('2019-03-20 07:59:59','2019-03-20 11:59:59','LINKBTC','4h','0.000121190000000','0.000119350000000','0.037660465660101','0.037088675439665','310.7555545845458','310.755554584545791','test','test','1.51'),('2019-03-25 23:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000120260000000','0.000117854800000','0.037533401166671','0.036782733143338','312.10212179170867','312.102121791708669','test','test','2.00'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.037366586050375','0.037670250848550','316.3174980984903','316.317498098490319','test','test','0.0'),('2019-03-30 15:59:59','2019-03-31 03:59:59','LINKBTC','4h','0.000121180000000','0.000120800000000','0.037434067116636','0.037316680208695','308.91291563488835','308.912915634888350','test','test','1.02'),('2019-03-31 07:59:59','2019-04-02 07:59:59','LINKBTC','4h','0.000122840000000','0.000127310000000','0.037407981137093','0.038769212622625','304.5260594032345','304.526059403234513','test','test','0.0'),('2019-04-02 11:59:59','2019-04-02 15:59:59','LINKBTC','4h','0.000122240000000','0.000124270000000','0.037710477022767','0.038336722673587','308.495394492532','308.495394492532000','test','test','0.0'),('2019-04-02 19:59:59','2019-04-02 23:59:59','LINKBTC','4h','0.000122500000000','0.000120050000000','0.037849642722949','0.037092649868490','308.9766752893823','308.976675289382285','test','test','2.00'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.037681422088625','0.038002979249947','423.10152805552553','423.101528055525534','test','test','0.0'),('2019-05-01 11:59:59','2019-05-01 15:59:59','LINKBTC','4h','0.000089150000000','0.000088410000000','0.037752879235586','0.037439507046754','423.4759308534554','423.475930853455395','test','test','0.83'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.037683240971401','0.037431678262947','426.37747195520086','426.377471955200861','test','test','0.66'),('2019-05-06 03:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000089280000000','0.000095480000000','0.037627338147300','0.040240347740862','421.4531602520136','421.453160252013618','test','test','0.0'),('2019-05-14 15:59:59','2019-05-14 23:59:59','LINKBTC','4h','0.000107050000000','0.000104909000000','0.038208006945869','0.037443846806952','356.91739323558244','356.917393235582438','test','test','2.00'),('2019-05-15 02:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000099090000000','0.000142980000000','0.038038193581665','0.054886476115718','383.8752001379083','383.875200137908280','test','test','0.0'),('2019-05-25 19:59:59','2019-05-25 23:59:59','LINKBTC','4h','0.000143830000000','0.000140953400000','0.041782256367010','0.040946611239670','290.49750654947115','290.497506549471154','test','test','2.00'),('2019-05-26 03:59:59','2019-05-26 07:59:59','LINKBTC','4h','0.000146840000000','0.000143903200000','0.041596557449824','0.040764626300828','283.2781084842262','283.278108484226209','test','test','2.00'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKBTC','4h','0.000142750000000','0.000139895000000','0.041411683861158','0.040583450183935','290.09936154926794','290.099361549267940','test','test','2.00'),('2019-05-28 07:59:59','2019-05-28 11:59:59','LINKBTC','4h','0.000137920000000','0.000142490000000','0.041227631932886','0.042593715734606','298.9242454530613','298.924245453061303','test','test','0.0'),('2019-05-28 15:59:59','2019-05-29 03:59:59','LINKBTC','4h','0.000139530000000','0.000137370000000','0.041531206111046','0.040888280538052','297.65072823798624','297.650728237986243','test','test','1.54'),('2019-05-29 07:59:59','2019-05-29 11:59:59','LINKBTC','4h','0.000144340000000','0.000141453200000','0.041388333761492','0.040560567086262','286.74195483921295','286.741954839212951','test','test','2.00'),('2019-05-29 15:59:59','2019-05-29 19:59:59','LINKBTC','4h','0.000139910000000','0.000137111800000','0.041204385611441','0.040380297899212','294.50636560246505','294.506365602465053','test','test','1.99'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.041021255008723','0.044075411095474','322.8494806290204','322.849480629020377','test','test','0.0'),('2019-06-09 23:59:59','2019-06-12 07:59:59','LINKBTC','4h','0.000138970000000','0.000138090000000','0.041699956361335','0.041435899646951','300.0644481638818','300.064448163881821','test','test','0.63'),('2019-06-12 11:59:59','2019-06-12 15:59:59','LINKBTC','4h','0.000138640000000','0.000140670000000','0.041641277091472','0.042250998618417','300.35543199272615','300.355431992726153','test','test','0.0'),('2019-06-12 19:59:59','2019-06-12 23:59:59','LINKBTC','4h','0.000139570000000','0.000140860000000','0.041776770764126','0.042162899834024','299.3248603863724','299.324860386372393','test','test','0.0'),('2019-06-13 03:59:59','2019-06-13 15:59:59','LINKBTC','4h','0.000139790000000','0.000137990000000','0.041862577224103','0.041323535525817','299.4676101588335','299.467610158833509','test','test','1.28'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKBTC','4h','0.000217740000000','0.000213385200000','0.041742790180040','0.040907934376439','191.70933305795796','191.709333057957963','test','test','2.00'),('2019-06-14 07:59:59','2019-06-16 11:59:59','LINKBTC','4h','0.000188400000000','0.000184632000000','0.041557266668128','0.040726121334765','220.57997169919557','220.579971699195568','test','test','1.99'),('2019-06-16 15:59:59','2019-06-20 19:59:59','LINKBTC','4h','0.000178480000000','0.000179460000000','0.041372567705159','0.041599736667233','231.80506334132048','231.805063341320476','test','test','0.0'),('2019-06-20 23:59:59','2019-06-21 03:59:59','LINKBTC','4h','0.000185610000000','0.000181897800000','0.041423049696731','0.040594588702796','223.17251062297765','223.172510622977654','test','test','1.99'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000175665000000','0.041238947253634','0.040414168308561','230.06386194496076','230.063861944960763','test','test','2.00'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.041055663043618','0.064018281645683','223.06798719705512','223.067987197055118','test','test','0.0'),('2019-07-08 03:59:59','2019-07-08 11:59:59','LINKBTC','4h','0.000292530000000','0.000286679400000','0.046158467177410','0.045235297833862','157.79054174754805','157.790541747548048','test','test','1.99'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000278506200000','0.045953318434400','0.045034252065712','161.69928018015963','161.699280180159633','test','test','1.99'),('2019-07-13 03:59:59','2019-07-13 15:59:59','LINKBTC','4h','0.000277170000000','0.000278350000000','0.045749081463580','0.045943849714570','165.05783982241945','165.057839822419453','test','test','1.23'),('2019-07-13 19:59:59','2019-07-13 23:59:59','LINKBTC','4h','0.000288010000000','0.000282249800000','0.045792363297133','0.044876516031190','158.99574076293646','158.995740762936464','test','test','2.00'),('2019-07-14 03:59:59','2019-07-14 15:59:59','LINKBTC','4h','0.000278150000000','0.000272587000000','0.045588841682479','0.044677064848829','163.90020378385523','163.900203783855233','test','test','1.99'),('2019-07-14 19:59:59','2019-07-14 23:59:59','LINKBTC','4h','0.000272840000000','0.000273250000000','0.045386224608335','0.045454427042323','166.34739997190619','166.347399971906185','test','test','0.0'),('2019-07-15 07:59:59','2019-07-15 11:59:59','LINKBTC','4h','0.000274630000000','0.000269137400000','0.045401380704777','0.044493353090681','165.31835817200113','165.318358172001126','test','test','1.99'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000270715200000','0.045199596790533','0.044295604854722','163.62437297470717','163.624372974707171','test','test','2.00'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.044998709693686','0.044866140163398','192.1297540399053','192.129754039905293','test','test','0.29'),('2019-08-04 11:59:59','2019-08-04 15:59:59','LINKBTC','4h','0.000230940000000','0.000229690000000','0.044969249798067','0.044725846480116','194.7226543607286','194.722654360728598','test','test','0.54'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229380000000','0.044915160171855','0.044448161871608','193.77522831811262','193.775228318112624','test','test','1.03'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000210030000000','0.044811382771800','0.044045931877392','209.7125738103727','209.712573810372703','test','test','1.70'),('2019-08-12 03:59:59','2019-08-12 07:59:59','LINKBTC','4h','0.000212280000000','0.000215530000000','0.044641282573043','0.045324739179235','210.29434036670017','210.294340366700169','test','test','0.0'),('2019-08-12 11:59:59','2019-08-12 15:59:59','LINKBTC','4h','0.000213650000000','0.000211330000000','0.044793161818864','0.044306758189471','209.6567368072247','209.656736807224689','test','test','1.08'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.044685072123443','0.047208563063247','209.59227074785593','209.592270747855935','test','test','0.0'),('2019-09-18 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000170760000000','0.000297510000000','0.045245847887844','0.078830476722373','264.9674858739973','264.967485873997305','test','test','1.99'),('2019-10-15 23:59:59','2019-10-16 03:59:59','LINKBTC','4h','0.000293710000000','0.000287835800000','0.052709098739961','0.051654916765162','179.45966681407285','179.459666814072847','test','test','2.00'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.052474836078895','0.052337046574968','176.65321016291833','176.653210162918327','test','test','0.26'),('2019-10-17 07:59:59','2019-10-17 11:59:59','LINKBTC','4h','0.000291380000000','0.000296020000000','0.052444216189133','0.053279349565197','179.9856413931407','179.985641393140696','test','test','0.0'),('2019-10-17 15:59:59','2019-10-18 19:59:59','LINKBTC','4h','0.000303640000000','0.000297567200000','0.052629801383814','0.051577205356138','173.3296054005211','173.329605400521103','test','test','1.99'),('2019-10-18 23:59:59','2019-10-19 03:59:59','LINKBTC','4h','0.000296150000000','0.000294770000000','0.052395891155442','0.052151736741143','176.92348862212316','176.923488622123159','test','test','0.46'),('2019-10-19 11:59:59','2019-10-19 15:59:59','LINKBTC','4h','0.000295540000000','0.000294470000000','0.052341634618931','0.052152132185953','177.10507754933641','177.105077549336414','test','test','0.36'),('2019-10-19 19:59:59','2019-10-20 03:59:59','LINKBTC','4h','0.000294310000000','0.000294090000000','0.052299522967158','0.052260428491765','177.70216087512486','177.702160875124861','test','test','0.07'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.052290835305960','0.052632327919706','176.93917810699273','176.939178106992728','test','test','0.0'),('2019-10-21 03:59:59','2019-10-26 03:59:59','LINKBTC','4h','0.000302500000000','0.000297940000000','0.052366722553459','0.051577326669678','173.11313240812785','173.113132408127854','test','test','1.50'),('2019-11-08 03:59:59','2019-11-08 07:59:59','LINKBTC','4h','0.000294010000000','0.000294670000000','0.052191301245952','0.052308461406567','177.51539487075877','177.515394870758769','test','test','0.0'),('2019-11-08 11:59:59','2019-11-19 07:59:59','LINKBTC','4h','0.000296720000000','0.000330580000000','0.052217336837200','0.058176082541256','175.98185776893894','175.981857768938937','test','test','0.0'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000328490000000','0.053541502549212','0.052773571495756','160.65503210373572','160.655032103735721','test','test','1.43'),('2019-11-19 23:59:59','2019-11-20 19:59:59','LINKBTC','4h','0.000335370000000','0.000328662600000','0.053370851204000','0.052303434179920','159.1402069475492','159.140206947549188','test','test','2.00'),('2019-11-20 23:59:59','2019-11-21 03:59:59','LINKBTC','4h','0.000333450000000','0.000330130000000','0.053133647420871','0.052604621451648','159.3451714526036','159.345171452603608','test','test','0.99'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334850000000','0.053016086094377','0.052483182346496','156.73639643570337','156.736396435703369','test','test','1.00'),('2019-11-21 23:59:59','2019-11-22 07:59:59','LINKBTC','4h','0.000333290000000','0.000326624200000','0.052897663039292','0.051839709778506','158.71362188872155','158.713621888721548','test','test','1.99'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.052662562314673','0.052585572561610','157.12194502692037','157.121945026920372','test','test','0.14'),('2019-11-23 23:59:59','2019-11-24 03:59:59','LINKBTC','4h','0.000331980000000','0.000328040000000','0.052645453480659','0.052020647508270','158.58019603789052','158.580196037890516','test','test','1.18'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000288286600000','0.052506607709017','0.051456475554837','178.4906948669711','178.490694866971097','test','test','2.00'),('2019-12-12 11:59:59','2019-12-12 15:59:59','LINKBTC','4h','0.000291190000000','0.000290420000000','0.052273245008088','0.052135017738415','179.51593464091488','179.515934640914878','test','test','0.26'),('2019-12-12 19:59:59','2019-12-13 03:59:59','LINKBTC','4h','0.000292770000000','0.000291850000000','0.052242527837050','0.052078360997517','178.44221688372974','178.442216883729742','test','test','0.31'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.052206046317153','0.051805488417021','178.02573339182723','178.025733391827231','test','test','0.76'),('2019-12-16 03:59:59','2019-12-16 07:59:59','LINKBTC','4h','0.000289340000000','0.000287010000000','0.052117033450457','0.051697344890494','180.12384547749127','180.123845477491273','test','test','0.80'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000287630000000','0.052023769326021','0.051380684583468','178.634650709134','178.634650709134007','test','test','1.23'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000261920000000','0.051880861605454','0.051067816421889','194.9748641642067','194.974864164206707','test','test','1.56');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:46:02
