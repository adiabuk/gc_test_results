-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 11:59:59','2019-02-08 15:59:59','HCETH','4h','0.009920000000000','0.009721600000000','1.297777777777778','1.271822222222222','130.82437275985663','130.824372759856630','test','test','1.99'),('2019-02-09 03:59:59','2019-02-09 07:59:59','HCETH','4h','0.009695000000000','0.009501100000000','1.292009876543210','1.266169679012346','133.26558809109952','133.265588091099517','test','test','2.00'),('2019-02-10 11:59:59','2019-02-11 03:59:59','HCETH','4h','0.010156000000000','0.009952880000000','1.286267610425240','1.260542258216735','126.65100535892476','126.651005358924763','test','test','1.99'),('2019-02-15 11:59:59','2019-02-15 15:59:59','HCETH','4h','0.009391000000000','0.009203180000000','1.280550865490017','1.254939848180217','136.35937232350298','136.359372323502981','test','test','2.0'),('2019-02-16 03:59:59','2019-02-16 07:59:59','HCETH','4h','0.009208000000000','0.009301000000000','1.274859528310061','1.287735498784957','138.45129542898144','138.451295428981439','test','test','0.0'),('2019-02-26 15:59:59','2019-02-27 15:59:59','HCETH','4h','0.008514000000000','0.008343720000000','1.277720855082260','1.252166437980615','150.07292166810666','150.072921668106659','test','test','2.00'),('2019-03-02 07:59:59','2019-03-04 11:59:59','HCETH','4h','0.008581000000000','0.008472000000000','1.272042095726339','1.255884003611880','148.2393771968697','148.239377196869697','test','test','1.30'),('2019-03-08 11:59:59','2019-03-20 15:59:59','HCETH','4h','0.008718000000000','0.009494000000000','1.268451408589793','1.381357842756538','145.4979821736399','145.497982173639912','test','test','1.39'),('2019-03-21 03:59:59','2019-03-21 15:59:59','HCETH','4h','0.009750000000000','0.009555000000000','1.293541727293514','1.267670892747644','132.67094638907832','132.670946389078324','test','test','2.00'),('2019-03-23 03:59:59','2019-03-26 07:59:59','HCETH','4h','0.009724000000000','0.009745000000000','1.287792652949987','1.290573776532047','132.43445628856304','132.434456288563041','test','test','0.27'),('2019-03-26 19:59:59','2019-03-27 07:59:59','HCETH','4h','0.009958000000000','0.009846000000000','1.288410680412667','1.273919618331304','129.38448286931782','129.384482869317821','test','test','1.12'),('2019-03-31 15:59:59','2019-04-02 07:59:59','HCETH','4h','0.010000000000000','0.009921000000000','1.285190444394586','1.275037439883869','128.51904443945864','128.519044439458639','test','test','0.79'),('2019-04-04 07:59:59','2019-04-04 19:59:59','HCETH','4h','0.009988000000000','0.009962000000000','1.282934221169983','1.279594584631094','128.4475591880239','128.447559188023888','test','test','0.26'),('2019-04-07 03:59:59','2019-04-07 11:59:59','HCETH','4h','0.010152000000000','0.009948960000000','1.282192079716896','1.256548238122558','126.29945623688891','126.299456236888915','test','test','1.99'),('2019-05-30 15:59:59','2019-07-01 11:59:59','HCETH','4h','0.005353000000000','0.014674000000000','1.276493448251488','3.499208828627375','238.46318853941486','238.463188539414858','test','test','0.0'),('2019-07-01 23:59:59','2019-07-02 07:59:59','HCETH','4h','0.015223000000000','0.014918540000000','1.770430199446129','1.735021595457206','116.2996912202673','116.299691220267306','test','test','1.99'),('2019-07-02 11:59:59','2019-07-07 23:59:59','HCETH','4h','0.014893000000000','0.016214000000000','1.762561620781924','1.918899759575513','118.34832611172527','118.348326111725271','test','test','0.0'),('2019-07-08 11:59:59','2019-07-08 15:59:59','HCETH','4h','0.015966000000000','0.015777000000000','1.797303429402722','1.776027571444741','112.5706770263511','112.570677026351106','test','test','1.18'),('2019-07-21 03:59:59','2019-07-21 15:59:59','HCETH','4h','0.014486000000000','0.014196280000000','1.792575460967615','1.756723951748263','123.74537215018744','123.745372150187436','test','test','2.00'),('2019-07-24 07:59:59','2019-07-24 11:59:59','HCETH','4h','0.014361000000000','0.014073780000000','1.784608458918870','1.748916289740493','124.26770133826824','124.267701338268239','test','test','1.99'),('2019-07-24 15:59:59','2019-07-25 07:59:59','HCETH','4h','0.014612000000000','0.014319760000000','1.776676865768120','1.741143328452758','121.59025908623867','121.590259086238675','test','test','2.00'),('2019-07-27 03:59:59','2019-07-27 07:59:59','HCETH','4h','0.014144000000000','0.013982000000000','1.768780524142484','1.748521584315626','125.05518411640863','125.055184116408626','test','test','1.14'),('2019-08-17 11:59:59','2019-08-24 07:59:59','HCETH','4h','0.011182000000000','0.013333000000000','1.764278537514293','2.103659966077452','157.77844191685682','157.778441916856821','test','test','0.0'),('2019-08-25 03:59:59','2019-08-25 07:59:59','HCETH','4h','0.013227000000000','0.013011000000000','1.839696632750550','1.809653956960566','139.08646199066686','139.086461990666862','test','test','1.63'),('2019-08-25 11:59:59','2019-08-25 15:59:59','HCETH','4h','0.013438000000000','0.013169240000000','1.833020482574998','1.796360072923498','136.40575104740276','136.405751047402759','test','test','1.99'),('2019-08-28 15:59:59','2019-08-28 19:59:59','HCETH','4h','0.013314000000000','0.013402000000000','1.824873724874665','1.836935380860017','137.06427256081307','137.064272560813066','test','test','0.0'),('2019-08-28 23:59:59','2019-08-29 03:59:59','HCETH','4h','0.013284000000000','0.013018320000000','1.827554092871410','1.791003011013982','137.57558663590862','137.575586635908621','test','test','2.00'),('2019-08-30 11:59:59','2019-08-30 15:59:59','HCETH','4h','0.012866000000000','0.012767000000000','1.819431630236426','1.805431651113668','141.41393053291046','141.413930532910456','test','test','0.76'),('2019-09-08 07:59:59','2019-09-08 11:59:59','HCETH','4h','0.012761000000000','0.012505780000000','1.816320523764702','1.779994113289408','142.3337139538204','142.333713953820393','test','test','2.00'),('2019-10-27 11:59:59','2019-11-08 15:59:59','HCETH','4h','0.008467000000000','0.009677000000000','1.808247988103526','2.066660656770736','213.56418898116516','213.564188981165159','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 03:59:59','HCETH','4h','0.009965000000000','0.010089000000000','1.865673025585128','1.888888625702795','187.2225815940921','187.222581594092105','test','test','0.0'),('2019-11-11 23:59:59','2019-11-13 19:59:59','HCETH','4h','0.010182000000000','0.010013000000000','1.870832047833499','1.839780131109490','183.73915221307197','183.739152213071975','test','test','1.66'),('2019-11-15 11:59:59','2019-11-15 15:59:59','HCETH','4h','0.010042000000000','0.009841160000000','1.863931621894830','1.826652989456933','185.61358513192886','185.613585131928858','test','test','2.00'),('2019-11-29 11:59:59','2019-11-29 15:59:59','HCETH','4h','0.008554000000000','0.008598000000000','1.855647481353075','1.865192546723607','216.9333038757394','216.933303875739398','test','test','0.0'),('2019-12-05 11:59:59','2019-12-05 15:59:59','HCETH','4h','0.008421000000000','0.008326000000000','1.857768606990971','1.836810523905335','220.6114009014334','220.611400901433399','test','test','1.12'),('2019-12-07 15:59:59','2019-12-07 19:59:59','HCETH','4h','0.008386000000000','0.008407000000000','1.853111255194163','1.857751767519357','220.97677739019352','220.976777390193519','test','test','0.0'),('2019-12-13 11:59:59','2019-12-13 15:59:59','HCETH','4h','0.008245000000000','0.008598000000000','1.854142480155317','1.933525414721093','224.88083446395592','224.880834463955921','test','test','0.0'),('2019-12-16 19:59:59','2019-12-17 03:59:59','HCETH','4h','0.008456000000000','0.008286880000000','1.871783132281045','1.834347469635424','221.3556211306817','221.355621130681698','test','test','2.00'),('2019-12-17 15:59:59','2019-12-20 15:59:59','HCETH','4h','0.008321000000000','0.008647000000000','1.863464096137573','1.936470861591346','223.9471332937836','223.947133293783594','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 23:59:59','HCETH','4h','0.008563000000000','0.008603000000000','1.879687821793967','1.888468332464498','219.5127667632801','219.512766763280098','test','test','0.70'),('2019-12-23 23:59:59','2019-12-26 19:59:59','HCETH','4h','0.008588000000000','0.008658000000000','1.881639046387419','1.896976113602967','219.1009602221028','219.100960222102799','test','test','0.0'),('2019-12-27 11:59:59','2019-12-27 15:59:59','HCETH','4h','0.008984000000000','0.008804320000000','1.885047283546430','1.847346337875501','209.82271633419742','209.822716334197423','test','test','1.99'),('2020-01-07 11:59:59','2020-01-08 19:59:59','HCETH','4h','0.008624000000000','0.008451520000000','1.876669295619556','1.839135909707165','217.6100760226758','217.610076022675798','test','test','2.00'),('2020-01-11 15:59:59','2020-01-11 19:59:59','HCETH','4h','0.008593000000000','0.008453000000000','1.868328543194581','1.837889116213638','217.42447843530556','217.424478435305559','test','test','1.62'),('2020-01-15 03:59:59','2020-01-15 15:59:59','HCETH','4h','0.009394000000000','0.009206120000000','1.861564226087704','1.824332941565950','198.1652359045885','198.165235904588513','test','test','1.99'),('2020-01-15 23:59:59','2020-01-16 03:59:59','HCETH','4h','0.009470000000000','0.009280600000000','1.853290607305093','1.816224795158991','195.70122569219564','195.701225692195635','test','test','1.99'),('2020-01-17 15:59:59','2020-01-18 15:59:59','HCETH','4h','0.009011000000000','0.008830780000000','1.845053760161514','1.808152684958284','204.7557163646115','204.755716364611487','test','test','2.00'),('2020-01-26 19:59:59','2020-01-28 23:59:59','HCETH','4h','0.008974000000000','0.008835000000000','1.836853521227463','1.808402146205108','204.68615123996696','204.686151239966961','test','test','1.57'),('2020-01-29 19:59:59','2020-01-30 07:59:59','HCETH','4h','0.008942000000000','0.008763160000000','1.830530993444717','1.793920373575823','204.7115850419053','204.711585041905295','test','test','1.99'),('2020-01-30 19:59:59','2020-01-30 23:59:59','HCETH','4h','0.008997000000000','0.008965000000000','1.822395300140519','1.815913511810576','202.55588531071675','202.555885310716747','test','test','0.35'),('2020-01-31 03:59:59','2020-02-04 11:59:59','HCETH','4h','0.008997000000000','0.009051000000000','1.820954902733865','1.831884275274448','202.39578778858117','202.395787788581174','test','test','0.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:37:27
