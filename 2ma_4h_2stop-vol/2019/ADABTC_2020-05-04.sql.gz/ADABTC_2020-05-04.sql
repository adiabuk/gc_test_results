-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000011280000000','0.000011970000000','0.033333333333333','0.035372340425532','2955.082742316785','2955.082742316784788','test','test','1.15'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033786446020489','0.033729757352669','2834.4333909805932','2834.433390980593231','test','test','0.16'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ADABTC','4h','0.000011830000000','0.000012010000000','0.033773848538751','0.034287736344074','2854.9322517963556','2854.932251796355558','test','test','0.0'),('2019-01-16 07:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012050000000','0.000012040000000','0.033888045828823','0.033859922969214','2812.2859608981466','2812.285960898146641','test','test','0.08'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.033881796304465','0.033631438203693','2781.7566752434404','2781.756675243440441','test','test','0.73'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.033826161170960','0.033468842567041','2977.655032654949','2977.655032654949082','test','test','1.05'),('2019-02-09 11:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011450000000','0.000011221000000','0.033746757036756','0.033071821896021','2947.315025044192','2947.315025044192225','test','test','2.00'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.033596771449926','0.033244665548267','2934.215847155109','2934.215847155108804','test','test','1.31'),('2019-02-16 15:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.033518525694002','0.033370736780007','2955.7782798943367','2955.778279894336720','test','test','0.44'),('2019-02-17 11:59:59','2019-02-17 15:59:59','ADABTC','4h','0.000011310000000','0.000011240000000','0.033485683713114','0.033278433681291','2960.714740328382','2960.714740328382049','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ADABTC','4h','0.000011340000000','0.000011540000000','0.033439628150487','0.034029392315399','2948.8208245579067','2948.820824557906690','test','test','0.0'),('2019-02-18 07:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011490000000','0.000011460000000','0.033570686853800','0.033483034929900','2921.7307966754083','2921.730796675408328','test','test','0.26'),('2019-02-23 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011730000000','0.000011495400000','0.033551208648489','0.032880184475519','2860.290592369083','2860.290592369082788','test','test','1.99'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.033402092165607','0.049553859399465','2969.0748591650763','2969.074859165076305','test','test','0.0'),('2019-04-02 15:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016830000000','0.000016860000000','0.036991373773131','0.037057312050801','2197.9425890155144','2197.942589015514386','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.037006026723724','0.036871581576681','3361.1286760875973','3361.128676087597341','test','test','0.36'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011260200000','0.036976150024382','0.036236627023894','3218.1157549505274','3218.115754950527389','test','test','2.00'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADABTC','4h','0.000010480000000','0.000010370000000','0.036811811579829','0.036425428061338','3512.577440823346','3512.577440823346024','test','test','1.04'),('2019-05-29 15:59:59','2019-05-30 19:59:59','ADABTC','4h','0.000010590000000','0.000010380000000','0.036725948575720','0.035997671975068','3467.9838126269647','3467.983812626964664','test','test','1.98'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADABTC','4h','0.000010580000000','0.000010710000000','0.036564109331130','0.037013384776598','3455.964965135182','3455.964965135181956','test','test','0.0'),('2019-06-06 23:59:59','2019-06-08 07:59:59','ADABTC','4h','0.000010670000000','0.000010650000000','0.036663948319012','0.036595224891985','3436.1713513600753','3436.171351360075278','test','test','0.65'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADABTC','4h','0.000010660000000','0.000010550000000','0.036648676446339','0.036270500610589','3437.9621431838023','3437.962143183802254','test','test','1.03'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADABTC','4h','0.000010640000000','0.000010980000000','0.036564637371728','0.037733056235110','3436.5260687714494','3436.526068771449445','test','test','0.0'),('2019-07-24 15:59:59','2019-07-24 19:59:59','ADABTC','4h','0.000005930000000','0.000005870000000','0.036824286008035','0.036451696267650','6209.829006414053','6209.829006414052856','test','test','1.01'),('2019-07-24 23:59:59','2019-07-25 03:59:59','ADABTC','4h','0.000006030000000','0.000005920000000','0.036741488287950','0.036071245549696','6093.115802313396','6093.115802313395761','test','test','1.82'),('2019-07-25 15:59:59','2019-07-31 07:59:59','ADABTC','4h','0.000005920000000','0.000006180000000','0.036592545457227','0.038199650494200','6181.173219126125','6181.173219126125332','test','test','0.33'),('2019-08-14 03:59:59','2019-08-14 15:59:59','ADABTC','4h','0.000004990000000','0.000004980000000','0.036949679909887','0.036875632455158','7404.745472923313','7404.745472923313173','test','test','1.80'),('2019-08-18 15:59:59','2019-08-19 07:59:59','ADABTC','4h','0.000004760000000','0.000004730000000','0.036933224919948','0.036700452493982','7759.0808655352','7759.080865535200246','test','test','0.63'),('2019-08-22 03:59:59','2019-08-23 15:59:59','ADABTC','4h','0.000004810000000','0.000004770000000','0.036881497714177','0.036574790872479','7667.671042448511','7667.671042448510889','test','test','1.45'),('2019-08-24 11:59:59','2019-08-26 03:59:59','ADABTC','4h','0.000004880000000','0.000004820000000','0.036813340638244','0.036360717597610','7543.717343902552','7543.717343902551875','test','test','1.22'),('2019-08-26 15:59:59','2019-08-26 19:59:59','ADABTC','4h','0.000004840000000','0.000004840000000','0.036712757740326','0.036712757740326','7585.280524860697','7585.280524860697369','test','test','0.0'),('2019-08-28 03:59:59','2019-08-28 11:59:59','ADABTC','4h','0.000004880000000','0.000004810000000','0.036712757740326','0.036186140313723','7523.106094329053','7523.106094329053121','test','test','1.43'),('2019-09-08 07:59:59','2019-09-08 15:59:59','ADABTC','4h','0.000004470000000','0.000004570000000','0.036595731645525','0.037414428102919','8186.964573942977','8186.964573942977040','test','test','0.22'),('2019-09-10 03:59:59','2019-09-11 11:59:59','ADABTC','4h','0.000004610000000','0.000004517800000','0.036777664191613','0.036042110907781','7977.801343083008','7977.801343083007851','test','test','1.99'),('2019-09-14 19:59:59','2019-09-22 11:59:59','ADABTC','4h','0.000004520000000','0.000004880000000','0.036614207906317','0.039530383757263','8100.488474848819','8100.488474848819351','test','test','0.88'),('2019-09-23 15:59:59','2019-09-23 23:59:59','ADABTC','4h','0.000004970000000','0.000004870600000','0.037262246984305','0.036517002044619','7497.434000866131','7497.434000866131100','test','test','2.00'),('2019-09-30 11:59:59','2019-09-30 15:59:59','ADABTC','4h','0.000004810000000','0.000004713800000','0.037096636997708','0.036354704257754','7712.398544221992','7712.398544221991870','test','test','2.00'),('2019-10-02 19:59:59','2019-10-02 23:59:59','ADABTC','4h','0.000004740000000','0.000004700000000','0.036931763055496','0.036620102607770','7791.511193142568','7791.511193142568118','test','test','0.84'),('2019-10-04 11:59:59','2019-10-09 15:59:59','ADABTC','4h','0.000004740000000','0.000004960000000','0.036862505178223','0.038573423140081','7776.899826629395','7776.899826629394738','test','test','0.0'),('2019-10-13 15:59:59','2019-10-15 19:59:59','ADABTC','4h','0.000004940000000','0.000004841200000','0.037242709169747','0.036497854986352','7539.009953390148','7539.009953390148439','test','test','1.99'),('2019-10-19 15:59:59','2019-10-19 19:59:59','ADABTC','4h','0.000004890000000','0.000004890000000','0.037077186017882','0.037077186017882','7582.2466294236765','7582.246629423676495','test','test','0.0'),('2019-10-23 15:59:59','2019-10-23 19:59:59','ADABTC','4h','0.000004860000000','0.000004840000000','0.037077186017882','0.036924605005463','7629.050620963329','7629.050620963328583','test','test','0.41'),('2019-10-24 03:59:59','2019-10-25 15:59:59','ADABTC','4h','0.000004880000000','0.000004860000000','0.037043279126233','0.036891462408503','7590.835886523178','7590.835886523177578','test','test','0.40'),('2019-11-04 19:59:59','2019-11-04 23:59:59','ADABTC','4h','0.000004620000000','0.000004600000000','0.037009542077849','0.036849327609980','8010.723393473737','8010.723393473736905','test','test','0.43'),('2019-11-05 03:59:59','2019-11-07 11:59:59','ADABTC','4h','0.000004730000000','0.000004690000000','0.036973938862767','0.036661262847014','7816.900393819591','7816.900393819591045','test','test','0.84'),('2019-11-08 15:59:59','2019-11-20 11:59:59','ADABTC','4h','0.000004730000000','0.000005100000000','0.036904455303710','0.039791273160448','7802.21042361743','7802.210423617430024','test','test','0.0'),('2019-11-22 15:59:59','2019-11-22 19:59:59','ADABTC','4h','0.000005100000000','0.000005180000000','0.037545970382986','0.038134926781150','7361.95497705599','7361.954977055989730','test','test','0.0'),('2019-11-24 19:59:59','2019-11-24 23:59:59','ADABTC','4h','0.000005090000000','0.000005070000000','0.037676849582578','0.037528806951605','7402.131548639991','7402.131548639990797','test','test','0.39'),('2019-11-25 03:59:59','2019-11-25 07:59:59','ADABTC','4h','0.000005080000000','0.000005060000000','0.037643951220139','0.037495746687776','7410.226618137619','7410.226618137618971','test','test','0.39'),('2019-11-25 11:59:59','2019-11-25 15:59:59','ADABTC','4h','0.000005100000000','0.000005080000000','0.037611016879614','0.037463522695772','7374.709192081175','7374.709192081175388','test','test','0.39'),('2019-11-26 15:59:59','2019-11-26 19:59:59','ADABTC','4h','0.000005120000000','0.000005070000000','0.037578240394316','0.037211265390465','7339.500077014799','7339.500077014798990','test','test','0.97'),('2019-11-27 11:59:59','2019-12-02 07:59:59','ADABTC','4h','0.000005200000000','0.000005230000000','0.037496690393460','0.037713017453422','7210.901998742307','7210.901998742307114','test','test','1.34'),('2019-12-13 11:59:59','2019-12-13 15:59:59','ADABTC','4h','0.000005150000000','0.000005120000000','0.037544763073452','0.037326055715743','7290.245256980884','7290.245256980883823','test','test','0.58'),('2019-12-13 23:59:59','2019-12-14 11:59:59','ADABTC','4h','0.000005140000000','0.000005070000000','0.037496161438405','0.036985513325431','7294.973042491267','7294.973042491266824','test','test','1.36'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADABTC','4h','0.000005130000000','0.000005130000000','0.037382684079966','0.037382684079966','7287.072920071431','7287.072920071431327','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:32:51
