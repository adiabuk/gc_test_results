-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-24 11:59:59','2019-05-24 15:59:59','RENBTC','4h','0.000004500000000','0.000004410000000','0.033333333333333','0.032666666666666','7407.407407407407','7407.407407407406936','test','test','1.99'),('2019-05-29 23:59:59','2019-05-30 03:59:59','RENBTC','4h','0.000004040000000','0.000004020000000','0.033185185185185','0.033020902090209','8214.154748808194','8214.154748808194199','test','test','0.49'),('2019-05-30 23:59:59','2019-06-14 03:59:59','RENBTC','4h','0.000004260000000','0.000005810000000','0.033148677830746','0.045209816478083','7781.379772475588','7781.379772475587743','test','test','0.0'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBTC','4h','0.000005820000000','0.000005703600000','0.035828930863488','0.035112352246218','6156.1736878844595','6156.173687884459468','test','test','2.00'),('2019-06-16 19:59:59','2019-06-17 11:59:59','RENBTC','4h','0.000005610000000','0.000005497800000','0.035669691170761','0.034956297347346','6358.233720278234','6358.233720278233704','test','test','2.00'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBTC','4h','0.000005450000000','0.000005341000000','0.035511159210002','0.034800936025802','6515.809029358164','6515.809029358163571','test','test','2.00'),('2019-06-22 15:59:59','2019-06-23 11:59:59','RENBTC','4h','0.000005430000000','0.000005400000000','0.035353331835735','0.035158009560399','6510.742511185143','6510.742511185142575','test','test','0.55'),('2019-06-26 15:59:59','2019-06-26 19:59:59','RENBTC','4h','0.000005510000000','0.000005399800000','0.035309926885661','0.034603728347948','6408.335187960194','6408.335187960194162','test','test','2.00'),('2019-06-26 23:59:59','2019-06-27 03:59:59','RENBTC','4h','0.000005420000000','0.000005311600000','0.035152993877280','0.034449933999734','6485.792228280443','6485.792228280442941','test','test','1.99'),('2019-06-27 07:59:59','2019-06-27 11:59:59','RENBTC','4h','0.000005640000000','0.000005527200000','0.034996758348936','0.034296823181957','6205.098998038376','6205.098998038375612','test','test','2.0'),('2019-06-27 19:59:59','2019-07-04 11:59:59','RENBTC','4h','0.000005710000000','0.000008320000000','0.034841217200719','0.050766887409804','6101.78935213991','6101.789352139910079','test','test','0.0'),('2019-07-04 19:59:59','2019-07-04 23:59:59','RENBTC','4h','0.000009380000000','0.000009192400000','0.038380255024960','0.037612649924461','4091.7116231300633','4091.711623130063344','test','test','1.99'),('2019-07-09 19:59:59','2019-07-10 03:59:59','RENBTC','4h','0.000008000000000','0.000008400000000','0.038209676113738','0.040120159919425','4776.209514217249','4776.209514217249307','test','test','0.0'),('2019-07-10 15:59:59','2019-07-13 03:59:59','RENBTC','4h','0.000007900000000','0.000008150000000','0.038634228070557','0.039856830224689','4890.408616526244','4890.408616526244259','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBTC','4h','0.000007760000000','0.000007604800000','0.038905917438142','0.038127799089379','5013.649154399771','5013.649154399770850','test','test','1.99'),('2019-07-19 23:59:59','2019-07-30 11:59:59','RENBTC','4h','0.000007810000000','0.000010690000000','0.038733002249528','0.053016106792248','4959.411299555469','4959.411299555468759','test','test','0.0'),('2019-08-02 11:59:59','2019-08-03 03:59:59','RENBTC','4h','0.000011380000000','0.000011152400000','0.041907025481244','0.041068884971619','3682.5154201444443','3682.515420144444306','test','test','2.00'),('2019-08-04 19:59:59','2019-08-05 19:59:59','RENBTC','4h','0.000011550000000','0.000011319000000','0.041720772034660','0.040886356593967','3612.1880549489556','3612.188054948955596','test','test','2.0'),('2019-08-05 23:59:59','2019-08-06 07:59:59','RENBTC','4h','0.000012070000000','0.000011828600000','0.041535346381173','0.040704639453550','3441.2051682827764','3441.205168282776413','test','test','2.00'),('2019-08-09 19:59:59','2019-08-09 23:59:59','RENBTC','4h','0.000010980000000','0.000010760400000','0.041350744841701','0.040523729944867','3766.0059054372796','3766.005905437279580','test','test','2.00'),('2019-08-15 23:59:59','2019-08-16 03:59:59','RENBTC','4h','0.000010240000000','0.000010035200000','0.041166963753516','0.040343624478446','4020.2113040542963','4020.211304054296306','test','test','2.00'),('2019-09-18 15:59:59','2019-09-18 19:59:59','RENBTC','4h','0.000004570000000','0.000004478600000','0.040983999470167','0.040164319480764','8968.052400474202','8968.052400474201932','test','test','1.99'),('2019-09-19 15:59:59','2019-09-22 23:59:59','RENBTC','4h','0.000004960000000','0.000004880000000','0.040801848361411','0.040143754033001','8226.179105123163','8226.179105123163026','test','test','1.61'),('2019-09-27 11:59:59','2019-09-27 23:59:59','RENBTC','4h','0.000004800000000','0.000004720000000','0.040655605177320','0.039978011757698','8469.917745274954','8469.917745274953631','test','test','1.66'),('2019-09-29 19:59:59','2019-09-30 03:59:59','RENBTC','4h','0.000005100000000','0.000004998000000','0.040505028861848','0.039694928284611','7942.162521931024','7942.162521931023548','test','test','2.00'),('2019-09-30 19:59:59','2019-10-01 03:59:59','RENBTC','4h','0.000004800000000','0.000004740000000','0.040325006511351','0.039820943929959','8401.043023198146','8401.043023198146329','test','test','1.24'),('2019-10-02 07:59:59','2019-10-02 19:59:59','RENBTC','4h','0.000005140000000','0.000005037200000','0.040212992604375','0.039408732752287','7823.539417193601','7823.539417193601366','test','test','2.00'),('2019-10-04 15:59:59','2019-10-16 15:59:59','RENBTC','4h','0.000005070000000','0.000006740000000','0.040034268192800','0.053221098149797','7896.3053634714','7896.305363471399687','test','test','0.0'),('2019-10-20 15:59:59','2019-10-20 19:59:59','RENBTC','4h','0.000006970000000','0.000006830600000','0.042964674849910','0.042105381352912','6164.22881634296','6164.228816342960272','test','test','1.99'),('2019-10-21 07:59:59','2019-10-21 11:59:59','RENBTC','4h','0.000006830000000','0.000006820000000','0.042773720739466','0.042711094501194','6262.623827154676','6262.623827154676292','test','test','0.14'),('2019-10-22 11:59:59','2019-10-23 15:59:59','RENBTC','4h','0.000006970000000','0.000006830600000','0.042759803797628','0.041904607721675','6134.835552027004','6134.835552027004269','test','test','1.99'),('2019-10-24 07:59:59','2019-10-25 15:59:59','RENBTC','4h','0.000007030000000','0.000006889400000','0.042569760225194','0.041718365020690','6055.442421791497','6055.442421791496599','test','test','1.99'),('2019-11-06 15:59:59','2019-11-07 07:59:59','RENBTC','4h','0.000006360000000','0.000006232800000','0.042380561290860','0.041532950065043','6663.61026585849','6663.610265858489583','test','test','2.00'),('2019-11-09 19:59:59','2019-11-10 19:59:59','RENBTC','4h','0.000006450000000','0.000006321000000','0.042192203240678','0.041348359175864','6541.4268590199135','6541.426859019913536','test','test','1.99'),('2019-11-11 11:59:59','2019-11-17 07:59:59','RENBTC','4h','0.000006360000000','0.000006610000000','0.042004682337386','0.043655809787755','6604.509801475855','6604.509801475855056','test','test','0.0'),('2019-11-17 15:59:59','2019-11-17 23:59:59','RENBTC','4h','0.000006570000000','0.000006580000000','0.042371599548580','0.042436092089750','6449.254116983189','6449.254116983189306','test','test','0.45'),('2019-11-23 19:59:59','2019-11-23 23:59:59','RENBTC','4h','0.000006410000000','0.000006420000000','0.042385931224395','0.042452055922093','6612.469769796429','6612.469769796429318','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','RENBTC','4h','0.000005310000000','0.000005203800000','0.042400625601661','0.041552613089628','7985.051902384431','7985.051902384430832','test','test','1.99'),('2019-12-15 07:59:59','2019-12-15 11:59:59','RENBTC','4h','0.000005010000000','0.000004970000000','0.042212178376765','0.041875154996511','8425.584506340341','8425.584506340341250','test','test','0.79'),('2019-12-15 23:59:59','2019-12-16 07:59:59','RENBTC','4h','0.000005050000000','0.000004949000000','0.042137284292264','0.041294538606419','8344.016691537468','8344.016691537468432','test','test','2.00'),('2019-12-24 15:59:59','2019-12-25 15:59:59','RENBTC','4h','0.000004810000000','0.000004713800000','0.041950007473188','0.041111007323724','8721.415275090969','8721.415275090968862','test','test','2.00'),('2019-12-31 11:59:59','2019-12-31 15:59:59','RENBTC','4h','0.000004500000000','0.000004480000000','0.041763562995529','0.041577947159993','9280.791776784197','9280.791776784197282','test','test','0.44'),('2020-01-02 03:59:59','2020-01-05 03:59:59','RENBTC','4h','0.000004540000000','0.000004670000000','0.041722315032076','0.042917006872202','9189.937231734899','9189.937231734898887','test','test','0.66'),('2020-01-06 07:59:59','2020-01-07 19:59:59','RENBTC','4h','0.000005100000000','0.000004998000000','0.041987802107660','0.041148046065507','8232.90237405098','8232.902374050980143','test','test','2.00'),('2020-01-08 19:59:59','2020-01-08 23:59:59','RENBTC','4h','0.000005090000000','0.000004988200000','0.041801189653848','0.040965165860771','8212.41447030417','8212.414470304169299','test','test','2.00'),('2020-01-09 03:59:59','2020-01-13 07:59:59','RENBTC','4h','0.000005090000000','0.000005400000000','0.041615406588720','0.044149940192355','8175.914850436149','8175.914850436149209','test','test','1.17'),('2020-01-26 07:59:59','2020-01-26 11:59:59','RENBTC','4h','0.000004930000000','0.000004890000000','0.042178636278417','0.041836416105773','8555.504316108858','8555.504316108857893','test','test','0.81'),('2020-02-02 15:59:59','2020-02-02 19:59:59','RENBTC','4h','0.000004770000000','0.000004890000000','0.042102587351162','0.043161771938613','8826.538228755231','8826.538228755231103','test','test','0.0'),('2020-02-02 23:59:59','2020-02-10 11:59:59','RENBTC','4h','0.000004950000000','0.000005710000000','0.042337961703929','0.048838335622108','8553.12357655138','8553.123576551379301','test','test','1.41'),('2020-02-11 19:59:59','2020-02-11 23:59:59','RENBTC','4h','0.000006050000000','0.000005929000000','0.043782489241302','0.042906839456476','7236.775081207017','7236.775081207017138','test','test','2.00'),('2020-02-12 03:59:59','2020-02-16 15:59:59','RENBTC','4h','0.000005920000000','0.000005840000000','0.043587900400230','0.042998874719146','7362.821013552365','7362.821013552365002','test','test','1.35');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:47:26
