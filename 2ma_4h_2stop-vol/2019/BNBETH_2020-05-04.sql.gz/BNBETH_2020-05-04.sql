-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 11:59:59','2019-01-30 15:59:59','BNBETH','4h','0.043388000000000','0.056441000000000','1.297777777777778','1.688205853128873','29.910984091863593','29.910984091863593','test','test','0.0'),('2019-02-01 07:59:59','2019-02-13 23:59:59','BNBETH','4h','0.061007000000000','0.073157000000000','1.384539572300243','1.660280975802267','22.694765720331162','22.694765720331162','test','test','0.0'),('2019-02-15 03:59:59','2019-02-17 03:59:59','BNBETH','4h','0.074730000000000','0.073235400000000','1.445815439745137','1.416899130950234','19.34718907728004','19.347189077280039','test','test','1.99'),('2019-02-19 19:59:59','2019-02-20 19:59:59','BNBETH','4h','0.074288000000000','0.072802240000000','1.439389593346270','1.410601801479344','19.37580219343999','19.375802193439991','test','test','2.00'),('2019-02-24 23:59:59','2019-02-25 03:59:59','BNBETH','4h','0.075142000000000','0.073639160000000','1.432992306264731','1.404332460139436','19.070457350945293','19.070457350945293','test','test','2.00'),('2019-02-25 11:59:59','2019-02-25 15:59:59','BNBETH','4h','0.072196000000000','0.071733000000000','1.426623451570221','1.417474376024803','19.76042234431577','19.760422344315771','test','test','0.64'),('2019-02-27 23:59:59','2019-03-16 07:59:59','BNBETH','4h','0.072951000000000','0.108480000000000','1.424590323671239','2.118402192044742','19.528043805722188','19.528043805722188','test','test','1.00'),('2019-03-16 11:59:59','2019-03-19 15:59:59','BNBETH','4h','0.111620000000000','0.111646000000000','1.578770738865351','1.579138486932100','14.144156413414724','14.144156413414724','test','test','0.42'),('2019-03-24 11:59:59','2019-03-26 07:59:59','BNBETH','4h','0.124743000000000','0.122248140000000','1.578852460657962','1.547275411444803','12.656842152729707','12.656842152729707','test','test','2.00'),('2019-03-31 03:59:59','2019-04-02 23:59:59','BNBETH','4h','0.121413000000000','0.120740000000000','1.571835338610594','1.563122555112246','12.946186476000047','12.946186476000047','test','test','0.55'),('2019-04-04 19:59:59','2019-04-05 07:59:59','BNBETH','4h','0.122672000000000','0.120218560000000','1.569899164499849','1.538501181209852','12.797534600396581','12.797534600396581','test','test','2.00'),('2019-04-12 19:59:59','2019-04-13 03:59:59','BNBETH','4h','0.111895000000000','0.110279000000000','1.562921834879850','1.540349944400688','13.967754009382459','13.967754009382459','test','test','1.44'),('2019-04-13 11:59:59','2019-04-18 03:59:59','BNBETH','4h','0.111510000000000','0.113702000000000','1.557905859217814','1.588530284322338','13.970996854253556','13.970996854253556','test','test','0.0'),('2019-04-18 07:59:59','2019-04-24 07:59:59','BNBETH','4h','0.120381000000000','0.131157000000000','1.564711287018819','1.704777649890990','12.99799210023857','12.997992100238569','test','test','0.0'),('2019-04-24 11:59:59','2019-04-30 03:59:59','BNBETH','4h','0.134610000000000','0.138262000000000','1.595837145434857','1.639132571147123','11.85526443380772','11.855264433807720','test','test','0.0'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BNBETH','4h','0.138448000000000','0.139236000000000','1.605458351148694','1.614596086476797','11.596110822465436','11.596110822465436','test','test','0.0'),('2019-05-02 11:59:59','2019-05-03 11:59:59','BNBETH','4h','0.141443000000000','0.140481000000000','1.607488958999384','1.596555902018427','11.36492409662821','11.364924096628210','test','test','0.68'),('2019-05-03 23:59:59','2019-05-04 03:59:59','BNBETH','4h','0.140953000000000','0.139561000000000','1.605059390781393','1.589208414413613','11.38719566650865','11.387195666508649','test','test','0.98'),('2019-05-18 19:59:59','2019-05-19 03:59:59','BNBETH','4h','0.116093000000000','0.114000000000000','1.601536951588553','1.572663403315403','13.795293011538623','13.795293011538623','test','test','1.80'),('2019-05-20 23:59:59','2019-05-21 03:59:59','BNBETH','4h','0.116999000000000','0.114659020000000','1.595120607527853','1.563218195377296','13.633625992767916','13.633625992767916','test','test','2.00'),('2019-05-21 15:59:59','2019-05-26 23:59:59','BNBETH','4h','0.124170000000000','0.125118000000000','1.588031182605507','1.600155315335716','12.789169546633707','12.789169546633707','test','test','0.57'),('2019-05-27 03:59:59','2019-05-27 15:59:59','BNBETH','4h','0.128441000000000','0.126001000000000','1.590725434323332','1.560506344937941','12.384872698930495','12.384872698930495','test','test','1.89'),('2019-06-01 23:59:59','2019-06-02 03:59:59','BNBETH','4h','0.125969000000000','0.123630000000000','1.584010081126578','1.554598086272645','12.574602331737001','12.574602331737001','test','test','1.85'),('2019-06-04 11:59:59','2019-06-04 15:59:59','BNBETH','4h','0.124561000000000','0.123617000000000','1.577474082270149','1.565519011793330','12.664269572901217','12.664269572901217','test','test','0.75'),('2019-06-06 03:59:59','2019-06-14 07:59:59','BNBETH','4h','0.126974000000000','0.131103000000000','1.574817399941966','1.626028049715623','12.402676137964987','12.402676137964987','test','test','1.51'),('2019-06-18 03:59:59','2019-06-21 03:59:59','BNBETH','4h','0.128230000000000','0.130000000000000','1.586197544336112','1.608092340042849','12.369941077252689','12.369941077252689','test','test','0.0'),('2019-06-21 15:59:59','2019-06-21 19:59:59','BNBETH','4h','0.131411000000000','0.128840000000000','1.591063054493165','1.559934586456989','12.107533269613391','12.107533269613391','test','test','1.95'),('2019-06-21 23:59:59','2019-06-22 03:59:59','BNBETH','4h','0.131288000000000','0.128662240000000','1.584145617151792','1.552462704808756','12.066187444029863','12.066187444029863','test','test','2.00'),('2019-07-04 23:59:59','2019-07-05 03:59:59','BNBETH','4h','0.116810000000000','0.115648000000000','1.577104969964451','1.561416279140903','13.5014550977181','13.501455097718100','test','test','0.99'),('2019-07-12 03:59:59','2019-07-25 03:59:59','BNBETH','4h','0.114090000000000','0.132219000000000','1.573618594225885','1.823667954333879','13.79278284009015','13.792782840090149','test','test','0.0'),('2019-07-27 11:59:59','2019-07-28 07:59:59','BNBETH','4h','0.133344000000000','0.131584000000000','1.629185118694328','1.607681595409426','12.217910957330878','12.217910957330878','test','test','1.31'),('2019-08-01 11:59:59','2019-08-02 03:59:59','BNBETH','4h','0.131630000000000','0.130976000000000','1.624406557964350','1.616335739086369','12.340701648289523','12.340701648289523','test','test','0.49'),('2019-08-07 19:59:59','2019-08-18 15:59:59','BNBETH','4h','0.133648000000000','0.144352000000000','1.622613042658132','1.752569719964285','12.14094518928927','12.140945189289271','test','test','1.82'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBETH','4h','0.143887000000000','0.143865000000000','1.651492304281722','1.651239794807661','11.477703366403649','11.477703366403649','test','test','0.33'),('2019-08-21 03:59:59','2019-08-22 03:59:59','BNBETH','4h','0.143400000000000','0.143184000000000','1.651436191065264','1.648948672116379','11.516291430022758','11.516291430022758','test','test','0.15'),('2019-09-05 19:59:59','2019-09-05 23:59:59','BNBETH','4h','0.133079000000000','0.130417420000000','1.650883409076622','1.617865740895090','12.405288656186343','12.405288656186343','test','test','1.99'),('2019-09-06 23:59:59','2019-09-07 03:59:59','BNBETH','4h','0.130289000000000','0.130426000000000','1.643546149480726','1.645274352341128','12.614619418989527','12.614619418989527','test','test','0.0'),('2019-10-09 07:59:59','2019-10-09 15:59:59','BNBETH','4h','0.093589000000000','0.091717220000000','1.643930194560816','1.611051590669600','17.56542109180369','17.565421091803689','test','test','2.00'),('2019-10-09 23:59:59','2019-10-10 03:59:59','BNBETH','4h','0.092067000000000','0.090997000000000','1.636623838140546','1.617603043427887','17.77644365669073','17.776443656690731','test','test','1.16'),('2019-10-11 11:59:59','2019-10-11 15:59:59','BNBETH','4h','0.091645000000000','0.091498000000000','1.632396994871066','1.629778604798001','17.812177367789467','17.812177367789467','test','test','0.16'),('2019-10-12 19:59:59','2019-10-24 07:59:59','BNBETH','4h','0.096199000000000','0.103161000000000','1.631815130410385','1.749910920781565','16.96291157299332','16.962911572993320','test','test','0.60'),('2019-10-25 03:59:59','2019-10-25 19:59:59','BNBETH','4h','0.106911000000000','0.104772780000000','1.658058639381758','1.624897466594123','15.50877495656909','15.508774956569090','test','test','1.99'),('2019-10-26 03:59:59','2019-10-26 07:59:59','BNBETH','4h','0.103708000000000','0.102166000000000','1.650689489873395','1.626145933027397','15.916703531775706','15.916703531775706','test','test','1.48'),('2019-10-28 03:59:59','2019-10-29 19:59:59','BNBETH','4h','0.111132000000000','0.108909360000000','1.645235366129840','1.612330658807243','14.804335080173484','14.804335080173484','test','test','1.99'),('2019-10-31 11:59:59','2019-11-05 15:59:59','BNBETH','4h','0.110461000000000','0.108555000000000','1.637923208947040','1.609660911518508','14.828067905840433','14.828067905840433','test','test','1.72'),('2019-11-11 23:59:59','2019-11-12 03:59:59','BNBETH','4h','0.108600000000000','0.109105000000000','1.631642698407367','1.639229987198304','15.024334239478513','15.024334239478513','test','test','0.0'),('2019-11-12 07:59:59','2019-11-16 11:59:59','BNBETH','4h','0.109271000000000','0.110842000000000','1.633328762583130','1.656811292129104','14.947504485024668','14.947504485024668','test','test','0.0'),('2019-11-24 07:59:59','2019-11-24 11:59:59','BNBETH','4h','0.107656000000000','0.106797000000000','1.638547102482235','1.625472940698105','15.220211622967929','15.220211622967929','test','test','0.79'),('2019-12-04 11:59:59','2019-12-04 15:59:59','BNBETH','4h','0.104297000000000','0.104092000000000','1.635641733196873','1.632426812774374','15.682538646335688','15.682538646335688','test','test','0.19'),('2019-12-05 03:59:59','2019-12-06 11:59:59','BNBETH','4h','0.105446000000000','0.104906000000000','1.634927306436318','1.626554672619240','15.504877439033422','15.504877439033422','test','test','0.76'),('2019-12-06 15:59:59','2019-12-08 03:59:59','BNBETH','4h','0.105118000000000','0.104823000000000','1.633066721143634','1.628483731715207','15.535557384497745','15.535557384497745','test','test','0.28'),('2019-12-18 11:59:59','2019-12-18 19:59:59','BNBETH','4h','0.103794000000000','0.102347000000000','1.632048279048428','1.609295770620358','15.723917365632195','15.723917365632195','test','test','1.39'),('2019-12-19 11:59:59','2019-12-22 11:59:59','BNBETH','4h','0.104980000000000','0.103542000000000','1.626992166064412','1.604705875963434','15.498115508329324','15.498115508329324','test','test','1.36'),('2019-12-22 15:59:59','2019-12-22 19:59:59','BNBETH','4h','0.103843000000000','0.103529000000000','1.622039657153084','1.617134940876146','15.620115531649546','15.620115531649546','test','test','0.30'),('2019-12-23 15:59:59','2019-12-23 19:59:59','BNBETH','4h','0.103788000000000','0.104312000000000','1.620949720202653','1.629133495334520','15.617891473028225','15.617891473028225','test','test','0.0'),('2019-12-25 03:59:59','2019-12-26 19:59:59','BNBETH','4h','0.104962000000000','0.103488000000000','1.622768336898624','1.599979513052007','15.460531781965127','15.460531781965127','test','test','1.40'),('2019-12-26 23:59:59','2019-12-29 19:59:59','BNBETH','4h','0.104535000000000','0.104526000000000','1.617704153821598','1.617564876666727','15.475239430062636','15.475239430062636','test','test','0.20'),('2019-12-30 03:59:59','2019-12-30 23:59:59','BNBETH','4h','0.106623000000000','0.105284000000000','1.617673203342737','1.597358032889121','15.171897276785849','15.171897276785849','test','test','1.25'),('2019-12-31 15:59:59','2020-01-01 11:59:59','BNBETH','4h','0.105931000000000','0.104850000000000','1.613158721019712','1.596696830001763','15.228391320951486','15.228391320951486','test','test','1.02');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:18:46
