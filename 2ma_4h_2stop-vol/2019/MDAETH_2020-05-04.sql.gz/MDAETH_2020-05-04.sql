-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005769946000000','1.297777777777778','1.271822222222222','220.4218587526161','220.421858752616089','test','test','2.00'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','1.292009876543210','1.303342715162799','220.91303352025471','220.913033520254714','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','1.294528285125341','1.376809465118382','217.10073876791785','217.100738767917846','test','test','0.66'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','1.312812991790461','1.310621382682091','195.67938467587734','195.679384675877344','test','test','1.31'),('2019-02-23 07:59:59','2019-02-23 15:59:59','MDAETH','4h','0.006221500000000','0.006097070000000','1.312325967544157','1.286079448193274','210.93401391049693','210.934013910496930','test','test','2.00'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','1.306493407688405','1.364586165746667','212.01736517613918','212.017365176139180','test','test','0.04'),('2019-03-07 19:59:59','2019-03-08 03:59:59','MDAETH','4h','0.006495600000000','0.006365688000000','1.319402909479130','1.293014851289547','203.12256134600804','203.122561346008041','test','test','2.00'),('2019-03-08 07:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006430000000000','0.006344300000000','1.313538896548111','1.296031854023356','204.28287660157247','204.282876601572468','test','test','1.33'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MDAETH','4h','0.006945000000000','0.006806100000000','1.309648442653721','1.283455473800647','188.57428979895192','188.574289798951924','test','test','1.99'),('2019-03-10 03:59:59','2019-03-10 07:59:59','MDAETH','4h','0.007412900000000','0.007264642000000','1.303827782908594','1.277751227250422','175.88633097823976','175.886330978239755','test','test','2.00'),('2019-03-10 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.007617800000000','0.007465444000000','1.298032992762333','1.272072332907086','170.39473243749285','170.394732437492848','test','test','2.00'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.007998172000000','1.292263957238945','1.266418678094166','158.33851511247397','158.338515112473971','test','test','1.99'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDAETH','4h','0.008747000000000','0.008572060000000','1.286520561873438','1.260790150635969','147.08134924813518','147.081349248135183','test','test','2.00'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.007935256000000','1.280802692709556','1.255186638855365','158.17846820006375','158.178468200063747','test','test','2.00'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDAETH','4h','0.007632700000000','0.008177000000000','1.275110236297514','1.366040379184924','167.0588699015439','167.058869901543886','test','test','0.0'),('2019-03-29 15:59:59','2019-03-29 23:59:59','MDAETH','4h','0.008488100000000','0.008318338000000','1.295316934716938','1.269410596022599','152.60387303600788','152.603873036007883','test','test','2.00'),('2019-03-30 03:59:59','2019-03-30 23:59:59','MDAETH','4h','0.008653900000000','0.008480822000000','1.289559970562641','1.263768771151388','149.01489161680175','149.014891616801748','test','test','2.00'),('2019-03-31 07:59:59','2019-04-02 07:59:59','MDAETH','4h','0.008552600000000','0.008505600000000','1.283828592915696','1.276773434967582','150.10974357688838','150.109743576888377','test','test','1.25'),('2019-05-23 15:59:59','2019-05-23 19:59:59','MDAETH','4h','0.004172600000000','0.004089148000000','1.282260780038337','1.256615564437570','307.30498491068806','307.304984910688063','test','test','2.00'),('2019-06-02 11:59:59','2019-06-03 03:59:59','MDAETH','4h','0.003860000000000','0.003816600000000','1.276561843238167','1.262208790389323','330.71550342957687','330.715503429576870','test','test','1.12'),('2019-06-03 15:59:59','2019-06-03 23:59:59','MDAETH','4h','0.003849800000000','0.003842300000000','1.273372275938424','1.270891551726897','330.76322820365306','330.763228203653057','test','test','0.19'),('2019-06-05 19:59:59','2019-06-06 15:59:59','MDAETH','4h','0.004007800000000','0.003927644000000','1.272821003891418','1.247364583813590','317.585958354064','317.585958354064019','test','test','2.00'),('2019-06-06 19:59:59','2019-06-07 07:59:59','MDAETH','4h','0.003950200000000','0.003929700000000','1.267164021651900','1.260587933746512','320.7847758725888','320.784775872588796','test','test','0.51'),('2019-06-07 15:59:59','2019-06-12 15:59:59','MDAETH','4h','0.003972000000000','0.004050900000000','1.265702668784036','1.290844647778764','318.65626102317134','318.656261023171339','test','test','1.32'),('2019-07-03 19:59:59','2019-07-03 23:59:59','MDAETH','4h','0.003031800000000','0.002971164000000','1.271289775227309','1.245863979722763','419.3184824946597','419.318482494659690','test','test','2.00'),('2019-07-07 07:59:59','2019-07-07 11:59:59','MDAETH','4h','0.002951500000000','0.002941000000000','1.265639598448521','1.261137068960562','428.8123321865225','428.812332186522497','test','test','0.35'),('2019-07-07 15:59:59','2019-07-07 19:59:59','MDAETH','4h','0.003012800000000','0.002952544000000','1.264639036340086','1.239346255613284','419.75538911978424','419.755389119784240','test','test','1.99'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDAETH','4h','0.003124000000000','0.003061520000000','1.259018418400797','1.233838050032781','403.0148586430207','403.014858643020716','test','test','2.00'),('2019-07-13 19:59:59','2019-07-13 23:59:59','MDAETH','4h','0.002919100000000','0.002860718000000','1.253422780985682','1.228354325365968','429.3867222725093','429.386722272509303','test','test','2.00'),('2019-07-14 15:59:59','2019-07-14 23:59:59','MDAETH','4h','0.002881100000000','0.002850700000000','1.247852013070190','1.234685270785183','433.11652253312616','433.116522533126158','test','test','1.05'),('2019-07-15 19:59:59','2019-07-18 11:59:59','MDAETH','4h','0.002959900000000','0.002966800000000','1.244926070340188','1.247828191994753','420.59734124132177','420.597341241321772','test','test','1.93'),('2019-07-19 11:59:59','2019-07-19 19:59:59','MDAETH','4h','0.002984600000000','0.002924908000000','1.245570986263425','1.220659566538157','417.332636287417','417.332636287417017','test','test','2.00'),('2019-07-20 19:59:59','2019-07-20 23:59:59','MDAETH','4h','0.002930000000000','0.002931600000000','1.240035115213366','1.240712267494711','423.2201758407391','423.220175840739103','test','test','0.0'),('2019-07-22 15:59:59','2019-07-24 23:59:59','MDAETH','4h','0.003016900000000','0.003019700000000','1.240185593498109','1.241336615958845','411.0794502628886','411.079450262888599','test','test','0.0'),('2019-07-26 11:59:59','2019-07-26 15:59:59','MDAETH','4h','0.003019400000000','0.003016000000000','1.240441376267161','1.239044575353301','410.82379819406543','410.823798194065432','test','test','0.11'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDAETH','4h','0.003285100000000','0.003219398000000','1.240130976064081','1.215328356542799','377.501743041028','377.501743041028021','test','test','1.99'),('2019-07-28 07:59:59','2019-07-29 15:59:59','MDAETH','4h','0.003106300000000','0.003044174000000','1.234619282837130','1.209926897180387','397.45655050611003','397.456550506110034','test','test','2.00'),('2019-07-30 19:59:59','2019-07-31 07:59:59','MDAETH','4h','0.003187500000000','0.003123750000000','1.229132086024520','1.204549444304030','385.610066203771','385.610066203770998','test','test','2.00'),('2019-08-01 19:59:59','2019-08-03 07:59:59','MDAETH','4h','0.003181000000000','0.003117380000000','1.223669276753300','1.199195891218234','384.6806905857592','384.680690585759180','test','test','1.99'),('2019-08-03 15:59:59','2019-08-05 03:59:59','MDAETH','4h','0.003350000000000','0.003283000000000','1.218230746634396','1.193866131701708','363.65096914459593','363.650969144595933','test','test','2.00'),('2019-08-09 11:59:59','2019-08-09 15:59:59','MDAETH','4h','0.003191700000000','0.003165200000000','1.212816387760466','1.202746633624535','379.99072211062','379.990722110620027','test','test','0.83'),('2019-08-14 19:59:59','2019-08-14 23:59:59','MDAETH','4h','0.003215700000000','0.003151386000000','1.210578664619148','1.186367091326765','376.4588315511857','376.458831551185710','test','test','2.00'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MDAETH','4h','0.003298300000000','0.003232334000000','1.205198314998618','1.181094348698646','365.3998468904035','365.399846890403524','test','test','2.00'),('2019-08-16 15:59:59','2019-08-16 19:59:59','MDAETH','4h','0.003210700000000','0.003146486000000','1.199841878043069','1.175845040482208','373.7010240891609','373.701024089160910','test','test','1.99'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDAETH','4h','0.003568200000000','0.003496836000000','1.194509247473989','1.170619062524509','334.76521704892906','334.765217048929060','test','test','1.99'),('2019-08-21 07:59:59','2019-08-22 03:59:59','MDAETH','4h','0.003528800000000','0.003458224000000','1.189200317485215','1.165416311135511','336.9985030280025','336.998503028002517','test','test','2.00'),('2019-08-23 19:59:59','2019-08-23 23:59:59','MDAETH','4h','0.003565500000000','0.003494190000000','1.183914982740837','1.160236683086020','332.04739384121063','332.047393841210635','test','test','2.00'),('2019-08-25 19:59:59','2019-08-25 23:59:59','MDAETH','4h','0.003591900000000','0.003520062000000','1.178653138373100','1.155080075605638','328.14196897828435','328.141968978284353','test','test','1.99'),('2019-08-26 15:59:59','2019-08-28 07:59:59','MDAETH','4h','0.003508200000000','0.003438036000000','1.173414679980330','1.149946386380723','334.4777036600907','334.477703660090697','test','test','2.00'),('2019-08-31 19:59:59','2019-08-31 23:59:59','MDAETH','4h','0.003523000000000','0.003476400000000','1.168199503624862','1.152747304683926','331.59225195142267','331.592251951422668','test','test','1.32'),('2019-09-01 11:59:59','2019-09-01 23:59:59','MDAETH','4h','0.003471000000000','0.003450000000000','1.164765681637987','1.157718698257290','335.57063717602625','335.570637176026253','test','test','0.60'),('2019-09-02 11:59:59','2019-09-02 15:59:59','MDAETH','4h','0.003446600000000','0.003397600000000','1.163199685331166','1.146662580769793','337.49192982393254','337.491929823932537','test','test','1.42'),('2019-09-04 19:59:59','2019-09-04 23:59:59','MDAETH','4h','0.003475900000000','0.003406382000000','1.159524773206416','1.136334277742288','333.58979637113157','333.589796371131570','test','test','2.00'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDAETH','4h','0.003538600000000','0.003490100000000','1.154371329769943','1.138549533157203','326.22261057196164','326.222610571961638','test','test','1.37'),('2019-09-24 19:59:59','2019-10-07 23:59:59','MDAETH','4h','0.003246700000000','0.005117600000000','1.150855374967112','1.814031929938612','354.4692687858787','354.469268785878683','test','test','1.22'),('2019-10-11 19:59:59','2019-10-11 23:59:59','MDAETH','4h','0.005774200000000','0.005658716000000','1.298227942738557','1.272263383883786','224.8325209965981','224.832520996598106','test','test','1.99'),('2019-10-12 23:59:59','2019-10-13 11:59:59','MDAETH','4h','0.006224000000000','0.006099520000000','1.292458040770830','1.266608879955413','207.65714022667575','207.657140226675750','test','test','1.99'),('2019-10-13 15:59:59','2019-10-13 19:59:59','MDAETH','4h','0.006421900000000','0.006293462000000','1.286713782811848','1.260979507155611','200.36341002068679','200.363410020686786','test','test','1.99'),('2019-10-14 15:59:59','2019-10-15 15:59:59','MDAETH','4h','0.006517700000000','0.006387346000000','1.280995054888240','1.255375153790475','196.54096612121452','196.540966121214524','test','test','2.00'),('2019-10-25 23:59:59','2019-10-26 03:59:59','MDAETH','4h','0.004694400000000','0.004600512000000','1.275301743533181','1.249795708662517','271.6644818364821','271.664481836482082','test','test','2.00'),('2019-10-27 23:59:59','2019-10-28 03:59:59','MDAETH','4h','0.004637300000000','0.004544554000000','1.269633735784145','1.244241061068462','273.7872761702165','273.787276170216501','test','test','2.00'),('2019-11-09 23:59:59','2019-11-10 19:59:59','MDAETH','4h','0.004107700000000','0.004106300000000','1.263990919180660','1.263560121584231','307.7125688781215','307.712568878121488','test','test','1.73'),('2019-11-11 07:59:59','2019-11-11 11:59:59','MDAETH','4h','0.004107800000000','0.004025644000000','1.263895186381453','1.238617282653824','307.6817728179204','307.681772817920375','test','test','1.99'),('2019-11-22 15:59:59','2019-11-25 11:59:59','MDAETH','4h','0.003867400000000','0.003820100000000','1.258277874441980','1.242888583584788','325.35498640998605','325.354986409986054','test','test','1.22'),('2019-11-25 19:59:59','2019-11-26 23:59:59','MDAETH','4h','0.003929600000000','0.003940800000000','1.254858032029271','1.258434581794827','319.33480049604816','319.334800496048160','test','test','0.92'),('2019-11-27 19:59:59','2019-11-28 03:59:59','MDAETH','4h','0.003971400000000','0.003891972000000','1.255652820866061','1.230539764448740','316.1738482313695','316.173848231369504','test','test','1.99'),('2019-11-29 19:59:59','2019-11-30 11:59:59','MDAETH','4h','0.003957800000000','0.003900700000000','1.250072141662212','1.232037092066752','315.85025561226234','315.850255612262345','test','test','1.44'),('2019-11-30 19:59:59','2019-11-30 23:59:59','MDAETH','4h','0.003917000000000','0.003908100000000','1.246064352863221','1.243233111418114','318.11701630411557','318.117016304115566','test','test','0.22'),('2019-12-01 03:59:59','2019-12-01 07:59:59','MDAETH','4h','0.003923400000000','0.003877000000000','1.245435188097642','1.230706077446745','317.437729545201','317.437729545201023','test','test','1.18'),('2019-12-01 11:59:59','2019-12-01 15:59:59','MDAETH','4h','0.003940700000000','0.003861886000000','1.242162052397442','1.217318811349493','315.2135540379735','315.213554037973495','test','test','1.99'),('2019-12-09 15:59:59','2019-12-09 23:59:59','MDAETH','4h','0.003756300000000','0.003681174000000','1.236641332164565','1.211908505521274','329.2179357784428','329.217935778442779','test','test','2.00'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDAETH','4h','0.003787200000000','0.003711456000000','1.231145148466056','1.206522245496735','325.08057363383386','325.080573633833865','test','test','1.99'),('2019-12-16 19:59:59','2019-12-22 11:59:59','MDAETH','4h','0.003712800000000','0.003806900000000','1.225673392250651','1.256737781986373','330.1210386367838','330.121038636783794','test','test','0.34'),('2019-12-23 07:59:59','2019-12-23 11:59:59','MDAETH','4h','0.003826200000000','0.003760900000000','1.232576589969700','1.211540770795318','322.1411818435262','322.141181843526226','test','test','1.70'),('2019-12-24 07:59:59','2019-12-24 11:59:59','MDAETH','4h','0.003826200000000','0.003797200000000','1.227901963486504','1.218595299710144','320.9194405641378','320.919440564137801','test','test','0.75'),('2019-12-24 15:59:59','2019-12-24 19:59:59','MDAETH','4h','0.003834100000000','0.003834100000000','1.225833815980646','1.225833815980646','319.71879084547777','319.718790845477770','test','test','0.0'),('2019-12-26 11:59:59','2019-12-26 15:59:59','MDAETH','4h','0.004141100000000','0.004058278000000','1.225833815980646','1.201317139661033','296.0164729131502','296.016472913150210','test','test','1.99'),('2019-12-27 07:59:59','2019-12-28 19:59:59','MDAETH','4h','0.003994300000000','0.003914414000000','1.220385665687399','1.195977952373651','305.53179923576073','305.531799235760730','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:01:48
