-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 11:59:59','VIBEBTC','4h','0.000007600000000','0.000007448000000','0.033333333333333','0.032666666666666','4385.964912280701','4385.964912280701355','test','test','2.00'),('2019-01-04 07:59:59','2019-01-07 11:59:59','VIBEBTC','4h','0.000007740000000','0.000007820000000','0.033185185185185','0.033528184515264','4287.491625992908','4287.491625992907757','test','test','0.0'),('2019-01-08 15:59:59','2019-01-09 15:59:59','VIBEBTC','4h','0.000008530000000','0.000008359400000','0.033261407258536','0.032596179113365','3899.3443444942554','3899.344344494255438','test','test','1.99'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000007977200000','0.033113578781831','0.032451307206194','4068.0072213552007','4068.007221355200727','test','test','1.99'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.032966407320579','0.037368649276742','3360.490042872443','3360.490042872443155','test','test','0.0'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010535000000','0.033944683310837','0.033265789644620','3157.644959147638','3157.644959147638019','test','test','2.00'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.033793818051678','0.034665483993487','3352.561314650574','3352.561314650573877','test','test','0.0'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.033987521594302','0.033652669164801','3348.524295005123','3348.524295005122895','test','test','0.98'),('2019-02-17 15:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010150000000','0.000009947000000','0.033913109943302','0.033234847744436','3341.1930978622445','3341.193097862244485','test','test','1.99'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000009950000000','0.033762385010220','0.033129756494249','3329.623768266316','3329.623768266315892','test','test','1.87'),('2019-02-20 15:59:59','2019-02-20 19:59:59','VIBEBTC','4h','0.000010230000000','0.000010025400000','0.033621800895560','0.032949364877649','3286.5885528406866','3286.588552840686589','test','test','1.99'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009751000000','0.033472370669358','0.032802923255971','3364.0573537042997','3364.057353704299658','test','test','2.00'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009770000000','0.033323604577494','0.032952592785639','3372.834471406275','3372.834471406275043','test','test','1.11'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009660000000','0.033241157512637','0.032732882932933','3388.4971980262317','3388.497198026231672','test','test','1.52'),('2019-03-02 15:59:59','2019-03-02 19:59:59','VIBEBTC','4h','0.000010190000000','0.000009986200000','0.033128207606036','0.032465643453915','3251.0507954893465','3251.050795489346456','test','test','1.99'),('2019-03-03 03:59:59','2019-03-03 07:59:59','VIBEBTC','4h','0.000010460000000','0.000010250800000','0.032980971127787','0.032321351705231','3153.056513172785','3153.056513172784889','test','test','1.99'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.032834389033886','0.032574571909978','3247.714048851237','3247.714048851236839','test','test','0.79'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VIBEBTC','4h','0.000010130000000','0.000009927400000','0.032776651895240','0.032121118857335','3235.602358858813','3235.602358858813204','test','test','2.00'),('2019-03-10 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010310000000','0.000010380000000','0.032630977886816','0.032852526718249','3164.983306189761','3164.983306189761151','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.032680210960468','0.032527356839979','3057.082409772519','3057.082409772518986','test','test','0.46'),('2019-03-15 15:59:59','2019-03-15 19:59:59','VIBEBTC','4h','0.000011360000000','0.000011132800000','0.032646243378137','0.031993318510574','2873.7890297656104','2873.789029765610394','test','test','2.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','VIBEBTC','4h','0.000011300000000','0.000011074000000','0.032501148963123','0.031851125983861','2876.2078728427728','2876.207872842772758','test','test','2.00'),('2019-03-18 11:59:59','2019-03-21 15:59:59','VIBEBTC','4h','0.000011110000000','0.000010887800000','0.032356699412176','0.031709565423932','2912.394186514511','2912.394186514511148','test','test','2.00'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.032212891859233','0.033010825877764','2955.311179746157','2955.311179746156995','test','test','0.0'),('2019-03-27 11:59:59','2019-03-30 07:59:59','VIBEBTC','4h','0.000011580000000','0.000011348400000','0.032390210530018','0.031742406319418','2797.082083766648','2797.082083766647884','test','test','1.99'),('2019-03-31 07:59:59','2019-04-02 03:59:59','VIBEBTC','4h','0.000011880000000','0.000011642400000','0.032246254038773','0.031601328957998','2714.3311480448933','2714.331148044893325','test','test','2.00'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.032102937354157','0.031832406983195','4508.83951603324','4508.839516033240216','test','test','0.84'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000006027000000','0.032042819493943','0.031401963104064','5210.214551860633','5210.214551860633037','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VIBEBTC','4h','0.000005810000000','0.000005693800000','0.031900406962859','0.031262398823602','5490.603608065175','5490.603608065174740','test','test','1.99'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.031758627376357','0.032798000635947','5774.295886610385','5774.295886610385423','test','test','0.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBEBTC','4h','0.000005930000000','0.000005811400000','0.031989599211822','0.031349807227586','5394.536123410044','5394.536123410043729','test','test','2.00'),('2019-05-23 07:59:59','2019-05-24 15:59:59','VIBEBTC','4h','0.000006080000000','0.000005958400000','0.031847423215325','0.031210474751018','5238.063028836294','5238.063028836293597','test','test','1.99'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005660000000','0.031705879112145','0.031155429822004','5504.492901414121','5504.492901414120752','test','test','1.73'),('2019-05-29 19:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000005940000000','0.000005821200000','0.031583557047670','0.030951885906717','5317.097146072316','5317.097146072315809','test','test','2.00'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005684000000','0.031443185683013','0.030814321969353','5421.238910864367','5421.238910864367426','test','test','2.00'),('2019-05-31 19:59:59','2019-06-01 03:59:59','VIBEBTC','4h','0.000005990000000','0.000005870200000','0.031303438191089','0.030677369427267','5225.949614539047','5225.949614539046706','test','test','2.00'),('2019-06-03 11:59:59','2019-06-04 03:59:59','VIBEBTC','4h','0.000005950000000','0.000005831000000','0.031164311799128','0.030541025563145','5237.699462038395','5237.699462038394813','test','test','2.00'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.031025803746688','0.031130798006406','5249.7129859031775','5249.712985903177469','test','test','0.16'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.031049135804403','0.031100884364077','5174.855967400481','5174.855967400480949','test','test','0.0'),('2019-07-05 19:59:59','2019-07-06 07:59:59','VIBEBTC','4h','0.000003380000000','0.000003312400000','0.031060635484330','0.030439422774643','9189.537125541552','9189.537125541552086','test','test','2.0'),('2019-07-06 11:59:59','2019-07-06 15:59:59','VIBEBTC','4h','0.000003480000000','0.000003410400000','0.030922588215511','0.030304136451201','8885.801211353768','8885.801211353767940','test','test','2.00'),('2019-07-26 07:59:59','2019-07-27 03:59:59','VIBEBTC','4h','0.000002190000000','0.000002146200000','0.030785154490109','0.030169451400307','14057.148168999493','14057.148168999492555','test','test','1.99'),('2019-07-28 03:59:59','2019-07-28 07:59:59','VIBEBTC','4h','0.000002210000000','0.000002200000000','0.030648331581264','0.030509651347865','13868.02333993846','13868.023339938459685','test','test','0.45'),('2019-07-28 19:59:59','2019-07-28 23:59:59','VIBEBTC','4h','0.000002230000000','0.000002240000000','0.030617513751620','0.030754812019564','13729.82679444833','13729.826794448330475','test','test','0.0'),('2019-07-29 07:59:59','2019-07-31 15:59:59','VIBEBTC','4h','0.000002280000000','0.000002234400000','0.030648024477830','0.030035063988273','13442.115999048048','13442.115999048048252','test','test','2.00'),('2019-08-14 07:59:59','2019-08-14 11:59:59','VIBEBTC','4h','0.000001590000000','0.000001600000000','0.030511811035706','0.030703709218321','19189.81826145017','19189.818261450171121','test','test','0.0'),('2019-08-19 03:59:59','2019-08-19 07:59:59','VIBEBTC','4h','0.000001510000000','0.000001479800000','0.030554455076287','0.029943365974761','20234.738461117144','20234.738461117143743','test','test','1.99'),('2019-08-21 19:59:59','2019-08-21 23:59:59','VIBEBTC','4h','0.000001510000000','0.000001500000000','0.030418657498170','0.030217209435268','20144.80629017881','20144.806290178810741','test','test','0.66'),('2019-08-22 15:59:59','2019-08-23 15:59:59','VIBEBTC','4h','0.000001570000000','0.000001538600000','0.030373891261970','0.029766413436731','19346.42755539462','19346.427555394620867','test','test','2.00'),('2019-08-24 07:59:59','2019-08-28 19:59:59','VIBEBTC','4h','0.000001640000000','0.000001670000000','0.030238896189694','0.030792046729749','18438.351335179403','18438.351335179402668','test','test','1.82'),('2019-08-29 19:59:59','2019-08-29 23:59:59','VIBEBTC','4h','0.000001660000000','0.000001650000000','0.030361818531929','0.030178916010652','18290.25212766787','18290.252127667870809','test','test','0.60'),('2019-09-01 11:59:59','2019-09-02 03:59:59','VIBEBTC','4h','0.000001650000000','0.000001620000000','0.030321173527200','0.029769879463069','18376.468804363903','18376.468804363903473','test','test','1.81'),('2019-09-09 19:59:59','2019-09-12 03:59:59','VIBEBTC','4h','0.000001490000000','0.000001490000000','0.030198663735171','0.030198663735171','20267.559553806263','20267.559553806262556','test','test','0.0'),('2019-09-14 19:59:59','2019-09-24 03:59:59','VIBEBTC','4h','0.000001560000000','0.000001740000000','0.030198663735171','0.033683124935383','19358.11777895598','19358.117778955980611','test','test','0.0'),('2019-09-24 11:59:59','2019-09-24 15:59:59','VIBEBTC','4h','0.000001810000000','0.000001773800000','0.030972988446330','0.030353528677403','17112.148312889258','17112.148312889257795','test','test','1.99'),('2019-09-26 07:59:59','2019-09-26 11:59:59','VIBEBTC','4h','0.000001760000000','0.000001760000000','0.030835330719901','0.030835330719901','17520.07427267121','17520.074272671208746','test','test','0.0'),('2019-09-27 15:59:59','2019-10-09 15:59:59','VIBEBTC','4h','0.000001900000000','0.000002700000000','0.030835330719901','0.043818627865122','16229.121431527015','16229.121431527015375','test','test','0.0'),('2019-10-16 03:59:59','2019-10-16 07:59:59','VIBEBTC','4h','0.000002540000000','0.000002510000000','0.033720507863284','0.033322234148363','13275.790497355818','13275.790497355817934','test','test','1.18'),('2019-10-23 11:59:59','2019-10-23 15:59:59','VIBEBTC','4h','0.000002470000000','0.000002420600000','0.033632002593301','0.032959362541435','13616.195381903373','13616.195381903373345','test','test','1.99'),('2019-11-08 03:59:59','2019-11-08 07:59:59','VIBEBTC','4h','0.000002100000000','0.000002060000000','0.033482527026220','0.032844764606673','15944.06048867619','15944.060488676190289','test','test','1.90'),('2019-11-09 11:59:59','2019-11-09 15:59:59','VIBEBTC','4h','0.000002110000000','0.000002090000000','0.033340802044098','0.033024775484438','15801.327982985043','15801.327982985043491','test','test','0.94'),('2019-11-09 19:59:59','2019-11-09 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002120000000','0.033270573919730','0.033587436528489','15843.13043796646','15843.130437966459795','test','test','0.0'),('2019-11-13 15:59:59','2019-11-13 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002100000000','0.033340987832787','0.033182973672442','15801.41603449626','15801.416034496260181','test','test','0.47'),('2019-11-16 19:59:59','2019-11-16 23:59:59','VIBEBTC','4h','0.000002100000000','0.000002110000000','0.033305873574933','0.033464472972909','15859.939797586983','15859.939797586983332','test','test','0.0'),('2019-11-17 15:59:59','2019-11-17 19:59:59','VIBEBTC','4h','0.000002120000000','0.000002080000000','0.033341117885594','0.032712040189639','15726.942398865092','15726.942398865092400','test','test','1.88'),('2019-11-18 03:59:59','2019-11-18 19:59:59','VIBEBTC','4h','0.000002110000000','0.000002130000000','0.033201322842048','0.033516027323963','15735.224095757556','15735.224095757555915','test','test','0.0'),('2019-11-19 07:59:59','2019-11-20 23:59:59','VIBEBTC','4h','0.000002190000000','0.000002146200000','0.033271257171363','0.032605832027936','15192.354872768441','15192.354872768441055','test','test','1.99'),('2019-11-26 15:59:59','2019-11-27 11:59:59','VIBEBTC','4h','0.000002090000000','0.000002050000000','0.033123384917268','0.032489444536076','15848.509529793304','15848.509529793303955','test','test','1.91'),('2019-11-29 15:59:59','2019-12-03 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002080000000','0.032982509277003','0.032982509277003','15856.975613943805','15856.975613943805001','test','test','0.96'),('2019-12-04 15:59:59','2019-12-04 19:59:59','VIBEBTC','4h','0.000002070000000','0.000002090000000','0.032982509277003','0.033301180864220','15933.57936087107','15933.579360871070094','test','test','0.0'),('2019-12-08 11:59:59','2019-12-08 23:59:59','VIBEBTC','4h','0.000002080000000','0.000002070000000','0.033053325185274','0.032894414968037','15891.021723689213','15891.021723689213104','test','test','0.48'),('2019-12-09 15:59:59','2019-12-09 19:59:59','VIBEBTC','4h','0.000002060000000','0.000002060000000','0.033018011803665','0.033018011803665','16028.161069740452','16028.161069740452149','test','test','0.0'),('2019-12-15 11:59:59','2019-12-15 15:59:59','VIBEBTC','4h','0.000002000000000','0.000001970000000','0.033018011803665','0.032522741626610','16509.00590183267','16509.005901832668314','test','test','1.49'),('2019-12-30 11:59:59','2019-12-30 15:59:59','VIBEBTC','4h','0.000001750000000','0.000001715000000','0.032907951764320','0.032249792729034','18804.54386532559','18804.543865325591469','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:04:09
