-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 23:59:59','THETAETH','4h','0.000353100000000','0.000349670000000','1.297777777777778','1.285171213694578','3675.3831146354505','3675.383114635450511','test','test','0.97'),('2019-01-11 11:59:59','2019-01-14 15:59:59','THETAETH','4h','0.000363560000000','0.000358480000000','1.294976319092622','1.276881700044898','3561.932883410227','3561.932883410227078','test','test','1.39'),('2019-01-15 07:59:59','2019-01-15 15:59:59','THETAETH','4h','0.000370510000000','0.000365510000000','1.290955292637572','1.273533964027851','3484.2657219442726','3484.265721944272627','test','test','1.34'),('2019-01-15 19:59:59','2019-02-17 23:59:59','THETAETH','4h','0.000367640000000','0.000672760000000','1.287083886279857','2.355289292061899','3500.935388640672','3500.935388640672045','test','test','0.0'),('2019-02-20 19:59:59','2019-02-20 23:59:59','THETAETH','4h','0.000678530000000','0.000664959400000','1.524462865342533','1.493973608035682','2246.714021992443','2246.714021992443122','test','test','2.00'),('2019-02-24 23:59:59','2019-03-04 07:59:59','THETAETH','4h','0.000662050000000','0.000976200000000','1.517687474829899','2.237846858891243','2292.4061246581064','2292.406124658106364','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','THETAETH','4h','0.001003470000000','0.000983400600000','1.677722893510198','1.644168435639994','1671.9213265072176','1671.921326507217600','test','test','2.00'),('2019-03-06 07:59:59','2019-03-07 07:59:59','THETAETH','4h','0.000987440000000','0.000967691200000','1.670266347316819','1.636861020370483','1691.51173470471','1691.511734704710079','test','test','2.00'),('2019-03-09 03:59:59','2019-03-09 11:59:59','THETAETH','4h','0.000955730000000','0.000946430000000','1.662842941328744','1.646662179655094','1739.8668466290108','1739.866846629010752','test','test','0.97'),('2019-03-09 23:59:59','2019-03-12 19:59:59','THETAETH','4h','0.001012890000000','0.000992632200000','1.659247216512378','1.626062272182131','1638.131698913384','1638.131698913384071','test','test','1.99'),('2019-03-14 19:59:59','2019-03-14 23:59:59','THETAETH','4h','0.001090000000000','0.001068200000000','1.651872784438990','1.618835328750210','1515.4796187513666','1515.479618751366615','test','test','1.99'),('2019-04-05 03:59:59','2019-04-05 07:59:59','THETAETH','4h','0.000789050000000','0.000773269000000','1.644531127619261','1.611640505066876','2084.1912776367285','2084.191277636728501','test','test','1.99'),('2019-04-14 03:59:59','2019-04-14 23:59:59','THETAETH','4h','0.000740530000000','0.000725719400000','1.637222100385397','1.604477658377689','2210.8788305475773','2210.878830547577309','test','test','1.99'),('2019-04-15 19:59:59','2019-04-18 07:59:59','THETAETH','4h','0.000740730000000','0.000731410000000','1.629945557717018','1.609437285339873','2200.4584095649125','2200.458409564912472','test','test','1.25'),('2019-05-18 07:59:59','2019-05-18 11:59:59','THETAETH','4h','0.000490570000000','0.000483100000000','1.625388163855430','1.600638078069507','3313.2644961074466','3313.264496107446575','test','test','1.52'),('2019-05-24 03:59:59','2019-05-24 07:59:59','THETAETH','4h','0.000559060000000','0.000547878800000','1.619888144791892','1.587490381896054','2897.521097542109','2897.521097542109146','test','test','2.00'),('2019-05-24 15:59:59','2019-05-24 19:59:59','THETAETH','4h','0.000497010000000','0.000487069800000','1.612688641926150','1.580434869087627','3244.781074678879','3244.781074678879122','test','test','2.00'),('2019-05-25 03:59:59','2019-05-26 19:59:59','THETAETH','4h','0.000493010000000','0.000483149800000','1.605521136850922','1.573410714113904','3256.569109857655','3256.569109857654894','test','test','2.00'),('2019-05-29 11:59:59','2019-05-29 15:59:59','THETAETH','4h','0.000577350000000','0.000565803000000','1.598385487353807','1.566417777606731','2768.4861649845107','2768.486164984510651','test','test','1.99'),('2019-05-29 19:59:59','2019-05-29 23:59:59','THETAETH','4h','0.000581710000000','0.000570075800000','1.591281551854457','1.559455920817368','2735.5238037071003','2735.523803707100342','test','test','2.00'),('2019-06-02 03:59:59','2019-06-03 07:59:59','THETAETH','4h','0.000523000000000','0.000512540000000','1.584209189401770','1.552525005613735','3029.0806680722185','3029.080668072218486','test','test','2.00'),('2019-06-03 15:59:59','2019-06-04 07:59:59','THETAETH','4h','0.000519440000000','0.000509051200000','1.577168259671096','1.545624894477674','3036.2857301538124','3036.285730153812437','test','test','2.00'),('2019-06-04 15:59:59','2019-06-04 19:59:59','THETAETH','4h','0.000518620000000','0.000513870000000','1.570158622961447','1.555777662992555','3027.5705197667785','3027.570519766778489','test','test','0.91'),('2019-06-05 03:59:59','2019-06-05 15:59:59','THETAETH','4h','0.000526840000000','0.000516303200000','1.566962854079471','1.535623596997882','2974.267052766439','2974.267052766439065','test','test','1.99'),('2019-06-05 23:59:59','2019-06-12 19:59:59','THETAETH','4h','0.000527440000000','0.000547800000000','1.559998574728007','1.620216933179134','2957.679688169283','2957.679688169283054','test','test','0.21'),('2019-07-02 03:59:59','2019-07-02 07:59:59','THETAETH','4h','0.000417370000000','0.000409022600000','1.573380432161591','1.541912823518359','3769.7496996947325','3769.749699694732499','test','test','1.99'),('2019-07-04 03:59:59','2019-07-04 07:59:59','THETAETH','4h','0.000418760000000','0.000410384800000','1.566387630240872','1.535059877636054','3740.5378504175956','3740.537850417595564','test','test','1.99'),('2019-07-06 11:59:59','2019-07-06 15:59:59','THETAETH','4h','0.000410170000000','0.000401966600000','1.559425907439802','1.528237389291006','3801.90142487213','3801.901424872130065','test','test','2.00'),('2019-07-06 23:59:59','2019-07-07 15:59:59','THETAETH','4h','0.000413470000000','0.000411970000000','1.552495125628958','1.546862932994805','3754.79508943565','3754.795089435649970','test','test','0.36'),('2019-07-10 15:59:59','2019-07-12 03:59:59','THETAETH','4h','0.000405870000000','0.000397752600000','1.551243527265813','1.520218656720497','3822.0206649070215','3822.020664907021455','test','test','2.00'),('2019-07-12 15:59:59','2019-07-31 15:59:59','THETAETH','4h','0.000407000000000','0.000584000000000','1.544349111589076','2.215970224000050','3794.469561643921','3794.469561643921224','test','test','0.0'),('2019-07-31 19:59:59','2019-08-02 15:59:59','THETAETH','4h','0.000593440000000','0.000583100000000','1.693598247680404','1.664089273089855','2853.8660145598606','2853.866014559860560','test','test','1.74'),('2019-08-11 03:59:59','2019-08-11 11:59:59','THETAETH','4h','0.000558500000000','0.000555660000000','1.687040697771393','1.678462012754973','3020.663738176173','3020.663738176172956','test','test','0.50'),('2019-08-11 15:59:59','2019-08-11 19:59:59','THETAETH','4h','0.000567510000000','0.000560310000000','1.685134323323299','1.663755022292607','2969.3473653738247','2969.347365373824687','test','test','1.26'),('2019-08-12 03:59:59','2019-08-13 11:59:59','THETAETH','4h','0.000584130000000','0.000572447400000','1.680383367538701','1.646775700187927','2876.728412405973','2876.728412405972904','test','test','2.00'),('2019-08-14 19:59:59','2019-08-14 23:59:59','THETAETH','4h','0.000587410000000','0.000575661800000','1.672914997016307','1.639456697075981','2847.9511704198208','2847.951170419820755','test','test','1.99'),('2019-08-15 23:59:59','2019-08-26 03:59:59','THETAETH','4h','0.000593530000000','0.000649750000000','1.665479819251790','1.823236420330650','2806.0583614169295','2806.058361416929529','test','test','1.99'),('2019-08-27 15:59:59','2019-08-28 15:59:59','THETAETH','4h','0.000656810000000','0.000654500000000','1.700536841713759','1.694556055635047','2589.0848825592775','2589.084882559277503','test','test','0.35'),('2019-08-28 19:59:59','2019-08-29 03:59:59','THETAETH','4h','0.000684460000000','0.000670770800000','1.699207778140712','1.665223622577898','2482.55234511982','2482.552345119820075','test','test','2.00'),('2019-08-29 15:59:59','2019-08-30 11:59:59','THETAETH','4h','0.000666340000000','0.000653013200000','1.691655743571198','1.657822628699774','2538.7275918768164','2538.727591876816405','test','test','1.99'),('2019-09-01 23:59:59','2019-09-02 03:59:59','THETAETH','4h','0.000663670000000','0.000650396600000','1.684137273599770','1.650454528127774','2537.61247849047','2537.612478490470039','test','test','1.99'),('2019-09-05 15:59:59','2019-09-06 07:59:59','THETAETH','4h','0.000661920000000','0.000648681600000','1.676652219050438','1.643119174669429','2533.0133838688025','2533.013383868802521','test','test','1.99'),('2019-10-06 03:59:59','2019-10-06 07:59:59','THETAETH','4h','0.000496230000000','0.000486305400000','1.669200431410213','1.635816422782009','3363.763640671087','3363.763640671087160','test','test','2.00'),('2019-10-08 15:59:59','2019-10-09 15:59:59','THETAETH','4h','0.000494630000000','0.000484737400000','1.661781762826168','1.628546127569645','3359.6461250352145','3359.646125035214482','test','test','1.99'),('2019-10-12 19:59:59','2019-10-13 03:59:59','THETAETH','4h','0.000484660000000','0.000474966800000','1.654396066102496','1.621308144780446','3413.5188918055883','3413.518891805588282','test','test','2.00'),('2019-10-13 11:59:59','2019-10-13 15:59:59','THETAETH','4h','0.000482170000000','0.000474240000000','1.647043194697597','1.619955129214568','3415.897286636656','3415.897286636656190','test','test','1.64'),('2019-10-15 03:59:59','2019-10-16 11:59:59','THETAETH','4h','0.000486730000000','0.000477830000000','1.641023624590257','1.611017029026282','3371.5275914578033','3371.527591457803283','test','test','1.82'),('2019-10-16 19:59:59','2019-10-17 03:59:59','THETAETH','4h','0.000485140000000','0.000480660000000','1.634355492242707','1.619263121782124','3368.8326920944605','3368.832692094460526','test','test','1.06'),('2019-10-17 11:59:59','2019-10-18 07:59:59','THETAETH','4h','0.000482690000000','0.000477630000000','1.631001632140355','1.613903974723317','3378.983679256572','3378.983679256572032','test','test','1.04'),('2019-10-21 23:59:59','2019-10-26 03:59:59','THETAETH','4h','0.000496250000000','0.000527100000000','1.627202152714346','1.728359203417092','3278.9967812883556','3278.996781288355578','test','test','0.88'),('2019-10-28 23:59:59','2019-10-29 23:59:59','THETAETH','4h','0.000540910000000','0.000530450000000','1.649681497314957','1.617780315118447','3049.8262138155264','3049.826213815526444','test','test','1.93'),('2019-11-15 15:59:59','2019-11-16 11:59:59','THETAETH','4h','0.000504510000000','0.000494419800000','1.642592345715732','1.609740498801417','3255.817220106107','3255.817220106107015','test','test','1.99'),('2019-11-18 07:59:59','2019-11-18 11:59:59','THETAETH','4h','0.000495040000000','0.000514220000000','1.635291935290329','1.698650248394055','3303.353133666631','3303.353133666631038','test','test','0.0'),('2019-11-18 15:59:59','2019-11-18 19:59:59','THETAETH','4h','0.000514880000000','0.000504582400000','1.649371560424490','1.616384129216000','3203.409649674662','3203.409649674661978','test','test','2.00'),('2019-11-19 11:59:59','2019-11-20 19:59:59','THETAETH','4h','0.000521880000000','0.000511442400000','1.642041020155937','1.609200199752818','3146.3957617765323','3146.395761776532254','test','test','1.99'),('2019-11-21 19:59:59','2019-11-22 11:59:59','THETAETH','4h','0.000509140000000','0.000502860000000','1.634743060066355','1.614579281111222','3210.7928272505687','3210.792827250568735','test','test','1.40'),('2019-11-26 15:59:59','2019-11-26 19:59:59','THETAETH','4h','0.000502000000000','0.000500770000000','1.630262220298548','1.626267753105386','3247.534303383561','3247.534303383561110','test','test','0.24'),('2019-11-27 15:59:59','2019-11-27 19:59:59','THETAETH','4h','0.000510120000000','0.000499917600000','1.629374560922289','1.596787069703843','3194.1005271745653','3194.100527174565286','test','test','1.99'),('2019-11-30 03:59:59','2019-11-30 07:59:59','THETAETH','4h','0.000502260000000','0.000492560000000','1.622132896207079','1.590805119571056','3229.6676944353103','3229.667694435310295','test','test','1.93'),('2019-12-03 23:59:59','2019-12-04 03:59:59','THETAETH','4h','0.000497180000000','0.000491440000000','1.615171168065741','1.596523832081395','3248.6648056352647','3248.664805635264656','test','test','1.15'),('2019-12-04 15:59:59','2019-12-04 19:59:59','THETAETH','4h','0.000495470000000','0.000489390000000','1.611027315624775','1.591258114504629','3251.51334212924','3251.513342129239845','test','test','1.22'),('2019-12-05 11:59:59','2019-12-10 03:59:59','THETAETH','4h','0.000502700000000','0.000550400000000','1.606634159820298','1.759083830445777','3196.00986636224','3196.009866362239791','test','test','0.0'),('2019-12-11 19:59:59','2019-12-11 23:59:59','THETAETH','4h','0.000594470000000','0.000582580600000','1.640511864403738','1.607701627115663','2759.620947068376','2759.620947068376154','test','test','1.99'),('2019-12-12 07:59:59','2019-12-17 23:59:59','THETAETH','4h','0.000566820000000','0.000778510000000','1.633220700561943','2.243178870884016','2881.374511417987','2881.374511417986923','test','test','0.0'),('2019-12-18 07:59:59','2019-12-18 23:59:59','THETAETH','4h','0.000790190000000','0.000774386200000','1.768766960633515','1.733391621420845','2238.4071686980537','2238.407168698053738','test','test','2.00'),('2019-12-21 19:59:59','2019-12-21 23:59:59','THETAETH','4h','0.000817260000000','0.000800914800000','1.760905774141810','1.725687658658974','2154.645735924688','2154.645735924687870','test','test','2.00'),('2019-12-25 03:59:59','2019-12-25 15:59:59','THETAETH','4h','0.000763910000000','0.000748631800000','1.753079526256736','1.718017935731601','2294.8770486794724','2294.877048679472409','test','test','2.00'),('2019-12-31 11:59:59','2019-12-31 15:59:59','THETAETH','4h','0.000708700000000','0.000696490000000','1.745288061695595','1.715218967250409','2462.661297722019','2462.661297722018844','test','test','1.72');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:06:58
