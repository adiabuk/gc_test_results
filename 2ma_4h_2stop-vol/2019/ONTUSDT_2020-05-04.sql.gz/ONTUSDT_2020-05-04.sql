-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 07:59:59','ONTUSDT','4h','0.619100000000000','0.613500000000000','222.222222222222200','220.212135896193388','358.9439867908613','358.943986790861288','test','test','1.08'),('2019-01-05 23:59:59','2019-01-06 03:59:59','ONTUSDT','4h','0.616000000000000','0.608500000000000','221.775536371993581','219.075347211620311','360.02522138310644','360.025221383106441','test','test','1.21'),('2019-01-06 11:59:59','2019-01-08 03:59:59','ONTUSDT','4h','0.615300000000000','0.607000000000000','221.175494336355086','218.191979623220448','359.45960399212595','359.459603992125949','test','test','1.34'),('2019-01-08 15:59:59','2019-01-10 07:59:59','ONTUSDT','4h','0.643600000000000','0.638600000000000','220.512491066769627','218.799373516530608','342.6235100478086','342.623510047808622','test','test','1.98'),('2019-01-11 23:59:59','2019-01-12 03:59:59','ONTUSDT','4h','0.628900000000000','0.627600000000000','220.131798277827585','219.676763554085852','350.0267105705638','350.026710570563807','test','test','0.20'),('2019-01-16 11:59:59','2019-01-16 15:59:59','ONTUSDT','4h','0.619000000000000','0.606620000000000','220.030679450329444','215.630065861322834','355.4615176903545','355.461517690354526','test','test','2.00'),('2019-01-19 11:59:59','2019-01-19 23:59:59','ONTUSDT','4h','0.620200000000000','0.611100000000000','219.052765319439118','215.838672826038760','353.1969772967416','353.196977296741579','test','test','1.46'),('2019-01-22 19:59:59','2019-01-23 03:59:59','ONTUSDT','4h','0.601500000000000','0.610700000000000','218.338522543127937','221.678031117353640','362.99006241584027','362.990062415840271','test','test','0.06'),('2019-01-25 15:59:59','2019-01-26 15:59:59','ONTUSDT','4h','0.616300000000000','0.604600000000000','219.080635559622493','214.921551613415176','355.47726035960164','355.477260359601644','test','test','1.89'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ONTUSDT','4h','0.551900000000000','0.564300000000000','218.156394682687534','223.057897299221935','395.28246907535345','395.282469075353447','test','test','0.0'),('2019-02-15 11:59:59','2019-03-04 03:59:59','ONTUSDT','4h','0.619900000000000','0.834400000000000','219.245617486361851','295.109764850169881','353.67900868908185','353.679008689081854','test','test','0.0'),('2019-03-05 15:59:59','2019-03-11 07:59:59','ONTUSDT','4h','0.882200000000000','0.924000000000000','236.104316900541420','247.291304484357596','267.63128190947793','267.631281909477934','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','ONTUSDT','4h','0.943800000000000','0.953400000000000','238.590314141389484','241.017170483577843','252.79753564461697','252.797535644616971','test','test','0.0'),('2019-03-13 15:59:59','2019-03-14 03:59:59','ONTUSDT','4h','1.026900000000000','1.006362000000000','239.129615550764669','234.347023239749404','232.86553272058106','232.865532720581058','test','test','1.99'),('2019-03-14 15:59:59','2019-03-25 15:59:59','ONTUSDT','4h','0.986100000000000','1.165700000000000','238.066817259427921','281.426314652991721','241.42259127819483','241.422591278194830','test','test','0.21'),('2019-03-27 03:59:59','2019-04-08 11:59:59','ONTUSDT','4h','1.214500000000000','1.422600000000000','247.702261124664318','290.145110478342929','203.95410549581254','203.954105495812541','test','test','0.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','ONTUSDT','4h','1.482900000000000','1.453242000000000','257.134005425481803','251.991325316972166','173.39942371399405','173.399423713994054','test','test','1.99'),('2019-05-03 15:59:59','2019-05-03 19:59:59','ONTUSDT','4h','1.139100000000000','1.137100000000000','255.991187623590776','255.541725438315382','224.73109263768833','224.731092637688334','test','test','0.17'),('2019-05-04 03:59:59','2019-05-04 07:59:59','ONTUSDT','4h','1.166700000000000','1.143366000000000','255.891307137973996','250.773480995214499','219.32913957141852','219.329139571418523','test','test','1.99'),('2019-05-11 07:59:59','2019-05-17 11:59:59','ONTUSDT','4h','1.106100000000000','1.292100000000000','254.754012439583022','297.593038127823149','230.3173424098933','230.317342409893314','test','test','0.0'),('2019-05-20 15:59:59','2019-05-22 23:59:59','ONTUSDT','4h','1.352100000000000','1.325058000000000','264.273795925858565','258.988320007341372','195.45432728781788','195.454327287817875','test','test','2.00'),('2019-05-24 11:59:59','2019-05-24 23:59:59','ONTUSDT','4h','1.364400000000000','1.337112000000000','263.099245721743671','257.837260807308780','192.8314612443152','192.831461244315193','test','test','1.99'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ONTUSDT','4h','1.362100000000000','1.441700000000000','261.929915740758133','277.236883873027637','192.29859462650182','192.298594626501824','test','test','0.0'),('2019-06-10 03:59:59','2019-06-11 07:59:59','ONTUSDT','4h','1.412500000000000','1.387100000000000','265.331464214595769','260.560193990843004','187.84528439971382','187.845284399713819','test','test','1.79'),('2019-06-13 15:59:59','2019-06-13 23:59:59','ONTUSDT','4h','1.473200000000000','1.443736000000000','264.271181942650742','258.985758303797752','179.38581451442488','179.385814514424879','test','test','1.99'),('2019-06-14 23:59:59','2019-06-18 19:59:59','ONTUSDT','4h','1.417700000000000','1.431000000000000','263.096643356238985','265.564856205669741','185.57991349103406','185.579913491034063','test','test','0.0'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ONTUSDT','4h','1.435700000000000','1.437700000000000','263.645135100556956','264.012405609856330','183.63525464968794','183.635254649687937','test','test','0.0'),('2019-06-22 03:59:59','2019-06-27 07:59:59','ONTUSDT','4h','1.458800000000000','1.596900000000000','263.726750769290106','288.692931384342842','180.78334985555944','180.783349855559436','test','test','0.0'),('2019-06-29 19:59:59','2019-06-29 23:59:59','ONTUSDT','4h','1.558900000000000','1.557400000000000','269.274790905968473','269.015690138530545','172.73384495860446','172.733844958604465','test','test','0.09'),('2019-06-30 07:59:59','2019-06-30 15:59:59','ONTUSDT','4h','1.594900000000000','1.563002000000000','269.217212957648940','263.832868698495929','168.79880428719602','168.798804287196020','test','test','1.99'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ONTUSDT','4h','1.067900000000000','1.046542000000000','268.020692011170524','262.660278170947095','250.97920405578284','250.979204055782844','test','test','1.99'),('2019-07-24 23:59:59','2019-07-26 03:59:59','ONTUSDT','4h','1.022200000000000','1.014100000000000','266.829488935565280','264.715109303029521','261.034522535282','261.034522535282008','test','test','0.95'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ONTUSDT','4h','1.037900000000000','1.017142000000000','266.359626795001816','261.032434259101763','256.6332274737468','256.633227473746786','test','test','2.00'),('2019-08-05 11:59:59','2019-08-05 15:59:59','ONTUSDT','4h','1.005700000000000','0.987400000000000','265.175806231468471','260.350592694592763','263.67287086752356','263.672870867523557','test','test','1.81'),('2019-08-05 19:59:59','2019-08-06 03:59:59','ONTUSDT','4h','1.009600000000000','0.989408000000000','264.103536556607196','258.821465825475059','261.5922509475111','261.592250947511104','test','test','1.99'),('2019-08-24 07:59:59','2019-08-24 11:59:59','ONTUSDT','4h','0.816600000000000','0.800268000000000','262.929743060800035','257.671148199584024','321.9810715904972','321.981071590497208','test','test','2.00'),('2019-08-24 15:59:59','2019-08-25 19:59:59','ONTUSDT','4h','0.816500000000000','0.800170000000000','261.761166424974249','256.525943096474748','320.58930364356917','320.589303643569167','test','test','2.00'),('2019-08-26 03:59:59','2019-08-26 07:59:59','ONTUSDT','4h','0.806000000000000','0.797600000000000','260.597783463085477','257.881876042378337','323.32231198893976','323.322311988939759','test','test','1.04'),('2019-09-08 15:59:59','2019-09-09 03:59:59','ONTUSDT','4h','0.765900000000000','0.750582000000000','259.994248480706119','254.794363511092001','339.46239519611714','339.462395196117143','test','test','2.00'),('2019-09-09 11:59:59','2019-09-11 07:59:59','ONTUSDT','4h','0.755500000000000','0.742000000000000','258.838718487458493','254.213539533678642','342.60584842813836','342.605848428138358','test','test','1.78'),('2019-09-13 07:59:59','2019-09-14 03:59:59','ONTUSDT','4h','0.749600000000000','0.739300000000000','257.810900942174101','254.268408573304811','343.9312979484713','343.931297948471297','test','test','1.37'),('2019-09-14 15:59:59','2019-09-22 03:59:59','ONTUSDT','4h','0.756200000000000','0.783200000000000','257.023680415758747','266.200669798495483','339.88849565691453','339.888495656914529','test','test','0.26'),('2019-10-07 15:59:59','2019-10-08 11:59:59','ONTUSDT','4h','0.633800000000000','0.623400000000000','259.063011389700193','254.812056327452012','408.7456790623228','408.745679062322779','test','test','1.64'),('2019-10-08 19:59:59','2019-10-08 23:59:59','ONTUSDT','4h','0.629600000000000','0.636800000000000','258.118354709200617','261.070152920614589','409.97197380749776','409.971973807497761','test','test','0.0'),('2019-10-09 11:59:59','2019-10-10 11:59:59','ONTUSDT','4h','0.655100000000000','0.641998000000000','258.774309867292629','253.598823669946739','395.0149746104299','395.014974610429874','test','test','2.00'),('2019-10-11 03:59:59','2019-10-11 07:59:59','ONTUSDT','4h','0.655200000000000','0.642096000000000','257.624201823438000','252.471717786969236','393.1993312323535','393.199331232353472','test','test','2.00'),('2019-10-11 15:59:59','2019-10-12 19:59:59','ONTUSDT','4h','0.640800000000000','0.633400000000000','256.479205370889360','253.517366856930892','400.2484478322243','400.248447832224315','test','test','1.15'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ONTUSDT','4h','0.647300000000000','0.636600000000000','255.821019034454167','251.592245816983677','395.2124502308886','395.212450230888578','test','test','1.65'),('2019-10-15 03:59:59','2019-10-15 07:59:59','ONTUSDT','4h','0.640900000000000','0.633900000000000','254.881291652794062','252.097442313475028','397.69276275985965','397.692762759859647','test','test','1.09'),('2019-10-15 15:59:59','2019-10-15 19:59:59','ONTUSDT','4h','0.646100000000000','0.633178000000000','254.262658466278680','249.177405296953111','393.5345278846598','393.534527884659781','test','test','1.99'),('2019-10-25 19:59:59','2019-11-08 11:59:59','ONTUSDT','4h','0.605800000000000','0.859400000000000','253.132602206428572','359.098973813477642','417.84846848205444','417.848468482054443','test','test','0.0'),('2019-11-10 19:59:59','2019-11-11 07:59:59','ONTUSDT','4h','0.854900000000000','0.837802000000000','276.680684785772826','271.147071090057352','323.64099284802063','323.640992848020630','test','test','2.00'),('2019-11-12 11:59:59','2019-11-14 11:59:59','ONTUSDT','4h','0.895200000000000','0.877296000000000','275.450992853391597','269.941972996323784','307.6977131963713','307.697713196371296','test','test','2.00'),('2019-11-29 15:59:59','2019-11-30 03:59:59','ONTUSDT','4h','0.693000000000000','0.679140000000000','274.226766218487626','268.742230894117881','395.70961936289706','395.709619362897058','test','test','1.99'),('2019-12-08 15:59:59','2019-12-09 03:59:59','ONTUSDT','4h','0.646800000000000','0.638800000000000','273.007980590849911','269.631258505619883','422.0902606537568','422.090260653756786','test','test','1.23'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTUSDT','4h','0.639900000000000','0.627102000000000','272.257597905243244','266.812445947138372','425.4689762544823','425.468976254482300','test','test','1.99'),('2019-12-13 15:59:59','2019-12-13 19:59:59','ONTUSDT','4h','0.623900000000000','0.613700000000000','271.047564136775520','266.616268810288716','434.44071828301895','434.440718283018953','test','test','1.63'),('2019-12-29 15:59:59','2019-12-30 03:59:59','ONTUSDT','4h','0.542600000000000','0.535300000000000','270.062831842000662','266.429476382275993','497.7199259896806','497.719925989680576','test','test','1.34');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:31:51
