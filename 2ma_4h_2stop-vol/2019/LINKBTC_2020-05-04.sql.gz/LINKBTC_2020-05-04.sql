-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079280000000','0.000092190000000','0.033333333333333','0.038761352169525','420.45072317524387','420.450723175243866','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000093972200000','0.034539559741376','0.033848768546548','360.19980958781935','360.199809587819345','test','test','2.00'),('2019-01-10 19:59:59','2019-01-10 23:59:59','LINKBTC','4h','0.000099400000000','0.000097412000000','0.034386050586970','0.033698329575231','345.9361226053297','345.936122605329672','test','test','1.99'),('2019-01-11 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000109220000000','0.000137160000000','0.034233223695472','0.042990559989663','313.4336540512014','313.433654051201415','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.036179298427515','0.036179298427515','273.8159269470572','273.815926947057221','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.036179298427515','0.035751070663783','297.3803914804757','297.380391480475680','test','test','1.18'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.036084136702241','0.035847130878253','296.2572799855573','296.257279985557318','test','test','0.65'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000129262000000','0.036031468741355','0.035310839366528','273.1726212384736','273.172621238473596','test','test','2.00'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKBTC','4h','0.000127920000000','0.000125361600000','0.035871328880282','0.035153902302676','280.42001938932145','280.420019389321453','test','test','1.99'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000120050000000','0.035711900751925','0.034997662736887','291.52572042387845','291.525720423878454','test','test','2.00'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.035553181193028','0.035488389113319','294.50945322256274','294.509453222562740','test','test','0.36'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121186800000','0.035538782953092','0.034828007294030','287.39109617574354','287.391096175743542','test','test','2.00'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.035380832806634','0.034921982639725','290.4114980434558','290.411498043455822','test','test','1.29'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000117698000000','0.035278866102877','0.034573288780819','293.7457627217042','293.745762721704182','test','test','2.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000120814400000','0.035122071142419','0.034419629719571','284.89674839730156','284.896748397301565','test','test','1.99'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.034965973048453','0.037372487643820','310.9191983678918','310.919198367891795','test','test','0.0'),('2019-03-08 03:59:59','2019-03-08 11:59:59','LINKBTC','4h','0.000125860000000','0.000123342800000','0.035500754069646','0.034790738988253','282.0654224507054','282.065422450705398','test','test','1.99'),('2019-03-10 11:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000125340000000','0.000122833200000','0.035342972940447','0.034636113481638','281.9768066096006','281.976806609600601','test','test','1.99'),('2019-03-12 01:59:59','2019-03-16 03:59:59','LINKBTC','4h','0.000120940000000','0.000121660000000','0.035185893060712','0.035395367535689','290.93677080132295','290.936770801322950','test','test','0.0'),('2019-03-25 23:59:59','2019-03-26 15:59:59','LINKBTC','4h','0.000120260000000','0.000117854800000','0.035232442944040','0.034527794085159','292.9689251957445','292.968925195744475','test','test','2.00'),('2019-03-27 15:59:59','2019-03-30 11:59:59','LINKBTC','4h','0.000118130000000','0.000119090000000','0.035075854308733','0.035360903154381','296.9258808832078','296.925880883207810','test','test','0.0'),('2019-03-31 07:59:59','2019-04-02 07:59:59','LINKBTC','4h','0.000122840000000','0.000127310000000','0.035139198496655','0.036417871707987','286.0566468304714','286.056646830471379','test','test','0.0'),('2019-05-01 03:59:59','2019-05-01 07:59:59','LINKBTC','4h','0.000089060000000','0.000089820000000','0.035423348099173','0.035725635821555','397.74700313466576','397.747003134665761','test','test','0.0'),('2019-05-05 07:59:59','2019-05-05 19:59:59','LINKBTC','4h','0.000088380000000','0.000087790000000','0.035490523148592','0.035253598407048','401.56735854935005','401.567358549350047','test','test','0.66'),('2019-05-06 11:59:59','2019-05-11 23:59:59','LINKBTC','4h','0.000092640000000','0.000095480000000','0.035437873206026','0.036524267419164','382.5331736401795','382.533173640179484','test','test','0.08'),('2019-05-14 15:59:59','2019-05-14 23:59:59','LINKBTC','4h','0.000107050000000','0.000104909000000','0.035679294142279','0.034965708259433','333.2956015159189','333.295601515918918','test','test','2.00'),('2019-05-15 19:59:59','2019-05-25 15:59:59','LINKBTC','4h','0.000102180000000','0.000142980000000','0.035520719501647','0.049703978022563','347.6288853165656','347.628885316565572','test','test','1.31'),('2019-05-28 19:59:59','2019-05-28 23:59:59','LINKBTC','4h','0.000151910000000','0.000148871800000','0.038672554728517','0.037899103633947','254.57543761777956','254.575437617779556','test','test','2.00'),('2019-06-05 07:59:59','2019-06-09 19:59:59','LINKBTC','4h','0.000127060000000','0.000136520000000','0.038500676707501','0.041367168141886','303.0117795333019','303.011779533301876','test','test','0.0'),('2019-06-10 23:59:59','2019-06-11 03:59:59','LINKBTC','4h','0.000151270000000','0.000148244600000','0.039137674804031','0.038354921307950','258.72727443664525','258.727274436645246','test','test','2.00'),('2019-06-11 07:59:59','2019-06-11 11:59:59','LINKBTC','4h','0.000148010000000','0.000145049800000','0.038963729582680','0.038184454991026','263.2506559197352','263.250655919735209','test','test','1.99'),('2019-06-12 15:59:59','2019-06-12 23:59:59','LINKBTC','4h','0.000140670000000','0.000140860000000','0.038790557451201','0.038842951038432','275.7557222663065','275.755722266306520','test','test','0.78'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKBTC','4h','0.000217740000000','0.000213385200000','0.038802200470586','0.038026156461174','178.2042824955727','178.204282495572699','test','test','2.00'),('2019-06-14 19:59:59','2019-06-14 23:59:59','LINKBTC','4h','0.000195800000000','0.000191884000000','0.038629746246272','0.037857151321347','197.29186029761095','197.291860297610953','test','test','1.99'),('2019-06-17 11:59:59','2019-06-18 11:59:59','LINKBTC','4h','0.000204000000000','0.000199920000000','0.038458058485178','0.037688897315474','188.51989453518522','188.519894535185216','test','test','2.00'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKBTC','4h','0.000179250000000','0.000175665000000','0.038287133780799','0.037521391105183','213.59628329595043','213.596283295950428','test','test','2.00'),('2019-06-27 03:59:59','2019-07-07 23:59:59','LINKBTC','4h','0.000184050000000','0.000286990000000','0.038116968741773','0.059435962288516','207.1011613244952','207.101161324495195','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKBTC','4h','0.000300720000000','0.000294705600000','0.042854522863272','0.041997432406007','142.50639419816372','142.506394198163719','test','test','2.00'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKBTC','4h','0.000284190000000','0.000278506200000','0.042664058317213','0.041810777150869','150.1251216341634','150.125121634163406','test','test','1.99'),('2019-07-13 19:59:59','2019-07-13 23:59:59','LINKBTC','4h','0.000288010000000','0.000282249800000','0.042474440280248','0.041624951474643','147.47557473784784','147.475574737847836','test','test','2.00'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKBTC','4h','0.000276240000000','0.000270715200000','0.042285664990113','0.041439951690311','153.07582171341264','153.075821713412637','test','test','2.00'),('2019-08-03 03:59:59','2019-08-03 19:59:59','LINKBTC','4h','0.000234210000000','0.000233520000000','0.042097728701268','0.041973705675762','179.7435152267974','179.743515226797399','test','test','0.29'),('2019-08-04 19:59:59','2019-08-04 23:59:59','LINKBTC','4h','0.000231790000000','0.000229380000000','0.042070168028934','0.041632750086185','181.50122105756745','181.501221057567449','test','test','1.03'),('2019-08-11 19:59:59','2019-08-11 23:59:59','LINKBTC','4h','0.000213680000000','0.000210030000000','0.041972964041656','0.041255997929937','196.42907170374394','196.429071703743944','test','test','1.70'),('2019-08-13 15:59:59','2019-08-20 11:59:59','LINKBTC','4h','0.000213200000000','0.000225240000000','0.041813638239052','0.044174971280319','196.12400674977386','196.124006749773855','test','test','0.0'),('2019-09-18 07:59:59','2019-10-15 19:59:59','LINKBTC','4h','0.000170760000000','0.000297510000000','0.042338378914889','0.073764881183934','247.94084630410453','247.940846304104525','test','test','1.99'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKBTC','4h','0.000297050000000','0.000296270000000','0.049322046085788','0.049192535242674','166.03954245341788','166.039542453417880','test','test','0.26'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKBTC','4h','0.000296020000000','0.000296150000000','0.049293265898429','0.049314913505235','166.52005235602024','166.520052356020244','test','test','0.0'),('2019-10-20 19:59:59','2019-10-20 23:59:59','LINKBTC','4h','0.000295530000000','0.000297460000000','0.049298076477719','0.049620024461348','166.8124267509875','166.812426750987498','test','test','0.0'),('2019-10-21 03:59:59','2019-10-26 03:59:59','LINKBTC','4h','0.000302500000000','0.000297940000000','0.049369620474081','0.048625404046439','163.20535693911188','163.205356939111880','test','test','1.50'),('2019-11-08 11:59:59','2019-11-19 07:59:59','LINKBTC','4h','0.000296720000000','0.000330580000000','0.049204239045716','0.054819147154667','165.82717392058657','165.827173920586574','test','test','0.0'),('2019-11-19 15:59:59','2019-11-19 19:59:59','LINKBTC','4h','0.000333270000000','0.000328490000000','0.050451996403261','0.049728377287206','151.38475231272278','151.384752312722782','test','test','1.43'),('2019-11-20 11:59:59','2019-11-20 15:59:59','LINKBTC','4h','0.000341150000000','0.000334327000000','0.050291192155249','0.049285368312144','147.41665588523787','147.416655885237873','test','test','1.99'),('2019-11-21 15:59:59','2019-11-21 19:59:59','LINKBTC','4h','0.000338250000000','0.000334850000000','0.050067675745670','0.049564408642831','148.01973612910572','148.019736129105723','test','test','1.00'),('2019-11-23 15:59:59','2019-11-23 19:59:59','LINKBTC','4h','0.000335170000000','0.000334680000000','0.049955838611706','0.049882805938974','149.04627088255452','149.046270882554523','test','test','0.14'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKBTC','4h','0.000294170000000','0.000288286600000','0.049939609128876','0.048940816946298','169.76445296555207','169.764452965552067','test','test','2.00'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKBTC','4h','0.000293250000000','0.000291000000000','0.049717655310526','0.049336189924512','169.54017156189528','169.540171561895278','test','test','0.76'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKBTC','4h','0.000291230000000','0.000287630000000','0.049632885224745','0.049019355070540','170.42504283468358','170.425042834683580','test','test','1.23'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKBTC','4h','0.000266090000000','0.000261920000000','0.049496545190477','0.048720865557855','186.01430038888012','186.014300388880116','test','test','1.56');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:01:17
