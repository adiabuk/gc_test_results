-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 15:59:59','2019-01-14 19:59:59','ADAETH','4h','0.000308000000000','0.000339920000000','1.297777777777778','1.432274747474748','4213.564213564213','4213.564213564212878','test','test','0.0'),('2019-01-14 23:59:59','2019-01-27 07:59:59','ADAETH','4h','0.000341380000000','0.000360010000000','1.327665993265993','1.400120201053636','3889.1147497392735','3889.114749739273520','test','test','0.78'),('2019-01-27 15:59:59','2019-01-27 19:59:59','ADAETH','4h','0.000363000000000','0.000362290000000','1.343766928329914','1.341138623869544','3701.8372681264846','3701.837268126484560','test','test','0.19'),('2019-01-28 11:59:59','2019-01-28 15:59:59','ADAETH','4h','0.000364960000000','0.000365140000000','1.343182860672054','1.343845324818593','3680.3563696625765','3680.356369662576526','test','test','0.0'),('2019-01-28 19:59:59','2019-01-28 23:59:59','ADAETH','4h','0.000366700000000','0.000365480000000','1.343330074926840','1.338860855697468','3663.294450304991','3663.294450304991187','test','test','0.33'),('2019-03-03 15:59:59','2019-03-04 07:59:59','ADAETH','4h','0.000319330000000','0.000318480000000','1.342336915098091','1.338763851565591','4203.604155882915','4203.604155882914711','test','test','0.26'),('2019-03-04 11:59:59','2019-03-04 15:59:59','ADAETH','4h','0.000320580000000','0.000318970000000','1.341542900979758','1.334805474844075','4184.736730238187','4184.736730238187192','test','test','0.50'),('2019-03-05 11:59:59','2019-03-05 15:59:59','ADAETH','4h','0.000319660000000','0.000317350000000','1.340045695171828','1.330361951331976','4192.096900368605','4192.096900368605020','test','test','0.72'),('2019-03-08 23:59:59','2019-04-07 23:59:59','ADAETH','4h','0.000317500000000','0.000515610000000','1.337893752096305','2.172697315018506','4213.838589279702','4213.838589279702319','test','test','0.0'),('2019-04-10 23:59:59','2019-04-11 03:59:59','ADAETH','4h','0.000504110000000','0.000494027800000','1.523405654967906','1.492937541868548','3021.9707106939077','3021.970710693907677','test','test','1.99'),('2019-04-11 19:59:59','2019-04-11 23:59:59','ADAETH','4h','0.000507480000000','0.000505450000000','1.516634963168048','1.510568184230491','2988.5610529834635','2988.561052983463469','test','test','0.40'),('2019-04-13 11:59:59','2019-04-14 07:59:59','ADAETH','4h','0.000510560000000','0.000504530000000','1.515286790070814','1.497390403075893','2967.8917072837935','2967.891707283793494','test','test','1.18'),('2019-04-15 19:59:59','2019-04-16 07:59:59','ADAETH','4h','0.000511810000000','0.000503420000000','1.511309815183053','1.486535212597355','2952.872775410901','2952.872775410900886','test','test','1.63'),('2019-05-14 23:59:59','2019-05-15 02:59:59','ADAETH','4h','0.000390490000000','0.000384110000000','1.505804347941787','1.481201844062383','3856.19183062764','3856.191830627639774','test','test','1.63'),('2019-05-28 19:59:59','2019-05-29 03:59:59','ADAETH','4h','0.000336780000000','0.000334780000000','1.500337124857475','1.491427230416846','4454.947220314374','4454.947220314374135','test','test','0.59'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ADAETH','4h','0.000338610000000','0.000343520000000','1.498357148315113','1.520084012844298','4425.023325699516','4425.023325699516136','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','ADAETH','4h','0.000335800000000','0.000337820000000','1.503185340432710','1.512227729913574','4476.430436071202','4476.430436071202166','test','test','0.0'),('2019-06-01 23:59:59','2019-06-04 07:59:59','ADAETH','4h','0.000342000000000','0.000344290000000','1.505194760317346','1.515273403595494','4401.154269933761','4401.154269933760588','test','test','0.0'),('2019-06-07 11:59:59','2019-06-07 23:59:59','ADAETH','4h','0.000340650000000','0.000341740000000','1.507434458823601','1.512257895078166','4425.170875748132','4425.170875748131948','test','test','0.0'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ADAETH','4h','0.000345530000000','0.000342800000000','1.508506333546838','1.496587767024155','4365.775283034289','4365.775283034288805','test','test','0.79'),('2019-06-11 11:59:59','2019-06-13 19:59:59','ADAETH','4h','0.000345430000000','0.000348810000000','1.505857763208464','1.520592439523911','4359.371690960438','4359.371690960438173','test','test','0.0'),('2019-07-14 23:59:59','2019-07-15 03:59:59','ADAETH','4h','0.000261070000000','0.000261540000000','1.509132135723007','1.511849001329127','5780.565119404785','5780.565119404785037','test','test','0.0'),('2019-07-16 15:59:59','2019-07-16 19:59:59','ADAETH','4h','0.000261410000000','0.000259470000000','1.509735883635479','1.498531692463554','5775.356274187976','5775.356274187975941','test','test','0.74'),('2019-07-17 11:59:59','2019-07-17 15:59:59','ADAETH','4h','0.000260840000000','0.000264460000000','1.507246063375051','1.528163985278968','5778.431465170415','5778.431465170415322','test','test','0.0'),('2019-07-20 19:59:59','2019-07-21 03:59:59','ADAETH','4h','0.000279990000000','0.000274390200000','1.511894490464810','1.481656600655514','5399.816030803994','5399.816030803994181','test','test','2.00'),('2019-07-22 15:59:59','2019-07-23 07:59:59','ADAETH','4h','0.000273160000000','0.000267970000000','1.505174959396078','1.476576855576831','5510.231949758668','5510.231949758667724','test','test','1.89'),('2019-07-24 15:59:59','2019-07-24 23:59:59','ADAETH','4h','0.000272020000000','0.000272230000000','1.498819825214023','1.499976917204667','5509.961860208894','5509.961860208893995','test','test','1.47'),('2019-07-25 15:59:59','2019-07-25 23:59:59','ADAETH','4h','0.000267090000000','0.000267300000000','1.499076956767500','1.500255608760915','5612.628540070761','5612.628540070761119','test','test','0.0'),('2019-07-26 07:59:59','2019-07-31 15:59:59','ADAETH','4h','0.000273540000000','0.000276670000000','1.499338879432703','1.516495166237647','5481.2417907169065','5481.241790716906507','test','test','0.0'),('2019-08-11 19:59:59','2019-08-12 03:59:59','ADAETH','4h','0.000256730000000','0.000251595400000','1.503151387611579','1.473088359859347','5854.989240102752','5854.989240102751864','test','test','1.99'),('2019-08-13 23:59:59','2019-08-14 03:59:59','ADAETH','4h','0.000251540000000','0.000254700000000','1.496470714777750','1.515270299172668','5949.235568012045','5949.235568012045405','test','test','0.0'),('2019-08-14 15:59:59','2019-08-16 03:59:59','ADAETH','4h','0.000253500000000','0.000248430000000','1.500648400198843','1.470635432194866','5919.717555025021','5919.717555025021284','test','test','2.00'),('2019-08-17 19:59:59','2019-08-19 07:59:59','ADAETH','4h','0.000258550000000','0.000253379000000','1.493978851753514','1.464099274718444','5778.297628131944','5778.297628131944293','test','test','1.99'),('2019-08-21 07:59:59','2019-08-21 11:59:59','ADAETH','4h','0.000252390000000','0.000249720000000','1.487338945745721','1.471604586281633','5893.0185258755155','5893.018525875515479','test','test','1.05'),('2019-08-21 15:59:59','2019-08-22 03:59:59','ADAETH','4h','0.000253760000000','0.000257100000000','1.483842421420368','1.503372818991080','5847.424422369042','5847.424422369042077','test','test','0.56'),('2019-08-22 15:59:59','2019-08-23 07:59:59','ADAETH','4h','0.000260890000000','0.000255672200000','1.488182509769415','1.458418859574027','5704.252787647727','5704.252787647727018','test','test','2.00'),('2019-08-24 19:59:59','2019-08-26 11:59:59','ADAETH','4h','0.000265630000000','0.000260317400000','1.481568365281552','1.451936997975921','5577.564150440657','5577.564150440656704','test','test','1.99'),('2019-08-26 15:59:59','2019-08-28 19:59:59','ADAETH','4h','0.000264590000000','0.000267440000000','1.474983616991411','1.490871229177909','5574.6007671923035','5574.600767192303465','test','test','1.73'),('2019-08-29 15:59:59','2019-08-31 23:59:59','ADAETH','4h','0.000262730000000','0.000260950000000','1.478514197477300','1.468497239872498','5627.504272360598','5627.504272360598407','test','test','0.67'),('2019-09-06 23:59:59','2019-09-07 03:59:59','ADAETH','4h','0.000262030000000','0.000259080000000','1.476288206898455','1.459667780953523','5634.0426931971715','5634.042693197171502','test','test','1.12'),('2019-09-08 15:59:59','2019-09-08 23:59:59','ADAETH','4h','0.000260280000000','0.000256690000000','1.472594778910692','1.452283516976278','5657.733129363349','5657.733129363348780','test','test','1.37'),('2019-09-10 03:59:59','2019-09-10 15:59:59','ADAETH','4h','0.000259610000000','0.000261780000000','1.468081165147489','1.480352403267631','5654.948442461728','5654.948442461727609','test','test','0.0'),('2019-09-18 15:59:59','2019-09-18 19:59:59','ADAETH','4h','0.000259050000000','0.000253869000000','1.470808106951965','1.441391944812926','5677.6996987144','5677.699698714400256','test','test','1.99'),('2019-10-05 11:59:59','2019-10-05 15:59:59','ADAETH','4h','0.000225520000000','0.000224750000000','1.464271182032179','1.459271675069760','6492.8661849599985','6492.866184959998463','test','test','0.34'),('2019-10-05 19:59:59','2019-10-05 23:59:59','ADAETH','4h','0.000226590000000','0.000224800000000','1.463160180484975','1.451601608954598','6457.302530936822','6457.302530936822222','test','test','0.78'),('2019-10-06 11:59:59','2019-10-06 19:59:59','ADAETH','4h','0.000226500000000','0.000227720000000','1.460591609033780','1.468458813285529','6448.5280752043245','6448.528075204324523','test','test','0.0'),('2019-10-07 11:59:59','2019-10-08 07:59:59','ADAETH','4h','0.000230450000000','0.000226540000000','1.462339876645279','1.437528642461365','6345.584190259403','6345.584190259402931','test','test','1.69'),('2019-10-09 11:59:59','2019-10-09 15:59:59','ADAETH','4h','0.000234280000000','0.000229594400000','1.456826269048854','1.427689743667877','6218.312570637075','6218.312570637074714','test','test','2.00'),('2019-10-14 07:59:59','2019-10-14 19:59:59','ADAETH','4h','0.000229320000000','0.000224733600000','1.450351485630859','1.421344455918242','6324.574767272193','6324.574767272192730','test','test','2.00'),('2019-10-19 15:59:59','2019-10-20 11:59:59','ADAETH','4h','0.000225570000000','0.000224020000000','1.443905479028055','1.433983709765771','6401.141459538304','6401.141459538303934','test','test','0.68'),('2019-10-20 15:59:59','2019-10-20 19:59:59','ADAETH','4h','0.000225560000000','0.000223460000000','1.441700641414214','1.428278175786577','6391.650298874864','6391.650298874864347','test','test','0.93'),('2019-10-21 15:59:59','2019-10-23 23:59:59','ADAETH','4h','0.000223720000000','0.000224240000000','1.438717871274740','1.442061932123403','6430.88624742866','6430.886247428659772','test','test','0.0'),('2019-10-24 03:59:59','2019-10-24 07:59:59','ADAETH','4h','0.000225920000000','0.000228340000000','1.439460995907776','1.454880151405726','6371.551858656941','6371.551858656940567','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 19:59:59','ADAETH','4h','0.000231510000000','0.000228630000000','1.442887474907320','1.424937857492379','6232.506046854652','6232.506046854651686','test','test','1.48'),('2019-10-27 15:59:59','2019-10-29 19:59:59','ADAETH','4h','0.000231690000000','0.000227056200000','1.438898671037333','1.410120697616586','6210.447887424288','6210.447887424287728','test','test','2.00'),('2019-10-30 03:59:59','2019-10-30 11:59:59','ADAETH','4h','0.000228710000000','0.000226930000000','1.432503565832723','1.421354703311704','6263.40591068481','6263.405910684809896','test','test','0.77'),('2019-11-01 03:59:59','2019-11-01 23:59:59','ADAETH','4h','0.000232290000000','0.000230710000000','1.430026040828052','1.420299228892505','6156.210085789539','6156.210085789539335','test','test','0.92'),('2019-11-04 11:59:59','2019-11-04 15:59:59','ADAETH','4h','0.000229630000000','0.000230010000000','1.427864527064597','1.430227408745059','6218.109685426978','6218.109685426978103','test','test','0.0'),('2019-11-04 23:59:59','2019-11-06 07:59:59','ADAETH','4h','0.000232600000000','0.000232270000000','1.428389611882477','1.426363091796831','6140.969956502483','6140.969956502483001','test','test','0.70'),('2019-11-06 11:59:59','2019-11-07 07:59:59','ADAETH','4h','0.000236880000000','0.000232142400000','1.427939274085667','1.399380488603954','6028.112437038447','6028.112437038446842','test','test','2.00'),('2019-11-10 23:59:59','2019-11-11 03:59:59','ADAETH','4h','0.000231930000000','0.000230440000000','1.421592877311953','1.412460064018309','6129.404895062964','6129.404895062963988','test','test','0.64'),('2019-11-11 15:59:59','2019-11-13 11:59:59','ADAETH','4h','0.000232500000000','0.000232430000000','1.419563363246699','1.419135967825506','6105.648874179349','6105.648874179349150','test','test','0.03'),('2019-11-15 11:59:59','2019-11-19 11:59:59','ADAETH','4h','0.000236520000000','0.000236920000000','1.419468386486434','1.421868975673795','6001.47296840197','6001.472968401970320','test','test','0.43'),('2019-11-19 19:59:59','2019-11-20 07:59:59','ADAETH','4h','0.000240930000000','0.000236740000000','1.420001850750292','1.395306678896875','5893.835764538629','5893.835764538628609','test','test','1.73'),('2019-11-21 19:59:59','2019-11-22 03:59:59','ADAETH','4h','0.000239990000000','0.000235500000000','1.414514034782866','1.388049732036189','5894.054063847935','5894.054063847935140','test','test','1.87'),('2019-11-22 07:59:59','2019-11-22 11:59:59','ADAETH','4h','0.000239680000000','0.000240510000000','1.408633078616938','1.413511105382843','5877.140681812992','5877.140681812991716','test','test','0.0'),('2019-11-22 15:59:59','2019-12-02 07:59:59','ADAETH','4h','0.000245800000000','0.000255180000000','1.409717084564917','1.463513448491764','5735.220034845062','5735.220034845062401','test','test','0.07'),('2019-12-03 11:59:59','2019-12-04 03:59:59','ADAETH','4h','0.000257070000000','0.000253360000000','1.421671832104216','1.401154453580442','5530.290707216774','5530.290707216773626','test','test','1.44'),('2019-12-06 19:59:59','2019-12-06 23:59:59','ADAETH','4h','0.000254850000000','0.000257390000000','1.417112414654488','1.431236273917672','5560.574513064502','5560.574513064501843','test','test','0.0'),('2019-12-07 03:59:59','2019-12-08 19:59:59','ADAETH','4h','0.000259160000000','0.000256410000000','1.420251050046307','1.405180474387921','5480.209330322223','5480.209330322222741','test','test','1.06'),('2019-12-13 11:59:59','2019-12-14 11:59:59','ADAETH','4h','0.000257010000000','0.000254320000000','1.416902033233333','1.402072001447030','5513.0229688857735','5513.022968885773480','test','test','1.04'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ADAETH','4h','0.000255280000000','0.000255440000000','1.413606470614154','1.414492466521778','5537.474422650243','5537.474422650242559','test','test','0.0'),('2019-12-16 19:59:59','2019-12-17 07:59:59','ADAETH','4h','0.000256510000000','0.000256000000000','1.413803358593626','1.410992397177374','5511.689051474117','5511.689051474117150','test','test','0.47'),('2019-12-17 11:59:59','2019-12-17 15:59:59','ADAETH','4h','0.000256290000000','0.000257320000000','1.413178700501126','1.418858102980802','5513.982989976689','5513.982989976689169','test','test','0.0'),('2019-12-17 23:59:59','2019-12-18 15:59:59','ADAETH','4h','0.000259740000000','0.000257510000000','1.414440789941054','1.402297096395322','5445.602486875543','5445.602486875543036','test','test','0.85'),('2019-12-23 19:59:59','2019-12-23 23:59:59','ADAETH','4h','0.000259170000000','0.000258460000000','1.411742191375335','1.407874703024536','5447.166691265716','5447.166691265715599','test','test','0.27'),('2019-12-24 11:59:59','2019-12-27 11:59:59','ADAETH','4h','0.000263370000000','0.000260010000000','1.410882749519602','1.392883106286182','5357.036676613137','5357.036676613137388','test','test','1.27'),('2019-12-28 07:59:59','2019-12-28 11:59:59','ADAETH','4h','0.000262520000000','0.000262440000000','1.406882828801064','1.406454097175649','5359.145317694136','5359.145317694135883','test','test','0.03'),('2019-12-28 15:59:59','2019-12-28 19:59:59','ADAETH','4h','0.000265720000000','0.000261990000000','1.406787555106528','1.387040010395752','5294.247911736142','5294.247911736141759','test','test','1.40');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:33:18
