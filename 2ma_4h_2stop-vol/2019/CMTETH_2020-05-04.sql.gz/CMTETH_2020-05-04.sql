-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','CMTETH','4h','0.000183550000000','0.000181860000000','1.297777777777778','1.285828747843458','7070.431913798844','7070.431913798844107','test','test','0.92'),('2019-01-13 07:59:59','2019-01-14 15:59:59','CMTETH','4h','0.000189330000000','0.000185543400000','1.295122437792373','1.269219989036525','6840.555843196395','6840.555843196394562','test','test','1.99'),('2019-01-15 23:59:59','2019-01-27 19:59:59','CMTETH','4h','0.000187730000000','0.000227580000000','1.289366338068852','1.563063928076010','6868.195483241099','6868.195483241099282','test','test','0.67'),('2019-02-05 23:59:59','2019-02-06 03:59:59','CMTETH','4h','0.000215820000000','0.000213580000000','1.350188024737109','1.336174396827688','6256.083888134133','6256.083888134133304','test','test','1.03'),('2019-02-07 19:59:59','2019-02-07 23:59:59','CMTETH','4h','0.000216230000000','0.000215410000000','1.347073885201682','1.341965433155872','6229.819568060315','6229.819568060314850','test','test','0.37'),('2019-02-08 07:59:59','2019-02-08 11:59:59','CMTETH','4h','0.000214390000000','0.000216070000000','1.345938673635946','1.356485699951112','6277.99185426534','6277.991854265340407','test','test','0.0'),('2019-02-10 07:59:59','2019-02-10 15:59:59','CMTETH','4h','0.000220300000000','0.000215894000000','1.348282457261539','1.321316808116308','6120.210881804534','6120.210881804534438','test','test','2.00'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CMTETH','4h','0.000216880000000','0.000212542400000','1.342290090784821','1.315444288969124','6189.091160018539','6189.091160018539085','test','test','1.99'),('2019-02-16 03:59:59','2019-02-16 11:59:59','CMTETH','4h','0.000213290000000','0.000209024200000','1.336324357047999','1.309597869907039','6265.293061315576','6265.293061315575869','test','test','2.00'),('2019-02-16 19:59:59','2019-02-17 11:59:59','CMTETH','4h','0.000210590000000','0.000206378200000','1.330385137683342','1.303777434929675','6317.41838493443','6317.418384934429923','test','test','2.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','CMTETH','4h','0.000193790000000','0.000191180000000','1.324472314849193','1.306634073754418','6834.575132097597','6834.575132097596907','test','test','1.34'),('2019-02-26 03:59:59','2019-03-05 15:59:59','CMTETH','4h','0.000201420000000','0.000205520000000','1.320508261272576','1.347387835650580','6555.99375073268','6555.993750732680382','test','test','0.93'),('2019-03-08 03:59:59','2019-03-16 03:59:59','CMTETH','4h','0.000212910000000','0.000237970000000','1.326481500023244','1.482611444086851','6230.245174126364','6230.245174126363963','test','test','0.42'),('2019-03-17 15:59:59','2019-03-18 15:59:59','CMTETH','4h','0.000239420000000','0.000239550000000','1.361177043148490','1.361916133515248','5685.310513526399','5685.310513526398609','test','test','0.93'),('2019-03-19 11:59:59','2019-03-21 15:59:59','CMTETH','4h','0.000242390000000','0.000241470000000','1.361341285452214','1.356174265432345','5616.326108553217','5616.326108553216727','test','test','0.37'),('2019-03-21 19:59:59','2019-03-21 23:59:59','CMTETH','4h','0.000244590000000','0.000242790000000','1.360193058781132','1.350183052215835','5561.114758498434','5561.114758498433730','test','test','0.73'),('2019-03-22 03:59:59','2019-03-22 07:59:59','CMTETH','4h','0.000243920000000','0.000242340000000','1.357968612877733','1.349172325536200','5567.270469324913','5567.270469324913392','test','test','0.64'),('2019-03-23 07:59:59','2019-03-24 11:59:59','CMTETH','4h','0.000247080000000','0.000243860000000','1.356013882357392','1.338342016155390','5488.15720559087','5488.157205590870035','test','test','1.34'),('2019-03-25 03:59:59','2019-03-25 07:59:59','CMTETH','4h','0.000244010000000','0.000240460000000','1.352086800979169','1.332415852479206','5541.112253510796','5541.112253510796108','test','test','1.45'),('2019-03-27 15:59:59','2019-03-27 23:59:59','CMTETH','4h','0.000243660000000','0.000238786800000','1.347715479090289','1.320761169508483','5531.131408890622','5531.131408890621969','test','test','2.00'),('2019-03-28 07:59:59','2019-03-29 15:59:59','CMTETH','4h','0.000242980000000','0.000241030000000','1.341725632516554','1.330957812188102','5521.959142795926','5521.959142795925800','test','test','0.80'),('2019-03-30 15:59:59','2019-04-03 03:59:59','CMTETH','4h','0.000252750000000','0.000247695000000','1.339332783554676','1.312546127883582','5299.041675785068','5299.041675785068037','test','test','2.00'),('2019-04-03 07:59:59','2019-04-07 23:59:59','CMTETH','4h','0.000261660000000','0.000275150000000','1.333380193405544','1.402123214153999','5095.85031493367','5095.850314933670234','test','test','0.0'),('2019-05-24 11:59:59','2019-05-24 19:59:59','CMTETH','4h','0.000165310000000','0.000169570000000','1.348656420238534','1.383410980460034','8158.347469835667','8158.347469835666743','test','test','1.56'),('2019-05-24 23:59:59','2019-05-25 07:59:59','CMTETH','4h','0.000168100000000','0.000164738000000','1.356379655843312','1.329252062726446','8068.885519591385','8068.885519591384764','test','test','1.99'),('2019-05-26 15:59:59','2019-05-26 19:59:59','CMTETH','4h','0.000168090000000','0.000164728200000','1.350351301817342','1.323344275780995','8033.501706331975','8033.501706331974674','test','test','2.00'),('2019-05-27 15:59:59','2019-05-27 19:59:59','CMTETH','4h','0.000165250000000','0.000164360000000','1.344349740475931','1.337109369710282','8135.248051291563','8135.248051291562660','test','test','0.53'),('2019-06-08 11:59:59','2019-06-09 15:59:59','CMTETH','4h','0.000148210000000','0.000149640000000','1.342740769194676','1.355696165591332','9059.717759899304','9059.717759899303928','test','test','0.0'),('2019-06-10 07:59:59','2019-06-11 03:59:59','CMTETH','4h','0.000153230000000','0.000150165400000','1.345619746171710','1.318707351248276','8781.699054830715','8781.699054830714886','test','test','2.00'),('2019-06-13 19:59:59','2019-06-14 19:59:59','CMTETH','4h','0.000167940000000','0.000164581200000','1.339639213966503','1.312846429687173','7976.891830216166','7976.891830216166454','test','test','1.99'),('2019-06-15 07:59:59','2019-06-16 19:59:59','CMTETH','4h','0.000202500000000','0.000198450000000','1.333685261904429','1.307011556666341','6586.100058787307','6586.100058787306807','test','test','1.99'),('2019-06-18 19:59:59','2019-06-19 07:59:59','CMTETH','4h','0.000182500000000','0.000178850000000','1.327757771851521','1.301202616414491','7275.385051241211','7275.385051241210931','test','test','2.00'),('2019-07-03 07:59:59','2019-07-07 19:59:59','CMTETH','4h','0.000153910000000','0.000180160000000','1.321856626198848','1.547304852030307','8588.503841198411','8588.503841198411465','test','test','0.0'),('2019-07-09 15:59:59','2019-07-09 19:59:59','CMTETH','4h','0.000233600000000','0.000228928000000','1.371956231939172','1.344517107300389','5873.100307958784','5873.100307958783560','test','test','1.99'),('2019-07-10 03:59:59','2019-07-10 07:59:59','CMTETH','4h','0.000216970000000','0.000212630600000','1.365858648686109','1.338541475712387','6295.149784237954','6295.149784237954009','test','test','2.00'),('2019-07-10 11:59:59','2019-07-10 15:59:59','CMTETH','4h','0.000203530000000','0.000199459400000','1.359788165803060','1.332592402486999','6681.020811688987','6681.020811688987123','test','test','1.99'),('2019-07-10 19:59:59','2019-07-10 23:59:59','CMTETH','4h','0.000204770000000','0.000200674600000','1.353744662843935','1.326669769587056','6611.049777037334','6611.049777037334024','test','test','1.99'),('2019-07-14 11:59:59','2019-07-15 11:59:59','CMTETH','4h','0.000219900000000','0.000215502000000','1.347728019897962','1.320773459500003','6128.822282391822','6128.822282391822228','test','test','1.99'),('2019-07-15 15:59:59','2019-07-15 19:59:59','CMTETH','4h','0.000223040000000','0.000218579200000','1.341738117587304','1.314903355235558','6015.683812712089','6015.683812712089093','test','test','1.99'),('2019-07-15 23:59:59','2019-07-16 03:59:59','CMTETH','4h','0.000234450000000','0.000229761000000','1.335774837064694','1.309059340323400','5697.482776987392','5697.482776987391844','test','test','1.99'),('2019-07-19 15:59:59','2019-07-19 19:59:59','CMTETH','4h','0.000208700000000','0.000204870000000','1.329838060011073','1.305433269547046','6372.007954054016','6372.007954054016409','test','test','1.83'),('2019-07-23 03:59:59','2019-07-23 07:59:59','CMTETH','4h','0.000208660000000','0.000204486800000','1.324414773241289','1.297926477776463','6347.238441681632','6347.238441681632139','test','test','2.00'),('2019-07-28 19:59:59','2019-07-28 23:59:59','CMTETH','4h','0.000203240000000','0.000199175200000','1.318528485360217','1.292157915653013','6487.5442105895345','6487.544210589534487','test','test','1.99'),('2019-08-19 11:59:59','2019-08-20 19:59:59','CMTETH','4h','0.000170960000000','0.000167540800000','1.312668358758616','1.286414991583444','7678.219225307768','7678.219225307768284','test','test','2.00'),('2019-08-25 07:59:59','2019-08-25 15:59:59','CMTETH','4h','0.000166610000000','0.000163770000000','1.306834277164133','1.284558247231079','7843.672511638758','7843.672511638757896','test','test','1.70'),('2019-09-22 03:59:59','2019-09-22 07:59:59','CMTETH','4h','0.000113060000000','0.000112630000000','1.301884048290121','1.296932605332711','11514.983621883259','11514.983621883258820','test','test','0.38'),('2019-10-03 03:59:59','2019-10-03 11:59:59','CMTETH','4h','0.000106100000000','0.000103978000000','1.300783727632919','1.274768053080261','12259.978582779633','12259.978582779633143','test','test','2.00'),('2019-10-03 15:59:59','2019-10-05 15:59:59','CMTETH','4h','0.000103630000000','0.000103080000000','1.295002466621217','1.288129443783799','12496.405158942558','12496.405158942558046','test','test','0.53'),('2019-10-08 19:59:59','2019-10-09 03:59:59','CMTETH','4h','0.000104310000000','0.000102670000000','1.293475128212902','1.273138638803745','12400.298420217643','12400.298420217643070','test','test','1.57'),('2019-10-09 07:59:59','2019-10-09 15:59:59','CMTETH','4h','0.000104130000000','0.000102047400000','1.288955908344201','1.263176790177317','12378.333893634886','12378.333893634886408','test','test','1.99'),('2019-10-22 11:59:59','2019-10-23 03:59:59','CMTETH','4h','0.000095550000000','0.000096390000000','1.283227215418226','1.294508333795529','13429.902830122723','13429.902830122722662','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','CMTETH','4h','0.000097750000000','0.000095795000000','1.285734130613183','1.260019448000919','13153.290338753786','13153.290338753786273','test','test','2.00'),('2019-10-27 15:59:59','2019-10-28 11:59:59','CMTETH','4h','0.000099330000000','0.000097343400000','1.280019756699346','1.254419361565359','12886.537367354738','12886.537367354738308','test','test','2.00'),('2019-10-29 11:59:59','2019-10-29 23:59:59','CMTETH','4h','0.000108680000000','0.000106506400000','1.274330780002905','1.248844164402847','11725.531652584696','11725.531652584695621','test','test','1.99'),('2019-10-30 03:59:59','2019-10-30 07:59:59','CMTETH','4h','0.000118940000000','0.000116561200000','1.268667087647336','1.243293745894389','10666.446003424719','10666.446003424718583','test','test','1.99'),('2019-10-30 11:59:59','2019-10-30 15:59:59','CMTETH','4h','0.000117660000000','0.000115306800000','1.263028567257792','1.237767995912636','10734.56201986905','10734.562019869050346','test','test','1.99'),('2019-11-05 03:59:59','2019-11-05 15:59:59','CMTETH','4h','0.000117800000000','0.000115444000000','1.257415106958869','1.232266804819692','10674.152011535389','10674.152011535388738','test','test','2.00'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CMTETH','4h','0.000106670000000','0.000111490000000','1.251826595372385','1.308391741989943','11735.507597003705','11735.507597003705087','test','test','0.0'),('2019-11-14 19:59:59','2019-11-16 15:59:59','CMTETH','4h','0.000111390000000','0.000109162200000','1.264396627954065','1.239108695394984','11351.078444690409','11351.078444690409015','test','test','2.00'),('2019-11-28 15:59:59','2019-11-28 19:59:59','CMTETH','4h','0.000102160000000','0.000100116800000','1.258777087385380','1.233601545637672','12321.623799778581','12321.623799778581088','test','test','2.00'),('2019-11-29 11:59:59','2019-11-29 15:59:59','CMTETH','4h','0.000100180000000','0.000098640000000','1.253182522552556','1.233918187508326','12509.308470279057','12509.308470279056564','test','test','1.53'),('2019-12-04 15:59:59','2019-12-04 19:59:59','CMTETH','4h','0.000098250000000','0.000096490000000','1.248901559209394','1.226529378606763','12711.466251495101','12711.466251495101460','test','test','1.79'),('2019-12-19 15:59:59','2019-12-19 19:59:59','CMTETH','4h','0.000091710000000','0.000089875800000','1.243929963519920','1.219051364249522','13563.733110019846','13563.733110019846208','test','test','1.99'),('2019-12-27 03:59:59','2019-12-27 11:59:59','CMTETH','4h','0.000094120000000','0.000092237600000','1.238401385904276','1.213633358186190','13157.685783088355','13157.685783088354583','test','test','2.00'),('2019-12-27 15:59:59','2019-12-27 19:59:59','CMTETH','4h','0.000091650000000','0.000089840000000','1.232897379744702','1.208548833565346','13452.235458207328','13452.235458207327611','test','test','1.97');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:33:08
