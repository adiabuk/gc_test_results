-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 15:59:59','WAVESETH','4h','0.022350000000000','0.021903000000000','1.297777777777778','1.271822222222222','58.06611981108625','58.066119811086253','test','test','1.99'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','1.292009876543210','1.290246497099509','60.80618771381823','60.806187713818233','test','test','0.13'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','1.291618014444609','1.287597129158380','60.92250433680531','60.922504336805311','test','test','0.31'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','1.290724484381003','1.285602319847153','60.97814921250074','60.978149212500739','test','test','0.39'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021180740000000','1.289586225595703','1.263794501083789','59.66715521194203','59.667155211942031','test','test','2.00'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','1.283854731259722','1.317558806473441','56.3613297888284','56.361329788828400','test','test','0.0'),('2019-01-27 11:59:59','2019-01-27 15:59:59','WAVESETH','4h','0.025120000000000','0.024617600000000','1.291344525751660','1.265517635236627','51.40702729903104','51.407027299031043','test','test','2.00'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.024754000000000','0.024258920000000','1.285605216748319','1.259893112413352','51.935251545136914','51.935251545136914','test','test','2.00'),('2019-01-28 07:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.025285000000000','0.025468000000000','1.279891415784993','1.289154620415749','50.61860453964774','50.618604539647741','test','test','0.86'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025707360000000','1.281949905702939','1.256310907588880','48.869697533658844','48.869697533658844','test','test','1.99'),('2019-02-04 11:59:59','2019-02-04 23:59:59','WAVESETH','4h','0.025830000000000','0.025313400000000','1.276252350566481','1.250727303555151','49.4096922402819','49.409692240281899','test','test','1.99'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019465000000000','1.270580117897297','1.246062172252665','64.0155238763249','64.015523876324906','test','test','1.92'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','1.265131685531823','1.257918775316631','63.83106385125242','63.831063851252424','test','test','0.57'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.019914580000000','1.263528816595114','1.238258240263212','62.1784762853754','62.178476285375403','test','test','2.00'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019660760000000','1.257913132965802','1.232754870306486','62.70128267200689','62.701282672006890','test','test','2.00'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','1.252322407930399','1.245072618002788','63.041651544444925','63.041651544444925','test','test','0.57'),('2019-03-10 11:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.020057000000000','0.019897000000000','1.250711343502041','1.240734087932398','62.35784731026778','62.357847310267779','test','test','0.79'),('2019-03-12 11:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020149000000000','0.019794000000000','1.248494175597676','1.226497280846712','61.963083805532555','61.963083805532555','test','test','1.76'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','1.243605976764128','1.231984065687763','61.491592996643995','61.491592996643995','test','test','0.93'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','1.241023329858269','1.243839385164774','61.218593619685734','61.218593619685734','test','test','0.0'),('2019-03-22 11:59:59','2019-03-22 15:59:59','WAVESETH','4h','0.020126000000000','0.020116000000000','1.241649119926381','1.241032182074882','61.69378514987485','61.693785149874849','test','test','0.04'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','1.241512022626048','1.234035249659300','61.28502431760529','61.285024317605291','test','test','0.60'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.019949860000000','1.239850517522326','1.215053507171880','60.90536510892206','60.905365108922062','test','test','2.00'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.013265280000000','1.234340070777783','1.209653269362227','91.18942603263761','91.189426032637613','test','test','2.00'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','1.228854114907659','1.509961572345522','113.25844377029118','113.258443770291180','test','test','0.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','1.291322438782740','1.290482515248873','119.98907626674779','119.989076266747787','test','test','0.06'),('2019-06-11 11:59:59','2019-06-11 15:59:59','WAVESETH','4h','0.009790000000000','0.009726000000000','1.291135789108547','1.282695269138890','131.8831245258986','131.883124525898609','test','test','0.65'),('2019-07-06 19:59:59','2019-07-06 23:59:59','WAVESETH','4h','0.006730000000000','0.006739000000000','1.289260118004179','1.290984240004482','191.5691111447517','191.569111144751702','test','test','0.0'),('2019-07-07 03:59:59','2019-07-07 15:59:59','WAVESETH','4h','0.007291000000000','0.007145180000000','1.289643256226469','1.263850391101940','176.881532879779','176.881532879779002','test','test','2.00'),('2019-07-14 11:59:59','2019-07-15 11:59:59','WAVESETH','4h','0.006317000000000','0.006640000000000','1.283911508421018','1.349560300129105','203.24703315197368','203.247033151973682','test','test','0.66'),('2019-07-15 23:59:59','2019-07-18 07:59:59','WAVESETH','4h','0.006533000000000','0.006681000000000','1.298500128800593','1.327916632560349','198.76016053889373','198.760160538893729','test','test','0.0'),('2019-07-18 15:59:59','2019-07-18 19:59:59','WAVESETH','4h','0.006800000000000','0.006664000000000','1.305037129636094','1.278936387043372','191.9172249464844','191.917224946484396','test','test','1.99'),('2019-07-19 11:59:59','2019-07-20 03:59:59','WAVESETH','4h','0.006712000000000','0.006577760000000','1.299236964615489','1.273252225323179','193.56927363162828','193.569273631628278','test','test','1.99'),('2019-07-20 19:59:59','2019-07-20 23:59:59','WAVESETH','4h','0.006525000000000','0.006516000000000','1.293462578106087','1.291678491791458','198.231812736565','198.231812736564990','test','test','0.13'),('2019-07-21 03:59:59','2019-07-21 11:59:59','WAVESETH','4h','0.006551000000000','0.006505000000000','1.293066114480614','1.283986425690184','197.38453892239562','197.384538922395620','test','test','0.70'),('2019-07-21 19:59:59','2019-07-21 23:59:59','WAVESETH','4h','0.006615000000000','0.006501000000000','1.291048405860518','1.268799045578115','195.16982703862706','195.169827038627062','test','test','1.72'),('2019-07-22 07:59:59','2019-07-22 11:59:59','WAVESETH','4h','0.006519000000000','0.006511000000000','1.286104103575540','1.284525819662578','197.28548912034665','197.285489120346654','test','test','0.12'),('2019-07-22 15:59:59','2019-07-22 23:59:59','WAVESETH','4h','0.006557000000000','0.006576000000000','1.285753373817104','1.289479058444605','196.08866460532315','196.088664605323146','test','test','0.0'),('2019-07-26 15:59:59','2019-07-26 19:59:59','WAVESETH','4h','0.006506000000000','0.006482000000000','1.286581303734326','1.281835230680280','197.75304391858688','197.753043918586883','test','test','0.36'),('2019-07-27 11:59:59','2019-07-27 15:59:59','WAVESETH','4h','0.006532000000000','0.006512000000000','1.285526620833427','1.281590531976007','196.80444287100843','196.804442871008433','test','test','0.30'),('2019-07-28 19:59:59','2019-07-28 23:59:59','WAVESETH','4h','0.006502000000000','0.006410000000000','1.284651934420667','1.266474761555902','197.5779659213576','197.577965921357588','test','test','1.41'),('2019-07-29 11:59:59','2019-07-29 23:59:59','WAVESETH','4h','0.006650000000000','0.006517000000000','1.280612562672941','1.255000311419482','192.57331769517918','192.573317695179185','test','test','2.00'),('2019-07-30 03:59:59','2019-07-30 11:59:59','WAVESETH','4h','0.006566000000000','0.006505000000000','1.274920951283284','1.263076574489455','194.17011137424365','194.170111374243646','test','test','0.92'),('2019-08-09 11:59:59','2019-08-09 15:59:59','WAVESETH','4h','0.006208000000000','0.006212000000000','1.272288867551322','1.273108641306188','204.9434387163856','204.943438716385600','test','test','0.0'),('2019-08-14 19:59:59','2019-08-19 07:59:59','WAVESETH','4h','0.006449000000000','0.006320020000000','1.272471039496848','1.247021618706911','197.312922855768','197.312922855767994','test','test','1.99'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESETH','4h','0.006417000000000','0.006314000000000','1.266815612654639','1.246481810550318','197.41555441088352','197.415554410883516','test','test','1.60'),('2019-08-21 07:59:59','2019-08-22 03:59:59','WAVESETH','4h','0.006459000000000','0.006446000000000','1.262296989964790','1.259756370539253','195.43226350283177','195.432263502831773','test','test','0.99'),('2019-08-22 07:59:59','2019-08-23 07:59:59','WAVESETH','4h','0.006491000000000','0.006561000000000','1.261732407870227','1.275339135423904','194.3818221953823','194.381822195382313','test','test','0.0'),('2019-08-23 15:59:59','2019-08-23 23:59:59','WAVESETH','4h','0.006860000000000','0.006722800000000','1.264756125104377','1.239461002602289','184.36678208518617','184.366782085186173','test','test','2.00'),('2019-08-24 03:59:59','2019-08-25 23:59:59','WAVESETH','4h','0.006905000000000','0.006766900000000','1.259134986770580','1.233952287035168','182.35119287046774','182.351192870467742','test','test','2.00'),('2019-08-28 15:59:59','2019-08-28 19:59:59','WAVESETH','4h','0.006644000000000','0.006634000000000','1.253538831273821','1.251652108168352','188.67231054693278','188.672310546932778','test','test','0.15'),('2019-09-23 03:59:59','2019-09-23 07:59:59','WAVESETH','4h','0.005622000000000','0.005509560000000','1.253119559472606','1.228057168283154','222.8956882733202','222.895688273320189','test','test','2.00'),('2019-10-04 15:59:59','2019-10-07 19:59:59','WAVESETH','4h','0.005082000000000','0.005063000000000','1.247550139208284','1.242885941521358','245.48408878557336','245.484088785573363','test','test','0.86'),('2019-10-08 15:59:59','2019-10-08 19:59:59','WAVESETH','4h','0.005096000000000','0.005004000000000','1.246513650833411','1.224009872207690','244.60628941001005','244.606289410010049','test','test','1.80'),('2019-10-29 03:59:59','2019-10-29 07:59:59','WAVESETH','4h','0.004591000000000','0.004499180000000','1.241512811138807','1.216682554916031','270.4231782049241','270.423178204924113','test','test','2.00'),('2019-11-04 03:59:59','2019-11-04 07:59:59','WAVESETH','4h','0.004392000000000','0.004358000000000','1.235994976422634','1.226426709300965','281.4196212255542','281.419621225554181','test','test','0.77'),('2019-11-05 03:59:59','2019-11-05 07:59:59','WAVESETH','4h','0.004421000000000','0.004347000000000','1.233868694840041','1.213215837247152','279.09267017417807','279.092670174178068','test','test','1.67'),('2019-11-05 11:59:59','2019-11-05 15:59:59','WAVESETH','4h','0.004388000000000','0.004354000000000','1.229279170930510','1.219754218375442','280.14566338434594','280.145663384345937','test','test','0.77'),('2019-11-15 15:59:59','2019-11-16 03:59:59','WAVESETH','4h','0.004301000000000','0.004258000000000','1.227162514807162','1.214893742861868','285.32027779752656','285.320277797526558','test','test','0.99'),('2019-11-22 03:59:59','2019-11-22 11:59:59','WAVESETH','4h','0.004218000000000','0.004195000000000','1.224436121041541','1.217759489750892','290.28831698471805','290.288316984718051','test','test','0.54'),('2019-12-11 15:59:59','2019-12-11 19:59:59','WAVESETH','4h','0.004428000000000','0.004339440000000','1.222952425199174','1.198493376695191','276.18618455265903','276.186184552659029','test','test','1.99'),('2019-12-12 03:59:59','2019-12-12 11:59:59','WAVESETH','4h','0.004396000000000','0.004308080000000','1.217517081087178','1.193166739465434','276.96020952847545','276.960209528475445','test','test','2.00'),('2019-12-12 15:59:59','2019-12-13 03:59:59','WAVESETH','4h','0.004371000000000','0.004283580000000','1.212105894060124','1.187863776178921','277.30631298561514','277.306312985615136','test','test','2.00'),('2019-12-13 15:59:59','2019-12-13 19:59:59','WAVESETH','4h','0.004450000000000','0.004361000000000','1.206718756753190','1.182584381618126','271.1727543265595','271.172754326559527','test','test','1.99'),('2019-12-14 23:59:59','2020-01-01 15:59:59','WAVESETH','4h','0.004788000000000','0.007925000000000','1.201355562278731','1.988459237898693','250.909683015608','250.909683015608010','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:59:32
