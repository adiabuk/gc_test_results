-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003180000000','0.033333333333333','0.032716049382716','10288.0658436214','10288.065843621399836','test','test','1.85'),('2019-01-09 11:59:59','2019-01-09 19:59:59','TNTBTC','4h','0.000003410000000','0.000003341800000','0.033196159122085','0.032532235939643','9734.94402407188','9734.944024071879539','test','test','2.00'),('2019-01-12 15:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003280000000','0.000003214400000','0.033048620637098','0.032387648224356','10075.798974725','10075.798974724999425','test','test','1.99'),('2019-01-14 19:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003300000000','0.000004210000000','0.032901737878711','0.041974641354356','9970.22359960936','9970.223599609360463','test','test','0.0'),('2019-01-21 15:59:59','2019-01-22 15:59:59','TNTBTC','4h','0.000004500000000','0.000004410000000','0.034917938651076','0.034219579878054','7759.5419224614325','7759.541922461432478','test','test','1.99'),('2019-01-24 15:59:59','2019-01-25 07:59:59','TNTBTC','4h','0.000004500000000','0.000004410000000','0.034762747812627','0.034067492856374','7725.055069472691','7725.055069472690775','test','test','1.99'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004449200000','0.034608246711238','0.033916081777013','7622.961830669066','7622.961830669066330','test','test','2.00'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004150000000','0.034454432281410','0.033802811812731','8145.255858489309','8145.255858489308594','test','test','1.89'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004000000000','0.034309627732814','0.033802588899324','8450.647224831144','8450.647224831143831','test','test','1.47'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.034196952436483','0.034114351102095','8260.133438764089','8260.133438764089078','test','test','0.24'),('2019-02-10 11:59:59','2019-02-11 15:59:59','TNTBTC','4h','0.000004150000000','0.000004067000000','0.034178596584397','0.033495024652709','8235.806405878822','8235.806405878822261','test','test','1.99'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003939600000','0.034026691710689','0.033346157876475','8464.351171813101','8464.351171813101246','test','test','2.00'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003900000000','0.033875461969752','0.033446658653679','8576.06632145626','8576.066321456259175','test','test','1.26'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003900000000','0.033780172343958','0.033268351550868','8530.346551504603','8530.346551504602758','test','test','1.51'),('2019-02-20 23:59:59','2019-02-21 07:59:59','TNTBTC','4h','0.000004070000000','0.000003988600000','0.033666434389938','0.032993105702139','8271.851201459023','8271.851201459023287','test','test','1.99'),('2019-02-21 23:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004020000000','0.000004040000000','0.033516805792650','0.033683556070225','8337.513878768548','8337.513878768548238','test','test','0.24'),('2019-02-26 11:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004160000000','0.000004076800000','0.033553861409888','0.032882784181690','8065.832069684721','8065.832069684721318','test','test','2.00'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.033404733136956','0.032752933465991','8147.495887062331','8147.495887062331349','test','test','1.95'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.033259888765630','0.033096046949051','8192.090828972905','8192.090828972905001','test','test','0.49'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.033223479473057','0.034457024502997','8223.633532934873','8223.633532934873074','test','test','0.0'),('2019-03-04 23:59:59','2019-03-05 03:59:59','TNTBTC','4h','0.000004290000000','0.000004204200000','0.033497600590821','0.032827648579005','7808.298506018959','7808.298506018959415','test','test','2.00'),('2019-03-05 19:59:59','2019-03-06 03:59:59','TNTBTC','4h','0.000004210000000','0.000004125800000','0.033348722365973','0.032681747918654','7921.311725884403','7921.311725884403131','test','test','1.99'),('2019-03-08 11:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004250000000','0.000004270000000','0.033200505822125','0.033356743496582','7811.883722852864','7811.883722852863684','test','test','0.47'),('2019-03-11 23:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004710000000','0.000004615800000','0.033235225305337','0.032570520799230','7056.311105167162','7056.311105167162168','test','test','1.99'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.033087513192869','0.032800419802909','7177.334748995469','7177.334748995469454','test','test','0.86'),('2019-03-26 03:59:59','2019-03-26 07:59:59','TNTBTC','4h','0.000004740000000','0.000004670000000','0.033023714661767','0.032536022673091','6967.028409655461','6967.028409655460564','test','test','1.47'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.032915338664283','0.033325073170477','6828.908436573306','6828.908436573306062','test','test','0.20'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.033006390776771','0.032682003643830','8109.67832353093','8109.678323530930356','test','test','0.98'),('2019-05-21 19:59:59','2019-05-26 23:59:59','TNTBTC','4h','0.000003550000000','0.000003520000000','0.032934304747228','0.032655986678942','9277.268942881254','9277.268942881253679','test','test','0.84'),('2019-05-28 03:59:59','2019-05-28 07:59:59','TNTBTC','4h','0.000003570000000','0.000003640000000','0.032872456287609','0.033517014254033','9207.970948910179','9207.970948910178777','test','test','0.0'),('2019-05-28 11:59:59','2019-05-28 23:59:59','TNTBTC','4h','0.000003950000000','0.000003871000000','0.033015691391259','0.032355377563434','8358.402883863066','8358.402883863065654','test','test','2.00'),('2019-05-31 11:59:59','2019-05-31 23:59:59','TNTBTC','4h','0.000003770000000','0.000003694600000','0.032868954985076','0.032211575885374','8718.555698959093','8718.555698959093206','test','test','2.00'),('2019-06-01 15:59:59','2019-06-01 23:59:59','TNTBTC','4h','0.000003640000000','0.000003670000000','0.032722870740698','0.032992564730319','8989.799654037792','8989.799654037791697','test','test','0.0'),('2019-06-02 15:59:59','2019-06-02 19:59:59','TNTBTC','4h','0.000004180000000','0.000004096400000','0.032782802738391','0.032127146683623','7842.775774734716','7842.775774734715924','test','test','2.00'),('2019-06-03 11:59:59','2019-06-03 15:59:59','TNTBTC','4h','0.000003690000000','0.000003630000000','0.032637101392887','0.032106416817393','8844.742924901657','8844.742924901656806','test','test','1.62'),('2019-06-05 11:59:59','2019-06-05 15:59:59','TNTBTC','4h','0.000003810000000','0.000003733800000','0.032519171487222','0.031868788057478','8535.215613444037','8535.215613444037444','test','test','2.00'),('2019-06-05 19:59:59','2019-06-06 15:59:59','TNTBTC','4h','0.000003820000000','0.000003743600000','0.032374641836168','0.031727148999445','8475.037129886796','8475.037129886795810','test','test','2.00'),('2019-06-07 11:59:59','2019-06-13 23:59:59','TNTBTC','4h','0.000003850000000','0.000004100000000','0.032230754539118','0.034323660678022','8371.624555615066','8371.624555615066129','test','test','0.0'),('2019-06-20 15:59:59','2019-06-20 19:59:59','TNTBTC','4h','0.000003990000000','0.000004100000000','0.032695844792208','0.033597233997006','8194.447316342803','8194.447316342802878','test','test','0.0'),('2019-06-20 23:59:59','2019-06-22 03:59:59','TNTBTC','4h','0.000004870000000','0.000004772600000','0.032896153504385','0.032238230434297','6754.856982419941','6754.856982419941232','test','test','2.00'),('2019-06-25 11:59:59','2019-06-25 15:59:59','TNTBTC','4h','0.000004280000000','0.000004210000000','0.032749948377699','0.032214318380867','7651.8570975932','7651.857097593199796','test','test','1.63'),('2019-06-25 19:59:59','2019-06-25 23:59:59','TNTBTC','4h','0.000004500000000','0.000004410000000','0.032630919489514','0.031978301099724','7251.315442114222','7251.315442114221696','test','test','1.99'),('2019-06-26 03:59:59','2019-06-26 07:59:59','TNTBTC','4h','0.000004930000000','0.000004831400000','0.032485893180672','0.031836175317059','6589.4306654506645','6589.430665450664492','test','test','2.00'),('2019-06-26 11:59:59','2019-06-26 15:59:59','TNTBTC','4h','0.000004800000000','0.000004704000000','0.032341511433202','0.031694681204538','6737.814881917129','6737.814881917129242','test','test','2.00'),('2019-06-26 23:59:59','2019-07-04 07:59:59','TNTBTC','4h','0.000004500000000','0.000005480000000','0.032197771382388','0.039209730483441','7155.060307197334','7155.060307197333714','test','test','0.44'),('2019-07-22 03:59:59','2019-07-23 07:59:59','TNTBTC','4h','0.000004470000000','0.000004380600000','0.033755984515955','0.033080864825636','7551.674388356898','7551.674388356897907','test','test','2.00'),('2019-07-23 15:59:59','2019-07-23 19:59:59','TNTBTC','4h','0.000004420000000','0.000004370000000','0.033605957918107','0.033225800023106','7603.1579000241345','7603.157900024134506','test','test','1.13'),('2019-07-29 07:59:59','2019-07-29 11:59:59','TNTBTC','4h','0.000004350000000','0.000004330000000','0.033521478385884','0.033367356646179','7706.086985260742','7706.086985260742040','test','test','0.45'),('2019-07-29 19:59:59','2019-07-30 03:59:59','TNTBTC','4h','0.000004320000000','0.000004290000000','0.033487229110394','0.033254678908238','7751.6734051838475','7751.673405183847535','test','test','0.69'),('2019-08-19 03:59:59','2019-08-19 07:59:59','TNTBTC','4h','0.000003080000000','0.000003018400000','0.033435551287693','0.032766840261939','10855.698470030162','10855.698470030161843','test','test','1.99'),('2019-08-19 15:59:59','2019-08-19 19:59:59','TNTBTC','4h','0.000003160000000','0.000003096800000','0.033286948837525','0.032621209860774','10533.844568837136','10533.844568837135739','test','test','2.00'),('2019-08-21 11:59:59','2019-08-23 15:59:59','TNTBTC','4h','0.000003130000000','0.000003110000000','0.033139006842692','0.032927256000247','10587.542122265744','10587.542122265744183','test','test','0.63'),('2019-08-24 07:59:59','2019-08-25 15:59:59','TNTBTC','4h','0.000003300000000','0.000003400000000','0.033091951099926','0.034094737496893','10027.863969674614','10027.863969674614054','test','test','0.0'),('2019-08-26 15:59:59','2019-08-26 19:59:59','TNTBTC','4h','0.000003290000000','0.000003240000000','0.033314792521474','0.032808488683762','10126.076754247553','10126.076754247553254','test','test','1.51'),('2019-08-31 07:59:59','2019-09-01 03:59:59','TNTBTC','4h','0.000003260000000','0.000003240000000','0.033202280557538','0.032998585584792','10184.748637281733','10184.748637281732954','test','test','1.84'),('2019-09-10 15:59:59','2019-09-10 19:59:59','TNTBTC','4h','0.000002920000000','0.000002861600000','0.033157015008039','0.032493874707878','11355.14212604087','11355.142126040869698','test','test','2.00'),('2019-09-16 07:59:59','2019-09-16 11:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.033009650496892','0.032773022177918','11831.415948706972','11831.415948706971903','test','test','0.71'),('2019-09-17 11:59:59','2019-09-17 15:59:59','TNTBTC','4h','0.000002790000000','0.000002770000000','0.032957066426009','0.032720815053780','11812.568611472881','11812.568611472881457','test','test','0.71'),('2019-09-17 19:59:59','2019-09-18 03:59:59','TNTBTC','4h','0.000002810000000','0.000002830000000','0.032904566121070','0.033138762321220','11709.810007498063','11709.810007498062987','test','test','0.0'),('2019-09-18 07:59:59','2019-10-10 11:59:59','TNTBTC','4h','0.000002940000000','0.000006620000000','0.032956609721103','0.074208420528470','11209.731197654046','11209.731197654045900','test','test','0.0'),('2019-10-11 15:59:59','2019-10-13 03:59:59','TNTBTC','4h','0.000007120000000','0.000006977600000','0.042123678789407','0.041281205213619','5916.247020984084','5916.247020984083974','test','test','2.00'),('2019-10-14 23:59:59','2019-10-23 15:59:59','TNTBTC','4h','0.000007370000000','0.000009090000000','0.041936462439232','0.051723533727628','5690.1577258116085','5690.157725811608543','test','test','0.0'),('2019-10-24 03:59:59','2019-10-25 15:59:59','TNTBTC','4h','0.000009960000000','0.000009760800000','0.044111367169986','0.043229139826586','4428.852125500626','4428.852125500626244','test','test','1.99'),('2019-11-07 11:59:59','2019-11-07 15:59:59','TNTBTC','4h','0.000007720000000','0.000007700000000','0.043915316649231','0.043801546398844','5688.5125193303975','5688.512519330397481','test','test','0.25'),('2019-11-08 07:59:59','2019-11-08 15:59:59','TNTBTC','4h','0.000007650000000','0.000007497000000','0.043890034371367','0.043012233683940','5737.259394949921','5737.259394949921443','test','test','2.00'),('2019-11-11 07:59:59','2019-11-11 11:59:59','TNTBTC','4h','0.000007570000000','0.000007530000000','0.043694967551939','0.043464082650740','5772.122529978688','5772.122529978688362','test','test','0.52'),('2019-11-11 15:59:59','2019-11-12 15:59:59','TNTBTC','4h','0.000007750000000','0.000007595000000','0.043643659796117','0.042770786600195','5631.439973692473','5631.439973692473359','test','test','2.00'),('2019-11-13 11:59:59','2019-11-18 19:59:59','TNTBTC','4h','0.000007860000000','0.000008490000000','0.043449687974801','0.046932296552934','5527.950124020442','5527.950124020441763','test','test','0.0'),('2019-11-23 11:59:59','2019-11-24 11:59:59','TNTBTC','4h','0.000008470000000','0.000008360000000','0.044223600992164','0.043649268511746','5221.204367433714','5221.204367433713742','test','test','1.29'),('2019-11-25 07:59:59','2019-12-04 07:59:59','TNTBTC','4h','0.000008420000000','0.000009260000000','0.044095971552071','0.048495094604772','5237.051253215043','5237.051253215043289','test','test','0.0'),('2019-12-04 15:59:59','2019-12-05 11:59:59','TNTBTC','4h','0.000009240000000','0.000009100000000','0.045073554452671','0.044390621809449','4878.090308730616','4878.090308730616016','test','test','1.51'),('2020-01-01 03:59:59','2020-01-01 15:59:59','TNTBTC','4h','0.000006190000000','0.000006640000000','0.044921791643066','0.048187511552497','7257.155354291762','7257.155354291761796','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:05:07
