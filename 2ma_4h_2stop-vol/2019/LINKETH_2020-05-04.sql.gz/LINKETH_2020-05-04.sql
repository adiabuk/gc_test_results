-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.297777777777778','2.287238963017428','561.3104291766085','561.310429176608523','test','test','0.0'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','1.517658041164367','1.550536022699582','377.3006832133887','377.300683213388709','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 03:59:59','LINKETH','4h','0.004291500000000','0.004205670000000','1.524964259283303','1.494464974097637','355.34527770786514','355.345277707865137','test','test','2.00'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','1.518186640353155','1.534319188708461','389.8634208628726','389.863420862872601','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003890541200000','1.521771651098779','1.491336218076803','383.32358955016423','383.323589550164229','test','test','1.99'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003885270000000','1.515008221538340','1.491661596545500','383.927396691993','383.927396691993010','test','test','1.54'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.003967226200000','1.509820082651042','1.479623680998021','372.9617638132207','372.961763813220728','test','test','2.00'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003900057000000','1.503109771172593','1.473047575749141','377.6989863863889','377.698986386388924','test','test','2.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003281324200000','1.496429283300715','1.466500697634700','446.9234395171012','446.923439517101201','test','test','2.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKETH','4h','0.003429610000000','0.003361017800000','1.489778486486045','1.459982916756324','434.3871421199625','434.387142119962505','test','test','2.00'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','1.483157248768329','1.500245638424993','463.6025408753216','463.602540875321608','test','test','0.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003230000000000','0.003198670000000','1.486954668692032','1.472531668763202','460.3574825671926','460.357482567192619','test','test','0.96'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','1.483749557596736','1.497019124798173','460.74886116099003','460.748861160990032','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003208290000000','1.486698350308167','1.461292022018581','455.4737950804262','455.473795080426214','test','test','1.70'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003209372600000','1.481052499577148','1.451431449585605','452.24772268125076','452.247722681250764','test','test','2.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','LINKETH','4h','0.003401970000000','0.003333930600000','1.474470044023471','1.444980643143002','433.41653336845167','433.416533368451667','test','test','1.99'),('2019-03-08 03:59:59','2019-03-08 11:59:59','LINKETH','4h','0.003609580000000','0.003537388400000','1.467916843827812','1.438558506951256','406.67247819076226','406.672478190762263','test','test','1.99'),('2019-03-08 15:59:59','2019-03-08 23:59:59','LINKETH','4h','0.003562430000000','0.003491181400000','1.461392768966355','1.432164913587028','410.223574629215','410.223574629215022','test','test','2.00'),('2019-03-10 15:59:59','2019-03-10 19:59:59','LINKETH','4h','0.003902250000000','0.003824205000000','1.454897689993171','1.425799736193307','372.8355922847513','372.835592284751328','test','test','2.00'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKETH','4h','0.003700000000000','0.003626000000000','1.448431478037646','1.419462848476893','391.46796703720156','391.467967037201561','test','test','2.00'),('2019-03-12 01:59:59','2019-03-16 03:59:59','LINKETH','4h','0.003540000000000','0.003471800000000','1.441994004801923','1.414213216347829','407.34293920958265','407.342939209582653','test','test','1.92'),('2019-03-25 19:59:59','2019-03-26 15:59:59','LINKETH','4h','0.003439950000000','0.003412920000000','1.435820496256569','1.424538289243730','417.3957459429842','417.395745942984206','test','test','0.78'),('2019-03-27 19:59:59','2019-03-30 03:59:59','LINKETH','4h','0.003515940000000','0.003450000000000','1.433313339142604','1.406432140492154','407.6614899977258','407.661489997725823','test','test','1.87'),('2019-03-31 03:59:59','2019-04-02 23:59:59','LINKETH','4h','0.003501720000000','0.003570170000000','1.427339739442504','1.455240715295753','407.6110424141578','407.611042414157794','test','test','0.0'),('2019-04-13 19:59:59','2019-04-14 07:59:59','LINKETH','4h','0.003268570000000','0.003203198600000','1.433539956298782','1.404869157172806','438.5832202763844','438.583220276384395','test','test','1.99'),('2019-04-30 15:59:59','2019-04-30 19:59:59','LINKETH','4h','0.002925320000000','0.002952000000000','1.427168667604120','1.440184973530199','487.8675384587397','487.867538458739716','test','test','0.0'),('2019-05-01 07:59:59','2019-05-01 15:59:59','LINKETH','4h','0.002981150000000','0.002953940000000','1.430061180032138','1.417008510857935','479.70118244037974','479.701182440379739','test','test','0.91'),('2019-05-03 07:59:59','2019-05-03 11:59:59','LINKETH','4h','0.002958000000000','0.002909380000000','1.427160586882315','1.403702659994479','482.4748434355359','482.474843435535888','test','test','1.64'),('2019-05-03 19:59:59','2019-05-12 07:59:59','LINKETH','4h','0.002985500000000','0.003419910000000','1.421947714240574','1.628850513283699','476.2846137131381','476.284613713138128','test','test','0.0'),('2019-05-14 15:59:59','2019-05-14 19:59:59','LINKETH','4h','0.004178870000000','0.004095292600000','1.467926114027935','1.438567591747376','351.27345766389834','351.273457663898341','test','test','1.99'),('2019-05-17 03:59:59','2019-05-25 15:59:59','LINKETH','4h','0.003537770000000','0.004581860000000','1.461401997965589','1.892700587771001','413.0856437715252','413.085643771525213','test','test','0.0'),('2019-05-27 07:59:59','2019-05-27 11:59:59','LINKETH','4h','0.004651490000000','0.004558460200000','1.557246129033458','1.526101206452789','334.7843656620691','334.784365662069092','test','test','1.99'),('2019-05-27 23:59:59','2019-05-28 03:59:59','LINKETH','4h','0.004490750000000','0.004400935000000','1.550325035126643','1.519318534424110','345.22630632447647','345.226306324476468','test','test','2.00'),('2019-05-28 19:59:59','2019-05-28 23:59:59','LINKETH','4h','0.004887510000000','0.004789759800000','1.543434701637191','1.512566007604447','315.7916201986678','315.791620198667772','test','test','1.99'),('2019-06-05 07:59:59','2019-06-12 07:59:59','LINKETH','4h','0.004069090000000','0.004446760000000','1.536574991852137','1.679191222304842','377.62128432945366','377.621284329453658','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 19:59:59','LINKETH','4h','0.004525500000000','0.004441760000000','1.568267487508293','1.539248214631496','346.54015854784956','346.540158547849558','test','test','1.85'),('2019-06-13 19:59:59','2019-06-14 03:59:59','LINKETH','4h','0.006918550000000','0.006780179000000','1.561818760202338','1.530582384998291','225.74365440769213','225.743654407692134','test','test','1.99'),('2019-06-14 15:59:59','2019-06-16 15:59:59','LINKETH','4h','0.006179120000000','0.006055537600000','1.554877343490328','1.523779796620522','251.6341070395668','251.634107039566800','test','test','1.99'),('2019-06-17 11:59:59','2019-06-18 11:59:59','LINKETH','4h','0.006962830000000','0.006823573400000','1.547966777519260','1.517007441968875','222.3186229621088','222.318622962108805','test','test','2.00'),('2019-06-25 03:59:59','2019-06-26 03:59:59','LINKETH','4h','0.006425000000000','0.006296500000000','1.541086925174730','1.510265186671235','239.8578871867284','239.857887186728391','test','test','2.00'),('2019-06-26 07:59:59','2019-06-26 15:59:59','LINKETH','4h','0.006490600000000','0.006360788000000','1.534237649951731','1.503552896952696','236.3784010648832','236.378401064883207','test','test','1.99'),('2019-06-26 19:59:59','2019-07-07 19:59:59','LINKETH','4h','0.006632350000000','0.010966680000000','1.527418815951945','2.525607572055738','230.2982828035229','230.298282803522909','test','test','0.0'),('2019-07-08 07:59:59','2019-07-08 11:59:59','LINKETH','4h','0.011201500000000','0.011000030000000','1.749238539530566','1.717776763111406','156.16109802531503','156.161098025315027','test','test','1.79'),('2019-07-10 19:59:59','2019-07-10 23:59:59','LINKETH','4h','0.011111730000000','0.010889495400000','1.742247033659641','1.707402092986448','156.79349963143824','156.793499631438237','test','test','2.00'),('2019-07-11 07:59:59','2019-07-11 11:59:59','LINKETH','4h','0.010840590000000','0.010623778200000','1.734503713510043','1.699813639239842','160.00085913313234','160.000859133132337','test','test','2.00'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKETH','4h','0.012013940000000','0.011773661200000','1.726794808116665','1.692258911954332','143.73259797507438','143.732597975074384','test','test','2.00'),('2019-07-14 11:59:59','2019-07-15 19:59:59','LINKETH','4h','0.012193870000000','0.011949992600000','1.719120164525036','1.684737761234535','140.9823267367157','140.982326736715692','test','test','2.00'),('2019-07-17 15:59:59','2019-07-17 19:59:59','LINKETH','4h','0.011569380000000','0.011424460000000','1.711479630460480','1.690041348716226','147.93183649084736','147.931836490847360','test','test','1.25'),('2019-07-18 11:59:59','2019-07-18 15:59:59','LINKETH','4h','0.012472020000000','0.012222579600000','1.706715567850646','1.672581256493633','136.84355604390032','136.843556043900321','test','test','2.00'),('2019-07-24 07:59:59','2019-07-24 11:59:59','LINKETH','4h','0.011574670000000','0.011343176600000','1.699130165326865','1.665147562020328','146.79728798547734','146.797287985477340','test','test','1.99'),('2019-07-24 19:59:59','2019-07-24 23:59:59','LINKETH','4h','0.011424470000000','0.011195980600000','1.691578475703190','1.657746906189126','148.0662539008978','148.066253900897806','test','test','2.00'),('2019-08-02 19:59:59','2019-08-05 19:59:59','LINKETH','4h','0.010892850000000','0.010835450000000','1.684060349144509','1.675186173511787','154.60236293940605','154.602362939406049','test','test','0.52'),('2019-08-06 23:59:59','2019-08-07 03:59:59','LINKETH','4h','0.010970120000000','0.010750717600000','1.682088310115015','1.648446543912715','153.33362899539983','153.333628995399835','test','test','2.00'),('2019-08-10 07:59:59','2019-08-10 11:59:59','LINKETH','4h','0.011107090000000','0.011089990000000','1.674612362070060','1.672034200608201','150.7696761320976','150.769676132097601','test','test','0.15'),('2019-08-10 15:59:59','2019-08-20 15:59:59','LINKETH','4h','0.011200650000000','0.012089680000000','1.674039437300758','1.806913090253354','149.459132934317','149.459132934317012','test','test','1.66'),('2019-09-23 11:59:59','2019-09-23 15:59:59','LINKETH','4h','0.008806250000000','0.008836640000000','1.703566915734668','1.709445853826271','193.4497562225315','193.449756222531505','test','test','0.0'),('2019-09-23 23:59:59','2019-10-15 19:59:59','LINKETH','4h','0.008960940000000','0.013548630000000','1.704873346421691','2.577709276876011','190.2560832258324','190.256083225832413','test','test','0.0'),('2019-10-16 23:59:59','2019-10-17 03:59:59','LINKETH','4h','0.013595980000000','0.013620690000000','1.898836886522651','1.902287925687608','139.66164164132712','139.661641641327122','test','test','0.0'),('2019-10-17 11:59:59','2019-10-18 23:59:59','LINKETH','4h','0.013575230000000','0.013638600000000','1.899603784114864','1.908471250212997','139.93160956498443','139.931609564984427','test','test','0.21'),('2019-10-20 19:59:59','2019-10-26 03:59:59','LINKETH','4h','0.013871250000000','0.015358970000000','1.901574332136671','2.105522077682773','137.08745297912378','137.087452979123782','test','test','0.0'),('2019-10-26 11:59:59','2019-10-26 19:59:59','LINKETH','4h','0.015554070000000','0.015408160000000','1.946896053369138','1.928632563289237','125.16955712357847','125.169557123578471','test','test','1.89'),('2019-10-31 19:59:59','2019-11-01 11:59:59','LINKETH','4h','0.014931840000000','0.014721240000000','1.942837500018049','1.915435547043479','130.11373682131932','130.113736821319321','test','test','1.41'),('2019-11-08 23:59:59','2019-11-10 19:59:59','LINKETH','4h','0.014775770000000','0.014727770000000','1.936748177134811','1.930456531250876','131.07595591531344','131.075955915313443','test','test','0.74'),('2019-11-12 15:59:59','2019-11-17 19:59:59','LINKETH','4h','0.015029520000000','0.015580500000000','1.935350033605048','2.006299682131129','128.76991637823753','128.769916378237525','test','test','0.20'),('2019-11-17 23:59:59','2019-11-18 15:59:59','LINKETH','4h','0.015844380000000','0.015739180000000','1.951116622166399','1.938162030781194','123.14250366163897','123.142503661638969','test','test','0.72'),('2019-11-18 23:59:59','2019-11-19 03:59:59','LINKETH','4h','0.015673730000000','0.015412040000000','1.948237824080798','1.915709870863300','124.29956520118682','124.299565201186823','test','test','1.66'),('2019-11-20 11:59:59','2019-11-20 15:59:59','LINKETH','4h','0.015812590000000','0.015496338200000','1.941009390032465','1.902189202231816','122.75088331718365','122.750883317183650','test','test','2.00'),('2019-11-21 15:59:59','2019-11-22 07:59:59','LINKETH','4h','0.016019970000000','0.015699570600000','1.932382681632321','1.893735027999675','120.62336456512222','120.623364565122216','test','test','2.00'),('2019-11-22 15:59:59','2019-11-22 23:59:59','LINKETH','4h','0.015711740000000','0.015699910000000','1.923794314158400','1.922345812163300','122.44311032122476','122.443110321224765','test','test','0.07'),('2019-12-10 03:59:59','2019-12-12 07:59:59','LINKETH','4h','0.014754620000000','0.014520610000000','1.923472424826155','1.892965927055723','130.36407747716683','130.364077477166830','test','test','1.58'),('2019-12-15 15:59:59','2019-12-15 23:59:59','LINKETH','4h','0.014574440000000','0.014580070000000','1.916693203099393','1.917433607721008','131.51058998489088','131.510589984890885','test','test','0.0'),('2019-12-16 11:59:59','2019-12-16 15:59:59','LINKETH','4h','0.014614260000000','0.014467430000000','1.916857737459752','1.897598998283686','131.16351682943588','131.163516829435878','test','test','1.00'),('2019-12-16 19:59:59','2019-12-17 07:59:59','LINKETH','4h','0.015055820000000','0.014754703600000','1.912578017642848','1.874326457289991','127.03247100741427','127.032471007414273','test','test','2.00'),('2019-12-18 03:59:59','2019-12-18 07:59:59','LINKETH','4h','0.014609280000000','0.014476310000000','1.904077670897769','1.886747233812623','130.33343675374616','130.333436753746156','test','test','0.91'),('2019-12-23 19:59:59','2019-12-23 23:59:59','LINKETH','4h','0.014749900000000','0.014568950000000','1.900226462656625','1.876914712853730','128.829786144762','128.829786144762011','test','test','1.22'),('2019-12-24 03:59:59','2019-12-24 07:59:59','LINKETH','4h','0.014613800000000','0.014554850000000','1.895046073811537','1.887401726273512','129.6751066670912','129.675106667091200','test','test','0.40'),('2019-12-25 11:59:59','2019-12-25 15:59:59','LINKETH','4h','0.014645470000000','0.014416920000000','1.893347329914199','1.863800682913325','129.27870050699624','129.278700506996245','test','test','1.56'),('2019-12-26 19:59:59','2019-12-28 19:59:59','LINKETH','4h','0.014805500000000','0.014665560000000','1.886781408358449','1.868947752603110','127.43787162598012','127.437871625980122','test','test','1.02');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:54:27
