-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.018938500000000','1.297777777777778','1.271822222222222','67.15538306741412','67.155383067414121','test','test','2.00'),('2019-01-11 11:59:59','2019-01-13 19:59:59','EOSETH','4h','0.019239000000000','0.019395000000000','1.292009876543210','1.302486176805216','67.1557709102973','67.155770910297306','test','test','1.45'),('2019-01-15 11:59:59','2019-01-15 15:59:59','EOSETH','4h','0.019130000000000','0.018778000000000','1.294337943268100','1.270521583831070','67.66011203701515','67.660112037015153','test','test','1.84'),('2019-01-15 23:59:59','2019-01-20 11:59:59','EOSETH','4h','0.019693000000000','0.019506000000000','1.289045418948760','1.276804953131291','65.45703645705377','65.457036457053775','test','test','0.94'),('2019-01-20 19:59:59','2019-02-10 23:59:59','EOSETH','4h','0.019799000000000','0.022686000000000','1.286325315433767','1.473891414007295','64.96920629495263','64.969206294952627','test','test','0.0'),('2019-02-12 03:59:59','2019-02-14 07:59:59','EOSETH','4h','0.023099000000000','0.022735000000000','1.328006670672329','1.307079599018806','57.49195509209614','57.491955092096141','test','test','1.57'),('2019-02-16 19:59:59','2019-02-16 23:59:59','EOSETH','4h','0.023017000000000','0.022733000000000','1.323356210304879','1.307027706862789','57.49473042989439','57.494730429894389','test','test','1.23'),('2019-02-18 19:59:59','2019-02-25 11:59:59','EOSETH','4h','0.023667000000000','0.024841000000000','1.319727653984415','1.385192658665097','55.76235492392','55.762354923920000','test','test','0.0'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSETH','4h','0.025964000000000','0.025633000000000','1.334275432802344','1.317265528001174','51.3894404869182','51.389440486918197','test','test','1.27'),('2019-03-03 19:59:59','2019-03-04 07:59:59','EOSETH','4h','0.026890000000000','0.026352200000000','1.330495453957640','1.303885544878487','49.47919129630493','49.479191296304933','test','test','2.00'),('2019-03-05 15:59:59','2019-03-11 07:59:59','EOSETH','4h','0.027063000000000','0.026933000000000','1.324582140828939','1.318219369580084','48.94439422196131','48.944394221961311','test','test','0.75'),('2019-03-12 11:59:59','2019-03-13 11:59:59','EOSETH','4h','0.027344000000000','0.026797120000000','1.323168191662527','1.296704827829277','48.389708589179584','48.389708589179584','test','test','1.99'),('2019-03-13 15:59:59','2019-03-13 19:59:59','EOSETH','4h','0.027086000000000','0.027101000000000','1.317287444144027','1.318016946900512','48.633517099018924','48.633517099018924','test','test','0.0'),('2019-03-14 15:59:59','2019-03-15 03:59:59','EOSETH','4h','0.027081000000000','0.026976000000000','1.317449555867690','1.312341465200207','48.648482547457256','48.648482547457256','test','test','0.38'),('2019-03-15 11:59:59','2019-03-15 19:59:59','EOSETH','4h','0.027350000000000','0.026993000000000','1.316314424608249','1.299132550766013','48.128498157522834','48.128498157522834','test','test','1.50'),('2019-03-16 03:59:59','2019-03-16 07:59:59','EOSETH','4h','0.027202000000000','0.026828000000000','1.312496230421086','1.294450734127524','48.2499900897392','48.249990089739200','test','test','1.37'),('2019-03-17 03:59:59','2019-03-17 15:59:59','EOSETH','4h','0.027119000000000','0.026911000000000','1.308486120133628','1.298450163314136','48.249792401402246','48.249792401402246','test','test','0.76'),('2019-03-25 19:59:59','2019-03-30 19:59:59','EOSETH','4h','0.027283000000000','0.029271000000000','1.306255907507074','1.401437403094952','47.8780158892744','47.878015889274401','test','test','0.94'),('2019-03-31 11:59:59','2019-04-08 03:59:59','EOSETH','4h','0.029740000000000','0.030330000000000','1.327407350971046','1.353741256050835','44.63373742337076','44.633737423370761','test','test','1.06'),('2019-04-09 19:59:59','2019-04-18 03:59:59','EOSETH','4h','0.031698000000000','0.032035000000000','1.333259329877666','1.347433990555588','42.061307649620375','42.061307649620375','test','test','0.20'),('2019-05-03 23:59:59','2019-05-04 07:59:59','EOSETH','4h','0.030281000000000','0.029837000000000','1.336409254472760','1.316813940282809','44.13359051790761','44.133590517907606','test','test','1.46'),('2019-05-04 23:59:59','2019-05-05 07:59:59','EOSETH','4h','0.030252000000000','0.030131000000000','1.332054740208327','1.326726873503144','44.031956241184936','44.031956241184936','test','test','0.45'),('2019-05-26 23:59:59','2019-06-02 19:59:59','EOSETH','4h','0.025934000000000','0.028200000000000','1.330870769829397','1.447156462913125','51.317605067841335','51.317605067841335','test','test','0.0'),('2019-06-16 15:59:59','2019-06-16 19:59:59','EOSETH','4h','0.026052000000000','0.025901000000000','1.356712034959114','1.348848396187472','52.0770779578963','52.077077957896300','test','test','0.57'),('2019-06-17 03:59:59','2019-06-17 11:59:59','EOSETH','4h','0.026185000000000','0.026072000000000','1.354964559676527','1.349117280881666','51.745830043021854','51.745830043021854','test','test','0.43'),('2019-06-17 23:59:59','2019-06-18 07:59:59','EOSETH','4h','0.026076000000000','0.025790000000000','1.353665164388780','1.338818246264252','51.91230113471317','51.912301134713168','test','test','1.09'),('2019-07-15 07:59:59','2019-07-15 11:59:59','EOSETH','4h','0.018830000000000','0.018889000000000','1.350365849249997','1.354596947768624','71.71353421402','71.713534214020001','test','test','0.0'),('2019-07-16 11:59:59','2019-07-16 15:59:59','EOSETH','4h','0.018866000000000','0.018935000000000','1.351306093365247','1.356248323856194','71.62652885430123','71.626528854301228','test','test','0.0'),('2019-07-20 19:59:59','2019-07-22 19:59:59','EOSETH','4h','0.018980000000000','0.019049000000000','1.352404366807680','1.357320905338224','71.2541816020906','71.254181602090597','test','test','1.15'),('2019-07-23 11:59:59','2019-07-28 23:59:59','EOSETH','4h','0.019500000000000','0.020195000000000','1.353496930925578','1.401736949745746','69.41009902182452','69.410099021824522','test','test','0.68'),('2019-07-31 15:59:59','2019-07-31 19:59:59','EOSETH','4h','0.020002000000000','0.020040000000000','1.364216935107838','1.366808688109243','68.20402635275663','68.204026352756628','test','test','0.0'),('2019-08-10 19:59:59','2019-08-11 07:59:59','EOSETH','4h','0.019753000000000','0.019699000000000','1.364792880219261','1.361061861359754','69.09294184272066','69.092941842720663','test','test','1.11'),('2019-08-13 15:59:59','2019-08-14 19:59:59','EOSETH','4h','0.019565000000000','0.019492000000000','1.363963764917149','1.358874608012526','69.71447814552255','69.714478145522548','test','test','0.60'),('2019-08-15 19:59:59','2019-08-15 23:59:59','EOSETH','4h','0.019593000000000','0.019270000000000','1.362832841160565','1.340365888284800','69.55712964633112','69.557129646331120','test','test','1.64'),('2019-08-22 19:59:59','2019-08-22 23:59:59','EOSETH','4h','0.019086000000000','0.019087000000000','1.357840184965951','1.357911328222001','71.14325604977215','71.143256049772148','test','test','0.0'),('2019-08-26 19:59:59','2019-08-26 23:59:59','EOSETH','4h','0.019105000000000','0.019006000000000','1.357855994578407','1.350819734779231','71.07333130481061','71.073331304810608','test','test','0.51'),('2019-08-31 19:59:59','2019-09-01 11:59:59','EOSETH','4h','0.019453000000000','0.019240000000000','1.356292381289701','1.341441701332126','69.7215021482394','69.721502148239395','test','test','1.19'),('2019-09-06 19:59:59','2019-09-06 23:59:59','EOSETH','4h','0.019002000000000','0.019003000000000','1.352992230188018','1.353063432810383','71.20262236543613','71.202622365436127','test','test','0.0'),('2019-09-07 15:59:59','2019-09-16 23:59:59','EOSETH','4h','0.019671000000000','0.020706000000000','1.353008052992988','1.424197282561781','68.78186431767514','68.781864317675144','test','test','0.0'),('2019-10-04 19:59:59','2019-10-04 23:59:59','EOSETH','4h','0.017227000000000','0.017116000000000','1.368827881786053','1.360008012111806','79.45828535357595','79.458285353575945','test','test','0.64'),('2019-10-07 03:59:59','2019-10-07 15:59:59','EOSETH','4h','0.017254000000000','0.017631000000000','1.366867910747331','1.396733982519195','79.2203495274911','79.220349527491095','test','test','0.26'),('2019-10-07 19:59:59','2019-10-09 15:59:59','EOSETH','4h','0.017581000000000','0.017229380000000','1.373504815585523','1.346034719273812','78.12438516498057','78.124385164980566','test','test','2.00'),('2019-10-12 19:59:59','2019-10-13 03:59:59','EOSETH','4h','0.017073000000000','0.017051000000000','1.367400349738476','1.365638339096278','80.09139282718188','80.091392827181878','test','test','0.12'),('2019-10-13 23:59:59','2019-10-14 19:59:59','EOSETH','4h','0.017127000000000','0.017010000000000','1.367008791817988','1.357670318726220','79.81600933134744','79.816009331347445','test','test','0.68'),('2019-10-21 15:59:59','2019-10-21 19:59:59','EOSETH','4h','0.016822000000000','0.016772000000000','1.364933575575373','1.360876585991568','81.1397916761011','81.139791676101098','test','test','0.29'),('2019-10-22 03:59:59','2019-10-22 23:59:59','EOSETH','4h','0.016893000000000','0.016901000000000','1.364032022334527','1.364677985525119','80.74539882404116','80.745398824041160','test','test','0.0'),('2019-10-23 03:59:59','2019-10-23 19:59:59','EOSETH','4h','0.017198000000000','0.016854040000000','1.364175569710214','1.336892058316010','79.32175658275463','79.321756582754631','test','test','2.00'),('2019-10-24 15:59:59','2019-11-03 19:59:59','EOSETH','4h','0.017009000000000','0.017893000000000','1.358112567178169','1.428697052414544','79.84670275608025','79.846702756080248','test','test','0.58'),('2019-11-04 11:59:59','2019-11-11 11:59:59','EOSETH','4h','0.018242000000000','0.018555000000000','1.373798008341808','1.397369918034330','75.30961563106061','75.309615631060609','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSETH','4h','0.018710000000000','0.018657000000000','1.379036210495702','1.375129801134062','73.70583701206316','73.705837012063157','test','test','0.28'),('2019-11-12 15:59:59','2019-11-13 01:59:59','EOSETH','4h','0.018729000000000','0.018515000000000','1.378168119526448','1.362420990604527','73.58471458841626','73.584714588416261','test','test','1.14'),('2019-11-15 07:59:59','2019-11-15 15:59:59','EOSETH','4h','0.018734000000000','0.018473000000000','1.374668757543799','1.355517025627554','73.37828320400337','73.378283204003367','test','test','1.39'),('2019-11-15 19:59:59','2019-11-15 23:59:59','EOSETH','4h','0.018559000000000','0.018519000000000','1.370412817117967','1.367459182079187','73.8408759695009','73.840875969500900','test','test','0.21'),('2019-11-18 11:59:59','2019-11-18 15:59:59','EOSETH','4h','0.018542000000000','0.018540000000000','1.369756453776016','1.369608707421386','73.87317731506934','73.873177315069341','test','test','0.01'),('2019-11-26 15:59:59','2019-11-26 23:59:59','EOSETH','4h','0.017888000000000','0.017688000000000','1.369723621252765','1.354409180049134','76.57220601815544','76.572206018155441','test','test','1.11'),('2019-11-29 15:59:59','2019-12-04 03:59:59','EOSETH','4h','0.017979000000000','0.017966000000000','1.366320412096402','1.365332472535957','75.99535080351535','75.995350803515350','test','test','0.07'),('2019-12-04 11:59:59','2019-12-04 15:59:59','EOSETH','4h','0.018042000000000','0.018078000000000','1.366100869971859','1.368826711415102','75.71781786785607','75.717817867856070','test','test','0.0'),('2019-12-04 23:59:59','2019-12-05 23:59:59','EOSETH','4h','0.018059000000000','0.018127000000000','1.366706612514802','1.371852858134770','75.68008264659184','75.680082646591842','test','test','0.0'),('2019-12-06 11:59:59','2019-12-08 15:59:59','EOSETH','4h','0.018307000000000','0.018206000000000','1.367850222652572','1.360303771978627','74.71733340539534','74.717333405395337','test','test','0.55'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSETH','4h','0.018233000000000','0.018137000000000','1.366173233613918','1.358980087646335','74.9286038289869','74.928603828986894','test','test','0.52'),('2019-12-18 15:59:59','2019-12-29 23:59:59','EOSETH','4h','0.018261000000000','0.019976000000000','1.364574756732233','1.492730153906308','74.72617911024768','74.726179110247685','test','test','0.0'),('2019-12-31 15:59:59','2020-01-01 15:59:59','EOSETH','4h','0.020025000000000','0.019923000000000','1.393053733882027','1.385958029469744','69.56572953218613','69.565729532186126','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:22:28
