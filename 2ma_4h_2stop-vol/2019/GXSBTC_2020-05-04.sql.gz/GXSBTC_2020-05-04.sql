-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-02 23:59:59','GXSBTC','4h','0.000144300000000','0.000142800000000','0.033333333333333','0.032986832986833','231.00023100023097','231.000231000230968','test','test','1.03'),('2019-01-04 15:59:59','2019-01-05 19:59:59','GXSBTC','4h','0.000148500000000','0.000145530000000','0.033256333256333','0.032591206591206','223.94837209652079','223.948372096520785','test','test','2.00'),('2019-01-12 03:59:59','2019-01-13 11:59:59','GXSBTC','4h','0.000146900000000','0.000144400000000','0.033108527330750','0.032545073836353','225.38139775867634','225.381397758676343','test','test','1.70'),('2019-01-14 15:59:59','2019-01-15 03:59:59','GXSBTC','4h','0.000147600000000','0.000144648000000','0.032983315443106','0.032323649134244','223.46419676900928','223.464196769009277','test','test','1.99'),('2019-01-16 03:59:59','2019-01-16 07:59:59','GXSBTC','4h','0.000144200000000','0.000144900000000','0.032836722930025','0.032996124497646','227.716525173546','227.716525173545989','test','test','0.0'),('2019-01-16 11:59:59','2019-01-16 15:59:59','GXSBTC','4h','0.000144800000000','0.000146200000000','0.032872145500608','0.033189970111802','227.01757942408685','227.017579424086847','test','test','0.0'),('2019-01-17 07:59:59','2019-01-25 19:59:59','GXSBTC','4h','0.000147100000000','0.000156200000000','0.032942773191984','0.034980701377212','223.9481522228703','223.948152222870306','test','test','0.0'),('2019-01-30 15:59:59','2019-01-31 07:59:59','GXSBTC','4h','0.000163200000000','0.000159936000000','0.033395646122035','0.032727733199594','204.6301845712922','204.630184571292205','test','test','2.00'),('2019-02-03 23:59:59','2019-02-04 19:59:59','GXSBTC','4h','0.000158400000000','0.000157000000000','0.033247221028159','0.032953369327153','209.89407214746916','209.894072147469160','test','test','0.88'),('2019-02-07 11:59:59','2019-02-09 19:59:59','GXSBTC','4h','0.000159400000000','0.000158400000000','0.033181920650158','0.032973753017472','208.1676326860588','208.167632686058795','test','test','0.62'),('2019-02-10 15:59:59','2019-02-10 23:59:59','GXSBTC','4h','0.000161800000000','0.000164200000000','0.033135661176228','0.033627166657210','204.79395040931738','204.793950409317375','test','test','0.0'),('2019-02-15 15:59:59','2019-02-15 19:59:59','GXSBTC','4h','0.000159100000000','0.000158600000000','0.033244884616446','0.033140406663534','208.95590582304072','208.955905823040723','test','test','0.31'),('2019-02-16 03:59:59','2019-02-16 11:59:59','GXSBTC','4h','0.000159500000000','0.000158400000000','0.033221667293576','0.032992552346724','208.28631532022845','208.286315320228454','test','test','0.68'),('2019-02-16 15:59:59','2019-02-16 19:59:59','GXSBTC','4h','0.000159700000000','0.000159100000000','0.033170752860943','0.033046128867727','207.70665535969104','207.706655359691041','test','test','0.37'),('2019-02-17 03:59:59','2019-02-18 11:59:59','GXSBTC','4h','0.000165700000000','0.000162386000000','0.033143058640228','0.032480197467423','200.01845890300544','200.018458903005438','test','test','2.00'),('2019-02-19 03:59:59','2019-02-19 15:59:59','GXSBTC','4h','0.000161600000000','0.000160300000000','0.032995756157382','0.032730320000175','204.18165938974283','204.181659389742833','test','test','0.80'),('2019-02-20 15:59:59','2019-02-21 11:59:59','GXSBTC','4h','0.000162300000000','0.000159054000000','0.032936770344670','0.032278034937777','202.93758684331348','202.937586843313483','test','test','2.00'),('2019-02-23 07:59:59','2019-02-24 15:59:59','GXSBTC','4h','0.000162100000000','0.000161300000000','0.032790384698694','0.032628556766807','202.2849148593063','202.284914859306298','test','test','0.49'),('2019-02-26 19:59:59','2019-02-27 15:59:59','GXSBTC','4h','0.000168900000000','0.000165522000000','0.032754422936052','0.032099334477331','193.92790370664295','193.927903706642951','test','test','2.00'),('2019-02-27 19:59:59','2019-03-04 07:59:59','GXSBTC','4h','0.000168800000000','0.000169000000000','0.032608847723003','0.032647483798504','193.1803775059413','193.180377505941294','test','test','1.77'),('2019-03-05 15:59:59','2019-03-07 07:59:59','GXSBTC','4h','0.000171900000000','0.000168700000000','0.032617433517559','0.032010244528285','189.74655914810162','189.746559148101625','test','test','1.97'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSBTC','4h','0.000173900000000','0.000248400000000','0.032482502631053','0.046398238375811','186.78839925850104','186.788399258501045','test','test','0.11'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSBTC','4h','0.000268000000000','0.000262640000000','0.035574888352111','0.034863390585069','132.74212071683084','132.742120716830840','test','test','1.99'),('2019-03-28 11:59:59','2019-04-02 07:59:59','GXSBTC','4h','0.000266400000000','0.000262500000000','0.035416777737212','0.034898288873942','132.9458623769236','132.945862376923600','test','test','1.46'),('2019-04-12 19:59:59','2019-04-13 07:59:59','GXSBTC','4h','0.000245400000000','0.000253200000000','0.035301557989819','0.036423612400253','143.85312954286516','143.853129542865162','test','test','1.71'),('2019-04-13 11:59:59','2019-04-18 19:59:59','GXSBTC','4h','0.000256900000000','0.000251900000000','0.035550903414360','0.034858982366980','138.384209475905','138.384209475905010','test','test','1.94'),('2019-04-22 07:59:59','2019-04-22 11:59:59','GXSBTC','4h','0.000250000000000','0.000249900000000','0.035397143181609','0.035382984324336','141.58857272643556','141.588572726435558','test','test','0.04'),('2019-04-22 23:59:59','2019-04-23 03:59:59','GXSBTC','4h','0.000250100000000','0.000248500000000','0.035393996768882','0.035167565761964','141.5193793237967','141.519379323796699','test','test','0.63'),('2019-05-16 07:59:59','2019-05-16 11:59:59','GXSBTC','4h','0.000161500000000','0.000158270000000','0.035343678767344','0.034636805191997','218.84630815693015','218.846308156930149','test','test','2.00'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSBTC','4h','0.000142700000000','0.000139846000000','0.035186595750600','0.034482863835588','246.57740540014328','246.577405400143277','test','test','1.99'),('2019-06-04 15:59:59','2019-06-04 19:59:59','GXSBTC','4h','0.000154000000000','0.000150920000000','0.035030210880598','0.034329606662986','227.46890182206351','227.468901822063515','test','test','2.00'),('2019-06-04 23:59:59','2019-06-18 11:59:59','GXSBTC','4h','0.000153600000000','0.000278400000000','0.034874521054462','0.063210069411212','227.04766311498557','227.047663114985568','test','test','0.06'),('2019-06-18 23:59:59','2019-06-19 07:59:59','GXSBTC','4h','0.000271800000000','0.000266364000000','0.041171309578184','0.040347883386620','151.4764885142899','151.476488514289912','test','test','1.99'),('2019-06-23 11:59:59','2019-06-23 15:59:59','GXSBTC','4h','0.000247500000000','0.000244000000000','0.040988325980059','0.040408693087412','165.60939789922696','165.609397899226963','test','test','1.41'),('2019-07-24 19:59:59','2019-07-27 03:59:59','GXSBTC','4h','0.000151100000000','0.000152000000000','0.040859518670582','0.041102891051810','270.4137569197985','270.413756919798516','test','test','0.52'),('2019-07-29 19:59:59','2019-07-29 23:59:59','GXSBTC','4h','0.000153000000000','0.000152800000000','0.040913601421966','0.040860119590042','267.40915962068993','267.409159620689934','test','test','0.13'),('2019-07-30 03:59:59','2019-07-30 15:59:59','GXSBTC','4h','0.000155700000000','0.000152700000000','0.040901716570427','0.040113629545949','262.69567482612007','262.695674826120069','test','test','1.92'),('2019-07-31 07:59:59','2019-07-31 15:59:59','GXSBTC','4h','0.000171400000000','0.000167972000000','0.040726586120543','0.039912054398132','237.61135426221063','237.611354262210625','test','test','2.00'),('2019-07-31 19:59:59','2019-08-05 03:59:59','GXSBTC','4h','0.000171200000000','0.000167776000000','0.040545579071118','0.039734667489696','236.83165345279338','236.831653452793375','test','test','2.0'),('2019-08-05 07:59:59','2019-08-05 11:59:59','GXSBTC','4h','0.000168500000000','0.000165130000000','0.040365376497469','0.039558068967520','239.55713054877677','239.557130548776769','test','test','1.99'),('2019-09-27 19:59:59','2019-10-05 15:59:59','GXSBTC','4h','0.000052100000000','0.000051990000000','0.040185974824147','0.040101129195919','771.3238929778674','771.323892977867445','test','test','1.88'),('2019-10-06 23:59:59','2019-10-07 03:59:59','GXSBTC','4h','0.000052510000000','0.000051690000000','0.040167120240096','0.039539867553048','764.9423012777801','764.942301277780075','test','test','1.56'),('2019-10-07 15:59:59','2019-10-07 19:59:59','GXSBTC','4h','0.000051440000000','0.000051420000000','0.040027730754086','0.040012167872766','778.1440659814456','778.144065981445578','test','test','0.03'),('2019-10-08 11:59:59','2019-10-09 15:59:59','GXSBTC','4h','0.000052710000000','0.000051720000000','0.040024272336014','0.039272535860722','759.3297730224709','759.329773022470931','test','test','1.87'),('2019-10-10 03:59:59','2019-10-10 07:59:59','GXSBTC','4h','0.000057620000000','0.000056467600000','0.039857219785950','0.039060075390231','691.725438839805','691.725438839804951','test','test','1.99'),('2019-10-10 15:59:59','2019-10-11 03:59:59','GXSBTC','4h','0.000057370000000','0.000056222600000','0.039680076586901','0.038886475055163','691.6520234774428','691.652023477442754','test','test','2.00'),('2019-10-11 19:59:59','2019-10-12 03:59:59','GXSBTC','4h','0.000056830000000','0.000055693400000','0.039503720690959','0.038713646277140','695.1208990138854','695.120899013885378','test','test','1.99'),('2019-10-14 15:59:59','2019-10-20 19:59:59','GXSBTC','4h','0.000055540000000','0.000056580000000','0.039328148598999','0.040064577740932','708.1049441663546','708.104944166354585','test','test','0.39'),('2019-10-27 15:59:59','2019-10-27 19:59:59','GXSBTC','4h','0.000057990000000','0.000063000000000','0.039491799519429','0.042903662178376','681.010510767872','681.010510767872006','test','test','0.0'),('2019-10-27 23:59:59','2019-10-28 15:59:59','GXSBTC','4h','0.000062680000000','0.000061426400000','0.040249991221417','0.039444991396989','642.1504662000177','642.150466200017718','test','test','1.99'),('2019-11-02 03:59:59','2019-11-02 07:59:59','GXSBTC','4h','0.000060620000000','0.000059407600000','0.040071102371544','0.039269680324113','661.0211542649988','661.021154264998813','test','test','2.00'),('2019-11-02 15:59:59','2019-11-02 19:59:59','GXSBTC','4h','0.000059730000000','0.000058535400000','0.039893008583226','0.039095148411561','667.8889767826257','667.888976782625718','test','test','2.00'),('2019-11-06 03:59:59','2019-11-18 11:59:59','GXSBTC','4h','0.000059550000000','0.000066420000000','0.039715706322856','0.044297518286551','666.9304168405747','666.930416840574708','test','test','0.36'),('2019-11-28 19:59:59','2019-11-29 03:59:59','GXSBTC','4h','0.000063250000000','0.000062610000000','0.040733886759233','0.040321717786491','644.0140199088203','644.014019908820273','test','test','1.24'),('2019-12-03 07:59:59','2019-12-03 19:59:59','GXSBTC','4h','0.000061820000000','0.000061890000000','0.040642293654179','0.040688313721403','657.4295317725512','657.429531772551172','test','test','0.06'),('2019-12-16 15:59:59','2019-12-16 19:59:59','GXSBTC','4h','0.000059620000000','0.000058427600000','0.040652520335784','0.039839469929068','681.8604551456633','681.860455145663309','test','test','1.99'),('2019-12-18 15:59:59','2019-12-18 19:59:59','GXSBTC','4h','0.000058550000000','0.000058470000000','0.040471842467625','0.040416543622238','691.2355673377511','691.235567337751149','test','test','0.13');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:22:49
