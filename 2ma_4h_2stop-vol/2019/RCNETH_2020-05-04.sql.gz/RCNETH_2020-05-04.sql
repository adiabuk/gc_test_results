-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.297777777777778','1.288978255786767','15171.589639674745','15171.589639674744831','test','test','0.67'),('2019-01-12 03:59:59','2019-01-12 11:59:59','RCNETH','4h','0.000086100000000','0.000085150000000','1.295822328446442','1.281524637249878','15050.201259540558','15050.201259540557658','test','test','1.46'),('2019-01-12 19:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000085960000000','0.000084920000000','1.292645063736094','1.277005802843987','15037.750857795421','15037.750857795421325','test','test','1.20'),('2019-01-13 11:59:59','2019-01-13 15:59:59','RCNETH','4h','0.000088320000000','0.000086553600000','1.289169672426737','1.263386278978202','14596.57690700563','14596.576907005630346','test','test','1.99'),('2019-01-13 19:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000087740000000','0.000085985200000','1.283440029438174','1.257771228849411','14627.764183247938','14627.764183247938490','test','test','1.99'),('2019-01-14 23:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000086760000000','0.000100820000000','1.277735851529560','1.484800928437186','14727.24586825219','14727.245868252190121','test','test','0.59'),('2019-01-26 11:59:59','2019-01-27 11:59:59','RCNETH','4h','0.000103830000000','0.000101753400000','1.323750313064588','1.297275306803296','12749.20844712114','12749.208447121140125','test','test','1.99'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101210000000','1.317866978339856','1.296978966139409','12814.731411317158','12814.731411317157836','test','test','1.58'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.313225197850868','1.303686031764784','12718.888114778387','12718.888114778386807','test','test','0.72'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.311105383165072','1.304490063940874','12721.767738842149','12721.767738842148901','test','test','0.50'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000098225400000','1.309635312226361','1.283442605981834','13066.300630812742','13066.300630812742384','test','test','2.00'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.303814710838688','1.307487797859865','13118.167932776823','13118.167932776823363','test','test','0.0'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000100557800000','1.304630952398950','1.278538333350971','12714.46206411607','12714.462064116070906','test','test','2.00'),('2019-02-21 23:59:59','2019-02-23 19:59:59','RCNETH','4h','0.000108920000000','0.000106741600000','1.298832592610510','1.272855940758300','11924.647379824737','11924.647379824737072','test','test','2.00'),('2019-02-25 19:59:59','2019-02-27 23:59:59','RCNETH','4h','0.000142190000000','0.000139346200000','1.293060003310019','1.267198803243818','9093.888482382861','9093.888482382861184','test','test','2.00'),('2019-02-28 19:59:59','2019-03-01 11:59:59','RCNETH','4h','0.000164020000000','0.000160739600000','1.287313069961974','1.261566808562735','7848.512803084834','7848.512803084833649','test','test','2.00'),('2019-03-04 03:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149450000000','0.000169370000000','1.281591678539921','1.452413399761167','8575.387611508339','8575.387611508338523','test','test','0.54'),('2019-03-14 03:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000170940000000','0.000176620000000','1.319552061033531','1.363398180763673','7719.387276433435','7719.387276433434636','test','test','1.39'),('2019-03-24 15:59:59','2019-03-25 07:59:59','RCNETH','4h','0.000175890000000','0.000172372200000','1.329295643195785','1.302709730331869','7557.539616781997','7557.539616781997211','test','test','2.00'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000169941800000','1.323387662559359','1.296919909308172','7631.553327716737','7631.553327716736931','test','test','2.00'),('2019-03-27 11:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000177820000000','0.000208630000000','1.317505939614651','1.545783737385022','7409.211222667031','7409.211222667030597','test','test','1.08'),('2019-04-13 07:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000187440000000','0.000184500000000','1.368234339119178','1.346773557231585','7299.585676051954','7299.585676051953669','test','test','1.56'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.363465276477491','1.362663923728973','7285.0249865221795','7285.024986522179461','test','test','0.30'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000185700000000','1.363287198088931','1.345320611569319','7244.591338553148','7244.591338553147580','test','test','1.31'),('2019-04-20 11:59:59','2019-04-20 19:59:59','RCNETH','4h','0.000193870000000','0.000189992600000','1.359294623306796','1.332108730840660','7011.371657846988','7011.371657846987546','test','test','2.00'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000184063600000','1.353253313869876','1.326188247592478','7205.054381162157','7205.054381162157370','test','test','1.99'),('2019-05-02 07:59:59','2019-05-02 11:59:59','RCNETH','4h','0.000162370000000','0.000191310000000','1.347238854697121','1.587363831324174','8297.338515102057','8297.338515102057499','test','test','0.0'),('2019-05-02 15:59:59','2019-05-02 23:59:59','RCNETH','4h','0.000206320000000','0.000202193600000','1.400599960614244','1.372587961401959','6788.483717595212','6788.483717595211601','test','test','1.99'),('2019-05-10 15:59:59','2019-05-10 23:59:59','RCNETH','4h','0.000179030000000','0.000175449400000','1.394375071900403','1.366487570462395','7788.499535834235','7788.499535834234848','test','test','2.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','RCNETH','4h','0.000134020000000','0.000131339600000','1.388177849358623','1.360414292371450','10357.990220553824','10357.990220553823747','test','test','1.99'),('2019-05-24 07:59:59','2019-05-24 11:59:59','RCNETH','4h','0.000131330000000','0.000128703400000','1.382008170028141','1.354368006627578','10523.171933512072','10523.171933512072428','test','test','1.99'),('2019-05-27 23:59:59','2019-05-28 03:59:59','RCNETH','4h','0.000137390000000','0.000134642200000','1.375865911494682','1.348348593264789','10014.308985331405','10014.308985331404983','test','test','1.99'),('2019-05-28 07:59:59','2019-05-28 11:59:59','RCNETH','4h','0.000130730000000','0.000130940000000','1.369750951888039','1.371951270865294','10477.709415497891','10477.709415497891314','test','test','0.0'),('2019-06-02 03:59:59','2019-06-03 07:59:59','RCNETH','4h','0.000127600000000','0.000127150000000','1.370239911660762','1.365407560875124','10738.557301416633','10738.557301416632981','test','test','0.35'),('2019-06-07 11:59:59','2019-06-07 23:59:59','RCNETH','4h','0.000124930000000','0.000126490000000','1.369166055930621','1.386262822497913','10959.465748263992','10959.465748263992282','test','test','0.74'),('2019-06-08 07:59:59','2019-06-12 15:59:59','RCNETH','4h','0.000128340000000','0.000128200000000','1.372965337390019','1.371467634824688','10697.87546665123','10697.875466651230454','test','test','1.03'),('2019-06-14 03:59:59','2019-06-14 07:59:59','RCNETH','4h','0.000131500000000','0.000128870000000','1.372632514597723','1.345179864305769','10438.270072986486','10438.270072986486412','test','test','1.99'),('2019-06-20 07:59:59','2019-06-20 15:59:59','RCNETH','4h','0.000123180000000','0.000124260000000','1.366531925643955','1.378513208966698','11093.780854391585','11093.780854391585308','test','test','0.0'),('2019-06-20 23:59:59','2019-06-21 03:59:59','RCNETH','4h','0.000129480000000','0.000126890400000','1.369194433049010','1.341810544388030','10574.563122096151','10574.563122096151346','test','test','2.00'),('2019-06-21 11:59:59','2019-06-21 23:59:59','RCNETH','4h','0.000131100000000','0.000128478000000','1.363109124457681','1.335846941968527','10397.476159097489','10397.476159097488562','test','test','2.00'),('2019-07-10 23:59:59','2019-07-11 19:59:59','RCNETH','4h','0.000090450000000','0.000088641000000','1.357050861682313','1.329909844448667','15003.326276200256','15003.326276200255961','test','test','1.99'),('2019-07-22 15:59:59','2019-07-23 19:59:59','RCNETH','4h','0.000083100000000','0.000083890000000','1.351019524519281','1.363863151768020','16257.756011062342','16257.756011062341713','test','test','0.0'),('2019-07-24 03:59:59','2019-07-24 07:59:59','RCNETH','4h','0.000083110000000','0.000085720000000','1.353873663907889','1.396390933343572','16290.141546238594','16290.141546238593946','test','test','0.0'),('2019-07-24 11:59:59','2019-07-24 19:59:59','RCNETH','4h','0.000086570000000','0.000084838600000','1.363321946004708','1.336055507084614','15748.203142020418','15748.203142020418454','test','test','2.00'),('2019-07-26 11:59:59','2019-07-30 07:59:59','RCNETH','4h','0.000089270000000','0.000087484600000','1.357262737355798','1.330117482608682','15204.018565652492','15204.018565652491816','test','test','1.99'),('2019-08-09 07:59:59','2019-08-09 11:59:59','RCNETH','4h','0.000083070000000','0.000081408600000','1.351230458523106','1.324205849352644','16266.166588697552','16266.166588697551560','test','test','1.99'),('2019-08-10 19:59:59','2019-08-11 07:59:59','RCNETH','4h','0.000085660000000','0.000083946800000','1.345224989818559','1.318320490022188','15704.237565007688','15704.237565007688318','test','test','2.00'),('2019-08-18 11:59:59','2019-08-18 19:59:59','RCNETH','4h','0.000079940000000','0.000078341200000','1.339246212086032','1.312461287844312','16753.142507956363','16753.142507956363261','test','test','1.99'),('2019-08-20 19:59:59','2019-08-20 23:59:59','RCNETH','4h','0.000079750000000','0.000078155000000','1.333294006698983','1.306628126565003','16718.42014669571','16718.420146695709263','test','test','2.00'),('2019-08-21 07:59:59','2019-08-21 11:59:59','RCNETH','4h','0.000079880000000','0.000078282400000','1.327368255558098','1.300820890446936','16617.028737582605','16617.028737582604663','test','test','2.00'),('2019-08-22 03:59:59','2019-08-22 07:59:59','RCNETH','4h','0.000082200000000','0.000080556000000','1.321468841088951','1.295039464267172','16076.263273588214','16076.263273588214361','test','test','1.99'),('2019-08-24 07:59:59','2019-08-28 19:59:59','RCNETH','4h','0.000085060000000','0.000083358800000','1.315595646239667','1.289283733314874','15466.678182925782','15466.678182925781584','test','test','2.00'),('2019-08-29 03:59:59','2019-08-29 07:59:59','RCNETH','4h','0.000085240000000','0.000083535200000','1.309748554478602','1.283553583389030','15365.421802893028','15365.421802893028143','test','test','1.99'),('2019-08-29 19:59:59','2019-09-01 23:59:59','RCNETH','4h','0.000085250000000','0.000084950000000','1.303927449792030','1.299338848795695','15295.336654451969','15295.336654451968570','test','test','0.35'),('2019-09-16 11:59:59','2019-09-16 15:59:59','RCNETH','4h','0.000075610000000','0.000078610000000','1.302907760681734','1.354603611522168','17231.950280144603','17231.950280144603312','test','test','0.0'),('2019-09-17 07:59:59','2019-09-17 11:59:59','RCNETH','4h','0.000077910000000','0.000076351800000','1.314395727535163','1.288107812984460','16870.693460854363','16870.693460854363366','test','test','2.00'),('2019-09-19 03:59:59','2019-09-19 07:59:59','RCNETH','4h','0.000097280000000','0.000095334400000','1.308553968746118','1.282382889371196','13451.418264248749','13451.418264248748528','test','test','1.99'),('2019-09-19 11:59:59','2019-09-30 19:59:59','RCNETH','4h','0.000099630000000','0.000188800000000','1.302738173329469','2.468703875585704','13075.762052890383','13075.762052890382620','test','test','0.0'),('2019-10-01 11:59:59','2019-10-07 07:59:59','RCNETH','4h','0.000209760000000','0.000212630000000','1.561841662719743','1.583211254500853','7445.850794811896','7445.850794811895867','test','test','0.0'),('2019-10-07 19:59:59','2019-10-08 07:59:59','RCNETH','4h','0.000231010000000','0.000226389800000','1.566590460893323','1.535258651675456','6781.483316277752','6781.483316277752238','test','test','2.00'),('2019-10-08 11:59:59','2019-10-09 15:59:59','RCNETH','4h','0.000225390000000','0.000220882200000','1.559627836622686','1.528435279890232','6919.685152946831','6919.685152946831295','test','test','2.00'),('2019-10-09 19:59:59','2019-10-09 23:59:59','RCNETH','4h','0.000219850000000','0.000219190000000','1.552696157348808','1.548034890740438','7062.525164197443','7062.525164197442791','test','test','0.30'),('2019-10-15 15:59:59','2019-10-15 19:59:59','RCNETH','4h','0.000219030000000','0.000227200000000','1.551660320324725','1.609538532519643','7084.236498766038','7084.236498766037585','test','test','0.0'),('2019-10-21 07:59:59','2019-10-25 07:59:59','RCNETH','4h','0.000215740000000','0.000240460000000','1.564522145256929','1.743788796924451','7251.88720337874','7251.887203378740196','test','test','0.0'),('2019-10-29 23:59:59','2019-10-30 03:59:59','RCNETH','4h','0.000227020000000','0.000222479600000','1.604359178960823','1.572271995381606','7067.038934723035','7067.038934723034799','test','test','2.00'),('2019-11-01 15:59:59','2019-11-04 15:59:59','RCNETH','4h','0.000226350000000','0.000226800000000','1.597228693720997','1.600404098678693','7056.455461546267','7056.455461546266633','test','test','0.0'),('2019-11-06 19:59:59','2019-11-07 11:59:59','RCNETH','4h','0.000256040000000','0.000250919200000','1.597934339267152','1.565975652481809','6240.955863408654','6240.955863408654295','test','test','2.00'),('2019-11-10 07:59:59','2019-11-10 19:59:59','RCNETH','4h','0.000252840000000','0.000250730000000','1.590832408870409','1.577556596567306','6291.8541720867315','6291.854172086731523','test','test','0.88'),('2019-11-10 23:59:59','2019-11-11 19:59:59','RCNETH','4h','0.000256440000000','0.000251311200000','1.587882228358608','1.556124583791436','6192.022415998317','6192.022415998317229','test','test','2.00'),('2019-11-12 07:59:59','2019-11-14 11:59:59','RCNETH','4h','0.000257540000000','0.000252389200000','1.580824974010348','1.549208474530141','6138.1726101201675','6138.172610120167519','test','test','1.99'),('2019-11-14 15:59:59','2019-11-15 19:59:59','RCNETH','4h','0.000258120000000','0.000255130000000','1.573799085236969','1.555568575145312','6097.160565771613','6097.160565771612710','test','test','1.15'),('2019-11-16 07:59:59','2019-11-16 11:59:59','RCNETH','4h','0.000257990000000','0.000253860000000','1.569747860772156','1.544618752415286','6084.5298684916315','6084.529868491631532','test','test','1.60'),('2019-11-16 19:59:59','2019-11-17 11:59:59','RCNETH','4h','0.000269080000000','0.000263698400000','1.564163614470629','1.532880342181216','5813.0058513105005','5813.005851310500475','test','test','1.99'),('2019-11-20 11:59:59','2019-11-21 11:59:59','RCNETH','4h','0.000262860000000','0.000257602800000','1.557211776184093','1.526067540660411','5924.110842973801','5924.110842973800573','test','test','2.00'),('2019-11-21 19:59:59','2019-11-30 15:59:59','RCNETH','4h','0.000257850000000','0.000302910000000','1.550290834956608','1.821208442182300','6012.37477198607','6012.374771986070300','test','test','0.0'),('2019-12-01 07:59:59','2019-12-01 23:59:59','RCNETH','4h','0.000372200000000','0.000364756000000','1.610494747673428','1.578284852719959','4326.960633190297','4326.960633190296903','test','test','2.00'),('2019-12-06 11:59:59','2019-12-08 03:59:59','RCNETH','4h','0.000326180000000','0.000324160000000','1.603336993239324','1.593407688173583','4915.497557297579','4915.497557297579078','test','test','0.61'),('2019-12-08 15:59:59','2019-12-08 19:59:59','RCNETH','4h','0.000328820000000','0.000324410000000','1.601130481002493','1.579656770701352','4869.322063750664','4869.322063750663801','test','test','1.34'),('2019-12-09 11:59:59','2019-12-09 15:59:59','RCNETH','4h','0.000347170000000','0.000340226600000','1.596358545380017','1.564431374472417','4598.204180603213','4598.204180603212990','test','test','2.00'),('2019-12-16 03:59:59','2019-12-16 07:59:59','RCNETH','4h','0.000313830000000','0.000310230000000','1.589263618511662','1.571032891600143','5064.090808755255','5064.090808755255239','test','test','1.14'),('2019-12-16 15:59:59','2019-12-16 19:59:59','RCNETH','4h','0.000313580000000','0.000311500000000','1.585212345864658','1.574697511757258','5055.2087054807635','5055.208705480763456','test','test','0.66'),('2019-12-18 03:59:59','2019-12-18 15:59:59','RCNETH','4h','0.000324620000000','0.000318127600000','1.582875716063013','1.551218201741753','4876.088090884767','4876.088090884766643','test','test','2.00'),('2019-12-19 19:59:59','2019-12-27 07:59:59','RCNETH','4h','0.000335480000000','0.000349810000000','1.575840712880511','1.643152616468140','4697.271708836624','4697.271708836624384','test','test','0.0'),('2019-12-27 15:59:59','2019-12-27 19:59:59','RCNETH','4h','0.000355150000000','0.000349810000000','1.590798913677762','1.566879819776483','4479.231067655251','4479.231067655250627','test','test','1.50'),('2019-12-30 03:59:59','2019-12-30 07:59:59','RCNETH','4h','0.000351600000000','0.000344568000000','1.585483559477478','1.553773888287929','4509.338906363702','4509.338906363702336','test','test','2.00'),('2019-12-31 19:59:59','2019-12-31 23:59:59','RCNETH','4h','0.000349810000000','0.000346420000000','1.578436965879800','1.563140372545326','4512.269420198965','4512.269420198965236','test','test','0.96'),('2020-01-01 07:59:59','2020-01-01 11:59:59','RCNETH','4h','0.000351600000000','0.000353400000000','1.575037722916584','1.583101055969058','4479.629473596654','4479.629473596653952','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:51:11
