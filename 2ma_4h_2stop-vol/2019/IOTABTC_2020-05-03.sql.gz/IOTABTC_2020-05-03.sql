-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-06 07:59:59','IOTABTC','4h','0.000095400000000','0.000093492000000','0.033333333333333','0.032666666666666','349.4060097833683','349.406009783368290','test','test','1.99'),('2019-01-06 11:59:59','2019-01-06 19:59:59','IOTABTC','4h','0.000094670000000','0.000093610000000','0.033185185185185','0.032813617673869','350.53538803406684','350.535388034066841','test','test','1.11'),('2019-01-06 23:59:59','2019-01-07 03:59:59','IOTABTC','4h','0.000092840000000','0.000092350000000','0.033102614627115','0.032927902421522','356.55552161907457','356.555521619074568','test','test','0.52'),('2019-01-19 11:59:59','2019-01-19 19:59:59','IOTABTC','4h','0.000085130000000','0.000084920000000','0.033063789692539','0.032982227425002','388.3917501766553','388.391750176655307','test','test','0.24'),('2019-01-21 15:59:59','2019-01-21 23:59:59','IOTABTC','4h','0.000085310000000','0.000085160000000','0.033045664744197','0.032987560773834','387.3598024170333','387.359802417033279','test','test','0.17'),('2019-02-08 11:59:59','2019-02-09 19:59:59','IOTABTC','4h','0.000075090000000','0.000075110000000','0.033032752750783','0.033041550927038','439.9088127684527','439.908812768452719','test','test','0.06'),('2019-02-09 23:59:59','2019-02-10 15:59:59','IOTABTC','4h','0.000075400000000','0.000075220000000','0.033034707901062','0.032955845203155','438.1260994835809','438.126099483580902','test','test','0.23'),('2019-02-10 19:59:59','2019-02-11 11:59:59','IOTABTC','4h','0.000075530000000','0.000074040000000','0.033017182857083','0.032365844283575','437.1399822200803','437.139982220080299','test','test','1.97'),('2019-02-12 19:59:59','2019-02-12 23:59:59','IOTABTC','4h','0.000075220000000','0.000075310000000','0.032872440951859','0.032911772508435','437.01729529192596','437.017295291925961','test','test','0.0'),('2019-02-13 03:59:59','2019-02-13 07:59:59','IOTABTC','4h','0.000075010000000','0.000075150000000','0.032881181297764','0.032942551320184','438.3573029964597','438.357302996459680','test','test','0.0'),('2019-02-13 11:59:59','2019-02-13 15:59:59','IOTABTC','4h','0.000074760000000','0.000074230000000','0.032894819080524','0.032661616109514','440.00560567849715','440.005605678497147','test','test','0.70'),('2019-02-15 11:59:59','2019-02-16 03:59:59','IOTABTC','4h','0.000075640000000','0.000074650000000','0.032842996198078','0.032413136781948','434.20143043466123','434.201430434661233','test','test','1.30'),('2019-02-16 07:59:59','2019-02-16 11:59:59','IOTABTC','4h','0.000074960000000','0.000075710000000','0.032747471883382','0.033075121348597','436.8659536203605','436.865953620360472','test','test','0.0'),('2019-02-16 15:59:59','2019-02-16 19:59:59','IOTABTC','4h','0.000074990000000','0.000075140000000','0.032820282875652','0.032885932194646','437.6621266255796','437.662126625579617','test','test','0.0'),('2019-02-16 23:59:59','2019-02-18 03:59:59','IOTABTC','4h','0.000075730000000','0.000074720000000','0.032834871613206','0.032396957704196','433.5781277328198','433.578127732819780','test','test','1.33'),('2019-02-18 07:59:59','2019-02-21 19:59:59','IOTABTC','4h','0.000075440000000','0.000076050000000','0.032737557411204','0.033002269898225','433.9548967550931','433.954896755093102','test','test','0.0'),('2019-02-22 03:59:59','2019-02-22 07:59:59','IOTABTC','4h','0.000076950000000','0.000076410000000','0.032796382408320','0.032566232356332','426.2037999781676','426.203799978167581','test','test','0.70'),('2019-02-22 11:59:59','2019-02-22 15:59:59','IOTABTC','4h','0.000076480000000','0.000077120000000','0.032745237952323','0.033019256679958','428.1542619289051','428.154261928905100','test','test','0.0'),('2019-02-22 19:59:59','2019-02-23 03:59:59','IOTABTC','4h','0.000077260000000','0.000076870000000','0.032806131002908','0.032640529254382','424.6198680158973','424.619868015897282','test','test','0.50'),('2019-02-23 19:59:59','2019-02-24 07:59:59','IOTABTC','4h','0.000077130000000','0.000076770000000','0.032769330614347','0.032616381579974','424.85842881300255','424.858428813002547','test','test','0.46'),('2019-02-24 11:59:59','2019-02-24 15:59:59','IOTABTC','4h','0.000077510000000','0.000075959800000','0.032735341940042','0.032080635101241','422.3370138052094','422.337013805209381','test','test','1.99'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTABTC','4h','0.000076390000000','0.000075390000000','0.032589851531419','0.032163226953183','426.6245782356242','426.624578235624199','test','test','1.30'),('2019-03-02 11:59:59','2019-03-02 15:59:59','IOTABTC','4h','0.000075720000000','0.000075360000000','0.032495046069589','0.032340552982095','429.1474652613458','429.147465261345815','test','test','0.47'),('2019-03-02 23:59:59','2019-03-03 11:59:59','IOTABTC','4h','0.000076280000000','0.000075630000000','0.032460714272368','0.032184108815144','425.54685726754354','425.546857267543544','test','test','0.85'),('2019-03-13 03:59:59','2019-03-13 11:59:59','IOTABTC','4h','0.000073980000000','0.000072570000000','0.032399246392985','0.031781742507961','437.9460177478386','437.946017747838596','test','test','1.90'),('2019-03-13 15:59:59','2019-03-17 11:59:59','IOTABTC','4h','0.000073190000000','0.000074870000000','0.032262023307424','0.033002564353420','440.7982416644927','440.798241664492707','test','test','0.0'),('2019-03-17 15:59:59','2019-03-17 19:59:59','IOTABTC','4h','0.000074460000000','0.000074420000000','0.032426587984312','0.032409168382924','435.4900347073894','435.490034707389384','test','test','0.05'),('2019-03-17 23:59:59','2019-03-18 03:59:59','IOTABTC','4h','0.000074180000000','0.000074280000000','0.032422716961782','0.032466425127004','437.0816522213743','437.081652221374327','test','test','0.0'),('2019-03-19 11:59:59','2019-03-19 15:59:59','IOTABTC','4h','0.000074210000000','0.000073820000000','0.032432429887386','0.032261985908730','437.03584270834716','437.035842708347161','test','test','0.52'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTABTC','4h','0.000075210000000','0.000073705800000','0.032394553447685','0.031746662378731','430.72135949587965','430.721359495879653','test','test','2.00'),('2019-03-21 19:59:59','2019-03-25 03:59:59','IOTABTC','4h','0.000076620000000','0.000076100000000','0.032250577654584','0.032031701377106','420.9159182274108','420.915918227410828','test','test','0.67'),('2019-03-25 07:59:59','2019-03-25 11:59:59','IOTABTC','4h','0.000075540000000','0.000075860000000','0.032201938481811','0.032338351247421','426.2898925312594','426.289892531259397','test','test','0.0'),('2019-03-28 15:59:59','2019-03-28 19:59:59','IOTABTC','4h','0.000075790000000','0.000075330000000','0.032232252429725','0.032036621922829','425.28371064420986','425.283710644209862','test','test','0.60'),('2019-03-29 19:59:59','2019-03-29 23:59:59','IOTABTC','4h','0.000075710000000','0.000075180000000','0.032188778983748','0.031963444776095','425.1588823635949','425.158882363594898','test','test','0.70'),('2019-04-01 07:59:59','2019-04-02 07:59:59','IOTABTC','4h','0.000075500000000','0.000073990000000','0.032138704715380','0.031495930621072','425.67820815073435','425.678208150734349','test','test','2.00'),('2019-04-29 03:59:59','2019-04-30 03:59:59','IOTABTC','4h','0.000057930000000','0.000056771400000','0.031995866027756','0.031355948707201','552.3194549932063','552.319454993206250','test','test','1.99'),('2019-04-30 07:59:59','2019-04-30 11:59:59','IOTABTC','4h','0.000055850000000','0.000057300000000','0.031853662178744','0.032680659674880','570.3431007832448','570.343100783244836','test','test','0.0'),('2019-04-30 15:59:59','2019-05-01 11:59:59','IOTABTC','4h','0.000055880000000','0.000054762400000','0.032037439400108','0.031396690612106','573.3256871887576','573.325687188757570','test','test','2.00'),('2019-05-14 23:59:59','2019-05-22 23:59:59','IOTABTC','4h','0.000047020000000','0.000050180000000','0.031895050780552','0.034038571845345','678.3294508837043','678.329450883704340','test','test','0.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','IOTABTC','4h','0.000049500000000','0.000048990000000','0.032371388794950','0.032037865395244','653.9674504030348','653.967450403034832','test','test','1.03'),('2019-05-28 11:59:59','2019-05-28 15:59:59','IOTABTC','4h','0.000049340000000','0.000051670000000','0.032297272483904','0.033822457828199','654.5859846758095','654.585984675809527','test','test','0.0'),('2019-05-28 19:59:59','2019-06-03 23:59:59','IOTABTC','4h','0.000055040000000','0.000054800000000','0.032636202560414','0.032493893537621','592.9542616354368','592.954261635436751','test','test','0.43'),('2019-06-04 03:59:59','2019-06-04 07:59:59','IOTABTC','4h','0.000054710000000','0.000055000000000','0.032604578333127','0.032777404648547','595.9528117917586','595.952811791758563','test','test','0.0'),('2019-06-04 11:59:59','2019-06-04 19:59:59','IOTABTC','4h','0.000055180000000','0.000054620000000','0.032642984180998','0.032311703442662','591.5727470278765','591.572747027876517','test','test','1.01'),('2019-06-04 23:59:59','2019-06-05 03:59:59','IOTABTC','4h','0.000055200000000','0.000054670000000','0.032569366239146','0.032256653121270','590.0247507091625','590.024750709162504','test','test','0.96'),('2019-06-05 07:59:59','2019-06-05 19:59:59','IOTABTC','4h','0.000055440000000','0.000055090000000','0.032499874435173','0.032294698460203','586.2170713415104','586.217071341510405','test','test','1.51'),('2019-06-05 23:59:59','2019-06-06 11:59:59','IOTABTC','4h','0.000055150000000','0.000054830000000','0.032454279774069','0.032265968449904','588.4728880157548','588.472888015754847','test','test','0.68'),('2019-06-06 15:59:59','2019-06-06 19:59:59','IOTABTC','4h','0.000054700000000','0.000054090000000','0.032412432813143','0.032050977895117','592.5490459441195','592.549045944119484','test','test','1.11'),('2019-06-07 11:59:59','2019-06-07 15:59:59','IOTABTC','4h','0.000054640000000','0.000055770000000','0.032332109498026','0.033000764031935','591.729676025374','591.729676025374033','test','test','0.0'),('2019-06-07 19:59:59','2019-06-08 03:59:59','IOTABTC','4h','0.000055770000000','0.000054654600000','0.032480699394451','0.031831085406562','582.4045077003884','582.404507700388422','test','test','1.99'),('2019-06-13 15:59:59','2019-06-13 19:59:59','IOTABTC','4h','0.000054240000000','0.000053710000000','0.032336340730475','0.032020369849443','596.1714736444567','596.171473644456682','test','test','0.97'),('2019-07-02 07:59:59','2019-07-02 11:59:59','IOTABTC','4h','0.000039340000000','0.000038553200000','0.032266124979135','0.031620802479552','820.1861967243235','820.186196724323509','test','test','2.00'),('2019-07-20 07:59:59','2019-07-20 19:59:59','IOTABTC','4h','0.000030740000000','0.000030190000000','0.032122719979228','0.031547980356958','1044.9811313997252','1044.981131399725200','test','test','1.78'),('2019-07-24 11:59:59','2019-07-25 07:59:59','IOTABTC','4h','0.000030740000000','0.000030250000000','0.031995000063168','0.031484995182525','1040.8262870256199','1040.826287025619877','test','test','1.59'),('2019-07-25 11:59:59','2019-07-26 23:59:59','IOTABTC','4h','0.000030340000000','0.000030520000000','0.031881665645247','0.032070811980651','1050.8129744643006','1050.812974464300623','test','test','0.0'),('2019-07-27 11:59:59','2019-07-27 15:59:59','IOTABTC','4h','0.000030410000000','0.000030250000000','0.031923698164226','0.031755733951589','1049.7763289781506','1049.776328978150559','test','test','0.52'),('2019-07-27 19:59:59','2019-07-27 23:59:59','IOTABTC','4h','0.000030330000000','0.000030260000000','0.031886372783640','0.031812780759411','1051.3146318377699','1051.314631837769866','test','test','0.23'),('2019-07-28 03:59:59','2019-07-28 07:59:59','IOTABTC','4h','0.000030300000000','0.000030350000000','0.031870019000478','0.031922609790908','1051.815808596619','1051.815808596619036','test','test','0.0'),('2019-07-28 11:59:59','2019-07-28 15:59:59','IOTABTC','4h','0.000030260000000','0.000030040000000','0.031881705842795','0.031649915516112','1053.5923940117427','1053.592394011742726','test','test','0.72'),('2019-08-18 15:59:59','2019-08-18 19:59:59','IOTABTC','4h','0.000024010000000','0.000024100000000','0.031830196881310','0.031949510405646','1325.7058259604423','1325.705825960442326','test','test','0.0'),('2019-08-18 23:59:59','2019-08-19 07:59:59','IOTABTC','4h','0.000023930000000','0.000023610000000','0.031856710997829','0.031430712355150','1331.2457583714724','1331.245758371472448','test','test','1.33'),('2019-08-21 23:59:59','2019-08-28 19:59:59','IOTABTC','4h','0.000023680000000','0.000025130000000','0.031762044632790','0.033706933345524','1341.3025605063156','1341.302560506315558','test','test','0.0'),('2019-08-28 23:59:59','2019-08-29 03:59:59','IOTABTC','4h','0.000024940000000','0.000024750000000','0.032194242124508','0.031948977248660','1290.8677676226232','1290.867767622623205','test','test','0.76'),('2019-08-29 11:59:59','2019-09-01 19:59:59','IOTABTC','4h','0.000025470000000','0.000025230000000','0.032139738818764','0.031836890867586','1261.8664632416262','1261.866463241626207','test','test','0.94'),('2019-09-10 19:59:59','2019-09-10 23:59:59','IOTABTC','4h','0.000023890000000','0.000023610000000','0.032072439274058','0.031696537934722','1342.5047833427375','1342.504783342737483','test','test','1.17'),('2019-09-11 11:59:59','2019-09-11 15:59:59','IOTABTC','4h','0.000023690000000','0.000023590000000','0.031988905643094','0.031853874382465','1350.3126062935603','1350.312606293560293','test','test','0.42'),('2019-09-13 19:59:59','2019-09-13 23:59:59','IOTABTC','4h','0.000023660000000','0.000023370000000','0.031958898696288','0.031567179312437','1350.7564960392222','1350.756496039222156','test','test','1.22'),('2019-09-14 15:59:59','2019-10-09 15:59:59','IOTABTC','4h','0.000023770000000','0.000032380000000','0.031871849944321','0.043416512460964','1340.8434978679472','1340.843497867947235','test','test','0.21'),('2019-10-12 07:59:59','2019-10-12 15:59:59','IOTABTC','4h','0.000032690000000','0.000032360000000','0.034437330503575','0.034089691498797','1053.451529629095','1053.451529629094921','test','test','1.00'),('2019-10-13 11:59:59','2019-10-18 11:59:59','IOTABTC','4h','0.000033630000000','0.000033840000000','0.034360077391402','0.034574636304640','1021.7091106572173','1021.709110657217252','test','test','0.98'),('2019-10-18 15:59:59','2019-10-20 19:59:59','IOTABTC','4h','0.000034040000000','0.000033359200000','0.034407757149900','0.033719602006902','1010.803676554041','1010.803676554040976','test','test','2.00'),('2019-10-22 23:59:59','2019-10-23 11:59:59','IOTABTC','4h','0.000033580000000','0.000033190000000','0.034254833784789','0.033856996227431','1020.0963009168818','1020.096300916881773','test','test','1.16'),('2019-10-23 15:59:59','2019-10-23 19:59:59','IOTABTC','4h','0.000033480000000','0.000033960000000','0.034166425438709','0.034656266663637','1020.5025519327759','1020.502551932775873','test','test','0.0'),('2019-10-23 23:59:59','2019-10-25 11:59:59','IOTABTC','4h','0.000033930000000','0.000033720000000','0.034275279044249','0.034063142038670','1010.1762170424075','1010.176217042407529','test','test','0.61'),('2019-11-08 23:59:59','2019-11-09 03:59:59','IOTABTC','4h','0.000030180000000','0.000029830000000','0.034228137487454','0.033831190896314','1134.1331175431928','1134.133117543192839','test','test','1.15'),('2019-11-09 11:59:59','2019-11-10 15:59:59','IOTABTC','4h','0.000030040000000','0.000030050000000','0.034139927133867','0.034151291956481','1136.482261446967','1136.482261446966959','test','test','0.0'),('2019-11-14 07:59:59','2019-11-15 15:59:59','IOTABTC','4h','0.000030590000000','0.000030090000000','0.034142452650003','0.033584387062393','1116.1311752207694','1116.131175220769364','test','test','1.63'),('2019-11-15 19:59:59','2019-11-17 11:59:59','IOTABTC','4h','0.000030220000000','0.000030170000000','0.034018438074979','0.033962153432234','1125.6928548967205','1125.692854896720519','test','test','0.36'),('2019-11-17 15:59:59','2019-11-18 03:59:59','IOTABTC','4h','0.000030250000000','0.000030330000000','0.034005930376591','0.034095863415603','1124.1629876559045','1124.162987655904544','test','test','0.26'),('2019-11-18 07:59:59','2019-11-18 19:59:59','IOTABTC','4h','0.000030520000000','0.000030260000000','0.034025915496372','0.033736048588474','1114.8727226858307','1114.872722685830695','test','test','1.37'),('2019-11-18 23:59:59','2019-11-19 07:59:59','IOTABTC','4h','0.000030480000000','0.000030070000000','0.033961500627950','0.033504669418716','1114.2224615469088','1114.222461546908789','test','test','1.34'),('2019-11-19 23:59:59','2019-11-20 07:59:59','IOTABTC','4h','0.000030200000000','0.000030150000000','0.033859982581453','0.033803923007643','1121.1914762070642','1121.191476207064170','test','test','0.16');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:40:02
