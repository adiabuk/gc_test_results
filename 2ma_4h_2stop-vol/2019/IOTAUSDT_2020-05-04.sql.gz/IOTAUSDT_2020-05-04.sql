-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 07:59:59','2019-01-06 07:59:59','IOTAUSDT','4h','0.361200000000000','0.353976000000000','222.222222222222200','217.777777777777743','615.2331733727082','615.233173372708166','test','test','2.00'),('2019-01-06 19:59:59','2019-01-07 11:59:59','IOTAUSDT','4h','0.373600000000000','0.366128000000000','221.234567901234556','216.809876543209896','592.1696142966664','592.169614296666396','test','test','1.99'),('2019-01-08 11:59:59','2019-01-08 19:59:59','IOTAUSDT','4h','0.366400000000000','0.359200000000000','220.251303155006866','215.923220778598449','601.1225522789489','601.122552278948888','test','test','1.96'),('2019-01-09 19:59:59','2019-01-10 07:59:59','IOTAUSDT','4h','0.363200000000000','0.355936000000000','219.289507071360532','214.903716929933324','603.7706692493406','603.770669249340585','test','test','1.99'),('2019-01-19 11:59:59','2019-01-19 23:59:59','IOTAUSDT','4h','0.314700000000000','0.308406000000000','218.314887039932273','213.948589299133630','693.7238228151646','693.723822815164567','test','test','2.00'),('2019-02-08 15:59:59','2019-02-12 03:59:59','IOTAUSDT','4h','0.265000000000000','0.265800000000000','217.344598653088156','218.000733290531429','820.1682968041063','820.168296804106262','test','test','0.0'),('2019-02-12 19:59:59','2019-02-13 15:59:59','IOTAUSDT','4h','0.274100000000000','0.268618000000000','217.490406350297718','213.140598223291789','793.4710191546798','793.471019154679766','test','test','1.99'),('2019-02-15 11:59:59','2019-02-24 15:59:59','IOTAUSDT','4h','0.272600000000000','0.282100000000000','216.523782322074226','224.069548763966026','794.2912044096634','794.291204409663351','test','test','1.32'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTAUSDT','4h','0.292700000000000','0.286846000000000','218.200619309161283','213.836606922978035','745.4752965806672','745.475296580667191','test','test','2.00'),('2019-03-12 23:59:59','2019-03-13 11:59:59','IOTAUSDT','4h','0.282700000000000','0.279500000000000','217.230838778898345','214.771911703933824','768.4147109264179','768.414710926417911','test','test','1.13'),('2019-03-13 15:59:59','2019-03-13 23:59:59','IOTAUSDT','4h','0.283400000000000','0.283800000000000','216.684410540017325','216.990245981852240','764.5886045872171','764.588604587217105','test','test','0.0'),('2019-03-14 07:59:59','2019-03-14 19:59:59','IOTAUSDT','4h','0.286500000000000','0.294500000000000','216.752373971536173','222.804796281387098','756.5527887313655','756.552788731365467','test','test','0.0'),('2019-03-14 23:59:59','2019-03-18 07:59:59','IOTAUSDT','4h','0.297000000000000','0.291060000000000','218.097356707058651','213.735409572917462','734.3345343672008','734.334534367200831','test','test','2.00'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTAUSDT','4h','0.302200000000000','0.296156000000000','217.128035121693898','212.785474419260026','718.4911817395562','718.491181739556168','test','test','1.99'),('2019-03-21 19:59:59','2019-03-25 07:59:59','IOTAUSDT','4h','0.305000000000000','0.301500000000000','216.163021632264162','213.682462367631615','708.7312184664399','708.731218466439941','test','test','1.14'),('2019-03-27 11:59:59','2019-03-27 19:59:59','IOTAUSDT','4h','0.303300000000000','0.300700000000000','215.611786240123621','213.763482104863755','710.8862058691843','710.886205869184323','test','test','0.85'),('2019-03-27 23:59:59','2019-03-28 11:59:59','IOTAUSDT','4h','0.305700000000000','0.300900000000000','215.201051987843613','211.822036451233686','703.9615701270644','703.961570127064419','test','test','1.57'),('2019-03-29 11:59:59','2019-03-30 07:59:59','IOTAUSDT','4h','0.306600000000000','0.306400000000000','214.450159646374772','214.310270435907483','699.4460523365127','699.446052336512707','test','test','0.06'),('2019-04-01 03:59:59','2019-04-03 23:59:59','IOTAUSDT','4h','0.310500000000000','0.335900000000000','214.419073155159822','231.959312955936184','690.5606220778094','690.560622077809398','test','test','0.0'),('2019-04-07 11:59:59','2019-04-08 11:59:59','IOTAUSDT','4h','0.357400000000000','0.350252000000000','218.316904221999010','213.950566137559036','610.8475216060409','610.847521606040914','test','test','1.99'),('2019-04-08 15:59:59','2019-04-09 07:59:59','IOTAUSDT','4h','0.350800000000000','0.343784000000000','217.346606869901251','212.999674732503223','619.5741358891141','619.574135889114132','test','test','2.00'),('2019-04-10 19:59:59','2019-04-11 03:59:59','IOTAUSDT','4h','0.354700000000000','0.347606000000000','216.380621950479480','212.053009511469895','610.0384041456991','610.038404145699133','test','test','1.99'),('2019-04-29 03:59:59','2019-04-30 03:59:59','IOTAUSDT','4h','0.308300000000000','0.302134000000000','215.418930297366188','211.110551691418863','698.731528697263','698.731528697263002','test','test','2.00'),('2019-05-11 11:59:59','2019-05-23 03:59:59','IOTAUSDT','4h','0.292800000000000','0.383000000000000','214.461512829377881','280.528549910012771','732.4505219582578','732.450521958257809','test','test','0.0'),('2019-05-23 15:59:59','2019-05-23 19:59:59','IOTAUSDT','4h','0.381100000000000','0.378300000000000','229.143076625074599','227.459527387209988','601.2675849516521','601.267584951652111','test','test','0.73'),('2019-05-23 23:59:59','2019-05-24 23:59:59','IOTAUSDT','4h','0.385900000000000','0.380600000000000','228.768954572215733','225.627012464849173','592.8192655408544','592.819265540854417','test','test','1.37'),('2019-05-25 11:59:59','2019-05-25 15:59:59','IOTAUSDT','4h','0.389600000000000','0.382200000000000','228.070745215023180','223.738806009193667','585.3971899769589','585.397189976958884','test','test','1.89'),('2019-05-26 19:59:59','2019-06-03 23:59:59','IOTAUSDT','4h','0.398300000000000','0.444200000000000','227.108092058172161','253.279976129149105','570.193552744595','570.193552744594967','test','test','0.0'),('2019-06-12 15:59:59','2019-06-12 23:59:59','IOTAUSDT','4h','0.438200000000000','0.434200000000000','232.924066296167013','230.797876736183753','531.5473899958171','531.547389995817070','test','test','0.91'),('2019-06-13 15:59:59','2019-06-14 03:59:59','IOTAUSDT','4h','0.444300000000000','0.435414000000000','232.451579727281882','227.802548132736234','523.1860898655906','523.186089865590588','test','test','2.00'),('2019-06-15 19:59:59','2019-06-16 03:59:59','IOTAUSDT','4h','0.437500000000000','0.440600000000000','231.418461595160608','233.058226694463485','528.9564836460814','528.956483646081438','test','test','0.93'),('2019-06-16 07:59:59','2019-06-16 19:59:59','IOTAUSDT','4h','0.456100000000000','0.446978000000000','231.782853839450155','227.147196762661139','508.1842881812106','508.184288181210604','test','test','2.00'),('2019-06-17 11:59:59','2019-06-17 15:59:59','IOTAUSDT','4h','0.440100000000000','0.433600000000000','230.752707822385929','227.344635564159375','524.3188089579321','524.318808957932106','test','test','1.47'),('2019-06-17 23:59:59','2019-06-18 03:59:59','IOTAUSDT','4h','0.435300000000000','0.430500000000000','229.995358431668933','227.459227670189449','528.3605753082218','528.360575308221769','test','test','1.10'),('2019-06-22 07:59:59','2019-06-22 15:59:59','IOTAUSDT','4h','0.442100000000000','0.451200000000000','229.431773818006803','234.154300716319057','518.958999814537','518.958999814537037','test','test','0.24'),('2019-06-22 19:59:59','2019-06-25 19:59:59','IOTAUSDT','4h','0.452700000000000','0.448900000000000','230.481224239853987','228.546546413232733','509.12574384770045','509.125743847700448','test','test','1.78'),('2019-06-26 03:59:59','2019-06-26 23:59:59','IOTAUSDT','4h','0.473000000000000','0.463540000000000','230.051295833938156','225.450269917259391','486.36637597027095','486.366375970270951','test','test','2.00'),('2019-07-08 19:59:59','2019-07-08 23:59:59','IOTAUSDT','4h','0.410300000000000','0.403300000000000','229.028845630231757','225.121456111802246','558.1985026327852','558.198502632785221','test','test','1.70'),('2019-07-20 15:59:59','2019-07-20 23:59:59','IOTAUSDT','4h','0.331000000000000','0.324380000000000','228.160536848358532','223.597326111391368','689.3067578500257','689.306757850025747','test','test','2.00'),('2019-08-05 11:59:59','2019-08-05 15:59:59','IOTAUSDT','4h','0.294200000000000','0.292700000000000','227.146490017921366','225.988367193220881','772.0818831336552','772.081883133655197','test','test','0.50'),('2019-08-22 19:59:59','2019-08-24 15:59:59','IOTAUSDT','4h','0.261200000000000','0.255976000000000','226.889129390210172','222.351346802405970','868.6413835766086','868.641383576608632','test','test','2.00'),('2019-08-25 11:59:59','2019-08-25 15:59:59','IOTAUSDT','4h','0.272100000000000','0.266658000000000','225.880733259587004','221.363118594395246','830.1386742358949','830.138674235894882','test','test','2.00'),('2019-08-26 03:59:59','2019-08-26 15:59:59','IOTAUSDT','4h','0.271200000000000','0.265776000000000','224.876818889544410','220.379282511753530','829.1918100646918','829.191810064691822','test','test','1.99'),('2019-09-08 15:59:59','2019-09-08 19:59:59','IOTAUSDT','4h','0.246600000000000','0.243800000000000','223.877366361146414','221.335368689568099','907.8563112779659','907.856311277965915','test','test','1.13'),('2019-09-14 15:59:59','2019-09-16 15:59:59','IOTAUSDT','4h','0.246000000000000','0.243400000000000','223.312477989684567','220.952264807679796','907.7743007710754','907.774300771075445','test','test','1.05'),('2019-09-17 11:59:59','2019-09-24 15:59:59','IOTAUSDT','4h','0.249500000000000','0.272600000000000','222.787986171461284','243.414849821003429','892.9378203264981','892.937820326498127','test','test','0.0'),('2019-09-30 19:59:59','2019-09-30 23:59:59','IOTAUSDT','4h','0.264900000000000','0.265400000000000','227.371733649137326','227.800898869313130','858.3304403515942','858.330440351594234','test','test','0.0'),('2019-10-01 03:59:59','2019-10-03 15:59:59','IOTAUSDT','4h','0.271900000000000','0.269300000000000','227.467103698065301','225.291986119488740','836.5836840679121','836.583684067912145','test','test','1.43'),('2019-10-04 19:59:59','2019-10-05 03:59:59','IOTAUSDT','4h','0.270400000000000','0.270500000000000','226.983744236159396','227.067687928554477','839.4369239502937','839.436923950293703','test','test','0.33'),('2019-10-05 15:59:59','2019-10-06 11:59:59','IOTAUSDT','4h','0.274200000000000','0.270700000000000','227.002398390024950','224.104847717650443','827.871620678428','827.871620678428030','test','test','1.56'),('2019-10-06 15:59:59','2019-10-06 19:59:59','IOTAUSDT','4h','0.271300000000000','0.266300000000000','226.358498240608384','222.186760344541142','834.3475792134478','834.347579213447830','test','test','1.84'),('2019-10-07 11:59:59','2019-10-08 15:59:59','IOTAUSDT','4h','0.279700000000000','0.274106000000000','225.431445374815667','220.922816467319365','805.9758504641246','805.975850464124619','test','test','1.99'),('2019-10-09 11:59:59','2019-10-10 11:59:59','IOTAUSDT','4h','0.274600000000000','0.271600000000000','224.429527839816501','221.977639334647364','817.2961683897178','817.296168389717764','test','test','1.09'),('2019-10-13 11:59:59','2019-10-15 19:59:59','IOTAUSDT','4h','0.280700000000000','0.278800000000000','223.884663727556671','222.369234938520833','797.5940994925425','797.594099492542455','test','test','0.96'),('2019-10-17 11:59:59','2019-10-17 15:59:59','IOTAUSDT','4h','0.278400000000000','0.276500000000000','223.547901774437605','222.022251582729922','802.9737851093305','802.973785109330493','test','test','0.68'),('2019-10-25 19:59:59','2019-10-26 03:59:59','IOTAUSDT','4h','0.270600000000000','0.269500000000000','223.208868398502574','222.301515274931432','824.8664759737715','824.866475973771458','test','test','0.40'),('2019-10-26 07:59:59','2019-10-26 11:59:59','IOTAUSDT','4h','0.277100000000000','0.271558000000000','223.007234371042301','218.547089683621465','804.7897306786081','804.789730678608066','test','test','1.99'),('2019-10-27 15:59:59','2019-10-31 07:59:59','IOTAUSDT','4h','0.271500000000000','0.273200000000000','222.016091107171036','223.406247110420338','817.7388254407772','817.738825440777191','test','test','0.73'),('2019-11-04 23:59:59','2019-11-05 07:59:59','IOTAUSDT','4h','0.274000000000000','0.270700000000000','222.325014663448655','219.647377625531192','811.405163005287','811.405163005287022','test','test','1.20'),('2019-11-05 11:59:59','2019-11-05 15:59:59','IOTAUSDT','4h','0.274100000000000','0.274500000000000','221.729984210578095','222.053559525004346','808.9382860655895','808.938286065589523','test','test','0.0'),('2019-11-05 19:59:59','2019-11-07 11:59:59','IOTAUSDT','4h','0.276900000000000','0.271362000000000','221.801889836006154','217.365852039286040','801.0180203539406','801.018020353940642','test','test','1.99'),('2019-12-29 19:59:59','2019-12-30 03:59:59','IOTAUSDT','4h','0.168300000000000','0.164934000000000','220.816103658957246','216.399781585778101','1312.0386432498944','1312.038643249894449','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:37:05
