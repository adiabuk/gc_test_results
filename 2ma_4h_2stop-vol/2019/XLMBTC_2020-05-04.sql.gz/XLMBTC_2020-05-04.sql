-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.033333333333333','0.032863079615048','1093.6132983377079','1093.613298337707874','test','test','1.41'),('2019-01-08 11:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030530000000','0.000030460000000','0.033228832507048','0.033152644551742','1088.3993615148306','1088.399361514830616','test','test','0.45'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.033211901850313','0.032706246072223','1075.8633576389086','1075.863357638908610','test','test','1.52'),('2019-01-13 03:59:59','2019-01-13 15:59:59','XLMBTC','4h','0.000030740000000','0.000030125200000','0.033099533899626','0.032437543221633','1076.7577716208993','1076.757771620899348','test','test','1.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.032952424860072','0.032610548966276','1102.8254638578462','1102.825463857846216','test','test','1.03'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.032876452439229','0.033038115817339','1469.6670737250286','1469.667073725028558','test','test','0.0'),('2019-02-20 11:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022780000000','0.000022324400000','0.032912377634364','0.032254130081677','1444.792696855331','1444.792696855331087','test','test','1.99'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.032766100400434','0.032548818567540','1448.545552627498','1448.545552627497955','test','test','0.66'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.032717815548680','0.032541676568606','1467.8248339470513','1467.824833947051275','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022393000000','0.032678673553108','0.032025100082046','1430.1388863504499','1430.138886350449866','test','test','1.99'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.032533435003983','0.038113086206095','1453.0341672167435','1453.034167216743526','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026656000000','0.033773357493341','0.033097890343474','1241.6675549022468','1241.667554902246820','test','test','2.00'),('2019-03-27 15:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026410000000','0.000026340000000','0.033623253682260','0.033534134872803','1273.1258493850646','1273.125849385064612','test','test','0.26'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026650000000','0.000026117000000','0.033603449502380','0.032931380512332','1260.9174297328414','1260.917429732841356','test','test','1.99'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.033454100837925','0.032891297107084','1308.8458856778213','1308.845885677821343','test','test','1.68'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.033329033342183','0.037242506934620','2150.260215624688','2150.260215624688044','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018051600000','0.034198694140502','0.033514720257692','1856.6066308633012','1856.606630863301234','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018531800000','0.034046699944322','0.033365765945436','1800.4600710905343','1800.460071090534257','test','test','1.99'),('2019-05-18 03:59:59','2019-05-18 07:59:59','XLMBTC','4h','0.000018890000000','0.000018512200000','0.033895381277903','0.033217473652345','1794.3558114294806','1794.355811429480582','test','test','2.00'),('2019-05-21 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016880000000','0.000016550000000','0.033744735138890','0.033085033563307','1999.0956835835307','1999.095683583530672','test','test','1.95'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XLMBTC','4h','0.000016190000000','0.000016280000000','0.033598134788760','0.033784906384250','2075.239949892554','2075.239949892553796','test','test','0.0'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMBTC','4h','0.000015980000000','0.000015770000000','0.033639639587758','0.033197566727093','2105.1088603102767','2105.108860310276668','test','test','1.31'),('2019-06-06 19:59:59','2019-06-06 23:59:59','XLMBTC','4h','0.000015860000000','0.000016030000000','0.033541401174277','0.033900924389890','2114.842444784181','2114.842444784181225','test','test','0.0'),('2019-06-07 15:59:59','2019-06-08 03:59:59','XLMBTC','4h','0.000016240000000','0.000015915200000','0.033621295222191','0.032948869317747','2070.2767993960047','2070.276799396004662','test','test','2.00'),('2019-07-18 11:59:59','2019-07-18 15:59:59','XLMBTC','4h','0.000009100000000','0.000008918000000','0.033471867243426','0.032802429898557','3678.227169607229','3678.227169607228916','test','test','2.00'),('2019-07-19 23:59:59','2019-07-21 03:59:59','XLMBTC','4h','0.000008890000000','0.000008712200000','0.033323103389010','0.032656641321230','3748.3805836907136','3748.380583690713593','test','test','2.00'),('2019-07-24 15:59:59','2019-07-25 07:59:59','XLMBTC','4h','0.000008720000000','0.000008560000000','0.033175000707282','0.032566285097974','3804.4725581744906','3804.472558174490587','test','test','1.83'),('2019-07-25 19:59:59','2019-07-30 07:59:59','XLMBTC','4h','0.000008700000000','0.000008740000000','0.033039730571880','0.033191637379107','3797.6701806758365','3797.670180675836491','test','test','0.45'),('2019-07-30 11:59:59','2019-07-30 15:59:59','XLMBTC','4h','0.000008780000000','0.000008670000000','0.033073487640152','0.032659127316642','3766.912031908024','3766.912031908023891','test','test','1.25'),('2019-08-14 11:59:59','2019-08-14 15:59:59','XLMBTC','4h','0.000007000000000','0.000007010000000','0.032981407568261','0.033028523864787','4711.629652608763','4711.629652608762626','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 03:59:59','XLMBTC','4h','0.000006780000000','0.000006700000000','0.032991877856378','0.032602593161907','4866.058680881744','4866.058680881744294','test','test','1.17'),('2019-08-24 11:59:59','2019-08-26 03:59:59','XLMBTC','4h','0.000006790000000','0.000006790000000','0.032905370146496','0.032905370146496','4846.151715242383','4846.151715242383034','test','test','0.0'),('2019-09-17 15:59:59','2019-09-23 03:59:59','XLMBTC','4h','0.000006060000000','0.000006570000000','0.032905370146496','0.035674633970706','5429.929067078512','5429.929067078512162','test','test','0.0'),('2019-09-25 23:59:59','2019-10-01 19:59:59','XLMBTC','4h','0.000006800000000','0.000007070000000','0.033520762107431','0.034851733544050','4929.523839328138','4929.523839328137910','test','test','0.0'),('2019-10-04 11:59:59','2019-10-09 15:59:59','XLMBTC','4h','0.000007240000000','0.000007360000000','0.033816533537791','0.034377028568804','4670.79192510927','4670.791925109269869','test','test','0.55'),('2019-10-14 03:59:59','2019-10-20 19:59:59','XLMBTC','4h','0.000007490000000','0.000007690000000','0.033941087989127','0.034847392074284','4531.520425784691','4531.520425784690815','test','test','0.0'),('2019-10-21 23:59:59','2019-10-23 15:59:59','XLMBTC','4h','0.000007790000000','0.000007830000000','0.034142488896940','0.034317803345705','4382.861219119385','4382.861219119385169','test','test','0.89'),('2019-10-23 19:59:59','2019-10-25 15:59:59','XLMBTC','4h','0.000007870000000','0.000007712600000','0.034181447663332','0.033497818710065','4343.258915289992','4343.258915289991819','test','test','1.99'),('2019-11-01 03:59:59','2019-11-01 19:59:59','XLMBTC','4h','0.000007610000000','0.000007457800000','0.034029530118162','0.033348939515799','4471.685955080392','4471.685955080391977','test','test','2.0'),('2019-11-02 03:59:59','2019-11-04 23:59:59','XLMBTC','4h','0.000007510000000','0.000008450000000','0.033878287762081','0.038118712595151','4511.090247946886','4511.090247946885938','test','test','0.93'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XLMBTC','4h','0.000008860000000','0.000008682800000','0.034820604391652','0.034124192303819','3930.090789125533','3930.090789125532865','test','test','2.00'),('2019-11-05 15:59:59','2019-11-06 15:59:59','XLMBTC','4h','0.000008650000000','0.000008477000000','0.034665846149912','0.033972529226914','4007.6122716660766','4007.612271666076595','test','test','1.99'),('2019-11-10 03:59:59','2019-11-15 11:59:59','XLMBTC','4h','0.000008550000000','0.000008470000000','0.034511775722579','0.034188858522836','4036.4649967928276','4036.464996792827606','test','test','1.16'),('2019-11-15 15:59:59','2019-11-16 15:59:59','XLMBTC','4h','0.000008480000000','0.000008420000000','0.034440016344858','0.034196336983927','4061.3226821766516','4061.322682176651597','test','test','0.70'),('2019-11-17 07:59:59','2019-11-17 19:59:59','XLMBTC','4h','0.000008510000000','0.000008420000000','0.034385865375762','0.034022207575078','4040.6422298192983','4040.642229819298336','test','test','1.05'),('2019-11-23 11:59:59','2019-11-24 15:59:59','XLMBTC','4h','0.000008360000000','0.000008192800000','0.034305052531166','0.033618951480543','4103.4751831538015','4103.475183153801481','test','test','2.00'),('2019-11-25 07:59:59','2019-11-25 15:59:59','XLMBTC','4h','0.000008330000000','0.000008163400000','0.034152585631027','0.033469533918406','4099.95025582561','4099.950255825609929','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:58:41
