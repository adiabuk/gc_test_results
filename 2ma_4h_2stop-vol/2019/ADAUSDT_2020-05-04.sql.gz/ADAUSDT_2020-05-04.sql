-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-10 11:59:59','ADAUSDT','4h','0.041980000000000','0.045670000000000','222.222222222222200','241.755333227462785','5293.526017680376','5293.526017680375844','test','test','0.59'),('2019-01-16 15:59:59','2019-01-17 11:59:59','ADAUSDT','4h','0.044130000000000','0.044340000000000','226.562913556720133','227.641051146724919','5133.988523832317','5133.988523832316787','test','test','0.0'),('2019-01-19 11:59:59','2019-01-20 11:59:59','ADAUSDT','4h','0.045440000000000','0.044531200000000','226.802499687832295','222.266449694075646','4991.252193834337','4991.252193834337049','test','test','2.00'),('2019-02-08 15:59:59','2019-02-14 11:59:59','ADAUSDT','4h','0.039880000000000','0.040140000000000','225.794488578108599','227.266568995117382','5661.847757725893','5661.847757725892734','test','test','0.0'),('2019-02-16 15:59:59','2019-02-24 15:59:59','ADAUSDT','4h','0.041200000000000','0.042700000000000','226.121617559666106','234.354200723246208','5488.388775720051','5488.388775720050944','test','test','1.01'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ADAUSDT','4h','0.043160000000000','0.042920000000000','227.951080484906129','226.683511918725031','5281.535692421366','5281.535692421365638','test','test','0.55'),('2019-03-06 11:59:59','2019-03-06 15:59:59','ADAUSDT','4h','0.042840000000000','0.042540000000000','227.669398581310332','226.075075061833360','5314.411731589877','5314.411731589876581','test','test','0.70'),('2019-03-07 03:59:59','2019-03-07 07:59:59','ADAUSDT','4h','0.043000000000000','0.042640000000000','227.315104465871030','225.412001265691657','5286.397778276071','5286.397778276071222','test','test','0.83'),('2019-03-07 19:59:59','2019-03-07 23:59:59','ADAUSDT','4h','0.043120000000000','0.042750000000000','226.892192643608922','224.945297669626228','5261.878308061431','5261.878308061431198','test','test','0.85'),('2019-03-08 15:59:59','2019-03-08 23:59:59','ADAUSDT','4h','0.043070000000000','0.042430000000000','226.459549316057206','223.094466623643086','5257.94170689708','5257.941706897079712','test','test','1.48'),('2019-03-09 07:59:59','2019-04-09 07:59:59','ADAUSDT','4h','0.044010000000000','0.082850000000000','225.711753162187392','424.908401488007826','5128.646970283739','5128.646970283739392','test','test','0.0'),('2019-04-09 15:59:59','2019-04-11 07:59:59','ADAUSDT','4h','0.083750000000000','0.084950000000000','269.977675012369730','273.846011848367823','3223.6140299984445','3223.614029998444494','test','test','1.03'),('2019-04-14 23:59:59','2019-04-15 11:59:59','ADAUSDT','4h','0.084160000000000','0.082476800000000','270.837305420369319','265.420559311961938','3218.123876192601','3218.123876192601074','test','test','1.99'),('2019-04-15 15:59:59','2019-04-15 19:59:59','ADAUSDT','4h','0.082850000000000','0.081193000000000','269.633584062945431','264.240912381686542','3254.478986879245','3254.478986879244985','test','test','2.00'),('2019-04-18 03:59:59','2019-04-18 11:59:59','ADAUSDT','4h','0.082840000000000','0.081900000000000','268.435212578221240','265.389231170404628','3240.405752996394','3240.405752996393858','test','test','1.13'),('2019-05-11 11:59:59','2019-05-12 15:59:59','ADAUSDT','4h','0.069500000000000','0.069000000000000','267.758327820928685','265.832008915742165','3852.6378103730744','3852.637810373074444','test','test','0.71'),('2019-05-13 15:59:59','2019-05-13 23:59:59','ADAUSDT','4h','0.074770000000000','0.073274600000000','267.330256953109426','261.983651814047221','3575.3678875633195','3575.367887563319528','test','test','2.00'),('2019-05-14 03:59:59','2019-05-17 15:59:59','ADAUSDT','4h','0.077880000000000','0.077640000000000','266.142122477762257','265.321961853793766','3417.3359332018777','3417.335933201877651','test','test','0.56'),('2019-05-19 03:59:59','2019-05-20 07:59:59','ADAUSDT','4h','0.084370000000000','0.082682600000000','265.959864561324878','260.640667270098390','3152.303716502606','3152.303716502606221','test','test','2.00'),('2019-05-20 19:59:59','2019-05-22 11:59:59','ADAUSDT','4h','0.083790000000000','0.082114200000000','264.777820718830014','259.482264304453395','3160.0169557086765','3160.016955708676505','test','test','2.00'),('2019-05-24 11:59:59','2019-05-24 23:59:59','ADAUSDT','4h','0.082200000000000','0.080620000000000','263.601030404524124','258.534246608427452','3206.82518740297','3206.825187402970187','test','test','1.92'),('2019-05-26 19:59:59','2019-05-30 23:59:59','ADAUSDT','4h','0.082760000000000','0.083920000000000','262.475078449836019','266.154042816701747','3171.5210059187534','3171.521005918753417','test','test','0.0'),('2019-06-01 23:59:59','2019-06-03 23:59:59','ADAUSDT','4h','0.090470000000000','0.088660600000000','263.292626086917267','258.026773565178928','2910.275517706613','2910.275517706612845','test','test','2.00'),('2019-06-10 23:59:59','2019-06-11 03:59:59','ADAUSDT','4h','0.085080000000000','0.083640000000000','262.122436637642124','257.685949698782167','3080.893707541633','3080.893707541632921','test','test','1.69'),('2019-06-11 19:59:59','2019-06-14 15:59:59','ADAUSDT','4h','0.088420000000000','0.086651600000000','261.136550651228731','255.913819638204160','2953.3651962364706','2953.365196236470638','test','test','2.00'),('2019-06-16 07:59:59','2019-06-18 07:59:59','ADAUSDT','4h','0.092570000000000','0.090718600000000','259.975943759445556','254.776424884256642','2808.4254484114244','2808.425448411424441','test','test','2.00'),('2019-06-21 07:59:59','2019-06-21 11:59:59','ADAUSDT','4h','0.089430000000000','0.089960000000000','258.820495120514636','260.354374829939559','2894.1126592923474','2894.112659292347416','test','test','0.0'),('2019-06-22 03:59:59','2019-06-22 15:59:59','ADAUSDT','4h','0.090650000000000','0.093460000000000','259.161357278164644','267.194930515358749','2858.922860211414','2858.922860211413990','test','test','0.79'),('2019-06-22 19:59:59','2019-06-27 07:59:59','ADAUSDT','4h','0.095450000000000','0.093541000000000','260.946595775318940','255.727663859812537','2733.8564250950126','2733.856425095012582','test','test','2.00'),('2019-07-20 19:59:59','2019-07-20 23:59:59','ADAUSDT','4h','0.064740000000000','0.063445200000000','259.786833127428565','254.591096464879996','4012.771596036894','4012.771596036894152','test','test','1.99'),('2019-07-26 11:59:59','2019-07-26 15:59:59','ADAUSDT','4h','0.061410000000000','0.061230000000000','258.632224980195531','257.874143226467538','4211.565298488773','4211.565298488772896','test','test','0.29'),('2019-07-26 19:59:59','2019-07-27 11:59:59','ADAUSDT','4h','0.062500000000000','0.061250000000000','258.463762368255971','253.294487120890835','4135.4201978920955','4135.420197892095530','test','test','2.00'),('2019-07-29 15:59:59','2019-07-29 23:59:59','ADAUSDT','4h','0.061570000000000','0.060350000000000','257.315034535508232','252.216377037809366','4179.22745713023','4179.227457130229595','test','test','1.98'),('2019-07-31 03:59:59','2019-07-31 07:59:59','ADAUSDT','4h','0.060490000000000','0.060100000000000','256.181999536019532','254.530305374686293','4235.113234187792','4235.113234187791932','test','test','0.64'),('2019-08-11 19:59:59','2019-08-12 03:59:59','ADAUSDT','4h','0.055350000000000','0.054243000000000','255.814956389056647','250.698657261275514','4621.769763126587','4621.769763126587350','test','test','2.00'),('2019-08-24 19:59:59','2019-08-25 19:59:59','ADAUSDT','4h','0.050280000000000','0.049780000000000','254.678001027327468','252.145403562855222','5065.19492894446','5065.194928944460116','test','test','0.99'),('2019-09-07 23:59:59','2019-09-09 03:59:59','ADAUSDT','4h','0.045970000000000','0.045700000000000','254.115201590778071','252.622682460268834','5527.84863151573','5527.848631515729721','test','test','0.58'),('2019-09-09 11:59:59','2019-09-10 19:59:59','ADAUSDT','4h','0.046180000000000','0.045970000000000','253.783530672887110','252.629469576280201','5495.529031461393','5495.529031461393060','test','test','0.45'),('2019-09-14 19:59:59','2019-09-16 15:59:59','ADAUSDT','4h','0.046780000000000','0.045870000000000','253.527072651418933','248.595271964954833','5419.561193916608','5419.561193916608318','test','test','1.94'),('2019-09-16 23:59:59','2019-09-22 07:59:59','ADAUSDT','4h','0.047020000000000','0.049490000000000','252.431116943315828','265.691535038806933','5368.590322061162','5368.590322061161714','test','test','0.0'),('2019-10-07 15:59:59','2019-10-11 07:59:59','ADAUSDT','4h','0.041240000000000','0.040450000000000','255.377876520091633','250.485817294803752','6192.480032009981','6192.480032009981187','test','test','1.91'),('2019-10-11 15:59:59','2019-10-11 19:59:59','ADAUSDT','4h','0.040920000000000','0.040470000000000','254.290752247805386','251.494299693760610','6214.3390089884015','6214.339008988401474','test','test','1.09'),('2019-10-14 03:59:59','2019-10-14 19:59:59','ADAUSDT','4h','0.041400000000000','0.041580000000000','253.669318346906607','254.772228426675753','6127.278220939773','6127.278220939772837','test','test','0.43'),('2019-10-14 23:59:59','2019-10-15 11:59:59','ADAUSDT','4h','0.041730000000000','0.041240000000000','253.914409475744179','250.932907902700435','6084.697087844336','6084.697087844336238','test','test','1.55'),('2019-10-22 03:59:59','2019-10-22 07:59:59','ADAUSDT','4h','0.039840000000000','0.039510000000000','253.251853570623354','251.154134903999250','6356.723232194361','6356.723232194361117','test','test','0.82'),('2019-10-25 15:59:59','2019-10-31 11:59:59','ADAUSDT','4h','0.040070000000000','0.041020000000000','252.785693866929108','258.778866044957113','6308.60229266107','6308.602292661070351','test','test','0.99'),('2019-11-01 03:59:59','2019-11-08 11:59:59','ADAUSDT','4h','0.041760000000000','0.042570000000000','254.117509906490824','259.046513331401172','6085.189413469608','6085.189413469607643','test','test','1.00'),('2019-11-10 19:59:59','2019-11-11 11:59:59','ADAUSDT','4h','0.043470000000000','0.042970000000000','255.212844000915396','252.277338548868983','5871.010904092832','5871.010904092831879','test','test','1.15'),('2019-11-12 03:59:59','2019-11-14 07:59:59','ADAUSDT','4h','0.043740000000000','0.042865200000000','254.560509456016206','249.469299266895888','5819.856183265117','5819.856183265116670','test','test','2.00'),('2019-11-15 11:59:59','2019-11-15 15:59:59','ADAUSDT','4h','0.043380000000000','0.042512400000000','253.429129413989472','248.360546825709690','5842.0730616410665','5842.073061641066488','test','test','2.00'),('2019-11-15 23:59:59','2019-11-18 19:59:59','ADAUSDT','4h','0.043880000000000','0.043370000000000','252.302777727705035','249.370361669338337','5749.835408562101','5749.835408562101293','test','test','1.23'),('2019-11-27 19:59:59','2019-11-28 03:59:59','ADAUSDT','4h','0.039340000000000','0.038553200000000','251.651129714734651','246.618107120439930','6396.825869718726','6396.825869718725698','test','test','2.00'),('2019-11-29 03:59:59','2019-11-30 15:59:59','ADAUSDT','4h','0.041070000000000','0.040248600000000','250.532680249335840','245.522026644349125','6100.138306533621','6100.138306533621289','test','test','1.99'),('2019-12-07 19:59:59','2019-12-08 03:59:59','ADAUSDT','4h','0.038890000000000','0.038170000000000','249.419201670449894','244.801515241992092','6413.453372858058','6413.453372858058174','test','test','1.85'),('2019-12-08 11:59:59','2019-12-09 03:59:59','ADAUSDT','4h','0.038620000000000','0.038400000000000','248.393049130792605','246.978070601305916','6431.720588575676','6431.720588575675720','test','test','0.56'),('2019-12-26 19:59:59','2019-12-26 23:59:59','ADAUSDT','4h','0.034420000000000','0.034160000000000','248.078609457573322','246.204686201937989','7207.397137059074','7207.397137059074339','test','test','0.75');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:50:48
