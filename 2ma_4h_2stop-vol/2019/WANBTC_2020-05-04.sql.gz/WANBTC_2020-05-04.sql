-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.033333333333333','0.033011099176512','358.03795202291445','358.037952022914453','test','test','0.96'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.033261725742929','0.033223842228415','378.83514513586175','378.835145135861751','test','test','0.11'),('2019-01-17 03:59:59','2019-01-18 11:59:59','WANBTC','4h','0.000091700000000','0.000089866000000','0.033253307184148','0.032588241040465','362.6314851052102','362.631485105210174','test','test','1.99'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.033105514707774','0.033142014723990','365.00016215847603','365.000162158476030','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 19:59:59','WANBTC','4h','0.000091300000000','0.000089474000000','0.033113625822488','0.032451353306038','362.6903156899063','362.690315689906299','test','test','2.00'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000089278000000','0.032966454152166','0.032307125069123','361.8710664343164','361.871066434316390','test','test','1.99'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.032819936578157','0.032939137316334','397.3357939244148','397.335793924414816','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000081340000000','0.032846425631085','0.032189497118463','395.7400678443962','395.740067844396208','test','test','2.00'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079800000000','0.032700441517169','0.032335752578316','405.20993205909406','405.209932059094058','test','test','1.11'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.032619399530757','0.032579178322951','402.2120780611234','402.212078061123407','test','test','0.12'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.032610461484578','0.032410642480383','399.63800838943627','399.638008389436266','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.032566057261424','0.032443781702245','407.58519726437487','407.585197264374870','test','test','0.37'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000077812000000','0.032538884914939','0.031888107216640','409.8096336894122','409.809633689412181','test','test','1.99'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.032394267648651','0.032394267648651','414.2489469136913','414.248946913691327','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.032394267648651','0.032518542332725','414.2489469136913','414.248946913691327','test','test','0.0'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000081400000000','0.000101100000000','0.032421884245112','0.040268458196325','398.3032462544417','398.303246254441717','test','test','1.35'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000101822000000','0.034165567345381','0.033482255998473','328.83125452724835','328.831254527248348','test','test','2.00'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000100600000000','0.034013720379402','0.033383222147979','331.8411744331859','331.841174433185927','test','test','1.85'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.033873609661308','0.033607673569757','332.4201144387395','332.420114438739517','test','test','0.78'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000102410000000','0.033814512752074','0.033138222497033','323.5838540868325','323.583854086832503','test','test','2.00'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.033664226028732','0.034260639481997','331.34080736940507','331.340807369405070','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000100646000000','0.033796762351679','0.033120827104645','329.082398750529','329.082398750529023','test','test','2.00'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.033646554519005','0.033317331872048','329.22264695699715','329.222646956997153','test','test','0.97'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000101600000000','0.033573393930792','0.032957070757183','324.3806176888159','324.380617688815903','test','test','1.83'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.033436433225546','0.033436433225546','323.057325850686','323.057325850686027','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANBTC','4h','0.000085300000000','0.000084600000000','0.033436433225546','0.033162042800483','391.98632151871044','391.986321518710440','test','test','1.64'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.033375457575532','0.033249985930511','627.358225103985','627.358225103984978','test','test','0.37'),('2019-05-18 03:59:59','2019-05-18 11:59:59','WANBTC','4h','0.000054600000000','0.000053508000000','0.033347574987750','0.032680623487995','610.7614466620797','610.761446662079720','test','test','2.00'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000053410000000','0.033199363543360','0.032535376272493','609.162633823111','609.162633823111037','test','test','1.99'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000051940000000','0.033051810816500','0.032390774600170','623.6190720094381','623.619072009438128','test','test','2.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000052528000000','0.032904913879538','0.032246815601947','613.8976470063059','613.897647006305874','test','test','1.99'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000052234000000','0.032758669817851','0.032103496421494','614.6091898283512','614.609189828351191','test','test','1.99'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.032613075729772','0.032551887970429','611.877593429114','611.877593429113972','test','test','0.18'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000050274000000','0.032599478449918','0.031947488880920','635.4674161777344','635.467416177734435','test','test','2.0'),('2019-06-02 11:59:59','2019-06-04 03:59:59','WANBTC','4h','0.000054600000000','0.000053508000000','0.032454591879029','0.031805500041448','594.4064446708669','594.406444670866904','test','test','2.00'),('2019-06-07 03:59:59','2019-06-11 19:59:59','WANBTC','4h','0.000057000000000','0.000056600000000','0.032310349248456','0.032083609955484','566.8482324290487','566.848232429048721','test','test','1.92'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.032259962738906','0.032372562957890','563.0010949198333','563.001094919833349','test','test','0.34'),('2019-06-13 11:59:59','2019-06-13 15:59:59','WANBTC','4h','0.000058800000000','0.000057624000000','0.032284985009792','0.031639285309596','549.0643709148262','549.064370914826213','test','test','2.00'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000059094000000','0.032141496187526','0.031498666263775','533.0264707715754','533.026470771575418','test','test','2.00'),('2019-07-07 07:59:59','2019-07-07 11:59:59','WANBTC','4h','0.000034300000000','0.000033614000000','0.031998645093359','0.031358672191492','932.9051047626563','932.905104762656265','test','test','1.99'),('2019-07-07 23:59:59','2019-07-08 03:59:59','WANBTC','4h','0.000034100000000','0.000033418000000','0.031856428892944','0.031219300315085','934.2061258927924','934.206125892792443','test','test','1.99'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025600000000','0.031714844764531','0.031347491350270','1224.511380869927','1224.511380869927052','test','test','1.15'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.031633210672473','0.034530909360028','1207.3744531478287','1207.374453147828717','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.032277143714152','0.032954286589274','1128.5714585367832','1128.571458536783211','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.032427619908624','0.051616440863727','1487.5055003955756','1487.505500395575609','test','test','0.0'),('2019-08-30 15:59:59','2019-08-30 19:59:59','WANBTC','4h','0.000039580000000','0.000038788400000','0.036691802343091','0.035957966296229','927.0288616243276','927.028861624327646','test','test','2.00'),('2019-08-30 23:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000038200000000','0.000037436000000','0.036528727666010','0.035798153112690','956.2494153405873','956.249415340587348','test','test','2.00'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000039846800000','0.036366377765273','0.035639050209968','894.4018141975569','894.401814197556860','test','test','2.00'),('2019-09-01 19:59:59','2019-09-02 03:59:59','WANBTC','4h','0.000041540000000','0.000040709200000','0.036204749419649','0.035480654431256','871.5635392308458','871.563539230845777','test','test','1.99'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000039033400000','0.036043839422229','0.035322962633784','904.9419890090047','904.941989009004715','test','test','1.99'),('2019-09-22 15:59:59','2019-09-22 19:59:59','WANBTC','4h','0.000026540000000','0.000026310000000','0.035883644580352','0.035572671021442','1352.0589517841747','1352.058951784174724','test','test','0.86'),('2019-09-23 15:59:59','2019-09-23 19:59:59','WANBTC','4h','0.000026040000000','0.000025680000000','0.035814539345039','0.035319407464693','1375.3663342948794','1375.366334294879380','test','test','1.38'),('2019-10-02 11:59:59','2019-10-02 15:59:59','WANBTC','4h','0.000024120000000','0.000024000000000','0.035704510038295','0.035526875659995','1480.2864858331304','1480.286485833130428','test','test','0.49'),('2019-10-02 23:59:59','2019-10-06 23:59:59','WANBTC','4h','0.000024870000000','0.000024372600000','0.035665035732006','0.034951735017366','1434.0585336552563','1434.058533655256269','test','test','1.99'),('2019-10-07 11:59:59','2019-10-08 07:59:59','WANBTC','4h','0.000024810000000','0.000024380000000','0.035506524462086','0.034891135283581','1431.13762442911','1431.137624429110019','test','test','1.73'),('2019-10-08 11:59:59','2019-10-11 03:59:59','WANBTC','4h','0.000024910000000','0.000024560000000','0.035369771311307','0.034872805435797','1419.9025014575402','1419.902501457540211','test','test','1.40'),('2019-10-14 15:59:59','2019-10-14 23:59:59','WANBTC','4h','0.000025070000000','0.000025630000000','0.035259334450083','0.036046938251122','1406.4353589981206','1406.435358998120591','test','test','0.0'),('2019-10-15 11:59:59','2019-10-15 15:59:59','WANBTC','4h','0.000025510000000','0.000024999800000','0.035434357516980','0.034725670366640','1389.037926969049','1389.037926969049067','test','test','2.00'),('2019-10-21 19:59:59','2019-10-21 23:59:59','WANBTC','4h','0.000024610000000','0.000024540000000','0.035276871483572','0.035176530930795','1433.4364682475234','1433.436468247523408','test','test','0.28'),('2019-10-22 03:59:59','2019-10-22 11:59:59','WANBTC','4h','0.000024590000000','0.000024260000000','0.035254573582954','0.034781454051341','1433.6955503438162','1433.695550343816194','test','test','1.34'),('2019-10-27 19:59:59','2019-10-27 23:59:59','WANBTC','4h','0.000024530000000','0.000024039400000','0.035149435909263','0.034446447191078','1432.9162620979478','1432.916262097947765','test','test','2.00'),('2019-10-28 03:59:59','2019-10-28 07:59:59','WANBTC','4h','0.000026230000000','0.000025705400000','0.034993216194110','0.034293351870228','1334.091353187588','1334.091353187588084','test','test','2.00'),('2019-10-31 15:59:59','2019-11-02 15:59:59','WANBTC','4h','0.000024780000000','0.000024284400000','0.034837690788803','0.034140936973027','1405.8793700082053','1405.879370008205342','test','test','1.99'),('2019-11-04 15:59:59','2019-11-04 23:59:59','WANBTC','4h','0.000024440000000','0.000024360000000','0.034682856607520','0.034569328435319','1419.1021525171757','1419.102152517175682','test','test','0.32'),('2019-11-05 19:59:59','2019-11-05 23:59:59','WANBTC','4h','0.000026940000000','0.000026401200000','0.034657628124808','0.033964475562312','1286.4746891168688','1286.474689116868831','test','test','1.99'),('2019-11-06 11:59:59','2019-11-06 23:59:59','WANBTC','4h','0.000026380000000','0.000025852400000','0.034503594222032','0.033813522337591','1307.9451941634402','1307.945194163440192','test','test','2.00'),('2019-11-11 19:59:59','2019-11-15 15:59:59','WANBTC','4h','0.000025370000000','0.000025120000000','0.034350244914378','0.034011752158028','1353.9710253992116','1353.971025399211612','test','test','0.98'),('2019-11-16 11:59:59','2019-11-21 11:59:59','WANBTC','4h','0.000026110000000','0.000026990000000','0.034275024301856','0.035430214703451','1312.7163654483252','1312.716365448325178','test','test','0.0'),('2019-11-23 15:59:59','2019-11-24 15:59:59','WANBTC','4h','0.000028040000000','0.000027479200000','0.034531733279988','0.033841098614388','1231.5168787442226','1231.516878744222595','test','test','1.99'),('2019-11-26 19:59:59','2019-11-27 03:59:59','WANBTC','4h','0.000028880000000','0.000028302400000','0.034378258909855','0.033690693731658','1190.382926241505','1190.382926241504947','test','test','1.99'),('2019-11-27 15:59:59','2019-11-27 19:59:59','WANBTC','4h','0.000029370000000','0.000028782600000','0.034225466648033','0.033540957315072','1165.3206213153937','1165.320621315393737','test','test','2.00'),('2019-12-16 11:59:59','2019-12-16 19:59:59','WANBTC','4h','0.000025700000000','0.000025186000000','0.034073353462931','0.033391886393672','1325.8114187910764','1325.811418791076449','test','test','1.99'),('2019-12-16 23:59:59','2019-12-20 23:59:59','WANBTC','4h','0.000025540000000','0.000026260000000','0.033921916336429','0.034878211550299','1328.1877970410599','1328.187797041059866','test','test','0.0'),('2019-12-31 03:59:59','2019-12-31 15:59:59','WANBTC','4h','0.000025200000000','0.000024696000000','0.034134426383955','0.033451737856276','1354.5407295220368','1354.540729522036827','test','test','2.00'),('2020-01-01 15:59:59','2020-01-01 15:59:59','WANBTC','4h','0.000024690000000','0.000024690000000','0.033982717822249','0.033982717822249','1376.3757724685659','1376.375772468565856','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:56:55
