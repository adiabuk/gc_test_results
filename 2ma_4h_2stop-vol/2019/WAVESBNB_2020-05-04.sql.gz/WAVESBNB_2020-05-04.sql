-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.467166000000000','3.111111111111111','3.048888888888889','6.526350138684941','6.526350138684941','test','test','1.99'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','3.097283950617284','3.099928376615677','6.611064995981396','6.611064995981396','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','3.097871600839149','3.055157316088153','7.239709279829748','7.239709279829748','test','test','1.37'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.442666000000000','3.088379537561150','3.026611946809927','6.8372360804984496','6.837236080498450','test','test','1.99'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','3.074653406283101','3.018840157049986','16.415661539151632','16.415661539151632','test','test','1.81'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','3.062250462009075','3.011183605540839','17.609260851116012','17.609260851116012','test','test','1.66'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.160132000000000','3.050902271682800','2.989884226249144','18.671372531718482','18.671372531718482','test','test','1.99'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.160622000000000','3.037342706030877','2.976595851910259','18.531682160041957','18.531682160041957','test','test','2.00'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.161602000000000','3.023843405115183','2.963366537012879','18.337437265707603','18.337437265707603','test','test','1.99'),('2019-05-07 15:59:59','2019-05-07 23:59:59','WAVESBNB','4h','0.110200000000000','0.107996000000000','3.010404101092449','2.950196019070600','27.31764157071188','27.317641570711881','test','test','1.99'),('2019-05-08 11:59:59','2019-05-08 15:59:59','WAVESBNB','4h','0.106300000000000','0.104174000000000','2.997024527309816','2.937084036763620','28.19402189378943','28.194021893789429','test','test','2.00'),('2019-05-09 19:59:59','2019-05-11 15:59:59','WAVESBNB','4h','0.116100000000000','0.113778000000000','2.983704418299550','2.924030329933559','25.699435127472444','25.699435127472444','test','test','2.00'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WAVESBNB','4h','0.105000000000000','0.102900000000000','2.970443509773775','2.911034639578300','28.289938188321663','28.289938188321663','test','test','2.00'),('2019-07-06 15:59:59','2019-07-06 19:59:59','WAVESBNB','4h','0.061900000000000','0.060662000000000','2.957241538619225','2.898096707846840','47.77449981614257','47.774499816142573','test','test','2.00'),('2019-07-07 03:59:59','2019-07-07 23:59:59','WAVESBNB','4h','0.064400000000000','0.063112000000000','2.944098242892028','2.885216278034187','45.715811225031494','45.715811225031494','test','test','1.99'),('2019-07-16 15:59:59','2019-07-17 03:59:59','WAVESBNB','4h','0.058390000000000','0.057222200000000','2.931013361812508','2.872393094576258','50.197180370140565','50.197180370140565','test','test','2.00'),('2019-07-29 11:59:59','2019-07-30 11:59:59','WAVESBNB','4h','0.051870000000000','0.050832600000000','2.917986635760008','2.859626903044808','56.25576702834023','56.255767028340230','test','test','2.00'),('2019-07-30 19:59:59','2019-07-31 03:59:59','WAVESBNB','4h','0.051110000000000','0.050087800000000','2.905017806267741','2.846917450142386','56.83854052568462','56.838540525684621','test','test','2.00'),('2019-07-31 07:59:59','2019-07-31 15:59:59','WAVESBNB','4h','0.050420000000000','0.050140000000000','2.892106616017662','2.876045730407092','57.36030575203613','57.360305752036133','test','test','0.55'),('2019-08-05 03:59:59','2019-08-05 11:59:59','WAVESBNB','4h','0.050360000000000','0.049352800000000','2.888537530326424','2.830766779719895','57.35777462919826','57.357774629198261','test','test','1.99'),('2019-08-05 19:59:59','2019-08-06 11:59:59','WAVESBNB','4h','0.050960000000000','0.049940800000000','2.875699585747196','2.818185594032252','56.43052562298265','56.430525622982650','test','test','1.99'),('2019-08-07 07:59:59','2019-08-07 11:59:59','WAVESBNB','4h','0.050050000000000','0.049049000000000','2.862918698699431','2.805660324725442','57.20117280118743','57.201172801187433','test','test','2.00'),('2019-08-18 11:59:59','2019-08-18 23:59:59','WAVESBNB','4h','0.045520000000000','0.045140000000000','2.850194615594100','2.826401251052673','62.614117214281634','62.614117214281634','test','test','1.42'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESBNB','4h','0.045050000000000','0.044250000000000','2.844907201251560','2.794387206556749','63.1499933685141','63.149993368514103','test','test','1.77'),('2019-08-21 15:59:59','2019-08-22 03:59:59','WAVESBNB','4h','0.045170000000000','0.045070000000000','2.833680535763825','2.827407167298552','62.73368465273024','62.733684652730240','test','test','0.22'),('2019-08-22 15:59:59','2019-08-22 19:59:59','WAVESBNB','4h','0.047710000000000','0.046755800000000','2.832286453882653','2.775640724805000','59.36462908997385','59.364629089973853','test','test','2.00'),('2019-08-22 23:59:59','2019-08-23 03:59:59','WAVESBNB','4h','0.047550000000000','0.046599000000000','2.819698514087619','2.763304543805866','59.299653293115014','59.299653293115014','test','test','2.00'),('2019-08-23 11:59:59','2019-08-28 03:59:59','WAVESBNB','4h','0.047670000000000','0.048450000000000','2.807166520691673','2.853098760803683','58.88748732308944','58.887487323089438','test','test','0.0'),('2019-08-28 11:59:59','2019-08-28 19:59:59','WAVESBNB','4h','0.048490000000000','0.048560000000000','2.817373685161009','2.821440836284154','58.10215890206247','58.102158902062470','test','test','0.0'),('2019-08-29 07:59:59','2019-08-29 15:59:59','WAVESBNB','4h','0.051550000000000','0.050519000000000','2.818277496521708','2.761911946591273','54.670756479567565','54.670756479567565','test','test','2.00'),('2019-08-30 19:59:59','2019-09-02 15:59:59','WAVESBNB','4h','0.050430000000000','0.050490000000000','2.805751818759390','2.809090012475939','55.63656194248244','55.636561942482437','test','test','0.19'),('2019-09-03 11:59:59','2019-09-03 15:59:59','WAVESBNB','4h','0.050220000000000','0.050840000000000','2.806493639585289','2.841141709209799','55.88398326533829','55.883983265338287','test','test','0.0'),('2019-09-03 23:59:59','2019-09-05 19:59:59','WAVESBNB','4h','0.051320000000000','0.050293600000000','2.814193210612958','2.757909346400699','54.83618882722053','54.836188827220532','test','test','2.00'),('2019-09-11 19:59:59','2019-09-11 23:59:59','WAVESBNB','4h','0.049850000000000','0.049180000000000','2.801685685232456','2.764030130385801','56.20232066664907','56.202320666649072','test','test','1.34'),('2019-09-12 07:59:59','2019-09-12 11:59:59','WAVESBNB','4h','0.050970000000000','0.050630000000000','2.793317784155422','2.774684704959565','54.80317410546246','54.803174105462460','test','test','0.66'),('2019-09-13 07:59:59','2019-09-13 11:59:59','WAVESBNB','4h','0.049370000000000','0.048570000000000','2.789177099889675','2.743980792822393','56.49538383410321','56.495383834103208','test','test','1.62'),('2019-09-13 19:59:59','2019-09-14 15:59:59','WAVESBNB','4h','0.049180000000000','0.048440000000000','2.779133476096945','2.737316502280114','56.509424076798396','56.509424076798396','test','test','1.50'),('2019-09-15 15:59:59','2019-09-18 11:59:59','WAVESBNB','4h','0.050330000000000','0.052880000000000','2.769840815248761','2.910176481429654','55.033594580742324','55.033594580742324','test','test','0.0'),('2019-09-22 23:59:59','2019-09-23 19:59:59','WAVESBNB','4h','0.054190000000000','0.053106200000000','2.801026518844516','2.745005988467625','51.688992781777365','51.688992781777365','test','test','2.00'),('2019-09-24 03:59:59','2019-09-24 11:59:59','WAVESBNB','4h','0.053800000000000','0.052724000000000','2.788577512094095','2.732805961852213','51.832295763830764','51.832295763830764','test','test','2.00'),('2019-09-28 07:59:59','2019-10-01 07:59:59','WAVESBNB','4h','0.054000000000000','0.052920000000000','2.776183834262566','2.720660157577315','51.41081174560307','51.410811745603070','test','test','1.99'),('2019-10-03 03:59:59','2019-10-03 07:59:59','WAVESBNB','4h','0.055610000000000','0.054497800000000','2.763845239443621','2.708568334654748','49.70050781232909','49.700507812329093','test','test','2.00'),('2019-10-04 07:59:59','2019-10-04 11:59:59','WAVESBNB','4h','0.056570000000000','0.055438600000000','2.751561482823871','2.696530253167394','48.63994136156745','48.639941361567452','test','test','1.99'),('2019-10-04 15:59:59','2019-10-09 07:59:59','WAVESBNB','4h','0.056980000000000','0.055840400000000','2.739332320677988','2.684545674264428','48.07533030322899','48.075330303228988','test','test','2.00'),('2019-11-17 07:59:59','2019-11-17 11:59:59','WAVESBNB','4h','0.038420000000000','0.038500000000000','2.727157510363863','2.732836130895593','70.98275664663879','70.982756646638791','test','test','0.0'),('2019-11-18 11:59:59','2019-11-18 19:59:59','WAVESBNB','4h','0.039490000000000','0.038700200000000','2.728419426037581','2.673851037516829','69.09140101386632','69.091401013866317','test','test','2.00'),('2019-11-19 11:59:59','2019-11-20 07:59:59','WAVESBNB','4h','0.038520000000000','0.038490000000000','2.716293117477413','2.714177624395266','70.51643607158394','70.516436071583939','test','test','0.07'),('2019-11-20 19:59:59','2019-11-21 15:59:59','WAVESBNB','4h','0.039370000000000','0.038950000000000','2.715823007903603','2.686850550110372','68.98204236483625','68.982042364836246','test','test','1.06'),('2019-11-22 03:59:59','2019-11-23 19:59:59','WAVESBNB','4h','0.039540000000000','0.038980000000000','2.709384683949552','2.671012012654364','68.52262731283642','68.522627312836420','test','test','1.41'),('2019-11-28 15:59:59','2019-11-29 11:59:59','WAVESBNB','4h','0.039080000000000','0.038630000000000','2.700857423661732','2.669757478916395','69.11098832297166','69.110988322971664','test','test','1.15'),('2019-12-02 15:59:59','2019-12-02 19:59:59','WAVESBNB','4h','0.038960000000000','0.038840000000000','2.693946324829435','2.685648748880268','69.14646624305531','69.146466243055315','test','test','0.30'),('2019-12-02 23:59:59','2019-12-03 07:59:59','WAVESBNB','4h','0.038880000000000','0.038750000000000','2.692102419062953','2.683101047805798','69.24131736273029','69.241317362730285','test','test','0.33'),('2019-12-03 11:59:59','2019-12-03 15:59:59','WAVESBNB','4h','0.039180000000000','0.038396400000000','2.690102114339142','2.636300072052359','68.6600845926274','68.660084592627399','test','test','2.00'),('2019-12-11 11:59:59','2019-12-15 03:59:59','WAVESBNB','4h','0.037890000000000','0.047550000000000','2.678146104942078','3.360935531538555','70.68213525843437','70.682135258434371','test','test','0.0'),('2019-12-15 07:59:59','2019-12-15 15:59:59','WAVESBNB','4h','0.049370000000000','0.048382600000000','2.829877088630184','2.773279546857580','57.31977088576432','57.319770885764321','test','test','1.99'),('2019-12-16 11:59:59','2020-01-01 15:59:59','WAVESBNB','4h','0.052730000000000','0.075800000000000','2.817299857125162','4.049901937608331','53.42878545657428','53.428785456574282','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:27:18
