-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.297777777777778','1.344373086107599','328.13597415367326','328.135974153673260','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.308132290739960','1.321438552840003','316.8157642867426','316.815764286742592','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.311089237873303','1.533131017573951','306.6875410229948','306.687541022994822','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005179000000000','0.005075420000000','1.360431855584558','1.333223218472867','262.68234322930266','262.682343229302660','test','test','1.99'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.354385491781960','1.345737510269037','278.9671455781586','278.967145578158579','test','test','0.63'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004472720000000','1.352463718112421','1.325414443750173','296.33297942866375','296.332979428663748','test','test','2.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.346452768254144','1.453281218658484','295.9236853305811','295.923685330581122','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.370192423899553','1.373915772877541','286.41145984522433','286.411459845224329','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.371019834783550','2.041820430061251','277.5343795108402','277.534379510840211','test','test','0.16'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSETH','4h','0.007801000000000','0.007644980000000','1.520086633734151','1.489684901059468','194.85791997617625','194.857919976176248','test','test','1.99'),('2019-03-28 11:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007755000000000','0.008025000000000','1.513330693139777','1.566019189225881','195.14257809668302','195.142578096683025','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','GXSETH','4h','0.008023000000000','0.007862540000000','1.525039247825578','1.494538462869067','190.08341615674655','190.083416156746551','test','test','1.99'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007754740000000','1.518261295613019','1.487896069700759','191.8692399359307','191.869239935930693','test','test','2.00'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.511513467632517','1.514108169214350','199.59242937178365','199.592429371783652','test','test','1.79'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007708680000000','1.512090067984036','1.481848266624355','192.23112992423543','192.231129924235432','test','test','1.99'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007666540000000','1.505369667681885','1.475262274328247','192.42869329948672','192.428693299486724','test','test','1.99'),('2019-05-31 11:59:59','2019-05-31 15:59:59','GXSETH','4h','0.004618000000000','0.004525640000000','1.498679135825521','1.468705553109011','324.52991247845836','324.529912478458357','test','test','1.99'),('2019-06-04 11:59:59','2019-06-20 23:59:59','GXSETH','4h','0.004464000000000','0.008338000000000','1.492018339666296','2.786838914905371','334.2334990291882','334.233499029188181','test','test','0.0'),('2019-06-23 07:59:59','2019-06-23 15:59:59','GXSETH','4h','0.008574000000000','0.008404000000000','1.779756245274980','1.744468332784107','207.57595582866568','207.575955828665684','test','test','1.98'),('2019-06-23 19:59:59','2019-06-23 23:59:59','GXSETH','4h','0.008451000000000','0.008684000000000','1.771914486943674','1.820767412687122','209.66920919934617','209.669209199346170','test','test','0.0'),('2019-06-24 03:59:59','2019-06-24 07:59:59','GXSETH','4h','0.008826000000000','0.008649480000000','1.782770692664441','1.747115278811152','201.99078774806716','201.990787748067163','test','test','1.99'),('2019-07-15 23:59:59','2019-07-16 03:59:59','GXSETH','4h','0.006579000000000','0.006508000000000','1.774847267363710','1.755693268886309','269.7746264422724','269.774626442272393','test','test','1.07'),('2019-07-17 03:59:59','2019-07-17 11:59:59','GXSETH','4h','0.006630000000000','0.006497400000000','1.770590823257621','1.735179006792469','267.05743940537263','267.057439405372634','test','test','2.00'),('2019-07-18 11:59:59','2019-07-18 15:59:59','GXSETH','4h','0.006650000000000','0.006566000000000','1.762721530709809','1.740455574532422','265.07090687365553','265.070906873655531','test','test','1.26'),('2019-07-20 19:59:59','2019-07-23 07:59:59','GXSETH','4h','0.007088000000000','0.006946240000000','1.757773540448167','1.722618069639203','247.99288098873694','247.992880988736943','test','test','2.00'),('2019-07-24 03:59:59','2019-07-24 23:59:59','GXSETH','4h','0.006780000000000','0.006805000000000','1.749961213601731','1.756413872943920','258.10637368757097','258.106373687570965','test','test','0.0'),('2019-07-25 03:59:59','2019-07-27 03:59:59','GXSETH','4h','0.006884000000000','0.006940000000000','1.751395137899995','1.765642396430268','254.41533089773316','254.415330897733156','test','test','0.0'),('2019-07-30 03:59:59','2019-07-30 15:59:59','GXSETH','4h','0.007134000000000','0.006991320000000','1.754561195351167','1.719469971444144','245.94353733545935','245.943537335459354','test','test','2.00'),('2019-07-31 07:59:59','2019-08-06 03:59:59','GXSETH','4h','0.007900000000000','0.007957000000000','1.746763145594051','1.759366373353400','221.10925893595578','221.109258935955779','test','test','1.53'),('2019-09-27 19:59:59','2019-09-30 07:59:59','GXSETH','4h','0.002496000000000','0.002446080000000','1.749563862873906','1.714572585616428','700.9470604462765','700.947060446276510','test','test','2.00'),('2019-10-03 11:59:59','2019-10-04 03:59:59','GXSETH','4h','0.002456000000000','0.002525000000000','1.741788023483355','1.790722621862977','709.1970779655356','709.197077965535641','test','test','0.0'),('2019-10-09 03:59:59','2019-10-09 15:59:59','GXSETH','4h','0.002489000000000','0.002439220000000','1.752662378678827','1.717609131105250','704.16326985891','704.163269858909985','test','test','2.00'),('2019-10-10 03:59:59','2019-10-10 07:59:59','GXSETH','4h','0.002552000000000','0.002500960000000','1.744872768106921','1.709975312744783','683.7275737096085','683.727573709608464','test','test','2.00'),('2019-10-10 19:59:59','2019-10-11 03:59:59','GXSETH','4h','0.002551000000000','0.002499980000000','1.737117778026446','1.702375422465917','680.9556166312998','680.955616631299790','test','test','2.00'),('2019-10-14 23:59:59','2019-10-15 07:59:59','GXSETH','4h','0.002511000000000','0.002495000000000','1.729397254568551','1.718377598625462','688.7284964430708','688.728496443070753','test','test','0.63'),('2019-10-15 11:59:59','2019-10-16 07:59:59','GXSETH','4h','0.003024000000000','0.002963520000000','1.726948442136753','1.692409473294018','571.0808340399316','571.080834039931574','test','test','1.99'),('2019-10-22 15:59:59','2019-10-22 19:59:59','GXSETH','4h','0.002735000000000','0.002680300000000','1.719273115727256','1.684887653412711','628.6190551105142','628.619055110514182','test','test','1.99'),('2019-10-27 15:59:59','2019-10-28 19:59:59','GXSETH','4h','0.003022000000000','0.002961560000000','1.711631901879580','1.677399263841988','566.3904374187888','566.390437418788792','test','test','2.00'),('2019-10-31 15:59:59','2019-10-31 19:59:59','GXSETH','4h','0.002755000000000','0.002716000000000','1.704024648982337','1.679902339976779','618.5207437322457','618.520743732245705','test','test','1.41'),('2019-11-02 03:59:59','2019-11-02 07:59:59','GXSETH','4h','0.003074000000000','0.003012520000000','1.698664135869991','1.664690853152591','552.5908054228988','552.590805422898825','test','test','2.00'),('2019-11-02 11:59:59','2019-11-03 11:59:59','GXSETH','4h','0.002939000000000','0.002880220000000','1.691114517488346','1.657292227138579','575.4047354502709','575.404735450270891','test','test','2.00'),('2019-11-03 15:59:59','2019-11-04 15:59:59','GXSETH','4h','0.002883000000000','0.002831000000000','1.683598452966176','1.653231779516908','583.97448940901','583.974489409009948','test','test','1.80'),('2019-11-05 23:59:59','2019-11-11 11:59:59','GXSETH','4h','0.002941000000000','0.002976000000000','1.676850303310783','1.696806019263138','570.1633129244416','570.163312924441584','test','test','1.53'),('2019-11-12 03:59:59','2019-11-18 03:59:59','GXSETH','4h','0.003008000000000','0.003151000000000','1.681284906855751','1.761213012467577','558.9378014813002','558.937801481300198','test','test','1.06'),('2019-11-22 11:59:59','2019-11-22 15:59:59','GXSETH','4h','0.003090000000000','0.003074000000000','1.699046708102823','1.690249055245333','549.8533035931467','549.853303593146734','test','test','0.51'),('2019-11-28 19:59:59','2019-11-29 07:59:59','GXSETH','4h','0.003122000000000','0.003059560000000','1.697091674134492','1.663149840651802','543.5911832589661','543.591183258966112','test','test','1.99'),('2019-11-29 23:59:59','2019-11-30 11:59:59','GXSETH','4h','0.003153000000000','0.003089940000000','1.689549044471672','1.655758063582239','535.8544384623127','535.854438462312714','test','test','2.00'),('2019-12-03 07:59:59','2019-12-04 03:59:59','GXSETH','4h','0.003061000000000','0.003043000000000','1.682039937607354','1.672148817425410','549.506676774699','549.506676774699031','test','test','0.58'),('2019-12-04 15:59:59','2019-12-04 19:59:59','GXSETH','4h','0.003024000000000','0.003020000000000','1.679841910900255','1.677619897790598','555.5032774141055','555.503277414105469','test','test','0.13'),('2019-12-04 23:59:59','2019-12-05 11:59:59','GXSETH','4h','0.003026000000000','0.003060000000000','1.679348130209220','1.698217210323930','554.9729445503041','554.972944550304078','test','test','0.0'),('2019-12-05 23:59:59','2019-12-06 07:59:59','GXSETH','4h','0.003044000000000','0.003020000000000','1.683541259123600','1.670267609248775','553.0687447843627','553.068744784362707','test','test','0.78'),('2019-12-16 15:59:59','2019-12-17 07:59:59','GXSETH','4h','0.002992000000000','0.002957000000000','1.680591559151417','1.660932232757600','561.6950398233345','561.695039823334469','test','test','1.16'),('2019-12-17 15:59:59','2019-12-17 19:59:59','GXSETH','4h','0.002975000000000','0.002995000000000','1.676222819952791','1.687491544792810','563.436242000938','563.436242000938023','test','test','0.0'),('2019-12-17 23:59:59','2019-12-22 19:59:59','GXSETH','4h','0.003056000000000','0.003066000000000','1.678726981028350','1.684220197589307','549.3216560956644','549.321656095664366','test','test','0.65'),('2019-12-23 23:59:59','2019-12-24 11:59:59','GXSETH','4h','0.003080000000000','0.003035000000000','1.679947695819674','1.655403005458672','545.4375635778164','545.437563577816377','test','test','1.46'),('2019-12-24 15:59:59','2019-12-24 23:59:59','GXSETH','4h','0.003088000000000','0.003039000000000','1.674493320183896','1.647922668406367','542.2581995414172','542.258199541417184','test','test','1.58'),('2019-12-28 03:59:59','2019-12-28 15:59:59','GXSETH','4h','0.003103000000000','0.003062000000000','1.668588730900001','1.646541635196843','537.734041540445','537.734041540444991','test','test','1.32'),('2019-12-29 07:59:59','2019-12-29 11:59:59','GXSETH','4h','0.003084000000000','0.003026000000000','1.663689376299299','1.632400795292373','539.4582932228597','539.458293222859652','test','test','1.88');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:43:14
