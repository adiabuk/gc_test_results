-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-02 07:59:59','ENJBTC','4h','0.000010600000000','0.000010490000000','0.033333333333333','0.032987421383647','3144.6540880503144','3144.654088050314385','test','test','1.03'),('2019-01-12 07:59:59','2019-01-12 15:59:59','ENJBTC','4h','0.000010340000000','0.000010133200000','0.033256464011181','0.032591334730957','3216.2924575610145','3216.292457561014544','test','test','1.99'),('2019-01-22 15:59:59','2019-01-24 03:59:59','ENJBTC','4h','0.000009650000000','0.000009520000000','0.033108657504464','0.032662634139119','3430.948964193206','3430.948964193205938','test','test','1.34'),('2019-01-29 23:59:59','2019-01-30 03:59:59','ENJBTC','4h','0.000009350000000','0.000009163000000','0.033009541201054','0.032349350377033','3530.432214016518','3530.432214016518174','test','test','2.00'),('2019-02-10 23:59:59','2019-02-11 03:59:59','ENJBTC','4h','0.000008240000000','0.000008090000000','0.032862832129050','0.032264600961652','3988.207782651671','3988.207782651671096','test','test','1.82'),('2019-02-11 07:59:59','2019-02-17 03:59:59','ENJBTC','4h','0.000008340000000','0.000008460000000','0.032729891869628','0.033200825565594','3924.4474663822543','3924.447466382254333','test','test','0.0'),('2019-02-17 11:59:59','2019-03-16 07:59:59','ENJBTC','4h','0.000008580000000','0.000041040000000','0.032834543802065','0.157054740983304','3826.86990700057','3826.869907000570038','test','test','0.0'),('2019-03-18 11:59:59','2019-03-19 03:59:59','ENJBTC','4h','0.000050800000000','0.000049784000000','0.060439032064562','0.059230251423271','1189.744725680363','1189.744725680362990','test','test','1.99'),('2019-03-19 19:59:59','2019-03-20 03:59:59','ENJBTC','4h','0.000048000000000','0.000047040000000','0.060170414144276','0.058967005861390','1253.5502946724073','1253.550294672407290','test','test','1.99'),('2019-03-21 19:59:59','2019-03-22 15:59:59','ENJBTC','4h','0.000047960000000','0.000047000800000','0.059902990081412','0.058704930279784','1249.0198098709755','1249.019809870975450','test','test','2.00'),('2019-04-13 19:59:59','2019-04-14 15:59:59','ENJBTC','4h','0.000033070000000','0.000032408600000','0.059636754569939','0.058444019478540','1803.3490949482646','1803.349094948264565','test','test','2.00'),('2019-04-17 11:59:59','2019-04-23 03:59:59','ENJBTC','4h','0.000031460000000','0.000032990000000','0.059371702327406','0.062259137310271','1887.2124071012713','1887.212407101271310','test','test','0.0'),('2019-05-17 23:59:59','2019-05-18 03:59:59','ENJBTC','4h','0.000021930000000','0.000021491400000','0.060013354545820','0.058813087454904','2736.5870745928155','2736.587074592815497','test','test','1.99'),('2019-05-21 23:59:59','2019-05-22 03:59:59','ENJBTC','4h','0.000021480000000','0.000022590000000','0.059746628525617','0.062834093966187','2781.5003969095383','2781.500396909538267','test','test','0.0'),('2019-05-22 07:59:59','2019-05-22 11:59:59','ENJBTC','4h','0.000022940000000','0.000022481200000','0.060432731956855','0.059224077317718','2634.382386959663','2634.382386959663108','test','test','1.99'),('2019-05-22 19:59:59','2019-05-22 23:59:59','ENJBTC','4h','0.000022440000000','0.000021991200000','0.060164142037046','0.058960859196305','2681.111498977115','2681.111498977114934','test','test','2.00'),('2019-06-02 19:59:59','2019-06-03 03:59:59','ENJBTC','4h','0.000019680000000','0.000019286400000','0.059896745850215','0.058698810933211','3043.5338338523943','3043.533833852394309','test','test','1.99'),('2019-06-06 23:59:59','2019-06-07 19:59:59','ENJBTC','4h','0.000019160000000','0.000019000000000','0.059630538090881','0.059132579526448','3112.241027707771','3112.241027707771082','test','test','0.83'),('2019-06-09 15:59:59','2019-06-09 19:59:59','ENJBTC','4h','0.000019780000000','0.000019384400000','0.059519880632118','0.058329483019476','3009.0940663355914','3009.094066335591378','test','test','2.00'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ENJBTC','4h','0.000019850000000','0.000019453000000','0.059255347829309','0.058070240872723','2985.1560619299075','2985.156061929907537','test','test','1.99'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ENJBTC','4h','0.000019600000000','0.000019290000000','0.058991990727845','0.058058954139803','3009.7954452982203','3009.795445298220329','test','test','1.58'),('2019-07-01 15:59:59','2019-07-01 23:59:59','ENJBTC','4h','0.000012140000000','0.000012020000000','0.058784649263836','0.058203581890553','4842.228110694875','4842.228110694874886','test','test','0.98'),('2019-07-02 07:59:59','2019-07-02 11:59:59','ENJBTC','4h','0.000012400000000','0.000012152000000','0.058655523180884','0.057482412717266','4730.284127490645','4730.284127490645005','test','test','2.0'),('2019-07-14 15:59:59','2019-07-14 19:59:59','ENJBTC','4h','0.000010300000000','0.000010094000000','0.058394831966747','0.057226935327412','5669.401161820065','5669.401161820064772','test','test','1.99'),('2019-07-14 23:59:59','2019-07-15 03:59:59','ENJBTC','4h','0.000010240000000','0.000010035200000','0.058135299380228','0.056972593392623','5677.275330100368','5677.275330100367682','test','test','2.00'),('2019-07-25 19:59:59','2019-07-25 23:59:59','ENJBTC','4h','0.000008940000000','0.000008820000000','0.057876920271871','0.057100048858826','6473.928442043747','6473.928442043747054','test','test','1.34'),('2019-07-26 07:59:59','2019-07-27 11:59:59','ENJBTC','4h','0.000009010000000','0.000008850000000','0.057704282180083','0.056679566847251','6404.470830197927','6404.470830197927171','test','test','1.77'),('2019-07-27 15:59:59','2019-07-27 19:59:59','ENJBTC','4h','0.000008900000000','0.000008880000000','0.057476567661676','0.057347406835470','6458.0413103006995','6458.041310300699479','test','test','0.22'),('2019-07-28 19:59:59','2019-07-28 23:59:59','ENJBTC','4h','0.000008930000000','0.000008900000000','0.057447865255853','0.057254871307625','6433.131607598282','6433.131607598282244','test','test','0.33'),('2019-07-30 11:59:59','2019-07-31 07:59:59','ENJBTC','4h','0.000008970000000','0.000008870000000','0.057404977711802','0.056765011405093','6399.663067090524','6399.663067090524237','test','test','1.11'),('2019-08-17 15:59:59','2019-08-17 19:59:59','ENJBTC','4h','0.000006580000000','0.000006448400000','0.057262762976978','0.056117507717438','8702.54756489024','8702.547564890239300','test','test','1.99'),('2019-08-21 15:59:59','2019-08-26 03:59:59','ENJBTC','4h','0.000006340000000','0.000006670000000','0.057008261808191','0.059975568810826','8991.839401922887','8991.839401922887191','test','test','0.78'),('2019-08-27 11:59:59','2019-08-28 19:59:59','ENJBTC','4h','0.000006830000000','0.000006693400000','0.057667663364332','0.056514310097045','8443.288925963721','8443.288925963721340','test','test','2.00'),('2019-08-28 23:59:59','2019-08-29 03:59:59','ENJBTC','4h','0.000006830000000','0.000006693400000','0.057411362638268','0.056263135385503','8405.76319740387','8405.763197403870436','test','test','2.00'),('2019-08-31 11:59:59','2019-09-03 15:59:59','ENJBTC','4h','0.000007010000000','0.000006960000000','0.057156201026543','0.056748524842331','8153.523684242921','8153.523684242921263','test','test','1.28'),('2019-09-04 03:59:59','2019-09-09 15:59:59','ENJBTC','4h','0.000007540000000','0.000007450000000','0.057065606318940','0.056384451866857','7568.382800920452','7568.382800920451700','test','test','1.19'),('2019-09-10 19:59:59','2019-09-10 23:59:59','ENJBTC','4h','0.000007520000000','0.000007400000000','0.056914238662922','0.056006032726812','7568.382800920449','7568.382800920448972','test','test','1.59'),('2019-09-18 07:59:59','2019-09-19 03:59:59','ENJBTC','4h','0.000007140000000','0.000007090000000','0.056712415121564','0.056315269357407','7942.915283132213','7942.915283132212608','test','test','0.70'),('2019-09-28 11:59:59','2019-09-30 11:59:59','ENJBTC','4h','0.000006990000000','0.000006940000000','0.056624160507307','0.056219123593807','8100.738270000986','8100.738270000985722','test','test','1.71'),('2019-10-01 07:59:59','2019-10-01 19:59:59','ENJBTC','4h','0.000007040000000','0.000006899200000','0.056534152304307','0.055403469258221','8030.419361407227','8030.419361407227370','test','test','2.00'),('2019-10-03 07:59:59','2019-10-09 15:59:59','ENJBTC','4h','0.000007180000000','0.000007490000000','0.056282889405177','0.058712930591194','7838.842535539926','7838.842535539925848','test','test','0.0'),('2019-10-12 03:59:59','2019-10-12 15:59:59','ENJBTC','4h','0.000007650000000','0.000007530000000','0.056822898557625','0.055931558972407','7427.829876813712','7427.829876813711962','test','test','1.56'),('2019-10-13 07:59:59','2019-10-13 15:59:59','ENJBTC','4h','0.000007730000000','0.000007575400000','0.056624823094243','0.055492326632358','7325.332871182808','7325.332871182808049','test','test','2.00'),('2019-10-22 15:59:59','2019-10-23 03:59:59','ENJBTC','4h','0.000007430000000','0.000007281400000','0.056373157213824','0.055245694069548','7587.235156638522','7587.235156638522312','test','test','1.99'),('2019-10-23 11:59:59','2019-10-25 15:59:59','ENJBTC','4h','0.000007590000000','0.000007438200000','0.056122609848430','0.055000157651461','7394.283247487423','7394.283247487423068','test','test','1.99'),('2019-11-01 03:59:59','2019-11-02 11:59:59','ENJBTC','4h','0.000007260000000','0.000007114800000','0.055873176026881','0.054755712506343','7696.029755768716','7696.029755768716313','test','test','1.99'),('2019-11-02 19:59:59','2019-11-03 03:59:59','ENJBTC','4h','0.000007080000000','0.000007160000000','0.055624850800095','0.056253380187667','7856.61734464614','7856.617344646139827','test','test','0.0'),('2019-11-04 03:59:59','2019-11-04 23:59:59','ENJBTC','4h','0.000007190000000','0.000007140000000','0.055764523997333','0.055376731758130','7755.844784051862','7755.844784051862007','test','test','0.97'),('2019-11-05 19:59:59','2019-11-07 03:59:59','ENJBTC','4h','0.000007210000000','0.000007180000000','0.055678347944177','0.055446676593508','7722.378355641702','7722.378355641702001','test','test','0.83'),('2019-11-12 15:59:59','2019-11-12 19:59:59','ENJBTC','4h','0.000007090000000','0.000007100000000','0.055626865421806','0.055705323624093','7845.820228745525','7845.820228745525128','test','test','0.0'),('2019-11-14 07:59:59','2019-11-14 11:59:59','ENJBTC','4h','0.000007230000000','0.000007100000000','0.055644300577870','0.054643780650467','7696.307133868541','7696.307133868541314','test','test','1.79'),('2019-11-14 15:59:59','2019-11-18 15:59:59','ENJBTC','4h','0.000007270000000','0.000007600000000','0.055421962816224','0.057937677772119','7623.378654226197','7623.378654226196886','test','test','0.0'),('2019-11-19 19:59:59','2019-11-22 15:59:59','ENJBTC','4h','0.000007950000000','0.000007820000000','0.055981010584201','0.055065597832510','7041.636551471839','7041.636551471839084','test','test','1.63'),('2019-11-23 19:59:59','2019-11-23 23:59:59','ENJBTC','4h','0.000008610000000','0.000008437800000','0.055777585528270','0.054662033817705','6478.232930112635','6478.232930112634676','test','test','1.99'),('2019-11-27 11:59:59','2019-11-27 15:59:59','ENJBTC','4h','0.000007790000000','0.000007730000000','0.055529685148144','0.055101985390905','7128.329287309914','7128.329287309914434','test','test','0.77'),('2019-11-28 15:59:59','2019-11-30 15:59:59','ENJBTC','4h','0.000007910000000','0.000007800000000','0.055434640757647','0.054663741834342','7008.172030043827','7008.172030043827363','test','test','1.39'),('2019-11-30 23:59:59','2019-12-03 15:59:59','ENJBTC','4h','0.000007990000000','0.000008170000000','0.055263329885801','0.056508311034668','6916.561938147825','6916.561938147824549','test','test','1.00'),('2019-12-03 19:59:59','2019-12-04 15:59:59','ENJBTC','4h','0.000008330000000','0.000008400000000','0.055539992363327','0.056006714988229','6667.466070027265','6667.466070027265232','test','test','0.12'),('2019-12-04 19:59:59','2019-12-04 23:59:59','ENJBTC','4h','0.000011600000000','0.000011368000000','0.055643708502194','0.054530834332150','4796.8714226029515','4796.871422602951498','test','test','2.00'),('2019-12-05 07:59:59','2019-12-10 03:59:59','ENJBTC','4h','0.000010670000000','0.000010456600000','0.055396403131073','0.054288475068452','5191.790359050923','5191.790359050923144','test','test','2.00'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ENJBTC','4h','0.000011250000000','0.000011025000000','0.055150196894935','0.054047192957036','4902.239723994252','4902.239723994252017','test','test','2.00'),('2019-12-11 23:59:59','2019-12-13 03:59:59','ENJBTC','4h','0.000011590000000','0.000011358200000','0.054905084908736','0.053806983210561','4737.280837682102','4737.280837682102174','test','test','2.00'),('2019-12-15 19:59:59','2019-12-17 23:59:59','ENJBTC','4h','0.000011310000000','0.000011480000000','0.054661062309141','0.055482669788589','4832.985173222027','4832.985173222026788','test','test','0.0'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ENJBTC','4h','0.000011160000000','0.000011240000000','0.054843641749018','0.055236786134316','4914.304816220292','4914.304816220292196','test','test','0.0'),('2019-12-22 11:59:59','2019-12-22 19:59:59','ENJBTC','4h','0.000011460000000','0.000011230800000','0.054931007167974','0.053832387024615','4793.281602790014','4793.281602790014404','test','test','1.99'),('2019-12-28 19:59:59','2019-12-29 03:59:59','ENJBTC','4h','0.000011120000000','0.000010897600000','0.054686869358338','0.053593131971171','4917.883935102358','4917.883935102358009','test','test','1.99'),('2019-12-29 07:59:59','2019-12-29 19:59:59','ENJBTC','4h','0.000011090000000','0.000010868200000','0.054443816605634','0.053354940273521','4909.27110961537','4909.271109615369824','test','test','2.00'),('2019-12-30 15:59:59','2019-12-30 23:59:59','ENJBTC','4h','0.000011600000000','0.000011368000000','0.054201844087387','0.053117807205639','4672.572766154062','4672.572766154062265','test','test','2.00'),('2019-12-31 11:59:59','2019-12-31 15:59:59','ENJBTC','4h','0.000011820000000','0.000011583600000','0.053960947002554','0.052881728062503','4565.2239426864835','4565.223942686483497','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:22:16
