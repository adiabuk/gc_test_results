-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.467166000000000','3.111111111111111','3.048888888888889','6.526350138684941','6.526350138684941','test','test','1.99'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','3.097283950617284','3.099928376615677','6.611064995981396','6.611064995981396','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','3.097871600839149','3.055157316088153','7.239709279829748','7.239709279829748','test','test','1.37'),('2019-01-25 11:59:59','2019-01-25 15:59:59','WAVESBNB','4h','0.433700000000000','0.437100000000000','3.088379537561150','3.112590951966749','7.121004236940626','7.121004236940626','test','test','0.0'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.442666000000000','3.093759851873505','3.031884654836035','6.849147336447876','6.849147336447876','test','test','1.99'),('2019-02-26 23:59:59','2019-02-27 03:59:59','WAVESBNB','4h','0.280700000000000','0.279400000000000','3.080009808087401','3.065745423511292','10.972603520083364','10.972603520083364','test','test','0.46'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','3.076839944848265','3.020987004044827','16.4273355304232','16.427335530423200','test','test','1.81'),('2019-03-24 03:59:59','2019-03-24 11:59:59','WAVESBNB','4h','0.187400000000000','0.183652000000000','3.064428180225280','3.003139616620774','16.352338208245886','16.352338208245886','test','test','2.00'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','3.050808499424278','2.999932451992821','17.543464631536963','17.543464631536963','test','test','1.66'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.160132000000000','3.039502711106177','2.978712656884054','18.60160777910757','18.601607779107571','test','test','1.99'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.160622000000000','3.025993810167927','2.965473933964569','18.462439354288758','18.462439354288758','test','test','2.00'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.161602000000000','3.012544948789403','2.952294049813615','18.268920247358416','18.268920247358416','test','test','1.99'),('2019-05-07 11:59:59','2019-05-07 15:59:59','WAVESBNB','4h','0.098200000000000','0.110200000000000','2.999155860128117','3.365651484583692','30.54130203796453','30.541302037964531','test','test','0.0'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESBNB','4h','0.108000000000000','0.105840000000000','3.080599332229355','3.018987345584768','28.524067891012546','28.524067891012546','test','test','1.99'),('2019-05-08 03:59:59','2019-05-08 07:59:59','WAVESBNB','4h','0.099800000000000','0.099900000000000','3.066907779641669','3.069980833529086','30.730538874165024','30.730538874165024','test','test','0.0'),('2019-05-08 11:59:59','2019-05-08 15:59:59','WAVESBNB','4h','0.106300000000000','0.104174000000000','3.067590680505540','3.006238866895429','28.85786152874449','28.857861528744490','test','test','2.00'),('2019-05-08 19:59:59','2019-05-13 07:59:59','WAVESBNB','4h','0.104200000000000','0.105800000000000','3.053956944147737','3.100850716802597','29.308607909287304','29.308607909287304','test','test','0.0'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WAVESBNB','4h','0.105000000000000','0.102900000000000','3.064377782515484','3.003090226865174','29.184550309671277','29.184550309671277','test','test','2.00'),('2019-06-16 23:59:59','2019-06-17 07:59:59','WAVESBNB','4h','0.075300000000000','0.074200000000000','3.050758325704304','3.006192135023364','40.51471880085397','40.514718800853970','test','test','1.46'),('2019-06-17 11:59:59','2019-06-17 15:59:59','WAVESBNB','4h','0.075200000000000','0.073696000000000','3.040854727775207','2.980037633219703','40.436897975734134','40.436897975734134','test','test','2.00'),('2019-07-03 23:59:59','2019-07-04 03:59:59','WAVESBNB','4h','0.060000000000000','0.059100000000000','3.027339817873983','2.981929720605873','50.45566363123306','50.455663631233058','test','test','1.49'),('2019-07-06 15:59:59','2019-07-06 19:59:59','WAVESBNB','4h','0.061900000000000','0.060662000000000','3.017248685147736','2.956903711444781','48.74392060012498','48.743920600124980','test','test','2.00'),('2019-07-06 23:59:59','2019-07-08 07:59:59','WAVESBNB','4h','0.059400000000000','0.058900000000000','3.003838690991524','2.978553853525265','50.56967493251724','50.569674932517238','test','test','0.84'),('2019-07-16 15:59:59','2019-07-17 03:59:59','WAVESBNB','4h','0.058390000000000','0.057222200000000','2.998219838221244','2.938255441456819','51.3481732868855','51.348173286885498','test','test','2.00'),('2019-07-17 07:59:59','2019-07-17 11:59:59','WAVESBNB','4h','0.054760000000000','0.055320000000000','2.984894416718039','3.015419268313402','54.50866356314899','54.508663563148993','test','test','0.0'),('2019-07-29 07:59:59','2019-07-31 07:59:59','WAVESBNB','4h','0.049500000000000','0.050420000000000','2.991677717072564','3.047280616056539','60.43793367823361','60.437933678233613','test','test','0.0'),('2019-07-31 11:59:59','2019-07-31 15:59:59','WAVESBNB','4h','0.050200000000000','0.050140000000000','3.004033916846780','3.000443438061704','59.84131308459721','59.841313084597211','test','test','0.11'),('2019-07-31 19:59:59','2019-07-31 23:59:59','WAVESBNB','4h','0.050250000000000','0.049560000000000','3.003236032672319','2.961997567746072','59.76589119745909','59.765891197459091','test','test','1.37'),('2019-08-04 19:59:59','2019-08-05 03:59:59','WAVESBNB','4h','0.050140000000000','0.050360000000000','2.994071929355375','3.007209061873488','59.714238718695164','59.714238718695164','test','test','0.81'),('2019-08-05 07:59:59','2019-08-05 11:59:59','WAVESBNB','4h','0.050250000000000','0.049245000000000','2.996991292137178','2.937051466294434','59.6416177539737','59.641617753973698','test','test','1.99'),('2019-08-05 19:59:59','2019-08-06 11:59:59','WAVESBNB','4h','0.050960000000000','0.049940800000000','2.983671330838791','2.923997904222016','58.54928043247235','58.549280432472351','test','test','1.99'),('2019-08-07 07:59:59','2019-08-07 11:59:59','WAVESBNB','4h','0.050050000000000','0.049049000000000','2.970410569368397','2.911002357981029','59.34886252484309','59.348862524843092','test','test','2.00'),('2019-08-18 11:59:59','2019-08-18 23:59:59','WAVESBNB','4h','0.045520000000000','0.045140000000000','2.957208744615648','2.932522028382038','64.96504272002743','64.965042720027427','test','test','1.42'),('2019-08-19 03:59:59','2019-08-19 07:59:59','WAVESBNB','4h','0.044820000000000','0.043923600000000','2.951722807674846','2.892688351521349','65.8572692475423','65.857269247542305','test','test','1.99'),('2019-08-20 15:59:59','2019-08-20 23:59:59','WAVESBNB','4h','0.045050000000000','0.044250000000000','2.938604039640735','2.886420172122142','65.22983439824051','65.229834398240513','test','test','1.77'),('2019-08-21 15:59:59','2019-08-22 03:59:59','WAVESBNB','4h','0.045170000000000','0.045070000000000','2.927007624636603','2.920527643178474','64.79981458128411','64.799814581284110','test','test','0.22'),('2019-08-22 07:59:59','2019-08-28 03:59:59','WAVESBNB','4h','0.045150000000000','0.048450000000000','2.925567628757019','3.139396491988429','64.7966252216394','64.796625221639403','test','test','0.0'),('2019-08-28 07:59:59','2019-08-28 19:59:59','WAVESBNB','4h','0.047820000000000','0.048560000000000','2.973085153919555','3.019092745176361','62.172420617305626','62.172420617305626','test','test','0.0'),('2019-08-28 23:59:59','2019-09-02 15:59:59','WAVESBNB','4h','0.050030000000000','0.050490000000000','2.983309063087734','3.010739048476907','59.63040301994271','59.630403019942712','test','test','0.41'),('2019-09-02 19:59:59','2019-09-03 15:59:59','WAVESBNB','4h','0.050270000000000','0.050840000000000','2.989404615396440','3.023300788676249','59.4669706663306','59.466970666330603','test','test','0.71'),('2019-09-03 19:59:59','2019-09-05 19:59:59','WAVESBNB','4h','0.051190000000000','0.050166200000000','2.996937098347508','2.936998356380558','58.545362343182425','58.545362343182425','test','test','1.99'),('2019-09-11 19:59:59','2019-09-11 23:59:59','WAVESBNB','4h','0.049850000000000','0.049180000000000','2.983617377910408','2.943516602720840','59.8519032680122','59.851903268012201','test','test','1.34'),('2019-09-12 03:59:59','2019-09-12 11:59:59','WAVESBNB','4h','0.049450000000000','0.050630000000000','2.974706094534949','3.045689981118392','60.15583608766327','60.155836087663268','test','test','0.0'),('2019-09-12 15:59:59','2019-09-13 07:59:59','WAVESBNB','4h','0.049990000000000','0.049370000000000','2.990480291553492','2.953390918063530','59.82157014509885','59.821570145098853','test','test','1.70'),('2019-09-13 19:59:59','2019-09-14 15:59:59','WAVESBNB','4h','0.049180000000000','0.048440000000000','2.982238208555722','2.937365165157364','60.63924783561858','60.639247835618583','test','test','1.50'),('2019-09-15 03:59:59','2019-09-18 11:59:59','WAVESBNB','4h','0.049110000000000','0.052880000000000','2.972266421133865','3.200436740980631','60.52263125908908','60.522631259089081','test','test','0.0'),('2019-09-18 15:59:59','2019-09-19 15:59:59','WAVESBNB','4h','0.051560000000000','0.050528800000000','3.022970936655369','2.962511517922262','58.630157809452456','58.630157809452456','test','test','2.00'),('2019-09-19 19:59:59','2019-09-19 23:59:59','WAVESBNB','4h','0.050840000000000','0.049980000000000','3.009535510270233','2.958626766390759','59.19621381334054','59.196213813340542','test','test','1.69'),('2019-09-22 23:59:59','2019-09-23 19:59:59','WAVESBNB','4h','0.054190000000000','0.053106200000000','2.998222456074795','2.938258006953299','55.327965603889915','55.327965603889915','test','test','2.00'),('2019-09-23 23:59:59','2019-09-24 15:59:59','WAVESBNB','4h','0.052040000000000','0.050999200000000','2.984897022936684','2.925199082477950','57.35774448379485','57.357744483794853','test','test','2.00'),('2019-09-24 19:59:59','2019-09-24 23:59:59','WAVESBNB','4h','0.051460000000000','0.052300000000000','2.971630813945854','3.020137807410963','57.74642079179663','57.746420791796631','test','test','0.0'),('2019-09-25 03:59:59','2019-10-01 07:59:59','WAVESBNB','4h','0.052040000000000','0.052770000000000','2.982410145826990','3.024246414206192','57.309956683839154','57.309956683839154','test','test','0.0'),('2019-10-03 03:59:59','2019-10-03 07:59:59','WAVESBNB','4h','0.055610000000000','0.054497800000000','2.991707094355702','2.931872952468588','53.79800565286283','53.798005652862827','test','test','2.00'),('2019-10-03 11:59:59','2019-10-09 07:59:59','WAVESBNB','4h','0.054400000000000','0.053490000000000','2.978410618380787','2.928587940757138','54.7501951908233','54.750195190823298','test','test','1.67'),('2019-11-17 03:59:59','2019-11-17 07:59:59','WAVESBNB','4h','0.038460000000000','0.038420000000000','2.967338912242198','2.964252756327229','77.15389787421212','77.153897874212120','test','test','0.10'),('2019-11-17 11:59:59','2019-11-17 15:59:59','WAVESBNB','4h','0.038500000000000','0.037740000000000','2.966653099816650','2.908090597067023','77.05592467056233','77.055924670562334','test','test','1.97'),('2019-11-17 19:59:59','2019-11-17 23:59:59','WAVESBNB','4h','0.038470000000000','0.038180000000000','2.953639210316733','2.931373669090015','76.77772836799411','76.777728367994115','test','test','0.75'),('2019-11-18 03:59:59','2019-11-18 19:59:59','WAVESBNB','4h','0.038740000000000','0.038180000000000','2.948691312266351','2.906066967019342','76.11490222680308','76.114902226803082','test','test','1.44'),('2019-11-19 11:59:59','2019-11-20 07:59:59','WAVESBNB','4h','0.038520000000000','0.038490000000000','2.939219235544793','2.936930123990631','76.30371847208706','76.303718472087056','test','test','0.07'),('2019-11-20 11:59:59','2019-11-21 15:59:59','WAVESBNB','4h','0.038510000000000','0.038950000000000','2.938710544088313','2.972287086269535','76.31032313914082','76.310323139140820','test','test','0.0'),('2019-11-21 19:59:59','2019-11-21 23:59:59','WAVESBNB','4h','0.038350000000000','0.038720000000000','2.946171997906362','2.974596603883555','76.82325939781909','76.823259397819086','test','test','0.0'),('2019-11-22 03:59:59','2019-11-23 19:59:59','WAVESBNB','4h','0.039540000000000','0.038980000000000','2.952488577012405','2.910672856144248','74.6709301217098','74.670930121709802','test','test','1.41'),('2019-11-23 23:59:59','2019-11-24 03:59:59','WAVESBNB','4h','0.038840000000000','0.038280000000000','2.943196194597259','2.900760822069596','75.77745094225693','75.777450942256934','test','test','1.44'),('2019-11-25 23:59:59','2019-11-26 03:59:59','WAVESBNB','4h','0.039100000000000','0.038318000000000','2.933766111813334','2.875090789577067','75.0323813763001','75.032381376300094','test','test','1.99'),('2019-11-26 19:59:59','2019-11-27 03:59:59','WAVESBNB','4h','0.038990000000000','0.038430000000000','2.920727151316386','2.878777748784014','74.90964737923535','74.909647379235352','test','test','1.43'),('2019-11-27 07:59:59','2019-11-27 11:59:59','WAVESBNB','4h','0.039070000000000','0.038620000000000','2.911405061864748','2.877872113878079','74.51766219259656','74.517662192596561','test','test','1.15'),('2019-11-27 15:59:59','2019-11-27 19:59:59','WAVESBNB','4h','0.039200000000000','0.038416000000000','2.903953295645488','2.845874229732578','74.08044121544613','74.080441215446129','test','test','2.0'),('2019-11-28 15:59:59','2019-11-29 11:59:59','WAVESBNB','4h','0.039080000000000','0.038630000000000','2.891046836553730','2.857756890892287','73.9776570254281','73.977657025428101','test','test','1.15'),('2019-11-29 15:59:59','2019-11-29 19:59:59','WAVESBNB','4h','0.038860000000000','0.039110000000000','2.883649070851188','2.902200596011065','74.2061006395056','74.206100639505607','test','test','0.0'),('2019-11-29 23:59:59','2019-11-30 11:59:59','WAVESBNB','4h','0.038850000000000','0.038670000000000','2.887771631997827','2.874391995092818','74.3313161389402','74.331316138940196','test','test','0.46'),('2019-12-01 11:59:59','2019-12-02 11:59:59','WAVESBNB','4h','0.039340000000000','0.038920000000000','2.884798379352269','2.853999820142103','73.32990288134899','73.329902881348985','test','test','1.22'),('2019-12-02 15:59:59','2019-12-02 19:59:59','WAVESBNB','4h','0.038960000000000','0.038840000000000','2.877954255083343','2.869089919595406','73.8694623994698','73.869462399469796','test','test','0.30'),('2019-12-02 23:59:59','2019-12-03 07:59:59','WAVESBNB','4h','0.038880000000000','0.038750000000000','2.875984402752691','2.866368199759948','73.97079225186963','73.970792251869625','test','test','0.33'),('2019-12-03 11:59:59','2019-12-03 15:59:59','WAVESBNB','4h','0.039180000000000','0.038396400000000','2.873847468754303','2.816370519379217','73.34985882476526','73.349858824765263','test','test','2.00'),('2019-12-11 11:59:59','2019-12-15 03:59:59','WAVESBNB','4h','0.037890000000000','0.047550000000000','2.861074813337618','3.590501646191706','75.51002410497803','75.510024104978029','test','test','0.0'),('2019-12-15 07:59:59','2019-12-15 15:59:59','WAVESBNB','4h','0.049370000000000','0.048382600000000','3.023169665082971','2.962706271781312','61.23495371851268','61.234953718512678','test','test','1.99'),('2019-12-15 19:59:59','2020-01-01 15:59:59','WAVESBNB','4h','0.050410000000000','0.075800000000000','3.009733355460380','4.525645473991209','59.70508540885498','59.705085408854977','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:16:44
