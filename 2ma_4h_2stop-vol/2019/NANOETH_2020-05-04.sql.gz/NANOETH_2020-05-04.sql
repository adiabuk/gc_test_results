-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.297777777777778','1.315084074185063','194.45276862118334','194.452768621183338','test','test','0.0'),('2019-01-09 23:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006854000000000','0.006798000000000','1.301623621423841','1.290988820898639','189.90715223575154','189.907152235751539','test','test','0.81'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.299260332418241','1.516819489715851','184.68519295213088','184.685192952130876','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.347606811817710','1.341097648345234','209.9730152411514','209.973015241151387','test','test','0.48'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.346160331046048','1.343486521373993','205.67766708113803','205.677667081138026','test','test','0.44'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.345566151118925','1.340605538580238','206.69218911197004','206.692189111970038','test','test','0.36'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.344463792776994','1.356365334288146','205.19899157158036','205.198991571580365','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.347108579779473','1.468354444716658','203.0919010673108','203.091901067310800','test','test','0.0'),('2019-03-17 19:59:59','2019-03-19 23:59:59','NANOETH','4h','0.007329000000000','0.007182420000000','1.374052105321069','1.346571063214648','187.48152617288434','187.481526172884344','test','test','2.00'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007308000000000','0.007176000000000','1.367945207075198','1.343236837160868','187.1846205631086','187.184620563108609','test','test','1.80'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.362454458205347','1.353032228203927','188.44460002840205','188.444600028402050','test','test','0.69'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007158000000000','1.360360629316143','1.343283402489302','187.66183326198683','187.661833261986828','test','test','1.25'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.356565690021289','1.361850030494383','188.72644546762504','188.726445467625041','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007158000000000','1.357739987904199','1.341621042713729','187.4295952380175','187.429595238017498','test','test','1.18'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.354158000084094','1.364283246830777','187.50456938300945','187.504569383009454','test','test','0.36'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.356408054916691','1.453552776907924','180.90264802836631','180.902648028366315','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.377995770914742','1.502839832211291','168.25345188214192','168.253451882141917','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 11:59:59','NANOETH','4h','0.009923000000000','0.009724540000000','1.405738895647309','1.377624117734363','141.66470781490565','141.664707814905654','test','test','2.00'),('2019-04-13 19:59:59','2019-04-14 11:59:59','NANOETH','4h','0.009546000000000','0.009355080000000','1.399491167222210','1.371501343877766','146.60498294806303','146.604982948063025','test','test','2.00'),('2019-04-17 07:59:59','2019-04-18 07:59:59','NANOETH','4h','0.009745000000000','0.009550100000000','1.393271206479000','1.365405782349420','142.9729303723961','142.972930372396092','test','test','1.99'),('2019-04-19 15:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009496000000000','0.009556000000000','1.387078890005760','1.395843078443033','146.0698072878854','146.069807287885396','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.389026487436265','1.455744611353486','140.1641258765151','140.164125876515101','test','test','0.95'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.403852737195647','1.391291265619382','216.57709614249418','216.577096142494185','test','test','0.89'),('2019-06-08 19:59:59','2019-06-09 19:59:59','NANOETH','4h','0.006592000000000','0.006460160000000','1.401061299067589','1.373040073086237','212.5396388148648','212.539638814864787','test','test','2.00'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006360000000000','1.394834359960621','1.370696311704195','215.5182880038043','215.518288003804287','test','test','1.73'),('2019-06-13 23:59:59','2019-06-14 07:59:59','NANOETH','4h','0.006924000000000','0.006785520000000','1.389470349236971','1.361680942252232','200.67451606542045','200.674516065420448','test','test','1.99'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004382560000000','1.383294925462585','1.355629026953334','309.323552205408','309.323552205408021','test','test','1.99'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004469780000000','1.377146948016084','1.349604009055762','301.9396948072976','301.939694807297599','test','test','2.00'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004401000000000','1.371026294913791','1.344448913528430','305.48714236047033','305.487142360470330','test','test','1.93'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004371000000000','1.365120210161488','1.340885491823790','306.76858655314345','306.768586553143450','test','test','1.77'),('2019-07-14 15:59:59','2019-07-15 23:59:59','NANOETH','4h','0.004497000000000','0.004444000000000','1.359734717197555','1.343709380303743','302.3648470530476','302.364847053047583','test','test','1.93'),('2019-07-16 11:59:59','2019-07-31 15:59:59','NANOETH','4h','0.004481000000000','0.005844000000000','1.356173531221153','1.768685140918638','302.64975032830904','302.649750328309040','test','test','0.04'),('2019-08-09 23:59:59','2019-08-10 03:59:59','NANOETH','4h','0.005367000000000','0.005434000000000','1.447842777820594','1.465917207877232','269.76761278565186','269.767612785651863','test','test','0.0'),('2019-08-10 11:59:59','2019-08-11 15:59:59','NANOETH','4h','0.005330000000000','0.005254000000000','1.451859317833180','1.431157383845315','272.3938682613846','272.393868261384625','test','test','1.44'),('2019-08-12 15:59:59','2019-08-12 19:59:59','NANOETH','4h','0.005403000000000','0.005294940000000','1.447258888058099','1.418313710296937','267.8620929220986','267.862092922098611','test','test','2.00'),('2019-08-13 03:59:59','2019-08-13 07:59:59','NANOETH','4h','0.005316000000000','0.005216000000000','1.440826626333396','1.413723040435477','271.03585897919413','271.035858979194131','test','test','1.88'),('2019-08-14 19:59:59','2019-08-14 23:59:59','NANOETH','4h','0.005355000000000','0.005290000000000','1.434803607244970','1.417387690443677','267.93718155835097','267.937181558350971','test','test','1.21'),('2019-08-15 01:59:59','2019-08-16 03:59:59','NANOETH','4h','0.005571000000000','0.005459580000000','1.430933403511349','1.402314735441122','256.8539586270596','256.853958627059626','test','test','2.00'),('2019-08-16 15:59:59','2019-08-18 11:59:59','NANOETH','4h','0.005526000000000','0.005415480000000','1.424573699495743','1.396082225505828','257.7947338935474','257.794733893547402','test','test','2.00'),('2019-08-21 19:59:59','2019-08-22 03:59:59','NANOETH','4h','0.005419000000000','0.005346000000000','1.418242260831318','1.399136948958152','261.716601002273','261.716601002273023','test','test','1.34'),('2019-08-22 07:59:59','2019-08-22 11:59:59','NANOETH','4h','0.005392000000000','0.005358000000000','1.413996635970614','1.405080485076140','262.2397321903958','262.239732190395785','test','test','0.63'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NANOETH','4h','0.005395000000000','0.005331000000000','1.412015269105175','1.395264763595864','261.72664858297975','261.726648582979749','test','test','1.18'),('2019-08-24 19:59:59','2019-08-25 15:59:59','NANOETH','4h','0.005452000000000','0.005430000000000','1.408292934547551','1.402610167753705','258.30758153843556','258.307581538435556','test','test','1.08'),('2019-08-25 23:59:59','2019-08-26 07:59:59','NANOETH','4h','0.005535000000000','0.005424300000000','1.407030097482251','1.378889495532606','254.20597967159014','254.205979671590143','test','test','2.00'),('2019-08-28 19:59:59','2019-09-01 03:59:59','NANOETH','4h','0.005550000000000','0.005548000000000','1.400776630382331','1.400271846011022','252.39218565447396','252.392185654473963','test','test','0.03'),('2019-09-02 11:59:59','2019-09-03 15:59:59','NANOETH','4h','0.005700000000000','0.005586000000000','1.400664456077595','1.372651166956043','245.73060632940266','245.730606329402661','test','test','2.00'),('2019-09-26 07:59:59','2019-09-26 19:59:59','NANOETH','4h','0.004554000000000','0.004533000000000','1.394439280717250','1.388009060055181','306.20098390804793','306.200983908047931','test','test','0.46'),('2019-10-08 15:59:59','2019-10-08 19:59:59','NANOETH','4h','0.004278000000000','0.004370000000000','1.393010342792346','1.422967554465300','325.6218660103661','325.621866010366091','test','test','0.0'),('2019-10-08 23:59:59','2019-10-09 15:59:59','NANOETH','4h','0.004403000000000','0.004314940000000','1.399667500941892','1.371674150923054','317.8895073681334','317.889507368133422','test','test','2.00'),('2019-10-12 03:59:59','2019-10-12 11:59:59','NANOETH','4h','0.004282000000000','0.004229000000000','1.393446756493261','1.376199517330687','325.4196068410231','325.419606841023096','test','test','1.23'),('2019-10-13 19:59:59','2019-10-14 07:59:59','NANOETH','4h','0.004308000000000','0.004301000000000','1.389614036679355','1.387356075152717','322.56593237682347','322.565932376823469','test','test','0.23'),('2019-10-15 07:59:59','2019-10-23 03:59:59','NANOETH','4h','0.004297000000000','0.004531000000000','1.389112267451214','1.464758595257494','323.2749051550416','323.274905155041608','test','test','0.0'),('2019-10-23 07:59:59','2019-10-23 15:59:59','NANOETH','4h','0.004593000000000','0.004550000000000','1.405922562519276','1.392760213251188','306.1011457694918','306.101145769491779','test','test','0.93'),('2019-10-24 11:59:59','2019-10-24 15:59:59','NANOETH','4h','0.004572000000000','0.004596000000000','1.402997596015256','1.410362412792239','306.86736570762383','306.867365707623833','test','test','0.0'),('2019-10-27 19:59:59','2019-10-27 23:59:59','NANOETH','4h','0.004618000000000','0.004615000000000','1.404634221965697','1.403721726802012','304.1650545616494','304.165054561649413','test','test','0.06'),('2019-10-29 15:59:59','2019-10-29 19:59:59','NANOETH','4h','0.004658000000000','0.004564840000000','1.404431445262656','1.376342816357403','301.50954170516445','301.509541705164452','test','test','2.00'),('2019-10-31 11:59:59','2019-11-02 19:59:59','NANOETH','4h','0.004754000000000','0.004658920000000','1.398189527728155','1.370225737173592','294.10802013633884','294.108020136338837','test','test','1.99'),('2019-11-03 15:59:59','2019-11-04 11:59:59','NANOETH','4h','0.004690000000000','0.004671000000000','1.391975352049363','1.386336219493086','296.7964503303547','296.796450330354673','test','test','0.40'),('2019-11-04 19:59:59','2019-11-13 23:59:59','NANOETH','4h','0.004806000000000','0.005272000000000','1.390722211481302','1.525569600276617','289.3720789599046','289.372078959904627','test','test','0.0'),('2019-11-14 23:59:59','2019-11-15 03:59:59','NANOETH','4h','0.005300000000000','0.005194000000000','1.420688297880261','1.392274531922656','268.0543958264643','268.054395826464315','test','test','2.00'),('2019-11-20 19:59:59','2019-11-20 23:59:59','NANOETH','4h','0.005193000000000','0.005154000000000','1.414374127667460','1.403752022722528','272.36166525466194','272.361665254661943','test','test','0.75'),('2019-11-21 07:59:59','2019-11-21 11:59:59','NANOETH','4h','0.005291000000000','0.005233000000000','1.412013659901919','1.396535150683565','266.8708485923113','266.870848592311290','test','test','1.09'),('2019-11-21 15:59:59','2019-11-22 11:59:59','NANOETH','4h','0.005317000000000','0.005287000000000','1.408573991186729','1.400626423058912','264.9189375938931','264.918937593893077','test','test','1.44'),('2019-11-24 23:59:59','2019-11-25 07:59:59','NANOETH','4h','0.005373000000000','0.005383000000000','1.406807864936103','1.409426156142014','261.82912059112283','261.829120591122830','test','test','1.30'),('2019-11-25 15:59:59','2019-11-25 23:59:59','NANOETH','4h','0.005426000000000','0.005317480000000','1.407389707426306','1.379241913277780','259.37886240809166','259.378862408091663','test','test','1.99'),('2019-11-26 15:59:59','2019-12-04 03:59:59','NANOETH','4h','0.005473000000000','0.005662000000000','1.401134642059967','1.449520252757817','256.0085222108472','256.008522210847218','test','test','1.15'),('2019-12-05 03:59:59','2019-12-05 07:59:59','NANOETH','4h','0.005591000000000','0.005632000000000','1.411886999992822','1.422240669640418','252.52852799013095','252.528527990130954','test','test','0.0'),('2019-12-09 15:59:59','2019-12-09 19:59:59','NANOETH','4h','0.005583000000000','0.005578000000000','1.414187815470066','1.412921303007707','253.30249247180112','253.302492471801116','test','test','0.08'),('2019-12-20 19:59:59','2019-12-21 11:59:59','NANOETH','4h','0.005443000000000','0.005334140000000','1.413906368256208','1.385628240891084','259.7660055587375','259.766005558737504','test','test','1.99'),('2019-12-30 19:59:59','2019-12-30 23:59:59','NANOETH','4h','0.005211000000000','0.005156000000000','1.407622339952847','1.392765454768159','270.1251851761364','270.125185176136426','test','test','1.05');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:05:33
