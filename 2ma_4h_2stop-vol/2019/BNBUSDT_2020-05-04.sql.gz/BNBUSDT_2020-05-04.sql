-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 15:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.907100000000000','5.893500000000000','222.222222222222200','221.710596852375403','37.619512488737655','37.619512488737655','test','test','1.94'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','222.108527695589601','229.454212820283885','37.864356312857296','37.864356312857296','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.937133999999999','223.740902167743883','219.266084124388982','36.93130121779111','36.931301217791109','test','test','2.00'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','222.746498158109461','246.468921588223168','36.56917439511902','36.569174395119020','test','test','1.64'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','228.018147809245846','339.415612056708312','34.68273117079062','34.682731170790618','test','test','0.78'),('2019-02-28 11:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.347600000000000','14.458200000000000','252.773139864237493','353.187658083528390','24.428190098596534','24.428190098596534','test','test','1.32'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.847196000000000','275.087477246302171','269.585727701376129','18.15734955619742','18.157349556197421','test','test','1.99'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBUSDT','4h','17.040199999999999','16.699396000000000','273.864866236318619','268.387568911592268','16.071693186483646','16.071693186483646','test','test','1.99'),('2019-03-27 23:59:59','2019-03-30 03:59:59','BNBUSDT','4h','16.600000000000001','16.268000000000001','272.647689053046065','267.194735271985166','16.4245595815088','16.424559581508799','test','test','2.00'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','271.435921546143618','293.233322574429735','16.439702110480507','16.439702110480507','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','276.279788441318317','273.359723786236373','15.098576293081269','15.098576293081269','test','test','1.05'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','275.630885184633485','274.695654912152975','15.060068800008386','15.060068800008386','test','test','0.33'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','275.423056235193314','276.371262636651124','15.074823552587427','15.074823552587427','test','test','0.0'),('2019-04-13 19:59:59','2019-04-24 07:59:59','BNBUSDT','4h','18.371700000000001','21.444099999999999','275.633768768850643','321.729513374162934','15.003171659065336','15.003171659065336','test','test','0.0'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BNBUSDT','4h','22.004500000000000','22.086600000000001','285.877267570031108','286.943891381865001','12.991763846941812','12.991763846941812','test','test','0.0'),('2019-04-25 19:59:59','2019-04-25 23:59:59','BNBUSDT','4h','22.881300000000000','22.486300000000000','286.114295083771992','281.175102530984816','12.504284943765084','12.504284943765084','test','test','1.72'),('2019-04-26 03:59:59','2019-04-26 15:59:59','BNBUSDT','4h','23.489899999999999','23.020101999999998','285.016696738708163','279.316362803933998','12.13358493389534','12.133584933895341','test','test','2.00'),('2019-04-26 23:59:59','2019-04-27 03:59:59','BNBUSDT','4h','23.055499999999999','22.594389999999997','283.749955864313904','278.074956747027613','12.307256657383874','12.307256657383874','test','test','2.00'),('2019-04-27 19:59:59','2019-04-29 11:59:59','BNBUSDT','4h','22.637699999999999','22.184946000000000','282.488844949361408','276.839068050374181','12.47869019155486','12.478690191554859','test','test','1.99'),('2019-05-02 11:59:59','2019-05-04 15:59:59','BNBUSDT','4h','22.739300000000000','22.677000000000000','281.233338971808678','280.462829896421852','12.367721916321464','12.367721916321464','test','test','0.27'),('2019-05-05 23:59:59','2019-05-06 03:59:59','BNBUSDT','4h','22.977699999999999','22.518145999999998','281.062114732833834','275.440872438177166','12.23195161973713','12.231951619737130','test','test','2.00'),('2019-05-13 03:59:59','2019-05-29 07:59:59','BNBUSDT','4h','21.890100000000000','32.824399999999997','279.812949778465679','419.582011443906936','12.78262546897756','12.782625468977560','test','test','0.0'),('2019-05-29 19:59:59','2019-05-30 19:59:59','BNBUSDT','4h','33.473199999999999','32.803736000000001','310.872741259674854','304.655286434481411','9.28721309165765','9.287213091657650','test','test','1.99'),('2019-05-31 19:59:59','2019-06-03 03:59:59','BNBUSDT','4h','31.916899999999998','32.081499999999998','309.491084631854108','311.087174243639822','9.696777714372452','9.696777714372452','test','test','0.0'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BNBUSDT','4h','31.897099999999998','31.259157999999999','309.845771212250952','303.648855788005903','9.713916663654407','9.713916663654407','test','test','1.99'),('2019-06-08 11:59:59','2019-06-08 15:59:59','BNBUSDT','4h','32.249200000000002','31.722100000000001','308.468678895752021','303.426884350586533','9.565157551063344','9.565157551063344','test','test','1.63'),('2019-06-08 23:59:59','2019-06-09 03:59:59','BNBUSDT','4h','31.733300000000000','31.401900000000001','307.348280107937455','304.138553416173011','9.685355135076952','9.685355135076952','test','test','1.04'),('2019-06-10 15:59:59','2019-06-11 11:59:59','BNBUSDT','4h','31.620000000000001','31.108499999999999','306.635007509767604','301.674735329462521','9.697501818778228','9.697501818778228','test','test','1.61'),('2019-06-11 23:59:59','2019-06-14 11:59:59','BNBUSDT','4h','31.888900000000000','31.729299999999999','305.532724803033148','304.003571308288429','9.581162247773776','9.581162247773776','test','test','0.50'),('2019-06-15 07:59:59','2019-06-15 19:59:59','BNBUSDT','4h','33.049999999999997','32.847499999999997','305.192912915312093','303.322971467041270','9.234278756892953','9.234278756892953','test','test','1.45'),('2019-06-17 07:59:59','2019-06-25 23:59:59','BNBUSDT','4h','33.579999999999998','36.094099999999997','304.777370371251891','327.595738055896447','9.07615754530232','9.076157545302321','test','test','1.27'),('2019-06-26 07:59:59','2019-06-26 19:59:59','BNBUSDT','4h','37.454900000000002','36.705801999999998','309.848118745617398','303.651156370704996','8.272565638824757','8.272565638824757','test','test','2.00'),('2019-07-08 07:59:59','2019-07-08 19:59:59','BNBUSDT','4h','33.718499999999999','33.413400000000003','308.471015995636833','305.679832906820081','9.148420481208738','9.148420481208738','test','test','0.90'),('2019-07-22 07:59:59','2019-07-22 11:59:59','BNBUSDT','4h','31.940000000000001','31.301200000000001','307.850753087010901','301.693738025270704','9.63840804906108','9.638408049061081','test','test','1.99'),('2019-08-01 15:59:59','2019-08-01 19:59:59','BNBUSDT','4h','28.489899999999999','28.284800000000001','306.482527517735264','304.276146786532763','10.757585232581906','10.757585232581906','test','test','0.71'),('2019-08-01 23:59:59','2019-08-02 03:59:59','BNBUSDT','4h','28.708800000000000','28.239999999999998','305.992220688579152','300.995524447050173','10.658481743875717','10.658481743875717','test','test','1.63'),('2019-08-05 11:59:59','2019-08-05 15:59:59','BNBUSDT','4h','28.300000000000001','28.049800000000001','304.881843746017182','302.186386597421688','10.773210026361031','10.773210026361031','test','test','0.88'),('2019-08-07 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','28.730000000000000','29.267199999999999','304.282853268551492','309.972402477596574','10.5911191530996','10.591119153099600','test','test','0.0'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBUSDT','4h','28.968299999999999','28.480599999999999','305.547197537228215','300.403113547525436','10.547639921473756','10.547639921473756','test','test','1.68'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BNBUSDT','4h','28.793099999999999','28.420100000000001','304.404067761738702','300.460667527824057','10.572118589583571','10.572118589583571','test','test','1.29'),('2019-09-18 03:59:59','2019-09-19 03:59:59','BNBUSDT','4h','21.640699999999999','21.207885999999998','303.527756598646533','297.457201466673610','14.025782742639866','14.025782742639866','test','test','2.00'),('2019-10-09 07:59:59','2019-10-11 23:59:59','BNBUSDT','4h','16.963500000000000','16.624230000000001','302.178744347096995','296.135169460155055','17.813466816818288','17.813466816818288','test','test','1.99'),('2019-10-12 15:59:59','2019-10-16 15:59:59','BNBUSDT','4h','17.298600000000000','17.608799999999999','300.835727705554348','306.230340144379568','17.390755766683682','17.390755766683682','test','test','0.74'),('2019-10-17 07:59:59','2019-10-20 07:59:59','BNBUSDT','4h','18.095300000000002','17.768100000000000','302.034530469737717','296.573128980417380','16.691324845111033','16.691324845111033','test','test','1.80'),('2019-10-20 15:59:59','2019-10-23 03:59:59','BNBUSDT','4h','18.205200000000001','17.841096000000000','300.820885694333185','294.804467980446532','16.5238989791012','16.523898979101201','test','test','2.00'),('2019-10-25 15:59:59','2019-11-07 11:59:59','BNBUSDT','4h','18.433199999999999','20.150900000000000','299.483903980136176','327.391348258214862','16.246983919240076','16.246983919240076','test','test','1.28'),('2019-11-08 03:59:59','2019-11-08 11:59:59','BNBUSDT','4h','20.440100000000001','20.031298000000000','305.685558264153656','299.571847098870592','14.955188979709181','14.955188979709181','test','test','2.00'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BNBUSDT','4h','20.195900000000002','20.069600000000001','304.326955782979610','302.423772735163425','15.068749388884852','15.068749388884852','test','test','0.62'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.541799999999999','20.130963999999999','303.904026216798286','297.825945692462312','14.794420460563257','14.794420460563257','test','test','1.99'),('2019-11-12 03:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.250000000000000','20.219999999999999','302.553341655834743','302.105114483011278','14.940905760781963','14.940905760781963','test','test','0.14'),('2019-11-12 23:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.979800000000001','20.560203999999999','302.453735617429516','296.404660905080902','14.416426067809489','14.416426067809489','test','test','2.00'),('2019-12-28 19:59:59','2019-12-31 19:59:59','BNBUSDT','4h','13.693400000000000','13.668100000000001','301.109496792463176','300.553165255456349','21.989388814499186','21.989388814499186','test','test','0.58'),('2020-01-01 03:59:59','2020-01-01 15:59:59','BNBUSDT','4h','13.817000000000000','13.822300000000000','300.985867562017233','301.101321357926565','21.783735077224957','21.783735077224957','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:42:49
