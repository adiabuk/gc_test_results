-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-30 15:59:59','2019-05-30 19:59:59','RENBNB','4h','0.001030000000000','0.001009400000000','3.111111111111111','3.048888888888889','3020.4962243797195','3020.496224379719479','test','test','1.99'),('2019-05-30 23:59:59','2019-06-12 19:59:59','RENBNB','4h','0.001110000000000','0.001340000000000','3.097283950617284','3.739063507952396','2790.3459014570126','2790.345901457012587','test','test','0.0'),('2019-06-14 03:59:59','2019-06-14 15:59:59','RENBNB','4h','0.001380000000000','0.001352400000000','3.239901630025086','3.175103597424584','2347.754804366005','2347.754804366004919','test','test','2.00'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBNB','4h','0.001610000000000','0.001577800000000','3.225502067224975','3.160992025880475','2003.4174330589906','2003.417433058990582','test','test','2.00'),('2019-06-16 19:59:59','2019-06-17 15:59:59','RENBNB','4h','0.001560000000000','0.001528800000000','3.211166502481753','3.146943172432118','2058.4400656934313','2058.440065693431279','test','test','2.00'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBNB','4h','0.001410000000000','0.001381800000000','3.196894651359612','3.132956758332420','2267.3011711770296','2267.301171177029573','test','test','1.99'),('2019-06-22 03:59:59','2019-07-07 15:59:59','RENBNB','4h','0.001450000000000','0.002660000000000','3.182686230686902','5.838583016294593','2194.956021163381','2194.956021163381138','test','test','0.0'),('2019-07-09 15:59:59','2019-07-13 03:59:59','RENBNB','4h','0.002890000000000','0.002979000000000','3.772885516377500','3.889074724321305','1305.496718469723','1305.496718469722964','test','test','0.0'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBNB','4h','0.002797000000000','0.002741060000000','3.798705340365013','3.722731233557713','1358.135624013233','1358.135624013232928','test','test','1.99'),('2019-07-19 23:59:59','2019-07-20 11:59:59','RENBNB','4h','0.002821000000000','0.002764580000000','3.781822205518946','3.706185761408567','1340.5963153204345','1340.596315320434542','test','test','2.00'),('2019-07-20 15:59:59','2019-07-30 11:59:59','RENBNB','4h','0.003119000000000','0.003809000000000','3.765014106827751','4.597928417091024','1207.1221887873521','1207.122188787352115','test','test','1.79'),('2019-08-02 07:59:59','2019-08-03 23:59:59','RENBNB','4h','0.003874000000000','0.003943000000000','3.950106175775145','4.020461706525916','1019.6453731995729','1019.645373199572873','test','test','0.0'),('2019-08-04 15:59:59','2019-08-07 15:59:59','RENBNB','4h','0.004470000000000','0.004380600000000','3.965740738164205','3.886425923400921','887.1903217369586','887.190321736958595','test','test','1.99'),('2019-08-09 19:59:59','2019-08-10 03:59:59','RENBNB','4h','0.004330000000000','0.004243400000000','3.948115223772364','3.869152919296917','911.8049015640565','911.804901564056536','test','test','2.00'),('2019-08-28 03:59:59','2019-08-28 07:59:59','RENBNB','4h','0.003257000000000','0.003191860000000','3.930568045000043','3.851956684100042','1206.8062772490155','1206.806277249015466','test','test','1.99'),('2019-08-30 23:59:59','2019-08-31 03:59:59','RENBNB','4h','0.003199000000000','0.003135020000000','3.913098853688931','3.834836876615152','1223.2256497933515','1223.225649793351522','test','test','1.99'),('2019-09-19 15:59:59','2019-09-23 19:59:59','RENBNB','4h','0.002346000000000','0.002349000000000','3.895707303228091','3.900689026122244','1660.5742980511898','1660.574298051189771','test','test','0.0'),('2019-09-25 23:59:59','2019-09-26 03:59:59','RENBNB','4h','0.002406000000000','0.002371000000000','3.896814352760126','3.840127527179658','1619.6235880133524','1619.623588013352446','test','test','1.45'),('2019-09-26 19:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002406000000000','0.002408000000000','3.884217280408911','3.887446056203099','1614.3878970943106','1614.387897094310574','test','test','0.0'),('2019-09-29 19:59:59','2019-09-30 03:59:59','RENBNB','4h','0.002709000000000','0.002654820000000','3.884934786140953','3.807236090418134','1434.0844540941132','1434.084454094113198','test','test','2.00'),('2019-09-30 19:59:59','2019-10-01 03:59:59','RENBNB','4h','0.002534000000000','0.002483320000000','3.867668409313659','3.790315041127386','1526.309553793867','1526.309553793867053','test','test','2.0'),('2019-10-01 15:59:59','2019-10-16 11:59:59','RENBNB','4h','0.002545000000000','0.003018000000000','3.850478771938932','4.566108028963339','1512.958260093883','1512.958260093882927','test','test','0.0'),('2019-10-22 15:59:59','2019-10-22 19:59:59','RENBNB','4h','0.003191000000000','0.003150000000000','4.009507495722134','3.957990790198910','1256.5050127615586','1256.505012761558646','test','test','1.28'),('2019-10-24 11:59:59','2019-10-24 23:59:59','RENBNB','4h','0.003162000000000','0.003100000000000','3.998059338939195','3.919666018567838','1264.4083930863994','1264.408393086399428','test','test','1.96'),('2019-11-06 15:59:59','2019-11-07 07:59:59','RENBNB','4h','0.002875000000000','0.002817500000000','3.980638601078894','3.901025829057316','1384.5699482013542','1384.569948201354237','test','test','2.00'),('2019-11-07 15:59:59','2019-11-08 03:59:59','RENBNB','4h','0.002838000000000','0.002781240000000','3.962946873962987','3.883687936483728','1396.3872001279024','1396.387200127902361','test','test','1.99'),('2019-11-08 19:59:59','2019-11-09 03:59:59','RENBNB','4h','0.002813000000000','0.002756740000000','3.945333776745374','3.866427101210466','1402.5360031089137','1402.536003108913746','test','test','2.00'),('2019-11-09 19:59:59','2019-11-10 11:59:59','RENBNB','4h','0.002894000000000','0.002836120000000','3.927798959959839','3.849242980760642','1357.2214789080301','1357.221478908030122','test','test','2.00'),('2019-11-12 11:59:59','2019-11-12 15:59:59','RENBNB','4h','0.002950000000000','0.002891000000000','3.910342075693350','3.832135234179483','1325.539686675712','1325.539686675711891','test','test','2.00'),('2019-11-14 19:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002869000000000','0.002811620000000','3.892962777579158','3.815103522027575','1356.9058130286364','1356.905813028636430','test','test','2.00'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBNB','4h','0.002791000000000','0.002761000000000','3.875660720789917','3.834001881082393','1388.6279902507763','1388.627990250776293','test','test','1.07'),('2019-11-19 19:59:59','2019-11-19 23:59:59','RENBNB','4h','0.002783000000000','0.002819000000000','3.866403200854912','3.916417758968738','1389.2932809396018','1389.293280939601800','test','test','0.0'),('2019-11-23 19:59:59','2019-11-24 03:59:59','RENBNB','4h','0.002925000000000','0.002866500000000','3.877517547102429','3.799967196160380','1325.647024650403','1325.647024650402955','test','test','1.99'),('2019-11-24 19:59:59','2019-11-24 23:59:59','RENBNB','4h','0.002839000000000','0.002824000000000','3.860284135781974','3.839888129428776','1359.733756879878','1359.733756879878001','test','test','0.52'),('2019-12-07 07:59:59','2019-12-07 15:59:59','RENBNB','4h','0.002567000000000','0.002518000000000','3.855751689925707','3.782151443409790','1502.0458472636178','1502.045847263617816','test','test','1.90'),('2019-12-14 15:59:59','2019-12-15 03:59:59','RENBNB','4h','0.002457000000000','0.002448000000000','3.839396079588837','3.825332357685582','1562.6357670284237','1562.635767028423743','test','test','0.36'),('2019-12-18 19:59:59','2019-12-18 23:59:59','RENBNB','4h','0.002455000000000','0.002405900000000','3.836270808054780','3.759545391893685','1562.6357670284235','1562.635767028423516','test','test','1.99'),('2019-12-22 07:59:59','2019-12-22 19:59:59','RENBNB','4h','0.002502000000000','0.002451960000000','3.819220715574537','3.742836301263047','1526.4671125397833','1526.467112539783329','test','test','1.99'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','3.802246401283095','3.817951673489965','1570.5272206869454','1570.527220686945384','test','test','0.0'),('2019-12-24 07:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','3.805736461773510','3.807277245766131','1540.7839926208544','1540.783992620854406','test','test','0.0'),('2020-01-02 03:59:59','2020-01-05 15:59:59','RENBNB','4h','0.002390000000000','0.002452000000000','3.806078858216315','3.904813958303935','1592.5016143164496','1592.501614316449604','test','test','0.0'),('2020-01-06 07:59:59','2020-01-06 11:59:59','RENBNB','4h','0.002678000000000','0.002624440000000','3.828019991569120','3.751459591737737','1429.432409099746','1429.432409099746110','test','test','2.00'),('2020-01-06 15:59:59','2020-01-06 19:59:59','RENBNB','4h','0.002644000000000','0.002591120000000','3.811006569384368','3.734786437996680','1441.3791866052827','1441.379186605282712','test','test','1.99'),('2020-01-06 23:59:59','2020-01-07 19:59:59','RENBNB','4h','0.002679000000000','0.002625420000000','3.794068762409326','3.718187387161140','1416.2257418474528','1416.225741847452809','test','test','2.00'),('2020-01-08 07:59:59','2020-01-08 11:59:59','RENBNB','4h','0.002631000000000','0.002578380000000','3.777206234576395','3.701662109884867','1435.6542130659047','1435.654213065904742','test','test','2.00'),('2020-01-08 19:59:59','2020-01-08 23:59:59','RENBNB','4h','0.002850000000000','0.002793000000000','3.760418651311612','3.685210278285379','1319.445140811092','1319.445140811091960','test','test','2.00'),('2020-01-11 15:59:59','2020-01-12 23:59:59','RENBNB','4h','0.003037000000000','0.002976260000000','3.743705679528004','3.668831565937444','1232.698610315444','1232.698610315444057','test','test','2.00'),('2020-01-13 07:59:59','2020-01-14 11:59:59','RENBNB','4h','0.002920000000000','0.002861600000000','3.727066987618990','3.652525647866610','1276.3928039791062','1276.392803979106247','test','test','2.00'),('2020-02-02 23:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002507000000000','0.002628000000000','3.710502245451795','3.889589110908383','1480.0567393106483','1480.056739310648254','test','test','0.91'),('2020-02-08 11:59:59','2020-02-08 19:59:59','RENBNB','4h','0.002907000000000','0.002848860000000','3.750299326664371','3.675293340131084','1290.0926476313625','1290.092647631362524','test','test','1.99'),('2020-02-14 11:59:59','2020-02-14 19:59:59','RENBNB','4h','0.002590000000000','0.002551000000000','3.733631329656973','3.677410626237428','1441.5564979370554','1441.556497937055383','test','test','1.50'),('2020-02-15 19:59:59','2020-02-15 23:59:59','RENBNB','4h','0.002538000000000','0.002498000000000','3.721137840008186','3.662491065539971','1466.169361705353','1466.169361705352912','test','test','1.57'),('2020-02-16 03:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002542000000000','0.002491160000000','3.708105223459694','3.633943118990500','1458.7353357433885','1458.735335743388532','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:54:06
