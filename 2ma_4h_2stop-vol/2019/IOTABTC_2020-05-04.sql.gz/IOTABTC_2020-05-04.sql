-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-06 07:59:59','IOTABTC','4h','0.000095100000000','0.000093400000000','0.033333333333333','0.032737469330529','350.5082369435682','350.508236943568193','test','test','1.78'),('2019-01-19 11:59:59','2019-01-19 19:59:59','IOTABTC','4h','0.000085130000000','0.000084920000000','0.033200919110488','0.033119018569983','390.002573833995','390.002573833994973','test','test','0.24'),('2019-02-08 11:59:59','2019-02-09 19:59:59','IOTABTC','4h','0.000075090000000','0.000075110000000','0.033182718990376','0.033191557109697','441.9059660457554','441.905966045755406','test','test','0.06'),('2019-02-10 03:59:59','2019-02-10 15:59:59','IOTABTC','4h','0.000076270000000','0.000075220000000','0.033184683016892','0.032727833440810','435.09483436333494','435.094834363334940','test','test','1.37'),('2019-02-12 19:59:59','2019-02-12 23:59:59','IOTABTC','4h','0.000075220000000','0.000075310000000','0.033083160888873','0.033122744569809','439.81867706558535','439.818677065585348','test','test','0.0'),('2019-02-15 11:59:59','2019-02-16 03:59:59','IOTABTC','4h','0.000075640000000','0.000074650000000','0.033091957262415','0.032658839365934','437.4928247278512','437.492824727851200','test','test','1.30'),('2019-02-16 11:59:59','2019-02-16 15:59:59','IOTABTC','4h','0.000075710000000','0.000074990000000','0.032995708840974','0.032681920565112','435.81704980814203','435.817049808142031','test','test','0.95'),('2019-02-16 23:59:59','2019-02-18 03:59:59','IOTABTC','4h','0.000075730000000','0.000074720000000','0.032925978113005','0.032486849129853','434.7811714380709','434.781171438070885','test','test','1.33'),('2019-02-18 07:59:59','2019-02-21 19:59:59','IOTABTC','4h','0.000075440000000','0.000076050000000','0.032828393894527','0.033093840875912','435.1589858765494','435.158985876549423','test','test','0.0'),('2019-02-23 19:59:59','2019-02-24 07:59:59','IOTABTC','4h','0.000077130000000','0.000076770000000','0.032887382112612','0.032733882079414','426.3889811047898','426.388981104789821','test','test','0.46'),('2019-02-24 11:59:59','2019-02-24 15:59:59','IOTABTC','4h','0.000077510000000','0.000075959800000','0.032853270994124','0.032196205574242','423.8584827006063','423.858482700606316','test','test','1.99'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTABTC','4h','0.000076390000000','0.000075390000000','0.032707256456372','0.032279094963292','428.16149307988525','428.161493079885247','test','test','1.30'),('2019-03-13 03:59:59','2019-03-13 11:59:59','IOTABTC','4h','0.000073980000000','0.000072570000000','0.032612109457910','0.031990548572054','440.82332330238194','440.823323302381937','test','test','1.90'),('2019-03-13 15:59:59','2019-03-17 11:59:59','IOTABTC','4h','0.000073190000000','0.000074870000000','0.032473984816609','0.033219391217646','443.6942863315874','443.694286331587421','test','test','0.0'),('2019-03-20 15:59:59','2019-03-20 19:59:59','IOTABTC','4h','0.000075210000000','0.000073705800000','0.032639630683506','0.031986838069836','433.97993197056235','433.979931970562347','test','test','2.00'),('2019-03-21 19:59:59','2019-03-25 03:59:59','IOTABTC','4h','0.000076620000000','0.000076100000000','0.032494565658246','0.032274033497684','424.1003087737666','424.100308773766585','test','test','0.67'),('2019-03-28 15:59:59','2019-03-28 19:59:59','IOTABTC','4h','0.000075790000000','0.000075330000000','0.032445558511454','0.032248633364135','428.09814634456313','428.098146344563133','test','test','0.60'),('2019-04-01 07:59:59','2019-04-02 07:59:59','IOTABTC','4h','0.000075500000000','0.000073990000000','0.032401797367606','0.031753761420254','429.1628790411361','429.162879041136080','test','test','2.00'),('2019-04-29 03:59:59','2019-04-30 03:59:59','IOTABTC','4h','0.000057930000000','0.000056771400000','0.032257789379305','0.031612633591719','556.8408316814316','556.840831681431609','test','test','1.99'),('2019-05-14 23:59:59','2019-05-22 23:59:59','IOTABTC','4h','0.000047020000000','0.000050180000000','0.032114421426508','0.034272685393070','682.9949261273595','682.994926127359463','test','test','0.0'),('2019-05-27 23:59:59','2019-05-28 03:59:59','IOTABTC','4h','0.000049500000000','0.000048990000000','0.032594035641300','0.032258218304390','658.4653664909091','658.465366490909105','test','test','1.03'),('2019-05-28 11:59:59','2019-05-28 15:59:59','IOTABTC','4h','0.000049340000000','0.000051670000000','0.032519409566431','0.034055084967521','659.0881549742826','659.088154974282588','test','test','0.0'),('2019-05-28 19:59:59','2019-06-03 23:59:59','IOTABTC','4h','0.000055040000000','0.000054800000000','0.032860670766673','0.032717382958097','597.0325357317103','597.032535731710254','test','test','0.43'),('2019-06-07 11:59:59','2019-06-07 15:59:59','IOTABTC','4h','0.000054640000000','0.000055770000000','0.032828829031434','0.033507756132560','600.8204434742721','600.820443474272111','test','test','0.0'),('2019-06-07 19:59:59','2019-06-08 03:59:59','IOTABTC','4h','0.000055770000000','0.000054654600000','0.032979701720573','0.032320107686162','591.3520122032155','591.352012203215509','test','test','1.99'),('2019-06-13 15:59:59','2019-06-13 19:59:59','IOTABTC','4h','0.000054240000000','0.000053710000000','0.032833125268482','0.032512300113757','605.3304806136061','605.330480613606142','test','test','0.97'),('2019-07-02 07:59:59','2019-07-02 11:59:59','IOTABTC','4h','0.000039340000000','0.000038553200000','0.032761830789654','0.032106594173861','832.7867511350845','832.786751135084501','test','test','2.00'),('2019-07-20 07:59:59','2019-07-20 19:59:59','IOTABTC','4h','0.000030740000000','0.000030190000000','0.032616222652811','0.032032653281990','1061.0352196750596','1061.035219675059579','test','test','1.78'),('2019-07-24 11:59:59','2019-07-25 07:59:59','IOTABTC','4h','0.000030740000000','0.000030250000000','0.032486540570407','0.031968700463722','1056.816544255259','1056.816544255259032','test','test','1.59'),('2019-07-25 15:59:59','2019-07-26 23:59:59','IOTABTC','4h','0.000030720000000','0.000030520000000','0.032371464991143','0.032160713265940','1053.7586260137803','1053.758626013780258','test','test','0.78'),('2019-08-18 19:59:59','2019-08-19 07:59:59','IOTABTC','4h','0.000024100000000','0.000023618000000','0.032324631274432','0.031678138648943','1341.271007237824','1341.271007237824051','test','test','1.99'),('2019-08-22 07:59:59','2019-08-28 19:59:59','IOTABTC','4h','0.000024010000000','0.000025130000000','0.032180966246545','0.033682119190990','1340.3151289689758','1340.315128968975841','test','test','0.0'),('2019-08-29 15:59:59','2019-09-01 19:59:59','IOTABTC','4h','0.000025990000000','0.000025470200000','0.032514555789755','0.031864264673960','1251.0410076858452','1251.041007685845216','test','test','2.00'),('2019-09-10 19:59:59','2019-09-10 23:59:59','IOTABTC','4h','0.000023890000000','0.000023610000000','0.032370046652912','0.031990657240488','1354.9621872294592','1354.962187229459232','test','test','1.17'),('2019-09-13 19:59:59','2019-09-13 23:59:59','IOTABTC','4h','0.000023660000000','0.000023370000000','0.032285737894595','0.031890012451255','1364.5704942770642','1364.570494277064199','test','test','1.22'),('2019-09-14 15:59:59','2019-10-09 15:59:59','IOTABTC','4h','0.000023770000000','0.000032380000000','0.032197798907186','0.043860527076764','1354.5561172564767','1354.556117256476682','test','test','0.21'),('2019-10-13 11:59:59','2019-10-18 11:59:59','IOTABTC','4h','0.000033630000000','0.000033840000000','0.034789516278204','0.035006756790200','1034.4786285520006','1034.478628552000600','test','test','0.98'),('2019-10-20 11:59:59','2019-10-20 19:59:59','IOTABTC','4h','0.000033740000000','0.000033065200000','0.034837791947536','0.034141036108585','1032.5368093519924','1032.536809351992360','test','test','2.00'),('2019-10-22 23:59:59','2019-10-23 11:59:59','IOTABTC','4h','0.000033580000000','0.000033190000000','0.034682957316658','0.034280147508632','1032.8456616038782','1032.845661603878170','test','test','1.16'),('2019-10-23 15:59:59','2019-10-23 19:59:59','IOTABTC','4h','0.000033480000000','0.000033960000000','0.034593444025986','0.035089407381197','1033.25699002347','1033.256990023470053','test','test','0.0'),('2019-10-23 23:59:59','2019-10-25 11:59:59','IOTABTC','4h','0.000033930000000','0.000033720000000','0.034703658104922','0.034488869770055','1022.8015946042311','1022.801594604231127','test','test','0.61'),('2019-11-09 19:59:59','2019-11-10 15:59:59','IOTABTC','4h','0.000030340000000','0.000030050000000','0.034655927363840','0.034324674267745','1142.2520554990112','1142.252055499011249','test','test','0.95'),('2019-11-14 07:59:59','2019-11-15 15:59:59','IOTABTC','4h','0.000030590000000','0.000030090000000','0.034582315564708','0.034017060325010','1130.5104793954815','1130.510479395481525','test','test','1.63'),('2019-11-18 07:59:59','2019-11-18 19:59:59','IOTABTC','4h','0.000030520000000','0.000030260000000','0.034456703289219','0.034163166498420','1128.987656920686','1128.987656920686049','test','test','1.37');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:58:47
