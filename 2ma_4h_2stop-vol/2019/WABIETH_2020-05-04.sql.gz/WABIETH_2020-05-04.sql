-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-10 11:59:59','WABIETH','4h','0.000883470000000','0.000889250000000','1.297777777777778','1.306268338357713','1468.9551176358877','1468.955117635887746','test','test','0.0'),('2019-01-10 15:59:59','2019-01-10 19:59:59','WABIETH','4h','0.000901060000000','0.000893170000000','1.299664569017763','1.288284246453727','1442.372948547004','1442.372948547003944','test','test','0.87'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','1.297135608447977','1.294977481626114','1448.4072629951957','1448.407262995195651','test','test','0.16'),('2019-01-12 15:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000903010000000','0.000884949800000','1.296656024709786','1.270722904215590','1435.9265398055234','1435.926539805523362','test','test','2.00'),('2019-01-14 23:59:59','2019-01-15 15:59:59','WABIETH','4h','0.000910970000000','0.000898390000000','1.290893109044409','1.273066577641861','1417.053370631754','1417.053370631753978','test','test','1.38'),('2019-01-15 23:59:59','2019-01-26 15:59:59','WABIETH','4h','0.000930000000000','0.001090140000000','1.286931657621621','1.508532986279176','1383.7974813135704','1383.797481313570415','test','test','0.69'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001082586400000','1.336176397323299','1.309452869376833','1209.559689071314','1209.559689071314097','test','test','1.99'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WABIETH','4h','0.001124740000000','0.001102245200000','1.330237835557418','1.303633078846270','1182.7069683281632','1182.706968328163157','test','test','1.99'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WABIETH','4h','0.001106880000000','0.001084742400000','1.324325667399385','1.297839154051397','1196.4491791335872','1196.449179133587222','test','test','1.99'),('2019-02-06 03:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001097280000000','0.001075334400000','1.318439775544277','1.292070980033391','1201.5527263271697','1201.552726327169694','test','test','1.99'),('2019-02-07 07:59:59','2019-02-08 15:59:59','WABIETH','4h','0.001097950000000','0.001156610000000','1.312580043208524','1.382707048386002','1195.482529448995','1195.482529448994910','test','test','1.69'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001106165200000','1.328163822136853','1.301600545694116','1176.678262608619','1176.678262608618979','test','test','2.00'),('2019-02-10 15:59:59','2019-02-10 23:59:59','WABIETH','4h','0.001186710000000','0.001162975800000','1.322260871816245','1.295815654379920','1114.2240916620274','1114.224091662027377','test','test','1.99'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.000999600000000','1.316384156830394','1.290056473693786','1290.5727027748965','1290.572702774896470','test','test','2.00'),('2019-02-26 11:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001052200000000','0.001437200000000','1.310533560577815','1.790057815303588','1245.5175447422685','1245.517544742268456','test','test','0.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','1.417094506072431','1.572416928198493','942.2045624874875','942.204562487487465','test','test','0.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIETH','4h','0.001643980000000','0.001636520000000','1.451610599878222','1.445023527605389','882.9855593609549','882.985559360954881','test','test','0.45'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001614481400000','1.450146806039815','1.421143869919019','880.2479049427384','880.247904942738387','test','test','2.00'),('2019-03-27 15:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001723340000000','0.002100820000000','1.443701709124083','1.759929801758246','837.7346949087719','837.734694908771871','test','test','0.77'),('2019-04-03 15:59:59','2019-04-03 19:59:59','WABIETH','4h','0.002088000000000','0.002046240000000','1.513974618598341','1.483695126226374','725.0836295969068','725.083629596906803','test','test','2.00'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','1.507245842515682','1.762844165059848','767.3781750455322','767.378175045532203','test','test','0.0'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','1.564045469747719','1.562980301146428','687.2055492202021','687.205549220202101','test','test','0.06'),('2019-04-25 03:59:59','2019-04-25 23:59:59','WABIETH','4h','0.002315670000000','0.002269356600000','1.563808765614099','1.532532590301817','675.3158980399188','675.315898039918807','test','test','2.00'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','1.556858504433592','1.561702952096442','713.4679915831499','713.467991583149910','test','test','0.0'),('2019-04-30 15:59:59','2019-04-30 23:59:59','WABIETH','4h','0.002225550000000','0.002191720000000','1.557935048358670','1.534253287586738','700.0224880854933','700.022488085493251','test','test','1.52'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIETH','4h','0.002254760000000','0.002209664800000','1.552672434853796','1.521618986156720','688.6198242180079','688.619824218007921','test','test','1.99'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001420853000000','1.545771668476668','1.514856235107135','1066.159718920349','1066.159718920348951','test','test','2.00'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','1.538901572172327','1.554231974835107','1083.4206828819335','1083.420682881933544','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001443383200000','1.542308328319612','1.511462161753220','1047.1662423071152','1047.166242307115226','test','test','2.00'),('2019-05-24 11:59:59','2019-05-24 15:59:59','WABIETH','4h','0.001432390000000','0.001403742200000','1.535453624638191','1.504744552145427','1071.952208992098','1071.952208992097894','test','test','1.99'),('2019-06-08 03:59:59','2019-06-09 23:59:59','WABIETH','4h','0.001291660000000','0.001265826800000','1.528629386306465','1.498056798580335','1183.4611169398027','1183.461116939802650','test','test','2.00'),('2019-06-10 03:59:59','2019-06-13 07:59:59','WABIETH','4h','0.001281060000000','0.001269100000000','1.521835477922881','1.507627593580260','1187.9501958712951','1187.950195871295136','test','test','0.93'),('2019-07-20 23:59:59','2019-07-27 03:59:59','WABIETH','4h','0.000651430000000','0.000692960000000','1.518678170291188','1.615497021759792','2331.2990962823137','2331.299096282313712','test','test','1.25'),('2019-07-28 19:59:59','2019-07-28 23:59:59','WABIETH','4h','0.000733970000000','0.000719290600000','1.540193470617544','1.509389601205193','2098.4419943833454','2098.441994383345445','test','test','2.0'),('2019-07-29 19:59:59','2019-07-29 23:59:59','WABIETH','4h','0.000705440000000','0.000699300000000','1.533348166303688','1.520002229383320','2173.605361623509','2173.605361623508998','test','test','0.87'),('2019-08-15 15:59:59','2019-08-15 23:59:59','WABIETH','4h','0.000597260000000','0.000585314800000','1.530382402543607','1.499774754492735','2562.3386842306645','2562.338684230664512','test','test','2.00'),('2019-08-17 19:59:59','2019-08-18 11:59:59','WABIETH','4h','0.000575570000000','0.000564058600000','1.523580702976746','1.493109088917211','2647.0815069874143','2647.081506987414286','test','test','1.99'),('2019-08-21 19:59:59','2019-08-21 23:59:59','WABIETH','4h','0.000566150000000','0.000567330000000','1.516809233185738','1.519970647819950','2679.1649442475286','2679.164944247528638','test','test','0.0'),('2019-08-22 19:59:59','2019-08-23 15:59:59','WABIETH','4h','0.000576070000000','0.000564548600000','1.517511769771119','1.487161534375697','2634.24891032534','2634.248910325340148','test','test','2.00'),('2019-08-24 03:59:59','2019-09-10 19:59:59','WABIETH','4h','0.000602270000000','0.000958300000000','1.510767273016580','2.403852554056800','2508.4551331073776','2508.455133107377605','test','test','0.0'),('2019-09-11 11:59:59','2019-09-11 15:59:59','WABIETH','4h','0.000989690000000','0.000969896200000','1.709230668803296','1.675046055427230','1727.036414234049','1727.036414234049062','test','test','1.99'),('2019-09-29 07:59:59','2019-09-29 11:59:59','WABIETH','4h','0.000749980000000','0.000734980400000','1.701634088053059','1.667601406291998','2268.9059548962096','2268.905954896209550','test','test','2.00'),('2019-10-01 11:59:59','2019-10-02 15:59:59','WABIETH','4h','0.000713490000000','0.000699220200000','1.694071269883935','1.660189844486257','2374.3447979424163','2374.344797942416335','test','test','1.99'),('2019-10-03 07:59:59','2019-10-03 23:59:59','WABIETH','4h','0.000694070000000','0.000691400000000','1.686542064240006','1.680054149027533','2429.930791188218','2429.930791188217881','test','test','0.38'),('2019-10-04 15:59:59','2019-10-06 11:59:59','WABIETH','4h','0.000712200000000','0.000717200000000','1.685100305303901','1.696930551760682','2366.0492913562216','2366.049291356221602','test','test','0.0'),('2019-10-06 15:59:59','2019-10-07 03:59:59','WABIETH','4h','0.000736930000000','0.000722191400000','1.687729248960963','1.653974663981744','2290.2165049067935','2290.216504906793489','test','test','2.00'),('2019-10-07 11:59:59','2019-10-07 19:59:59','WABIETH','4h','0.000764380000000','0.000749092400000','1.680228230076692','1.646623665475158','2198.1582852464644','2198.158285246464402','test','test','1.99'),('2019-10-07 23:59:59','2019-10-08 07:59:59','WABIETH','4h','0.000748930000000','0.000733951400000','1.672760549054130','1.639305338073047','2233.5339071129874','2233.533907112987436','test','test','2.00'),('2019-10-12 19:59:59','2019-10-13 03:59:59','WABIETH','4h','0.000737850000000','0.000723093000000','1.665326057725000','1.632019536570500','2256.9981130649862','2256.998113064986228','test','test','2.00'),('2019-10-14 15:59:59','2019-10-14 23:59:59','WABIETH','4h','0.000715580000000','0.000701268400000','1.657924608579555','1.624766116407964','2316.896236031688','2316.896236031688204','test','test','2.00'),('2019-10-15 07:59:59','2019-10-15 19:59:59','WABIETH','4h','0.000707480000000','0.000705990000000','1.650556054763646','1.647079873781006','2333.007370899031','2333.007370899030775','test','test','0.21'),('2019-10-19 11:59:59','2019-10-19 23:59:59','WABIETH','4h','0.000690340000000','0.000699630000000','1.649783570100837','1.671984933727799','2389.813092245614','2389.813092245613916','test','test','0.0'),('2019-10-20 11:59:59','2019-10-23 15:59:59','WABIETH','4h','0.000700070000000','0.000744490000000','1.654717206462385','1.759710333308356','2363.645358981794','2363.645358981793834','test','test','0.78'),('2019-10-24 15:59:59','2019-10-24 23:59:59','WABIETH','4h','0.000845150000000','0.000828247000000','1.678049012428156','1.644488032179593','1985.5043630457974','1985.504363045797390','test','test','1.99'),('2019-10-27 15:59:59','2019-10-27 19:59:59','WABIETH','4h','0.000821270000000','0.000804844600000','1.670591016817364','1.637179196481017','2034.1556574784956','2034.155657478495641','test','test','2.00'),('2019-10-28 03:59:59','2019-10-28 07:59:59','WABIETH','4h','0.000861050000000','0.000843829000000','1.663166167853731','1.629902844496656','1931.5558537294364','1931.555853729436421','test','test','1.99'),('2019-10-29 07:59:59','2019-11-05 15:59:59','WABIETH','4h','0.000836230000000','0.000881740000000','1.655774318218826','1.745886236258287','1980.0465400892408','1980.046540089240807','test','test','1.27'),('2019-11-05 19:59:59','2019-11-06 07:59:59','WABIETH','4h','0.000946680000000','0.000927746400000','1.675799188894262','1.642283205116377','1770.185478613958','1770.185478613957912','test','test','2.00'),('2019-11-06 11:59:59','2019-11-07 11:59:59','WABIETH','4h','0.000942870000000','0.000924012600000','1.668351192499176','1.634984168649193','1769.4392572668303','1769.439257266830282','test','test','1.99'),('2019-11-10 11:59:59','2019-11-11 07:59:59','WABIETH','4h','0.000913630000000','0.001036930000000','1.660936298310291','1.885089889568961','1817.9528893647218','1817.952889364721841','test','test','0.58'),('2019-11-11 11:59:59','2019-11-11 15:59:59','WABIETH','4h','0.001111970000000','0.001089730600000','1.710748207478884','1.676533243329306','1538.4841384919414','1538.484138491941394','test','test','1.99'),('2019-11-11 19:59:59','2019-11-11 23:59:59','WABIETH','4h','0.001138640000000','0.001115867200000','1.703144882112311','1.669081984470065','1495.7711674561856','1495.771167456185594','test','test','1.99'),('2019-11-12 19:59:59','2019-11-12 23:59:59','WABIETH','4h','0.001175180000000','0.001151676400000','1.695575349302923','1.661663842316865','1442.8218224467087','1442.821822446708666','test','test','2.00'),('2019-11-18 03:59:59','2019-11-18 11:59:59','WABIETH','4h','0.001124180000000','0.001101696400000','1.688039458861577','1.654278669684345','1501.5739995922156','1501.573999592215614','test','test','1.99'),('2019-11-19 03:59:59','2019-11-21 11:59:59','WABIETH','4h','0.001133640000000','0.001110967200000','1.680537061266637','1.646926320041304','1482.4256918127771','1482.425691812777131','test','test','2.00'),('2019-11-23 11:59:59','2019-11-24 11:59:59','WABIETH','4h','0.001180270000000','0.001156664600000','1.673068007661007','1.639606647507787','1417.5298937200869','1417.529893720086875','test','test','2.00'),('2019-11-25 07:59:59','2019-11-25 11:59:59','WABIETH','4h','0.001189190000000','0.001165406200000','1.665632149849180','1.632319506852197','1400.644261933905','1400.644261933905000','test','test','1.99'),('2019-11-26 11:59:59','2019-11-30 07:59:59','WABIETH','4h','0.001186240000000','0.001166710000000','1.658229340294295','1.630928609400085','1397.886886544287','1397.886886544287108','test','test','1.71'),('2019-12-03 23:59:59','2019-12-04 03:59:59','WABIETH','4h','0.001164080000000','0.001143930000000','1.652162511206693','1.623563897193210','1419.2860552596842','1419.286055259684190','test','test','1.73'),('2019-12-04 11:59:59','2019-12-04 15:59:59','WABIETH','4h','0.001174070000000','0.001150588600000','1.645807263648141','1.612891118375178','1401.7965399406692','1401.796539940669163','test','test','2.00'),('2019-12-07 03:59:59','2019-12-07 07:59:59','WABIETH','4h','0.001133850000000','0.001136250000000','1.638492564698594','1.641960732582597','1445.069951667852','1445.069951667851910','test','test','0.0'),('2019-12-15 03:59:59','2019-12-15 07:59:59','WABIETH','4h','0.001066460000000','0.001116990000000','1.639263268672817','1.716933291895476','1537.1071288869875','1537.107128886987539','test','test','0.0'),('2019-12-15 11:59:59','2019-12-16 07:59:59','WABIETH','4h','0.001117000000000','0.001094660000000','1.656523273833408','1.623392808356740','1483.0109882125405','1483.010988212540497','test','test','2.00'),('2019-12-16 23:59:59','2019-12-18 03:59:59','WABIETH','4h','0.001186980000000','0.001163240400000','1.649160948171926','1.616177729208488','1389.375514475329','1389.375514475329055','test','test','2.00'),('2019-12-19 11:59:59','2019-12-21 23:59:59','WABIETH','4h','0.001146510000000','0.001150000000000','1.641831343957829','1.646829112307353','1432.025315049872','1432.025315049872006','test','test','0.0'),('2019-12-22 23:59:59','2019-12-23 03:59:59','WABIETH','4h','0.001156290000000','0.001133164200000','1.642941959146612','1.610083119963680','1420.8736209312644','1420.873620931264441','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:02:04
