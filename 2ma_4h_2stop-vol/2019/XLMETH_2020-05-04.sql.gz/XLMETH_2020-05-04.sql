-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 15:59:59','2019-01-08 19:59:59','XLMETH','4h','0.000826140000000','0.000821090000000','1.297777777777778','1.289844766692759','1570.8932841622216','1570.893284162221562','test','test','0.61'),('2019-01-10 03:59:59','2019-01-10 19:59:59','XLMETH','4h','0.000845590000000','0.000838510000000','1.296014886425551','1.285163545473207','1532.6752757548593','1532.675275754859285','test','test','0.83'),('2019-01-13 03:59:59','2019-01-13 07:59:59','XLMETH','4h','0.000895190000000','0.000877286200000','1.293603477325030','1.267731407778529','1445.0602412058115','1445.060241205811508','test','test','2.00'),('2019-01-13 19:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000898290000000','0.000880324200000','1.287854128536919','1.262097045966180','1433.6730104275002','1433.673010427500230','test','test','2.00'),('2019-01-15 23:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000871000000000','0.000857130000000','1.282130332410088','1.261713400480664','1472.021047543155','1472.021047543154964','test','test','1.59'),('2019-01-20 03:59:59','2019-01-22 19:59:59','XLMETH','4h','0.000876270000000','0.000868190000000','1.277593236425772','1.265812674098727','1457.9903870105927','1457.990387010592713','test','test','0.92'),('2019-01-23 03:59:59','2019-01-23 07:59:59','XLMETH','4h','0.000868160000000','0.000862540000000','1.274975333686428','1.266721830443572','1468.5948830704347','1468.594883070434662','test','test','0.64'),('2019-01-26 07:59:59','2019-01-26 15:59:59','XLMETH','4h','0.000877000000000','0.000868340000000','1.273141221854683','1.260569496676506','1451.7003669950773','1451.700366995077275','test','test','0.98'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMETH','4h','0.000624170000000','0.000625000000000','1.270347505148421','1.272036769978953','2035.2588319663253','2035.258831966325261','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XLMETH','4h','0.000623190000000','0.000616450000000','1.270722897332984','1.256979621080117','2039.061758585638','2039.061758585638017','test','test','1.08'),('2019-03-01 23:59:59','2019-03-03 11:59:59','XLMETH','4h','0.000626160000000','0.000623630000000','1.267668835943458','1.262546818959082','2024.5126420458955','2024.512642045895518','test','test','0.40'),('2019-03-03 15:59:59','2019-03-05 07:59:59','XLMETH','4h','0.000660150000000','0.000646947000000','1.266530609946930','1.241199997747991','1918.54973861536','1918.549738615359956','test','test','2.00'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMETH','4h','0.000639150000000','0.000772780000000','1.260901585013832','1.524524019192661','1972.7788234590196','1972.778823459019577','test','test','0.29'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMETH','4h','0.000796010000000','0.000780089800000','1.319484348164683','1.293094661201389','1657.6228290658198','1657.622829065819815','test','test','2.00'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMETH','4h','0.000771150000000','0.000775680000000','1.313619973283951','1.321336628252474','1703.4558429409988','1703.455842940998764','test','test','0.25'),('2019-04-05 07:59:59','2019-04-05 15:59:59','XLMETH','4h','0.000772350000000','0.000766430000000','1.315334785499179','1.305252851233425','1703.029436782778','1703.029436782778021','test','test','0.76'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XLMETH','4h','0.000569580000000','0.000566480000000','1.313094355662344','1.305947699349704','2305.3730040772925','2305.373004077292535','test','test','0.82'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMETH','4h','0.000514910000000','0.000510000000000','1.311506209815091','1.299000149551759','2547.059116768155','2547.059116768155036','test','test','0.95'),('2019-06-03 23:59:59','2019-06-04 03:59:59','XLMETH','4h','0.000510000000000','0.000506790000000','1.308727085312128','1.300489803069281','2566.131539827702','2566.131539827701999','test','test','0.62'),('2019-06-05 03:59:59','2019-06-05 07:59:59','XLMETH','4h','0.000510330000000','0.000504210000000','1.306896578147051','1.291223960314942','2560.885266684402','2560.885266684401813','test','test','1.19'),('2019-06-07 07:59:59','2019-06-08 19:59:59','XLMETH','4h','0.000512970000000','0.000507300000000','1.303413774184360','1.289006779429062','2540.916182592277','2540.916182592276982','test','test','1.10'),('2019-06-08 23:59:59','2019-06-10 03:59:59','XLMETH','4h','0.000509530000000','0.000505000000000','1.300212219794294','1.288652622997897','2551.787372273063','2551.787372273062829','test','test','0.88'),('2019-07-12 07:59:59','2019-07-13 11:59:59','XLMETH','4h','0.000359660000000','0.000352466800000','1.297643420506206','1.271690552096082','3607.972586626831','3607.972586626830889','test','test','2.00'),('2019-07-14 11:59:59','2019-07-24 23:59:59','XLMETH','4h','0.000360310000000','0.000396380000000','1.291876116415067','1.421203560890911','3585.457290708187','3585.457290708186974','test','test','0.0'),('2019-07-27 11:59:59','2019-07-28 23:59:59','XLMETH','4h','0.000404290000000','0.000398200000000','1.320615548520810','1.300722529424390','3266.5055987553746','3266.505598755374649','test','test','1.50'),('2019-08-11 15:59:59','2019-08-11 23:59:59','XLMETH','4h','0.000369410000000','0.000362021800000','1.316194877610495','1.289870980058285','3562.9649376316142','3562.964937631614248','test','test','2.00'),('2019-08-14 19:59:59','2019-08-17 23:59:59','XLMETH','4h','0.000367900000000','0.000363850000000','1.310345122598892','1.295920285016599','3561.688291924144','3561.688291924143869','test','test','1.10'),('2019-08-18 11:59:59','2019-08-18 15:59:59','XLMETH','4h','0.000368000000000','0.000365680000000','1.307139603136161','1.298898940420738','3552.0097911308712','3552.009791130871236','test','test','0.63'),('2019-08-24 23:59:59','2019-08-27 15:59:59','XLMETH','4h','0.000368480000000','0.000361960000000','1.305308344754956','1.282211811950456','3542.4130068252157','3542.413006825215689','test','test','1.76'),('2019-08-28 19:59:59','2019-08-29 03:59:59','XLMETH','4h','0.000371480000000','0.000368850000000','1.300175781909511','1.290970811772701','3499.988645174737','3499.988645174737030','test','test','0.70'),('2019-08-29 11:59:59','2019-08-29 19:59:59','XLMETH','4h','0.000370930000000','0.000363511400000','1.298130232990220','1.272167628330416','3499.663637317607','3499.663637317607026','test','test','2.00'),('2019-08-30 07:59:59','2019-08-30 23:59:59','XLMETH','4h','0.000373590000000','0.000367760000000','1.292360765288041','1.272193032582055','3459.302350940982','3459.302350940981796','test','test','1.59'),('2019-09-18 07:59:59','2019-09-20 15:59:59','XLMETH','4h','0.000327170000000','0.000336960000000','1.287879046908933','1.326416614134652','3936.4215756607678','3936.421575660767758','test','test','0.0'),('2019-09-25 23:59:59','2019-09-27 23:59:59','XLMETH','4h','0.000337630000000','0.000338480000000','1.296442950736871','1.299706809126607','3839.8333996886263','3839.833399688626287','test','test','0.0'),('2019-09-30 07:59:59','2019-10-01 03:59:59','XLMETH','4h','0.000344060000000','0.000337178800000','1.297168252601257','1.271224887549232','3770.1803540116744','3770.180354011674353','test','test','1.99'),('2019-10-06 15:59:59','2019-10-09 03:59:59','XLMETH','4h','0.000340200000000','0.000341250000000','1.291403060367473','1.295388872282188','3796.0113473470706','3796.011347347070569','test','test','0.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','XLMETH','4h','0.000345860000000','0.000338942800000','1.292288796348521','1.266443020421551','3736.4505763850148','3736.450576385014756','test','test','2.00'),('2019-10-13 07:59:59','2019-10-25 15:59:59','XLMETH','4h','0.000340580000000','0.000357020000000','1.286545290586972','1.348647600109697','3777.5127446913275','3777.512744691327498','test','test','0.78'),('2019-10-29 07:59:59','2019-10-29 11:59:59','XLMETH','4h','0.000361470000000','0.000361040000000','1.300345803814244','1.298798929396892','3597.3823659342247','3597.382365934224708','test','test','0.11'),('2019-10-29 15:59:59','2019-10-29 19:59:59','XLMETH','4h','0.000362680000000','0.000355426400000','1.300002053943722','1.274002012864847','3584.43270636297','3584.432706362969839','test','test','2.00'),('2019-11-01 03:59:59','2019-11-04 11:59:59','XLMETH','4h','0.000383780000000','0.000376104400000','1.294224267037305','1.268339781696559','3372.3077467228754','3372.307746722875436','test','test','1.99'),('2019-11-04 23:59:59','2019-11-06 07:59:59','XLMETH','4h','0.000428000000000','0.000419440000000','1.288472159183806','1.262702716000130','3010.4489700556214','3010.448970055621430','test','test','2.00'),('2019-11-10 03:59:59','2019-11-13 23:59:59','XLMETH','4h','0.000407510000000','0.000404900000000','1.282745616254100','1.274529950237504','3147.764757316631','3147.764757316630948','test','test','0.64'),('2019-11-15 19:59:59','2019-11-15 23:59:59','XLMETH','4h','0.000402510000000','0.000400170000000','1.280919912694857','1.273473258957792','3182.330656865312','3182.330656865311994','test','test','0.58'),('2019-11-22 19:59:59','2019-11-23 03:59:59','XLMETH','4h','0.000391490000000','0.000385710000000','1.279265100753287','1.260377894739458','3267.682701354535','3267.682701354534856','test','test','1.47'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XLMETH','4h','0.000410540000000','0.000402329200000','1.275067943861325','1.249566584984098','3105.8312073399056','3105.831207339905632','test','test','2.00'),('2019-11-26 11:59:59','2019-11-26 23:59:59','XLMETH','4h','0.000391080000000','0.000390050000000','1.269400975221941','1.266057712962356','3245.8856889177173','3245.885688917717289','test','test','0.26'),('2019-12-27 15:59:59','2019-12-28 19:59:59','XLMETH','4h','0.000359060000000','0.000358640000000','1.268658028053144','1.267174052194562','3533.275853765789','3533.275853765789179','test','test','0.11');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:52:22
