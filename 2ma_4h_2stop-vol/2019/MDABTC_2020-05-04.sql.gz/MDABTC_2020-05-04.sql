-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-02 23:59:59','MDABTC','4h','0.000224100000000','0.000223340000000','0.033333333333333','0.033220288561654','148.74312063067083','148.743120630670830','test','test','0.33'),('2019-01-03 15:59:59','2019-01-03 19:59:59','MDABTC','4h','0.000225740000000','0.000221225200000','0.033308212272960','0.032642048027501','147.551219424826','147.551219424826002','test','test','2.00'),('2019-01-05 15:59:59','2019-01-05 19:59:59','MDABTC','4h','0.000225110000000','0.000220607800000','0.033160175773969','0.032496972258490','147.3065424635482','147.306542463548197','test','test','1.99'),('2019-01-17 07:59:59','2019-01-17 11:59:59','MDABTC','4h','0.000211360000000','0.000207132800000','0.033012797214974','0.032352541270675','156.19226540014193','156.192265400141935','test','test','1.99'),('2019-01-17 15:59:59','2019-01-18 03:59:59','MDABTC','4h','0.000206400000000','0.000202272000000','0.032866073671796','0.032208752198360','159.23485306102927','159.234853061029270','test','test','1.99'),('2019-01-19 19:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201460000000','0.000199400000000','0.032720002233255','0.032385428597791','162.4143861473995','162.414386147399512','test','test','1.02'),('2019-01-23 11:59:59','2019-01-23 15:59:59','MDABTC','4h','0.000203190000000','0.000199900000000','0.032645652536485','0.032117062562347','160.6656456345555','160.665645634555489','test','test','1.61'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MDABTC','4h','0.000200400000000','0.000201290000000','0.032528188097788','0.032672649611795','162.3163078731936','162.316307873193608','test','test','0.0'),('2019-01-24 15:59:59','2019-01-24 19:59:59','MDABTC','4h','0.000200030000000','0.000199290000000','0.032560290656456','0.032439835649278','162.7770367267721','162.777036726772110','test','test','0.36'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000197234800000','0.032533522877083','0.031882852419541','161.6492242724999','161.649224272499907','test','test','2.00'),('2019-01-26 07:59:59','2019-01-27 03:59:59','MDABTC','4h','0.000205880000000','0.000201762400000','0.032388929442074','0.031741150853233','157.31945522670486','157.319455226704861','test','test','2.00'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000203510000000','0.032244978644554','0.031641716591703','155.47991052873223','155.479910528732233','test','test','1.87'),('2019-01-31 15:59:59','2019-02-05 15:59:59','MDABTC','4h','0.000207030000000','0.000209070000000','0.032110920410587','0.032427330001649','155.102740716741','155.102740716741010','test','test','0.53'),('2019-02-14 19:59:59','2019-02-15 03:59:59','MDABTC','4h','0.000209920000000','0.000205721600000','0.032181233653045','0.031537608979984','153.30237067952132','153.302370679521317','test','test','1.99'),('2019-02-18 03:59:59','2019-02-18 11:59:59','MDABTC','4h','0.000203080000000','0.000200400000000','0.032038205947920','0.031615405120953','157.76150259956887','157.761502599568871','test','test','1.31'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MDABTC','4h','0.000202610000000','0.000203410000000','0.031944250208594','0.032070381199991','157.66373924581436','157.663739245814355','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 19:59:59','MDABTC','4h','0.000200540000000','0.000198720000000','0.031972279317794','0.031682115019607','159.43093306968075','159.430933069680748','test','test','0.90'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.031907798362641','0.031938615243424','154.08440391462773','154.084403914627728','test','test','0.0'),('2019-02-24 23:59:59','2019-03-02 11:59:59','MDABTC','4h','0.000217700000000','0.000227270000000','0.031914646558371','0.033317600933950','146.59920329981932','146.599203299819322','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 03:59:59','MDABTC','4h','0.000230410000000','0.000225801800000','0.032226414197388','0.031581885913440','139.8655188463531','139.865518846353098','test','test','2.00'),('2019-03-08 07:59:59','2019-03-08 23:59:59','MDABTC','4h','0.000225470000000','0.000220960600000','0.032083185689844','0.031441521976047','142.29469858448675','142.294698584486753','test','test','2.00'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000240210000000','0.000253770000000','0.031940593753445','0.033743659617883','132.9694590293697','132.969459029369688','test','test','1.38'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDABTC','4h','0.000281530000000','0.000275899400000','0.032341275056653','0.031694449555520','114.87683393120922','114.876833931209219','test','test','2.0'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDABTC','4h','0.000297500000000','0.000291550000000','0.032197536056402','0.031553585335274','108.22701195429093','108.227011954290930','test','test','2.00'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDABTC','4h','0.000279460000000','0.000273870800000','0.032054435896151','0.031413347178228','114.70133792367741','114.701337923677414','test','test','2.00'),('2019-03-22 19:59:59','2019-03-28 03:59:59','MDABTC','4h','0.000262010000000','0.000279870000000','0.031911971736612','0.034087262050783','121.7967701103486','121.796770110348604','test','test','0.0'),('2019-03-29 15:59:59','2019-04-02 07:59:59','MDABTC','4h','0.000291830000000','0.000285993400000','0.032395369584206','0.031747462192522','111.00767427682557','111.007674276825568','test','test','1.99'),('2019-05-22 19:59:59','2019-05-22 23:59:59','MDABTC','4h','0.000129390000000','0.000126802200000','0.032251390163832','0.031606362360555','249.25720816007248','249.257208160072480','test','test','1.99'),('2019-05-23 11:59:59','2019-05-23 15:59:59','MDABTC','4h','0.000127800000000','0.000130970000000','0.032108050651992','0.032904471000715','251.23670306723355','251.236703067233549','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','MDABTC','4h','0.000121100000000','0.000119690000000','0.032285032951709','0.031909129595294','266.59812511733','266.598125117330028','test','test','1.16'),('2019-06-01 19:59:59','2019-06-01 23:59:59','MDABTC','4h','0.000119600000000','0.000117208000000','0.032201498872505','0.031557468895055','269.2433016095764','269.243301609576406','test','test','2.00'),('2019-06-02 11:59:59','2019-06-02 15:59:59','MDABTC','4h','0.000119510000000','0.000123930000000','0.032058381099739','0.033244039575690','268.2485239707026','268.248523970702593','test','test','0.0'),('2019-06-02 19:59:59','2019-06-03 03:59:59','MDABTC','4h','0.000122400000000','0.000119952000000','0.032321860761061','0.031675423545840','264.0674898779503','264.067489877950322','test','test','2.00'),('2019-06-05 19:59:59','2019-06-06 15:59:59','MDABTC','4h','0.000126160000000','0.000123636800000','0.032178208046568','0.031534643885637','255.05871945598886','255.058719455988864','test','test','2.00'),('2019-06-08 19:59:59','2019-06-08 23:59:59','MDABTC','4h','0.000129410000000','0.000126821800000','0.032035193788583','0.031394489912811','247.54805493070782','247.548054930707821','test','test','1.99'),('2019-06-09 03:59:59','2019-06-12 15:59:59','MDABTC','4h','0.000127500000000','0.000126300000000','0.031892815149522','0.031592647477526','250.13972666292113','250.139726662921134','test','test','0.94'),('2019-07-08 11:59:59','2019-07-08 15:59:59','MDABTC','4h','0.000079550000000','0.000077959000000','0.031826111222412','0.031189588997964','400.07682240618766','400.076822406187659','test','test','2.00'),('2019-07-23 19:59:59','2019-07-23 23:59:59','MDABTC','4h','0.000070100000000','0.000068698000000','0.031684661839202','0.031050968602418','451.9923229557997','451.992322955799693','test','test','1.99'),('2019-07-24 11:59:59','2019-07-24 23:59:59','MDABTC','4h','0.000069800000000','0.000068404000000','0.031543841119916','0.030912964297518','451.9174945546737','451.917494554673681','test','test','1.99'),('2019-07-26 19:59:59','2019-07-26 23:59:59','MDABTC','4h','0.000073690000000','0.000072216200000','0.031403646270494','0.030775573345084','426.1588583321271','426.158858332127124','test','test','2.00'),('2019-07-28 19:59:59','2019-07-29 07:59:59','MDABTC','4h','0.000069590000000','0.000068198200000','0.031264074509292','0.030638793019106','449.26102183204813','449.261021832048129','test','test','2.00'),('2019-07-29 19:59:59','2019-07-29 23:59:59','MDABTC','4h','0.000067030000000','0.000067020000000','0.031125123067029','0.031120479605435','464.34615943650107','464.346159436501068','test','test','0.01'),('2019-07-30 19:59:59','2019-07-31 07:59:59','MDABTC','4h','0.000069960000000','0.000068560800000','0.031124091186674','0.030501609362941','444.8840935773935','444.884093577393514','test','test','2.00'),('2019-07-31 19:59:59','2019-07-31 23:59:59','MDABTC','4h','0.000067390000000','0.000066150000000','0.030985761892512','0.030415612838547','459.79762416547794','459.797624165477941','test','test','1.84'),('2019-08-01 23:59:59','2019-08-02 03:59:59','MDABTC','4h','0.000067680000000','0.000068940000000','0.030859062102742','0.031433565918485','455.9554093194675','455.955409319467492','test','test','0.0'),('2019-08-03 15:59:59','2019-08-03 23:59:59','MDABTC','4h','0.000068000000000','0.000067500000000','0.030986729617351','0.030758886017223','455.68720025516336','455.687200255163361','test','test','0.73'),('2019-08-15 11:59:59','2019-08-15 15:59:59','MDABTC','4h','0.000060510000000','0.000059299800000','0.030936097706212','0.030317375752088','511.25595283773856','511.255952837738562','test','test','2.00'),('2019-08-20 19:59:59','2019-08-20 23:59:59','MDABTC','4h','0.000064940000000','0.000063641200000','0.030798603938628','0.030182631859855','474.26245670816826','474.262456708168259','test','test','2.00'),('2019-08-21 07:59:59','2019-08-23 03:59:59','MDABTC','4h','0.000064720000000','0.000063425600000','0.030661721254457','0.030048486829368','473.75959911088796','473.759599110887962','test','test','2.00'),('2019-08-25 19:59:59','2019-08-25 23:59:59','MDABTC','4h','0.000066610000000','0.000065277800000','0.030525446937770','0.029914937999015','458.27123461597694','458.271234615976937','test','test','2.00'),('2019-08-26 15:59:59','2019-08-28 07:59:59','MDABTC','4h','0.000064200000000','0.000062950000000','0.030389778284714','0.029798076994124','473.36103247217386','473.361032472173861','test','test','1.94'),('2019-09-01 19:59:59','2019-09-01 23:59:59','MDABTC','4h','0.000062290000000','0.000061044200000','0.030258289109027','0.029653123326846','485.7647954571664','485.764795457166372','test','test','2.00'),('2019-09-09 19:59:59','2019-09-12 23:59:59','MDABTC','4h','0.000061770000000','0.000060534600000','0.030123807824098','0.029521331667616','487.6769924574677','487.676992457467691','test','test','1.99'),('2019-09-17 11:59:59','2019-09-17 15:59:59','MDABTC','4h','0.000063310000000','0.000062043800000','0.029989924233768','0.029390125749093','473.6996404007021','473.699640400702094','test','test','1.99'),('2019-09-18 07:59:59','2019-09-18 11:59:59','MDABTC','4h','0.000063800000000','0.000062540000000','0.029856635681618','0.029266990525523','467.9723461068722','467.972346106872180','test','test','1.97'),('2019-09-18 15:59:59','2019-09-18 19:59:59','MDABTC','4h','0.000063550000000','0.000064130000000','0.029725603424708','0.029996899254548','467.75143075859086','467.751430758590857','test','test','0.0'),('2019-09-24 19:59:59','2019-09-24 23:59:59','MDABTC','4h','0.000063670000000','0.000062396600000','0.029785891386895','0.029190173559157','467.81673294950696','467.816732949506957','test','test','2.00'),('2019-09-25 03:59:59','2019-10-07 23:59:59','MDABTC','4h','0.000064500000000','0.000111790000000','0.029653509647398','0.051394819278800','459.7443356185703','459.744335618570290','test','test','0.0'),('2019-10-09 11:59:59','2019-10-09 15:59:59','MDABTC','4h','0.000120840000000','0.000118423200000','0.034484911787709','0.033795213551955','285.3766284980912','285.376628498091179','test','test','2.00'),('2019-10-11 15:59:59','2019-10-15 19:59:59','MDABTC','4h','0.000114160000000','0.000111876800000','0.034331645513097','0.033645012602835','300.7327042142373','300.732704214237287','test','test','2.00'),('2019-11-06 19:59:59','2019-11-06 23:59:59','MDABTC','4h','0.000082730000000','0.000081075400000','0.034179060421928','0.033495479213489','413.13985763239447','413.139857632394467','test','test','1.99'),('2019-11-09 11:59:59','2019-11-12 19:59:59','MDABTC','4h','0.000083070000000','0.000081408600000','0.034027153486719','0.033346610416985','409.6202418047349','409.620241804734917','test','test','1.99'),('2019-11-22 15:59:59','2019-11-22 19:59:59','MDABTC','4h','0.000080790000000','0.000079760000000','0.033875921693445','0.033444034091709','419.3083511999642','419.308351199964193','test','test','1.27'),('2019-11-23 19:59:59','2019-11-24 15:59:59','MDABTC','4h','0.000081070000000','0.000079448600000','0.033779946670837','0.033104347737420','416.6762880330223','416.676288033022274','test','test','2.00'),('2019-11-26 03:59:59','2019-11-26 23:59:59','MDABTC','4h','0.000082700000000','0.000081270000000','0.033629813574522','0.033048306519969','406.6482898974876','406.648289897487587','test','test','1.72'),('2019-12-12 23:59:59','2019-12-13 15:59:59','MDABTC','4h','0.000075710000000','0.000074195800000','0.033500589784622','0.032830577988930','442.48566615535003','442.485666155350032','test','test','1.99'),('2019-12-17 19:59:59','2019-12-17 23:59:59','MDABTC','4h','0.000073280000000','0.000072520000000','0.033351698274468','0.033005801840399','455.12688693323935','455.126886933239348','test','test','1.03'),('2019-12-18 03:59:59','2019-12-18 11:59:59','MDABTC','4h','0.000073470000000','0.000072840000000','0.033274832400230','0.032989503090142','452.9036668059102','452.903666805910177','test','test','0.89'),('2019-12-26 11:59:59','2019-12-26 15:59:59','MDABTC','4h','0.000071990000000','0.000070550200000','0.033211425886877','0.032547197369139','461.3338781341483','461.333878134148279','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:25:04
