-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.297777777777778','1.307882586235599','503.7292351854871','503.729235185487084','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002702650000000','0.002648597000000','1.300023290768405','1.274022824953037','481.0179974352597','481.017997435259701','test','test','2.00'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.294245409476101','1.298152292074109','482.9273915955599','482.927391595559925','test','test','0.00'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.295113605608991','1.305657459142976','477.31342390153515','477.313423901535145','test','test','0.25'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.297456684172099','1.324708041760781','471.06927551741256','471.069275517412564','test','test','0.93'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.303512541414029','1.293742228553661','463.04800286104023','463.048002861040231','test','test','0.74'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.301341360778391','1.284847784092045','459.94357742180756','459.943577421807561','test','test','1.26'),('2019-02-25 19:59:59','2019-02-26 07:59:59','XRPETH','4h','0.002380130000000','0.002332527400000','1.297676121514759','1.271722599084464','545.212287360253','545.212287360252958','test','test','2.00'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.291908672085804','1.284534905180418','561.596870174057','561.596870174057017','test','test','0.57'),('2019-03-04 03:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002392200000000','0.002344356000000','1.290270057217941','1.264464656073582','539.3654615909793','539.365461590979294','test','test','2.00'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.284535523630305','1.279257960842450','553.784133038294','553.784133038294044','test','test','0.41'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.283362731899671','1.285074399217337','553.9376432577999','553.937643257799891','test','test','0.0'),('2019-03-12 19:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002341610000000','0.002332830000000','1.283743102414708','1.278929634570276','548.230961780445','548.230961780445000','test','test','0.75'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002206244600000','1.282673442893723','1.257019974035849','569.7554904092902','569.755490409290246','test','test','1.99'),('2019-04-26 19:59:59','2019-04-26 23:59:59','XRPETH','4h','0.001921600000000','0.001921710000000','1.276972672036418','1.277045771013273','664.5361532246136','664.536153224613599','test','test','0.0'),('2019-04-30 11:59:59','2019-05-01 03:59:59','XRPETH','4h','0.001933450000000','0.001894781000000','1.276988916253497','1.251449137928427','660.4716523589939','660.471652358993879','test','test','2.00'),('2019-05-14 07:59:59','2019-05-15 19:59:59','XRPETH','4h','0.001834520000000','0.001797829600000','1.271313409959036','1.245887141759855','692.9951213173126','692.995121317312623','test','test','1.99'),('2019-05-15 23:59:59','2019-05-16 03:59:59','XRPETH','4h','0.001842670000000','0.001805816600000','1.265663128136996','1.240349865574256','686.8636967753293','686.863696775329345','test','test','2.00'),('2019-05-27 23:59:59','2019-05-28 03:59:59','XRPETH','4h','0.001600790000000','0.001589290000000','1.260037958678609','1.250985905301961','787.1350762302422','787.135076230242248','test','test','0.71'),('2019-05-28 15:59:59','2019-05-30 03:59:59','XRPETH','4h','0.001638620000000','0.001605847600000','1.258026391261577','1.232865863436345','767.7352841180851','767.735284118085133','test','test','2.00'),('2019-05-30 07:59:59','2019-06-01 03:59:59','XRPETH','4h','0.001638090000000','0.001618740000000','1.252435162855970','1.237640725186939','764.5704221721453','764.570422172145300','test','test','1.18'),('2019-06-02 15:59:59','2019-06-04 19:59:59','XRPETH','4h','0.001635040000000','0.001650030000000','1.249147510040629','1.260599658719260','763.9859025104153','763.985902510415258','test','test','0.0'),('2019-06-06 15:59:59','2019-06-09 19:59:59','XRPETH','4h','0.001675050000000','0.001641549000000','1.251692431969214','1.226658583329830','747.2567576903459','747.256757690345921','test','test','2.00'),('2019-06-17 07:59:59','2019-06-17 11:59:59','XRPETH','4h','0.001598430000000','0.001591290000000','1.246129354493795','1.240563040303567','779.5958249618658','779.595824961865787','test','test','0.44'),('2019-06-17 23:59:59','2019-06-18 19:59:59','XRPETH','4h','0.001638130000000','0.001613210000000','1.244892395784856','1.225954510206203','759.9472543600665','759.947254360066495','test','test','1.52'),('2019-07-14 15:59:59','2019-07-25 03:59:59','XRPETH','4h','0.001300820000000','0.001435720000000','1.240683976767377','1.369347641583354','953.7706806225128','953.770680622512828','test','test','0.0'),('2019-07-26 19:59:59','2019-07-31 19:59:59','XRPETH','4h','0.001472340000000','0.001465690000000','1.269275902282039','1.263543065606967','862.0807030183511','862.080703018351073','test','test','1.53'),('2019-08-01 03:59:59','2019-08-01 11:59:59','XRPETH','4h','0.001477350000000','0.001461720000000','1.268001938576467','1.254586789627369','858.294878381201','858.294878381200988','test','test','1.05'),('2019-08-10 11:59:59','2019-08-11 03:59:59','XRPETH','4h','0.001438460000000','0.001420800000000','1.265020794365557','1.249490110697957','879.4271612457467','879.427161245746674','test','test','1.22'),('2019-08-13 15:59:59','2019-08-13 19:59:59','XRPETH','4h','0.001433330000000','0.001415350000000','1.261569531328312','1.245744131613464','880.1668361984415','880.166836198441501','test','test','1.25'),('2019-08-15 11:59:59','2019-08-15 15:59:59','XRPETH','4h','0.001435060000000','0.001420810000000','1.258052775836124','1.245560439588396','876.6551752791688','876.655175279168816','test','test','0.99'),('2019-08-18 11:59:59','2019-08-18 15:59:59','XRPETH','4h','0.001484760000000','0.001455064800000','1.255276701114407','1.230171167092119','845.440812733645','845.440812733644975','test','test','2.00'),('2019-08-21 15:59:59','2019-08-21 23:59:59','XRPETH','4h','0.001432120000000','0.001418480000000','1.249697693553898','1.237795145904207','872.6207954318758','872.620795431875763','test','test','0.95'),('2019-08-25 07:59:59','2019-08-26 07:59:59','XRPETH','4h','0.001448830000000','0.001429220000000','1.247052682965078','1.230173750921329','860.7308538372878','860.730853837287782','test','test','1.35'),('2019-08-26 19:59:59','2019-08-27 15:59:59','XRPETH','4h','0.001434360000000','0.001427240000000','1.243301809177578','1.237130200319729','866.7989968889107','866.798996888910665','test','test','0.49'),('2019-08-28 19:59:59','2019-09-02 19:59:59','XRPETH','4h','0.001481320000000','0.001465270000000','1.241930340542500','1.228474110986626','838.3943648519567','838.394364851956652','test','test','1.08'),('2019-09-05 11:59:59','2019-09-05 23:59:59','XRPETH','4h','0.001490250000000','0.001473790000000','1.238940067307862','1.225255817344509','831.363910288785','831.363910288784950','test','test','1.10'),('2019-09-06 19:59:59','2019-09-07 11:59:59','XRPETH','4h','0.001477450000000','0.001468380000000','1.235899122871561','1.228311992989369','836.5082560300254','836.508256030025450','test','test','0.61'),('2019-09-07 15:59:59','2019-09-07 19:59:59','XRPETH','4h','0.001487280000000','0.001465280000000','1.234213094008852','1.215956485926854','829.845821909023','829.845821909023016','test','test','1.47'),('2019-09-18 03:59:59','2019-09-19 03:59:59','XRPETH','4h','0.001441180000000','0.001424280000000','1.230156069990630','1.215730642505623','853.5755908287861','853.575590828786062','test','test','1.35'),('2019-09-24 19:59:59','2019-09-27 23:59:59','XRPETH','4h','0.001417480000000','0.001392240000000','1.226950419438406','1.205103036345434','865.5857009893657','865.585700989365705','test','test','1.78'),('2019-09-30 11:59:59','2019-09-30 15:59:59','XRPETH','4h','0.001499870000000','0.001469872600000','1.222095445417746','1.197653536509391','814.8009130242928','814.800913024292754','test','test','2.00'),('2019-10-02 15:59:59','2019-10-02 23:59:59','XRPETH','4h','0.001419830000000','0.001401270000000','1.216663910104778','1.200759694690577','856.908158092714','856.908158092713961','test','test','1.30'),('2019-10-03 15:59:59','2019-10-03 23:59:59','XRPETH','4h','0.001414710000000','0.001413020000000','1.213129640012733','1.211680446120259','857.5111789785421','857.511178978542148','test','test','0.11'),('2019-10-04 11:59:59','2019-10-09 15:59:59','XRPETH','4h','0.001442560000000','0.001472330000000','1.212807596925517','1.237836214217326','840.7328616664242','840.732861666424242','test','test','1.19'),('2019-10-13 07:59:59','2019-10-23 19:59:59','XRPETH','4h','0.001531070000000','0.001662010000000','1.218369511879252','1.322566775156221','795.7634281118774','795.763428111877374','test','test','0.51'),('2019-10-24 03:59:59','2019-10-25 15:59:59','XRPETH','4h','0.001683660000000','0.001655970000000','1.241524459274134','1.221105958937189','737.3961840716855','737.396184071685525','test','test','1.64'),('2019-11-05 07:59:59','2019-11-05 11:59:59','XRPETH','4h','0.001620680000000','0.001607000000000','1.236987014754813','1.226545729391974','763.2518540086958','763.251854008695773','test','test','0.84'),('2019-11-06 23:59:59','2019-11-07 03:59:59','XRPETH','4h','0.001625170000000','0.001596750000000','1.234666729118627','1.213075616532528','759.7154323046985','759.715432304698538','test','test','1.74'),('2019-11-21 15:59:59','2019-11-25 03:59:59','XRPETH','4h','0.001497950000000','0.001529670000000','1.229868704099494','1.255911920023948','821.0345499512624','821.034549951262420','test','test','0.0'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XRPETH','4h','0.001551880000000','0.001520842400000','1.235656085416039','1.210942963707718','796.2317224373268','796.231722437326766','test','test','2.00'),('2019-11-27 03:59:59','2019-11-27 07:59:59','XRPETH','4h','0.001509540000000','0.001491990000000','1.230164280591967','1.215862318984862','814.9265872994207','814.926587299420703','test','test','1.16'),('2019-12-05 19:59:59','2019-12-10 15:59:59','XRPETH','4h','0.001492250000000','0.001519640000000','1.226986066901500','1.249507191627539','822.2389458210754','822.238945821075390','test','test','0.0'),('2019-12-10 19:59:59','2019-12-12 23:59:59','XRPETH','4h','0.001519510000000','0.001509510000000','1.231990761285064','1.223882945204321','810.7816080743557','810.781608074355745','test','test','0.65'),('2019-12-13 03:59:59','2019-12-13 07:59:59','XRPETH','4h','0.001516890000000','0.001513760000000','1.230189024378232','1.227650612465500','810.9942213200907','810.994221320090674','test','test','0.20'),('2019-12-15 19:59:59','2019-12-16 03:59:59','XRPETH','4h','0.001526590000000','0.001507610000000','1.229624932842069','1.214337081339476','805.4716281660887','805.471628166088749','test','test','1.24'),('2019-12-16 19:59:59','2019-12-17 03:59:59','XRPETH','4h','0.001570440000000','0.001539031200000','1.226227632508160','1.201703079857997','780.817880662846','780.817880662846051','test','test','1.99'),('2019-12-20 19:59:59','2019-12-20 23:59:59','XRPETH','4h','0.001510890000000','0.001522910000000','1.220777731919235','1.230489721764736','807.9858440516748','807.985844051674803','test','test','0.0'),('2019-12-25 03:59:59','2019-12-25 07:59:59','XRPETH','4h','0.001505980000000','0.001503020000000','1.222935951884902','1.220532274267949','812.0532489707047','812.053248970704658','test','test','0.19');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:04:57
