-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-03 19:59:59','LTCUSDT','4h','31.480000000000000','30.850400000000000','222.222222222222200','217.777777777777743','7.059155724975292','7.059155724975292','test','test','1.99'),('2019-01-04 07:59:59','2019-01-04 15:59:59','LTCUSDT','4h','32.060000000000002','31.418800000000001','221.234567901234556','216.809876543209867','6.900641544018544','6.900641544018544','test','test','2.00'),('2019-01-04 23:59:59','2019-01-10 07:59:59','LTCUSDT','4h','31.760000000000002','35.170000000000002','220.251303155006866','243.899191812392701','6.934864708910795','6.934864708910795','test','test','0.0'),('2019-01-23 11:59:59','2019-01-23 15:59:59','LTCUSDT','4h','32.020000000000003','31.559999999999999','225.506389523314823','222.266759942405230','7.042673001977351','7.042673001977351','test','test','1.43'),('2019-01-24 15:59:59','2019-01-27 15:59:59','LTCUSDT','4h','31.980000000000000','32.340000000000003','224.786471838668263','227.316901165182372','7.0289703514280255','7.028970351428026','test','test','0.0'),('2019-01-31 03:59:59','2019-01-31 11:59:59','LTCUSDT','4h','32.020000000000003','31.379600000000003','225.348789466782478','220.841813677446822','7.037751076414193','7.037751076414193','test','test','1.99'),('2019-02-01 11:59:59','2019-02-06 03:59:59','LTCUSDT','4h','32.119999999999997','32.789999999999999','224.347239291374564','229.026960658909445','6.984658757514775','6.984658757514775','test','test','0.0'),('2019-02-08 07:59:59','2019-02-24 15:59:59','LTCUSDT','4h','33.820000000000000','44.390000000000001','225.387177373048985','295.829000697505762','6.664316303165257','6.664316303165257','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','LTCUSDT','4h','46.009999999999998','45.859999999999999','241.040915889594970','240.255083736075335','5.238881023464355','5.238881023464355','test','test','0.32'),('2019-03-01 07:59:59','2019-03-04 07:59:59','LTCUSDT','4h','46.920000000000002','46.140000000000001','240.866286522146112','236.862115518581021','5.13355256867319','5.133552568673190','test','test','1.66'),('2019-03-05 15:59:59','2019-03-14 15:59:59','LTCUSDT','4h','52.140000000000001','55.939999999999998','239.976470743576101','257.466125304864704','4.602540674023324','4.602540674023324','test','test','0.76'),('2019-03-15 11:59:59','2019-03-20 11:59:59','LTCUSDT','4h','57.799999999999997','59.810000000000002','243.863060646084705','252.343419675472774','4.219084094222919','4.219084094222919','test','test','0.0'),('2019-03-20 15:59:59','2019-03-21 15:59:59','LTCUSDT','4h','60.020000000000003','58.819600000000001','245.747584874837571','240.832633177340824','4.094428271823351','4.094428271823351','test','test','2.00'),('2019-03-22 15:59:59','2019-03-25 15:59:59','LTCUSDT','4h','59.259999999999998','58.609999999999999','244.655373386504976','241.971843303797783','4.128507819549527','4.128507819549527','test','test','1.09'),('2019-03-27 03:59:59','2019-03-30 19:59:59','LTCUSDT','4h','60.030000000000001','60.259999999999998','244.059033368125597','244.994125449995806','4.065617747261796','4.065617747261796','test','test','0.0'),('2019-04-01 03:59:59','2019-04-01 15:59:59','LTCUSDT','4h','60.659999999999997','60.369999999999997','244.266831608541196','243.099054141240231','4.026818852761972','4.026818852761972','test','test','0.47'),('2019-04-02 07:59:59','2019-04-11 11:59:59','LTCUSDT','4h','66.909999999999997','77.189999999999998','244.007325504696524','281.496419902967034','3.6467990659796223','3.646799065979622','test','test','0.0'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCUSDT','4h','83.280000000000001','81.614400000000003','252.338235370978850','247.291470663559267','3.0299980231865855','3.029998023186586','test','test','1.99'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCUSDT','4h','81.739999999999995','80.105199999999996','251.216732102663428','246.192397460610152','3.0733634952613587','3.073363495261359','test','test','1.99'),('2019-04-17 03:59:59','2019-04-17 07:59:59','LTCUSDT','4h','80.140000000000001','79.549999999999997','250.100213293318234','248.258946437278070','3.120791281423986','3.120791281423986','test','test','0.73'),('2019-04-18 03:59:59','2019-04-18 11:59:59','LTCUSDT','4h','80.620000000000005','79.799999999999997','249.691042880864899','247.151391985772989','3.0971352379169548','3.097135237916955','test','test','1.01'),('2019-04-18 19:59:59','2019-04-19 03:59:59','LTCUSDT','4h','82.469999999999999','80.820599999999999','249.126676015288893','244.144142494983100','3.020815763493257','3.020815763493257','test','test','2.0'),('2019-04-19 15:59:59','2019-04-20 11:59:59','LTCUSDT','4h','82.750000000000000','81.094999999999999','248.019446344109838','243.059057417227649','2.9972138531010253','2.997213853101025','test','test','2.00'),('2019-05-02 15:59:59','2019-05-02 19:59:59','LTCUSDT','4h','73.909999999999997','73.200000000000003','246.917137693691558','244.545183049360332','3.340781189198912','3.340781189198912','test','test','0.96'),('2019-05-03 03:59:59','2019-05-04 15:59:59','LTCUSDT','4h','74.750000000000000','75.950000000000003','246.390036661617955','250.345461999329558','3.296187781426327','3.296187781426327','test','test','0.0'),('2019-05-04 23:59:59','2019-05-05 11:59:59','LTCUSDT','4h','77.769999999999996','76.214599999999990','247.269020069998334','242.323639668598332','3.1794910642921224','3.179491064292122','test','test','2.00'),('2019-05-06 19:59:59','2019-05-06 23:59:59','LTCUSDT','4h','76.010000000000005','74.939999999999998','246.170046647464943','242.704687485344294','3.238653422542625','3.238653422542625','test','test','1.40'),('2019-05-07 03:59:59','2019-05-07 15:59:59','LTCUSDT','4h','77.650000000000006','76.097000000000008','245.399966833660386','240.491967496987172','3.1603344086756002','3.160334408675600','test','test','1.99'),('2019-05-09 03:59:59','2019-05-09 07:59:59','LTCUSDT','4h','75.299999999999997','74.280000000000001','244.309300314399678','240.999931306156839','3.2444794198459452','3.244479419845945','test','test','1.35'),('2019-05-10 07:59:59','2019-05-17 07:59:59','LTCUSDT','4h','77.000000000000000','88.000000000000000','243.573884979234634','278.370154261982407','3.1632972075225276','3.163297207522528','test','test','1.06'),('2019-05-19 03:59:59','2019-05-20 15:59:59','LTCUSDT','4h','91.599999999999994','90.250000000000000','251.306389264289663','247.602637894128179','2.743519533452944','2.743519533452944','test','test','1.47'),('2019-05-21 15:59:59','2019-05-22 23:59:59','LTCUSDT','4h','90.769999999999996','88.954599999999999','250.483333404253813','245.473666736168724','2.759538761752273','2.759538761752273','test','test','1.99'),('2019-05-24 07:59:59','2019-05-30 23:59:59','LTCUSDT','4h','94.090000000000003','107.780000000000001','249.370074144679307','285.653168150850604','2.6503355738620393','2.650335573862039','test','test','0.0'),('2019-05-31 11:59:59','2019-06-03 23:59:59','LTCUSDT','4h','107.879999999999995','105.989999999999995','257.432983923828488','252.922895495797007','2.386290173561629','2.386290173561629','test','test','1.75'),('2019-06-06 23:59:59','2019-06-21 15:59:59','LTCUSDT','4h','111.189999999999998','136.240000000000009','256.430742050932622','314.202035228159559','2.3062392485918934','2.306239248591893','test','test','0.56'),('2019-06-22 03:59:59','2019-06-24 03:59:59','LTCUSDT','4h','139.990000000000009','137.190200000000004','269.268807201427478','263.883431057398923','1.9234860147255337','1.923486014725534','test','test','2.00'),('2019-06-25 23:59:59','2019-06-26 03:59:59','LTCUSDT','4h','136.330000000000013','136.330000000000013','268.072056947198860','268.072056947198860','1.9663467831526358','1.966346783152636','test','test','0.0'),('2019-06-26 11:59:59','2019-06-26 23:59:59','LTCUSDT','4h','137.099999999999994','134.358000000000004','268.072056947198860','262.710615808254886','1.955303114129824','1.955303114129824','test','test','1.99'),('2019-06-29 19:59:59','2019-06-30 07:59:59','LTCUSDT','4h','133.800000000000011','131.123999999999995','266.880625582989126','261.543013071329312','1.9946235095888574','1.994623509588857','test','test','2.00'),('2019-06-30 11:59:59','2019-06-30 15:59:59','LTCUSDT','4h','132.419999999999987','133.870000000000005','265.694489469286964','268.603846135428569','2.00645287320108','2.006452873201080','test','test','0.0'),('2019-07-09 03:59:59','2019-07-09 07:59:59','LTCUSDT','4h','122.760000000000005','120.304800000000000','266.341013172873943','261.014192909416465','2.169607471268116','2.169607471268116','test','test','2.00'),('2019-07-20 19:59:59','2019-07-20 23:59:59','LTCUSDT','4h','103.400000000000006','101.332000000000008','265.157275336550072','259.854129829819044','2.5643837073167317','2.564383707316732','test','test','1.99'),('2019-07-31 15:59:59','2019-08-02 19:59:59','LTCUSDT','4h','96.120000000000005','94.197600000000008','263.978798557276548','258.699222586131043','2.7463462188647165','2.746346218864717','test','test','1.99'),('2019-08-03 03:59:59','2019-08-03 07:59:59','LTCUSDT','4h','95.780000000000001','95.769999999999996','262.805559452577540','262.778120993666221','2.7438458911315258','2.743845891131526','test','test','0.01'),('2019-08-05 03:59:59','2019-08-05 07:59:59','LTCUSDT','4h','95.099999999999994','94.739999999999995','262.799462017263920','261.804637555368913','2.7634012830416816','2.763401283041682','test','test','0.37'),('2019-08-05 11:59:59','2019-08-05 15:59:59','LTCUSDT','4h','102.069999999999993','100.028599999999997','262.578389914620573','257.326822116328174','2.5725324768748954','2.572532476874895','test','test','1.99'),('2019-08-06 07:59:59','2019-08-06 11:59:59','LTCUSDT','4h','97.510000000000005','95.559800000000010','261.411374848333367','256.183147351366699','2.68086734538338','2.680867345383380','test','test','1.99'),('2019-09-03 23:59:59','2019-09-04 03:59:59','LTCUSDT','4h','69.060000000000002','68.140000000000001','260.249546515674126','256.782567326644028','3.768455640250132','3.768455640250132','test','test','1.33'),('2019-09-07 15:59:59','2019-09-09 11:59:59','LTCUSDT','4h','68.980000000000004','70.469999999999999','259.479106695889641','265.083975773547991','3.7616570990995886','3.761657099099589','test','test','0.59'),('2019-09-10 03:59:59','2019-09-10 15:59:59','LTCUSDT','4h','71.879999999999995','70.442399999999992','260.724633157591484','255.510140494439639','3.6272208285697203','3.627220828569720','test','test','2.00'),('2019-09-14 15:59:59','2019-09-16 15:59:59','LTCUSDT','4h','70.269999999999996','69.969999999999999','259.565857010224420','258.457706204716146','3.693836018360957','3.693836018360957','test','test','0.44'),('2019-09-16 23:59:59','2019-09-21 19:59:59','LTCUSDT','4h','72.629999999999995','73.040000000000006','259.319601275667026','260.783473456901049','3.5704199542292034','3.570419954229203','test','test','0.48'),('2019-09-23 07:59:59','2019-09-23 15:59:59','LTCUSDT','4h','73.269999999999996','72.799999999999997','259.644906204830193','257.979379987875518','3.543672802031257','3.543672802031257','test','test','0.64'),('2019-10-08 03:59:59','2019-10-08 07:59:59','LTCUSDT','4h','57.820000000000000','57.369999999999997','259.274789267729091','257.256912146136585','4.484171381316656','4.484171381316656','test','test','0.77'),('2019-10-09 11:59:59','2019-10-10 11:59:59','LTCUSDT','4h','57.850000000000001','57.869999999999997','258.826372129597416','258.915854021431301','4.47409459169572','4.474094591695720','test','test','0.0'),('2019-10-25 15:59:59','2019-11-01 19:59:59','LTCUSDT','4h','54.750000000000000','57.649999999999999','258.846256994449391','272.556834990502409','4.727785515880354','4.727785515880354','test','test','0.0'),('2019-11-02 19:59:59','2019-11-08 15:59:59','LTCUSDT','4h','58.609999999999999','60.229999999999997','261.893052104683477','269.131863645539738','4.46840218571376','4.468402185713760','test','test','1.75'),('2019-11-10 07:59:59','2019-11-11 07:59:59','LTCUSDT','4h','63.350000000000001','62.082999999999998','263.501676891540399','258.231643353709558','4.15945819876149','4.159458198761490','test','test','2.00'),('2019-12-22 19:59:59','2019-12-23 19:59:59','LTCUSDT','4h','41.829999999999998','41.280000000000001','262.330558327577990','258.881315987626579','6.271349709002582','6.271349709002582','test','test','1.31'),('2019-12-27 19:59:59','2019-12-27 23:59:59','LTCUSDT','4h','41.049999999999997','40.950000000000003','261.564060029810946','260.926875961528879','6.371840682821217','6.371840682821217','test','test','0.24'),('2019-12-28 03:59:59','2019-12-31 15:59:59','LTCUSDT','4h','41.549999999999997','41.570000000000000','261.422463570192747','261.548298691044863','6.291756042603917','6.291756042603917','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:55:51
