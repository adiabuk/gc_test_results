-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.297777777777778','1.290878374387146','22998.011302104867','22998.011302104867355','test','test','0.53'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.296244577024304','1.610437842344446','22555.15185356367','22555.151853563671466','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.366065302651002','1.357881770671064','19484.599952232235','19484.599952232234500','test','test','0.59'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.364246739988794','1.372420543566473','19461.43708971175','19461.437089711751469','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000070658000000','1.366063140783833','1.338741877968156','18946.78419949838','18946.784199498379166','test','test','2.00'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDETH','4h','0.000073720000000','0.000072245600000','1.359991749047016','1.332791914066075','18448.07038859219','18448.070388592190284','test','test','2.00'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056114800000','1.353947341273474','1.326868394448004','23645.604982072546','23645.604982072545681','test','test','2.00'),('2019-03-01 19:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000057900000000','0.000061610000000','1.347929797534481','1.434299737929178','23280.30738401521','23280.307384015210118','test','test','1.64'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.367123117622191','1.427855632154445','21384.68821558253','21384.688215582529665','test','test','0.67'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.380619231962692','1.516027738087160','21058.865649217387','21058.865649217386817','test','test','0.0'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000068740000000','1.410710011101463','1.382946465532153','20118.511282108706','20118.511282108705927','test','test','1.96'),('2019-04-05 15:59:59','2019-04-06 11:59:59','LENDETH','4h','0.000072970000000','0.000071510600000','1.404540334308283','1.376449527622117','19248.188766729923','19248.188766729923373','test','test','2.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000068874400000','1.398297932822468','1.370331974166018','19896.10035319391','19896.100353193909541','test','test','2.00'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.392083275343257','1.388546372685832','20805.309749562948','20805.309749562948127','test','test','0.40'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000065464000000','1.391297296974940','1.363471351035441','20827.803846930245','20827.803846930244617','test','test','2.00'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000065865800000','1.385113753432829','1.357411478364172','20608.745029502','20608.745029501998943','test','test','2.00'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000038700200000','1.378957692306461','1.351378538460332','34919.161618294784','34919.161618294783693','test','test','2.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000040366200000','1.372828991451766','1.345372411622730','33329.1816327207','33329.181632720697962','test','test','2.00'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.366727529267536','1.380182359866543','35407.448944754804','35407.448944754803961','test','test','0.0'),('2019-06-08 07:59:59','2019-06-12 15:59:59','LENDETH','4h','0.000036130000000','0.000037870000000','1.369717491622870','1.435682297474622','37910.807960776925','37910.807960776925029','test','test','0.35'),('2019-06-16 07:59:59','2019-06-19 15:59:59','LENDETH','4h','0.000038670000000','0.000049770000000','1.384376337367704','1.781753563764950','35799.75012587805','35799.750125878046674','test','test','0.33'),('2019-07-22 11:59:59','2019-07-22 23:59:59','LENDETH','4h','0.000022800000000','0.000022344000000','1.472682387678203','1.443228739924639','64591.33279290366','64591.332792903660447','test','test','2.00'),('2019-07-25 19:59:59','2019-07-25 23:59:59','LENDETH','4h','0.000022300000000','0.000022800000000','1.466137132621856','1.499010162501270','65746.0597588276','65746.059758827599580','test','test','0.0'),('2019-07-28 19:59:59','2019-07-28 23:59:59','LENDETH','4h','0.000022500000000','0.000022300000000','1.473442250372837','1.460344985925078','65486.32223879273','65486.322238792730786','test','test','0.88'),('2019-07-29 03:59:59','2019-07-29 07:59:59','LENDETH','4h','0.000022390000000','0.000022200000000','1.470531747162223','1.458052915900016','65678.05927477549','65678.059274775485392','test','test','0.84'),('2019-08-13 15:59:59','2019-08-13 19:59:59','LENDETH','4h','0.000018590000000','0.000018400000000','1.467758673548400','1.452757374571843','78954.20513977406','78954.205139774057898','test','test','1.02'),('2019-08-14 19:59:59','2019-08-14 23:59:59','LENDETH','4h','0.000019000000000','0.000018670000000','1.464425051553609','1.438990300658204','77075.00271334786','77075.002713347857934','test','test','1.73'),('2019-08-15 23:59:59','2019-08-16 11:59:59','LENDETH','4h','0.000019200000000','0.000018816000000','1.458772884687964','1.429597426994204','75977.75441083145','75977.754410831446876','test','test','2.00'),('2019-08-21 11:59:59','2019-08-22 19:59:59','LENDETH','4h','0.000019350000000','0.000018963000000','1.452289449644906','1.423243660652008','75053.71832790211','75053.718327902111923','test','test','2.00'),('2019-08-24 23:59:59','2019-08-28 19:59:59','LENDETH','4h','0.000020400000000','0.000022200000000','1.445834829868706','1.573408491327709','70874.25636611306','70874.256366113055265','test','test','0.49'),('2019-08-31 11:59:59','2019-08-31 15:59:59','LENDETH','4h','0.000022380000000','0.000021932400000','1.474184532415151','1.444700841766848','65870.62253865735','65870.622538657349651','test','test','1.99'),('2019-09-02 03:59:59','2019-09-02 19:59:59','LENDETH','4h','0.000021800000000','0.000021470000000','1.467632601159973','1.445416144353423','67322.596383485','67322.596383484997205','test','test','1.51'),('2019-09-07 23:59:59','2019-09-08 07:59:59','LENDETH','4h','0.000021100000000','0.000020820000000','1.462695610758518','1.443285432037552','69322.06686059324','69322.066860593244201','test','test','1.32'),('2019-09-08 11:59:59','2019-09-08 15:59:59','LENDETH','4h','0.000020900000000','0.000020600000000','1.458382237709414','1.437448521378657','69779.05443585714','69779.054435857135104','test','test','1.43'),('2019-09-09 19:59:59','2019-09-09 23:59:59','LENDETH','4h','0.000029340000000','0.000028753200000','1.453730300747024','1.424655694732083','49547.726678494335','49547.726678494334919','test','test','1.99'),('2019-09-13 15:59:59','2019-09-14 15:59:59','LENDETH','4h','0.000022600000000','0.000022148000000','1.447269277188148','1.418323891644385','64038.463592395914','64038.463592395914020','test','test','2.00'),('2019-09-15 07:59:59','2019-09-16 03:59:59','LENDETH','4h','0.000022010000000','0.000022100000000','1.440836969289534','1.446728624320704','65462.83367966987','65462.833679669871344','test','test','0.49'),('2019-09-16 19:59:59','2019-09-17 07:59:59','LENDETH','4h','0.000022650000000','0.000022197000000','1.442146225963127','1.413303301443865','63670.9150535597','63670.915053559700027','test','test','2.00'),('2019-09-17 11:59:59','2019-09-17 19:59:59','LENDETH','4h','0.000022800000000','0.000022344000000','1.435736687181069','1.407021953437448','62970.907332503026','62970.907332503025827','test','test','2.00'),('2019-09-17 23:59:59','2019-09-19 23:59:59','LENDETH','4h','0.000023900000000','0.000023422000000','1.429355635238042','1.400768522533281','59805.675114562415','59805.675114562414819','test','test','2.00'),('2019-09-20 07:59:59','2019-09-20 15:59:59','LENDETH','4h','0.000024910000000','0.000024411800000','1.423002943525873','1.394542884655356','57125.770514888514','57125.770514888514299','test','test','2.00'),('2019-09-22 15:59:59','2019-09-22 19:59:59','LENDETH','4h','0.000027500000000','0.000026950000000','1.416678485999092','1.388344916279110','51515.581309057874','51515.581309057874023','test','test','1.99'),('2019-09-26 11:59:59','2019-09-26 15:59:59','LENDETH','4h','0.000026600000000','0.000026068000000','1.410382137172429','1.382174494428980','53021.884856106335','53021.884856106335064','test','test','2.00'),('2019-09-28 19:59:59','2019-09-29 15:59:59','LENDETH','4h','0.000026040000000','0.000025519200000','1.404113772118329','1.376031496675962','53921.41982021232','53921.419820212322520','test','test','2.00'),('2019-09-30 15:59:59','2019-10-01 03:59:59','LENDETH','4h','0.000025500000000','0.000024990000000','1.397873266464470','1.369915801135181','54818.55946919489','54818.559469194893609','test','test','2.00'),('2019-10-02 11:59:59','2019-10-09 15:59:59','LENDETH','4h','0.000025000000000','0.000026220000000','1.391660496391294','1.459573528615189','55666.419855651766','55666.419855651765829','test','test','0.0'),('2019-10-10 23:59:59','2019-10-11 03:59:59','LENDETH','4h','0.000028000000000','0.000027950000000','1.406752281329938','1.404240223684706','50241.152904640636','50241.152904640635825','test','test','0.17'),('2019-10-11 11:59:59','2019-10-12 07:59:59','LENDETH','4h','0.000028800000000','0.000028224000000','1.406194046297664','1.378070165371711','48826.18216311333','48826.182163113327988','test','test','1.99'),('2019-10-12 11:59:59','2019-11-02 15:59:59','LENDETH','4h','0.000028400000000','0.000065490000000','1.399944294980785','3.228251826700409','49293.81320354878','49293.813203548779711','test','test','0.0'),('2019-11-02 23:59:59','2019-11-07 11:59:59','LENDETH','4h','0.000065720000000','0.000068070000000','1.806234857585146','1.870821770478102','27483.79272040697','27483.792720406971057','test','test','0.0'),('2019-11-09 11:59:59','2019-11-21 03:59:59','LENDETH','4h','0.000069280000000','0.000092850000000','1.820587504894692','2.439976181141341','26278.68800367627','26278.688003676270455','test','test','0.0'),('2019-11-22 03:59:59','2019-11-22 07:59:59','LENDETH','4h','0.000105360000000','0.000103252800000','1.958229432949503','1.919064844290513','18586.080419034766','18586.080419034766237','test','test','1.99'),('2019-11-28 19:59:59','2019-11-28 23:59:59','LENDETH','4h','0.000101200000000','0.000099176000000','1.949526191025283','1.910535667204777','19264.092796692523','19264.092796692522825','test','test','2.00'),('2019-11-29 03:59:59','2019-11-30 15:59:59','LENDETH','4h','0.000101490000000','0.000099460200000','1.940861630176282','1.902044397572756','19123.673565634854','19123.673565634853730','test','test','2.00'),('2019-12-04 23:59:59','2019-12-05 03:59:59','LENDETH','4h','0.000100910000000','0.000098891800000','1.932235578486609','1.893590866916877','19148.108002047462','19148.108002047461923','test','test','2.00'),('2019-12-05 15:59:59','2019-12-05 19:59:59','LENDETH','4h','0.000097100000000','0.000096840000000','1.923647864804446','1.918497005434218','19810.997577800685','19810.997577800684667','test','test','0.26'),('2019-12-06 11:59:59','2019-12-10 03:59:59','LENDETH','4h','0.000099800000000','0.000099370000000','1.922503229388840','1.914219898841373','19263.55941271383','19263.559412713828351','test','test','0.43'),('2019-12-30 23:59:59','2020-01-01 15:59:59','LENDETH','4h','0.000075670000000','0.000153280000000','1.920662489267181','3.890566226442097','25382.086550379026','25382.086550379026448','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 14:08:49
