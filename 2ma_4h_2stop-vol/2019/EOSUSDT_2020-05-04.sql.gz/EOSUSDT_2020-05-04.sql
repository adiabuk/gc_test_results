-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-04 15:59:59','EOSUSDT','4h','2.618400000000000','2.616900000000000','222.222222222222200','222.094918016091242','84.86947075398038','84.869470753980380','test','test','0.87'),('2019-01-05 03:59:59','2019-01-05 07:59:59','EOSUSDT','4h','2.713900000000000','2.659622000000000','222.193932398637571','217.750053750664819','81.87255698391155','81.872556983911551','test','test','2.00'),('2019-01-06 19:59:59','2019-01-07 03:59:59','EOSUSDT','4h','2.835900000000000','2.779182000000000','221.206403810199191','216.782275733995192','78.00218759836355','78.002187598363548','test','test','2.00'),('2019-01-08 11:59:59','2019-01-10 07:59:59','EOSUSDT','4h','2.768000000000000','2.712640000000000','220.223264237709401','215.818798952955234','79.56042783154241','79.560427831542412','test','test','1.99'),('2019-01-19 11:59:59','2019-01-19 19:59:59','EOSUSDT','4h','2.479700000000000','2.444000000000000','219.244494174430685','216.088052491151615','88.41573342518478','88.415733425184783','test','test','1.43'),('2019-01-22 19:59:59','2019-01-23 07:59:59','EOSUSDT','4h','2.461900000000000','2.419100000000000','218.543062689257567','214.743703217670486','88.77008111184759','88.770081111847588','test','test','1.73'),('2019-02-02 23:59:59','2019-02-03 11:59:59','EOSUSDT','4h','2.438900000000000','2.390122000000000','217.698760584460416','213.344785372771213','89.26104415288057','89.261044152880572','test','test','1.99'),('2019-02-03 23:59:59','2019-02-04 03:59:59','EOSUSDT','4h','2.370700000000000','2.386200000000000','216.731210537418406','218.148232414218512','91.42076624516743','91.420766245167428','test','test','0.0'),('2019-02-07 03:59:59','2019-02-07 07:59:59','EOSUSDT','4h','2.366300000000000','2.358000000000000','217.046104287818395','216.284796480021896','91.72383226464032','91.723832264640322','test','test','0.35'),('2019-02-08 11:59:59','2019-02-24 15:59:59','EOSUSDT','4h','2.428500000000000','3.570400000000000','216.876924774974754','318.854178388540163','89.30488975704128','89.304889757041281','test','test','0.0'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSUSDT','4h','3.563800000000000','3.546100000000000','239.538536689100397','238.348842514512313','67.21436014622044','67.214360146220443','test','test','0.49'),('2019-02-27 23:59:59','2019-02-28 15:59:59','EOSUSDT','4h','3.502100000000000','3.550100000000000','239.274160205858607','242.553666699071613','68.3230519419373','68.323051941937294','test','test','0.0'),('2019-03-01 19:59:59','2019-03-01 23:59:59','EOSUSDT','4h','3.622300000000000','3.549854000000000','240.002939426572567','235.202880638041108','66.25705751223603','66.257057512236031','test','test','2.00'),('2019-03-03 11:59:59','2019-03-03 15:59:59','EOSUSDT','4h','3.537900000000000','3.497700000000000','238.936259695787811','236.221305163502933','67.53618239514621','67.536182395146213','test','test','1.13'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSUSDT','4h','3.627600000000000','3.589700000000000','238.332936466391203','235.842910473427196','65.69989427345661','65.699894273456607','test','test','1.04'),('2019-03-09 15:59:59','2019-03-11 07:59:59','EOSUSDT','4h','3.757400000000000','3.682252000000000','237.779597356843624','233.024005409706746','63.283014147241076','63.283014147241076','test','test','1.99'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSUSDT','4h','3.662000000000000','3.623500000000000','236.722799146368772','234.234042246550302','64.64303635892102','64.643036358921023','test','test','1.05'),('2019-03-15 11:59:59','2019-03-20 11:59:59','EOSUSDT','4h','3.688400000000000','3.711600000000000','236.169742057520239','237.655247429967488','64.03040398479564','64.030403984795640','test','test','0.05'),('2019-03-23 07:59:59','2019-03-23 11:59:59','EOSUSDT','4h','3.684600000000000','3.658400000000000','236.499854362508501','234.818180318026663','64.18603223213063','64.186032232130628','test','test','0.71'),('2019-03-26 23:59:59','2019-04-11 11:59:59','EOSUSDT','4h','3.743900000000000','5.246600000000000','236.126149019290295','330.900786197443438','63.0695662328829','63.069566232882899','test','test','0.0'),('2019-04-12 03:59:59','2019-04-13 11:59:59','EOSUSDT','4h','5.280400000000000','5.239100000000000','257.187179503324330','255.175621569552732','48.70600323902059','48.706003239020589','test','test','0.78'),('2019-04-14 23:59:59','2019-04-15 11:59:59','EOSUSDT','4h','5.542200000000000','5.431356000000000','256.740166629152839','251.605363296569777','46.32459431798795','46.324594317987952','test','test','2.00'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSUSDT','4h','5.484400000000000','5.374712000000000','255.599099221912184','250.487117237473939','46.60475151737878','46.604751517378780','test','test','2.00'),('2019-04-16 11:59:59','2019-04-21 07:59:59','EOSUSDT','4h','5.383300000000000','5.337300000000000','254.463103225370361','252.288730118100261','47.26898059282789','47.268980592827887','test','test','0.85'),('2019-05-03 11:59:59','2019-05-04 11:59:59','EOSUSDT','4h','5.034500000000000','4.933810000000000','253.979909201532593','248.900311017501934','50.44789138971746','50.447891389717462','test','test','2.00'),('2019-05-04 23:59:59','2019-05-05 11:59:59','EOSUSDT','4h','4.947200000000000','4.869300000000000','252.851109605081291','248.869645051750950','51.109942918232804','51.109942918232804','test','test','1.57'),('2019-05-06 19:59:59','2019-05-07 15:59:59','EOSUSDT','4h','4.933100000000000','4.852100000000000','251.966339704341266','247.829129123560108','51.0766738368047','51.076673836804702','test','test','1.64'),('2019-05-09 03:59:59','2019-05-09 07:59:59','EOSUSDT','4h','4.944800000000000','4.888100000000000','251.046959575278805','248.168306726241752','50.76989151740795','50.769891517407949','test','test','1.14'),('2019-05-11 03:59:59','2019-05-11 07:59:59','EOSUSDT','4h','4.898300000000000','4.923700000000000','250.407258942159388','251.705738899926530','51.121258179809196','51.121258179809196','test','test','0.0'),('2019-05-11 11:59:59','2019-05-22 23:59:59','EOSUSDT','4h','5.276000000000000','5.928500000000000','250.695810043885444','281.700172449805734','47.516264223632575','47.516264223632575','test','test','0.43'),('2019-05-24 07:59:59','2019-05-30 23:59:59','EOSUSDT','4h','6.224100000000000','7.300000000000000','257.585668356312169','302.112012821304120','41.38520723579508','41.385207235795079','test','test','0.0'),('2019-05-31 11:59:59','2019-06-03 07:59:59','EOSUSDT','4h','7.656600000000000','7.503468000000000','267.480411570754825','262.130803339339707','34.934620010285876','34.934620010285876','test','test','2.00'),('2019-06-15 03:59:59','2019-06-18 19:59:59','EOSUSDT','4h','6.668300000000000','6.758900000000000','266.291609741551497','269.909626303881396','39.933957641610526','39.933957641610526','test','test','0.19'),('2019-06-21 03:59:59','2019-06-21 15:59:59','EOSUSDT','4h','6.992600000000000','6.909200000000000','267.095613422069221','263.909992314126441','38.19689577869022','38.196895778690219','test','test','1.19'),('2019-06-21 19:59:59','2019-06-25 15:59:59','EOSUSDT','4h','6.974600000000000','7.079900000000000','266.387697620304152','270.409523181543250','38.19397494054199','38.193974940541992','test','test','0.0'),('2019-06-26 03:59:59','2019-06-26 23:59:59','EOSUSDT','4h','7.316600000000000','7.170268000000000','267.281436633912847','261.935807901234568','36.53082533333964','36.530825333339642','test','test','2.00'),('2019-07-24 15:59:59','2019-07-24 19:59:59','EOSUSDT','4h','4.640900000000000','4.548082000000000','266.093519137762144','260.771648755006879','57.33661986635397','57.336619866353971','test','test','2.00'),('2019-07-25 03:59:59','2019-07-26 03:59:59','EOSUSDT','4h','4.570000000000000','4.478600000000000','264.910881274927590','259.612663649429010','57.96737008204104','57.967370082041043','test','test','2.00'),('2019-08-05 03:59:59','2019-08-05 11:59:59','EOSUSDT','4h','4.357100000000000','4.422800000000000','263.733499580372325','267.710293990055447','60.529595276760304','60.529595276760304','test','test','0.55'),('2019-08-05 15:59:59','2019-08-06 11:59:59','EOSUSDT','4h','4.419000000000000','4.335800000000000','264.617231671413094','259.635074243248027','59.88169985775359','59.881699857753588','test','test','1.88'),('2019-09-07 15:59:59','2019-09-19 03:59:59','EOSUSDT','4h','3.427400000000000','3.887800000000000','263.510085576265283','298.907192245843532','76.88337678014392','76.883376780143919','test','test','0.0'),('2019-09-19 19:59:59','2019-09-20 03:59:59','EOSUSDT','4h','3.945200000000000','3.922000000000000','271.376109280616049','269.780264777090224','68.78640101404645','68.786401014046447','test','test','0.58'),('2019-10-07 15:59:59','2019-10-10 11:59:59','EOSUSDT','4h','3.127300000000000','3.110000000000000','271.021477168721390','269.522205734890633','86.66308866073655','86.663088660736548','test','test','0.55'),('2019-10-10 19:59:59','2019-10-10 23:59:59','EOSUSDT','4h','3.153900000000000','3.105300000000000','270.688305738981228','266.517136184171477','85.82653404958344','85.826534049583444','test','test','1.54'),('2019-10-11 03:59:59','2019-10-11 07:59:59','EOSUSDT','4h','3.138600000000000','3.075828000000000','269.761379171245721','264.366151587820752','85.94958872466887','85.949588724668871','test','test','2.00'),('2019-10-14 19:59:59','2019-10-15 07:59:59','EOSUSDT','4h','3.158800000000000','3.113000000000000','268.562439708262389','264.668505385532740','85.02040005959934','85.020400059599339','test','test','1.44'),('2019-10-22 15:59:59','2019-10-22 19:59:59','EOSUSDT','4h','2.992200000000000','2.969600000000000','267.697120969877972','265.675212362859952','89.46498261141568','89.464982611415678','test','test','0.75'),('2019-10-25 15:59:59','2019-11-03 19:59:59','EOSUSDT','4h','3.056300000000000','3.225400000000000','267.247807946096259','282.034185043791183','87.44161500706615','87.441615007066147','test','test','0.0'),('2019-11-04 11:59:59','2019-11-08 15:59:59','EOSUSDT','4h','3.369100000000000','3.403000000000000','270.533669523361766','273.255788604671864','80.29849797375019','80.298497973750187','test','test','0.0'),('2019-11-10 07:59:59','2019-11-11 11:59:59','EOSUSDT','4h','3.544500000000000','3.473610000000000','271.138584874763978','265.715813177268672','76.49558044146254','76.495580441462536','test','test','1.99'),('2019-11-12 03:59:59','2019-11-12 11:59:59','EOSUSDT','4h','3.469200000000000','3.467900000000000','269.933524497542862','269.832373344006953','77.80857964301363','77.808579643013630','test','test','0.03'),('2019-11-13 11:59:59','2019-11-13 15:59:59','EOSUSDT','4h','3.477800000000000','3.450400000000000','269.911046463423759','267.784540432859103','77.60970914469601','77.609709144696012','test','test','0.78'),('2019-12-08 19:59:59','2019-12-09 03:59:59','EOSUSDT','4h','2.750700000000000','2.735000000000000','269.438489567742693','267.900632190997271','97.95269915575768','97.952699155757685','test','test','0.57'),('2019-12-22 19:59:59','2019-12-23 19:59:59','EOSUSDT','4h','2.515500000000000','2.516600000000000','269.096743484021488','269.214416478588134','106.97544960605109','106.975449606051086','test','test','0.0'),('2019-12-24 11:59:59','2019-12-25 15:59:59','EOSUSDT','4h','2.515000000000000','2.474800000000000','269.122893038369682','264.821207034336908','107.00711452817879','107.007114528178789','test','test','1.59'),('2019-12-26 19:59:59','2019-12-26 23:59:59','EOSUSDT','4h','2.574200000000000','2.522716000000000','268.166962815251281','262.803623558946299','104.17487484082484','104.174874840824842','test','test','1.99'),('2019-12-27 07:59:59','2019-12-27 15:59:59','EOSUSDT','4h','2.548100000000000','2.576100000000000','266.975109647183501','269.908786924417996','104.77418847265945','104.774188472659446','test','test','0.83'),('2019-12-28 03:59:59','2019-12-31 19:59:59','EOSUSDT','4h','2.620700000000000','2.574800000000000','267.627037931013376','262.939709720598842','102.12044031404335','102.120440314043350','test','test','1.75');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 13:53:09
