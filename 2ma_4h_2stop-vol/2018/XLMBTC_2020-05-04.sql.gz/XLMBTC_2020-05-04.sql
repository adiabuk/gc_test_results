-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-25 19:59:59','XLMBTC','4h','0.000039240000000','0.000038570000000','0.033333333333333','0.032764186204553','849.4733265375468','849.473326537546768','test','test','1.70'),('2018-05-26 03:59:59','2018-05-26 07:59:59','XLMBTC','4h','0.000038790000000','0.000038810000000','0.033206856193604','0.033223977542505','856.0674450529631','856.067445052963080','test','test','0.0'),('2018-05-26 15:59:59','2018-05-26 19:59:59','XLMBTC','4h','0.000038790000000','0.000038590000000','0.033210660937805','0.033039427831655','856.1655307503136','856.165530750313565','test','test','0.51'),('2018-05-31 11:59:59','2018-06-01 19:59:59','XLMBTC','4h','0.000038600000000','0.000038080000000','0.033172609136438','0.032725724246517','859.3940190787046','859.394019078704559','test','test','1.34'),('2018-06-02 07:59:59','2018-06-04 15:59:59','XLMBTC','4h','0.000038830000000','0.000038500000000','0.033073301383122','0.032792225167401','851.7461082441984','851.746108244198354','test','test','0.84'),('2018-06-06 15:59:59','2018-06-06 19:59:59','XLMBTC','4h','0.000038730000000','0.000038560000000','0.033010840001851','0.032865943466857','852.3325587877844','852.332558787784365','test','test','0.43'),('2018-06-07 07:59:59','2018-06-07 15:59:59','XLMBTC','4h','0.000038980000000','0.000038440000000','0.032978640771852','0.032521779150077','846.0400403245823','846.040040324582264','test','test','1.38'),('2018-06-07 19:59:59','2018-06-07 23:59:59','XLMBTC','4h','0.000038900000000','0.000038122000000','0.032877115967013','0.032219573647673','845.1700762728365','845.170076272836468','test','test','1.99'),('2018-07-02 15:59:59','2018-07-03 19:59:59','XLMBTC','4h','0.000032210000000','0.000031750000000','0.032730995451604','0.032263554970147','1016.1749596896753','1016.174959689675347','test','test','1.42'),('2018-07-04 19:59:59','2018-07-04 23:59:59','XLMBTC','4h','0.000032110000000','0.000031940000000','0.032627119789058','0.032454382001324','1016.1046337296303','1016.104633729630336','test','test','0.52'),('2018-07-08 19:59:59','2018-07-08 23:59:59','XLMBTC','4h','0.000031800000000','0.000031350000000','0.032588733614006','0.032127572289280','1024.8029438366805','1024.802943836680470','test','test','1.41'),('2018-07-09 11:59:59','2018-07-09 15:59:59','XLMBTC','4h','0.000031750000000','0.000031590000000','0.032486253319623','0.032322543066674','1023.1890809330042','1023.189080933004220','test','test','0.50'),('2018-07-13 23:59:59','2018-07-14 03:59:59','XLMBTC','4h','0.000033070000000','0.000032408600000','0.032449873263412','0.031800875798144','981.2480575570607','981.248057557060747','test','test','2.00'),('2018-07-15 11:59:59','2018-07-23 19:59:59','XLMBTC','4h','0.000034270000000','0.000036490000000','0.032305651604464','0.034398401722991','942.6802335705733','942.680233570573250','test','test','0.0'),('2018-07-24 07:59:59','2018-07-24 11:59:59','XLMBTC','4h','0.000036830000000','0.000036093400000','0.032770707186358','0.032115293042631','889.7829808948803','889.782980894880325','test','test','2.00'),('2018-07-24 15:59:59','2018-07-24 19:59:59','XLMBTC','4h','0.000036770000000','0.000036270000000','0.032625059598864','0.032181422672037','887.2738536541623','887.273853654162281','test','test','1.35'),('2018-07-25 11:59:59','2018-07-26 23:59:59','XLMBTC','4h','0.000037250000000','0.000038850000000','0.032526473615124','0.033923583891210','873.1939225536703','873.193922553670291','test','test','0.0'),('2018-08-10 19:59:59','2018-08-11 03:59:59','XLMBTC','4h','0.000035980000000','0.000035260400000','0.032836942565366','0.032180203714059','912.644318103545','912.644318103544947','test','test','1.99'),('2018-08-12 03:59:59','2018-08-13 23:59:59','XLMBTC','4h','0.000035570000000','0.000035480000000','0.032691000598408','0.032608285106312','919.061023289526','919.061023289526020','test','test','1.23'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XLMBTC','4h','0.000035810000000','0.000035260000000','0.032672619377943','0.032170805899645','912.3881423608673','912.388142360867278','test','test','1.53'),('2018-08-17 15:59:59','2018-08-18 07:59:59','XLMBTC','4h','0.000035500000000','0.000034980000000','0.032561105271654','0.032084153870492','917.2142330043441','917.214233004344123','test','test','1.46'),('2018-09-06 23:59:59','2018-09-07 03:59:59','XLMBTC','4h','0.000031930000000','0.000032050000000','0.032455116071396','0.032577089573700','1016.445852533542','1016.445852533542052','test','test','0.0'),('2018-09-11 23:59:59','2018-09-12 03:59:59','XLMBTC','4h','0.000031880000000','0.000031242400000','0.032482221294130','0.031832576868247','1018.8902538936707','1018.890253893670661','test','test','2.00'),('2018-09-12 19:59:59','2018-09-12 23:59:59','XLMBTC','4h','0.000031760000000','0.000031124800000','0.032337855866156','0.031691098748833','1018.1944542240624','1018.194454224062383','test','test','2.00'),('2018-09-16 11:59:59','2018-09-17 07:59:59','XLMBTC','4h','0.000031780000000','0.000031610000000','0.032194132062307','0.032021916755492','1013.0312165609399','1013.031216560939924','test','test','0.53'),('2018-09-17 11:59:59','2018-09-17 23:59:59','XLMBTC','4h','0.000032180000000','0.000031536400000','0.032155861994126','0.031512744754243','999.2499065918444','999.249906591844365','test','test','2.00'),('2018-09-18 11:59:59','2018-10-02 23:59:59','XLMBTC','4h','0.000032350000000','0.000037790000000','0.032012947051929','0.037396267978127','989.5810526098711','989.581052609871108','test','test','0.71'),('2018-10-08 23:59:59','2018-10-09 03:59:59','XLMBTC','4h','0.000037490000000','0.000037140000000','0.033209240591084','0.032899205002744','885.8159666867017','885.815966686701699','test','test','0.93'),('2018-10-17 07:59:59','2018-10-18 19:59:59','XLMBTC','4h','0.000035690000000','0.000036470000000','0.033140343793676','0.033864621410910','928.5610477353755','928.561047735375496','test','test','0.0'),('2018-10-18 23:59:59','2018-10-24 11:59:59','XLMBTC','4h','0.000036970000000','0.000037070000000','0.033301294375283','0.033391370908622','900.7653333860726','900.765333386072598','test','test','1.37'),('2018-11-02 23:59:59','2018-11-14 01:59:59','XLMBTC','4h','0.000037030000000','0.000040050000000','0.033321311382692','0.036038847444688','899.8463781445253','899.846378144525261','test','test','0.24'),('2018-11-14 23:59:59','2018-11-15 03:59:59','XLMBTC','4h','0.000040760000000','0.000040300000000','0.033925208285358','0.033542342833659','832.3161993463578','832.316199346357848','test','test','1.12'),('2018-11-15 23:59:59','2018-11-20 11:59:59','XLMBTC','4h','0.000042680000000','0.000044250000000','0.033840127073869','0.035084948992941','792.8802032302926','792.880203230292636','test','test','1.17'),('2018-12-01 11:59:59','2018-12-01 15:59:59','XLMBTC','4h','0.000039980000000','0.000039730000000','0.034116754166996','0.033903417785261','853.3455269383692','853.345526938369176','test','test','0.62'),('2018-12-24 03:59:59','2018-12-24 07:59:59','XLMBTC','4h','0.000031810000000','0.000033080000000','0.034069346082166','0.035429549462372','1071.026283626721','1071.026283626720897','test','test','0.0'),('2018-12-24 11:59:59','2018-12-24 19:59:59','XLMBTC','4h','0.000032700000000','0.000032046000000','0.034371613499990','0.033684181229990','1051.119678898763','1051.119678898762913','test','test','1.99'),('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.034218850773323','0.033736104518975','1122.665707786184','1122.665707786183930','test','test','1.41'),('2019-01-08 11:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030530000000','0.000030460000000','0.034111573827912','0.034033361899712','1117.3132600036759','1117.313260003675850','test','test','0.45'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.034094193399423','0.033575104611029','1104.4442306259582','1104.444230625958198','test','test','1.52'),('2019-01-13 03:59:59','2019-01-13 15:59:59','XLMBTC','4h','0.000030740000000','0.000030125200000','0.033978840335336','0.033299263528629','1105.362405183337','1105.362405183336932','test','test','1.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.033827823267179','0.033476865261395','1132.122599303168','1132.122599303168045','test','test','1.03'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.033749832599227','0.033915790649558','1508.7095484678882','1508.709548467888226','test','test','0.0'),('2019-02-20 11:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022780000000','0.000022324400000','0.033786712165967','0.033110977922648','1483.174370762374','1483.174370762374110','test','test','1.99'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.033636549000785','0.033413494962318','1487.0269231116215','1487.026923111621500','test','test','0.66'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.033586981436681','0.033406163232446','1506.8183686263394','1506.818368626339407','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022393000000','0.033546799613518','0.032875863621248','1468.1312741145634','1468.131274114563439','test','test','1.99'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.033397702726347','0.039125580281915','1491.6347800958756','1491.634780095875612','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026656000000','0.034670564405362','0.033977153117255','1274.6531031383004','1274.653103138300366','test','test','2.00'),('2019-03-27 15:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026410000000','0.000026340000000','0.034516473008005','0.034424986710748','1306.9471036730276','1306.947103673027641','test','test','0.26'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026650000000','0.000026117000000','0.034496142719725','0.033806219865331','1294.414360965303','1294.414360965303104','test','test','1.99'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.034342826529860','0.033765071623450','1343.6160614186228','1343.616061418622849','test','test','1.68'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.034214436550658','0.038231873616606','2207.383003268243','2207.383003268243101','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018051600000','0.035107200343091','0.034405056336229','1905.9283573882008','1905.928357388200766','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018531800000','0.034951168341566','0.034252144974735','1848.2902348792054','1848.290234879205400','test','test','1.99'),('2019-05-18 03:59:59','2019-05-18 07:59:59','XLMBTC','4h','0.000018890000000','0.000018512200000','0.034795829815603','0.034099913219291','1842.0238123665076','1842.023812366507627','test','test','2.00'),('2019-05-21 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016880000000','0.000016550000000','0.034641181683090','0.033963954789996','2052.202706344167','2052.202706344166927','test','test','1.95');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:17:04
