-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-05-31 23:59:59','WABIETH','4h','0.001360300000000','0.001333094000000','1.297777777777778','1.271822222222222','954.0379164726734','954.037916472673373','test','test','2.00'),('2018-06-02 11:59:59','2018-06-03 11:59:59','WABIETH','4h','0.001382080000000','0.001354438400000','1.292009876543210','1.266169679012346','934.8300218100326','934.830021810032576','test','test','2.00'),('2018-06-29 15:59:59','2018-06-29 23:59:59','WABIETH','4h','0.000814920000000','0.000801440000000','1.286267610425240','1.264990813453105','1578.3974014936925','1578.397401493692541','test','test','1.65'),('2018-06-30 03:59:59','2018-06-30 07:59:59','WABIETH','4h','0.000872190000000','0.000854746200000','1.281539433320321','1.255908644653915','1469.3351601374943','1469.335160137494313','test','test','1.99'),('2018-07-01 23:59:59','2018-07-02 03:59:59','WABIETH','4h','0.000917490000000','0.000899140200000','1.275843702505564','1.250326828455453','1390.5804995210458','1390.580499521045795','test','test','2.00'),('2018-07-04 15:59:59','2018-07-04 23:59:59','WABIETH','4h','0.000896890000000','0.000878952200000','1.270173286049984','1.244769820328984','1416.1973999598436','1416.197399959843551','test','test','2.00'),('2018-07-05 11:59:59','2018-07-05 15:59:59','WABIETH','4h','0.000882820000000','0.000865163600000','1.264528071445317','1.239237510016411','1432.3736112064944','1432.373611206494388','test','test','2.00'),('2018-07-06 19:59:59','2018-07-07 11:59:59','WABIETH','4h','0.000905890000000','0.000887772200000','1.258907946683338','1.233729787749671','1389.6918463426443','1389.691846342644340','test','test','2.00'),('2018-07-16 11:59:59','2018-07-16 19:59:59','WABIETH','4h','0.000842230000000','0.000825385400000','1.253312800253634','1.228246544248561','1488.0885271881011','1488.088527188101125','test','test','2.00'),('2018-07-17 11:59:59','2018-07-20 07:59:59','WABIETH','4h','0.000874460000000','0.000856970800000','1.247742521141396','1.222787670718568','1426.8720366184803','1426.872036618480251','test','test','2.00'),('2018-08-17 15:59:59','2018-08-17 19:59:59','WABIETH','4h','0.000545810000000','0.000534893800000','1.242196998825212','1.217353058848708','2275.878050649882','2275.878050649881970','test','test','1.99'),('2018-08-18 03:59:59','2018-08-18 07:59:59','WABIETH','4h','0.000539660000000','0.000528866800000','1.236676123274878','1.211942600809380','2291.583818098206','2291.583818098205938','test','test','2.00'),('2018-08-20 15:59:59','2018-08-20 23:59:59','WABIETH','4h','0.000564280000000','0.000552994400000','1.231179784949212','1.206556189250228','2181.8596883625355','2181.859688362535508','test','test','1.99'),('2018-08-21 15:59:59','2018-08-21 19:59:59','WABIETH','4h','0.000560140000000','0.000548937200000','1.225707874793882','1.201193717298005','2188.217007879962','2188.217007879961784','test','test','2.00'),('2018-08-21 23:59:59','2018-08-22 19:59:59','WABIETH','4h','0.000559840000000','0.000548643200000','1.220260284239242','1.195855078554457','2179.658981564808','2179.658981564808073','test','test','2.00'),('2018-08-26 11:59:59','2018-09-13 19:59:59','WABIETH','4h','0.000619280000000','0.000851450000000','1.214836905198179','1.670283043100035','1961.692457689864','1961.692457689864113','test','test','0.0'),('2018-09-15 15:59:59','2018-09-15 19:59:59','WABIETH','4h','0.000954220000000','0.000935135600000','1.316047158065258','1.289726214903953','1379.1863072093','1379.186307209299912','test','test','1.99'),('2018-09-16 07:59:59','2018-09-16 23:59:59','WABIETH','4h','0.000989940000000','0.000970141200000','1.310198059584968','1.283994098393269','1323.5125963037844','1323.512596303784449','test','test','1.99'),('2018-09-20 15:59:59','2018-09-20 23:59:59','WABIETH','4h','0.000932570000000','0.000913918600000','1.304374957097924','1.278287457955966','1398.6885242908565','1398.688524290856549','test','test','1.99'),('2018-09-21 11:59:59','2018-09-21 15:59:59','WABIETH','4h','0.000940750000000','0.000921935000000','1.298577735066378','1.272606180365051','1380.3643210910209','1380.364321091020884','test','test','2.00'),('2018-09-23 11:59:59','2018-09-23 15:59:59','WABIETH','4h','0.000897730000000','0.000901560000000','1.292806278466083','1.298321798774556','1440.0836314549842','1440.083631454984243','test','test','0.0'),('2018-09-25 03:59:59','2018-09-28 11:59:59','WABIETH','4h','0.000951300000000','0.000976880000000','1.294031949645744','1.328827847124918','1360.2774620474545','1360.277462047454492','test','test','0.27'),('2018-10-04 07:59:59','2018-10-04 11:59:59','WABIETH','4h','0.000945330000000','0.000941270000000','1.301764371307782','1.296173558208114','1377.0475614946972','1377.047561494697220','test','test','0.42'),('2018-10-04 19:59:59','2018-10-06 11:59:59','WABIETH','4h','0.000945280000000','0.000936360000000','1.300521968396745','1.288249778190564','1375.8060769261433','1375.806076926143305','test','test','0.94'),('2018-10-10 11:59:59','2018-10-11 07:59:59','WABIETH','4h','0.000970000000000','0.000950600000000','1.297794815017593','1.271838918717241','1337.9327989872095','1337.932798987209480','test','test','2.00'),('2018-10-11 23:59:59','2018-10-12 11:59:59','WABIETH','4h','0.000987380000000','0.000967632400000','1.292026838061960','1.266186301300721','1308.5406206951325','1308.540620695132475','test','test','2.00'),('2018-10-13 15:59:59','2018-10-22 07:59:59','WABIETH','4h','0.001232190000000','0.001210970000000','1.286284496559462','1.264132915214871','1043.9011001221095','1043.901100122109483','test','test','1.72'),('2018-10-22 11:59:59','2018-10-22 15:59:59','WABIETH','4h','0.001225530000000','0.001215040000000','1.281361922927331','1.270394026122269','1045.5573694053435','1045.557369405343479','test','test','0.85'),('2018-10-22 23:59:59','2018-10-26 11:59:59','WABIETH','4h','0.001256530000000','0.001266850000000','1.278924612526206','1.289428541601732','1017.8225848377722','1017.822584837772183','test','test','0.10'),('2018-10-28 15:59:59','2018-10-28 19:59:59','WABIETH','4h','0.001315870000000','0.001289552600000','1.281258818987434','1.255633642607685','973.6971121671851','973.697112167185082','test','test','2.00'),('2018-10-28 23:59:59','2018-11-04 07:59:59','WABIETH','4h','0.001289570000000','0.001451890000000','1.275564335347490','1.436121422526630','989.1392753766679','989.139275376667911','test','test','0.86'),('2018-11-04 15:59:59','2018-11-04 19:59:59','WABIETH','4h','0.001494910000000','0.001465011800000','1.311243688053965','1.285018814292886','877.1388833133535','877.138883313353517','test','test','2.00'),('2018-11-07 15:59:59','2018-11-08 03:59:59','WABIETH','4h','0.001428640000000','0.001400067200000','1.305415938329281','1.279307619562695','913.7472969602428','913.747296960242807','test','test','1.99'),('2018-11-11 19:59:59','2018-11-11 23:59:59','WABIETH','4h','0.001510830000000','0.001480613400000','1.299614089714484','1.273621807920194','860.1987581094393','860.198758109439268','test','test','2.0'),('2018-11-12 11:59:59','2018-11-13 03:59:59','WABIETH','4h','0.001500250000000','0.001470245000000','1.293838027093531','1.267961266551660','862.4149489042031','862.414948904203129','test','test','2.00'),('2018-11-25 11:59:59','2018-11-25 19:59:59','WABIETH','4h','0.001201740000000','0.001289150000000','1.288087635862004','1.381778234702600','1071.8521775608733','1071.852177560873315','test','test','0.01'),('2018-11-25 23:59:59','2018-11-30 11:59:59','WABIETH','4h','0.001277660000000','0.001328700000000','1.308907768937692','1.361196055748408','1024.4570299905233','1024.457029990523324','test','test','0.76'),('2018-12-03 15:59:59','2018-12-06 15:59:59','WABIETH','4h','0.001353570000000','0.001380050000000','1.320527388228962','1.346360972927428','975.5885460145853','975.588546014585290','test','test','0.0'),('2018-12-06 23:59:59','2018-12-07 03:59:59','WABIETH','4h','0.001408350000000','0.001402200000000','1.326268184828621','1.320476620702732','941.7177440470205','941.717744047020460','test','test','0.43'),('2018-12-16 19:59:59','2018-12-16 23:59:59','WABIETH','4h','0.001411000000000','0.001382780000000','1.324981170578424','1.298481547166856','939.0369741874017','939.036974187401711','test','test','2.00'),('2018-12-17 03:59:59','2018-12-17 19:59:59','WABIETH','4h','0.001383710000000','0.001356035800000','1.319092365375853','1.292710518068336','953.301172482567','953.301172482567040','test','test','1.99'),('2019-01-10 07:59:59','2019-01-10 11:59:59','WABIETH','4h','0.000883470000000','0.000889250000000','1.313229732640849','1.321821385843181','1486.445190714851','1486.445190714850924','test','test','0.0'),('2019-01-10 15:59:59','2019-01-10 19:59:59','WABIETH','4h','0.000901060000000','0.000893170000000','1.315138988908034','1.303623166851252','1459.5465217721728','1459.546521772172810','test','test','0.87'),('2019-01-11 11:59:59','2019-01-12 03:59:59','WABIETH','4h','0.000895560000000','0.000894070000000','1.312579917339860','1.310396094841271','1465.6526836167986','1465.652683616798640','test','test','0.16'),('2019-01-12 15:59:59','2019-01-14 15:59:59','WABIETH','4h','0.000903010000000','0.000884949800000','1.312094623451285','1.285852730982259','1453.023359045066','1453.023359045065945','test','test','2.00'),('2019-01-14 23:59:59','2019-01-15 15:59:59','WABIETH','4h','0.000910970000000','0.000898390000000','1.306263091791501','1.288224309290719','1433.9254770096725','1433.925477009672477','test','test','1.38'),('2019-01-15 23:59:59','2019-01-26 15:59:59','WABIETH','4h','0.000930000000000','0.001090140000000','1.302254473457994','1.526494292145696','1400.2736273741875','1400.273627374187527','test','test','0.69'),('2019-01-27 23:59:59','2019-01-28 03:59:59','WABIETH','4h','0.001104680000000','0.001082586400000','1.352085544277484','1.325043833391934','1223.9612777252087','1223.961277725208674','test','test','1.99'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WABIETH','4h','0.001124740000000','0.001102245200000','1.346076275191806','1.319154749687970','1196.7888358125488','1196.788835812548768','test','test','1.99'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WABIETH','4h','0.001106880000000','0.001084742400000','1.340093713968731','1.313291839689356','1210.6946678670959','1210.694667867095859','test','test','1.99'),('2019-02-06 03:59:59','2019-02-06 19:59:59','WABIETH','4h','0.001097280000000','0.001075334400000','1.334137741906648','1.307454987068515','1215.8589803027924','1215.858980302792361','test','test','1.99'),('2019-02-07 07:59:59','2019-02-08 15:59:59','WABIETH','4h','0.001097950000000','0.001156610000000','1.328208240831507','1.399170211237424','1209.7165087950336','1209.716508795033633','test','test','1.69'),('2019-02-08 23:59:59','2019-02-09 19:59:59','WABIETH','4h','0.001128740000000','0.001106165200000','1.343977567588378','1.317098016236610','1190.688349476742','1190.688349476741905','test','test','2.00'),('2019-02-10 15:59:59','2019-02-10 23:59:59','WABIETH','4h','0.001186710000000','0.001162975800000','1.338004333954651','1.311244247275558','1127.4905696881729','1127.490569688172855','test','test','1.99'),('2019-02-24 23:59:59','2019-02-25 03:59:59','WABIETH','4h','0.001020000000000','0.000999600000000','1.332057648025964','1.305416495065445','1305.9388706136901','1305.938870613690142','test','test','2.00'),('2019-02-26 11:59:59','2019-03-11 23:59:59','WABIETH','4h','0.001052200000000','0.001437200000000','1.326137391812515','1.811371088683659','1260.3472646003756','1260.347264600375638','test','test','0.0'),('2019-03-12 11:59:59','2019-03-21 15:59:59','WABIETH','4h','0.001504020000000','0.001668870000000','1.433967102228325','1.591138866435144','953.4228947941685','953.422894794168542','test','test','0.0'),('2019-03-24 11:59:59','2019-03-24 15:59:59','WABIETH','4h','0.001643980000000','0.001636520000000','1.468894160940952','1.462228659876085','893.4988022609472','893.498802260947173','test','test','0.45'),('2019-03-25 11:59:59','2019-03-25 15:59:59','WABIETH','4h','0.001647430000000','0.001614481400000','1.467412938482092','1.438064679712450','890.7285520368649','890.728552036864926','test','test','2.00'),('2019-03-27 15:59:59','2019-04-02 19:59:59','WABIETH','4h','0.001723340000000','0.002100820000000','1.460891103199950','1.780884356786542','847.7091596550592','847.709159655059239','test','test','0.77'),('2019-04-03 15:59:59','2019-04-03 19:59:59','WABIETH','4h','0.002088000000000','0.002046240000000','1.532000715108081','1.501360700805919','733.7168175804986','733.716817580498628','test','test','2.00'),('2019-04-12 15:59:59','2019-04-17 23:59:59','WABIETH','4h','0.001964150000000','0.002297230000000','1.525191823040934','1.783833419873393','776.5149418531855','776.514941853185519','test','test','0.0'),('2019-04-24 15:59:59','2019-04-24 19:59:59','WABIETH','4h','0.002275950000000','0.002274400000000','1.582667733448147','1.581589882446655','695.3877428977557','695.387742897755743','test','test','0.06'),('2019-04-25 03:59:59','2019-04-25 23:59:59','WABIETH','4h','0.002315670000000','0.002269356600000','1.582428211003371','1.550779646783303','683.3565279177824','683.356527917782387','test','test','2.00'),('2019-04-28 11:59:59','2019-04-29 15:59:59','WABIETH','4h','0.002182100000000','0.002188890000000','1.575395196732245','1.580297324675883','721.9628782971655','721.962878297165503','test','test','0.0'),('2019-04-30 15:59:59','2019-04-30 23:59:59','WABIETH','4h','0.002225550000000','0.002191720000000','1.576484558497498','1.552520831502386','708.3572862876582','708.357286287658212','test','test','1.52'),('2019-05-05 11:59:59','2019-05-05 19:59:59','WABIETH','4h','0.002254760000000','0.002209664800000','1.571159285831918','1.539736100115280','696.818856921321','696.818856921320958','test','test','1.99'),('2019-05-22 23:59:59','2019-05-23 03:59:59','WABIETH','4h','0.001449850000000','0.001420853000000','1.564176355672664','1.532892828559211','1078.853919834924','1078.853919834924000','test','test','2.00'),('2019-05-23 11:59:59','2019-05-23 15:59:59','WABIETH','4h','0.001420410000000','0.001434560000000','1.557224460758564','1.572737394432457','1096.3204009818037','1096.320400981803687','test','test','0.0'),('2019-05-24 03:59:59','2019-05-24 07:59:59','WABIETH','4h','0.001472840000000','0.001443383200000','1.560671779352762','1.529458343765707','1059.634297922899','1059.634297922898895','test','test','2.00'),('2019-05-24 11:59:59','2019-05-24 15:59:59','WABIETH','4h','0.001432390000000','0.001403742200000','1.553735460333417','1.522660751126749','1084.7153780279234','1084.715378027923407','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:17:36
