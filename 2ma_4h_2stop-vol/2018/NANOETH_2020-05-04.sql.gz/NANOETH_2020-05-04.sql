-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-08-15 07:59:59','2018-08-15 15:59:59','NANOETH','4h','0.003763000000000','0.004200000000000','1.297777777777778','1.448489680219683','344.8784952904007','344.878495290400679','test','test','0.31'),('2018-08-16 15:59:59','2018-09-06 07:59:59','NANOETH','4h','0.004186000000000','0.009849000000000','1.331269311653757','3.132267427252235','318.0289803281789','318.028980328178875','test','test','0.0'),('2018-09-06 15:59:59','2018-09-09 07:59:59','NANOETH','4h','0.010369000000000','0.010500000000000','1.731491115120085','1.753366448911263','166.9872808486918','166.987280848691796','test','test','0.0'),('2018-09-09 15:59:59','2018-09-09 19:59:59','NANOETH','4h','0.010327000000000','0.010310000000000','1.736352300407013','1.733493968935442','168.1371453865608','168.137145386560803','test','test','0.16'),('2018-09-12 19:59:59','2018-09-12 23:59:59','NANOETH','4h','0.010616000000000','0.011097000000000','1.735717115635554','1.814360666183849','163.5001050900107','163.500105090010692','test','test','0.0'),('2018-09-13 11:59:59','2018-09-13 19:59:59','NANOETH','4h','0.011601000000000','0.011368980000000','1.753193460201841','1.718129590997804','151.12433929849507','151.124339298495073','test','test','1.99'),('2018-09-13 23:59:59','2018-09-14 03:59:59','NANOETH','4h','0.011465000000000','0.011235700000000','1.745401489267611','1.710493459482259','152.2373736823036','152.237373682303598','test','test','2.0'),('2018-09-14 19:59:59','2018-09-15 03:59:59','NANOETH','4h','0.012317000000000','0.012070660000000','1.737644149315310','1.702891266329004','141.07689772796218','141.076897727962177','test','test','1.99'),('2018-09-18 15:59:59','2018-09-19 03:59:59','NANOETH','4h','0.011318000000000','0.011091640000000','1.729921286429464','1.695322860700875','152.84690638182227','152.846906381822265','test','test','2.00'),('2018-09-21 03:59:59','2018-09-21 15:59:59','NANOETH','4h','0.011578000000000','0.011346440000000','1.722232747378667','1.687788092431094','148.75045321978465','148.750453219784646','test','test','2.00'),('2018-10-17 03:59:59','2018-10-18 19:59:59','NANOETH','4h','0.009552000000000','0.009542000000000','1.714578379612539','1.712783385496529','179.49941160097774','179.499411600977737','test','test','0.10'),('2018-10-18 23:59:59','2018-10-22 03:59:59','NANOETH','4h','0.009794000000000','0.009780000000000','1.714179492031204','1.711729163984600','175.02343190026585','175.023431900265848','test','test','0.22'),('2018-10-23 03:59:59','2018-10-23 23:59:59','NANOETH','4h','0.010094000000000','0.009892120000000','1.713634974687514','1.679362275193764','169.76768126486172','169.767681264861722','test','test','1.99'),('2018-10-26 11:59:59','2018-10-27 19:59:59','NANOETH','4h','0.010066000000000','0.009864680000000','1.706018819244459','1.671898442859570','169.48329219595257','169.483292195952572','test','test','1.99'),('2018-10-31 11:59:59','2018-10-31 19:59:59','NANOETH','4h','0.010285000000000','0.010079300000000','1.698436513381150','1.664467783113527','165.13723999816722','165.137239998167217','test','test','1.99'),('2018-11-20 15:59:59','2018-11-20 19:59:59','NANOETH','4h','0.008681000000000','0.008556000000000','1.690887906655012','1.666540367393190','194.7803140945757','194.780314094575687','test','test','1.43'),('2018-11-20 23:59:59','2018-11-22 23:59:59','NANOETH','4h','0.008663000000000','0.008489740000000','1.685477342374607','1.651767795527115','194.56046893392664','194.560468933926643','test','test','1.99'),('2018-11-25 07:59:59','2018-11-25 11:59:59','NANOETH','4h','0.008691000000000','0.008863000000000','1.677986331964053','1.711194668070118','193.07172154689368','193.071721546893684','test','test','0.0'),('2018-11-26 19:59:59','2018-11-30 11:59:59','NANOETH','4h','0.008791000000000','0.008665000000000','1.685365962209845','1.661209880849540','191.71493143099136','191.714931430991356','test','test','1.43'),('2018-12-03 19:59:59','2018-12-04 07:59:59','NANOETH','4h','0.009039000000000','0.009110000000000','1.679997944129777','1.693194077997817','185.86104039493057','185.861040394930569','test','test','1.25'),('2018-12-05 03:59:59','2018-12-05 07:59:59','NANOETH','4h','0.008934000000000','0.008840000000000','1.682930418322675','1.665223292810885','188.37367565734','188.373675657339987','test','test','1.05'),('2018-12-05 11:59:59','2018-12-05 15:59:59','NANOETH','4h','0.008977000000000','0.009023000000000','1.678995501542278','1.687599020877350','187.03302902331262','187.033029023312622','test','test','0.0'),('2018-12-06 03:59:59','2018-12-06 15:59:59','NANOETH','4h','0.009044000000000','0.009003000000000','1.680907394727849','1.673287182080365','185.85884506057596','185.858845060575959','test','test','0.45'),('2018-12-06 23:59:59','2018-12-07 19:59:59','NANOETH','4h','0.009135000000000','0.009029000000000','1.679214014139519','1.659728881627336','183.82200483191232','183.822004831912324','test','test','1.16'),('2018-12-11 11:59:59','2018-12-13 15:59:59','NANOETH','4h','0.009268000000000','0.009100000000000','1.674883984692367','1.644523549924530','180.71687361808017','180.716873618080172','test','test','1.81'),('2018-12-14 19:59:59','2018-12-15 03:59:59','NANOETH','4h','0.009267000000000','0.009081660000000','1.668137221410626','1.634774476982413','180.0083329460047','180.008332946004714','test','test','2.00'),('2018-12-18 11:59:59','2018-12-18 15:59:59','NANOETH','4h','0.009194000000000','0.009079000000000','1.660723278204356','1.639950689886594','180.6312027631451','180.631202763145097','test','test','1.25'),('2018-12-18 23:59:59','2018-12-19 03:59:59','NANOETH','4h','0.009180000000000','0.009402000000000','1.656107147467076','1.696156797438502','180.40382870011717','180.403828700117174','test','test','0.0'),('2018-12-19 07:59:59','2018-12-19 15:59:59','NANOETH','4h','0.009579000000000','0.009387420000000','1.665007069682948','1.631706928289289','173.81846431599834','173.818464315998341','test','test','2.00'),('2018-12-19 19:59:59','2018-12-20 19:59:59','NANOETH','4h','0.009495000000000','0.009305100000000','1.657607038262135','1.624454897496892','174.57683394019327','174.576833940193268','test','test','1.99'),('2019-01-09 11:59:59','2019-01-09 15:59:59','NANOETH','4h','0.006674000000000','0.006763000000000','1.650239895869859','1.672246391334710','247.26399398709304','247.263993987093045','test','test','0.0'),('2019-01-09 23:59:59','2019-01-14 15:59:59','NANOETH','4h','0.006854000000000','0.006798000000000','1.655130228195381','1.641607133246601','241.48383837107988','241.483838371079884','test','test','0.81'),('2019-01-15 23:59:59','2019-01-27 19:59:59','NANOETH','4h','0.007035000000000','0.008213000000000','1.652125095984541','1.928770918737887','234.8436525919746','234.843652591974603','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','NANOETH','4h','0.006418000000000','0.006387000000000','1.713601945485285','1.705324965069261','266.9993682588477','266.999368258847710','test','test','0.48'),('2019-03-01 11:59:59','2019-03-05 15:59:59','NANOETH','4h','0.006545000000000','0.006532000000000','1.711762616503946','1.708362629641524','261.53745095553035','261.537450955530346','test','test','0.44'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NANOETH','4h','0.006510000000000','0.006486000000000','1.711007063867853','1.704699203724561','262.82750597048425','262.827505970484253','test','test','0.36'),('2019-03-09 15:59:59','2019-03-09 19:59:59','NANOETH','4h','0.006552000000000','0.006610000000000','1.709605317169343','1.724739185972124','260.92877246174345','260.928772461743449','test','test','0.0'),('2019-03-09 23:59:59','2019-03-16 07:59:59','NANOETH','4h','0.006633000000000','0.007230000000000','1.712968399125516','1.867143302529396','258.2494194369842','258.249419436984226','test','test','0.0'),('2019-03-17 19:59:59','2019-03-19 23:59:59','NANOETH','4h','0.007329000000000','0.007182420000000','1.747229488770824','1.712284898995407','238.39943904636698','238.399439046366979','test','test','2.00'),('2019-03-20 11:59:59','2019-03-21 15:59:59','NANOETH','4h','0.007308000000000','0.007176000000000','1.739464024376286','1.708045133952412','238.0218971505591','238.021897150559113','test','test','1.80'),('2019-03-21 23:59:59','2019-03-22 03:59:59','NANOETH','4h','0.007230000000000','0.007180000000000','1.732482048726536','1.720500845070059','239.62407312953476','239.624073129534764','test','test','0.69'),('2019-03-24 03:59:59','2019-03-24 07:59:59','NANOETH','4h','0.007249000000000','0.007158000000000','1.729819559025097','1.708104345910008','238.62871555043412','238.628715550434123','test','test','1.25'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NANOETH','4h','0.007188000000000','0.007216000000000','1.724993956110633','1.731713465121637','239.9824646787191','239.982464678719111','test','test','0.0'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NANOETH','4h','0.007244000000000','0.007158000000000','1.726487180335300','1.705990507570414','238.33340424286308','238.333404242863082','test','test','1.18'),('2019-03-27 07:59:59','2019-03-29 11:59:59','NANOETH','4h','0.007222000000000','0.007276000000000','1.721932364165326','1.734807516154377','238.42874053798477','238.428740537984766','test','test','0.36'),('2019-03-31 11:59:59','2019-04-07 23:59:59','NANOETH','4h','0.007498000000000','0.008035000000000','1.724793509051781','1.848321665141512','230.03381022296364','230.033810222963638','test','test','0.0'),('2019-04-08 03:59:59','2019-04-12 03:59:59','NANOETH','4h','0.008190000000000','0.008932000000000','1.752244210405055','1.910994540578505','213.9492320396893','213.949232039689292','test','test','0.0'),('2019-04-12 11:59:59','2019-04-13 11:59:59','NANOETH','4h','0.009923000000000','0.009724540000000','1.787522061554711','1.751771620323616','180.13927860069643','180.139278600696429','test','test','2.00'),('2019-04-13 19:59:59','2019-04-14 11:59:59','NANOETH','4h','0.009546000000000','0.009355080000000','1.779577519058911','1.743985968677733','186.42127792362365','186.421277923623649','test','test','2.00'),('2019-04-17 07:59:59','2019-04-18 07:59:59','NANOETH','4h','0.009745000000000','0.009550100000000','1.771668285640872','1.736234919928055','181.80279996314746','181.802799963147464','test','test','1.99'),('2019-04-19 15:59:59','2019-04-21 11:59:59','NANOETH','4h','0.009496000000000','0.009556000000000','1.763794204371357','1.774938649639078','185.7407544620216','185.740754462021613','test','test','0.0'),('2019-04-21 15:59:59','2019-04-26 03:59:59','NANOETH','4h','0.009910000000000','0.010386000000000','1.766270747764184','1.851108777626520','178.23115517297518','178.231155172975178','test','test','0.95'),('2019-06-08 11:59:59','2019-06-08 15:59:59','NANOETH','4h','0.006482000000000','0.006424000000000','1.785123643289148','1.769150614700630','275.3970446296124','275.397044629612424','test','test','0.89'),('2019-06-08 19:59:59','2019-06-09 19:59:59','NANOETH','4h','0.006592000000000','0.006460160000000','1.781574081380588','1.745942599752976','270.263058461861','270.263058461861021','test','test','2.00'),('2019-06-13 11:59:59','2019-06-13 15:59:59','NANOETH','4h','0.006472000000000','0.006360000000000','1.773655974352230','1.742962298652686','274.05067588878705','274.050675888787055','test','test','1.73'),('2019-06-13 23:59:59','2019-06-14 07:59:59','NANOETH','4h','0.006924000000000','0.006785520000000','1.766835157530109','1.731498454379507','255.17549935443517','255.175499354435175','test','test','1.99'),('2019-07-07 15:59:59','2019-07-07 19:59:59','NANOETH','4h','0.004472000000000','0.004382560000000','1.758982556829975','1.723802905693376','393.33241431797296','393.332414317972962','test','test','1.99'),('2019-07-08 03:59:59','2019-07-08 07:59:59','NANOETH','4h','0.004561000000000','0.004469780000000','1.751164856577398','1.716141559445850','383.9431827619815','383.943182761981518','test','test','2.00'),('2019-07-09 03:59:59','2019-07-09 07:59:59','NANOETH','4h','0.004488000000000','0.004401000000000','1.743381901659276','1.709586396881122','388.4540779098209','388.454077909820910','test','test','1.93'),('2019-07-13 03:59:59','2019-07-13 11:59:59','NANOETH','4h','0.004450000000000','0.004371000000000','1.735871789486353','1.705055189178618','390.0835481991804','390.083548199180427','test','test','1.77'),('2019-07-14 15:59:59','2019-07-15 23:59:59','NANOETH','4h','0.004497000000000','0.004444000000000','1.729023656084634','1.708646014596423','384.4838016643616','384.483801664361579','test','test','1.93'),('2019-07-16 11:59:59','2019-07-21 11:59:59','NANOETH','4h','0.004481000000000','0.005357000000000','1.724495291309476','2.061620458724585','384.8460815240964','384.846081524096405','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:46:08
