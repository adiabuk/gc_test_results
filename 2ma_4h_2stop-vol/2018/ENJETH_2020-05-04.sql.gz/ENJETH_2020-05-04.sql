-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-29 19:59:59','2018-05-01 07:59:59','ENJETH','4h','0.000233300000000','0.000230920000000','1.297777777777778','1.284538553126637','5562.699433252369','5562.699433252369090','test','test','1.02'),('2018-05-03 11:59:59','2018-05-03 15:59:59','ENJETH','4h','0.000237740000000','0.000232985200000','1.294835727855302','1.268939013298196','5446.4361397127195','5446.436139712719523','test','test','2.00'),('2018-05-21 11:59:59','2018-05-22 11:59:59','ENJETH','4h','0.000203610000000','0.000203190000000','1.289080902398167','1.286421828781904','6331.127657768122','6331.127657768121935','test','test','0.79'),('2018-05-22 15:59:59','2018-05-23 03:59:59','ENJETH','4h','0.000203990000000','0.000203550000000','1.288489997150109','1.285710764840946','6316.437066278292','6316.437066278292150','test','test','0.38'),('2018-05-23 07:59:59','2018-05-23 11:59:59','ENJETH','4h','0.000203760000000','0.000201950000000','1.287872389970295','1.276432220035832','6320.535875394066','6320.535875394066352','test','test','0.88'),('2018-05-23 15:59:59','2018-05-23 19:59:59','ENJETH','4h','0.000202810000000','0.000198753800000','1.285330129984859','1.259623527385162','6337.6072678115415','6337.607267811541533','test','test','1.99'),('2018-05-24 03:59:59','2018-05-24 07:59:59','ENJETH','4h','0.000204440000000','0.000200351200000','1.279617551629370','1.254025200596782','6259.13496199066','6259.134961990659576','test','test','1.99'),('2018-06-07 15:59:59','2018-06-07 19:59:59','ENJETH','4h','0.000182530000000','0.000178879400000','1.273930362511017','1.248451755260797','6979.293061474921','6979.293061474921160','test','test','1.99'),('2018-06-07 23:59:59','2018-06-08 11:59:59','ENJETH','4h','0.000187750000000','0.000183995000000','1.268268449788746','1.242903080792971','6755.091610059901','6755.091610059900631','test','test','2.00'),('2018-07-02 15:59:59','2018-07-03 03:59:59','ENJETH','4h','0.000133350000000','0.000131810000000','1.262631701123019','1.248050127671730','9468.554189148997','9468.554189148997466','test','test','1.15'),('2018-07-03 11:59:59','2018-07-03 23:59:59','ENJETH','4h','0.000130580000000','0.000130440000000','1.259391351467177','1.258041108020972','9644.59604431901','9644.596044319010616','test','test','0.10'),('2018-07-04 15:59:59','2018-07-05 19:59:59','ENJETH','4h','0.000138870000000','0.000136092600000','1.259091297368020','1.233909471420660','9066.690410945632','9066.690410945631811','test','test','2.00'),('2018-07-06 19:59:59','2018-07-06 23:59:59','ENJETH','4h','0.000132460000000','0.000129810800000','1.253495336046384','1.228425429325456','9463.198973625127','9463.198973625127110','test','test','2.00'),('2018-07-07 11:59:59','2018-07-07 15:59:59','ENJETH','4h','0.000137000000000','0.000134260000000','1.247924245663956','1.222965760750677','9108.936099736904','9108.936099736903998','test','test','1.99'),('2018-07-07 23:59:59','2018-07-08 03:59:59','ENJETH','4h','0.000135080000000','0.000137240000000','1.242377915683227','1.262244189727318','9197.349094486432','9197.349094486431568','test','test','0.0'),('2018-07-08 15:59:59','2018-07-08 19:59:59','ENJETH','4h','0.000132780000000','0.000132850000000','1.246792643248581','1.247449937156002','9389.912963161474','9389.912963161474181','test','test','0.0'),('2018-07-09 11:59:59','2018-07-12 07:59:59','ENJETH','4h','0.000133810000000','0.000133540000000','1.246938708561341','1.244422652576650','9318.725869227568','9318.725869227568182','test','test','0.20'),('2018-07-12 15:59:59','2018-07-12 19:59:59','ENJETH','4h','0.000137320000000','0.000136870000000','1.246379585009187','1.242295177688665','9076.460712271974','9076.460712271973534','test','test','0.32'),('2018-07-13 11:59:59','2018-07-13 15:59:59','ENJETH','4h','0.000136480000000','0.000136110000000','1.245471938937960','1.242095439689667','9125.673644035465','9125.673644035465259','test','test','0.27'),('2018-07-18 19:59:59','2018-07-18 23:59:59','ENJETH','4h','0.000135800000000','0.000133084000000','1.244721605771673','1.219827173656240','9165.843930571966','9165.843930571965757','test','test','1.99'),('2018-07-24 11:59:59','2018-07-24 15:59:59','ENJETH','4h','0.000131870000000','0.000129232600000','1.239189509746021','1.214405719551101','9397.05399064246','9397.053990642460121','test','test','1.99'),('2018-07-24 23:59:59','2018-07-25 03:59:59','ENJETH','4h','0.000141690000000','0.000138856200000','1.233682000813817','1.209008360797541','8706.909455951843','8706.909455951843483','test','test','1.99'),('2018-07-28 11:59:59','2018-07-29 03:59:59','ENJETH','4h','0.000134610000000','0.000131917800000','1.228198969699089','1.203634990305107','9124.12874005712','9124.128740057120012','test','test','2.00'),('2018-07-29 15:59:59','2018-07-30 19:59:59','ENJETH','4h','0.000134810000000','0.000132113800000','1.222740307611537','1.198285501459306','9070.100939185057','9070.100939185056632','test','test','1.99'),('2018-07-30 23:59:59','2018-07-31 19:59:59','ENJETH','4h','0.000132990000000','0.000130330200000','1.217305906244375','1.192959788119488','9153.364209672716','9153.364209672716242','test','test','1.99'),('2018-08-07 11:59:59','2018-08-07 19:59:59','ENJETH','4h','0.000126860000000','0.000125350000000','1.211895657772178','1.197470603040695','9553.016378465849','9553.016378465848902','test','test','1.19'),('2018-08-07 23:59:59','2018-08-08 03:59:59','ENJETH','4h','0.000127180000000','0.000125830000000','1.208690090054070','1.195859993957412','9503.77488641351','9503.774886413510103','test','test','1.06'),('2018-08-13 03:59:59','2018-08-14 03:59:59','ENJETH','4h','0.000127730000000','0.000125175400000','1.205838957588146','1.181722178436383','9440.530475128367','9440.530475128367470','test','test','2.00'),('2018-08-14 11:59:59','2018-08-14 15:59:59','ENJETH','4h','0.000129760000000','0.000127164800000','1.200479673332199','1.176470079865555','9251.53878955147','9251.538789551470472','test','test','1.99'),('2018-08-15 03:59:59','2018-08-15 23:59:59','ENJETH','4h','0.000131850000000','0.000129213000000','1.195144208117389','1.171241323955041','9064.423269756458','9064.423269756458467','test','test','1.99'),('2018-08-16 11:59:59','2018-08-19 11:59:59','ENJETH','4h','0.000128970000000','0.000131090000000','1.189832456081312','1.209390840255092','9225.652912160283','9225.652912160283449','test','test','0.0'),('2018-08-19 15:59:59','2018-08-20 23:59:59','ENJETH','4h','0.000132190000000','0.000129546200000','1.194178763675485','1.170295188401975','9033.8056106777','9033.805610677700315','test','test','2.00'),('2018-08-21 11:59:59','2018-08-21 15:59:59','ENJETH','4h','0.000133280000000','0.000130650000000','1.188871302503594','1.165411432113554','8920.102809900915','8920.102809900914508','test','test','1.97'),('2018-08-22 03:59:59','2018-08-22 11:59:59','ENJETH','4h','0.000133780000000','0.000134220000000','1.183657997972474','1.187551027716142','8847.794871972446','8847.794871972446344','test','test','0.0'),('2018-08-24 19:59:59','2018-08-24 23:59:59','ENJETH','4h','0.000136120000000','0.000133520000000','1.184523115693289','1.161897784362092','8702.05051199889','8702.050511998890215','test','test','1.91'),('2018-08-26 23:59:59','2018-09-13 15:59:59','ENJETH','4h','0.000137360000000','0.000196310000000','1.179495264286356','1.685692452912453','8586.890392300205','8586.890392300205349','test','test','1.07'),('2018-09-13 19:59:59','2018-09-13 23:59:59','ENJETH','4h','0.000199330000000','0.000195343400000','1.291983528425489','1.266143857856979','6481.6311063336625','6481.631106333662501','test','test','2.0'),('2018-09-15 03:59:59','2018-09-15 15:59:59','ENJETH','4h','0.000197070000000','0.000193128600000','1.286241379410265','1.260516551822060','6526.824881566269','6526.824881566269141','test','test','2.00'),('2018-09-17 03:59:59','2018-09-17 11:59:59','ENJETH','4h','0.000198390000000','0.000195450000000','1.280524751057330','1.261548276597385','6454.583149641264','6454.583149641263844','test','test','1.48'),('2018-09-17 19:59:59','2018-09-18 15:59:59','ENJETH','4h','0.000199030000000','0.000195049400000','1.276307756732898','1.250781601598240','6412.6400880917345','6412.640088091734469','test','test','2.00'),('2018-09-20 11:59:59','2018-09-20 23:59:59','ENJETH','4h','0.000197010000000','0.000193069800000','1.270635277814085','1.245222572257803','6449.597877336608','6449.597877336607780','test','test','2.00'),('2018-09-25 11:59:59','2018-09-25 23:59:59','ENJETH','4h','0.000193470000000','0.000189600600000','1.264988009912689','1.239688249714435','6538.419444423884','6538.419444423883760','test','test','2.00'),('2018-09-26 03:59:59','2018-09-26 07:59:59','ENJETH','4h','0.000190010000000','0.000188620000000','1.259365840979744','1.250153070499444','6627.892431870659','6627.892431870658584','test','test','0.73'),('2018-09-27 07:59:59','2018-09-27 23:59:59','ENJETH','4h','0.000194500000000','0.000190760000000','1.257318558650788','1.233141841893184','6464.362769412793','6464.362769412792659','test','test','1.92'),('2018-09-28 03:59:59','2018-10-03 03:59:59','ENJETH','4h','0.000253010000000','0.000247949800000','1.251945954926876','1.226907035828338','4948.207402580437','4948.207402580436792','test','test','1.99'),('2018-10-03 23:59:59','2018-10-04 07:59:59','ENJETH','4h','0.000248890000000','0.000243912200000','1.246381750682757','1.221454115669102','5007.761463629543','5007.761463629542959','test','test','2.00'),('2018-10-04 11:59:59','2018-10-06 23:59:59','ENJETH','4h','0.000245450000000','0.000240541000000','1.240842276235278','1.216025430710572','5055.376965717164','5055.376965717164239','test','test','2.00'),('2018-10-10 15:59:59','2018-10-11 07:59:59','ENJETH','4h','0.000244420000000','0.000239640000000','1.235327421674232','1.211168739587648','5054.117591335537','5054.117591335537327','test','test','1.95'),('2018-10-11 11:59:59','2018-10-11 15:59:59','ENJETH','4h','0.000243220000000','0.000242580000000','1.229958825654991','1.226722358060142','5056.980616951695','5056.980616951695083','test','test','0.26'),('2018-10-12 11:59:59','2018-10-12 15:59:59','ENJETH','4h','0.000243770000000','0.000242920000000','1.229239610633914','1.224953383169342','5042.620546555826','5042.620546555825968','test','test','0.34'),('2018-10-14 03:59:59','2018-10-15 03:59:59','ENJETH','4h','0.000245220000000','0.000242750000000','1.228287115641786','1.215915085727280','5008.91899372721','5008.918993727210363','test','test','1.00'),('2018-10-19 03:59:59','2018-10-19 05:59:59','ENJETH','4h','0.000241550000000','0.000242390000000','1.225537775660785','1.229799633377842','5073.640139353282','5073.640139353282393','test','test','0.0'),('2018-10-20 03:59:59','2018-10-20 07:59:59','ENJETH','4h','0.000239400000000','0.000238450000000','1.226484855153464','1.221617851759998','5123.161466806451','5123.161466806451244','test','test','0.39'),('2018-10-20 15:59:59','2018-10-21 07:59:59','ENJETH','4h','0.000254300000000','0.000249214000000','1.225403298843805','1.200895232866929','4818.731021800258','4818.731021800257622','test','test','2.00'),('2018-10-21 11:59:59','2018-10-21 15:59:59','ENJETH','4h','0.000255190000000','0.000250086200000','1.219957061960055','1.195557920720854','4780.583337748561','4780.583337748560552','test','test','2.00'),('2018-10-22 03:59:59','2018-10-22 07:59:59','ENJETH','4h','0.000245590000000','0.000246200000000','1.214535030573566','1.217551710278154','4945.376564899083','4945.376564899082950','test','test','0.0'),('2018-10-24 15:59:59','2018-10-26 03:59:59','ENJETH','4h','0.000251670000000','0.000248350000000','1.215205403841252','1.199174562101065','4828.566789213066','4828.566789213065931','test','test','1.31'),('2018-10-31 19:59:59','2018-11-02 23:59:59','ENJETH','4h','0.000248850000000','0.000248100000000','1.211642994565655','1.207991267638091','4868.969236751677','4868.969236751677272','test','test','0.30'),('2018-11-03 03:59:59','2018-11-03 11:59:59','ENJETH','4h','0.000251200000000','0.000248220000000','1.210831499692863','1.196467336201284','4820.18909113401','4820.189091134009686','test','test','1.18'),('2018-11-09 07:59:59','2018-11-09 11:59:59','ENJETH','4h','0.000240340000000','0.000236510000000','1.207639463361401','1.188394813512544','5024.71275427062','5024.712754270620280','test','test','1.59'),('2018-11-09 15:59:59','2018-11-09 19:59:59','ENJETH','4h','0.000241910000000','0.000242750000000','1.203362874506100','1.207541390543408','4974.423853937827','4974.423853937826607','test','test','0.0'),('2018-11-10 03:59:59','2018-11-10 15:59:59','ENJETH','4h','0.000243920000000','0.000240520000000','1.204291433625501','1.187504819676966','4937.239396627998','4937.239396627997849','test','test','1.39'),('2018-11-12 07:59:59','2018-11-12 15:59:59','ENJETH','4h','0.000245910000000','0.000241380000000','1.200561074970271','1.178445090790631','4882.115712944862','4882.115712944862025','test','test','1.84'),('2018-11-12 23:59:59','2018-11-13 03:59:59','ENJETH','4h','0.000239970000000','0.000239740000000','1.195646411819240','1.194500440761531','4982.482859604284','4982.482859604284386','test','test','0.09'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ENJETH','4h','0.000239800000000','0.000240530000000','1.195391751584194','1.199030767341727','4984.953092511233','4984.953092511233081','test','test','0.0'),('2018-11-28 11:59:59','2018-11-28 15:59:59','ENJETH','4h','0.000246780000000','0.000241844400000','1.196200421752534','1.172276413317483','4847.2340617251575','4847.234061725157517','test','test','2.00'),('2018-11-29 11:59:59','2018-11-29 15:59:59','ENJETH','4h','0.000234460000000','0.000229770800000','1.190883975433634','1.167066295924961','5079.262882511449','5079.262882511448879','test','test','2.00'),('2018-11-29 19:59:59','2018-11-30 11:59:59','ENJETH','4h','0.000229600000000','0.000225008000000','1.185591157765040','1.161879334609739','5163.724554725784','5163.724554725784401','test','test','2.00'),('2018-12-01 19:59:59','2018-12-23 03:59:59','ENJETH','4h','0.000244110000000','0.000338000000000','1.180321863730529','1.634299250095935','4835.204881940637','4835.204881940637279','test','test','1.36'),('2018-12-27 07:59:59','2018-12-28 11:59:59','ENJETH','4h','0.000341280000000','0.000334454400000','1.281205727367286','1.255581612819940','3754.118985487827','3754.118985487827103','test','test','2.00'),('2019-01-11 15:59:59','2019-01-11 19:59:59','ENJETH','4h','0.000271290000000','0.000273050000000','1.275511479690098','1.283786389212213','4701.653137565328','4701.653137565327597','test','test','0.0'),('2019-01-12 07:59:59','2019-01-12 19:59:59','ENJETH','4h','0.000297960000000','0.000292000800000','1.277350348472790','1.251803341503334','4286.985999707309','4286.985999707309020','test','test','2.00'),('2019-01-13 19:59:59','2019-01-13 23:59:59','ENJETH','4h','0.000287220000000','0.000281475600000','1.271673235812911','1.246239771096653','4427.523277671858','4427.523277671857613','test','test','1.99'),('2019-01-15 23:59:59','2019-01-16 11:59:59','ENJETH','4h','0.000285580000000','0.000279868400000','1.266021354764854','1.240700927669557','4433.15832609025','4433.158326090249830','test','test','2.00'),('2019-01-17 07:59:59','2019-01-17 15:59:59','ENJETH','4h','0.000277400000000','0.000277070000000','1.260394593188121','1.258895205243809','4543.599831247731','4543.599831247731345','test','test','0.64'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ENJETH','4h','0.000278140000000','0.000281100000000','1.260061395867163','1.273471123816278','4530.313496322581','4530.313496322581159','test','test','0.52'),('2019-01-20 23:59:59','2019-01-21 07:59:59','ENJETH','4h','0.000278970000000','0.000280830000000','1.263041335411410','1.271462516484160','4527.51670577987','4527.516705779869881','test','test','0.0'),('2019-01-21 15:59:59','2019-01-21 23:59:59','ENJETH','4h','0.000285220000000','0.000288000000000','1.264912708983132','1.277241638689931','4434.866801006706','4434.866801006705828','test','test','0.0'),('2019-01-23 03:59:59','2019-01-23 23:59:59','ENJETH','4h','0.000301900000000','0.000295862000000','1.267652471140199','1.242299421717395','4198.915108115928','4198.915108115927978','test','test','1.99'),('2019-01-24 15:59:59','2019-01-25 11:59:59','ENJETH','4h','0.000299320000000','0.000293333600000','1.262018460157354','1.236778090954207','4216.285113448328','4216.285113448328048','test','test','2.00'),('2019-02-11 11:59:59','2019-02-11 23:59:59','ENJETH','4h','0.000272270000000','0.000266824600000','1.256409489223321','1.231281299438855','4614.571892692256','4614.571892692256370','test','test','2.0'),('2019-02-20 07:59:59','2019-02-20 11:59:59','ENJETH','4h','0.000263680000000','0.000258406400000','1.250825447048995','1.225808938108015','4743.725148092366','4743.725148092365998','test','test','2.00'),('2019-02-20 15:59:59','2019-02-20 19:59:59','ENJETH','4h','0.000257910000000','0.000252751800000','1.245266222839889','1.220360898383091','4828.297556666623','4828.297556666622768','test','test','2.00'),('2019-02-21 03:59:59','2019-02-21 07:59:59','ENJETH','4h','0.000258680000000','0.000253710000000','1.239731706293933','1.215912831312176','4792.530177415854','4792.530177415854268','test','test','1.92'),('2019-02-22 03:59:59','2019-02-23 19:59:59','ENJETH','4h','0.000262400000000','0.000257152000000','1.234438622964654','1.209749850505361','4704.415483859199','4704.415483859199412','test','test','2.00'),('2019-02-25 03:59:59','2019-03-16 07:59:59','ENJETH','4h','0.000303950000000','0.001167460000000','1.228952229084811','4.720357194825969','4043.2710284086565','4043.271028408656548','test','test','0.0'),('2019-03-17 07:59:59','2019-03-24 11:59:59','ENJETH','4h','0.001177280000000','0.001318800000000','2.004819999249513','2.245817999974737','1702.9253866960391','1702.925386696039141','test','test','0.94'),('2019-04-13 07:59:59','2019-04-13 11:59:59','ENJETH','4h','0.000951090000000','0.000932068200000','2.058375110521785','2.017207608311349','2164.2274763921237','2164.227476392123663','test','test','1.99'),('2019-04-13 19:59:59','2019-04-14 15:59:59','ENJETH','4h','0.001030760000000','0.001010144800000','2.049226776697244','2.008242241163299','1988.073631783581','1988.073631783581050','test','test','1.99'),('2019-04-17 07:59:59','2019-04-20 11:59:59','ENJETH','4h','0.000968200000000','0.001156600000000','2.040119102134144','2.437101583896252','2107.1256993742454','2107.125699374245414','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:51:09
