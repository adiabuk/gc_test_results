-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 15:59:59','2018-02-10 11:59:59','BNBETH','4h','0.011279000000000','0.011053420000000','1.297777777777778','1.271822222222222','115.06142191486636','115.061421914866358','test','test','1.99'),('2018-02-14 15:59:59','2018-02-20 07:59:59','BNBETH','4h','0.010883000000000','0.011438000000000','1.292009876543210','1.357898462547205','118.7181729801718','118.718172980171801','test','test','0.0'),('2018-02-23 23:59:59','2018-02-24 03:59:59','BNBETH','4h','0.011455000000000','0.011230000000000','1.306651784544097','1.280986428671341','114.06824832336076','114.068248323360763','test','test','1.96'),('2018-02-26 15:59:59','2018-02-26 19:59:59','BNBETH','4h','0.011426000000000','0.011364000000000','1.300948372127930','1.293889138881656','113.85860074636176','113.858600746361759','test','test','0.54'),('2018-02-27 03:59:59','2018-03-06 07:59:59','BNBETH','4h','0.011464000000000','0.011729000000000','1.299379653628758','1.329415906961942','113.34435220069413','113.344352200694132','test','test','0.0'),('2018-03-07 07:59:59','2018-03-07 19:59:59','BNBETH','4h','0.011924000000000','0.011885000000000','1.306054376591687','1.301782645571302','109.53156462526731','109.531564625267308','test','test','0.32'),('2018-03-07 23:59:59','2018-03-08 03:59:59','BNBETH','4h','0.012088000000000','0.011846240000000','1.305105103031602','1.279003000970970','107.967000581701','107.967000581701001','test','test','2.00'),('2018-03-08 23:59:59','2018-03-09 03:59:59','BNBETH','4h','0.011859000000000','0.011621820000000','1.299304635907017','1.273318543188877','109.56274862189197','109.562748621891970','test','test','2.00'),('2018-03-13 07:59:59','2018-03-13 11:59:59','BNBETH','4h','0.011558000000000','0.011523000000000','1.293529948636319','1.289612874038441','111.91641708222174','111.916417082221741','test','test','0.30'),('2018-03-13 15:59:59','2018-04-07 19:59:59','BNBETH','4h','0.014000000000000','0.031920000000000','1.292659487614569','2.947263631761217','92.33282054389775','92.332820543897753','test','test','0.0'),('2018-04-10 03:59:59','2018-04-10 15:59:59','BNBETH','4h','0.030897000000000','0.030279060000000','1.660349297424935','1.627142311476436','53.73820427306647','53.738204273066472','test','test','2.00'),('2018-05-09 23:59:59','2018-05-10 03:59:59','BNBETH','4h','0.019473000000000','0.019184000000000','1.652969967214157','1.628438137474266','84.88522401346259','84.885224013462590','test','test','1.48'),('2018-05-17 23:59:59','2018-05-18 03:59:59','BNBETH','4h','0.018527000000000','0.018341000000000','1.647518449494181','1.630978349553234','88.92526849971293','88.925268499712928','test','test','1.00'),('2018-05-18 11:59:59','2018-05-18 15:59:59','BNBETH','4h','0.021839000000000','0.021402220000000','1.643842871729526','1.610966014294935','75.27097723016284','75.270977230162842','test','test','2.00'),('2018-05-18 19:59:59','2018-05-19 15:59:59','BNBETH','4h','0.021751000000000','0.021315980000000','1.636536903410729','1.603806165342514','75.23961672616103','75.239616726161032','test','test','2.00'),('2018-05-22 11:59:59','2018-06-19 15:59:59','BNBETH','4h','0.021001000000000','0.030597000000000','1.629263406062236','2.373723748168479','77.58027741832467','77.580277418324670','test','test','0.88'),('2018-06-21 15:59:59','2018-06-24 07:59:59','BNBETH','4h','0.031393000000000','0.032042000000000','1.794699037641402','1.831801566084981','57.16876493617691','57.168764936176913','test','test','0.0'),('2018-06-24 15:59:59','2018-06-25 03:59:59','BNBETH','4h','0.031994000000000','0.031354120000000','1.802944043962197','1.766885163082953','56.35256748022118','56.352567480221182','test','test','2.00'),('2018-06-25 07:59:59','2018-06-25 15:59:59','BNBETH','4h','0.032496000000000','0.031964000000000','1.794930959322365','1.765545703587521','55.23544311060945','55.235443110609452','test','test','1.63'),('2018-06-26 23:59:59','2018-06-27 23:59:59','BNBETH','4h','0.032743000000000','0.032088140000000','1.788400902492399','1.752632884442551','54.61933550659375','54.619335506593750','test','test','2.00'),('2018-06-28 11:59:59','2018-06-30 03:59:59','BNBETH','4h','0.033437000000000','0.032837000000000','1.780452454036878','1.748503670580763','53.247972426858794','53.247972426858794','test','test','1.79'),('2018-07-25 11:59:59','2018-07-25 23:59:59','BNBETH','4h','0.027613000000000','0.027520000000000','1.773352724379963','1.767380109909701','64.221660970556','64.221660970556002','test','test','1.45'),('2018-07-26 15:59:59','2018-08-14 03:59:59','BNBETH','4h','0.028440000000000','0.034927000000000','1.772025476719905','2.176214269528697','62.30750621378005','62.307506213780051','test','test','1.14'),('2018-08-14 19:59:59','2018-08-14 23:59:59','BNBETH','4h','0.035204000000000','0.034499920000000','1.861845208455192','1.824608304286088','52.88731986294716','52.887319862947159','test','test','2.00'),('2018-08-15 03:59:59','2018-08-15 07:59:59','BNBETH','4h','0.035546000000000','0.035527000000000','1.853570340862057','1.852579572942280','52.1456799882422','52.145679988242200','test','test','0.05'),('2018-08-20 23:59:59','2018-08-21 03:59:59','BNBETH','4h','0.035610000000000','0.034897800000000','1.853350170213218','1.816283166808953','52.045778439012025','52.045778439012025','test','test','2.00'),('2018-08-22 03:59:59','2018-09-13 19:59:59','BNBETH','4h','0.034990000000000','0.046713000000000','1.845113058345604','2.463297121877628','52.73258240484721','52.732582404847207','test','test','0.50'),('2018-09-14 23:59:59','2018-09-15 15:59:59','BNBETH','4h','0.047351000000000','0.046403980000000','1.982487294686053','1.942837548792332','41.86790764051559','41.867907640515590','test','test','1.99'),('2018-09-17 19:59:59','2018-09-18 15:59:59','BNBETH','4h','0.047336000000000','0.046389280000000','1.973676240043004','1.934202715242144','41.69503633688956','41.695036336889558','test','test','1.99'),('2018-09-25 07:59:59','2018-09-25 23:59:59','BNBETH','4h','0.045787000000000','0.044871260000000','1.964904345642813','1.925606258729957','42.914022443986575','42.914022443986575','test','test','1.99'),('2018-09-26 03:59:59','2018-09-26 15:59:59','BNBETH','4h','0.045700000000000','0.044797000000000','1.956171437439957','1.917518859584196','42.804626639824','42.804626639824001','test','test','1.97'),('2018-09-28 19:59:59','2018-09-29 11:59:59','BNBETH','4h','0.045185000000000','0.044281300000000','1.947581975694232','1.908630336180347','43.10240070143259','43.102400701432593','test','test','2.00'),('2018-10-02 23:59:59','2018-10-09 03:59:59','BNBETH','4h','0.045773000000000','0.046164000000000','1.938926055802257','1.955488660128359','42.35960185703924','42.359601857039237','test','test','0.03'),('2018-10-09 11:59:59','2018-10-09 15:59:59','BNBETH','4h','0.046130000000000','0.045207400000000','1.942606634541391','1.903754501850563','42.1115680585604','42.111568058560401','test','test','2.00'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBETH','4h','0.045916000000000','0.045873000000000','1.933972827276763','1.932161675792032','42.119801970484424','42.119801970484424','test','test','0.09'),('2018-10-11 03:59:59','2018-10-15 07:59:59','BNBETH','4h','0.047947000000000','0.047632000000000','1.933570349169045','1.920867267433207','40.32724360583655','40.327243605836550','test','test','1.89'),('2018-10-15 15:59:59','2018-10-16 11:59:59','BNBETH','4h','0.049001000000000','0.048020980000000','1.930747442116637','1.892132493274304','39.40220489615797','39.402204896157969','test','test','1.99'),('2018-10-17 07:59:59','2018-10-20 11:59:59','BNBETH','4h','0.047571000000000','0.047631000000000','1.922166342373895','1.924590718160455','40.40626310932912','40.406263109329117','test','test','0.0'),('2018-10-20 15:59:59','2018-10-20 19:59:59','BNBETH','4h','0.047724000000000','0.047598000000000','1.922705092548687','1.917628803015933','40.2880121647114','40.288012164711397','test','test','0.26'),('2018-10-21 19:59:59','2018-10-21 23:59:59','BNBETH','4h','0.047684000000000','0.047843000000000','1.921577028208074','1.927984434203483','40.298150914522154','40.298150914522154','test','test','0.0'),('2018-10-22 15:59:59','2018-10-24 11:59:59','BNBETH','4h','0.047876000000000','0.047965000000000','1.923000896207055','1.926575695266342','40.16628156502328','40.166281565023283','test','test','0.08'),('2018-10-24 19:59:59','2018-10-24 23:59:59','BNBETH','4h','0.048033000000000','0.048150000000000','1.923795295998007','1.928481325386797','40.05153323752435','40.051533237524353','test','test','0.0'),('2018-10-25 07:59:59','2018-10-25 15:59:59','BNBETH','4h','0.048252000000000','0.047888000000000','1.924836635862183','1.910316190379014','39.891333744967724','39.891333744967724','test','test','0.75'),('2018-10-29 19:59:59','2018-10-30 11:59:59','BNBETH','4h','0.047938000000000','0.047815000000000','1.921609870199256','1.916679376352318','40.08531582876332','40.085315828763321','test','test','0.25'),('2018-11-01 15:59:59','2018-11-02 11:59:59','BNBETH','4h','0.047897000000000','0.047836000000000','1.920514204899937','1.918068302933240','40.09675355241323','40.096753552413233','test','test','0.12'),('2018-11-14 15:59:59','2018-11-14 19:59:59','BNBETH','4h','0.046758000000000','0.046472000000000','1.919970671129559','1.908226977816264','41.06186473180118','41.061864731801180','test','test','0.61'),('2018-11-19 07:59:59','2018-11-19 15:59:59','BNBETH','4h','0.045891000000000','0.044973180000000','1.917360961504383','1.879013742274295','41.780762273743925','41.780762273743925','test','test','1.99'),('2018-11-26 23:59:59','2018-11-27 19:59:59','BNBETH','4h','0.045665000000000','0.044906000000000','1.908839357231030','1.877112453209606','41.800927564459215','41.800927564459215','test','test','1.66'),('2018-11-29 11:59:59','2018-11-29 19:59:59','BNBETH','4h','0.045600000000000','0.044709000000000','1.901788934115158','1.864628979284092','41.70589767796398','41.705897677963982','test','test','1.95'),('2018-11-29 23:59:59','2018-11-30 11:59:59','BNBETH','4h','0.045568000000000','0.044656640000000','1.893531166374921','1.855660543047423','41.55396695871931','41.553966958719307','test','test','2.0'),('2018-12-03 11:59:59','2018-12-07 19:59:59','BNBETH','4h','0.045260000000000','0.048342000000000','1.885115472302143','2.013483255899916','41.65080583964081','41.650805839640810','test','test','0.0'),('2018-12-10 23:59:59','2018-12-17 19:59:59','BNBETH','4h','0.051521000000000','0.053070000000000','1.913641646434982','1.971176067551183','37.14294455532661','37.142944555326608','test','test','0.0'),('2018-12-17 23:59:59','2018-12-19 07:59:59','BNBETH','4h','0.053834000000000','0.052927000000000','1.926427073349693','1.893970459397021','35.78457988166759','35.784579881667590','test','test','1.68'),('2018-12-19 11:59:59','2018-12-20 03:59:59','BNBETH','4h','0.053425000000000','0.054186000000000','1.919214492471322','1.946552297408536','35.923528169795446','35.923528169795446','test','test','0.0'),('2018-12-31 23:59:59','2019-01-01 03:59:59','BNBETH','4h','0.046469000000000','0.045539620000000','1.925289560235147','1.886783769030444','41.43169769599403','41.431697695994032','test','test','2.00'),('2019-01-08 11:59:59','2019-01-24 19:59:59','BNBETH','4h','0.043388000000000','0.055440000000000','1.916732717745213','2.449148655660427','44.17656305303801','44.176563053038009','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:13:48
