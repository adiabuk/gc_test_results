-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 23:59:59','2018-03-21 03:59:59','LINKETH','4h','0.000703000000000','0.000707100000000','1.297777777777778','1.305346609767663','1846.0565828986882','1846.056582898688248','test','test','0.0'),('2018-03-21 07:59:59','2018-03-21 11:59:59','LINKETH','4h','0.000713320000000','0.000722970000000','1.299459740442197','1.317039208977030','1821.7065839205356','1821.706583920535650','test','test','0.0'),('2018-03-21 15:59:59','2018-03-22 15:59:59','LINKETH','4h','0.000775000000000','0.000759500000000','1.303366289005493','1.277298963225383','1681.7629535554745','1681.762953555474496','test','test','1.99'),('2018-03-24 15:59:59','2018-03-25 03:59:59','LINKETH','4h','0.000789830000000','0.000774033400000','1.297573549943246','1.271622078944381','1642.8516895322362','1642.851689532236151','test','test','1.99'),('2018-03-26 23:59:59','2018-03-27 07:59:59','LINKETH','4h','0.000758480000000','0.000749400000000','1.291806556387943','1.276341938293857','1703.1517724764567','1703.151772476456699','test','test','1.19'),('2018-03-27 15:59:59','2018-03-29 11:59:59','LINKETH','4h','0.000770000000000','0.000754600000000','1.288369974589257','1.262602575097472','1673.2077592068276','1673.207759206827632','test','test','2.00'),('2018-04-04 19:59:59','2018-04-04 23:59:59','LINKETH','4h','0.000743590000000','0.000767000000000','1.282643885813305','1.323024597451290','1724.9342861164148','1724.934286116414796','test','test','0.0'),('2018-04-08 03:59:59','2018-04-08 07:59:59','LINKETH','4h','0.000790850000000','0.000775033000000','1.291617377288413','1.265785029742645','1633.2014633475537','1633.201463347553727','test','test','2.00'),('2018-04-08 19:59:59','2018-04-09 11:59:59','LINKETH','4h','0.000804000000000','0.000787920000000','1.285876855611576','1.260159318499344','1599.3493228999696','1599.349322899969593','test','test','2.00'),('2018-04-10 03:59:59','2018-04-12 23:59:59','LINKETH','4h','0.000810000000000','0.000793800000000','1.280161847364413','1.254558610417125','1580.4467251412505','1580.446725141250454','test','test','1.99'),('2018-04-13 15:59:59','2018-04-13 23:59:59','LINKETH','4h','0.000795000000000','0.000779100000000','1.274472239153904','1.248982794370826','1603.1097347847851','1603.109734784785132','test','test','2.00'),('2018-04-16 11:59:59','2018-04-16 15:59:59','LINKETH','4h','0.000794280000000','0.000795000000000','1.268807918090998','1.269958068794812','1597.4315330752356','1597.431533075235620','test','test','0.0'),('2018-04-16 23:59:59','2018-04-20 11:59:59','LINKETH','4h','0.000801680000000','0.000806820000000','1.269063507136290','1.277200153212880','1583.005073266503','1583.005073266502905','test','test','0.0'),('2018-04-29 15:59:59','2018-04-29 23:59:59','LINKETH','4h','0.000763650000000','0.000749980000000','1.270871650708866','1.248121941463544','1664.2069674705238','1664.206967470523750','test','test','1.79'),('2018-04-30 07:59:59','2018-04-30 11:59:59','LINKETH','4h','0.000756820000000','0.000756230000000','1.265816159765461','1.264829357706502','1672.545862642981','1672.545862642981092','test','test','0.07'),('2018-04-30 15:59:59','2018-05-03 07:59:59','LINKETH','4h','0.000808720000000','0.000792545600000','1.265596870419025','1.240284933010644','1564.9382609791096','1564.938260979109600','test','test','2.00'),('2018-05-07 23:59:59','2018-05-08 23:59:59','LINKETH','4h','0.000765710000000','0.000750395800000','1.259971995439385','1.234772555530597','1645.495024799709','1645.495024799708972','test','test','2.00'),('2018-05-15 15:59:59','2018-05-15 19:59:59','LINKETH','4h','0.000724110000000','0.000727950000000','1.254372119904099','1.261024132637567','1732.2949826740396','1732.294982674039602','test','test','0.0'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKETH','4h','0.000622050000000','0.000622350000000','1.255850344955981','1.256456011869391','2018.8897113672226','2018.889711367222617','test','test','0.70'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKETH','4h','0.000455540000000','0.000484080000000','1.255984937603405','1.334673549183510','2757.1342529819667','2757.134252981966711','test','test','1.39'),('2018-07-06 23:59:59','2018-07-10 03:59:59','LINKETH','4h','0.000489000000000','0.000484350000000','1.273471295732318','1.261361599361857','2604.2357785936965','2604.235778593696523','test','test','0.95'),('2018-07-17 15:59:59','2018-07-20 11:59:59','LINKETH','4h','0.000475000000000','0.000472210000000','1.270780252094437','1.263316090192661','2675.3268465146048','2675.326846514604767','test','test','0.58'),('2018-07-20 19:59:59','2018-07-20 23:59:59','LINKETH','4h','0.000486540000000','0.000476809200000','1.269121549449598','1.243739118460606','2608.4629207251164','2608.462920725116419','test','test','2.00'),('2018-07-25 03:59:59','2018-07-25 07:59:59','LINKETH','4h','0.000501930000000','0.000491891400000','1.263481009229822','1.238211389045226','2517.2454510187117','2517.245451018711719','test','test','1.99'),('2018-07-25 15:59:59','2018-08-04 15:59:59','LINKETH','4h','0.000498820000000','0.000627750000000','1.257865538077690','1.582986030087547','2521.682246256545','2521.682246256545113','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKETH','4h','0.000630040000000','0.000617439200000','1.330114536302103','1.303512245576061','2111.15887293204','2111.158872932040140','test','test','2.00'),('2018-08-09 03:59:59','2018-08-29 19:59:59','LINKETH','4h','0.000685000000000','0.001090000000000','1.324202916140760','2.107125808165589','1933.1429432711823','1933.142943271182276','test','test','0.0'),('2018-08-31 07:59:59','2018-08-31 11:59:59','LINKETH','4h','0.001132470000000','0.001109820600000','1.498185781035166','1.468222065414463','1322.9363965801883','1322.936396580188330','test','test','1.99'),('2018-08-31 23:59:59','2018-09-01 03:59:59','LINKETH','4h','0.001158760000000','0.001135584800000','1.491527177563899','1.461696634012621','1287.1752369463038','1287.175236946303812','test','test','1.99'),('2018-09-05 19:59:59','2018-09-14 03:59:59','LINKETH','4h','0.001129500000000','0.001231530000000','1.484898167885837','1.619031997075206','1314.6508790489925','1314.650879048992465','test','test','0.0'),('2018-09-16 15:59:59','2018-09-16 19:59:59','LINKETH','4h','0.001263740000000','0.001238465200000','1.514705685483475','1.484411571773805','1198.5896509436077','1198.589650943607694','test','test','2.00'),('2018-09-17 19:59:59','2018-09-22 03:59:59','LINKETH','4h','0.001348770000000','0.001420980000000','1.507973660214659','1.588707052864333','1118.036181272314','1118.036181272314025','test','test','0.0'),('2018-09-24 23:59:59','2018-09-28 19:59:59','LINKETH','4h','0.001470130000000','0.001509950000000','1.525914414136809','1.567245393010056','1037.9452253452475','1037.945225345247536','test','test','0.0'),('2018-10-04 23:59:59','2018-10-05 03:59:59','LINKETH','4h','0.001446960000000','0.001456510000000','1.535099076108642','1.545230797909409','1060.9132775672042','1060.913277567204204','test','test','0.0'),('2018-10-05 15:59:59','2018-10-06 23:59:59','LINKETH','4h','0.001535680000000','0.001504966400000','1.537350569842145','1.506603558445302','1001.0878372070648','1001.087837207064808','test','test','2.00'),('2018-10-09 19:59:59','2018-10-15 07:59:59','LINKETH','4h','0.001489320000000','0.001574720000000','1.530517900642847','1.618280254411613','1027.6622221167022','1027.662222116702196','test','test','0.17'),('2018-10-15 15:59:59','2018-11-04 19:59:59','LINKETH','4h','0.001640010000000','0.002363900000000','1.550020645924795','2.234189916464913','945.1287772176968','945.128777217696779','test','test','1.36'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LINKETH','4h','0.002407460000000','0.002359310800000','1.702058261600377','1.668017096368369','706.9933712711226','706.993371271122555','test','test','2.0'),('2018-11-08 15:59:59','2018-11-08 23:59:59','LINKETH','4h','0.002398420000000','0.002350451600000','1.694493558215486','1.660603687051176','706.5040977874959','706.504097787495880','test','test','1.99'),('2018-11-10 03:59:59','2018-11-19 19:59:59','LINKETH','4h','0.002416070000000','0.002755250000000','1.686962475734528','1.923786712002366','698.2258277841818','698.225827784181774','test','test','0.12'),('2018-11-22 15:59:59','2018-11-22 23:59:59','LINKETH','4h','0.002800010000000','0.002744009800000','1.739590083794048','1.704798282118167','621.2799539266101','621.279953926610119','test','test','2.00'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKETH','4h','0.002893880000000','0.002836002400000','1.731858572310519','1.697221400864309','598.4555587344736','598.455558734473584','test','test','2.00'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKETH','4h','0.003130000000000','0.003067400000000','1.724161423100250','1.689678194638245','550.8502949202075','550.850294920207489','test','test','1.99'),('2018-11-30 03:59:59','2018-11-30 07:59:59','LINKETH','4h','0.003175000000000','0.003111500000000','1.716498483442026','1.682168513773185','540.6294436037879','540.629443603787877','test','test','2.00'),('2018-12-08 19:59:59','2018-12-08 23:59:59','LINKETH','4h','0.002741280000000','0.002686454400000','1.708869601293395','1.674692209267527','623.3838211687222','623.383821168722193','test','test','1.99'),('2018-12-12 07:59:59','2018-12-12 15:59:59','LINKETH','4h','0.002601070000000','0.002555680000000','1.701274625287647','1.671586514148075','654.0672205237254','654.067220523725382','test','test','1.74'),('2018-12-18 11:59:59','2018-12-22 03:59:59','LINKETH','4h','0.002571230000000','0.002650300000000','1.694677267256631','1.746791676127865','659.0920560419063','659.092056041906289','test','test','0.0'),('2019-01-03 11:59:59','2019-01-26 19:59:59','LINKETH','4h','0.002312050000000','0.004074820000000','1.706258247005794','3.007156086617568','737.9850120048415','737.985012004841451','test','test','0.0'),('2019-01-29 07:59:59','2019-01-29 15:59:59','LINKETH','4h','0.004022410000000','0.004109550000000','1.995346655808410','2.038573106515112','496.0575017982777','496.057501798277713','test','test','0.0'),('2019-01-29 19:59:59','2019-01-30 03:59:59','LINKETH','4h','0.004291500000000','0.004205670000000','2.004952533743233','1.964853483068368','467.1915492818904','467.191549281890389','test','test','2.00'),('2019-02-05 19:59:59','2019-02-06 07:59:59','LINKETH','4h','0.003894150000000','0.003935530000000','1.996041633593262','2.017251962624781','512.5744086882279','512.574408688227891','test','test','0.0'),('2019-02-06 11:59:59','2019-02-06 15:59:59','LINKETH','4h','0.003969940000000','0.003890541200000','2.000755040044711','1.960739939243817','503.976140708603','503.976140708602998','test','test','1.99'),('2019-02-08 03:59:59','2019-02-08 11:59:59','LINKETH','4h','0.003946080000000','0.003885270000000','1.991862795422290','1.961167731817490','504.7699984344692','504.769998434469187','test','test','1.54'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKETH','4h','0.004048190000000','0.003967226200000','1.985041670176779','1.945340836773243','490.3528910888025','490.352891088802494','test','test','2.00'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKETH','4h','0.003979650000000','0.003900057000000','1.976219262753771','1.936694877498695','496.5811724030433','496.581172403043297','test','test','2.00'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKETH','4h','0.003348290000000','0.003281324200000','1.967436066030421','1.928087344709812','587.5942842556711','587.594284255671141','test','test','2.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKETH','4h','0.003429610000000','0.003361017800000','1.958691905736952','1.919518067622213','571.1121397876004','571.112139787600427','test','test','2.00'),('2019-03-03 15:59:59','2019-03-03 19:59:59','LINKETH','4h','0.003199200000000','0.003236060000000','1.949986608378122','1.972453633379628','609.5231959171424','609.523195917142402','test','test','0.0'),('2019-03-04 03:59:59','2019-03-04 07:59:59','LINKETH','4h','0.003230000000000','0.003198670000000','1.954979280600678','1.936016586835595','605.2567432200243','605.256743220024305','test','test','0.96'),('2019-03-04 11:59:59','2019-03-04 15:59:59','LINKETH','4h','0.003220300000000','0.003249100000000','1.950765348652882','1.968211562372474','605.771309708065','605.771309708065019','test','test','0.0'),('2019-03-04 19:59:59','2019-03-04 23:59:59','LINKETH','4h','0.003264070000000','0.003208290000000','1.954642285035014','1.921239218722327','598.835896606082','598.835896606081974','test','test','1.70'),('2019-03-05 07:59:59','2019-03-05 15:59:59','LINKETH','4h','0.003274870000000','0.003209372600000','1.947219381409972','1.908274993781773','594.5944057046455','594.594405704645510','test','test','2.0'),('2019-03-07 19:59:59','2019-03-07 23:59:59','LINKETH','4h','0.003401970000000','0.003333930600000','1.938565073048150','1.899793771587187','569.8360282566132','569.836028256613190','test','test','1.99'),('2019-03-08 03:59:59','2019-03-08 11:59:59','LINKETH','4h','0.003609580000000','0.003537388400000','1.929949228279047','1.891350243713466','534.6741804528635','534.674180452863538','test','test','1.99'),('2019-03-08 15:59:59','2019-03-08 23:59:59','LINKETH','4h','0.003562430000000','0.003491181400000','1.921371676153362','1.882944242630295','539.3429979405524','539.342997940552436','test','test','2.00'),('2019-03-10 15:59:59','2019-03-10 19:59:59','LINKETH','4h','0.003902250000000','0.003824205000000','1.912832246481570','1.874575601551939','490.1870065940342','490.187006594034187','test','test','2.00'),('2019-03-11 15:59:59','2019-03-11 19:59:59','LINKETH','4h','0.003700000000000','0.003626000000000','1.904330769830541','1.866244154433930','514.6839918460921','514.683991846092113','test','test','2.00'),('2019-03-12 01:59:59','2019-03-15 19:59:59','LINKETH','4h','0.003540000000000','0.003569070000000','1.895867077520183','1.911435680894056','535.5556716158709','535.555671615870892','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:53:19
