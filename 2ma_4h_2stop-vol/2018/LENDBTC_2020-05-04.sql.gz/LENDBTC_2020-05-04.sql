-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-02 15:59:59','2018-06-03 23:59:59','LENDBTC','4h','0.000006270000000','0.000006260000000','0.033333333333333','0.033280170122275','5316.32110579479','5316.321105794790128','test','test','0.15'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDBTC','4h','0.000006120000000','0.000006140000000','0.033321519286432','0.033430413140309','5444.692693861365','5444.692693861365115','test','test','0.0'),('2018-06-09 19:59:59','2018-06-10 03:59:59','LENDBTC','4h','0.000006120000000','0.000005997600000','0.033345717920626','0.032678803562213','5448.646719056608','5448.646719056608163','test','test','1.99'),('2018-06-30 19:59:59','2018-07-01 03:59:59','LENDBTC','4h','0.000004310000000','0.000004350000000','0.033197514729868','0.033505612314368','7702.439612498375','7702.439612498375027','test','test','0.0'),('2018-07-01 07:59:59','2018-07-01 15:59:59','LENDBTC','4h','0.000004670000000','0.000004576600000','0.033265980859757','0.032600661242562','7123.336372538947','7123.336372538947217','test','test','1.99'),('2018-07-01 23:59:59','2018-07-02 11:59:59','LENDBTC','4h','0.000005180000000','0.000005076400000','0.033118132055936','0.032455769414817','6393.461786860188','6393.461786860188113','test','test','2.00'),('2018-07-02 15:59:59','2018-07-05 19:59:59','LENDBTC','4h','0.000004980000000','0.000004880400000','0.032970940357909','0.032311521550751','6620.670754600269','6620.670754600268992','test','test','1.99'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LENDBTC','4h','0.000004280000000','0.000004260000000','0.032824402845208','0.032671017785184','7669.25300121672','7669.253001216719895','test','test','0.46'),('2018-07-17 03:59:59','2018-07-17 07:59:59','LENDBTC','4h','0.000004280000000','0.000004194400000','0.032790317276313','0.032134510930787','7661.289083250779','7661.289083250779186','test','test','1.99'),('2018-07-17 23:59:59','2018-07-18 23:59:59','LENDBTC','4h','0.000004260000000','0.000004270000000','0.032644582532863','0.032721213008292','7663.047542925614','7663.047542925613925','test','test','0.0'),('2018-08-27 19:59:59','2018-08-27 23:59:59','LENDBTC','4h','0.000002060000000','0.000002080000000','0.032661611527403','0.032978714551941','15855.151226894606','15855.151226894606225','test','test','0.0'),('2018-08-28 03:59:59','2018-08-28 11:59:59','LENDBTC','4h','0.000002180000000','0.000002136400000','0.032732078866189','0.032077437288865','15014.715076233535','15014.715076233535001','test','test','1.99'),('2018-08-28 23:59:59','2018-08-29 03:59:59','LENDBTC','4h','0.000002170000000','0.000002126600000','0.032586602960117','0.031934870900915','15016.867723556272','15016.867723556271812','test','test','1.99'),('2018-09-01 15:59:59','2018-09-02 11:59:59','LENDBTC','4h','0.000002120000000','0.000002077600000','0.032441773613628','0.031792938141355','15302.723402654614','15302.723402654613892','test','test','2.00'),('2018-09-04 11:59:59','2018-09-05 11:59:59','LENDBTC','4h','0.000002120000000','0.000002077600000','0.032297587953123','0.031651636194061','15234.711298642767','15234.711298642767360','test','test','2.00'),('2018-09-16 15:59:59','2018-09-19 19:59:59','LENDBTC','4h','0.000001860000000','0.000002020000000','0.032154043117776','0.034919982310703','17287.119955793307','17287.119955793306872','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','LENDBTC','4h','0.000002330000000','0.000002283400000','0.032768696271759','0.032113322346324','14063.818142385979','14063.818142385978717','test','test','2.00'),('2018-09-23 11:59:59','2018-09-23 15:59:59','LENDBTC','4h','0.000002140000000','0.000002097200000','0.032623057621663','0.031970596469230','15244.419449375077','15244.419449375076510','test','test','1.99'),('2018-09-24 19:59:59','2018-09-24 23:59:59','LENDBTC','4h','0.000002140000000','0.000002097200000','0.032478066254455','0.031828504929366','15176.666474044549','15176.666474044548522','test','test','1.99'),('2018-09-25 11:59:59','2018-09-25 15:59:59','LENDBTC','4h','0.000002100000000','0.000002058000000','0.032333719293324','0.031687044907458','15397.009187297353','15397.009187297353492','test','test','2.00'),('2018-09-27 15:59:59','2018-10-01 19:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.032190013874243','0.032342573181704','15255.930746086779','15255.930746086778527','test','test','0.0'),('2018-10-02 03:59:59','2018-10-11 03:59:59','LENDBTC','4h','0.000002190000000','0.000002460000000','0.032223915942568','0.036196727497131','14714.116868752406','14714.116868752405935','test','test','1.36'),('2018-10-13 03:59:59','2018-10-13 07:59:59','LENDBTC','4h','0.000002500000000','0.000002450000000','0.033106762954693','0.032444627695599','13242.705181877152','13242.705181877152427','test','test','1.99'),('2018-10-18 03:59:59','2018-10-26 07:59:59','LENDBTC','4h','0.000002450000000','0.000002800000000','0.032959621786005','0.037668139184006','13452.90685143075','13452.906851430749157','test','test','0.0'),('2018-10-27 07:59:59','2018-11-04 07:59:59','LENDBTC','4h','0.000003120000000','0.000003240000000','0.034005958985561','0.035313880485006','10899.345828705485','10899.345828705485474','test','test','0.0'),('2018-11-07 23:59:59','2018-11-08 03:59:59','LENDBTC','4h','0.000003280000000','0.000003214400000','0.034296608207660','0.033610676043507','10456.282990140242','10456.282990140241964','test','test','1.99'),('2018-11-08 07:59:59','2018-11-08 11:59:59','LENDBTC','4h','0.000003200000000','0.000003140000000','0.034144178837848','0.033503975484638','10670.055886827571','10670.055886827571157','test','test','1.87'),('2018-11-28 19:59:59','2018-11-28 23:59:59','LENDBTC','4h','0.000002160000000','0.000002180000000','0.034001911426024','0.034316743939228','15741.625660196192','15741.625660196192257','test','test','0.0'),('2018-11-29 03:59:59','2018-11-29 07:59:59','LENDBTC','4h','0.000002170000000','0.000002200000000','0.034071874206736','0.034542913942313','15701.324519233076','15701.324519233075989','test','test','0.0'),('2018-11-29 11:59:59','2018-11-29 15:59:59','LENDBTC','4h','0.000002210000000','0.000002190000000','0.034176549703531','0.033867259660965','15464.502128294418','15464.502128294418071','test','test','0.90'),('2018-11-29 19:59:59','2018-11-29 23:59:59','LENDBTC','4h','0.000002200000000','0.000002170000000','0.034107818582960','0.033642711965920','15503.553901345658','15503.553901345658232','test','test','1.36'),('2018-12-01 11:59:59','2018-12-05 19:59:59','LENDBTC','4h','0.000002270000000','0.000002224600000','0.034004461556952','0.033324372325813','14979.939011872935','14979.939011872935225','test','test','2.00'),('2018-12-14 23:59:59','2018-12-15 03:59:59','LENDBTC','4h','0.000002060000000','0.000002050000000','0.033853330616698','0.033688994060306','16433.655639174005','16433.655639174005046','test','test','0.48'),('2018-12-15 07:59:59','2018-12-15 11:59:59','LENDBTC','4h','0.000002080000000','0.000002130000000','0.033816811381945','0.034629715501703','16258.082395165704','16258.082395165703929','test','test','0.0'),('2018-12-15 15:59:59','2018-12-20 11:59:59','LENDBTC','4h','0.000002140000000','0.000002190000000','0.033997456741891','0.034791789843337','15886.662028920982','15886.662028920982266','test','test','1.40'),('2018-12-21 15:59:59','2018-12-25 03:59:59','LENDBTC','4h','0.000002220000000','0.000002175600000','0.034173975208879','0.033490495704701','15393.682526522025','15393.682526522025000','test','test','1.99'),('2019-01-03 23:59:59','2019-01-04 03:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.034022090874617','0.034022090874617','16278.512380199576','16278.512380199576000','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','LENDBTC','4h','0.000002090000000','0.000002090000000','0.034022090874617','0.034022090874617','16278.512380199576','16278.512380199576000','test','test','0.0'),('2019-01-09 11:59:59','2019-01-09 15:59:59','LENDBTC','4h','0.000002110000000','0.000002080000000','0.034022090874617','0.033538364464077','16124.21368465266','16124.213684652659140','test','test','1.42'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LENDBTC','4h','0.000002080000000','0.000002060000000','0.033914596116719','0.033588494230981','16305.094286884296','16305.094286884295798','test','test','0.96'),('2019-01-13 23:59:59','2019-01-20 11:59:59','LENDBTC','4h','0.000002100000000','0.000002220000000','0.033842129031000','0.035775964975629','16115.299538571324','16115.299538571323865','test','test','0.0'),('2019-01-22 19:59:59','2019-01-23 19:59:59','LENDBTC','4h','0.000002350000000','0.000002303000000','0.034271870352028','0.033586432944987','14583.774617884448','14583.774617884448162','test','test','2.00'),('2019-01-25 07:59:59','2019-01-27 15:59:59','LENDBTC','4h','0.000002330000000','0.000002283400000','0.034119550928242','0.033437159909677','14643.584089374059','14643.584089374058749','test','test','2.00'),('2019-02-02 19:59:59','2019-02-03 03:59:59','LENDBTC','4h','0.000002290000000','0.000002244200000','0.033967908479672','0.033288550310079','14833.147807716836','14833.147807716835814','test','test','2.00'),('2019-02-09 19:59:59','2019-02-10 03:59:59','LENDBTC','4h','0.000002170000000','0.000002130000000','0.033816939997540','0.033193586264866','15583.843316838607','15583.843316838607279','test','test','1.84'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LENDBTC','4h','0.000002110000000','0.000002120000000','0.033678416945834','0.033838030296288','15961.33504541917','15961.335045419169546','test','test','0.0'),('2019-02-21 23:59:59','2019-02-22 07:59:59','LENDBTC','4h','0.000002190000000','0.000002146200000','0.033713886579269','0.033039608847684','15394.468757656927','15394.468757656926755','test','test','1.99'),('2019-02-22 15:59:59','2019-02-22 23:59:59','LENDBTC','4h','0.000002180000000','0.000002136400000','0.033564047083361','0.032892766141694','15396.351873101328','15396.351873101328238','test','test','1.99'),('2019-03-01 19:59:59','2019-03-01 23:59:59','LENDBTC','4h','0.000002070000000','0.000002028600000','0.033414873540768','0.032746576069953','16142.45098587837','16142.450985878369465','test','test','2.00'),('2019-03-02 11:59:59','2019-03-07 07:59:59','LENDBTC','4h','0.000002050000000','0.000002170000000','0.033266362991698','0.035213662288773','16227.494142291818','16227.494142291818207','test','test','0.0'),('2019-03-08 03:59:59','2019-03-11 19:59:59','LENDBTC','4h','0.000002260000000','0.000002250000000','0.033699096168826','0.033549985123831','14911.10449948053','14911.104499480530649','test','test','1.76'),('2019-03-12 11:59:59','2019-03-16 23:59:59','LENDBTC','4h','0.000002340000000','0.000002340000000','0.033665960381049','0.033665960381049','14387.162556003988','14387.162556003988357','test','test','0.85'),('2019-03-26 23:59:59','2019-03-27 03:59:59','LENDBTC','4h','0.000002240000000','0.000002260000000','0.033665960381049','0.033966549313023','15029.446598682736','15029.446598682736294','test','test','0.0'),('2019-03-27 07:59:59','2019-04-02 07:59:59','LENDBTC','4h','0.000002270000000','0.000002310000000','0.033732757921488','0.034327167752704','14860.24578039119','14860.245780391189328','test','test','0.0'),('2019-04-05 15:59:59','2019-04-06 07:59:59','LENDBTC','4h','0.000002390000000','0.000002342200000','0.033864848995092','0.033187552015190','14169.392884975545','14169.392884975544803','test','test','2.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDBTC','4h','0.000002370000000','0.000002322600000','0.033714338555113','0.033040051784011','14225.459305954992','14225.459305954991578','test','test','2.00'),('2019-04-14 19:59:59','2019-04-14 23:59:59','LENDBTC','4h','0.000002210000000','0.000002170000000','0.033564497050424','0.032956994841367','15187.555226436201','15187.555226436201337','test','test','1.80'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDBTC','4h','0.000001250000000','0.000001225000000','0.033429496559522','0.032760906628332','26743.59724761796','26743.597247617959511','test','test','1.99'),('2019-05-21 07:59:59','2019-05-21 11:59:59','LENDBTC','4h','0.000001180000000','0.000001160000000','0.033280921019258','0.032716837612152','28204.170355303395','28204.170355303394899','test','test','1.69'),('2019-05-21 19:59:59','2019-05-22 11:59:59','LENDBTC','4h','0.000001180000000','0.000001156400000','0.033155569151012','0.032492457767992','28097.939958484934','28097.939958484934323','test','test','2.00'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LENDBTC','4h','0.000001240000000','0.000001215200000','0.033008211065897','0.032348046844579','26619.52505314247','26619.525053142471734','test','test','1.99'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDBTC','4h','0.000001200000000','0.000001220000000','0.032861507905604','0.033409199704031','27384.58992133649','27384.589921336490079','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:33:35
