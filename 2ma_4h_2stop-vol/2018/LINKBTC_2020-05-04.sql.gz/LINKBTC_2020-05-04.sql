-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 23:59:59','2018-03-22 03:59:59','LINKBTC','4h','0.000049890000000','0.000048990000000','0.033333333333333','0.032732010422930','668.1365671143182','668.136567114318154','test','test','1.80'),('2018-03-26 07:59:59','2018-03-26 11:59:59','LINKBTC','4h','0.000048650000000','0.000047677000000','0.033199706019910','0.032535711899512','682.4194454246751','682.419445424675132','test','test','1.99'),('2018-04-06 03:59:59','2018-04-06 07:59:59','LINKBTC','4h','0.000042610000000','0.000041757800000','0.033052151770933','0.032391108735514','775.6900204396412','775.690020439641216','test','test','1.99'),('2018-04-07 07:59:59','2018-04-07 11:59:59','LINKBTC','4h','0.000042230000000','0.000042610000000','0.032905253318618','0.033201346055087','779.1914117598337','779.191411759833727','test','test','0.0'),('2018-04-08 15:59:59','2018-04-21 11:59:59','LINKBTC','4h','0.000044970000000','0.000051280000000','0.032971051704500','0.037597410082427','733.1788237602798','733.178823760279784','test','test','0.0'),('2018-04-21 19:59:59','2018-04-25 03:59:59','LINKBTC','4h','0.000055220000000','0.000054115600000','0.033999131344039','0.033319148717158','615.7032115907118','615.703211590711817','test','test','2.00'),('2018-04-29 03:59:59','2018-05-04 11:59:59','LINKBTC','4h','0.000053030000000','0.000056750000000','0.033848024093621','0.036222428197492','638.2806730835586','638.280673083558554','test','test','0.0'),('2018-05-04 19:59:59','2018-05-05 03:59:59','LINKBTC','4h','0.000060920000000','0.000059701600000','0.034375669450037','0.033688156061036','564.2755983262786','564.275598326278555','test','test','2.00'),('2018-05-07 03:59:59','2018-05-07 07:59:59','LINKBTC','4h','0.000058030000000','0.000058530000000','0.034222888696926','0.034517761079288','589.7447647238594','589.744764723859362','test','test','0.0'),('2018-05-07 23:59:59','2018-05-09 03:59:59','LINKBTC','4h','0.000061310000000','0.000060083800000','0.034288415893006','0.033602647575146','559.2630222313816','559.263022231381569','test','test','1.99'),('2018-05-10 11:59:59','2018-05-10 23:59:59','LINKBTC','4h','0.000060820000000','0.000059603600000','0.034136022933482','0.033453302474812','561.2631195902919','561.263119590291922','test','test','2.00'),('2018-05-13 19:59:59','2018-05-13 23:59:59','LINKBTC','4h','0.000058130000000','0.000057860000000','0.033984307275999','0.033826458265772','584.6259638052526','584.625963805252582','test','test','0.46'),('2018-05-14 23:59:59','2018-05-16 15:59:59','LINKBTC','4h','0.000059590000000','0.000058540000000','0.033949229718171','0.033351030503469','569.7135378112285','569.713537811228548','test','test','1.76'),('2018-06-02 15:59:59','2018-06-02 23:59:59','LINKBTC','4h','0.000048210000000','0.000048110000000','0.033816296559348','0.033746152820374','701.4373897396483','701.437389739648324','test','test','0.20'),('2018-06-30 03:59:59','2018-07-05 15:59:59','LINKBTC','4h','0.000032010000000','0.000034750000000','0.033800709061799','0.036693990624727','1055.9421762511297','1055.942176251129695','test','test','0.46'),('2018-07-06 19:59:59','2018-07-09 23:59:59','LINKBTC','4h','0.000034850000000','0.000035090000000','0.034443660520227','0.034680862199563','988.3403305660576','988.340330566057560','test','test','0.0'),('2018-07-16 19:59:59','2018-07-16 23:59:59','LINKBTC','4h','0.000033330000000','0.000032930000000','0.034496372004524','0.034082374140683','1034.99465960168','1034.994659601680041','test','test','1.20'),('2018-07-17 19:59:59','2018-07-18 15:59:59','LINKBTC','4h','0.000034020000000','0.000033339600000','0.034404372479226','0.033716285029641','1011.2984267850086','1011.298426785008587','test','test','2.00'),('2018-07-25 19:59:59','2018-07-25 23:59:59','LINKBTC','4h','0.000030390000000','0.000030030000000','0.034251464157096','0.033845721245067','1127.063644524383','1127.063644524383108','test','test','1.18'),('2018-07-26 03:59:59','2018-08-04 15:59:59','LINKBTC','4h','0.000030960000000','0.000036110000000','0.034161299065534','0.039843814898464','1103.401132607687','1103.401132607687032','test','test','0.0'),('2018-08-08 15:59:59','2018-08-08 19:59:59','LINKBTC','4h','0.000035950000000','0.000035650000000','0.035424080361741','0.035128469120892','985.3708028300601','985.370802830060143','test','test','0.83'),('2018-08-09 03:59:59','2018-08-11 15:59:59','LINKBTC','4h','0.000038880000000','0.000042130000000','0.035358388974885','0.038314015625306','909.4235847449928','909.423584744992809','test','test','0.0'),('2018-08-14 07:59:59','2018-08-14 11:59:59','LINKBTC','4h','0.000040900000000','0.000040190000000','0.036015194897201','0.035389992247396','880.567112401005','880.567112401005033','test','test','1.73'),('2018-08-14 15:59:59','2018-08-14 19:59:59','LINKBTC','4h','0.000041160000000','0.000041850000000','0.035876260975022','0.036477685175041','871.6292753892667','871.629275389266695','test','test','0.0'),('2018-08-16 19:59:59','2018-08-18 19:59:59','LINKBTC','4h','0.000042830000000','0.000041973400000','0.036009910797249','0.035289712581304','840.7637356350377','840.763735635037733','test','test','2.00'),('2018-08-19 15:59:59','2018-08-25 23:59:59','LINKBTC','4h','0.000045760000000','0.000047000000000','0.035849866749261','0.036821322928655','783.4324027373444','783.432402737344432','test','test','0.24'),('2018-08-28 11:59:59','2018-08-28 15:59:59','LINKBTC','4h','0.000047750000000','0.000047040000000','0.036065745900237','0.035529480359103','755.3035790625619','755.303579062561880','test','test','1.48'),('2018-08-28 23:59:59','2018-08-29 07:59:59','LINKBTC','4h','0.000047340000000','0.000046860000000','0.035946575779985','0.035582098459022','759.3277520064497','759.327752006449714','test','test','1.01'),('2018-09-02 03:59:59','2018-09-02 07:59:59','LINKBTC','4h','0.000046500000000','0.000045650000000','0.035865580819771','0.035209973428442','771.3028133284157','771.302813328415709','test','test','1.82'),('2018-09-12 03:59:59','2018-09-12 07:59:59','LINKBTC','4h','0.000041910000000','0.000041071800000','0.035719890288365','0.035005492482598','852.2999352986134','852.299935298613377','test','test','2.00'),('2018-09-15 03:59:59','2018-09-15 07:59:59','LINKBTC','4h','0.000041690000000','0.000041360000000','0.035561135220417','0.035279648661944','852.9895711301671','852.989571130167064','test','test','0.79'),('2018-09-16 11:59:59','2018-09-28 19:59:59','LINKBTC','4h','0.000042300000000','0.000050370000000','0.035498582651867','0.042271007285450','839.2099917699079','839.209991769907901','test','test','0.14'),('2018-10-05 15:59:59','2018-10-07 19:59:59','LINKBTC','4h','0.000052120000000','0.000051077600000','0.037003565903774','0.036263494585699','709.9686474246822','709.968647424682217','test','test','2.00'),('2018-10-09 15:59:59','2018-10-11 03:59:59','LINKBTC','4h','0.000051030000000','0.000051180000000','0.036839105610869','0.036947392223482','721.9107507518887','721.910750751888713','test','test','0.0'),('2018-10-14 15:59:59','2018-10-15 07:59:59','LINKBTC','4h','0.000051920000000','0.000050881600000','0.036863169302561','0.036125905916510','709.9994087550206','709.999408755020568','test','test','2.00'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LINKBTC','4h','0.000051370000000','0.000050740000000','0.036699332994549','0.036249253574916','714.4117771958211','714.411777195821060','test','test','1.22'),('2018-10-16 11:59:59','2018-10-29 15:59:59','LINKBTC','4h','0.000053810000000','0.000064690000000','0.036599315345742','0.043999437088200','680.1582483876974','680.158248387697427','test','test','0.0'),('2018-10-29 19:59:59','2018-11-06 03:59:59','LINKBTC','4h','0.000065990000000','0.000074100000000','0.038243786844066','0.042943849146011','579.5391247774814','579.539124777481447','test','test','0.0'),('2018-11-08 07:59:59','2018-11-08 23:59:59','LINKBTC','4h','0.000079020000000','0.000077439600000','0.039288245133387','0.038502480230719','497.1936868310189','497.193686831018908','test','test','1.99'),('2018-11-10 03:59:59','2018-11-17 07:59:59','LINKBTC','4h','0.000079760000000','0.000087820000000','0.039113630710572','0.043066186672548','490.39155855782343','490.391558557823430','test','test','0.66'),('2018-11-18 19:59:59','2018-11-19 03:59:59','LINKBTC','4h','0.000092780000000','0.000090924400000','0.039991976479900','0.039192136950302','431.04091916253503','431.040919162535033','test','test','2.00'),('2018-11-27 11:59:59','2018-11-27 15:59:59','LINKBTC','4h','0.000080690000000','0.000079076200000','0.039814234362212','0.039017949674968','493.42216336859036','493.422163368590361','test','test','2.00'),('2018-11-28 07:59:59','2018-11-28 11:59:59','LINKBTC','4h','0.000078660000000','0.000080750000000','0.039637282209491','0.040690446712642','503.9064608376642','503.906460837664213','test','test','0.0'),('2018-11-29 15:59:59','2018-11-29 23:59:59','LINKBTC','4h','0.000086030000000','0.000084309400000','0.039871318765746','0.039073892390431','463.45831414328075','463.458314143280745','test','test','2.00'),('2018-11-30 03:59:59','2018-11-30 07:59:59','LINKBTC','4h','0.000087630000000','0.000085877400000','0.039694112904565','0.038900230646474','452.9740146589677','452.974014658967690','test','test','2.00'),('2018-12-01 15:59:59','2018-12-01 19:59:59','LINKBTC','4h','0.000081080000000','0.000079458400000','0.039517694624990','0.038727340732490','487.3913989268568','487.391398926856823','test','test','2.00'),('2018-12-18 03:59:59','2018-12-18 11:59:59','LINKBTC','4h','0.000066590000000','0.000068670000000','0.039342060426656','0.040570945930297','590.8103382888754','590.810338288875414','test','test','0.64'),('2018-12-18 15:59:59','2018-12-24 23:59:59','LINKBTC','4h','0.000069490000000','0.000075670000000','0.039615146094132','0.043138266008677','570.0841285671606','570.084128567160633','test','test','0.0'),('2018-12-25 03:59:59','2018-12-27 19:59:59','LINKBTC','4h','0.000076070000000','0.000075780000000','0.040398061630698','0.040244052982441','531.0643043341338','531.064304334133794','test','test','0.38'),('2018-12-29 15:59:59','2018-12-31 19:59:59','LINKBTC','4h','0.000078610000000','0.000077037800000','0.040363837486640','0.039556560736907','513.4695011657607','513.469501165760676','test','test','2.00'),('2019-01-02 15:59:59','2019-01-08 07:59:59','LINKBTC','4h','0.000079280000000','0.000092190000000','0.040184442653366','0.046728100002697','506.867339220061','506.867339220061012','test','test','0.0'),('2019-01-08 15:59:59','2019-01-10 11:59:59','LINKBTC','4h','0.000095890000000','0.000093972200000','0.041638588730996','0.040805816956376','434.2328577640583','434.232857764058281','test','test','2.00'),('2019-01-10 19:59:59','2019-01-10 23:59:59','LINKBTC','4h','0.000099400000000','0.000097412000000','0.041453528336636','0.040624457769903','417.0375084168566','417.037508416856610','test','test','1.99'),('2019-01-11 15:59:59','2019-01-25 15:59:59','LINKBTC','4h','0.000109220000000','0.000137160000000','0.041269290432917','0.051826550776221','377.85470090566844','377.854700905668437','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','LINKBTC','4h','0.000132130000000','0.000132130000000','0.043615348286985','0.043615348286985','330.0942124194707','330.094212419470693','test','test','0.0'),('2019-02-05 23:59:59','2019-02-06 03:59:59','LINKBTC','4h','0.000121660000000','0.000120220000000','0.043615348286985','0.043099105466557','358.50195863048384','358.501958630483841','test','test','1.18'),('2019-02-08 03:59:59','2019-02-08 19:59:59','LINKBTC','4h','0.000121800000000','0.000121000000000','0.043500627660223','0.043214909251946','357.1480103466575','357.148010346657486','test','test','0.65'),('2019-02-09 15:59:59','2019-02-09 19:59:59','LINKBTC','4h','0.000131900000000','0.000129262000000','0.043437134680606','0.042568391986994','329.31868597881555','329.318685978815552','test','test','2.00'),('2019-02-10 07:59:59','2019-02-10 19:59:59','LINKBTC','4h','0.000127920000000','0.000125361600000','0.043244080748692','0.042379199133718','338.0556656401813','338.055665640181303','test','test','1.99'),('2019-02-13 23:59:59','2019-02-14 03:59:59','LINKBTC','4h','0.000122500000000','0.000120050000000','0.043051884834253','0.042190847137568','351.4439578306394','351.443957830639420','test','test','2.00'),('2019-02-15 23:59:59','2019-02-16 07:59:59','LINKBTC','4h','0.000120720000000','0.000120500000000','0.042860543123879','0.042782434115535','355.0409470168894','355.040947016889390','test','test','0.36'),('2019-02-17 11:59:59','2019-02-18 23:59:59','LINKBTC','4h','0.000123660000000','0.000121186800000','0.042843185566469','0.041986321855140','346.45953070086614','346.459530700866139','test','test','2.00'),('2019-02-19 03:59:59','2019-02-19 07:59:59','LINKBTC','4h','0.000121830000000','0.000120250000000','0.042652771408396','0.042099612261837','350.1007256701633','350.100725670163285','test','test','1.29'),('2019-02-25 15:59:59','2019-02-25 19:59:59','LINKBTC','4h','0.000120100000000','0.000117698000000','0.042529847153605','0.041679250210533','354.12029270279027','354.120292702790266','test','test','2.00'),('2019-02-25 23:59:59','2019-02-26 03:59:59','LINKBTC','4h','0.000123280000000','0.000120814400000','0.042340825610700','0.041494009098486','343.45251144305826','343.452511443058256','test','test','1.99'),('2019-03-07 15:59:59','2019-03-07 19:59:59','LINKBTC','4h','0.000112460000000','0.000120200000000','0.042152644163542','0.045053777596103','374.8234408993558','374.823440899355774','test','test','0.0'),('2019-03-08 03:59:59','2019-03-08 11:59:59','LINKBTC','4h','0.000125860000000','0.000123342800000','0.042797340481888','0.041941393672250','340.039253789039','340.039253789038980','test','test','1.99'),('2019-03-10 11:59:59','2019-03-11 19:59:59','LINKBTC','4h','0.000125340000000','0.000122833200000','0.042607130079747','0.041754987478152','339.9324244434871','339.932424443487093','test','test','1.99'),('2019-03-12 01:59:59','2019-03-15 19:59:59','LINKBTC','4h','0.000120940000000','0.000124770000000','0.042417765057170','0.043761076121904','350.7339594606416','350.733959460641586','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:37:27
