-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-27 03:59:59','XLMETH','4h','0.000490070000000','0.000482880000000','1.297777777777778','1.278737595309514','2648.147770273181','2648.147770273180868','test','test','1.64'),('2018-05-28 07:59:59','2018-05-29 03:59:59','XLMETH','4h','0.000487090000000','0.000477348200000','1.293546626118163','1.267675693595800','2655.662456872782','2655.662456872782059','test','test','2.00'),('2018-05-29 11:59:59','2018-05-30 15:59:59','XLMETH','4h','0.000499910000000','0.000489911800000','1.287797530002083','1.262041579402041','2576.05875057927','2576.058750579270054','test','test','2.00'),('2018-05-30 23:59:59','2018-06-03 11:59:59','XLMETH','4h','0.000492440000000','0.000491920000000','1.282073985424296','1.280720158618146','2603.513088750499','2603.513088750498810','test','test','0.89'),('2018-06-06 23:59:59','2018-06-07 03:59:59','XLMETH','4h','0.000492990000000','0.000489040000000','1.281773135022929','1.271503141953414','2599.9982454470255','2599.998245447025511','test','test','0.80'),('2018-06-28 11:59:59','2018-06-28 15:59:59','XLMETH','4h','0.000438360000000','0.000438610000000','1.279490914340815','1.280220617617996','2918.8131087252827','2918.813108725282746','test','test','0.0'),('2018-06-30 03:59:59','2018-06-30 07:59:59','XLMETH','4h','0.000439830000000','0.000435840000000','1.279653070624633','1.268044458770525','2909.4265298516075','2909.426529851607484','test','test','0.90'),('2018-07-02 11:59:59','2018-07-05 15:59:59','XLMETH','4h','0.000448450000000','0.000439481000000','1.277073379101498','1.251531911519468','2847.7497582818546','2847.749758281854611','test','test','2.00'),('2018-07-10 11:59:59','2018-07-10 15:59:59','XLMETH','4h','0.000439750000000','0.000437690000000','1.271397497416602','1.265441661499199','2891.1824841764683','2891.182484176468279','test','test','0.46'),('2018-07-13 23:59:59','2018-07-14 03:59:59','XLMETH','4h','0.000475090000000','0.000465588200000','1.270073978323846','1.244672498757369','2673.3334280322583','2673.333428032258325','test','test','2.00'),('2018-07-14 07:59:59','2018-07-30 19:59:59','XLMETH','4h','0.000465390000000','0.000635750000000','1.264429205086851','1.727284357493641','2716.923881232624','2716.923881232623899','test','test','0.78'),('2018-07-30 23:59:59','2018-07-31 03:59:59','XLMETH','4h','0.000646140000000','0.000633217200000','1.367285905621693','1.339940187509259','2116.0830557181','2116.083055718099786','test','test','2.00'),('2018-07-31 15:59:59','2018-07-31 23:59:59','XLMETH','4h','0.000641060000000','0.000641670000000','1.361209079374485','1.362504336508635','2123.37235106618','2123.372351066179817','test','test','0.0'),('2018-08-01 15:59:59','2018-08-01 19:59:59','XLMETH','4h','0.000659090000000','0.000645908200000','1.361496914293186','1.334266976007322','2065.722305441117','2065.722305441116987','test','test','1.99'),('2018-08-09 23:59:59','2018-08-10 03:59:59','XLMETH','4h','0.000609120000000','0.000610330000000','1.355445816896327','1.358138372449329','2225.2525231421178','2225.252523142117752','test','test','0.0'),('2018-08-10 19:59:59','2018-08-29 15:59:59','XLMETH','4h','0.000646550000000','0.000778680000000','1.356044162574772','1.633167533081314','2097.3538977260414','2097.353897726041396','test','test','0.0'),('2018-08-30 23:59:59','2018-09-01 15:59:59','XLMETH','4h','0.000783180000000','0.000777700000000','1.417627133798448','1.407707834667705','1810.0910822524168','1810.091082252416754','test','test','0.69'),('2018-09-04 19:59:59','2018-09-14 03:59:59','XLMETH','4h','0.000800030000000','0.000947330000000','1.415422845102727','1.676027803771317','1769.2122109204995','1769.212210920499501','test','test','0.0'),('2018-09-17 15:59:59','2018-09-22 03:59:59','XLMETH','4h','0.000966740000000','0.000984750000000','1.473335058140192','1.500782732175719','1524.0240996960833','1524.024099696083340','test','test','0.0'),('2018-09-22 07:59:59','2018-09-22 15:59:59','XLMETH','4h','0.001006860000000','0.000986722800000','1.479434541259197','1.449845850434013','1469.3547675537782','1469.354767553778174','test','test','2.0'),('2018-09-23 03:59:59','2018-09-29 11:59:59','XLMETH','4h','0.001069350000000','0.001101170000000','1.472859276631379','1.516686257678193','1377.3406991456295','1377.340699145629515','test','test','0.0'),('2018-09-30 23:59:59','2018-10-02 23:59:59','XLMETH','4h','0.001113670000000','0.001096170000000','1.482598605752893','1.459301331335269','1331.2728238642442','1331.272823864244174','test','test','1.57'),('2018-10-05 07:59:59','2018-10-05 11:59:59','XLMETH','4h','0.001115190000000','0.001094440000000','1.477421433660088','1.449931503918567','1324.8158911576393','1324.815891157639271','test','test','1.86'),('2018-10-11 19:59:59','2018-10-11 23:59:59','XLMETH','4h','0.001095870000000','0.001078980000000','1.471312560384194','1.448636084940127','1342.5977172330604','1342.597717233060393','test','test','1.54'),('2018-10-12 07:59:59','2018-10-12 23:59:59','XLMETH','4h','0.001095030000000','0.001097110000000','1.466273343618846','1.469058517134391','1339.0257286273852','1339.025728627385206','test','test','0.00'),('2018-10-16 23:59:59','2018-10-25 11:59:59','XLMETH','4h','0.001100650000000','0.001165150000000','1.466892271066745','1.552854703705463','1332.7508936235358','1332.750893623535831','test','test','0.0'),('2018-11-02 23:59:59','2018-11-04 19:59:59','XLMETH','4h','0.001180130000000','0.001161000000000','1.485995033875349','1.461906937650327','1259.1791021966637','1259.179102196663735','test','test','1.62'),('2018-11-05 15:59:59','2018-11-07 15:59:59','XLMETH','4h','0.001170000000000','0.001173260000000','1.480642123603122','1.484767673451794','1265.5060885496766','1265.506088549676633','test','test','0.0'),('2018-11-08 15:59:59','2018-11-14 01:59:59','XLMETH','4h','0.001220630000000','0.001233810000000','1.481558912458382','1.497556345313712','1213.7657705106235','1213.765770510623497','test','test','0.98'),('2018-11-14 19:59:59','2018-11-24 23:59:59','XLMETH','4h','0.001265520000000','0.001340830000000','1.485113897537344','1.573491740339937','1173.5206852024025','1173.520685202402547','test','test','0.0'),('2018-11-29 11:59:59','2018-11-29 23:59:59','XLMETH','4h','0.001403520000000','0.001399620000000','1.504753418160143','1.500572118049831','1072.1282334132347','1072.128233413234739','test','test','0.97'),('2018-11-30 07:59:59','2018-11-30 11:59:59','XLMETH','4h','0.001443690000000','0.001414816200000','1.503824240357851','1.473747755550694','1041.653152933006','1041.653152933005913','test','test','2.00'),('2018-12-03 15:59:59','2018-12-03 19:59:59','XLMETH','4h','0.001392430000000','0.001385320000000','1.497140577067372','1.489495905878911','1075.1998858595202','1075.199885859520236','test','test','0.51'),('2019-01-08 15:59:59','2019-01-08 19:59:59','XLMETH','4h','0.000826140000000','0.000821090000000','1.495441761247714','1.486300476605521','1810.1553746915947','1810.155374691594716','test','test','0.61'),('2019-01-10 03:59:59','2019-01-10 19:59:59','XLMETH','4h','0.000845590000000','0.000838510000000','1.493410364660560','1.480906260565435','1766.1163976165283','1766.116397616528275','test','test','0.83'),('2019-01-13 03:59:59','2019-01-13 07:59:59','XLMETH','4h','0.000895190000000','0.000877286200000','1.490631674861643','1.460819041364410','1665.1567542774644','1665.156754277464415','test','test','2.00'),('2019-01-13 19:59:59','2019-01-14 15:59:59','XLMETH','4h','0.000898290000000','0.000880324200000','1.484006645195592','1.454326512291680','1652.035139204034','1652.035139204034067','test','test','2.00'),('2019-01-15 23:59:59','2019-01-19 19:59:59','XLMETH','4h','0.000871000000000','0.000857130000000','1.477411060105833','1.453884433924814','1696.22394960486','1696.223949604860081','test','test','1.59'),('2019-01-20 03:59:59','2019-01-22 19:59:59','XLMETH','4h','0.000876270000000','0.000868190000000','1.472182920954496','1.458608066170797','1680.0562851113195','1680.056285111319539','test','test','0.92'),('2019-01-23 03:59:59','2019-01-23 07:59:59','XLMETH','4h','0.000868160000000','0.000862540000000','1.469166286558118','1.459655695733320','1692.275947472952','1692.275947472952112','test','test','0.64'),('2019-01-26 07:59:59','2019-01-26 15:59:59','XLMETH','4h','0.000877000000000','0.000868340000000','1.467052821930385','1.452566302616911','1672.8082348122978','1672.808234812297769','test','test','0.98'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMETH','4h','0.000624170000000','0.000625000000000','1.463833595416280','1.465780151457416','2345.2482423318647','2345.248242331864731','test','test','0.0'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XLMETH','4h','0.000623190000000','0.000616450000000','1.464266163425421','1.448429654589452','2349.63039109328','2349.630391093280195','test','test','1.08'),('2019-03-01 23:59:59','2019-03-03 11:59:59','XLMETH','4h','0.000626160000000','0.000623630000000','1.460746939239650','1.454844790018562','2332.865304777773','2332.865304777772963','test','test','0.40'),('2019-03-03 15:59:59','2019-03-05 07:59:59','XLMETH','4h','0.000660150000000','0.000646947000000','1.459435350523853','1.430246643513376','2210.7632364218025','2210.763236421802503','test','test','2.00'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMETH','4h','0.000639150000000','0.000772780000000','1.452948971188191','1.756723626620997','2273.2519302013475','2273.251930201347477','test','test','0.29'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMETH','4h','0.000796010000000','0.000780089800000','1.520454450173259','1.490045361169794','1910.0946598324888','1910.094659832488787','test','test','2.00'),('2019-04-01 03:59:59','2019-04-02 07:59:59','XLMETH','4h','0.000771150000000','0.000775680000000','1.513696874839156','1.522588850256418','1962.908480631727','1962.908480631726889','test','test','0.25'),('2019-04-05 07:59:59','2019-04-05 15:59:59','XLMETH','4h','0.000772350000000','0.000766430000000','1.515672869376325','1.504055359974231','1962.4171287322138','1962.417128732213769','test','test','0.76'),('2019-05-15 23:59:59','2019-05-16 07:59:59','XLMETH','4h','0.000569580000000','0.000566480000000','1.513091200620305','1.504856040112698','2656.5033895507295','2656.503389550729480','test','test','0.82');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:53:05
