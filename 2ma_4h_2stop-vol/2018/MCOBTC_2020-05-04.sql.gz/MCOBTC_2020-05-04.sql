-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-27 19:59:59','2018-02-27 23:59:59','MCOBTC','4h','0.000812000000000','0.000795760000000','0.033333333333333','0.032666666666666','41.050903119868636','41.050903119868636','test','test','2.00'),('2018-03-03 03:59:59','2018-03-06 03:59:59','MCOBTC','4h','0.000789000000000','0.000775000000000','0.033185185185185','0.032596347932216','42.05980378350458','42.059803783504577','test','test','1.77'),('2018-03-07 11:59:59','2018-03-07 15:59:59','MCOBTC','4h','0.000803000000000','0.000786940000000','0.033054332462303','0.032393245813057','41.16355225691546','41.163552256915459','test','test','2.00'),('2018-03-11 07:59:59','2018-03-15 03:59:59','MCOBTC','4h','0.000788000000000','0.000824000000000','0.032907424318026','0.034410809185347','41.76069075891652','41.760690758916517','test','test','0.0'),('2018-04-03 07:59:59','2018-04-06 03:59:59','MCOBTC','4h','0.000719000000000','0.000707000000000','0.033241509844098','0.032686714130427','46.23297613921773','46.232976139217733','test','test','1.66'),('2018-04-07 11:59:59','2018-04-09 15:59:59','MCOBTC','4h','0.000728000000000','0.000715000000000','0.033118221907726','0.032526825087945','45.49206306006349','45.492063060063487','test','test','1.78'),('2018-04-10 07:59:59','2018-04-25 03:59:59','MCOBTC','4h','0.000764000000000','0.001274000000000','0.032986800392219','0.055006784947234','43.176440303952','43.176440303951999','test','test','1.17'),('2018-04-27 07:59:59','2018-04-27 11:59:59','MCOBTC','4h','0.001367000000000','0.001339660000000','0.037880130293334','0.037122527687467','27.710409870763556','27.710409870763556','test','test','2.00'),('2018-04-28 19:59:59','2018-04-29 03:59:59','MCOBTC','4h','0.001355000000000','0.001327900000000','0.037711774158697','0.036957538675523','27.831567644794585','27.831567644794585','test','test','1.99'),('2018-05-07 23:59:59','2018-05-08 03:59:59','MCOBTC','4h','0.001288000000000','0.001262240000000','0.037544166273547','0.036793282948076','29.149197417350063','29.149197417350063','test','test','2.00'),('2018-05-13 15:59:59','2018-05-13 19:59:59','MCOBTC','4h','0.001253000000000','0.001227940000000','0.037377303312331','0.036629757246084','29.8302500497455','29.830250049745501','test','test','1.99'),('2018-05-14 11:59:59','2018-05-14 15:59:59','MCOBTC','4h','0.001244000000000','0.001258000000000','0.037211181964276','0.037629957324003','29.9125256947558','29.912525694755800','test','test','0.0'),('2018-05-14 19:59:59','2018-05-15 03:59:59','MCOBTC','4h','0.001292000000000','0.001266160000000','0.037304243155327','0.036558158292220','28.873253216197106','28.873253216197106','test','test','2.00'),('2018-05-15 11:59:59','2018-05-15 19:59:59','MCOBTC','4h','0.001309000000000','0.001282820000000','0.037138446519081','0.036395677588699','28.371616897693404','28.371616897693404','test','test','1.99'),('2018-05-16 07:59:59','2018-05-16 11:59:59','MCOBTC','4h','0.001282000000000','0.001256360000000','0.036973386756774','0.036233919021639','28.840395286094815','28.840395286094815','test','test','1.99'),('2018-05-17 03:59:59','2018-05-17 11:59:59','MCOBTC','4h','0.001206000000000','0.001189000000000','0.036809060593410','0.036290193238445','30.521609115597197','30.521609115597197','test','test','1.40'),('2018-06-03 19:59:59','2018-06-04 07:59:59','MCOBTC','4h','0.000945000000000','0.000926100000000','0.036693756736751','0.035959881602016','38.829372208202464','38.829372208202464','test','test','1.99'),('2018-06-22 23:59:59','2018-06-23 03:59:59','MCOBTC','4h','0.000807000000000','0.000790860000000','0.036530673373477','0.035800059906007','45.26725325090072','45.267253250900723','test','test','1.99'),('2018-06-25 15:59:59','2018-07-10 15:59:59','MCOBTC','4h','0.000795000000000','0.001326000000000','0.036368314825150','0.060659604349873','45.7463079561638','45.746307956163797','test','test','0.0'),('2018-07-16 07:59:59','2018-07-17 07:59:59','MCOBTC','4h','0.001144000000000','0.001146000000000','0.041766379163978','0.041839397309370','36.50907269578457','36.509072695784567','test','test','0.78'),('2018-07-22 23:59:59','2018-07-23 03:59:59','MCOBTC','4h','0.001083000000000','0.001061340000000','0.041782605418509','0.040946953310139','38.58042974931589','38.580429749315890','test','test','1.99'),('2018-09-04 07:59:59','2018-09-04 11:59:59','MCOBTC','4h','0.000681000000000','0.000667380000000','0.041596904949982','0.040764966850982','61.08209243756599','61.082092437565990','test','test','1.99'),('2018-09-04 15:59:59','2018-09-05 11:59:59','MCOBTC','4h','0.000683000000000','0.000669340000000','0.041412029816871','0.040583789220534','60.63254731606344','60.632547316063437','test','test','1.99'),('2018-09-06 15:59:59','2018-09-06 19:59:59','MCOBTC','4h','0.000759000000000','0.000743820000000','0.041227976351019','0.040403416823999','54.31880942163197','54.318809421631968','test','test','2.00'),('2018-09-10 07:59:59','2018-09-11 15:59:59','MCOBTC','4h','0.000693000000000','0.000679140000000','0.041044740900570','0.040223846082559','59.227620347142526','59.227620347142526','test','test','1.99'),('2018-09-13 11:59:59','2018-09-13 19:59:59','MCOBTC','4h','0.000689000000000','0.000682000000000','0.040862319829901','0.040447172894038','59.30670512322302','59.306705123223018','test','test','1.01'),('2018-09-14 19:59:59','2018-09-14 23:59:59','MCOBTC','4h','0.000692000000000','0.000678160000000','0.040770064955264','0.039954663656159','58.91627883708734','58.916278837087340','test','test','1.99'),('2018-09-18 15:59:59','2018-09-18 23:59:59','MCOBTC','4h','0.000682000000000','0.000674000000000','0.040588864666574','0.040112748952010','59.51446432049039','59.514464320490390','test','test','1.17'),('2018-09-20 03:59:59','2018-09-20 11:59:59','MCOBTC','4h','0.000684000000000','0.000676000000000','0.040483061174449','0.040009575078841','59.18576195094899','59.185761950948987','test','test','1.16'),('2018-09-20 23:59:59','2018-09-21 03:59:59','MCOBTC','4h','0.000680000000000','0.000673000000000','0.040377842042092','0.039962187785776','59.37917947366438','59.379179473664379','test','test','1.02'),('2018-09-21 07:59:59','2018-09-21 11:59:59','MCOBTC','4h','0.000680000000000','0.000676000000000','0.040285474429577','0.040048501050579','59.24334474937809','59.243344749378089','test','test','0.58'),('2018-09-25 23:59:59','2018-09-26 11:59:59','MCOBTC','4h','0.000678000000000','0.000673000000000','0.040232813678689','0.039936111512917','59.34043315440805','59.340433154408053','test','test','1.17'),('2018-09-26 15:59:59','2018-09-27 03:59:59','MCOBTC','4h','0.000682000000000','0.000681000000000','0.040166879864073','0.040107984145797','58.895718275766356','58.895718275766356','test','test','0.43'),('2018-09-27 15:59:59','2018-09-27 23:59:59','MCOBTC','4h','0.000677000000000','0.000671000000000','0.040153791926678','0.039797923755984','59.311361782389945','59.311361782389945','test','test','0.88'),('2018-09-29 03:59:59','2018-09-30 11:59:59','MCOBTC','4h','0.000678000000000','0.000676000000000','0.040074710110968','0.039956495626865','59.10724205157553','59.107242051575533','test','test','0.29'),('2018-09-30 19:59:59','2018-09-30 23:59:59','MCOBTC','4h','0.000678000000000','0.000673000000000','0.040048440225612','0.039753097746072','59.068495907982296','59.068495907982296','test','test','0.73'),('2018-10-01 07:59:59','2018-10-01 15:59:59','MCOBTC','4h','0.000682000000000','0.000675000000000','0.039982808563492','0.039572427830436','58.62581900805277','58.625819008052773','test','test','1.02'),('2018-10-02 07:59:59','2018-10-05 11:59:59','MCOBTC','4h','0.000702000000000','0.000687960000000','0.039891612845035','0.039093780588134','56.82565932341183','56.825659323411827','test','test','1.99'),('2018-10-08 23:59:59','2018-10-09 11:59:59','MCOBTC','4h','0.000693000000000','0.000681000000000','0.039714316787946','0.039026622990752','57.3078164328225','57.307816432822499','test','test','1.73'),('2018-10-09 19:59:59','2018-10-11 03:59:59','MCOBTC','4h','0.000692000000000','0.000686000000000','0.039561495944125','0.039218477193164','57.169791826770386','57.169791826770386','test','test','0.86'),('2018-10-18 07:59:59','2018-10-27 19:59:59','MCOBTC','4h','0.000675000000000','0.000727000000000','0.039485269555023','0.042527097728151','58.49669563707061','58.496695637070609','test','test','0.0'),('2018-10-28 15:59:59','2018-10-28 19:59:59','MCOBTC','4h','0.000732000000000','0.000724000000000','0.040161231371273','0.039722310809838','54.86507017933515','54.865070179335149','test','test','1.09'),('2018-11-03 23:59:59','2018-11-04 07:59:59','MCOBTC','4h','0.000708000000000','0.000700000000000','0.040063693468732','0.039610996367390','56.587137667700866','56.587137667700866','test','test','1.12'),('2018-11-16 07:59:59','2018-11-16 11:59:59','MCOBTC','4h','0.000690000000000','0.000683000000000','0.039963094112878','0.039557671418979','57.91752769982383','57.917527699823829','test','test','1.01'),('2018-11-16 15:59:59','2018-11-16 19:59:59','MCOBTC','4h','0.000697000000000','0.000683060000000','0.039873000180901','0.039075540177283','57.206599972598106','57.206599972598106','test','test','2.00'),('2018-12-01 03:59:59','2018-12-01 07:59:59','MCOBTC','4h','0.000585000000000','0.000573300000000','0.039695786846764','0.038901871109829','67.85604589190349','67.856045891903491','test','test','2.00'),('2018-12-01 19:59:59','2018-12-06 11:59:59','MCOBTC','4h','0.000583000000000','0.000590000000000','0.039519361127445','0.039993864605819','67.78621119630303','67.786211196303029','test','test','1.37'),('2018-12-19 11:59:59','2018-12-19 15:59:59','MCOBTC','4h','0.000557000000000','0.000548000000000','0.039624806344861','0.038984549150779','71.13968823134849','71.139688231348487','test','test','1.61'),('2018-12-20 07:59:59','2018-12-20 11:59:59','MCOBTC','4h','0.000565000000000','0.000553700000000','0.039482526968398','0.038692876429030','69.88057870512998','69.880578705129977','test','test','2.00'),('2018-12-23 03:59:59','2018-12-27 07:59:59','MCOBTC','4h','0.000551000000000','0.000578000000000','0.039307049070761','0.041233165812885','71.33765711571888','71.337657115718883','test','test','0.0'),('2018-12-30 03:59:59','2019-01-01 03:59:59','MCOBTC','4h','0.000579000000000','0.000580000000000','0.039735075013455','0.039803702086017','68.627072562099','68.627072562099002','test','test','0.0'),('2019-01-02 11:59:59','2019-01-10 07:59:59','MCOBTC','4h','0.000604000000000','0.000638000000000','0.039750325474025','0.041987926576867','65.81179714242494','65.811797142424936','test','test','1.65'),('2019-01-12 03:59:59','2019-01-12 11:59:59','MCOBTC','4h','0.000641000000000','0.000628180000000','0.040247570163545','0.039442618760274','62.788721003970515','62.788721003970515','test','test','1.99'),('2019-01-17 23:59:59','2019-01-18 07:59:59','MCOBTC','4h','0.000627000000000','0.000622000000000','0.040068692073929','0.039749165023898','63.90541000626687','63.905410006266870','test','test','0.79'),('2019-01-18 23:59:59','2019-01-19 11:59:59','MCOBTC','4h','0.000631000000000','0.000635000000000','0.039997686062811','0.040251237163051','63.38777505992285','63.387775059922852','test','test','1.10'),('2019-01-19 15:59:59','2019-01-20 11:59:59','MCOBTC','4h','0.000638000000000','0.000626000000000','0.040054030751754','0.039300663402191','62.78061246356355','62.780612463563550','test','test','1.88'),('2019-01-26 11:59:59','2019-01-26 19:59:59','MCOBTC','4h','0.000629000000000','0.000624000000000','0.039886615785184','0.039569552066701','63.41274369663592','63.412743696635921','test','test','0.79'),('2019-02-08 15:59:59','2019-02-08 15:59:59','MCOBTC','4h','0.000584000000000','0.000584000000000','0.039816157181077','0.039816157181077','68.17835133746003','68.178351337460029','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:19:00
