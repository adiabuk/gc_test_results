-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-12 23:59:59','2018-02-13 03:59:59','BTCUSDT','4h','8903.000000000000000','8760.590000000000146','222.222222222222200','218.667615160932002','0.024960375404046074','0.024960375404046','test','test','1.59'),('2018-02-14 15:59:59','2018-02-22 11:59:59','BTCUSDT','4h','9330.079999999999927','10259.870000000000800','221.432309541935524','243.499167177560963','0.023733163010599644','0.023733163010600','test','test','0.97'),('2018-02-23 15:59:59','2018-02-23 19:59:59','BTCUSDT','4h','10292.000000000000000','10086.159999999999854','226.336055683185606','221.809334569521894','0.021991455079983055','0.021991455079983','test','test','2.00'),('2018-02-26 15:59:59','2018-03-06 15:59:59','BTCUSDT','4h','10260.920000000000073','10966.000000000000000','225.330117657926991','240.813696065930486','0.02196003064617276','0.021960030646173','test','test','0.21'),('2018-03-20 19:59:59','2018-03-22 11:59:59','BTCUSDT','4h','8950.000000000000000','8771.000000000000000','228.770912859705589','224.195494602511474','0.025560995850246435','0.025560995850246','test','test','2.0'),('2018-04-12 11:59:59','2018-05-01 03:59:59','BTCUSDT','4h','7690.000000000000000','8938.010000000000218','227.754153246995770','264.716371815758237','0.029616924999609332','0.029616924999609','test','test','0.98'),('2018-05-03 15:59:59','2018-05-07 03:59:59','BTCUSDT','4h','9442.280000000000655','9350.020000000000437','235.967979595609648','233.662349409098454','0.024990572149481867','0.024990572149482','test','test','0.97'),('2018-05-07 15:59:59','2018-05-07 23:59:59','BTCUSDT','4h','9365.280000000000655','9365.000000000000000','235.455617331940488','235.448577758873455','0.025141332382154134','0.025141332382154','test','test','0.00'),('2018-05-21 07:59:59','2018-05-21 11:59:59','BTCUSDT','4h','8540.000000000000000','8469.979999999999563','235.454052982370030','233.523550313772176','0.027570732199340753','0.027570732199341','test','test','0.81'),('2018-06-02 11:59:59','2018-06-02 15:59:59','BTCUSDT','4h','7652.279999999999745','7623.100000000000364','235.025052389348275','234.128844850063132','0.030713075369608572','0.030713075369609','test','test','0.38'),('2018-06-03 11:59:59','2018-06-04 07:59:59','BTCUSDT','4h','7714.850000000000364','7597.699999999999818','234.825895158396037','231.260063856710815','0.03043816732125654','0.030438167321257','test','test','1.51'),('2018-06-30 03:59:59','2018-07-01 15:59:59','BTCUSDT','4h','6366.000000000000000','6316.579999999999927','234.033488202465975','232.216658955377397','0.03676303616124191','0.036763036161242','test','test','0.77'),('2018-07-02 15:59:59','2018-07-04 00:22:25','BTCUSDT','4h','6630.079999999999927','6497.478399999999965','233.629748369779605','228.957153402384023','0.03523784756289209','0.035237847562892','test','test','1.99'),('2018-07-04 15:59:59','2018-07-05 19:59:59','BTCUSDT','4h','6683.760000000000218','6550.084800000000541','232.591393932580587','227.939566053928985','0.03479948321492402','0.034799483214924','test','test','1.99'),('2018-07-07 23:59:59','2018-07-10 07:59:59','BTCUSDT','4h','6756.979999999999563','6621.840399999999136','231.557654403991364','226.926501315911537','0.0342694005907952','0.034269400590795','test','test','2.00'),('2018-07-16 11:59:59','2018-07-31 15:59:59','BTCUSDT','4h','6635.569999999999709','7758.439999999999600','230.528509273306980','269.538503472406433','0.03474132731224401','0.034741327312244','test','test','0.04'),('2018-08-22 03:59:59','2018-08-22 15:59:59','BTCUSDT','4h','6726.010000000000218','6591.489800000000287','239.197396873106868','234.413448935644738','0.03556304508514065','0.035563045085141','test','test','1.99'),('2018-08-24 19:59:59','2018-09-05 11:59:59','BTCUSDT','4h','6623.560000000000400','6991.899999999999636','238.134297331448579','251.377083247038627','0.03595261420315488','0.035952614203155','test','test','0.09'),('2018-09-14 03:59:59','2018-09-14 11:59:59','BTCUSDT','4h','6542.369999999999891','6459.279999999999745','241.077138646024167','238.015388936041660','0.0368485944154831','0.036848594415483','test','test','1.27'),('2018-09-20 23:59:59','2018-09-24 23:59:59','BTCUSDT','4h','6492.000000000000000','6581.390000000000327','240.396749821583597','243.706833842925477','0.03702969036068755','0.037029690360688','test','test','0.0'),('2018-09-27 19:59:59','2018-09-28 19:59:59','BTCUSDT','4h','6669.359999999999673','6684.000000000000000','241.132324048548497','241.661636789811666','0.036155241889558896','0.036155241889559','test','test','0.17'),('2018-09-30 11:59:59','2018-09-30 23:59:59','BTCUSDT','4h','6627.930000000000291','6626.569999999999709','241.249949102162503','241.200446477545313','0.0363989886891024','0.036398988689102','test','test','0.36'),('2018-10-04 03:59:59','2018-10-04 23:59:59','BTCUSDT','4h','6598.510000000000218','6593.789999999999964','241.238948518914214','241.066387162333797','0.036559609444998066','0.036559609444998','test','test','0.41'),('2018-10-05 19:59:59','2018-10-06 11:59:59','BTCUSDT','4h','6595.500000000000000','6587.159999999999854','241.200601550785251','240.895603746686447','0.03657048010776821','0.036570480107768','test','test','0.12'),('2018-10-07 03:59:59','2018-10-07 07:59:59','BTCUSDT','4h','6604.069999999999709','6570.930000000000291','241.132824260985529','239.922791387922587','0.03651276020105564','0.036512760201056','test','test','0.50'),('2018-10-07 15:59:59','2018-10-07 19:59:59','BTCUSDT','4h','6582.069999999999709','6584.000000000000000','240.863928066971511','240.934554386832815','0.036593948114646536','0.036593948114647','test','test','0.0'),('2018-10-08 03:59:59','2018-10-10 03:59:59','BTCUSDT','4h','6605.260000000000218','6616.060000000000400','240.879622804718451','241.273475571496903','0.03646784877578149','0.036467848775781','test','test','0.13'),('2018-10-15 07:59:59','2018-10-16 15:59:59','BTCUSDT','4h','6860.250000000000000','6723.045000000000073','240.967145641780348','236.147802728944725','0.03512512600004086','0.035125126000041','test','test','1.99'),('2018-10-22 07:59:59','2018-10-22 11:59:59','BTCUSDT','4h','6615.060000000000400','6594.000000000000000','239.896180550039134','239.132436371999347','0.03626515565241118','0.036265155652411','test','test','0.31'),('2018-10-24 07:59:59','2018-10-24 15:59:59','BTCUSDT','4h','6610.939999999999600','6581.000000000000000','239.726459621585832','238.640772835581089','0.03626208370089365','0.036262083700894','test','test','0.45'),('2018-11-04 15:59:59','2018-11-05 11:59:59','BTCUSDT','4h','6479.989999999999782','6452.840000000000146','239.485195891362565','238.481795721231066','0.036957648991952544','0.036957648991953','test','test','0.41'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BTCUSDT','4h','6473.149999999999636','6448.119999999999891','239.262218075777781','238.337052844254231','0.03696225455547574','0.036962254555476','test','test','0.38'),('2018-11-06 11:59:59','2018-11-08 19:59:59','BTCUSDT','4h','6471.720000000000255','6495.720000000000255','239.056625802105856','239.943153497873055','0.03693865399030024','0.036938653990300','test','test','0.0'),('2018-11-13 19:59:59','2018-11-13 23:59:59','BTCUSDT','4h','6461.300000000000182','6457.659999999999854','239.253631956720824','239.118847436527915','0.03702871433871215','0.037028714338712','test','test','0.05'),('2018-12-17 19:59:59','2018-12-18 11:59:59','BTCUSDT','4h','3535.610000000000127','3490.849999999999909','239.223679841122390','236.195163712451887','0.06766121824554246','0.067661218245542','test','test','1.26'),('2018-12-18 15:59:59','2018-12-25 03:59:59','BTCUSDT','4h','3512.179999999999836','3709.099999999999909','238.550676256973361','251.925673884806571','0.0679209710940138','0.067920971094014','test','test','0.0'),('2018-12-28 19:59:59','2018-12-29 23:59:59','BTCUSDT','4h','3819.539999999999964','3743.149199999999837','241.522897952047401','236.692439993006445','0.06323350402196269','0.063233504021963','test','test','2.00'),('2018-12-30 15:59:59','2018-12-30 19:59:59','BTCUSDT','4h','3768.000000000000000','3780.119999999999891','240.449462850038344','241.222883096785296','0.06381355171179362','0.063813551711794','test','test','0.0'),('2019-01-01 23:59:59','2019-01-03 19:59:59','BTCUSDT','4h','3797.139999999999873','3756.000000000000000','240.621334015982058','238.014329354205699','0.06336909727215274','0.063369097272153','test','test','1.08'),('2019-01-04 23:59:59','2019-01-05 23:59:59','BTCUSDT','4h','3792.010000000000218','3770.960000000000036','240.041999646698486','238.709491532911073','0.06330204816092216','0.063302048160922','test','test','0.55'),('2019-01-06 11:59:59','2019-01-10 07:59:59','BTCUSDT','4h','3814.239999999999782','3777.019999999999982','239.745886732523530','237.406405760118957','0.0628554801828211','0.062855480182821','test','test','0.97'),('2019-01-19 11:59:59','2019-01-20 11:59:59','BTCUSDT','4h','3695.380000000000109','3621.472400000000107','239.226002071989114','234.441482030549338','0.06473650939064159','0.064736509390642','test','test','2.0'),('2019-01-26 07:59:59','2019-01-26 11:59:59','BTCUSDT','4h','3620.579999999999927','3589.929999999999836','238.162775396113631','236.146609735945674','0.065780282550341','0.065780282550341','test','test','0.84');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:55:23
