-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-30 15:59:59','ADABTC','4h','0.000028360000000','0.000027792800000','0.033333333333333','0.032666666666666','1175.3643629525152','1175.364362952515194','test','test','2.00'),('2018-05-31 15:59:59','2018-06-01 19:59:59','ADABTC','4h','0.000029820000000','0.000029223600000','0.033185185185185','0.032521481481481','1112.8499391410164','1112.849939141016421','test','test','1.99'),('2018-06-05 19:59:59','2018-06-06 07:59:59','ADABTC','4h','0.000028700000000','0.000028250000000','0.033037695473251','0.032519682826458','1151.1392150958495','1151.139215095849522','test','test','1.56'),('2018-07-01 11:59:59','2018-07-01 15:59:59','ADABTC','4h','0.000022370000000','0.000022060000000','0.032922581551741','0.032466345508780','1471.7291708422588','1471.729170842258782','test','test','1.38'),('2018-07-01 19:59:59','2018-07-02 07:59:59','ADABTC','4h','0.000022050000000','0.000022310000000','0.032821195764417','0.033208203061412','1488.4896038284203','1488.489603828420286','test','test','0.0'),('2018-07-02 15:59:59','2018-07-05 15:59:59','ADABTC','4h','0.000022960000000','0.000022620000000','0.032907197385971','0.032419895682520','1433.2403042670344','1433.240304267034389','test','test','1.48'),('2018-07-13 23:59:59','2018-07-14 03:59:59','ADABTC','4h','0.000022130000000','0.000021687400000','0.032798908118538','0.032142929956167','1482.1015869199073','1482.101586919907277','test','test','2.00'),('2018-07-14 19:59:59','2018-07-20 19:59:59','ADABTC','4h','0.000022230000000','0.000022270000000','0.032653135193566','0.032711890272637','1468.8769767686113','1468.876976768611257','test','test','1.88'),('2018-07-22 15:59:59','2018-07-22 23:59:59','ADABTC','4h','0.000023370000000','0.000022902600000','0.032666191877804','0.032012868040248','1397.783135550031','1397.783135550030920','test','test','2.00'),('2018-08-09 19:59:59','2018-08-09 23:59:59','ADABTC','4h','0.000019080000000','0.000018710000000','0.032521008802792','0.031890360309237','1704.4553879869902','1704.455387986990218','test','test','1.93'),('2018-08-28 19:59:59','2018-08-28 23:59:59','ADABTC','4h','0.000015000000000','0.000014900000000','0.032380864693113','0.032164992261826','2158.7243128741925','2158.724312874192492','test','test','0.66'),('2018-09-01 07:59:59','2018-09-02 03:59:59','ADABTC','4h','0.000014950000000','0.000014710000000','0.032332893041716','0.031813836564792','2162.7353205161057','2162.735320516105730','test','test','1.60'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADABTC','4h','0.000011560000000','0.000011328800000','0.032217547157955','0.031573196214796','2786.9850482659936','2786.985048265993555','test','test','2.00'),('2018-09-19 23:59:59','2018-09-20 03:59:59','ADABTC','4h','0.000011290000000','0.000011320000000','0.032074358059475','0.032159586645993','2840.952883921622','2840.952883921621833','test','test','0.0'),('2018-09-20 15:59:59','2018-09-25 03:59:59','ADABTC','4h','0.000011690000000','0.000012300000000','0.032093297745368','0.033767969398462','2745.363365728657','2745.363365728656845','test','test','0.25'),('2018-09-25 23:59:59','2018-09-26 03:59:59','ADABTC','4h','0.000012580000000','0.000012328400000','0.032465447001611','0.031816138061579','2580.7191575207567','2580.719157520756653','test','test','1.99'),('2018-09-26 15:59:59','2018-09-26 23:59:59','ADABTC','4h','0.000012490000000','0.000012240200000','0.032321156126048','0.031674733003527','2587.762700244071','2587.762700244070857','test','test','2.00'),('2018-09-27 15:59:59','2018-09-28 11:59:59','ADABTC','4h','0.000012950000000','0.000012691000000','0.032177506543266','0.031533956412401','2484.7495400205403','2484.749540020540280','test','test','2.00'),('2018-09-28 15:59:59','2018-10-03 03:59:59','ADABTC','4h','0.000012700000000','0.000012446000000','0.032034495403074','0.031393805495013','2522.4012128404543','2522.401212840454264','test','test','1.99'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ADABTC','4h','0.000012570000000','0.000012500000000','0.031892119867949','0.031714518563991','2537.1614851192608','2537.161485119260760','test','test','0.55'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADABTC','4h','0.000012700000000','0.000012446000000','0.031852652911514','0.031215599853284','2508.0829064184245','2508.082906418424500','test','test','1.99'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ADABTC','4h','0.000012020000000','0.000011880000000','0.031711085565241','0.031341738478791','2638.1934746456454','2638.193474645645438','test','test','1.16'),('2018-11-02 23:59:59','2018-11-03 07:59:59','ADABTC','4h','0.000011360000000','0.000011280000000','0.031629008434918','0.031406268938897','2784.243700256905','2784.243700256904958','test','test','0.70'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABTC','4h','0.000011310000000','0.000011640000000','0.031579510769136','0.032500928855238','2792.1760184912464','2792.176018491246396','test','test','0.0'),('2018-11-04 11:59:59','2018-11-09 15:59:59','ADABTC','4h','0.000011630000000','0.000011680000000','0.031784270343825','0.031920918109706','2732.955317611808','2732.955317611807914','test','test','0.0'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADABTC','4h','0.000011930000000','0.000011780000000','0.031814636514021','0.031414620128681','2666.775902264971','2666.775902264971137','test','test','1.25'),('2018-11-12 03:59:59','2018-11-12 11:59:59','ADABTC','4h','0.000011940000000','0.000011850000000','0.031725743983946','0.031486605210198','2657.0974860925926','2657.097486092592590','test','test','1.42'),('2018-11-12 15:59:59','2018-11-13 11:59:59','ADABTC','4h','0.000011990000000','0.000011840000000','0.031672602034224','0.031276364310693','2641.5848235382628','2641.584823538262754','test','test','1.33'),('2018-12-02 03:59:59','2018-12-02 07:59:59','ADABTC','4h','0.000010000000000','0.000009960000000','0.031584549206772','0.031458211009945','3158.4549206772435','3158.454920677243535','test','test','0.40'),('2018-12-03 03:59:59','2018-12-03 15:59:59','ADABTC','4h','0.000010090000000','0.000009900000000','0.031556474051922','0.030962249069775','3127.4999060378595','3127.499906037859546','test','test','1.88'),('2018-12-16 15:59:59','2018-12-16 19:59:59','ADABTC','4h','0.000008970000000','0.000009000000000','0.031424424055889','0.031529522464103','3503.2802737892234','3503.280273789223429','test','test','0.0'),('2018-12-17 15:59:59','2018-12-27 19:59:59','ADABTC','4h','0.000009180000000','0.000010120000000','0.031447779257715','0.034667922231817','3425.6840150015964','3425.684015001596435','test','test','0.0'),('2018-12-28 15:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000010360000000','0.000011970000000','0.032163366585293','0.037161727608683','3104.5720642174597','3104.572064217459683','test','test','0.0'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033274113479380','0.033218284429918','2791.4524731023116','2791.452473102311615','test','test','0.16'),('2019-01-15 23:59:59','2019-01-16 03:59:59','ADABTC','4h','0.000011830000000','0.000012010000000','0.033261707023944','0.033767802312559','2811.6404923029204','2811.640492302920393','test','test','0.0'),('2019-01-16 07:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012050000000','0.000012040000000','0.033374172643636','0.033346476234803','2769.6408832892757','2769.640883289275735','test','test','0.08'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.033368017886117','0.033121456177599','2739.574539090093','2739.574539090092912','test','test','0.73'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.033313226395336','0.032961326116512','2932.502323533059','2932.502323533059098','test','test','1.05'),('2019-02-09 11:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011450000000','0.000011221000000','0.033235026333375','0.032570325806708','2902.6223871942934','2902.622387194293424','test','test','2.00'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.033087315105226','0.032740548484036','2889.7218432512173','2889.721843251217251','test','test','1.31'),('2019-02-16 15:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.033010255856073','0.032864707990746','2910.9573065320205','2910.957306532020539','test','test','0.44'),('2019-02-17 11:59:59','2019-02-17 15:59:59','ADABTC','4h','0.000011310000000','0.000011240000000','0.032977911886000','0.032773804562214','2915.81891122904','2915.818911229040168','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','ADABTC','4h','0.000011340000000','0.000011540000000','0.032932554702937','0.033513375773536','2904.1053529926708','2904.105352992670760','test','test','0.0'),('2019-02-18 07:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011490000000','0.000011460000000','0.033061626051959','0.032975303268534','2877.4261141826705','2877.426114182670517','test','test','0.26'),('2019-02-23 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011730000000','0.000011495400000','0.033042443211198','0.032381594346974','2816.917579812257','2816.917579812256918','test','test','1.99'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.032895587908037','0.048802432194234','2924.052258492167','2924.052258492166857','test','test','0.0'),('2019-04-02 15:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016830000000','0.000016860000000','0.036430442193858','0.036495380593491','2164.6133210848743','2164.613321084874315','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.036444872949332','0.036312466508099','3310.1610308203853','3310.161030820385349','test','test','0.36'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011260200000','0.036415449295725','0.035687140309811','3169.316735920375','3169.316735920374867','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04  9:56:25
