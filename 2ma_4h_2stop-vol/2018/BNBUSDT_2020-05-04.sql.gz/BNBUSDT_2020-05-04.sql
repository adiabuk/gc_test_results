-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-23 11:59:59','2018-04-23 15:59:59','BNBUSDT','4h','13.726500000000000','13.451969999999999','222.222222222222200','217.777777777777743','16.18928512164224','16.189285121642239','test','test','2.00'),('2018-04-23 19:59:59','2018-04-25 15:59:59','BNBUSDT','4h','13.534200000000000','13.590000000000000','221.234567901234556','222.146693397302926','16.34633505498918','16.346335054989179','test','test','0.0'),('2018-04-26 07:59:59','2018-05-01 03:59:59','BNBUSDT','4h','14.260300000000001','13.975094000000000','221.437262455916425','217.008517206798103','15.528233098596552','15.528233098596552','test','test','2.00'),('2018-05-02 07:59:59','2018-05-02 15:59:59','BNBUSDT','4h','14.219900000000001','14.138999999999999','220.453096845001255','219.198892839715626','15.503139743950467','15.503139743950467','test','test','0.56'),('2018-05-02 23:59:59','2018-05-06 11:59:59','BNBUSDT','4h','14.439000000000000','14.150399999999999','220.174384843826630','215.773641893073204','15.24858957295011','15.248589572950110','test','test','1.99'),('2018-05-09 19:59:59','2018-05-10 11:59:59','BNBUSDT','4h','14.570800000000000','14.279384000000000','219.196441965881462','214.812513126563829','15.043542013196356','15.043542013196356','test','test','1.99'),('2018-05-18 11:59:59','2018-05-18 15:59:59','BNBUSDT','4h','14.879799999999999','14.582203999999999','218.222235557144217','213.857790846001336','14.665669938920162','14.665669938920162','test','test','2.00'),('2018-05-18 19:59:59','2018-05-19 15:59:59','BNBUSDT','4h','14.990700000000000','14.690886000000001','217.252358954668011','212.907311775574641','14.492475932055742','14.492475932055742','test','test','1.99'),('2018-05-21 23:59:59','2018-05-22 11:59:59','BNBUSDT','4h','14.699600000000000','14.405607999999999','216.286792914869494','211.961057056572088','14.713787648294478','14.713787648294478','test','test','2.00'),('2018-05-31 07:59:59','2018-06-04 15:59:59','BNBUSDT','4h','13.856199999999999','13.891999999999999','215.325518279692261','215.881850719640653','15.540012289061378','15.540012289061378','test','test','0.54'),('2018-06-05 07:59:59','2018-06-05 11:59:59','BNBUSDT','4h','14.715600000000000','14.421288000000001','215.449147710791948','211.140164756576098','14.640867359182904','14.640867359182904','test','test','1.99'),('2018-06-05 19:59:59','2018-06-10 07:59:59','BNBUSDT','4h','15.100000000000000','14.798000000000000','214.491595943188400','210.201764024324632','14.204741453191286','14.204741453191286','test','test','1.99'),('2018-06-11 23:59:59','2018-06-12 15:59:59','BNBUSDT','4h','15.470000000000001','15.770000000000000','213.538299961218655','217.679314181539610','13.803380734403273','13.803380734403273','test','test','0.0'),('2018-06-13 03:59:59','2018-06-13 11:59:59','BNBUSDT','4h','15.630100000000001','15.317498000000001','214.458525343512207','210.169354836641958','13.720867130953238','13.720867130953238','test','test','2.00'),('2018-06-15 15:59:59','2018-06-15 23:59:59','BNBUSDT','4h','15.325400000000000','15.018891999999999','213.505376341985510','209.235268815145787','13.931471696790004','13.931471696790004','test','test','2.00'),('2018-06-16 11:59:59','2018-06-20 07:59:59','BNBUSDT','4h','15.670400000000001','15.991899999999999','212.556463558243337','216.917354348138616','13.564201523780078','13.564201523780078','test','test','1.47'),('2018-06-21 15:59:59','2018-06-22 11:59:59','BNBUSDT','4h','16.594999999999999','16.263099999999998','213.525550400442285','209.255039392433446','12.866860524280947','12.866860524280947','test','test','2.00'),('2018-07-16 11:59:59','2018-07-17 07:59:59','BNBUSDT','4h','13.183100000000000','13.050000000000001','212.576547954218114','210.430319940116249','16.12492873104339','16.124928731043390','test','test','1.00'),('2018-07-17 15:59:59','2018-07-18 19:59:59','BNBUSDT','4h','13.183600000000000','13.170000000000000','212.099608395528804','211.880809685451197','16.08814044688316','16.088140446883159','test','test','0.10'),('2018-07-19 11:59:59','2018-07-19 15:59:59','BNBUSDT','4h','13.263400000000001','13.060400000000000','212.050986459955993','208.805487549316837','15.987679362754346','15.987679362754346','test','test','1.53'),('2018-07-25 07:59:59','2018-07-30 15:59:59','BNBUSDT','4h','13.042199999999999','13.390000000000001','211.329764479813974','216.965354494234816','16.20353655670163','16.203536556701629','test','test','0.77'),('2018-07-31 11:59:59','2018-08-01 07:59:59','BNBUSDT','4h','13.449999999999999','13.495799999999999','212.582117816351911','213.306003392261857','15.80536191943137','15.805361919431370','test','test','0.0'),('2018-08-02 11:59:59','2018-08-02 15:59:59','BNBUSDT','4h','13.612800000000000','13.516299999999999','212.742981277665223','211.234864086984771','15.628157416377617','15.628157416377617','test','test','0.70'),('2018-08-02 23:59:59','2018-08-04 15:59:59','BNBUSDT','4h','14.150000000000000','13.867000000000001','212.407844124180684','208.159687241697071','15.011155061779553','15.011155061779553','test','test','1.99'),('2018-08-06 15:59:59','2018-08-06 19:59:59','BNBUSDT','4h','13.679600000000001','13.612399999999999','211.463809261406567','210.425009297784300','15.458332791997321','15.458332791997321','test','test','0.49'),('2018-08-06 23:59:59','2018-08-07 03:59:59','BNBUSDT','4h','13.699800000000000','13.560300000000000','211.232964825046082','209.082057615225949','15.418689676130024','15.418689676130024','test','test','1.01'),('2018-08-26 23:59:59','2018-08-27 03:59:59','BNBUSDT','4h','10.215800000000000','10.313599999999999','210.754985445086021','212.772628466340279','20.63029674084125','20.630296740841249','test','test','0.0'),('2018-08-27 07:59:59','2018-08-30 11:59:59','BNBUSDT','4h','10.420000000000000','10.449999999999999','211.203350560920313','211.811421627794346','20.26903556246836','20.269035562468360','test','test','0.0'),('2018-08-30 23:59:59','2018-09-05 11:59:59','BNBUSDT','4h','10.789899999999999','10.574102000000000','211.338477464670092','207.111707915376712','19.58669472976303','19.586694729763028','test','test','1.99'),('2018-09-14 19:59:59','2018-09-14 23:59:59','BNBUSDT','4h','10.026000000000000','9.926800000000000','210.399195342604912','208.317447868239640','20.985357604488822','20.985357604488822','test','test','0.98'),('2018-09-15 03:59:59','2018-09-16 03:59:59','BNBUSDT','4h','10.140000000000001','9.937200000000001','209.936584792745947','205.737853096891030','20.7038052063852','20.703805206385201','test','test','1.99'),('2018-09-20 23:59:59','2018-09-24 11:59:59','BNBUSDT','4h','10.038800000000000','9.925599999999999','209.003533304778216','206.646757597512305','20.819573385741144','20.819573385741144','test','test','1.12'),('2018-09-27 19:59:59','2018-09-28 11:59:59','BNBUSDT','4h','10.039500000000000','9.949999999999999','208.479805369830189','206.621252396016729','20.76595501467505','20.765955014675050','test','test','0.89'),('2018-09-29 11:59:59','2018-09-29 15:59:59','BNBUSDT','4h','9.960900000000001','9.988099999999999','208.066793597871651','208.634956794556871','20.88835281931067','20.888352819310668','test','test','0.0'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBUSDT','4h','10.000000000000000','9.895500000000000','208.193052086023926','206.017434691724986','20.819305208602394','20.819305208602394','test','test','1.04'),('2018-09-30 19:59:59','2018-09-30 23:59:59','BNBUSDT','4h','9.980800000000000','10.017200000000001','207.709581553957491','208.467098864049291','20.81091511241158','20.810915112411578','test','test','0.0'),('2018-10-01 19:59:59','2018-10-01 23:59:59','BNBUSDT','4h','9.951900000000000','9.981100000000000','207.877918733977907','208.487856055196204','20.888264425283403','20.888264425283403','test','test','0.0'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBUSDT','4h','10.024100000000001','10.345700000000001','208.013460360915332','214.687089799176192','20.75133531797521','20.751335317975212','test','test','0.0'),('2018-10-10 15:59:59','2018-10-11 03:59:59','BNBUSDT','4h','10.340199999999999','10.133395999999999','209.496489124973294','205.306559342473832','20.26039043006647','20.260390430066469','test','test','2.0'),('2018-10-15 07:59:59','2018-10-18 15:59:59','BNBUSDT','4h','10.355100000000000','10.147997999999999','208.565393617751170','204.394085745396126','20.14132105124539','20.141321051245392','test','test','2.00'),('2018-11-04 15:59:59','2018-11-04 19:59:59','BNBUSDT','4h','9.700900000000001','9.826499999999999','207.638436312783398','210.326783538389833','21.404038420433505','21.404038420433505','test','test','0.0'),('2018-11-04 23:59:59','2018-11-05 11:59:59','BNBUSDT','4h','9.819000000000001','9.695000000000000','208.235846807362577','205.606124330113062','21.207439332657355','21.207439332657355','test','test','1.26'),('2018-11-05 15:59:59','2018-11-05 19:59:59','BNBUSDT','4h','9.726699999999999','9.729699999999999','207.651464034640441','207.715509845871793','21.348603743781595','21.348603743781595','test','test','0.0'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBUSDT','4h','9.733300000000000','9.694200000000000','207.665696437136347','206.831474875005114','21.335589824328476','21.335589824328476','test','test','0.40'),('2018-11-06 07:59:59','2018-11-08 19:59:59','BNBUSDT','4h','9.742000000000001','9.742500000000000','207.480313867773816','207.490962621308341','21.297507069161753','21.297507069161753','test','test','0.12'),('2018-12-04 15:59:59','2018-12-06 07:59:59','BNBUSDT','4h','5.756200000000000','5.894800000000000','207.482680257448152','212.478528122998739','36.04507839502591','36.045078395025911','test','test','0.0'),('2018-12-17 19:59:59','2018-12-25 03:59:59','BNBUSDT','4h','5.061900000000000','5.365500000000000','208.592868672014987','221.103743033188437','41.20841357435252','41.208413574352520','test','test','1.61'),('2018-12-26 23:59:59','2018-12-27 03:59:59','BNBUSDT','4h','5.602900000000000','5.490842000000000','211.373062974497969','207.145601715008013','37.72565331783505','37.725653317835047','test','test','2.00'),('2018-12-28 15:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.637000000000000','5.893500000000000','210.433627139055744','220.008973131812155','37.33078359749082','37.330783597490822','test','test','0.02'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','212.561481804112731','219.591422217348168','36.236806253791016','36.236806253791016','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.937133999999999','214.123690784831723','209.841216969135047','35.34385731720643','35.343857317206428','test','test','2.00'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','213.172029936899122','235.874775880992360','34.99729604454025','34.997296044540249','test','test','1.64'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','218.217084591142083','324.826273870512011','33.19193912617761','33.191939126177608','test','test','0.78'),('2019-02-28 11:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.347600000000000','14.458200000000000','241.908015542113134','338.006346429218354','23.37817615119575','23.378176151195749','test','test','1.32'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.847196000000000','263.263200183692049','257.997936180018201','17.376879525266467','17.376879525266467','test','test','1.99'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBUSDT','4h','17.040199999999999','16.699396000000000','262.093141516209016','256.851278685884836','15.380872379209695','15.380872379209695','test','test','1.99'),('2019-03-27 23:59:59','2019-03-30 03:59:59','BNBUSDT','4h','16.600000000000001','16.268000000000001','260.928283109470328','255.709717447280923','15.718571271654838','15.718571271654838','test','test','2.00'),('2019-03-30 15:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.510999999999999','17.836900000000000','259.768601851206029','280.629069975154550','15.733062918733332','15.733062918733332','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','264.404261434305681','261.609711956679519','14.449583648532421','14.449583648532421','test','test','1.05'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','263.783250439277651','262.888219822447923','14.412731349914909','14.412731349914909','test','test','0.33'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','263.584354746648785','264.491803730445781','14.426851888664112','14.426851888664112','test','test','0.0'),('2019-04-13 19:59:59','2019-04-23 11:59:59','BNBUSDT','4h','18.371700000000001','23.763100000000001','263.786010076381501','341.197240105491687','14.35827985849875','14.358279858498751','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:14:07
