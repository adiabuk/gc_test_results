-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-09-16 19:59:59','2018-09-16 23:59:59','WANBTC','4h','0.000152800000000','0.000149744000000','0.033333333333333','0.032666666666666','218.1500872600349','218.150087260034894','test','test','2.00'),('2018-09-17 03:59:59','2018-09-17 11:59:59','WANBTC','4h','0.000151300000000','0.000151000000000','0.033185185185185','0.033119385082372','219.33367604220166','219.333676042201660','test','test','0.72'),('2018-09-20 15:59:59','2018-09-20 19:59:59','WANBTC','4h','0.000145900000000','0.000143500000000','0.033170562940116','0.032624919684076','227.35135668345137','227.351356683451371','test','test','1.64'),('2018-09-20 23:59:59','2018-09-21 11:59:59','WANBTC','4h','0.000150100000000','0.000149600000000','0.033049308883218','0.032939217914253','220.18193792949884','220.181937929498844','test','test','0.33'),('2018-09-21 19:59:59','2018-09-22 03:59:59','WANBTC','4h','0.000156700000000','0.000153566000000','0.033024844223448','0.032364347338979','210.75203716303625','210.752037163036249','test','test','2.00'),('2018-09-22 19:59:59','2018-09-24 11:59:59','WANBTC','4h','0.000149200000000','0.000146216000000','0.032878067138010','0.032220505795250','220.36238028156984','220.362380281569841','test','test','2.00'),('2018-09-30 23:59:59','2018-10-01 15:59:59','WANBTC','4h','0.000147000000000','0.000146700000000','0.032731942395175','0.032665142512736','222.66627479710655','222.666274797106553','test','test','0.20'),('2018-10-01 19:59:59','2018-10-03 03:59:59','WANBTC','4h','0.000151800000000','0.000148800000000','0.032717097976855','0.032070515012886','215.527654656488','215.527654656488011','test','test','1.97'),('2018-10-04 15:59:59','2018-10-11 03:59:59','WANBTC','4h','0.000158200000000','0.000155036000000','0.032573412873751','0.031921944616276','205.90020779867677','205.900207798676774','test','test','1.99'),('2018-10-17 07:59:59','2018-10-17 11:59:59','WANBTC','4h','0.000155500000000','0.000154500000000','0.032428642149867','0.032220097827360','208.54432250718537','208.544322507185370','test','test','0.64'),('2018-10-17 15:59:59','2018-10-18 03:59:59','WANBTC','4h','0.000161700000000','0.000158466000000','0.032382298967088','0.031734652987746','200.2615891594805','200.261589159480508','test','test','1.99'),('2018-10-24 15:59:59','2018-10-25 03:59:59','WANBTC','4h','0.000157000000000','0.000154200000000','0.032238377638345','0.031663425680464','205.33998495761364','205.339984957613638','test','test','1.78'),('2018-10-25 07:59:59','2018-10-27 15:59:59','WANBTC','4h','0.000157500000000','0.000158400000000','0.032110610536594','0.032294099739660','203.8768922958349','203.876892295834892','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 15:59:59','WANBTC','4h','0.000165400000000','0.000165800000000','0.032151385915053','0.032229140173614','194.38564640298128','194.385646402981280','test','test','1.81'),('2018-10-30 03:59:59','2018-11-03 03:59:59','WANBTC','4h','0.000169000000000','0.000165620000000','0.032168664639178','0.031525291346394','190.3471280424721','190.347128042472093','test','test','2.00'),('2018-12-02 03:59:59','2018-12-02 07:59:59','WANBTC','4h','0.000105900000000','0.000105000000000','0.032025692796337','0.031753519769739','302.4144739975155','302.414473997515472','test','test','0.84'),('2018-12-04 15:59:59','2018-12-04 19:59:59','WANBTC','4h','0.000105000000000','0.000103900000000','0.031965209901537','0.031630336273997','304.4305704908317','304.430570490831713','test','test','1.04'),('2018-12-19 19:59:59','2018-12-19 23:59:59','WANBTC','4h','0.000095300000000','0.000093394000000','0.031890793539862','0.031252977669065','334.63581888627255','334.635818886272546','test','test','2.00'),('2018-12-20 19:59:59','2018-12-21 03:59:59','WANBTC','4h','0.000095200000000','0.000093296000000','0.031749056679685','0.031114075546091','333.49849453450275','333.498494534502754','test','test','2.00'),('2018-12-21 11:59:59','2018-12-21 15:59:59','WANBTC','4h','0.000095100000000','0.000101000000000','0.031607949761108','0.033568905634826','332.3654023250076','332.365402325007608','test','test','0.0'),('2018-12-22 03:59:59','2018-12-25 03:59:59','WANBTC','4h','0.000100200000000','0.000098196000000','0.032043717733046','0.031402843378385','319.79758216612333','319.797582166123334','test','test','2.00'),('2019-01-05 03:59:59','2019-01-07 11:59:59','WANBTC','4h','0.000093100000000','0.000092200000000','0.031901301209788','0.031592910542883','342.65629656055376','342.656296560553756','test','test','0.96'),('2019-01-16 15:59:59','2019-01-16 19:59:59','WANBTC','4h','0.000087800000000','0.000087700000000','0.031832769950475','0.031796513948254','362.5600222149809','362.560022214980904','test','test','0.11'),('2019-01-17 03:59:59','2019-01-18 11:59:59','WANBTC','4h','0.000091700000000','0.000089866000000','0.031824713061093','0.031188218799871','347.05248703481885','347.052487034818853','test','test','1.99'),('2019-01-21 23:59:59','2019-01-22 11:59:59','WANBTC','4h','0.000090700000000','0.000090800000000','0.031683269891932','0.031718201832276','349.319403439167','349.319403439166990','test','test','0.0'),('2019-01-22 15:59:59','2019-01-23 19:59:59','WANBTC','4h','0.000091300000000','0.000089474000000','0.031691032545342','0.031057211894435','347.1087902009005','347.108790200900501','test','test','2.00'),('2019-01-26 11:59:59','2019-01-27 15:59:59','WANBTC','4h','0.000091100000000','0.000089278000000','0.031550183511807','0.030919179841571','346.3247366828466','346.324736682846606','test','test','1.99'),('2019-02-06 19:59:59','2019-02-06 23:59:59','WANBTC','4h','0.000082600000000','0.000082900000000','0.031409960473977','0.031524040233568','380.2658653023863','380.265865302386317','test','test','0.0'),('2019-02-07 07:59:59','2019-02-07 15:59:59','WANBTC','4h','0.000083000000000','0.000081340000000','0.031435311531664','0.030806605301031','378.7386931525783','378.738693152578321','test','test','2.00'),('2019-02-11 23:59:59','2019-02-12 03:59:59','WANBTC','4h','0.000080700000000','0.000079800000000','0.031295599035968','0.030946577485381','387.8017228744458','387.801722874445773','test','test','1.11'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WANBTC','4h','0.000081100000000','0.000081000000000','0.031218038691393','0.031179545425436','384.9326595732785','384.932659573278499','test','test','0.12'),('2019-02-12 15:59:59','2019-02-12 23:59:59','WANBTC','4h','0.000081600000000','0.000081100000000','0.031209484632291','0.031018250045083','382.46917441533486','382.469174415334862','test','test','0.61'),('2019-02-17 23:59:59','2019-02-18 03:59:59','WANBTC','4h','0.000079900000000','0.000079600000000','0.031166988057356','0.031049965574037','390.07494439744954','390.074944397449542','test','test','0.37'),('2019-02-24 03:59:59','2019-02-24 15:59:59','WANBTC','4h','0.000079400000000','0.000077812000000','0.031140983061063','0.030518163399842','392.20381688996355','392.203816889963548','test','test','1.99'),('2019-02-26 07:59:59','2019-02-26 11:59:59','WANBTC','4h','0.000078200000000','0.000078200000000','0.031002578691903','0.031002578691903','396.4524129399346','396.452412939934618','test','test','0.0'),('2019-02-26 15:59:59','2019-03-04 07:59:59','WANBTC','4h','0.000078200000000','0.000078500000000','0.031002578691903','0.031121514415785','396.4524129399346','396.452412939934618','test','test','0.0'),('2019-03-07 19:59:59','2019-03-17 03:59:59','WANBTC','4h','0.000081400000000','0.000101100000000','0.031029008852766','0.038538486425241','381.19175494797975','381.191754947979746','test','test','1.35'),('2019-03-19 07:59:59','2019-03-19 11:59:59','WANBTC','4h','0.000103900000000','0.000101822000000','0.032697781646649','0.032043826013716','314.7043469359854','314.704346935985427','test','test','2.00'),('2019-03-19 19:59:59','2019-03-19 23:59:59','WANBTC','4h','0.000102500000000','0.000100600000000','0.032552458172664','0.031949046752878','317.5849577820856','317.584957782085610','test','test','1.85'),('2019-03-23 07:59:59','2019-03-23 11:59:59','WANBTC','4h','0.000101900000000','0.000101100000000','0.032418366746045','0.032163855525271','318.1390259670723','318.139025967072314','test','test','0.78'),('2019-03-23 19:59:59','2019-03-24 11:59:59','WANBTC','4h','0.000104500000000','0.000102410000000','0.032361808696984','0.031714572523044','309.6823798754428','309.682379875442791','test','test','2.00'),('2019-03-27 03:59:59','2019-03-27 07:59:59','WANBTC','4h','0.000101600000000','0.000103400000000','0.032217978436108','0.032788769392653','317.1060869695691','317.106086969569105','test','test','0.0'),('2019-03-27 11:59:59','2019-03-27 15:59:59','WANBTC','4h','0.000102700000000','0.000100646000000','0.032344820870896','0.031697924453478','314.9447017614021','314.944701761402087','test','test','2.00'),('2019-03-28 07:59:59','2019-03-29 11:59:59','WANBTC','4h','0.000102200000000','0.000101200000000','0.032201066111470','0.031885987186700','315.078924769763','315.078924769762978','test','test','0.97'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WANBTC','4h','0.000103500000000','0.000101600000000','0.032131048572632','0.031541203236516','310.4449137452367','310.444913745236704','test','test','1.83'),('2019-03-31 11:59:59','2019-04-02 03:59:59','WANBTC','4h','0.000103500000000','0.000103500000000','0.031999971831273','0.031999971831273','309.178471799738','309.178471799738020','test','test','0.0'),('2019-04-19 07:59:59','2019-04-19 19:59:59','WANBTC','4h','0.000085300000000','0.000084600000000','0.031999971831273','0.031737369483302','375.146211386552','375.146211386552011','test','test','1.64'),('2019-05-16 03:59:59','2019-05-16 07:59:59','WANBTC','4h','0.000053200000000','0.000053000000000','0.031941615753946','0.031821534491713','600.4063111643984','600.406311164398403','test','test','0.37'),('2019-05-18 03:59:59','2019-05-18 11:59:59','WANBTC','4h','0.000054600000000','0.000053508000000','0.031914931029005','0.031276632408425','584.5225463187791','584.522546318779064','test','test','2.00'),('2019-05-18 23:59:59','2019-05-19 03:59:59','WANBTC','4h','0.000054500000000','0.000053410000000','0.031773086891099','0.031137625153277','582.992420020159','582.992420020158988','test','test','1.99'),('2019-05-22 07:59:59','2019-05-22 11:59:59','WANBTC','4h','0.000053000000000','0.000051940000000','0.031631873171583','0.030999235708151','596.8277956902389','596.827795690238872','test','test','2.0'),('2019-05-22 19:59:59','2019-05-22 23:59:59','WANBTC','4h','0.000053600000000','0.000052528000000','0.031491287068598','0.030861461327226','587.524012473839','587.524012473838980','test','test','1.99'),('2019-05-23 03:59:59','2019-05-23 07:59:59','WANBTC','4h','0.000053300000000','0.000052234000000','0.031351325792737','0.030724299276882','588.2049867305315','588.204986730531459','test','test','1.99'),('2019-05-23 11:59:59','2019-05-24 15:59:59','WANBTC','4h','0.000053300000000','0.000053200000000','0.031211986566992','0.031153427492757','585.5907423450614','585.590742345061358','test','test','0.18'),('2019-05-30 07:59:59','2019-05-30 15:59:59','WANBTC','4h','0.000051300000000','0.000050274000000','0.031198973439384','0.030574993970596','608.1671235747367','608.167123574736706','test','test','2.0'),('2019-06-02 11:59:59','2019-06-04 03:59:59','WANBTC','4h','0.000054600000000','0.000053508000000','0.031060311335209','0.030439105108505','568.8701709745217','568.870170974521670','test','test','2.00'),('2019-06-07 03:59:59','2019-06-11 19:59:59','WANBTC','4h','0.000057000000000','0.000056600000000','0.030922265507052','0.030705267152617','542.4958860886393','542.495886088639281','test','test','1.92'),('2019-06-12 11:59:59','2019-06-12 23:59:59','WANBTC','4h','0.000057300000000','0.000057500000000','0.030874043650511','0.030981806455574','538.8140253143339','538.814025314333890','test','test','0.34'),('2019-06-13 11:59:59','2019-06-13 15:59:59','WANBTC','4h','0.000058800000000','0.000057624000000','0.030897990940525','0.030280031121714','525.476036403492','525.476036403492003','test','test','2.00'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANBTC','4h','0.000060300000000','0.000059094000000','0.030760666536345','0.030145453205618','510.1271399062207','510.127139906220691','test','test','2.00'),('2019-07-07 07:59:59','2019-07-07 11:59:59','WANBTC','4h','0.000034300000000','0.000033614000000','0.030623952462850','0.030011473413593','892.8266024154582','892.826602415458183','test','test','1.99'),('2019-07-07 23:59:59','2019-07-08 03:59:59','WANBTC','4h','0.000034100000000','0.000033418000000','0.030487846007460','0.029878089087311','894.0717304240403','894.071730424040311','test','test','1.99'),('2019-07-23 23:59:59','2019-07-24 03:59:59','WANBTC','4h','0.000025900000000','0.000025600000000','0.030352344469649','0.030000772912085','1171.9051918783355','1171.905191878335472','test','test','1.15'),('2019-07-24 07:59:59','2019-07-30 23:59:59','WANBTC','4h','0.000026200000000','0.000028600000000','0.030274217456857','0.033047428216264','1155.504483086141','1155.504483086140908','test','test','0.0'),('2019-07-31 07:59:59','2019-07-31 11:59:59','WANBTC','4h','0.000028600000000','0.000029200000000','0.030890486514503','0.031538538679143','1080.0869410665343','1080.086941066534337','test','test','0.0'),('2019-08-22 15:59:59','2019-08-29 03:59:59','WANBTC','4h','0.000021800000000','0.000034700000000','0.031034498106645','0.049398948821128','1423.6008305800506','1423.600830580050570','test','test','0.0'),('2019-08-30 15:59:59','2019-08-30 19:59:59','WANBTC','4h','0.000039580000000','0.000038788400000','0.035115487154308','0.034413177411222','887.2028083453259','887.202808345325934','test','test','2.00'),('2019-08-30 23:59:59','2019-08-31 07:59:59','WANBTC','4h','0.000038200000000','0.000037436000000','0.034959418322511','0.034260229956061','915.1680189139036','915.168018913903552','test','test','2.00'),('2019-08-31 11:59:59','2019-08-31 15:59:59','WANBTC','4h','0.000040660000000','0.000039846800000','0.034804043129967','0.034107962267368','855.9774503189046','855.977450318904630','test','test','2.00'),('2019-09-01 19:59:59','2019-09-02 03:59:59','WANBTC','4h','0.000041540000000','0.000040709200000','0.034649358493834','0.033956371323957','834.1203296541538','834.120329654153807','test','test','1.99'),('2019-09-02 15:59:59','2019-09-02 19:59:59','WANBTC','4h','0.000039830000000','0.000039033400000','0.034495361344972','0.033805454118073','866.0648090628168','866.064809062816835','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:27:59
