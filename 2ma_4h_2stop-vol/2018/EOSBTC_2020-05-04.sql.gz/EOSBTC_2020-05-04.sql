-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-29 15:59:59','2018-04-02 03:59:59','EOSBTC','4h','0.000828000000000','0.000811440000000','0.033333333333333','0.032666666666666','40.25764895330113','40.257648953301128','test','test','1.99'),('2018-04-02 11:59:59','2018-04-03 11:59:59','EOSBTC','4h','0.000819660000000','0.000803266800000','0.033185185185185','0.032521481481481','40.4865251264977','40.486525126497703','test','test','2.00'),('2018-04-04 19:59:59','2018-05-03 19:59:59','EOSBTC','4h','0.000835760000000','0.001886300000000','0.033037695473251','0.074565670732260','39.53012285016139','39.530122850161391','test','test','1.95'),('2018-05-05 03:59:59','2018-05-05 15:59:59','EOSBTC','4h','0.001860000000000','0.001822800000000','0.042266134419697','0.041420811731303','22.723728182632975','22.723728182632975','test','test','2.00'),('2018-05-06 15:59:59','2018-05-06 23:59:59','EOSBTC','4h','0.001845000000000','0.001808100000000','0.042078284933388','0.041236719234720','22.80665850048106','22.806658500481060','test','test','2.00'),('2018-05-07 03:59:59','2018-05-11 07:59:59','EOSBTC','4h','0.001812500000000','0.001776250000000','0.041891270333684','0.041053444927010','23.112425011687478','23.112425011687478','test','test','2.00'),('2018-05-24 23:59:59','2018-05-25 03:59:59','EOSBTC','4h','0.001680700000000','0.001647086000000','0.041705086909978','0.040870985171778','24.814117278501943','24.814117278501943','test','test','1.99'),('2018-05-25 11:59:59','2018-05-28 15:59:59','EOSBTC','4h','0.001635900000000','0.001658700000000','0.041519730968156','0.042098403176771','25.38036002699187','25.380360026991870','test','test','1.09'),('2018-05-31 19:59:59','2018-06-01 03:59:59','EOSBTC','4h','0.001654900000000','0.001643500000000','0.041648324792293','0.041361424736319','25.166671576707156','25.166671576707156','test','test','1.25'),('2018-06-02 11:59:59','2018-06-05 03:59:59','EOSBTC','4h','0.001820900000000','0.001784482000000','0.041584569224298','0.040752877839812','22.83737120341504','22.837371203415039','test','test','2.00'),('2018-06-05 11:59:59','2018-06-07 11:59:59','EOSBTC','4h','0.001836100000000','0.001799378000000','0.041399748916635','0.040571753938302','22.54765476642606','22.547654766426060','test','test','2.00'),('2018-06-07 19:59:59','2018-06-08 03:59:59','EOSBTC','4h','0.001871700000000','0.001834266000000','0.041215750032561','0.040391435031910','22.02048941206437','22.020489412064371','test','test','2.00'),('2018-06-08 19:59:59','2018-06-10 03:59:59','EOSBTC','4h','0.001847200000000','0.001810256000000','0.041032568921305','0.040211917542879','22.213387246267384','22.213387246267384','test','test','2.00'),('2018-06-10 11:59:59','2018-06-10 19:59:59','EOSBTC','4h','0.001841600000000','0.001812700000000','0.040850201948322','0.040209144804368','22.181908095309268','22.181908095309268','test','test','1.56'),('2018-07-16 15:59:59','2018-07-16 23:59:59','EOSBTC','4h','0.001199600000000','0.001203400000000','0.040707744805221','0.040836695647385','33.93443214840002','33.934432148400020','test','test','0.0'),('2018-07-17 19:59:59','2018-07-18 11:59:59','EOSBTC','4h','0.001200600000000','0.001198100000000','0.040736400547924','0.040651575459327','33.930035438883706','33.930035438883706','test','test','0.20'),('2018-08-05 03:59:59','2018-08-05 11:59:59','EOSBTC','4h','0.001008500000000','0.000995100000000','0.040717550528236','0.040176533991718','40.374368396862224','40.374368396862224','test','test','1.32'),('2018-08-05 15:59:59','2018-08-05 23:59:59','EOSBTC','4h','0.001001000000000','0.001001000000000','0.040597324631232','0.040597324631232','40.556767863368194','40.556767863368194','test','test','0.18'),('2018-08-06 07:59:59','2018-08-07 07:59:59','EOSBTC','4h','0.001001100000000','0.001002400000000','0.040597324631232','0.040650043162868','40.55271664292434','40.552716642924338','test','test','0.18'),('2018-08-17 23:59:59','2018-08-18 07:59:59','EOSBTC','4h','0.000848800000000','0.000831824000000','0.040609039860484','0.039796859063274','47.842883907262014','47.842883907262014','test','test','2.00'),('2018-08-27 15:59:59','2018-08-27 19:59:59','EOSBTC','4h','0.000771200000000','0.000774900000000','0.040428555238882','0.040622520039691','52.42291913755417','52.422919137554167','test','test','0.0'),('2018-08-27 23:59:59','2018-08-28 15:59:59','EOSBTC','4h','0.000780300000000','0.000769900000000','0.040471658527950','0.039932243881416','51.86679293598672','51.866792935986723','test','test','1.33'),('2018-08-28 19:59:59','2018-09-05 11:59:59','EOSBTC','4h','0.000823500000000','0.000830600000000','0.040351788606498','0.040699691094787','49.00035046326465','49.000350463264652','test','test','0.0'),('2018-09-13 15:59:59','2018-09-14 11:59:59','EOSBTC','4h','0.000817400000000','0.000810900000000','0.040429100270563','0.040107606324198','49.46060713305929','49.460607133059291','test','test','0.79'),('2018-09-15 11:59:59','2018-09-17 15:59:59','EOSBTC','4h','0.000831800000000','0.000815164000000','0.040357657171370','0.039550504027943','48.518462576785815','48.518462576785815','test','test','1.99'),('2018-09-19 19:59:59','2018-09-25 03:59:59','EOSBTC','4h','0.000820000000000','0.000834600000000','0.040178289806164','0.040893659356371','48.99791439776152','48.997914397761519','test','test','0.35'),('2018-09-26 15:59:59','2018-09-27 11:59:59','EOSBTC','4h','0.000860900000000','0.000857100000000','0.040337260817322','0.040159212738444','46.854757599397786','46.854757599397786','test','test','1.24'),('2018-09-27 19:59:59','2018-09-29 03:59:59','EOSBTC','4h','0.000882400000000','0.000864752000000','0.040297694577571','0.039491740686020','45.668284879386775','45.668284879386775','test','test','1.99'),('2018-09-30 11:59:59','2018-09-30 23:59:59','EOSBTC','4h','0.000878800000000','0.000863200000000','0.040118593712782','0.039406429327348','45.651563168845904','45.651563168845904','test','test','1.77'),('2018-10-01 23:59:59','2018-10-02 07:59:59','EOSBTC','4h','0.000868800000000','0.000863200000000','0.039960334960463','0.039702763740644','45.994860681932686','45.994860681932686','test','test','0.64'),('2018-10-04 11:59:59','2018-10-06 19:59:59','EOSBTC','4h','0.000863400000000','0.000865500000000','0.039903096911614','0.040000151004172','46.216234551325506','46.216234551325506','test','test','0.0'),('2018-10-08 07:59:59','2018-10-11 03:59:59','EOSBTC','4h','0.000870500000000','0.000858400000000','0.039924664487738','0.039369709358155','45.86406029608093','45.864060296080929','test','test','1.39'),('2018-10-21 03:59:59','2018-10-21 11:59:59','EOSBTC','4h','0.000839800000000','0.000837200000000','0.039801341125609','0.039678117159276','47.3938332050594','47.393833205059401','test','test','0.30'),('2018-10-21 15:59:59','2018-10-21 19:59:59','EOSBTC','4h','0.000838100000000','0.000836000000000','0.039773958021979','0.039674297704778','47.45729390523725','47.457293905237250','test','test','0.25'),('2018-10-28 15:59:59','2018-10-29 07:59:59','EOSBTC','4h','0.000836800000000','0.000835100000000','0.039751811284824','0.039671053542013','47.504554594674424','47.504554594674424','test','test','0.20'),('2018-10-29 11:59:59','2018-10-29 15:59:59','EOSBTC','4h','0.000837500000000','0.000820750000000','0.039733865119754','0.038939187817359','47.44342103851277','47.443421038512767','test','test','2.00'),('2018-11-02 15:59:59','2018-11-03 23:59:59','EOSBTC','4h','0.000839700000000','0.000834600000000','0.039557270163667','0.039317015218050','47.10881286610298','47.108812866102980','test','test','0.60'),('2018-11-04 07:59:59','2018-11-08 23:59:59','EOSBTC','4h','0.000847600000000','0.000852500000000','0.039503880175752','0.039732253244253','46.606748673609935','46.606748673609935','test','test','0.34'),('2018-11-12 19:59:59','2018-11-12 23:59:59','EOSBTC','4h','0.000846000000000','0.000845400000000','0.039554629746530','0.039526576817632','46.75488149708011','46.754881497080113','test','test','0.07'),('2018-11-19 23:59:59','2018-11-20 07:59:59','EOSBTC','4h','0.000839500000000','0.000822710000000','0.039548395762330','0.038757427847083','47.109464874723315','47.109464874723315','test','test','2.00'),('2018-11-20 23:59:59','2018-11-21 03:59:59','EOSBTC','4h','0.000835100000000','0.000824800000000','0.039372625114498','0.038887008974300','47.14719807747282','47.147198077472822','test','test','1.23'),('2018-11-23 03:59:59','2018-11-23 07:59:59','EOSBTC','4h','0.000833900000000','0.000838400000000','0.039264710416676','0.039476595770885','47.08563426870821','47.085634268708212','test','test','0.0'),('2018-11-24 23:59:59','2018-11-25 03:59:59','EOSBTC','4h','0.000840300000000','0.000835900000000','0.039311796050944','0.039105950635468','46.78304897172968','46.783048971729677','test','test','0.52'),('2018-11-25 07:59:59','2018-11-25 23:59:59','EOSBTC','4h','0.000835500000000','0.000833300000000','0.039266052625283','0.039162659069597','46.997070766347235','46.997070766347235','test','test','0.26'),('2018-11-26 15:59:59','2018-11-26 23:59:59','EOSBTC','4h','0.000846500000000','0.000842200000000','0.039243076279575','0.039043731651102','46.35921592389263','46.359215923892627','test','test','0.53'),('2018-12-15 23:59:59','2018-12-25 11:59:59','EOSBTC','4h','0.000586600000000','0.000658700000000','0.039198777473248','0.044016765635234','66.82369156707769','66.823691567077688','test','test','0.0'),('2018-12-26 03:59:59','2018-12-27 07:59:59','EOSBTC','4h','0.000675000000000','0.000661500000000','0.040269441509245','0.039464052679060','59.65843186554765','59.658431865547648','test','test','2.00'),('2018-12-28 19:59:59','2018-12-31 11:59:59','EOSBTC','4h','0.000684100000000','0.000671800000000','0.040090466213648','0.039369646546307','58.60322498706037','58.603224987060372','test','test','1.79'),('2019-01-01 11:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000693100000000','0.000694000000000','0.039930284065350','0.039982134095156','57.611144229331984','57.611144229331984','test','test','0.60'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000689332000000','0.039941806294196','0.039142970168312','56.78391568694309','56.783915686943089','test','test','2.00'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.039764287155110','0.039799769862268','59.13784526340042','59.137845263400422','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.039772172201146','0.039434280596097','58.25717328423254','58.257173284232543','test','test','0.84'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.039697085177801','0.038923802809168','57.707639450212724','57.707639450212724','test','test','1.94'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000669500000000','0.039525244651438','0.039070059492304','58.35707168380103','58.357071683801031','test','test','1.15'),('2019-02-02 23:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000695900000000','0.000681982000000','0.039424092393853','0.038635610545976','56.65195055877728','56.651950558777280','test','test','2.00'),('2019-02-07 03:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000693000000000','0.000896200000000','0.039248874205436','0.050757346411128','56.63618211462626','56.636182114626259','test','test','0.53'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000925700000000','0.041806312473368','0.041355100936735','44.67440956760799','44.674409567607988','test','test','1.07'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.041706043243005','0.041242440757087','45.45122410963892','45.451224109638922','test','test','1.11'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000909000000000','0.041603020468356','0.040839250114185','44.92766789239333','44.927667892393330','test','test','1.83'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.041433293722985','0.040649550768698','43.784522585844755','43.784522585844755','test','test','1.89'),('2019-03-09 07:59:59','2019-03-11 07:59:59','EOSBTC','4h','0.000958500000000','0.000939330000000','0.041259128622032','0.040433946049591','43.04551760253752','43.045517602537522','test','test','1.99'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.041075754717045','0.040792443590495','43.58632716155065','43.586327161550649','test','test','0.68'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.041012796688923','0.040755813362176','43.55649605875436','43.556496058754362','test','test','0.62'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.040955689282979','0.040695106335961','44.16660118945253','44.166601189452528','test','test','0.63'),('2019-03-26 11:59:59','2019-03-28 15:59:59','EOSBTC','4h','0.000924700000000','0.001065800000000','0.040897781961420','0.047138375705073','44.228162605623204','44.228162605623204','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:04:21
