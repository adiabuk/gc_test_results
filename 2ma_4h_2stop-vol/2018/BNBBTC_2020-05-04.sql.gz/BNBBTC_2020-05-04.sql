-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-02 03:59:59','2018-01-02 19:59:59','BNBBTC','4h','0.000627680000000','0.000615126400000','0.033333333333333','0.032666666666666','53.10561644999575','53.105616449995750','test','test','1.99'),('2018-01-03 19:59:59','2018-01-16 03:59:59','BNBBTC','4h','0.000597920000000','0.001372900000000','0.033185185185185','0.076197385504316','55.50104560005537','55.501045600055370','test','test','0.0'),('2018-01-19 03:59:59','2018-01-20 07:59:59','BNBBTC','4h','0.001314500000000','0.001288210000000','0.042743451922770','0.041888582884315','32.51689001351828','32.516890013518278','test','test','1.99'),('2018-01-20 19:59:59','2018-01-20 23:59:59','BNBBTC','4h','0.001278900000000','0.001266600000000','0.042553481025335','0.042144216957299','33.273501466365886','33.273501466365886','test','test','0.96'),('2018-02-07 11:59:59','2018-02-07 15:59:59','BNBBTC','4h','0.001086800000000','0.001072900000000','0.042462533454661','0.041919444372015','39.0711570248994','39.071157024899399','test','test','1.27'),('2018-02-09 15:59:59','2018-02-10 11:59:59','BNBBTC','4h','0.001144200000000','0.001121316000000','0.042341846991850','0.041495010052013','37.005634497334775','37.005634497334775','test','test','1.99'),('2018-02-11 15:59:59','2018-02-11 19:59:59','BNBBTC','4h','0.001097400000000','0.001075452000000','0.042153661005220','0.041310587785116','38.41230272026609','38.412302720266091','test','test','1.99'),('2018-02-14 23:59:59','2018-02-15 19:59:59','BNBBTC','4h','0.001101000000000','0.001083500000000','0.041966311400752','0.041299271937071','38.1165407817915','38.116540781791500','test','test','1.58'),('2018-02-16 15:59:59','2018-02-16 19:59:59','BNBBTC','4h','0.001084000000000','0.001080800000000','0.041818080408823','0.041694632200974','38.57756495278906','38.577564952789061','test','test','0.29'),('2018-02-16 23:59:59','2018-02-17 11:59:59','BNBBTC','4h','0.001103900000000','0.001081822000000','0.041790647473746','0.040954834524271','37.85727645053517','37.857276450535167','test','test','2.00'),('2018-02-26 07:59:59','2018-02-26 11:59:59','BNBBTC','4h','0.000978300000000','0.000962900000000','0.041604911262751','0.040949983701219','42.52776373581859','42.527763735818588','test','test','1.57'),('2018-02-27 07:59:59','2018-02-27 15:59:59','BNBBTC','4h','0.001012800000000','0.000992544000000','0.041459371804633','0.040630184368540','40.93539870125702','40.935398701257022','test','test','1.99'),('2018-02-28 03:59:59','2018-03-01 07:59:59','BNBBTC','4h','0.001008600000000','0.000991000000000','0.041275107929946','0.040554860161190','40.923168679303764','40.923168679303764','test','test','1.74'),('2018-03-13 15:59:59','2018-03-19 15:59:59','BNBBTC','4h','0.001063000000000','0.001043300000000','0.041115052870222','0.040353089990125','38.67831878666249','38.678318786662487','test','test','1.85'),('2018-03-20 03:59:59','2018-03-20 19:59:59','BNBBTC','4h','0.001051500000000','0.001030470000000','0.040945727785756','0.040126813230041','38.94030222135637','38.940302221356369','test','test','2.00'),('2018-03-21 11:59:59','2018-04-12 11:59:59','BNBBTC','4h','0.001099000000000','0.001626100000000','0.040763746773375','0.060314766722643','37.09167131335315','37.091671313353153','test','test','0.98'),('2018-04-14 03:59:59','2018-04-14 07:59:59','BNBBTC','4h','0.001711700000000','0.001690500000000','0.045108417873212','0.044549734424645','26.352992856933128','26.352992856933128','test','test','1.23'),('2018-04-24 15:59:59','2018-04-25 03:59:59','BNBBTC','4h','0.001592200000000','0.001560356000000','0.044984265995753','0.044084580675838','28.252899130607403','28.252899130607403','test','test','2.00'),('2018-04-26 07:59:59','2018-04-26 11:59:59','BNBBTC','4h','0.001613700000000','0.001581426000000','0.044784335924661','0.043888649206168','27.75257849951099','27.752578499510989','test','test','2.00'),('2018-04-28 03:59:59','2018-04-29 11:59:59','BNBBTC','4h','0.001627200000000','0.001594656000000','0.044585294431662','0.043693588543029','27.40000886901575','27.400008869015750','test','test','2.00'),('2018-05-09 15:59:59','2018-05-11 07:59:59','BNBBTC','4h','0.001513800000000','0.001506700000000','0.044387137567522','0.044178953740907','29.321665720386953','29.321665720386953','test','test','0.46'),('2018-05-13 11:59:59','2018-05-13 19:59:59','BNBBTC','4h','0.001537800000000','0.001507044000000','0.044340874494941','0.043454057005042','28.833967027533273','28.833967027533273','test','test','2.00'),('2018-05-17 15:59:59','2018-05-17 19:59:59','BNBBTC','4h','0.001509500000000','0.001546200000000','0.044143803941630','0.045217058399833','29.243990686737174','29.243990686737174','test','test','0.0'),('2018-05-17 23:59:59','2018-05-23 11:59:59','BNBBTC','4h','0.001536700000000','0.001651800000000','0.044382304932342','0.047706573363209','28.881567600925067','28.881567600925067','test','test','0.0'),('2018-05-29 23:59:59','2018-05-30 03:59:59','BNBBTC','4h','0.001688800000000','0.001671100000000','0.045121031250312','0.044648126079107','26.71780628275225','26.717806282752250','test','test','1.04'),('2018-05-30 11:59:59','2018-05-30 15:59:59','BNBBTC','4h','0.001686000000000','0.001678700000000','0.045015941212266','0.044821032332759','26.699846507868585','26.699846507868585','test','test','0.43'),('2018-05-30 23:59:59','2018-06-20 15:59:59','BNBBTC','4h','0.001705000000000','0.002362600000000','0.044972628127932','0.062318082824078','26.37690799292173','26.376907992921730','test','test','0.0'),('2018-06-21 15:59:59','2018-06-24 03:59:59','BNBBTC','4h','0.002474300000000','0.002424814000000','0.048827173615964','0.047850630143645','19.733732213540797','19.733732213540797','test','test','2.00'),('2018-06-28 23:59:59','2018-06-29 03:59:59','BNBBTC','4h','0.002419900000000','0.002416800000000','0.048610163955449','0.048547892163944','20.087674678891133','20.087674678891133','test','test','0.12'),('2018-06-29 19:59:59','2018-06-29 23:59:59','BNBBTC','4h','0.002394300000000','0.002346414000000','0.048596325779559','0.047624399263968','20.296673674793748','20.296673674793748','test','test','2.00'),('2018-07-28 07:59:59','2018-07-29 11:59:59','BNBBTC','4h','0.001755300000000','0.001720194000000','0.048380342109427','0.047412735267238','27.562434973752246','27.562434973752246','test','test','2.00'),('2018-07-31 15:59:59','2018-08-11 15:59:59','BNBBTC','4h','0.001775000000000','0.001899000000000','0.048165318366719','0.051530106804732','27.135390629137273','27.135390629137273','test','test','1.61'),('2018-08-27 11:59:59','2018-08-28 19:59:59','BNBBTC','4h','0.001588900000000','0.001613800000000','0.048913049130722','0.049679576239637','30.78422124156431','30.784221241564310','test','test','0.81'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BNBBTC','4h','0.001626300000000','0.001593774000000','0.049083388488258','0.048101720718493','30.181017332754234','30.181017332754234','test','test','1.99'),('2018-09-01 03:59:59','2018-09-02 03:59:59','BNBBTC','4h','0.001600800000000','0.001583100000000','0.048865240094977','0.048324938527210','30.525512303209084','30.525512303209084','test','test','1.10'),('2018-09-06 23:59:59','2018-09-07 07:59:59','BNBBTC','4h','0.001578800000000','0.001548900000000','0.048745173079918','0.047822015824351','30.87482460091067','30.874824600910671','test','test','1.89'),('2018-09-15 03:59:59','2018-09-16 07:59:59','BNBBTC','4h','0.001559000000000','0.001527820000000','0.048540027023125','0.047569226482662','31.135360502325273','31.135360502325273','test','test','2.00'),('2018-09-16 23:59:59','2018-09-17 15:59:59','BNBBTC','4h','0.001528700000000','0.001510900000000','0.048324293569689','0.047761611273921','31.61136493078359','31.611364930783591','test','test','1.16'),('2018-09-20 19:59:59','2018-09-20 23:59:59','BNBBTC','4h','0.001517400000000','0.001546200000000','0.048199253059518','0.049114066877967','31.764368696136955','31.764368696136955','test','test','0.0'),('2018-09-21 07:59:59','2018-09-21 11:59:59','BNBBTC','4h','0.001537800000000','0.001528100000000','0.048402545019174','0.048097235689816','31.475188593558038','31.475188593558038','test','test','0.63'),('2018-09-23 11:59:59','2018-09-23 15:59:59','BNBBTC','4h','0.001534500000000','0.001523500000000','0.048334698501538','0.047988213207620','31.49866308343984','31.498663083439840','test','test','0.71'),('2018-09-24 03:59:59','2018-09-24 07:59:59','BNBBTC','4h','0.001535100000000','0.001518500000000','0.048257701769557','0.047735860945262','31.436194234614458','31.436194234614458','test','test','1.08'),('2018-09-29 19:59:59','2018-09-30 03:59:59','BNBBTC','4h','0.001518400000000','0.001505900000000','0.048141737141936','0.047745417519785','31.705569772086104','31.705569772086104','test','test','0.82'),('2018-10-02 19:59:59','2018-10-09 15:59:59','BNBBTC','4h','0.001527500000000','0.001557100000000','0.048053666114791','0.048984853359961','31.45902855305459','31.459028553054591','test','test','0.0'),('2018-10-10 15:59:59','2018-10-10 19:59:59','BNBBTC','4h','0.001568800000000','0.001566300000000','0.048260596613718','0.048183689747620','30.76274643913663','30.762746439136631','test','test','0.15'),('2018-10-15 23:59:59','2018-10-16 07:59:59','BNBBTC','4h','0.001563900000000','0.001532622000000','0.048243506199029','0.047278636075048','30.848203976615576','30.848203976615576','test','test','2.00'),('2018-11-01 23:59:59','2018-11-02 03:59:59','BNBBTC','4h','0.001499400000000','0.001507100000000','0.048029090615922','0.048275738606947','32.03220662659878','32.032206626598779','test','test','0.0'),('2018-11-02 23:59:59','2018-11-03 03:59:59','BNBBTC','4h','0.001501600000000','0.001494800000000','0.048083901280594','0.047866153192749','32.02177762426375','32.021777624263748','test','test','0.45'),('2018-11-03 23:59:59','2018-11-04 03:59:59','BNBBTC','4h','0.001501900000000','0.001497600000000','0.048035512816629','0.047897985214850','31.983163204360395','31.983163204360395','test','test','0.28'),('2018-11-04 11:59:59','2018-11-04 15:59:59','BNBBTC','4h','0.001503300000000','0.001497100000000','0.048004951127345','0.047806966229461','31.93304804586221','31.933048045862211','test','test','0.41'),('2018-11-04 19:59:59','2018-11-05 19:59:59','BNBBTC','4h','0.001515800000000','0.001504800000000','0.047960954483370','0.047612906918179','31.640687744669766','31.640687744669766','test','test','0.97'),('2018-11-05 23:59:59','2018-11-06 03:59:59','BNBBTC','4h','0.001507900000000','0.001503300000000','0.047883610579995','0.047737536829303','31.755163193842204','31.755163193842204','test','test','0.30'),('2018-11-06 07:59:59','2018-11-06 19:59:59','BNBBTC','4h','0.001506600000000','0.001501600000000','0.047851149746508','0.047692344656416','31.761018018390782','31.761018018390782','test','test','0.33'),('2018-11-07 03:59:59','2018-11-07 07:59:59','BNBBTC','4h','0.001510900000000','0.001502100000000','0.047815859726487','0.047537363753495','31.647269658142235','31.647269658142235','test','test','0.58'),('2018-11-08 15:59:59','2018-11-08 19:59:59','BNBBTC','4h','0.001507000000000','0.001500800000000','0.047753971732489','0.047557505491785','31.688103339408677','31.688103339408677','test','test','0.41'),('2018-12-03 15:59:59','2018-12-06 19:59:59','BNBBTC','4h','0.001294800000000','0.001389200000000','0.047710312567888','0.051188728930576','36.84763096067963','36.847630960679631','test','test','0.0'),('2018-12-11 15:59:59','2018-12-11 19:59:59','BNBBTC','4h','0.001362400000000','0.001393000000000','0.048483293981819','0.049572246415644','35.586680843965546','35.586680843965546','test','test','0.0'),('2018-12-11 23:59:59','2018-12-12 03:59:59','BNBBTC','4h','0.001449500000000','0.001420510000000','0.048725283411558','0.047750777743327','33.61523519251986','33.615235192519862','test','test','2.00'),('2018-12-12 11:59:59','2018-12-13 11:59:59','BNBBTC','4h','0.001450100000000','0.001421098000000','0.048508726596395','0.047538552064467','33.45198717081244','33.451987170812437','test','test','1.99'),('2018-12-14 15:59:59','2018-12-14 19:59:59','BNBBTC','4h','0.001421800000000','0.001393364000000','0.048293132255967','0.047327269610848','33.966192330824775','33.966192330824775','test','test','1.99'),('2018-12-15 11:59:59','2018-12-20 19:59:59','BNBBTC','4h','0.001420400000000','0.001396800000000','0.048078496112607','0.047279670071874','33.84856104801949','33.848561048019491','test','test','1.66'),('2018-12-21 23:59:59','2018-12-22 03:59:59','BNBBTC','4h','0.001427600000000','0.001428100000000','0.047900979214666','0.047917755965582','33.553501831511774','33.553501831511774','test','test','0.0'),('2018-12-22 11:59:59','2018-12-25 03:59:59','BNBBTC','4h','0.001438900000000','0.001445500000000','0.047904707381536','0.048124438473841','33.29258974323194','33.292589743231943','test','test','0.0'),('2018-12-26 19:59:59','2018-12-27 07:59:59','BNBBTC','4h','0.001473200000000','0.001461700000000','0.047953536513160','0.047579204670979','32.550594972277885','32.550594972277885','test','test','0.78'),('2018-12-28 11:59:59','2019-01-02 19:59:59','BNBBTC','4h','0.001489000000000','0.001559500000000','0.047870351659342','0.050136879390694','32.149329522727854','32.149329522727854','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:12:38
