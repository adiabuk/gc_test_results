-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-22 23:59:59','2018-03-23 11:59:59','MDAETH','4h','0.001660900000000','0.001627682000000','1.297777777777778','1.271822222222222','781.3702075849104','781.370207584910418','test','test','2.00'),('2018-03-24 11:59:59','2018-03-24 23:59:59','MDAETH','4h','0.001718800000000','0.001684424000000','1.292009876543210','1.266169679012346','751.6929698296543','751.692969829654317','test','test','2.00'),('2018-03-25 15:59:59','2018-04-03 19:59:59','MDAETH','4h','0.001754800000000','0.001797100000000','1.286267610425240','1.317273491392295','732.9995500485753','732.999550048575315','test','test','1.14'),('2018-04-04 19:59:59','2018-04-04 23:59:59','MDAETH','4h','0.001820000000000','0.001783600000000','1.293157806195697','1.267294650071783','710.5262671404926','710.526267140492564','test','test','2.00'),('2018-04-06 11:59:59','2018-04-07 07:59:59','MDAETH','4h','0.001828300000000','0.001853000000000','1.287410438168160','1.304803118703495','704.1571066937374','704.157106693737433','test','test','0.28'),('2018-04-11 15:59:59','2018-04-11 19:59:59','MDAETH','4h','0.001912800000000','0.001874544000000','1.291275478287124','1.265449968721382','675.070827209914','675.070827209914000','test','test','1.99'),('2018-04-12 19:59:59','2018-04-12 23:59:59','MDAETH','4h','0.001799700000000','0.001763706000000','1.285536476161403','1.259825746638175','714.3059821978125','714.305982197812455','test','test','2.00'),('2018-04-14 07:59:59','2018-04-14 19:59:59','MDAETH','4h','0.001825200000000','0.001788696000000','1.279822980711797','1.254226521097561','701.1960227436977','701.196022743697654','test','test','2.00'),('2018-04-15 11:59:59','2018-04-15 15:59:59','MDAETH','4h','0.001852400000000','0.001856800000000','1.274134878575300','1.277161327217997','687.8292369765171','687.829236976517109','test','test','0.0'),('2018-04-17 19:59:59','2018-04-18 07:59:59','MDAETH','4h','0.001894000000000','0.001875000000000','1.274807422718122','1.262018963884096','673.0767807381845','673.076780738184539','test','test','1.57'),('2018-04-18 11:59:59','2018-04-21 03:59:59','MDAETH','4h','0.001892800000000','0.001894400000000','1.271965542977227','1.273040746310259','672.0020831451959','672.002083145195911','test','test','0.0'),('2018-04-23 11:59:59','2018-04-24 03:59:59','MDAETH','4h','0.001935200000000','0.001896496000000','1.272204477051234','1.246760387510209','657.4020654460696','657.402065446069628','test','test','2.00'),('2018-04-30 15:59:59','2018-05-01 03:59:59','MDAETH','4h','0.001899800000000','0.001861804000000','1.266550234931006','1.241219230232386','666.6755631808644','666.675563180864401','test','test','1.99'),('2018-05-01 15:59:59','2018-05-01 19:59:59','MDAETH','4h','0.001899900000000','0.001861902000000','1.260921122775757','1.235702700320242','663.677626599167','663.677626599166956','test','test','2.00'),('2018-05-02 19:59:59','2018-05-03 03:59:59','MDAETH','4h','0.001818500000000','0.001782130000000','1.255317028896754','1.230210688318819','690.30356276973','690.303562769729979','test','test','1.99'),('2018-06-01 15:59:59','2018-06-01 19:59:59','MDAETH','4h','0.001395800000000','0.001367884000000','1.249737842101657','1.224743085259624','895.3559550807117','895.355955080711738','test','test','2.00'),('2018-06-02 07:59:59','2018-06-02 11:59:59','MDAETH','4h','0.001381000000000','0.001353380000000','1.244183451692317','1.219299782658470','900.9293640060222','900.929364006022183','test','test','2.00'),('2018-06-06 11:59:59','2018-06-06 15:59:59','MDAETH','4h','0.001288900000000','0.001266400000000','1.238653747462573','1.217030883533713','961.0161746160082','961.016174616008243','test','test','1.74'),('2018-06-29 23:59:59','2018-06-30 03:59:59','MDAETH','4h','0.000976100000000','0.001002200000000','1.233848666589493','1.266840624583536','1264.0596932583678','1264.059693258367815','test','test','0.0'),('2018-06-30 07:59:59','2018-06-30 11:59:59','MDAETH','4h','0.001123000000000','0.001100540000000','1.241180212810391','1.216356608554183','1105.2361645684693','1105.236164568469349','test','test','1.99'),('2018-06-30 15:59:59','2018-07-01 11:59:59','MDAETH','4h','0.001109800000000','0.001087604000000','1.235663856309012','1.210950579182832','1113.4112960073992','1113.411296007399187','test','test','1.99'),('2018-07-01 15:59:59','2018-07-10 03:59:59','MDAETH','4h','0.001141400000000','0.001123600000000','1.230172016947638','1.210987627687372','1077.7746775430508','1077.774677543050757','test','test','1.88'),('2018-07-17 07:59:59','2018-07-30 19:59:59','MDAETH','4h','0.001150800000000','0.001346900000000','1.225908819334246','1.434807602329941','1065.2666139505093','1065.266613950509281','test','test','0.0'),('2018-07-31 07:59:59','2018-07-31 15:59:59','MDAETH','4h','0.001377400000000','0.001349852000000','1.272330771111067','1.246884155688846','923.7191600922515','923.719160092251514','test','test','2.00'),('2018-07-31 19:59:59','2018-08-01 03:59:59','MDAETH','4h','0.001363600000000','0.001367700000000','1.266675967683907','1.270484541655382','928.9204808476876','928.920480847687600','test','test','1.15'),('2018-08-10 03:59:59','2018-08-10 07:59:59','MDAETH','4h','0.001295000000000','0.001269100000000','1.267522317455346','1.242171871106239','978.7817123207304','978.781712320730435','test','test','1.99'),('2018-08-11 03:59:59','2018-08-11 07:59:59','MDAETH','4h','0.001298100000000','0.001272138000000','1.261888884933322','1.236651107234656','972.1045257941005','972.104525794100482','test','test','2.00'),('2018-08-13 23:59:59','2018-08-14 23:59:59','MDAETH','4h','0.001253000000000','0.001239500000000','1.256280489889174','1.242745145425085','1002.6181084510569','1002.618108451056855','test','test','1.07'),('2018-08-15 03:59:59','2018-08-15 19:59:59','MDAETH','4h','0.001269400000000','0.001244012000000','1.253272635563821','1.228207182852544','987.2952856182613','987.295285618261346','test','test','2.00'),('2018-08-17 11:59:59','2018-09-07 07:59:59','MDAETH','4h','0.001309200000000','0.002634200000000','1.247702534961315','2.510462891533070','953.0266842050985','953.026684205098491','test','test','1.40'),('2018-09-07 19:59:59','2018-09-07 23:59:59','MDAETH','4h','0.002686100000000','0.002637700000000','1.528315947532816','1.500777698077998','568.9720961739384','568.972096173938439','test','test','1.80'),('2018-09-17 03:59:59','2018-09-17 07:59:59','MDAETH','4h','0.002506200000000','0.002463200000000','1.522196336542857','1.496079329731213','607.3722514335873','607.372251433587280','test','test','1.71'),('2018-10-04 11:59:59','2018-10-04 15:59:59','MDAETH','4h','0.002020800000000','0.001996500000000','1.516392557251380','1.498158026797496','750.3921997483075','750.392199748307462','test','test','1.20'),('2018-10-07 15:59:59','2018-10-20 15:59:59','MDAETH','4h','0.002136500000000','0.009737700000000','1.512340439372739','6.892917152576608','707.8588529710925','707.858852971092460','test','test','0.0'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDAETH','4h','0.008790100000000','0.008614298000000','2.708024153418043','2.653863670349682','308.07660361293307','308.076603612933070','test','test','2.00'),('2018-11-12 07:59:59','2018-11-12 11:59:59','MDAETH','4h','0.006735100000000','0.006600398000000','2.695988490513963','2.642068720703684','400.28930387283975','400.289303872839753','test','test','2.00'),('2018-11-12 23:59:59','2018-11-13 03:59:59','MDAETH','4h','0.006653000000000','0.006519940000000','2.684006319445011','2.630326193056111','403.4279752660471','403.427975266047099','test','test','1.99'),('2018-11-22 11:59:59','2018-11-22 15:59:59','MDAETH','4h','0.005463500000000','0.005530700000000','2.672077402469700','2.704943440988226','489.07795414472423','489.077954144724231','test','test','0.0'),('2018-11-22 23:59:59','2018-11-23 03:59:59','MDAETH','4h','0.005704500000000','0.005590410000000','2.679380966584929','2.625793347253230','469.6960235927652','469.696023592765187','test','test','1.99'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDAETH','4h','0.005917300000000','0.008283200000000','2.667472606733440','3.734001841396317','450.7921867631251','450.792186763125073','test','test','0.0'),('2018-12-07 15:59:59','2018-12-07 19:59:59','MDAETH','4h','0.007575600000000','0.007424088000000','2.904479103325190','2.846389521258686','383.39921634262504','383.399216342625039','test','test','2.00'),('2018-12-11 03:59:59','2018-12-20 19:59:59','MDAETH','4h','0.007458000000000','0.009143600000000','2.891570307310412','3.545100866441872','387.7139055122568','387.713905512256815','test','test','1.98'),('2019-01-10 11:59:59','2019-01-10 15:59:59','MDAETH','4h','0.005887700000000','0.005769946000000','3.036799320450736','2.976063334041721','515.7870340626622','515.787034062662201','test','test','2.00'),('2019-01-17 03:59:59','2019-01-20 15:59:59','MDAETH','4h','0.005848500000000','0.005899800000000','3.023302434582066','3.049821271017744','516.936382761745','516.936382761744994','test','test','0.0'),('2019-01-21 23:59:59','2019-01-31 03:59:59','MDAETH','4h','0.005962800000000','0.006341800000000','3.029195509345550','3.221733427444759','508.0156150374908','508.015615037490818','test','test','0.66'),('2019-01-31 15:59:59','2019-02-06 23:59:59','MDAETH','4h','0.006709000000000','0.006697800000000','3.071981713367597','3.066853349201594','457.8896576788786','457.889657678878621','test','test','1.31'),('2019-02-23 07:59:59','2019-02-23 15:59:59','MDAETH','4h','0.006221500000000','0.006097070000000','3.070842076886262','3.009425235348537','493.5854821001788','493.585482100178808','test','test','2.00'),('2019-02-24 23:59:59','2019-03-02 15:59:59','MDAETH','4h','0.006162200000000','0.006436200000000','3.057193889877879','3.193130913315376','496.1205234945116','496.120523494511588','test','test','0.04'),('2019-03-07 19:59:59','2019-03-08 03:59:59','MDAETH','4h','0.006495600000000','0.006365688000000','3.087402117308434','3.025654074962265','475.30668718954894','475.306687189548938','test','test','2.00'),('2019-03-08 07:59:59','2019-03-09 03:59:59','MDAETH','4h','0.006430000000000','0.006344300000000','3.073680330120396','3.032713859779600','478.0218242799994','478.021824279999407','test','test','1.33'),('2019-03-09 19:59:59','2019-03-09 23:59:59','MDAETH','4h','0.006945000000000','0.006806100000000','3.064576670044664','3.003285136643771','441.2637393872806','441.263739387280623','test','test','1.99'),('2019-03-10 03:59:59','2019-03-10 07:59:59','MDAETH','4h','0.007412900000000','0.007264642000000','3.050956329288910','2.989937202703132','411.57392239055025','411.573922390550251','test','test','2.00'),('2019-03-10 19:59:59','2019-03-12 19:59:59','MDAETH','4h','0.007617800000000','0.007465444000000','3.037396523380959','2.976648592913340','398.72358468074236','398.723584680742363','test','test','2.00'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDAETH','4h','0.008161400000000','0.007998172000000','3.023896983277044','2.963419043611503','370.51204245313846','370.512042453138463','test','test','1.99'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDAETH','4h','0.008747000000000','0.008572060000000','3.010457441129146','2.950248292306563','344.1702802251225','344.170280225122497','test','test','2.00'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDAETH','4h','0.008097200000000','0.007935256000000','2.997077630279683','2.937136077674089','370.13753276190323','370.137532761903230','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:07:13
