-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-10-13 23:59:59','2019-10-16 15:59:59','ATOMBTC','4h','0.000346700000000','0.000348400000000','0.033333333333333','0.033496779155850','96.14460148062686','96.144601480626861','test','test','0.11'),('2019-10-16 19:59:59','2019-10-18 11:59:59','ATOMBTC','4h','0.000350500000000','0.000353000000000','0.033369654627226','0.033607669282199','95.20586198923252','95.205861989232517','test','test','0.88'),('2019-10-18 15:59:59','2019-10-18 19:59:59','ATOMBTC','4h','0.000349600000000','0.000349700000000','0.033422546772776','0.033432106997825','95.60225049420924','95.602250494209244','test','test','0.0'),('2019-10-18 23:59:59','2019-10-19 03:59:59','ATOMBTC','4h','0.000344600000000','0.000345300000000','0.033424671267231','0.033492568161854','96.99556374704262','96.995563747042624','test','test','0.0'),('2019-10-19 11:59:59','2019-10-19 15:59:59','ATOMBTC','4h','0.000347100000000','0.000348400000000','0.033439759466036','0.033565002010853','96.34041908970326','96.340419089703261','test','test','0.0'),('2019-10-19 19:59:59','2019-10-19 23:59:59','ATOMBTC','4h','0.000346900000000','0.000345600000000','0.033467591142662','0.033342172092545','96.47619239741135','96.476192397411353','test','test','0.37'),('2019-10-20 19:59:59','2019-10-21 07:59:59','ATOMBTC','4h','0.000351700000000','0.000352500000000','0.033439720242636','0.033515784434260','95.08023952981517','95.080239529815174','test','test','0.31'),('2019-10-21 11:59:59','2019-10-23 03:59:59','ATOMBTC','4h','0.000352700000000','0.000352500000000','0.033456623396330','0.033437651679065','94.85858632359009','94.858586323590089','test','test','0.05'),('2019-10-23 07:59:59','2019-10-23 11:59:59','ATOMBTC','4h','0.000350500000000','0.000348800000000','0.033452407459160','0.033290156124836','95.44196136707623','95.441961367076232','test','test','0.48'),('2019-10-23 15:59:59','2019-10-23 19:59:59','ATOMBTC','4h','0.000353300000000','0.000356400000000','0.033416351607088','0.033709560466363','94.58350299204139','94.583502992041389','test','test','0.0'),('2019-10-23 23:59:59','2019-10-25 15:59:59','ATOMBTC','4h','0.000359700000000','0.000357600000000','0.033481509131372','0.033286037435025','93.08176016505854','93.081760165058540','test','test','0.58'),('2019-10-25 19:59:59','2019-10-25 23:59:59','ATOMBTC','4h','0.000356500000000','0.000351300000000','0.033438070976628','0.032950334737979','93.79543050947484','93.795430509474841','test','test','1.45'),('2019-10-31 15:59:59','2019-11-18 03:59:59','ATOMBTC','4h','0.000351500000000','0.000444300000000','0.033329685145817','0.042129101309492','94.82129486718888','94.821294867188882','test','test','0.34'),('2019-11-23 23:59:59','2019-11-24 03:59:59','ATOMBTC','4h','0.000440500000000','0.000432600000000','0.035285110959967','0.034652301932535','80.10240853567966','80.102408535679658','test','test','1.79'),('2019-11-24 07:59:59','2019-11-24 15:59:59','ATOMBTC','4h','0.000435700000000','0.000431400000000','0.035144486731649','0.034797639605310','80.6621224045184','80.662122404518399','test','test','0.98'),('2019-11-24 19:59:59','2019-12-04 03:59:59','ATOMBTC','4h','0.000452500000000','0.000484900000000','0.035067409592462','0.037578313616320','77.49703777339717','77.497037773397167','test','test','1.10'),('2019-12-04 11:59:59','2019-12-04 15:59:59','ATOMBTC','4h','0.000491200000000','0.000494400000000','0.035625388264431','0.035857475484395','72.52725623866176','72.527256238661764','test','test','0.0'),('2019-12-04 19:59:59','2019-12-05 03:59:59','ATOMBTC','4h','0.000495000000000','0.000488400000000','0.035676963202200','0.035201270359504','72.07467313575847','72.074673135758474','test','test','1.33'),('2019-12-06 15:59:59','2019-12-06 19:59:59','ATOMBTC','4h','0.000492700000000','0.000490400000000','0.035571253681601','0.035405201553597','72.19657739314255','72.196577393142547','test','test','0.46'),('2019-12-06 23:59:59','2019-12-07 03:59:59','ATOMBTC','4h','0.000486400000000','0.000499500000000','0.035534353208712','0.036491384514292','73.05582485343658','73.055824853436576','test','test','0.0'),('2019-12-07 07:59:59','2019-12-09 23:59:59','ATOMBTC','4h','0.000499300000000','0.000499300000000','0.035747026832174','0.035747026832174','71.59428566427754','71.594285664277535','test','test','0.0'),('2019-12-10 03:59:59','2019-12-10 07:59:59','ATOMBTC','4h','0.000500500000000','0.000505800000000','0.035747026832174','0.036125566776651','71.42263103331425','71.422631033314246','test','test','0.0'),('2019-12-10 11:59:59','2019-12-10 15:59:59','ATOMBTC','4h','0.000497000000000','0.000487900000000','0.035831146819835','0.035175083568204','72.09486281657009','72.094862816570085','test','test','1.83'),('2019-12-11 07:59:59','2019-12-17 11:59:59','ATOMBTC','4h','0.000506100000000','0.000548600000000','0.035685354986140','0.038682050474998','70.51048209077169','70.510482090771688','test','test','0.29'),('2019-12-18 03:59:59','2019-12-21 19:59:59','ATOMBTC','4h','0.000563400000000','0.000571000000000','0.036351287316997','0.036841649020244','64.52127674298347','64.521276742983474','test','test','0.0'),('2019-12-21 23:59:59','2019-12-22 03:59:59','ATOMBTC','4h','0.000568400000000','0.000583000000000','0.036460256584385','0.037396779712696','64.1454197473348','64.145419747334799','test','test','0.0'),('2019-12-22 07:59:59','2019-12-22 15:59:59','ATOMBTC','4h','0.000580000000000','0.000571100000000','0.036668372835121','0.036105702976099','63.221332474346355','63.221332474346355','test','test','1.53'),('2019-12-23 19:59:59','2019-12-29 03:59:59','ATOMBTC','4h','0.000580700000000','0.000597800000000','0.036543335088672','0.037619434675406','62.92980039378605','62.929800393786053','test','test','0.0'),('2019-12-29 07:59:59','2019-12-29 15:59:59','ATOMBTC','4h','0.000606000000000','0.000593880000000','0.036782468330168','0.036046818963565','60.6971424590231','60.697142459023098','test','test','2.00'),('2020-01-01 03:59:59','2020-01-01 07:59:59','ATOMBTC','4h','0.000597100000000','0.000601300000000','0.036618990693145','0.036876568587821','61.32807016102011','61.328070161020108','test','test','0.0'),('2020-01-01 11:59:59','2020-01-02 03:59:59','ATOMBTC','4h','0.000602700000000','0.000595500000000','0.036676230225295','0.036238087106625','60.853210926323776','60.853210926323776','test','test','1.19'),('2020-01-02 07:59:59','2020-01-02 11:59:59','ATOMBTC','4h','0.000593500000000','0.000597500000000','0.036578865087813','0.036825394928337','61.63246013110887','61.632460131108871','test','test','0.0'),('2020-01-02 19:59:59','2020-01-02 23:59:59','ATOMBTC','4h','0.000596600000000','0.000588500000000','0.036633649496818','0.036136276783234','61.40403871407718','61.404038714077181','test','test','1.35'),('2020-01-16 23:59:59','2020-01-17 03:59:59','ATOMBTC','4h','0.000584300000000','0.000572614000000','0.036523122227133','0.035792659782590','62.50748284636848','62.507482846368482','test','test','2.00'),('2020-01-17 07:59:59','2020-01-18 03:59:59','ATOMBTC','4h','0.000559100000000','0.000547918000000','0.036360797239457','0.035633581294668','65.03451482642977','65.034514826429771','test','test','1.99'),('2020-01-18 07:59:59','2020-01-18 11:59:59','ATOMBTC','4h','0.000532200000000','0.000535200000000','0.036199193696170','0.036403247775630','68.0180264866036','68.018026486603603','test','test','0.0'),('2020-01-21 19:59:59','2020-01-22 03:59:59','ATOMBTC','4h','0.000537700000000','0.000529300000000','0.036244539047162','0.035678323447392','67.40661902020003','67.406619020200026','test','test','1.56'),('2020-01-22 07:59:59','2020-01-22 11:59:59','ATOMBTC','4h','0.000532500000000','0.000532700000000','0.036118713358324','0.036132279072261','67.828569686993','67.828569686993006','test','test','0.0'),('2020-01-22 15:59:59','2020-01-22 19:59:59','ATOMBTC','4h','0.000531800000000','0.000530800000000','0.036121727961421','0.036053804441373','67.92352004780159','67.923520047801588','test','test','0.18'),('2020-01-22 23:59:59','2020-01-23 03:59:59','ATOMBTC','4h','0.000536500000000','0.000534000000000','0.036106633845855','0.035938382989164','67.30034267633674','67.300342676336740','test','test','0.46'),('2020-01-23 19:59:59','2020-01-23 23:59:59','ATOMBTC','4h','0.000532300000000','0.000529500000000','0.036069244766590','0.035879513627483','67.76112110950592','67.761121109505922','test','test','0.52'),('2020-01-24 07:59:59','2020-01-24 11:59:59','ATOMBTC','4h','0.000533800000000','0.000532100000000','0.036027082291233','0.035912346360369','67.49172403752881','67.491724037528812','test','test','0.31'),('2020-01-24 15:59:59','2020-01-24 19:59:59','ATOMBTC','4h','0.000531000000000','0.000528400000000','0.036001585417708','0.035825306468393','67.7995958902214','67.799595890221397','test','test','0.48'),('2020-01-25 03:59:59','2020-01-25 07:59:59','ATOMBTC','4h','0.000531600000000','0.000530800000000','0.035962412317860','0.035908292810986','67.64938359266323','67.649383592663227','test','test','0.15'),('2020-02-07 15:59:59','2020-02-08 03:59:59','ATOMBTC','4h','0.000498900000000','0.000488922000000','0.035950385760777','0.035231378045561','72.05930198592237','72.059301985922374','test','test','2.00'),('2020-02-08 07:59:59','2020-02-08 19:59:59','ATOMBTC','4h','0.000480300000000','0.000477300000000','0.035790606268506','0.035567054699059','74.51718981575357','74.517189815753568','test','test','0.62'),('2020-02-10 15:59:59','2020-02-10 19:59:59','ATOMBTC','4h','0.000481000000000','0.000476800000000','0.035740928141963','0.035428845193530','74.3054639126043','74.305463912604296','test','test','0.87'),('2020-02-10 23:59:59','2020-02-13 11:59:59','ATOMBTC','4h','0.000484300000000','0.000485000000000','0.035671576375644','0.035723135540341','73.65594956771469','73.655949567714686','test','test','0.16'),('2020-02-13 15:59:59','2020-02-13 19:59:59','ATOMBTC','4h','0.000484300000000','0.000479500000000','0.035683033967799','0.035329371851248','73.6796076146998','73.679607614699805','test','test','0.99'),('2020-02-14 07:59:59','2020-02-14 11:59:59','ATOMBTC','4h','0.000485100000000','0.000484200000000','0.035604442386343','0.035538385906962','73.3960882010788','73.396088201078797','test','test','0.18'),('2020-02-14 15:59:59','2020-02-15 19:59:59','ATOMBTC','4h','0.000491700000000','0.000481866000000','0.035589763168703','0.034877967905329','72.38105179724042','72.381051797240417','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:11:39
