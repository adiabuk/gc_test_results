-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 23:59:59','2018-07-02 03:59:59','VIBEBTC','4h','0.000012480000000','0.000012870000000','0.033333333333333','0.034375000000000','2670.940170940171','2670.940170940170901','test','test','0.0'),('2018-07-02 15:59:59','2018-07-03 11:59:59','VIBEBTC','4h','0.000012860000000','0.000012602800000','0.033564814814815','0.032893518518519','2610.0167041069117','2610.016704106911675','test','test','1.99'),('2018-07-03 19:59:59','2018-07-03 23:59:59','VIBEBTC','4h','0.000012750000000','0.000012495000000','0.033415637860082','0.032747325102880','2620.83434196725','2620.834341967250111','test','test','2.00'),('2018-07-04 15:59:59','2018-07-05 03:59:59','VIBEBTC','4h','0.000012750000000','0.000012800000000','0.033267123914038','0.033397583223505','2609.186189336279','2609.186189336278858','test','test','0.31'),('2018-07-07 03:59:59','2018-07-07 07:59:59','VIBEBTC','4h','0.000012500000000','0.000012250000000','0.033296114871697','0.032630192574263','2663.689189735751','2663.689189735750915','test','test','2.00'),('2018-07-18 03:59:59','2018-07-18 07:59:59','VIBEBTC','4h','0.000011510000000','0.000011510000000','0.033148132138934','0.033148132138934','2879.9419755806925','2879.941975580692542','test','test','0.0'),('2018-07-18 11:59:59','2018-07-18 15:59:59','VIBEBTC','4h','0.000011730000000','0.000011495400000','0.033148132138934','0.032485169496155','2825.9277185791793','2825.927718579179327','test','test','1.99'),('2018-08-27 19:59:59','2018-08-27 23:59:59','VIBEBTC','4h','0.000004920000000','0.000004900000000','0.033000807107205','0.032866657484818','6707.481119350632','6707.481119350632071','test','test','0.40'),('2018-08-28 07:59:59','2018-08-30 11:59:59','VIBEBTC','4h','0.000005200000000','0.000005096000000','0.032970996080008','0.032311576158408','6340.576169232307','6340.576169232306711','test','test','2.00'),('2018-09-01 03:59:59','2018-09-01 07:59:59','VIBEBTC','4h','0.000005610000000','0.000005497800000','0.032824458319652','0.032167969153259','5851.062089064606','5851.062089064605971','test','test','2.00'),('2018-09-01 15:59:59','2018-09-02 11:59:59','VIBEBTC','4h','0.000005570000000','0.000005458600000','0.032678571838232','0.032025000401467','5866.889019431198','5866.889019431197994','test','test','2.00'),('2018-09-04 19:59:59','2018-09-05 11:59:59','VIBEBTC','4h','0.000005320000000','0.000005213600000','0.032533333741173','0.031882667066350','6115.288297212948','6115.288297212948237','test','test','2.00'),('2018-09-10 07:59:59','2018-09-10 11:59:59','VIBEBTC','4h','0.000005280000000','0.000005174400000','0.032388741146768','0.031740966323833','6134.231277796927','6134.231277796927316','test','test','2.00'),('2018-09-14 07:59:59','2018-09-14 11:59:59','VIBEBTC','4h','0.000004830000000','0.000004733400000','0.032244791186116','0.031599895362394','6675.940204164709','6675.940204164709030','test','test','2.00'),('2018-09-15 03:59:59','2018-09-28 07:59:59','VIBEBTC','4h','0.000004990000000','0.000011880000000','0.032101481003066','0.076425970804895','6433.162525664574','6433.162525664573877','test','test','0.20'),('2018-09-30 07:59:59','2018-09-30 15:59:59','VIBEBTC','4h','0.000012600000000','0.000012348000000','0.041951367625695','0.041112340273181','3329.4736210868955','3329.473621086895491','test','test','2.00'),('2018-09-30 19:59:59','2018-09-30 23:59:59','VIBEBTC','4h','0.000011920000000','0.000011750000000','0.041764917102914','0.041169276506648','3503.768213331711','3503.768213331711195','test','test','1.42'),('2018-10-01 03:59:59','2018-10-01 07:59:59','VIBEBTC','4h','0.000012360000000','0.000012112800000','0.041632552525966','0.040799901475447','3368.3294923920707','3368.329492392070733','test','test','1.99'),('2018-10-07 11:59:59','2018-10-07 15:59:59','VIBEBTC','4h','0.000012290000000','0.000012044200000','0.041447518959184','0.040618568580000','3372.458824994629','3372.458824994629140','test','test','2.00'),('2018-10-07 19:59:59','2018-10-08 11:59:59','VIBEBTC','4h','0.000011980000000','0.000011740400000','0.041263307763810','0.040438041608534','3444.349562922351','3444.349562922351197','test','test','2.00'),('2018-10-10 11:59:59','2018-10-10 15:59:59','VIBEBTC','4h','0.000012600000000','0.000012348000000','0.041079915284860','0.040258316979163','3260.3107368936153','3260.310736893615285','test','test','2.00'),('2018-10-14 15:59:59','2018-10-14 19:59:59','VIBEBTC','4h','0.000011430000000','0.000011201400000','0.040897337883594','0.040079391125922','3578.0698060886743','3578.069806088674341','test','test','1.99'),('2018-10-17 11:59:59','2018-10-17 15:59:59','VIBEBTC','4h','0.000011270000000','0.000011150000000','0.040715571937444','0.040282043221162','3612.7393023464256','3612.739302346425575','test','test','1.06'),('2018-10-18 11:59:59','2018-10-18 15:59:59','VIBEBTC','4h','0.000011480000000','0.000011250400000','0.040619232222715','0.039806847578261','3538.260646577952','3538.260646577951775','test','test','2.00'),('2018-10-20 11:59:59','2018-10-20 15:59:59','VIBEBTC','4h','0.000011240000000','0.000011370000000','0.040438702301725','0.040906409712688','3597.749315100098','3597.749315100098102','test','test','0.0'),('2018-10-20 19:59:59','2018-10-20 23:59:59','VIBEBTC','4h','0.000011940000000','0.000011701200000','0.040542637281939','0.039731784536300','3395.5307606314163','3395.530760631416342','test','test','2.00'),('2018-10-21 07:59:59','2018-10-21 11:59:59','VIBEBTC','4h','0.000012220000000','0.000011975600000','0.040362447782908','0.039555198827250','3302.9826336258775','3302.982633625877497','test','test','2.00'),('2018-10-24 11:59:59','2018-10-25 11:59:59','VIBEBTC','4h','0.000012000000000','0.000011760000000','0.040183059126095','0.039379397943573','3348.588260507944','3348.588260507944142','test','test','1.99'),('2018-11-27 19:59:59','2018-11-27 23:59:59','VIBEBTC','4h','0.000007530000000','0.000007379400000','0.040004467752202','0.039204378397158','5312.678320345492','5312.678320345491557','test','test','1.99'),('2018-11-28 03:59:59','2018-11-28 07:59:59','VIBEBTC','4h','0.000007100000000','0.000006980000000','0.039826670117747','0.039153543298856','5609.390157429202','5609.390157429202191','test','test','1.69'),('2018-11-28 15:59:59','2018-11-28 19:59:59','VIBEBTC','4h','0.000007120000000','0.000007280000000','0.039677086380216','0.040568706298873','5572.624491603371','5572.624491603371098','test','test','0.0'),('2018-11-29 07:59:59','2018-11-29 11:59:59','VIBEBTC','4h','0.000007350000000','0.000007203000000','0.039875224139918','0.039077719657120','5425.200563254089','5425.200563254088593','test','test','2.00'),('2018-11-29 15:59:59','2018-11-29 23:59:59','VIBEBTC','4h','0.000007520000000','0.000007369600000','0.039698000921518','0.038904040903088','5278.989484244415','5278.989484244414598','test','test','2.00'),('2018-12-01 15:59:59','2018-12-04 07:59:59','VIBEBTC','4h','0.000007740000000','0.000007620000000','0.039521565361867','0.038908827914396','5106.145395590037','5106.145395590036969','test','test','1.67'),('2018-12-17 23:59:59','2018-12-25 07:59:59','VIBEBTC','4h','0.000006870000000','0.000007180000000','0.039385401484651','0.041162617563289','5732.955092380073','5732.955092380073438','test','test','0.0'),('2018-12-27 23:59:59','2018-12-28 03:59:59','VIBEBTC','4h','0.000007310000000','0.000007320000000','0.039780338391015','0.039834757458581','5441.906756636814','5441.906756636813952','test','test','0.0'),('2018-12-28 07:59:59','2018-12-29 23:59:59','VIBEBTC','4h','0.000007650000000','0.000007497000000','0.039792431517141','0.038996582886798','5201.625034920377','5201.625034920377402','test','test','2.00'),('2019-01-03 03:59:59','2019-01-03 11:59:59','VIBEBTC','4h','0.000007600000000','0.000007448000000','0.039615576265954','0.038823264740635','5212.5758244675735','5212.575824467573511','test','test','2.00'),('2019-01-04 07:59:59','2019-01-07 11:59:59','VIBEBTC','4h','0.000007740000000','0.000007820000000','0.039439507038105','0.039847150521703','5095.543544974791','5095.543544974791075','test','test','0.0'),('2019-01-08 15:59:59','2019-01-09 15:59:59','VIBEBTC','4h','0.000008530000000','0.000008359400000','0.039530094478904','0.038739492589326','4634.243197995832','4634.243197995831906','test','test','1.99'),('2019-01-11 19:59:59','2019-01-11 23:59:59','VIBEBTC','4h','0.000008140000000','0.000007977200000','0.039354405170109','0.038567317066707','4834.6935098414415','4834.693509841441482','test','test','1.99'),('2019-01-14 15:59:59','2019-01-27 11:59:59','VIBEBTC','4h','0.000009810000000','0.000011120000000','0.039179496702687','0.044411417261354','3993.83248753177','3993.832487531769857','test','test','0.0'),('2019-02-03 03:59:59','2019-02-03 07:59:59','VIBEBTC','4h','0.000010750000000','0.000010535000000','0.040342145715724','0.039535302801410','3752.75774099756','3752.757740997560177','test','test','2.00'),('2019-02-11 19:59:59','2019-02-12 03:59:59','VIBEBTC','4h','0.000010080000000','0.000010340000000','0.040162847290321','0.041198793748206','3984.4094534048277','3984.409453404827673','test','test','0.0'),('2019-02-12 15:59:59','2019-02-13 07:59:59','VIBEBTC','4h','0.000010150000000','0.000010050000000','0.040393057614295','0.039995096455533','3979.611587615282','3979.611587615282133','test','test','0.98'),('2019-02-17 15:59:59','2019-02-18 03:59:59','VIBEBTC','4h','0.000010150000000','0.000009947000000','0.040304621801237','0.039498529365212','3970.89869962925','3970.898699629250132','test','test','1.99'),('2019-02-19 19:59:59','2019-02-19 23:59:59','VIBEBTC','4h','0.000010140000000','0.000009950000000','0.040125490148787','0.039373631852113','3957.1489298606407','3957.148929860640692','test','test','1.87'),('2019-02-20 15:59:59','2019-02-20 19:59:59','VIBEBTC','4h','0.000010230000000','0.000010025400000','0.039958410527304','0.039159242316758','3906.0029840961656','3906.002984096165619','test','test','1.99'),('2019-02-23 15:59:59','2019-02-23 19:59:59','VIBEBTC','4h','0.000009950000000','0.000009751000000','0.039780817591627','0.038985201239794','3998.0721197614957','3998.072119761495742','test','test','2.00'),('2019-02-26 19:59:59','2019-02-26 23:59:59','VIBEBTC','4h','0.000009880000000','0.000009770000000','0.039604013957886','0.039163078579812','4008.503437033018','4008.503437033018145','test','test','1.11'),('2019-02-28 03:59:59','2019-02-28 07:59:59','VIBEBTC','4h','0.000009810000000','0.000009660000000','0.039506028318314','0.038901960607025','4027.118075261388','4027.118075261388185','test','test','1.52'),('2019-03-02 15:59:59','2019-03-02 19:59:59','VIBEBTC','4h','0.000010190000000','0.000009986200000','0.039371791049139','0.038584355228156','3863.7675219959647','3863.767521995964671','test','test','1.99'),('2019-03-03 03:59:59','2019-03-03 07:59:59','VIBEBTC','4h','0.000010460000000','0.000010250800000','0.039196805311143','0.038412869204920','3747.304523053792','3747.304523053791854','test','test','1.99'),('2019-03-05 15:59:59','2019-03-07 03:59:59','VIBEBTC','4h','0.000010110000000','0.000010030000000','0.039022597287538','0.038713813134917','3859.8019077683043','3859.801907768304318','test','test','0.79'),('2019-03-08 15:59:59','2019-03-08 23:59:59','VIBEBTC','4h','0.000010130000000','0.000009927400000','0.038953978586955','0.038174899015216','3845.407560410179','3845.407560410179030','test','test','2.00'),('2019-03-10 11:59:59','2019-03-11 15:59:59','VIBEBTC','4h','0.000010310000000','0.000010380000000','0.038780849793235','0.039044153332083','3761.479126404979','3761.479126404979070','test','test','0.0'),('2019-03-12 11:59:59','2019-03-13 11:59:59','VIBEBTC','4h','0.000010690000000','0.000010640000000','0.038839361690757','0.038657699568724','3633.242440669515','3633.242440669514963','test','test','0.46'),('2019-03-15 15:59:59','2019-03-15 19:59:59','VIBEBTC','4h','0.000011360000000','0.000011132800000','0.038798992330305','0.038023012483699','3415.4042544282865','3415.404254428286549','test','test','2.00'),('2019-03-17 11:59:59','2019-03-17 15:59:59','VIBEBTC','4h','0.000011300000000','0.000011074000000','0.038626552364393','0.037854021317105','3418.2789703002554','3418.278970300255423','test','test','2.00'),('2019-03-18 11:59:59','2019-03-21 15:59:59','VIBEBTC','4h','0.000011110000000','0.000010887800000','0.038454878798329','0.037685781222362','3461.285220371637','3461.285220371637024','test','test','2.00'),('2019-03-26 15:59:59','2019-03-26 19:59:59','VIBEBTC','4h','0.000010900000000','0.000011170000000','0.038283968225892','0.039232286704882','3512.2906629258505','3512.290662925850484','test','test','0.0'),('2019-03-27 11:59:59','2019-03-30 07:59:59','VIBEBTC','4h','0.000011580000000','0.000011348400000','0.038494705665667','0.037724811552354','3324.2405583477835','3324.240558347783463','test','test','1.99'),('2019-03-31 07:59:59','2019-04-02 03:59:59','VIBEBTC','4h','0.000011880000000','0.000011642400000','0.038323618084931','0.037557145723232','3225.8937781928544','3225.893778192854370','test','test','2.00'),('2019-05-06 11:59:59','2019-05-06 23:59:59','VIBEBTC','4h','0.000007120000000','0.000007060000000','0.038153290893442','0.037831774397149','5358.608271550905','5358.608271550904647','test','test','0.84'),('2019-05-16 07:59:59','2019-05-16 11:59:59','VIBEBTC','4h','0.000006150000000','0.000006027000000','0.038081842783155','0.037320205927492','6192.169558236603','6192.169558236602825','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','VIBEBTC','4h','0.000005810000000','0.000005693800000','0.037912590148563','0.037154338345592','6525.402779442914','6525.402779442913925','test','test','1.99'),('2019-05-21 19:59:59','2019-05-21 23:59:59','VIBEBTC','4h','0.000005500000000','0.000005680000000','0.037744089747903','0.038979350866925','6862.56177234602','6862.561772346020007','test','test','0.0'),('2019-05-22 15:59:59','2019-05-22 23:59:59','VIBEBTC','4h','0.000005930000000','0.000005811400000','0.038018592218797','0.037258220374421','6411.229716491886','6411.229716491886393','test','test','2.00'),('2019-05-23 07:59:59','2019-05-24 15:59:59','VIBEBTC','4h','0.000006080000000','0.000005958400000','0.037849620697824','0.037092628283868','6225.266562142178','6225.266562142178373','test','test','1.99'),('2019-05-28 11:59:59','2019-05-28 15:59:59','VIBEBTC','4h','0.000005760000000','0.000005660000000','0.037681400161390','0.037027209186366','6541.9097502412815','6541.909750241281472','test','test','1.73'),('2019-05-29 19:59:59','2019-05-30 15:59:59','VIBEBTC','4h','0.000005940000000','0.000005821200000','0.037536024389162','0.036785303901379','6319.196025111486','6319.196025111486051','test','test','2.00'),('2019-05-30 19:59:59','2019-05-30 23:59:59','VIBEBTC','4h','0.000005800000000','0.000005684000000','0.037369197614099','0.036621813661817','6442.965105879194','6442.965105879194198','test','test','2.00'),('2019-05-31 19:59:59','2019-06-01 03:59:59','VIBEBTC','4h','0.000005990000000','0.000005870200000','0.037203112291370','0.036459050045543','6210.870165504173','6210.870165504173201','test','test','2.00'),('2019-06-03 11:59:59','2019-06-04 03:59:59','VIBEBTC','4h','0.000005950000000','0.000005831000000','0.037037765125631','0.036297009823118','6224.834474895909','6224.834474895908897','test','test','2.00'),('2019-06-07 11:59:59','2019-06-09 15:59:59','VIBEBTC','4h','0.000005910000000','0.000005930000000','0.036873152836183','0.036997935079283','6239.11215502256','6239.112155022559818','test','test','0.16'),('2019-06-10 07:59:59','2019-06-12 15:59:59','VIBEBTC','4h','0.000006000000000','0.000006010000000','0.036900882223539','0.036962383693912','6150.147037256481','6150.147037256480871','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:09:48
