-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 15:59:59','2018-04-28 19:59:59','DLTETH','4h','0.000423680000000','0.000421320000000','1.297777777777778','1.290548841893253','3063.1084256461895','3063.108425646189517','test','test','0.55'),('2018-04-29 07:59:59','2018-04-29 11:59:59','DLTETH','4h','0.000422050000000','0.000413609000000','1.296171347581217','1.270247920629593','3071.132206092209','3071.132206092208889','test','test','1.99'),('2018-04-29 15:59:59','2018-04-29 19:59:59','DLTETH','4h','0.000419160000000','0.000430070000000','1.290410586036411','1.323997711462638','3078.563283797145','3078.563283797144777','test','test','0.0'),('2018-04-29 23:59:59','2018-04-30 03:59:59','DLTETH','4h','0.000433500000000','0.000424830000000','1.297874391686684','1.271916903852950','2993.943233417956','2993.943233417955980','test','test','2.00'),('2018-04-30 19:59:59','2018-05-01 03:59:59','DLTETH','4h','0.000460010000000','0.000450809800000','1.292106061056965','1.266263939835826','2808.8651574030246','2808.865157403024568','test','test','2.00'),('2018-05-01 11:59:59','2018-05-03 15:59:59','DLTETH','4h','0.000455190000000','0.000446086200000','1.286363367452268','1.260636100103223','2825.992151524128','2825.992151524128076','test','test','1.99'),('2018-05-13 23:59:59','2018-05-15 07:59:59','DLTETH','4h','0.000402820000000','0.000394763600000','1.280646196930258','1.255033272991653','3179.202117397988','3179.202117397987877','test','test','2.00'),('2018-05-31 23:59:59','2018-06-01 03:59:59','DLTETH','4h','0.000359990000000','0.000352790200000','1.274954436055012','1.249455347333912','3541.638478999451','3541.638478999450854','test','test','1.99'),('2018-07-01 23:59:59','2018-07-06 07:59:59','DLTETH','4h','0.000200310000000','0.000207660000000','1.269287971894768','1.315862114940180','6336.618101416642','6336.618101416642276','test','test','0.0'),('2018-07-08 07:59:59','2018-07-09 03:59:59','DLTETH','4h','0.000220800000000','0.000216384000000','1.279637781460415','1.254045025831207','5795.460966759126','5795.460966759125768','test','test','2.00'),('2018-07-17 19:59:59','2018-07-19 03:59:59','DLTETH','4h','0.000203180000000','0.000199116400000','1.273950502431702','1.248471492383068','6270.058580724983','6270.058580724982676','test','test','1.99'),('2018-07-19 07:59:59','2018-07-20 07:59:59','DLTETH','4h','0.000200710000000','0.000196695800000','1.268288500198672','1.242922730194698','6319.010015438554','6319.010015438553637','test','test','2.00'),('2018-07-23 15:59:59','2018-07-23 19:59:59','DLTETH','4h','0.000200100000000','0.000196098000000','1.262651662420011','1.237398629171611','6310.10326046982','6310.103260469820270','test','test','1.99'),('2018-07-30 07:59:59','2018-07-30 11:59:59','DLTETH','4h','0.000190390000000','0.000192350000000','1.257039877253700','1.269980673300852','6602.446962832608','6602.446962832607824','test','test','0.0'),('2018-08-13 19:59:59','2018-08-14 03:59:59','DLTETH','4h','0.000148830000000','0.000145853400000','1.259915609708623','1.234717297514450','8465.468048838426','8465.468048838425602','test','test','2.00'),('2018-08-17 15:59:59','2018-08-17 19:59:59','DLTETH','4h','0.000144550000000','0.000144260000000','1.254315984776584','1.251799543160637','8677.384882577548','8677.384882577547614','test','test','0.20'),('2018-08-20 11:59:59','2018-08-21 03:59:59','DLTETH','4h','0.000150560000000','0.000147548800000','1.253756775528596','1.228681640018024','8327.289954361027','8327.289954361027412','test','test','1.99'),('2018-08-21 11:59:59','2018-08-21 19:59:59','DLTETH','4h','0.000145380000000','0.000143790000000','1.248184523192913','1.234533309876936','8585.668752186775','8585.668752186775237','test','test','1.09'),('2018-08-22 11:59:59','2018-08-22 15:59:59','DLTETH','4h','0.000153230000000','0.000150165400000','1.245150920233807','1.220247901829131','8126.025714506346','8126.025714506346048','test','test','2.00'),('2018-08-23 11:59:59','2018-08-30 15:59:59','DLTETH','4h','0.000146870000000','0.000162000000000','1.239616916143879','1.367317630661867','8440.232288036219','8440.232288036218961','test','test','0.0'),('2018-08-31 07:59:59','2018-09-01 07:59:59','DLTETH','4h','0.000167160000000','0.000163816800000','1.267994852703432','1.242634955649363','7585.5159888934695','7585.515988893469512','test','test','2.00'),('2018-09-01 11:59:59','2018-09-01 15:59:59','DLTETH','4h','0.000172500000000','0.000169050000000','1.262359320024750','1.237112133624255','7318.025043621742','7318.025043621742043','test','test','2.00'),('2018-09-01 19:59:59','2018-09-02 03:59:59','DLTETH','4h','0.000170150000000','0.000166747000000','1.256748834157974','1.231613857474815','7386.123033546715','7386.123033546715305','test','test','1.99'),('2018-09-02 15:59:59','2018-09-06 03:59:59','DLTETH','4h','0.000172280000000','0.000168834400000','1.251163283783938','1.226140018108259','7262.382654887035','7262.382654887034732','test','test','1.99'),('2018-09-07 19:59:59','2018-09-07 23:59:59','DLTETH','4h','0.000170310000000','0.000169470000000','1.245602558078232','1.239459018950843','7313.737056416136','7313.737056416135601','test','test','0.49'),('2018-09-08 19:59:59','2018-09-12 11:59:59','DLTETH','4h','0.000173190000000','0.000175460000000','1.244237327161034','1.260545536253104','7184.233080206908','7184.233080206908198','test','test','0.0'),('2018-09-16 03:59:59','2018-09-19 07:59:59','DLTETH','4h','0.000182150000000','0.000189040000000','1.247861373625939','1.295062937525377','6850.7349636340305','6850.734963634030464','test','test','0.0'),('2018-09-20 15:59:59','2018-09-20 23:59:59','DLTETH','4h','0.000213590000000','0.000209318200000','1.258350610048036','1.233183597847075','5891.430357451362','5891.430357451362397','test','test','2.00'),('2018-09-22 07:59:59','2018-10-06 23:59:59','DLTETH','4h','0.000201350000000','0.000295720000000','1.252757940670045','1.839908508641399','6221.792603278096','6221.792603278096067','test','test','0.82'),('2018-10-07 03:59:59','2018-10-07 07:59:59','DLTETH','4h','0.000329690000000','0.000323096200000','1.383235844663679','1.355571127770405','4195.565060097908','4195.565060097907917','test','test','1.99'),('2018-10-07 19:59:59','2018-10-08 15:59:59','DLTETH','4h','0.000308750000000','0.000302575000000','1.377088129798507','1.349546367202537','4460.204468983018','4460.204468983018160','test','test','2.00'),('2018-10-08 19:59:59','2018-10-09 19:59:59','DLTETH','4h','0.000305050000000','0.000298949000000','1.370967738110514','1.343548383348304','4494.239429963985','4494.239429963984549','test','test','2.00'),('2018-10-10 11:59:59','2018-10-15 07:59:59','DLTETH','4h','0.000410000000000','0.000401800000000','1.364874548163356','1.337577057200089','3328.9623125935514','3328.962312593551360','test','test','1.99'),('2018-10-16 07:59:59','2018-10-22 03:59:59','DLTETH','4h','0.000418170000000','0.000435980000000','1.358808439060408','1.416680544423456','3249.4163595198306','3249.416359519830621','test','test','0.0'),('2018-10-22 19:59:59','2018-10-26 23:59:59','DLTETH','4h','0.000451610000000','0.000454420000000','1.371668906918863','1.380203681676822','3037.286390732851','3037.286390732851032','test','test','1.09'),('2018-10-27 07:59:59','2018-10-27 15:59:59','DLTETH','4h','0.000475370000000','0.000465862600000','1.373565523531743','1.346094213061108','2889.466149592407','2889.466149592406964','test','test','1.99'),('2018-10-28 15:59:59','2018-10-28 19:59:59','DLTETH','4h','0.000483570000000','0.000473898600000','1.367460787871601','1.340111572114169','2827.844547576569','2827.844547576568857','test','test','2.00'),('2018-10-30 15:59:59','2018-10-30 19:59:59','DLTETH','4h','0.000465500000000','0.000461920000000','1.361383184369950','1.350913255691015','2924.561083501503','2924.561083501503163','test','test','0.76'),('2018-10-30 23:59:59','2018-10-31 23:59:59','DLTETH','4h','0.000521990000000','0.000511550200000','1.359056533552409','1.331875402881361','2603.6064552049065','2603.606455204906524','test','test','2.00'),('2018-11-28 07:59:59','2018-12-05 23:59:59','DLTETH','4h','0.000356500000000','0.000376320000000','1.353016282292176','1.428238674199696','3795.277089178614','3795.277089178614006','test','test','0.0'),('2018-12-19 15:59:59','2018-12-19 19:59:59','DLTETH','4h','0.000355990000000','0.000356480000000','1.369732369382736','1.371617728131570','3847.6709159884713','3847.670915988471279','test','test','0.0'),('2018-12-20 11:59:59','2018-12-20 15:59:59','DLTETH','4h','0.000376780000000','0.000369244400000','1.370151337993588','1.342748311233716','3636.4757630277295','3636.475763027729499','test','test','2.00'),('2019-01-01 03:59:59','2019-01-01 07:59:59','DLTETH','4h','0.000301060000000','0.000296400000000','1.364061776491394','1.342947952408321','4530.863537140086','4530.863537140086009','test','test','1.54'),('2019-01-01 23:59:59','2019-01-05 03:59:59','DLTETH','4h','0.000295300000000','0.000308540000000','1.359369815584045','1.420318194718257','4603.351898354367','4603.351898354367222','test','test','0.0'),('2019-01-07 15:59:59','2019-01-28 07:59:59','DLTETH','4h','0.000350440000000','0.001133500000000','1.372913899836092','4.440697139208453','3917.6860513528472','3917.686051352847244','test','test','0.0'),('2019-01-28 15:59:59','2019-01-29 23:59:59','DLTETH','4h','0.001159220000000','0.001136035600000','2.054643508585505','2.013550638413795','1772.436214511055','1772.436214511054914','test','test','2.00'),('2019-02-01 19:59:59','2019-02-01 23:59:59','DLTETH','4h','0.001092900000000','0.001085690000000','2.045511759658459','2.032017258983981','1871.636709359007','1871.636709359007000','test','test','0.65'),('2019-02-02 07:59:59','2019-02-02 15:59:59','DLTETH','4h','0.001231970000000','0.001207330600000','2.042512981730797','2.001662722096181','1657.9242852754508','1657.924285275450757','test','test','2.00'),('2019-02-03 11:59:59','2019-02-03 15:59:59','DLTETH','4h','0.001164100000000','0.001140818000000','2.033435146256438','1.992766443331309','1746.7873432320575','1746.787343232057538','test','test','2.00'),('2019-02-20 11:59:59','2019-02-20 15:59:59','DLTETH','4h','0.000822440000000','0.000805991200000','2.024397656717520','1.983909703583169','2461.453305672779','2461.453305672779152','test','test','2.00'),('2019-03-02 19:59:59','2019-03-02 23:59:59','DLTETH','4h','0.000726550000000','0.000732570000000','2.015400333798775','2.032099404763566','2773.932053951931','2773.932053951930811','test','test','0.0'),('2019-03-03 23:59:59','2019-03-04 07:59:59','DLTETH','4h','0.000726790000000','0.000738290000000','2.019111238457618','2.051059640667696','2778.1219313111324','2778.121931311132357','test','test','0.0'),('2019-03-04 19:59:59','2019-03-05 03:59:59','DLTETH','4h','0.000734000000000','0.000719320000000','2.026210883393191','1.985686665725327','2760.505290726419','2760.505290726418934','test','test','1.99'),('2019-03-05 15:59:59','2019-03-05 19:59:59','DLTETH','4h','0.000737110000000','0.000722367800000','2.017205501689221','1.976861391655436','2736.6410735022196','2736.641073502219569','test','test','2.00'),('2019-03-06 15:59:59','2019-03-06 23:59:59','DLTETH','4h','0.000780780000000','0.000765164400000','2.008240143903936','1.968075341025857','2572.0947564024896','2572.094756402489566','test','test','2.00'),('2019-03-07 15:59:59','2019-03-07 19:59:59','DLTETH','4h','0.000734160000000','0.000727170000000','1.999314632153252','1.980278986954996','2723.2682687060747','2723.268268706074650','test','test','0.95'),('2019-03-09 03:59:59','2019-03-09 07:59:59','DLTETH','4h','0.000726960000000','0.000734720000000','1.995084488775861','2.016381197856004','2744.4212732142914','2744.421273214291432','test','test','0.0'),('2019-03-09 15:59:59','2019-03-10 15:59:59','DLTETH','4h','0.000729000000000','0.000728780000000','1.999817090793671','1.999213579463116','2743.2333207046236','2743.233320704623566','test','test','0.03'),('2019-03-10 19:59:59','2019-03-11 15:59:59','DLTETH','4h','0.000738650000000','0.000731230000000','1.999682977164659','1.979595455753217','2707.213128226709','2707.213128226709159','test','test','1.03'),('2019-03-12 11:59:59','2019-03-18 11:59:59','DLTETH','4h','0.000763090000000','0.000761580000000','1.995219083517671','1.991270950510933','2614.6576203562768','2614.657620356276766','test','test','0.26'),('2019-03-20 15:59:59','2019-03-21 03:59:59','DLTETH','4h','0.000782480000000','0.000768090000000','1.994341720627285','1.957665284986979','2548.744658812091','2548.744658812091075','test','test','1.83'),('2019-03-21 07:59:59','2019-03-21 11:59:59','DLTETH','4h','0.000778600000000','0.000783820000000','1.986191401596106','1.999507506292140','2550.977911117526','2550.977911117526219','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 15:59:59','DLTETH','4h','0.000830370000000','0.000813762600000','1.989150535973002','1.949367525253542','2395.499037745827','2395.499037745827081','test','test','2.0'),('2019-03-28 11:59:59','2019-03-28 15:59:59','DLTETH','4h','0.000892810000000','0.000874953800000','1.980309866924234','1.940703669585749','2218.0641647430402','2218.064164743040237','test','test','1.99'),('2019-03-29 07:59:59','2019-03-29 11:59:59','DLTETH','4h','0.000876230000000','0.000858705400000','1.971508489737903','1.932078319943145','2249.9897170125464','2249.989717012546407','test','test','1.99'),('2019-03-30 19:59:59','2019-04-02 07:59:59','DLTETH','4h','0.000857810000000','0.000861450000000','1.962746229783513','1.971074876309448','2288.0897049270966','2288.089704927096591','test','test','0.91');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:45:32
