-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-15 15:59:59','TNTBTC','4h','0.000013190000000','0.000012940000000','0.033333333333333','0.032701541571898','2527.1670457417235','2527.167045741723541','test','test','1.89'),('2018-06-02 15:59:59','2018-06-02 23:59:59','TNTBTC','4h','0.000011330000000','0.000011103400000','0.033192935164126','0.032529076460843','2929.6500586165544','2929.650058616554361','test','test','2.00'),('2018-06-23 15:59:59','2018-06-23 19:59:59','TNTBTC','4h','0.000009220000000','0.000009035600000','0.033045411007840','0.032384502787683','3584.1009769892016','3584.100976989201627','test','test','1.99'),('2018-07-02 15:59:59','2018-07-02 23:59:59','TNTBTC','4h','0.000007440000000','0.000007291200000','0.032898542514472','0.032240571664183','4421.847112160244','4421.847112160244251','test','test','2.00'),('2018-07-03 03:59:59','2018-07-03 07:59:59','TNTBTC','4h','0.000008300000000','0.000008134000000','0.032752326769964','0.032097280234565','3946.0634662606694','3946.063466260669429','test','test','1.99'),('2018-07-04 15:59:59','2018-07-05 19:59:59','TNTBTC','4h','0.000007650000000','0.000007497000000','0.032606760873208','0.031954625655744','4262.321682772316','4262.321682772316308','test','test','2.00'),('2018-08-28 03:59:59','2018-08-28 07:59:59','TNTBTC','4h','0.000002930000000','0.000002950000000','0.032461841935994','0.032683424474806','11079.126940612286','11079.126940612286489','test','test','0.0'),('2018-08-28 11:59:59','2018-09-02 11:59:59','TNTBTC','4h','0.000003020000000','0.000003110000000','0.032511082500174','0.033479955819716','10765.25910601803','10765.259106018029343','test','test','0.0'),('2018-09-02 15:59:59','2018-09-03 03:59:59','TNTBTC','4h','0.000003300000000','0.000003234000000','0.032726387682295','0.032071859928649','9917.087176452997','9917.087176452996573','test','test','1.99'),('2018-09-15 19:59:59','2018-09-25 03:59:59','TNTBTC','4h','0.000002780000000','0.000003930000000','0.032580937070374','0.046058662836896','11719.761536105594','11719.761536105594132','test','test','0.0'),('2018-09-25 19:59:59','2018-09-26 03:59:59','TNTBTC','4h','0.000004010000000','0.000003929800000','0.035575987240712','0.034864467495898','8871.817267010418','8871.817267010417709','test','test','1.99'),('2018-09-27 03:59:59','2018-09-27 07:59:59','TNTBTC','4h','0.000004040000000','0.000003959200000','0.035417871741864','0.034709514307027','8766.799936105004','8766.799936105004235','test','test','2.00'),('2018-09-28 07:59:59','2018-09-28 11:59:59','TNTBTC','4h','0.000004300000000','0.000004214000000','0.035260458978567','0.034555249798996','8200.106739201654','8200.106739201653909','test','test','1.99'),('2018-09-29 19:59:59','2018-09-29 23:59:59','TNTBTC','4h','0.000004230000000','0.000004145400000','0.035103745827551','0.034401670911000','8298.757878853743','8298.757878853743023','test','test','2.0'),('2018-09-30 03:59:59','2018-09-30 15:59:59','TNTBTC','4h','0.000004300000000','0.000004214000000','0.034947729179429','0.034248774595840','8127.378878936949','8127.378878936949150','test','test','1.99'),('2018-10-01 19:59:59','2018-10-03 03:59:59','TNTBTC','4h','0.000004360000000','0.000004272800000','0.034792405938631','0.034096557819858','7979.909618952141','7979.909618952140590','test','test','1.99'),('2018-10-04 11:59:59','2018-10-04 23:59:59','TNTBTC','4h','0.000004610000000','0.000004517800000','0.034637773023348','0.033945017562881','7513.616707884694','7513.616707884693824','test','test','1.99'),('2018-10-08 15:59:59','2018-10-09 15:59:59','TNTBTC','4h','0.000004420000000','0.000004390000000','0.034483827365467','0.034249774238552','7801.770897164452','7801.770897164452435','test','test','0.67'),('2018-10-10 11:59:59','2018-10-11 03:59:59','TNTBTC','4h','0.000004540000000','0.000004449200000','0.034431815559486','0.033743179248296','7584.10034349907','7584.100343499069822','test','test','2.00'),('2018-10-13 19:59:59','2018-10-14 03:59:59','TNTBTC','4h','0.000004430000000','0.000004341400000','0.034278785268110','0.033593209562748','7737.874778354451','7737.874778354451337','test','test','2.00'),('2018-10-14 15:59:59','2018-10-14 23:59:59','TNTBTC','4h','0.000004590000000','0.000004498200000','0.034126435111363','0.033443906409136','7434.95318330351','7434.953183303509832','test','test','1.99'),('2018-10-15 11:59:59','2018-10-15 19:59:59','TNTBTC','4h','0.000004380000000','0.000004292400000','0.033974762066424','0.033295266825096','7756.794992334196','7756.794992334195740','test','test','1.99'),('2018-10-16 07:59:59','2018-10-27 15:59:59','TNTBTC','4h','0.000004550000000','0.000005140000000','0.033823763123906','0.038209701638874','7433.7940931662515','7433.794093166251514','test','test','0.0'),('2018-10-30 15:59:59','2018-10-30 23:59:59','TNTBTC','4h','0.000005800000000','0.000005684000000','0.034798416127233','0.034102447804688','5999.726918488391','5999.726918488390766','test','test','2.00'),('2018-11-02 11:59:59','2018-11-02 15:59:59','TNTBTC','4h','0.000005870000000','0.000005752600000','0.034643756500000','0.033950881370000','5901.832453151694','5901.832453151693699','test','test','1.99'),('2018-11-08 19:59:59','2018-11-09 03:59:59','TNTBTC','4h','0.000005460000000','0.000005350800000','0.034489784248889','0.033799988563911','6316.810301994382','6316.810301994381916','test','test','1.99'),('2018-11-09 11:59:59','2018-11-10 03:59:59','TNTBTC','4h','0.000005570000000','0.000005458600000','0.034336496318894','0.033649766392516','6164.541529424456','6164.541529424455803','test','test','2.00'),('2018-11-10 11:59:59','2018-11-10 15:59:59','TNTBTC','4h','0.000005690000000','0.000005576200000','0.034183889668588','0.033500211875216','6007.713474268541','6007.713474268541177','test','test','2.00'),('2018-11-28 19:59:59','2018-11-28 23:59:59','TNTBTC','4h','0.000003820000000','0.000003880000000','0.034031961270061','0.034566494693151','8908.890384832692','8908.890384832691780','test','test','0.0'),('2018-11-30 07:59:59','2018-12-03 03:59:59','TNTBTC','4h','0.000003990000000','0.000003950000000','0.034150746475192','0.033808383102007','8559.084329622054','8559.084329622053701','test','test','1.00'),('2018-12-04 15:59:59','2018-12-04 19:59:59','TNTBTC','4h','0.000004060000000','0.000003978800000','0.034074665725595','0.033393172411083','8392.774809259934','8392.774809259934045','test','test','2.00'),('2018-12-05 11:59:59','2018-12-05 19:59:59','TNTBTC','4h','0.000004130000000','0.000004047400000','0.033923222766815','0.033244758311479','8213.855391480602','8213.855391480601611','test','test','1.99'),('2018-12-12 19:59:59','2018-12-13 19:59:59','TNTBTC','4h','0.000003840000000','0.000003763200000','0.033772452887851','0.033097003830094','8794.909606211286','8794.909606211285791','test','test','2.00'),('2018-12-17 15:59:59','2018-12-17 19:59:59','TNTBTC','4h','0.000003860000000','0.000003782800000','0.033622353097239','0.032949906035294','8710.454170269082','8710.454170269082169','test','test','1.99'),('2018-12-24 15:59:59','2018-12-24 23:59:59','TNTBTC','4h','0.000003570000000','0.000003570000000','0.033472920416806','0.033472920416806','9376.168183979395','9376.168183979394598','test','test','0.0'),('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003180000000','0.033472920416806','0.032853051520198','10331.148276792112','10331.148276792111574','test','test','1.85'),('2019-01-09 11:59:59','2019-01-09 19:59:59','TNTBTC','4h','0.000003410000000','0.000003341800000','0.033335171773116','0.032668468337654','9775.710197394654','9775.710197394653733','test','test','2.00'),('2019-01-12 15:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003280000000','0.000003214400000','0.033187015454124','0.032523275145042','10117.992516501286','10117.992516501286445','test','test','1.99'),('2019-01-14 19:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003300000000','0.000004210000000','0.033039517607662','0.042150414887351','10011.975032624712','10011.975032624712185','test','test','0.0'),('2019-01-21 15:59:59','2019-01-22 15:59:59','TNTBTC','4h','0.000004500000000','0.000004410000000','0.035064161447592','0.034362878218640','7792.035877242764','7792.035877242764400','test','test','1.99'),('2019-01-24 15:59:59','2019-01-25 07:59:59','TNTBTC','4h','0.000004500000000','0.000004410000000','0.034908320730048','0.034210154315447','7757.4046066772335','7757.404606677233460','test','test','1.99'),('2019-01-25 15:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004540000000','0.000004449200000','0.034753172637914','0.034058109185156','7654.883840950219','7654.883840950218655','test','test','2.00'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004150000000','0.034598714092857','0.033944364890155','8179.36503377226','8179.365033772260176','test','test','1.89'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004000000000','0.034453303158923','0.033944141043274','8486.035260818444','8486.035260818443930','test','test','1.47'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.034340156022112','0.034257208785344','8294.723676838646','8294.723676838646497','test','test','0.24'),('2019-02-10 11:59:59','2019-02-11 15:59:59','TNTBTC','4h','0.000004150000000','0.000004067000000','0.034321723302830','0.033635288836773','8270.294771766316','8270.294771766315534','test','test','1.99'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003939600000','0.034169182310373','0.033485798664166','8499.796594620175','8499.796594620174801','test','test','2.00'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003900000000','0.034017319277883','0.033586720299682','8611.979564020925','8611.979564020924954','test','test','1.26'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003900000000','0.033921630616060','0.033407666515817','8566.068337388944','8566.068337388944201','test','test','1.51'),('2019-02-20 23:59:59','2019-02-21 07:59:59','TNTBTC','4h','0.000004070000000','0.000003988600000','0.033807416371562','0.033131268044131','8306.490508983235','8306.490508983235486','test','test','1.99'),('2019-02-21 23:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004020000000','0.000004040000000','0.033657161187688','0.033824609750811','8372.428156141346','8372.428156141346335','test','test','0.24'),('2019-02-26 11:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004160000000','0.000004076800000','0.033694371979493','0.033020484539903','8099.6086489166655','8099.608648916665516','test','test','2.00'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.033544619215140','0.032890090059723','8181.614442717072','8181.614442717072052','test','test','1.95'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.033399168291714','0.033234640369095','8226.396130964036','8226.396130964036274','test','test','0.49'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.033362606531132','0.034601317169664','8258.07092354752','8258.070923547520579','test','test','0.0'),('2019-03-04 23:59:59','2019-03-05 03:59:59','TNTBTC','4h','0.000004290000000','0.000004204200000','0.033637875561917','0.032965118050679','7840.996634479459','7840.996634479459317','test','test','2.00'),('2019-03-05 19:59:59','2019-03-06 03:59:59','TNTBTC','4h','0.000004210000000','0.000004125800000','0.033488373892753','0.032818606414898','7954.483109917548','7954.483109917548063','test','test','1.99'),('2019-03-08 11:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004250000000','0.000004270000000','0.033339536675452','0.033496428612748','7844.596864812181','7844.596864812180684','test','test','0.47'),('2019-03-11 23:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004710000000','0.000004615800000','0.033374401550406','0.032706913519398','7085.860201784806','7085.860201784806122','test','test','1.99'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.033226070876849','0.032937775251020','7207.390645737333','7207.390645737333216','test','test','0.86'),('2019-03-26 03:59:59','2019-03-26 07:59:59','TNTBTC','4h','0.000004740000000','0.000004670000000','0.033162005182220','0.032672270928474','6996.203624941019','6996.203624941019370','test','test','1.47'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.033053175348055','0.033464625663591','6857.5052589325005','6857.505258932500510','test','test','0.20'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.033144608751507','0.032818863210952','8143.6385138838095','8143.638513883809537','test','test','0.98');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:25:11
