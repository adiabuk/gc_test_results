-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-28 19:59:59','2018-04-29 03:59:59','RCNETH','4h','0.000226270000000','0.000221744600000','1.297777777777778','1.271822222222222','5735.527368974136','5735.527368974136152','test','test','2.00'),('2018-04-29 23:59:59','2018-04-30 11:59:59','RCNETH','4h','0.000225190000000','0.000221040000000','1.292009876543210','1.268199578627431','5737.421184525111','5737.421184525111130','test','test','1.84'),('2018-04-30 19:59:59','2018-05-01 03:59:59','RCNETH','4h','0.000230180000000','0.000225576400000','1.286718699228592','1.260984325244020','5590.054301974942','5590.054301974942064','test','test','2.00'),('2018-05-02 11:59:59','2018-05-02 15:59:59','RCNETH','4h','0.000223560000000','0.000221310000000','1.280999949454243','1.268107437885662','5730.005141591711','5730.005141591711435','test','test','1.00'),('2018-06-01 19:59:59','2018-06-01 23:59:59','RCNETH','4h','0.000161440000000','0.000158211200000','1.278134946883447','1.252572247945778','7917.089611517883','7917.089611517882986','test','test','2.00'),('2018-07-01 15:59:59','2018-07-01 23:59:59','RCNETH','4h','0.000103950000000','0.000101871000000','1.272454347119521','1.247005260177131','12241.023060312848','12241.023060312847520','test','test','2.00'),('2018-07-02 07:59:59','2018-07-02 11:59:59','RCNETH','4h','0.000102520000000','0.000106650000000','1.266798994465656','1.317831767067520','12356.603535560438','12356.603535560438104','test','test','0.0'),('2018-07-02 15:59:59','2018-07-03 11:59:59','RCNETH','4h','0.000111240000000','0.000109015200000','1.278139610599404','1.252576818387416','11489.928178707334','11489.928178707334155','test','test','1.99'),('2018-07-06 03:59:59','2018-07-06 11:59:59','RCNETH','4h','0.000110240000000','0.000108035200000','1.272458990107851','1.247009810305694','11542.625091689504','11542.625091689504188','test','test','1.99'),('2018-07-08 19:59:59','2018-07-09 03:59:59','RCNETH','4h','0.000108490000000','0.000109000000000','1.266803616818483','1.272758726456030','11676.685563816782','11676.685563816781723','test','test','1.95'),('2018-07-09 15:59:59','2018-07-09 23:59:59','RCNETH','4h','0.000110200000000','0.000107996000000','1.268126974515715','1.242764435025401','11507.50430595023','11507.504305950229536','test','test','2.00'),('2018-07-18 03:59:59','2018-07-19 19:59:59','RCNETH','4h','0.000105060000000','0.000102958800000','1.262490854628979','1.237241037536399','12016.855650380534','12016.855650380533916','test','test','1.99'),('2018-07-23 15:59:59','2018-07-23 19:59:59','RCNETH','4h','0.000104300000000','0.000102214000000','1.256879784163961','1.231742188480682','12050.621132923885','12050.621132923884943','test','test','2.00'),('2018-07-28 07:59:59','2018-07-28 15:59:59','RCNETH','4h','0.000100020000000','0.000098019600000','1.251293651789899','1.226267778754101','12510.434431012789','12510.434431012788991','test','test','1.99'),('2018-07-29 03:59:59','2018-07-29 07:59:59','RCNETH','4h','0.000106840000000','0.000104703200000','1.245732346670833','1.220817699737416','11659.793585462681','11659.793585462681222','test','test','1.99'),('2018-07-29 15:59:59','2018-07-29 23:59:59','RCNETH','4h','0.000104540000000','0.000102449200000','1.240195758463407','1.215391843294139','11863.360995441046','11863.360995441045816','test','test','2.00'),('2018-07-30 11:59:59','2018-07-30 15:59:59','RCNETH','4h','0.000108550000000','0.000106379000000','1.234683777314681','1.209990101768387','11374.332356652976','11374.332356652976159','test','test','2.00'),('2018-08-20 07:59:59','2018-08-20 11:59:59','RCNETH','4h','0.000072970000000','0.000071670000000','1.229196293859949','1.207297497340586','16845.22809181785','16845.228091817851237','test','test','1.78'),('2018-08-20 15:59:59','2018-08-20 23:59:59','RCNETH','4h','0.000074110000000','0.000072627800000','1.224329894633424','1.199843296740756','16520.44116358688','16520.441163586878247','test','test','1.99'),('2018-08-25 15:59:59','2018-08-29 19:59:59','RCNETH','4h','0.000072010000000','0.000072950000000','1.218888428435053','1.234799484159660','16926.655026177654','16926.655026177653781','test','test','1.95'),('2018-08-31 07:59:59','2018-09-02 15:59:59','RCNETH','4h','0.000074850000000','0.000074620000000','1.222424218596077','1.218667938432054','16331.65288705513','16331.652887055130122','test','test','0.30'),('2018-09-04 15:59:59','2018-09-05 11:59:59','RCNETH','4h','0.000079160000000','0.000077576800000','1.221589489670738','1.197157699877323','15431.903608776382','15431.903608776381589','test','test','2.00'),('2018-09-05 15:59:59','2018-09-14 03:59:59','RCNETH','4h','0.000080850000000','0.000093960000000','1.216160203049979','1.413363174750476','15042.179382188982','15042.179382188982345','test','test','0.0'),('2018-09-15 11:59:59','2018-09-21 23:59:59','RCNETH','4h','0.000101000000000','0.000114300000000','1.259983085650090','1.425901650394112','12475.080055941482','12475.080055941481987','test','test','1.51'),('2018-09-22 19:59:59','2018-09-24 11:59:59','RCNETH','4h','0.000120680000000','0.000118266400000','1.296853877815428','1.270916800259119','10746.220399531223','10746.220399531222938','test','test','2.00'),('2018-09-25 03:59:59','2018-09-27 19:59:59','RCNETH','4h','0.000124200000000','0.000121716000000','1.291090082802915','1.265268281146857','10395.250264113645','10395.250264113645244','test','test','1.99'),('2018-09-28 19:59:59','2018-09-29 11:59:59','RCNETH','4h','0.000129160000000','0.000126576800000','1.285351904657124','1.259644866563981','9951.625152192042','9951.625152192042151','test','test','1.99'),('2018-10-03 19:59:59','2018-10-04 03:59:59','RCNETH','4h','0.000125950000000','0.000123431000000','1.279639229525315','1.254046444934809','10159.898606790905','10159.898606790904523','test','test','2.00'),('2018-10-04 11:59:59','2018-10-08 03:59:59','RCNETH','4h','0.000124780000000','0.000127600000000','1.273951944060758','1.302742972128167','10209.584421067138','10209.584421067138464','test','test','0.0'),('2018-10-08 15:59:59','2018-10-08 19:59:59','RCNETH','4h','0.000129160000000','0.000126576800000','1.280349950297960','1.254742951292001','9912.898345447196','9912.898345447196334','test','test','1.99'),('2018-10-09 03:59:59','2018-10-11 07:59:59','RCNETH','4h','0.000130150000000','0.000131220000000','1.274659506074413','1.285138842774372','9793.772616783812','9793.772616783811827','test','test','0.34'),('2018-10-11 11:59:59','2018-10-11 19:59:59','RCNETH','4h','0.000136410000000','0.000133681800000','1.276988247563293','1.251448482612027','9361.397606944454','9361.397606944454310','test','test','2.00'),('2018-10-12 07:59:59','2018-10-12 19:59:59','RCNETH','4h','0.000135700000000','0.000132986000000','1.271312744240789','1.245886489355973','9368.553752695574','9368.553752695574076','test','test','2.00'),('2018-10-14 07:59:59','2018-10-15 07:59:59','RCNETH','4h','0.000136980000000','0.000134240400000','1.265662465377497','1.240349216069947','9239.761026262935','9239.761026262935047','test','test','1.99'),('2018-10-17 11:59:59','2018-10-18 19:59:59','RCNETH','4h','0.000135900000000','0.000134880000000','1.260037298864708','1.250580065274995','9271.797636973568','9271.797636973567933','test','test','0.75'),('2018-10-18 23:59:59','2018-10-26 11:59:59','RCNETH','4h','0.000138370000000','0.000143670000000','1.257935691400327','1.306118528463432','9091.101332661181','9091.101332661181004','test','test','1.85'),('2018-10-27 23:59:59','2018-10-29 07:59:59','RCNETH','4h','0.000168550000000','0.000165179000000','1.268642988525462','1.243270128754953','7526.80503426557','7526.805034265569702','test','test','2.00'),('2018-10-31 19:59:59','2018-11-04 07:59:59','RCNETH','4h','0.000166090000000','0.000162768200000','1.263004575243126','1.237744483738263','7604.3384625391445','7604.338462539144530','test','test','2.00'),('2018-11-06 03:59:59','2018-11-06 07:59:59','RCNETH','4h','0.000163210000000','0.000159945800000','1.257391221575379','1.232243397143871','7704.1310065276575','7704.131006527657519','test','test','2.00'),('2018-11-06 11:59:59','2018-11-06 15:59:59','RCNETH','4h','0.000171790000000','0.000168354200000','1.251802816146155','1.226766759823232','7286.820048583475','7286.820048583475000','test','test','2.00'),('2018-11-07 03:59:59','2018-11-07 07:59:59','RCNETH','4h','0.000162030000000','0.000159910000000','1.246239248074394','1.229933457752122','7691.410529373539','7691.410529373539248','test','test','1.30'),('2018-11-27 11:59:59','2018-11-27 19:59:59','RCNETH','4h','0.000128720000000','0.000128040000000','1.242615739113890','1.236051268149025','9653.633771860548','9653.633771860548222','test','test','0.52'),('2018-11-28 03:59:59','2018-11-28 07:59:59','RCNETH','4h','0.000134010000000','0.000131329800000','1.241156967788364','1.216333828432597','9261.674261535438','9261.674261535437836','test','test','2.00'),('2018-11-28 15:59:59','2018-11-30 11:59:59','RCNETH','4h','0.000138700000000','0.000135926000000','1.235640714598194','1.210927900306230','8908.729016569529','8908.729016569528540','test','test','2.00'),('2018-12-03 11:59:59','2018-12-06 15:59:59','RCNETH','4h','0.000148340000000','0.000145373200000','1.230148978088868','1.205545998527090','8292.766469521828','8292.766469521828185','test','test','2.0'),('2019-01-11 11:59:59','2019-01-11 15:59:59','RCNETH','4h','0.000085540000000','0.000084960000000','1.224681649297362','1.216377752213045','14317.063938477464','14317.063938477464035','test','test','0.67'),('2019-01-12 03:59:59','2019-01-12 11:59:59','RCNETH','4h','0.000086100000000','0.000085150000000','1.222836338834181','1.209343951820331','14202.51264615773','14202.512646157729250','test','test','1.46'),('2019-01-12 19:59:59','2019-01-12 23:59:59','RCNETH','4h','0.000085960000000','0.000084920000000','1.219838030608881','1.205079636567080','14190.763501731975','14190.763501731975339','test','test','1.20'),('2019-01-13 11:59:59','2019-01-13 15:59:59','RCNETH','4h','0.000088320000000','0.000086553600000','1.216558387488480','1.192227219738710','13774.438264135873','13774.438264135873396','test','test','1.99'),('2019-01-13 19:59:59','2019-01-14 15:59:59','RCNETH','4h','0.000087740000000','0.000085985200000','1.211151461321865','1.186928432095428','13803.868945998003','13803.868945998003255','test','test','1.99'),('2019-01-14 23:59:59','2019-01-24 03:59:59','RCNETH','4h','0.000086760000000','0.000100820000000','1.205768565938212','1.401170894627599','13897.747417452882','13897.747417452881564','test','test','0.59'),('2019-01-26 11:59:59','2019-01-27 11:59:59','RCNETH','4h','0.000103830000000','0.000101753400000','1.249191305646965','1.224207479534026','12031.121117663148','12031.121117663147743','test','test','1.99'),('2019-01-27 23:59:59','2019-01-28 03:59:59','RCNETH','4h','0.000102840000000','0.000101210000000','1.243639344288534','1.223927829982911','12092.953561732145','12092.953561732145317','test','test','1.58'),('2019-01-28 11:59:59','2019-01-28 15:59:59','RCNETH','4h','0.000103250000000','0.000102500000000','1.239259007776173','1.230257126363755','12002.508549890297','12002.508549890297218','test','test','0.72'),('2019-01-28 19:59:59','2019-01-31 07:59:59','RCNETH','4h','0.000103060000000','0.000102540000000','1.237258589684525','1.231015872173988','12005.225981802103','12005.225981802102979','test','test','0.50'),('2019-02-05 15:59:59','2019-02-05 19:59:59','RCNETH','4h','0.000100230000000','0.000098225400000','1.235871319126628','1.211153892744095','12330.353378495736','12330.353378495736251','test','test','2.00'),('2019-02-06 03:59:59','2019-02-06 11:59:59','RCNETH','4h','0.000099390000000','0.000099670000000','1.230378557708287','1.233844761513079','12379.299302830135','12379.299302830135275','test','test','0.0'),('2019-02-07 19:59:59','2019-02-08 03:59:59','RCNETH','4h','0.000102610000000','0.000100557800000','1.231148825220463','1.206525848716054','11998.331792422405','11998.331792422404760','test','test','2.00'),('2019-02-21 23:59:59','2019-02-23 19:59:59','RCNETH','4h','0.000108920000000','0.000106741600000','1.225677052663928','1.201163511610649','11253.002686962243','11253.002686962243388','test','test','2.00'),('2019-02-25 19:59:59','2019-02-27 23:59:59','RCNETH','4h','0.000142190000000','0.000139346200000','1.220229599096532','1.195825007114601','8581.683656350886','8581.683656350885940','test','test','2.00'),('2019-02-28 19:59:59','2019-03-01 11:59:59','RCNETH','4h','0.000164020000000','0.000160739600000','1.214806356433881','1.190510229305203','7406.452605986349','7406.452605986349226','test','test','2.00'),('2019-03-04 03:59:59','2019-03-13 03:59:59','RCNETH','4h','0.000149450000000','0.000169370000000','1.209407217071953','1.370607563435776','8092.386865653747','8092.386865653747009','test','test','0.54'),('2019-03-14 03:59:59','2019-03-20 19:59:59','RCNETH','4h','0.000170940000000','0.000176620000000','1.245229516263913','1.286606044006858','7284.599954743846','7284.599954743845956','test','test','1.39'),('2019-03-24 15:59:59','2019-03-25 07:59:59','RCNETH','4h','0.000175890000000','0.000172372200000','1.254424300206790','1.229335814202654','7131.8682142634025','7131.868214263402479','test','test','2.00'),('2019-03-25 19:59:59','2019-03-25 23:59:59','RCNETH','4h','0.000173410000000','0.000169941800000','1.248849081094760','1.223872099472865','7201.713171643848','7201.713171643848000','test','test','2.00'),('2019-03-27 11:59:59','2019-04-02 07:59:59','RCNETH','4h','0.000177820000000','0.000208630000000','1.243298640734338','1.458718903477702','6991.8942792393345','6991.894279239334537','test','test','1.08'),('2019-04-13 07:59:59','2019-04-14 23:59:59','RCNETH','4h','0.000187440000000','0.000184500000000','1.291169810232864','1.270917786960966','6888.44328976133','6888.443289761329652','test','test','1.56'),('2019-04-16 03:59:59','2019-04-17 23:59:59','RCNETH','4h','0.000187160000000','0.000187050000000','1.286669360616887','1.285913143317956','6874.702717551222','6874.702717551222122','test','test','0.30'),('2019-04-19 19:59:59','2019-04-20 03:59:59','RCNETH','4h','0.000188180000000','0.000185700000000','1.286501312328235','1.269546677114216','6836.546457265571','6836.546457265571007','test','test','1.31'),('2019-04-20 11:59:59','2019-04-20 19:59:59','RCNETH','4h','0.000193870000000','0.000189992600000','1.282733615614009','1.257078943301729','6616.462658554747','6616.462658554746668','test','test','2.00'),('2019-04-21 03:59:59','2019-04-21 11:59:59','RCNETH','4h','0.000187820000000','0.000184063600000','1.277032577322391','1.251491925775943','6799.236382293637','6799.236382293636780','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:07:40
