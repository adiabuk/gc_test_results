-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-31 07:59:59','2018-05-31 19:59:59','LTCETH','4h','0.209700000000000','0.206900000000000','1.297777777777778','1.280449319133153','6.188735230223069','6.188735230223069','test','test','1.41'),('2018-06-01 19:59:59','2018-06-01 23:59:59','LTCETH','4h','0.207230000000000','0.207420000000000','1.293927009190083','1.295113353501940','6.2439174308260545','6.243917430826055','test','test','0.0'),('2018-06-11 03:59:59','2018-06-11 07:59:59','LTCETH','4h','0.202240000000000','0.201430000000000','1.294190641259385','1.289007223441841','6.39928125622718','6.399281256227180','test','test','0.40'),('2018-06-11 19:59:59','2018-06-11 23:59:59','LTCETH','4h','0.203090000000000','0.201590000000000','1.293038770633264','1.283488531054999','6.366826385510187','6.366826385510187','test','test','0.73'),('2018-06-12 19:59:59','2018-06-12 23:59:59','LTCETH','4h','0.202240000000000','0.202100000000000','1.290916495171427','1.290022862312823','6.383091847168846','6.383091847168846','test','test','0.06'),('2018-06-14 15:59:59','2018-06-14 19:59:59','LTCETH','4h','0.203520000000000','0.199449600000000','1.290717910091737','1.264903551889902','6.341970863265219','6.341970863265219','test','test','2.00'),('2018-06-27 19:59:59','2018-06-27 23:59:59','LTCETH','4h','0.184770000000000','0.182540000000000','1.284981386046885','1.269472870103363','6.954491454494157','6.954491454494157','test','test','1.20'),('2018-07-03 03:59:59','2018-07-05 03:59:59','LTCETH','4h','0.182600000000000','0.180830000000000','1.281535049170547','1.269112721475958','7.0182642342308155','7.018264234230815','test','test','0.96'),('2018-07-11 11:59:59','2018-07-11 15:59:59','LTCETH','4h','0.179540000000000','0.176820000000000','1.278774531905083','1.259401318544373','7.122504912025636','7.122504912025636','test','test','1.51'),('2018-07-13 23:59:59','2018-07-14 03:59:59','LTCETH','4h','0.177240000000000','0.176370000000000','1.274469373380481','1.268213514912635','7.1906419170643225','7.190641917064323','test','test','0.49'),('2018-07-15 03:59:59','2018-07-15 07:59:59','LTCETH','4h','0.177350000000000','0.176580000000000','1.273079182609848','1.267551858275991','7.1783432907237','7.178343290723700','test','test','0.43'),('2018-07-17 19:59:59','2018-07-21 03:59:59','LTCETH','4h','0.178010000000000','0.177600000000000','1.271850888313436','1.268921508704377','7.144828314776898','7.144828314776898','test','test','0.23'),('2018-07-23 03:59:59','2018-07-26 07:59:59','LTCETH','4h','0.182220000000000','0.180880000000000','1.271199915066978','1.261851830958814','6.976182170272078','6.976182170272078','test','test','0.80'),('2018-07-31 11:59:59','2018-07-31 15:59:59','LTCETH','4h','0.180830000000000','0.180100000000000','1.269122563042941','1.263999190422130','7.018318658645919','7.018318658645919','test','test','0.40'),('2018-07-31 23:59:59','2018-08-01 03:59:59','LTCETH','4h','0.182380000000000','0.184150000000000','1.267984035793872','1.280289835461353','6.952429190667137','6.952429190667137','test','test','0.0'),('2018-08-01 19:59:59','2018-08-04 19:59:59','LTCETH','4h','0.185150000000000','0.181447000000000','1.270718657942201','1.245304284783357','6.863184757991906','6.863184757991906','test','test','2.00'),('2018-08-06 03:59:59','2018-08-06 11:59:59','LTCETH','4h','0.184350000000000','0.181220000000000','1.265071019462458','1.243591918345466','6.8623326252370935','6.862332625237094','test','test','1.69'),('2018-08-07 19:59:59','2018-08-07 23:59:59','LTCETH','4h','0.183210000000000','0.179545800000000','1.260297885880905','1.235091928163287','6.878979782112902','6.878979782112902','test','test','2.00'),('2018-08-11 15:59:59','2018-08-18 15:59:59','LTCETH','4h','0.180270000000000','0.195540000000000','1.254696561943656','1.360977232609211','6.96009631077637','6.960096310776370','test','test','0.0'),('2018-08-19 15:59:59','2018-08-20 11:59:59','LTCETH','4h','0.193950000000000','0.193620000000000','1.278314488758224','1.276139475706972','6.590948640155832','6.590948640155832','test','test','1.25'),('2018-08-20 15:59:59','2018-09-13 23:59:59','LTCETH','4h','0.195860000000000','0.258530000000000','1.277831152524612','1.686703195456897','6.524206844300074','6.524206844300074','test','test','0.18'),('2018-09-14 19:59:59','2018-09-15 15:59:59','LTCETH','4h','0.264460000000000','0.259170800000000','1.368691606509565','1.341317774379374','5.1754201259531305','5.175420125953131','test','test','1.99'),('2018-09-17 19:59:59','2018-09-18 03:59:59','LTCETH','4h','0.264870000000000','0.259572600000000','1.362608532702856','1.335356362048799','5.144442680193513','5.144442680193513','test','test','2.00'),('2018-09-25 07:59:59','2018-09-29 11:59:59','LTCETH','4h','0.264830000000000','0.266050000000000','1.356552494779732','1.362801764287081','5.122352055204212','5.122352055204212','test','test','1.05'),('2018-09-29 23:59:59','2018-09-30 03:59:59','LTCETH','4h','0.266250000000000','0.264200000000000','1.357941221336920','1.347485711463716','5.100248718636321','5.100248718636321','test','test','0.76'),('2018-10-11 11:59:59','2018-10-11 15:59:59','LTCETH','4h','0.261990000000000','0.262340000000000','1.355617774698431','1.357428783596269','5.174311136678616','5.174311136678616','test','test','0.0'),('2018-10-11 23:59:59','2018-10-15 07:59:59','LTCETH','4h','0.267890000000000','0.262532200000000','1.356020221120172','1.328899816697768','5.061854571354556','5.061854571354556','test','test','2.00'),('2018-10-15 19:59:59','2018-10-15 23:59:59','LTCETH','4h','0.268080000000000','0.262718400000000','1.349993464581861','1.322993595290224','5.0357858272973015','5.035785827297302','test','test','2.00'),('2018-10-23 15:59:59','2018-10-23 19:59:59','LTCETH','4h','0.261240000000000','0.258220000000000','1.343993493628163','1.328456591351494','5.144669628036147','5.144669628036147','test','test','1.15'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCETH','4h','0.257180000000000','0.255880000000000','1.340540848677793','1.333764648727248','5.212461500419132','5.212461500419132','test','test','0.55'),('2018-11-03 11:59:59','2018-11-03 15:59:59','LTCETH','4h','0.255890000000000','0.255230000000000','1.339035026466560','1.335581342784244','5.232854064115676','5.232854064115676','test','test','0.25'),('2018-11-04 07:59:59','2018-11-04 19:59:59','LTCETH','4h','0.257430000000000','0.255040000000000','1.338267541203823','1.325842962003741','5.198568702963227','5.198568702963227','test','test','0.92'),('2018-11-20 03:59:59','2018-11-20 11:59:59','LTCETH','4h','0.251000000000000','0.245980000000000','1.335506523603805','1.308796393131729','5.320743121927511','5.320743121927511','test','test','1.99'),('2018-11-20 23:59:59','2018-12-07 19:59:59','LTCETH','4h','0.252840000000000','0.263770000000000','1.329570939054455','1.387046854114830','5.258546666091025','5.258546666091025','test','test','1.83'),('2018-12-14 23:59:59','2018-12-19 19:59:59','LTCETH','4h','0.278400000000000','0.289990000000000','1.342343364623427','1.398226121792915','4.8216356487910454','4.821635648791045','test','test','0.0'),('2018-12-19 23:59:59','2018-12-20 03:59:59','LTCETH','4h','0.292510000000000','0.290620000000000','1.354761755105536','1.346008209185227','4.6315057779410465','4.631505777941046','test','test','0.64'),('2018-12-20 11:59:59','2018-12-20 15:59:59','LTCETH','4h','0.289960000000000','0.287880000000000','1.352816522678800','1.343112224268082','4.6655280820761496','4.665528082076150','test','test','0.71'),('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.350660011920863','1.459939154796709','5.806543192127866','5.806543192127866','test','test','0.0'),('2019-01-15 23:59:59','2019-01-16 15:59:59','LTCETH','4h','0.258350000000000','0.256340000000000','1.374944265893273','1.364247002589826','5.322021544003379','5.322021544003379','test','test','0.77'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.372567096270285','1.355941545605003','5.328702136308275','5.328702136308275','test','test','1.49'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.368872529455778','1.818221683180832','5.367285639334135','5.367285639334135','test','test','0.0'),('2019-02-15 11:59:59','2019-02-17 11:59:59','LTCETH','4h','0.346280000000000','0.342220000000000','1.468727896950234','1.451507626470802','4.241445930894751','4.241445930894751','test','test','1.17'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.339668000000000','1.464901170177027','1.435603146773486','4.226489238825814','4.226489238825814','test','test','1.99'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.458390498309574','1.455300226862414','4.352494995999564','4.352494995999564','test','test','0.21'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.457703771321316','1.873819186247303','4.332730267867423','4.332730267867423','test','test','0.0'),('2019-03-20 19:59:59','2019-03-29 07:59:59','LTCETH','4h','0.435300000000000','0.433750000000000','1.550173863527091','1.544654062267116','3.56116210320949','3.561162103209490','test','test','1.41'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.548947241024874','1.537816272009336','3.5562201327598357','3.556220132759836','test','test','0.71'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.546473692354755','1.703409347032307','3.451410923192257','3.451410923192257','test','test','0.39'),('2019-04-10 23:59:59','2019-04-11 07:59:59','LTCETH','4h','0.498150000000000','0.493730000000000','1.581348282283100','1.567317248643250','3.174441999966074','3.174441999966074','test','test','0.88'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.489078800000000','1.578230274807577','1.546665669311425','3.1624058726557474','3.162405872655747','test','test','2.00'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.571215918030655','1.562528589833160','3.217528962035211','3.217528962035211','test','test','0.55'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.569285400653434','1.544200787719521','3.3268717418983114','3.326871741898311','test','test','1.59'),('2019-04-30 23:59:59','2019-05-01 03:59:59','LTCETH','4h','0.459000000000000','0.454640000000000','1.563711042223675','1.548857490711485','3.406777869768355','3.406777869768355','test','test','0.94'),('2019-05-03 11:59:59','2019-05-06 03:59:59','LTCETH','4h','0.470640000000000','0.461227200000000','1.560410252998744','1.529202047938769','3.315507081843328','3.315507081843328','test','test','1.99'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.553475096318749','1.552151401130712','3.3940902257346504','3.394090225734650','test','test','0.72'),('2019-05-12 11:59:59','2019-05-12 23:59:59','LTCETH','4h','0.460670000000000','0.451456600000000','1.553180941832519','1.522117322995869','3.371569543995743','3.371569543995743','test','test','1.99'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCETH','4h','0.395420000000000','0.421150000000000','1.546277915424375','1.646894299936714','3.9104696662393774','3.910469666239377','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04  9:57:18
