-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-30 15:59:59','ADABTC','4h','0.000028360000000','0.000027792800000','0.033333333333333','0.032666666666666','1175.3643629525152','1175.364362952515194','test','test','2.00'),('2018-05-30 19:59:59','2018-06-04 07:59:59','ADABTC','4h','0.000027690000000','0.000028460000000','0.033185185185185','0.034107994596257','1198.4537806134022','1198.453780613402159','test','test','0.0'),('2018-06-05 19:59:59','2018-06-06 07:59:59','ADABTC','4h','0.000028700000000','0.000028250000000','0.033390253943201','0.032866713376147','1163.423482341502','1163.423482341501995','test','test','1.56'),('2018-07-01 11:59:59','2018-07-01 15:59:59','ADABTC','4h','0.000022370000000','0.000022060000000','0.033273911594967','0.032812806874608','1487.4345818045097','1487.434581804509662','test','test','1.38'),('2018-07-01 19:59:59','2018-07-02 07:59:59','ADABTC','4h','0.000022050000000','0.000022310000000','0.033171443879332','0.033562581086072','1504.3738720785284','1504.373872078528393','test','test','0.0'),('2018-07-02 11:59:59','2018-07-05 15:59:59','ADABTC','4h','0.000022430000000','0.000022620000000','0.033258363258607','0.033540088136856','1482.7625171024122','1482.762517102412176','test','test','0.0'),('2018-07-05 19:59:59','2018-07-05 23:59:59','ADABTC','4h','0.000022380000000','0.000022580000000','0.033320968787107','0.033618743307099','1488.8725999600933','1488.872599960093339','test','test','0.0'),('2018-07-13 23:59:59','2018-07-14 03:59:59','ADABTC','4h','0.000022130000000','0.000021687400000','0.033387140902661','0.032719398084608','1508.6823724654616','1508.682372465461640','test','test','2.00'),('2018-07-14 07:59:59','2018-07-20 19:59:59','ADABTC','4h','0.000021740000000','0.000022270000000','0.033238753609760','0.034049082009630','1528.9215091885924','1528.921509188592381','test','test','0.22'),('2018-07-22 11:59:59','2018-07-22 23:59:59','ADABTC','4h','0.000022970000000','0.000022890000000','0.033418826587509','0.033302435376059','1454.8901431218499','1454.890143121849860','test','test','0.34'),('2018-07-23 03:59:59','2018-07-23 11:59:59','ADABTC','4h','0.000023190000000','0.000022726200000','0.033392961873853','0.032725102636376','1439.9724827017394','1439.972482701739409','test','test','2.00'),('2018-08-09 19:59:59','2018-08-09 23:59:59','ADABTC','4h','0.000019080000000','0.000018710000000','0.033244548709970','0.032599869306265','1742.3767667698924','1742.376766769892356','test','test','1.93'),('2018-08-28 19:59:59','2018-08-28 23:59:59','ADABTC','4h','0.000015000000000','0.000014900000000','0.033101286620257','0.032880611376122','2206.752441350489','2206.752441350488880','test','test','0.66'),('2018-08-29 11:59:59','2018-08-29 15:59:59','ADABTC','4h','0.000014850000000','0.000014700000000','0.033052247677116','0.032718386589468','2225.74058431759','2225.740584317590219','test','test','1.01'),('2018-08-29 19:59:59','2018-08-30 07:59:59','ADABTC','4h','0.000014820000000','0.000014730000000','0.032978056324306','0.032777784727195','2225.239967901859','2225.239967901859018','test','test','0.60'),('2018-09-01 03:59:59','2018-09-02 03:59:59','ADABTC','4h','0.000014840000000','0.000014710000000','0.032933551524948','0.032645050062802','2219.2420165058998','2219.242016505899755','test','test','0.87'),('2018-09-19 07:59:59','2018-09-19 11:59:59','ADABTC','4h','0.000011560000000','0.000011328800000','0.032869440088915','0.032212051287137','2843.3771703213765','2843.377170321376525','test','test','2.00'),('2018-09-19 23:59:59','2018-09-20 03:59:59','ADABTC','4h','0.000011290000000','0.000011320000000','0.032723353688520','0.032810306798410','2898.4369963259514','2898.436996325951441','test','test','0.0'),('2018-09-20 07:59:59','2018-09-20 11:59:59','ADABTC','4h','0.000011280000000','0.000011550000000','0.032742676601829','0.033526410882192','2902.7195568997236','2902.719556899723557','test','test','0.0'),('2018-09-20 15:59:59','2018-09-25 03:59:59','ADABTC','4h','0.000011690000000','0.000012300000000','0.032916839775243','0.034634484964541','2815.811785735063','2815.811785735063040','test','test','0.25'),('2018-09-25 23:59:59','2018-09-26 03:59:59','ADABTC','4h','0.000012580000000','0.000012328400000','0.033298538706198','0.032632567932074','2646.9426634497613','2646.942663449761312','test','test','1.99'),('2018-09-26 07:59:59','2018-09-26 23:59:59','ADABTC','4h','0.000012360000000','0.000012240000000','0.033150545200837','0.032828695247431','2682.0829450515466','2682.082945051546631','test','test','0.97'),('2018-09-27 03:59:59','2018-09-27 07:59:59','ADABTC','4h','0.000012420000000','0.000012210000000','0.033079022988969','0.032519715836982','2663.3673904161924','2663.367390416192393','test','test','1.69'),('2018-09-27 11:59:59','2018-09-28 11:59:59','ADABTC','4h','0.000012370000000','0.000012340000000','0.032954732510750','0.032874809958177','2664.0850857518008','2664.085085751800761','test','test','0.24'),('2018-09-28 15:59:59','2018-10-03 03:59:59','ADABTC','4h','0.000012700000000','0.000012446000000','0.032936971943511','0.032278232504641','2593.4623577567972','2593.462357756797246','test','test','1.99'),('2018-10-05 23:59:59','2018-10-06 03:59:59','ADABTC','4h','0.000012570000000','0.000012500000000','0.032790585401540','0.032607980709566','2608.6384567653317','2608.638456765331739','test','test','0.55'),('2018-10-06 07:59:59','2018-10-06 11:59:59','ADABTC','4h','0.000012500000000','0.000012500000000','0.032750006581102','0.032750006581102','2620.0005264881243','2620.000526488124251','test','test','0.0'),('2018-10-07 15:59:59','2018-10-11 03:59:59','ADABTC','4h','0.000012700000000','0.000012446000000','0.032750006581102','0.032095006449480','2578.7406756772875','2578.740675677287527','test','test','1.99'),('2018-10-17 19:59:59','2018-10-17 23:59:59','ADABTC','4h','0.000012020000000','0.000011880000000','0.032604450996297','0.032224698655242','2712.516721821686','2712.516721821686133','test','test','1.16'),('2018-10-20 11:59:59','2018-10-20 15:59:59','ADABTC','4h','0.000011890000000','0.000011880000000','0.032520061587173','0.032492710820489','2735.0766683913653','2735.076668391365274','test','test','0.08'),('2018-10-20 19:59:59','2018-10-20 23:59:59','ADABTC','4h','0.000011850000000','0.000011780000000','0.032513983639021','0.032321917912883','2743.7960876811258','2743.796087681125755','test','test','0.59'),('2018-10-21 03:59:59','2018-10-21 07:59:59','ADABTC','4h','0.000011890000000','0.000011850000000','0.032471302366546','0.032362063334194','2730.975808792786','2730.975808792786211','test','test','0.33'),('2018-11-02 23:59:59','2018-11-03 07:59:59','ADABTC','4h','0.000011360000000','0.000011280000000','0.032447027026024','0.032218526835700','2856.252379051369','2856.252379051369189','test','test','0.70'),('2018-11-04 03:59:59','2018-11-04 07:59:59','ADABTC','4h','0.000011310000000','0.000011640000000','0.032396249205952','0.033341497856524','2864.38985021676','2864.389850216759896','test','test','0.0'),('2018-11-04 11:59:59','2018-11-09 15:59:59','ADABTC','4h','0.000011630000000','0.000011680000000','0.032606304461634','0.032746486338081','2803.637528945333','2803.637528945333088','test','test','0.0'),('2018-11-09 19:59:59','2018-11-09 23:59:59','ADABTC','4h','0.000011720000000','0.000011620000000','0.032637455989734','0.032358979402791','2784.765869431191','2784.765869431190822','test','test','0.85'),('2018-11-10 15:59:59','2018-11-10 23:59:59','ADABTC','4h','0.000011730000000','0.000011740000000','0.032575572303746','0.032603343465130','2777.1161384267884','2777.116138426788439','test','test','0.0'),('2018-11-11 07:59:59','2018-11-11 15:59:59','ADABTC','4h','0.000011930000000','0.000011780000000','0.032581743672943','0.032172082185018','2731.076586164515','2731.076586164514993','test','test','1.25'),('2018-11-11 19:59:59','2018-11-12 11:59:59','ADABTC','4h','0.000011950000000','0.000011850000000','0.032490707786737','0.032218819018647','2718.8876808985024','2718.887680898502367','test','test','1.50'),('2018-11-12 15:59:59','2018-11-13 11:59:59','ADABTC','4h','0.000011990000000','0.000011840000000','0.032430288060495','0.032024571362490','2704.777986696821','2704.777986696820790','test','test','1.33'),('2018-11-13 15:59:59','2018-11-13 19:59:59','ADABTC','4h','0.000011830000000','0.000011640000000','0.032340128794272','0.031820718441701','2733.738697740622','2733.738697740621774','test','test','1.60'),('2018-12-02 03:59:59','2018-12-02 07:59:59','ADABTC','4h','0.000010000000000','0.000009960000000','0.032224704271478','0.032095805454392','3222.4704271478','3222.470427147799910','test','test','0.40'),('2018-12-02 11:59:59','2018-12-02 15:59:59','ADABTC','4h','0.000009930000000','0.000009900000000','0.032196060089903','0.032098791026187','3242.3021238573347','3242.302123857334664','test','test','0.30'),('2018-12-02 19:59:59','2018-12-03 15:59:59','ADABTC','4h','0.000010030000000','0.000009900000000','0.032174444742411','0.031757428010954','3207.821011207466','3207.821011207466199','test','test','1.29'),('2018-12-16 15:59:59','2018-12-16 19:59:59','ADABTC','4h','0.000008970000000','0.000009000000000','0.032081774357643','0.032189071261849','3576.5634735387584','3576.563473538758444','test','test','0.0'),('2018-12-16 23:59:59','2018-12-17 03:59:59','ADABTC','4h','0.000008980000000','0.000009010000000','0.032105618114133','0.032212875190238','3575.2358701707008','3575.235870170700764','test','test','0.0'),('2018-12-17 07:59:59','2018-12-17 11:59:59','ADABTC','4h','0.000009020000000','0.000008970000000','0.032129453019934','0.031951351839114','3562.0236164006647','3562.023616400664650','test','test','0.55'),('2018-12-17 15:59:59','2018-12-27 19:59:59','ADABTC','4h','0.000009180000000','0.000010120000000','0.032089874979752','0.035375766317548','3495.6290827616313','3495.629082761631253','test','test','0.0'),('2018-12-28 15:59:59','2019-01-10 15:59:59','ADABTC','4h','0.000010360000000','0.000011970000000','0.032820073054818','0.037920489813337','3167.960719576984','3167.960719576984047','test','test','0.0'),('2019-01-10 19:59:59','2019-01-11 07:59:59','ADABTC','4h','0.000012000000000','0.000012110000000','0.033953499001155','0.034264739408666','2829.458250096259','2829.458250096258780','test','test','0.41'),('2019-01-11 11:59:59','2019-01-12 15:59:59','ADABTC','4h','0.000012010000000','0.000011890000000','0.034022663536158','0.033682720186921','2832.8612436434264','2832.861243643426405','test','test','0.99'),('2019-01-12 19:59:59','2019-01-13 03:59:59','ADABTC','4h','0.000011940000000','0.000011910000000','0.033947120569660','0.033861826296872','2843.1424262697187','2843.142426269718726','test','test','0.25'),('2019-01-13 07:59:59','2019-01-13 15:59:59','ADABTC','4h','0.000011970000000','0.000011790000000','0.033928166286819','0.033417968297544','2834.433273752604','2834.433273752603782','test','test','1.50'),('2019-01-14 19:59:59','2019-01-15 03:59:59','ADABTC','4h','0.000011920000000','0.000011900000000','0.033814788955869','0.033758052732789','2836.811154015828','2836.811154015827924','test','test','0.16'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADABTC','4h','0.000011890000000','0.000011790000000','0.033802180906295','0.033517890066040','2842.9084025479674','2842.908402547967398','test','test','0.84'),('2019-01-15 19:59:59','2019-01-15 23:59:59','ADABTC','4h','0.000011840000000','0.000011830000000','0.033739005164016','0.033710509382627','2849.57813885274','2849.578138852739812','test','test','0.08'),('2019-01-16 03:59:59','2019-01-20 15:59:59','ADABTC','4h','0.000012010000000','0.000012040000000','0.033732672768152','0.033816934232186','2808.715467789527','2808.715467789526883','test','test','0.0'),('2019-01-20 19:59:59','2019-01-20 23:59:59','ADABTC','4h','0.000012070000000','0.000012120000000','0.033751397537938','0.033891212772147','2796.304684170469','2796.304684170469045','test','test','0.0'),('2019-01-21 03:59:59','2019-01-21 07:59:59','ADABTC','4h','0.000012120000000','0.000012020000000','0.033782467589984','0.033503734359044','2787.332309404621','2787.332309404620901','test','test','0.82'),('2019-01-21 11:59:59','2019-01-21 19:59:59','ADABTC','4h','0.000012220000000','0.000012070000000','0.033720526871997','0.033306608784370','2759.453917512057','2759.453917512057160','test','test','1.22'),('2019-01-21 23:59:59','2019-01-22 03:59:59','ADABTC','4h','0.000012060000000','0.000012070000000','0.033628545074747','0.033656429440481','2788.4365733620966','2788.436573362096624','test','test','0.0'),('2019-01-22 19:59:59','2019-01-23 07:59:59','ADABTC','4h','0.000012180000000','0.000012090000000','0.033634741600466','0.033386209027064','2761.4730378050535','2761.473037805053536','test','test','0.73'),('2019-01-23 11:59:59','2019-01-23 19:59:59','ADABTC','4h','0.000012210000000','0.000012050000000','0.033579512139710','0.033139485772605','2750.164794407007','2750.164794407006866','test','test','1.31'),('2019-02-08 15:59:59','2019-02-08 19:59:59','ADABTC','4h','0.000011360000000','0.000011240000000','0.033481728502575','0.033128048271914','2947.335255508373','2947.335255508372938','test','test','1.05'),('2019-02-08 23:59:59','2019-02-10 07:59:59','ADABTC','4h','0.000011130000000','0.000011140000000','0.033403132895762','0.033433144695309','3001.1799546955576','3001.179954695557626','test','test','0.0'),('2019-02-10 11:59:59','2019-02-10 15:59:59','ADABTC','4h','0.000011220000000','0.000011210000000','0.033409802184550','0.033380025177255','2977.7007294607643','2977.700729460764251','test','test','0.08'),('2019-02-10 19:59:59','2019-02-14 03:59:59','ADABTC','4h','0.000011450000000','0.000011330000000','0.033403185071818','0.033053108023030','2917.3087398967295','2917.308739896729548','test','test','1.31'),('2019-02-14 07:59:59','2019-02-14 11:59:59','ADABTC','4h','0.000011280000000','0.000011180000000','0.033325390172087','0.033029952315951','2954.3785613552204','2954.378561355220427','test','test','0.88'),('2019-02-16 03:59:59','2019-02-16 07:59:59','ADABTC','4h','0.000011300000000','0.000011290000000','0.033259737315168','0.033230303919314','2943.339585413077','2943.339585413077202','test','test','0.08'),('2019-02-16 11:59:59','2019-02-16 15:59:59','ADABTC','4h','0.000011280000000','0.000011340000000','0.033253196560534','0.033430075265643','2947.9784184870173','2947.978418487017279','test','test','0.0'),('2019-02-16 19:59:59','2019-02-17 03:59:59','ADABTC','4h','0.000011340000000','0.000011290000000','0.033292502939447','0.033145710598444','2935.8468200570255','2935.846820057025525','test','test','0.44'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ADABTC','4h','0.000011290000000','0.000011310000000','0.033259882419224','0.033318801608629','2945.9594702589707','2945.959470258970669','test','test','0.0'),('2019-02-17 19:59:59','2019-02-17 23:59:59','ADABTC','4h','0.000011300000000','0.000011340000000','0.033272975572425','0.033390756016929','2944.5111126039724','2944.511112603972379','test','test','0.0'),('2019-02-18 03:59:59','2019-02-21 11:59:59','ADABTC','4h','0.000011540000000','0.000011460000000','0.033299149004537','0.033068305683882','2885.5415081921046','2885.541508192104629','test','test','0.69'),('2019-02-21 15:59:59','2019-02-21 19:59:59','ADABTC','4h','0.000011480000000','0.000011400000000','0.033247850488836','0.033016158150935','2896.154223766183','2896.154223766182895','test','test','0.69'),('2019-02-22 19:59:59','2019-02-24 15:59:59','ADABTC','4h','0.000011600000000','0.000011368000000','0.033196363302636','0.032532436036583','2861.7554571237547','2861.755457123754695','test','test','2.00'),('2019-03-09 07:59:59','2019-04-02 07:59:59','ADABTC','4h','0.000011250000000','0.000016690000000','0.033048823910179','0.049029766316523','2937.673236460385','2937.673236460384942','test','test','0.0'),('2019-04-02 11:59:59','2019-04-08 03:59:59','ADABTC','4h','0.000016660000000','0.000016860000000','0.036600144444922','0.037039521929255','2196.887421664012','2196.887421664011981','test','test','0.0'),('2019-05-15 15:59:59','2019-05-15 19:59:59','ADABTC','4h','0.000011010000000','0.000010970000000','0.036697783885885','0.036564458603829','3333.132051397396','3333.132051397396026','test','test','0.36'),('2019-05-15 23:59:59','2019-05-16 11:59:59','ADABTC','4h','0.000011490000000','0.000011260200000','0.036668156045428','0.035934792924519','3191.3103607857647','3191.310360785764715','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','ADABTC','4h','0.000011690000000','0.000011456200000','0.036505186463004','0.035775082733744','3122.770441659899','3122.770441659899006','test','test','2.00'),('2019-05-16 23:59:59','2019-05-17 03:59:59','ADABTC','4h','0.000011180000000','0.000011030000000','0.036342941189835','0.035855334644354','3250.710303205307','3250.710303205306900','test','test','1.34'),('2019-05-17 07:59:59','2019-05-17 11:59:59','ADABTC','4h','0.000010980000000','0.000010850000000','0.036234584179728','0.035805577263210','3300.0532039825544','3300.053203982554351','test','test','1.18'),('2019-05-17 15:59:59','2019-05-17 19:59:59','ADABTC','4h','0.000010940000000','0.000010990000000','0.036139249309391','0.036304419553035','3303.4048728876696','3303.404872887669626','test','test','0.0'),('2019-05-17 23:59:59','2019-05-18 07:59:59','ADABTC','4h','0.000011240000000','0.000011015200000','0.036175953807979','0.035452434731819','3218.501228467853','3218.501228467852798','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:02:11
