-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 15:59:59','2018-04-23 03:59:59','XRPETH','4h','0.001335000000000','0.001344130000000','1.297777777777778','1.306653216812318','972.1181856013316','972.118185601331561','test','test','0.11'),('2018-04-23 07:59:59','2018-04-23 15:59:59','XRPETH','4h','0.001358300000000','0.001350000000000','1.299750097563231','1.291807871390976','956.8947195488706','956.894719548870626','test','test','0.61'),('2018-04-23 19:59:59','2018-04-23 23:59:59','XRPETH','4h','0.001354670000000','0.001358950000000','1.297985158413841','1.302086065998723','958.15597777602','958.155977776019995','test','test','0.0'),('2018-04-24 03:59:59','2018-04-24 07:59:59','XRPETH','4h','0.001358430000000','0.001337070000000','1.298896471210482','1.278472578462931','956.1747540988358','956.174754098835820','test','test','1.57'),('2018-05-23 19:59:59','2018-05-25 19:59:59','XRPETH','4h','0.001027800000000','0.001034590000000','1.294357828377692','1.302908800993653','1259.3479552225067','1259.347955222506698','test','test','1.12'),('2018-05-25 23:59:59','2018-06-10 11:59:59','XRPETH','4h','0.001034050000000','0.001095710000000','1.296258044514573','1.373553408399075','1253.573854759995','1253.573854759994902','test','test','0.70'),('2018-06-10 19:59:59','2018-06-10 23:59:59','XRPETH','4h','0.001101010000000','0.001109660000000','1.313434792044462','1.323753691011033','1192.9362967134375','1192.936296713437514','test','test','0.0'),('2018-06-11 03:59:59','2018-06-11 07:59:59','XRPETH','4h','0.001096150000000','0.001085340000000','1.315727880703700','1.302752449977607','1200.3173659660629','1200.317365966062880','test','test','0.98'),('2018-06-11 15:59:59','2018-06-11 19:59:59','XRPETH','4h','0.001099530000000','0.001111530000000','1.312844451653457','1.327172513115938','1194.005121873398','1194.005121873397911','test','test','0.0'),('2018-06-11 23:59:59','2018-06-12 15:59:59','XRPETH','4h','0.001126940000000','0.001104401200000','1.316028465311786','1.289707896005550','1167.7892925193762','1167.789292519376204','test','test','1.99'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001106420000000','1.310179449910400','1.283975860912192','1160.4778121438444','1160.477812143844403','test','test','2.00'),('2018-06-13 23:59:59','2018-06-14 03:59:59','XRPETH','4h','0.001112930000000','0.001125040000000','1.304356430133021','1.318549377011001','1172.0022194864193','1172.002219486419335','test','test','0.0'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001109115000000','1.307510418328128','1.281360209961566','1155.2996848492403','1155.299684849240293','test','test','2.00'),('2018-06-24 19:59:59','2018-06-24 23:59:59','XRPETH','4h','0.001052870000000','0.001041280000000','1.301699260913336','1.287370146745409','1236.3342681559316','1236.334268155931568','test','test','1.10'),('2018-06-25 03:59:59','2018-06-25 11:59:59','XRPETH','4h','0.001054250000000','0.001049570000000','1.298515013320463','1.292750678236432','1231.6955307758722','1231.695530775872157','test','test','0.44'),('2018-06-26 01:59:59','2018-06-27 03:59:59','XRPETH','4h','0.001052620000000','0.001059700000000','1.297234049968456','1.305959342166758','1232.3859037149743','1232.385903714974347','test','test','0.0'),('2018-06-27 07:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001061300000000','0.001057100000000','1.299173003790301','1.294031642614461','1224.1336132952993','1224.133613295299256','test','test','0.59'),('2018-06-28 19:59:59','2018-06-28 23:59:59','XRPETH','4h','0.001054730000000','0.001060350000000','1.298030479084559','1.304946875975190','1230.6756033151223','1230.675603315122316','test','test','0.0'),('2018-06-29 03:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001061660000000','0.001042860000000','1.299567456171366','1.276554562988971','1224.0900628933612','1224.090062893361164','test','test','1.77'),('2018-07-03 03:59:59','2018-07-03 23:59:59','XRPETH','4h','0.001052550000000','0.001051360000000','1.294453479908611','1.292989986828861','1229.8261174372822','1229.826117437282164','test','test','0.11'),('2018-07-04 00:22:26','2018-07-04 11:59:59','XRPETH','4h','0.001045710000000','0.001034280000000','1.294128259224222','1.279982955073996','1237.5594182175005','1237.559418217500479','test','test','1.09'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XRPETH','4h','0.001048610000000','0.001065490000000','1.290984858301950','1.311766487704814','1231.1391826341062','1231.139182634106191','test','test','0.0'),('2018-07-04 23:59:59','2018-07-05 03:59:59','XRPETH','4h','0.001049450000000','0.001048280000000','1.295602998169253','1.294158569651593','1234.5542885980785','1234.554288598078529','test','test','0.11'),('2018-07-10 19:59:59','2018-07-10 23:59:59','XRPETH','4h','0.001023610000000','0.001023710000000','1.295282014054218','1.295408554632568','1265.4057835056492','1265.405783505649197','test','test','0.0'),('2018-07-11 03:59:59','2018-07-11 07:59:59','XRPETH','4h','0.001027970000000','0.001022150000000','1.295310134182740','1.287976549563594','1260.0660857639227','1260.066085763922729','test','test','0.56'),('2018-07-11 19:59:59','2018-07-11 23:59:59','XRPETH','4h','0.001023320000000','0.001010680000000','1.293680448711819','1.277700969299985','1264.1993205564422','1264.199320556442217','test','test','1.23'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XRPETH','4h','0.001014080000000','0.001013990000000','1.290129453286967','1.290014953789101','1272.216642954172','1272.216642954171903','test','test','0.00'),('2018-07-17 23:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001016060000000','0.001015460000000','1.290104008954107','1.289342181497684','1269.7124273705365','1269.712427370536489','test','test','0.05'),('2018-07-18 23:59:59','2018-07-19 03:59:59','XRPETH','4h','0.001018320000000','0.001006390000000','1.289934713963791','1.274822645912895','1266.728252380186','1266.728252380185950','test','test','1.17'),('2018-07-19 11:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001018000000000','0.001018880000000','1.286576476619148','1.287688644889703','1263.82758017598','1263.827580175980074','test','test','0.0'),('2018-07-31 11:59:59','2018-08-06 23:59:59','XRPETH','4h','0.000999000000000','0.001017910000000','1.286823625123715','1.311181818067748','1288.1117368605758','1288.111736860575775','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XRPETH','4h','0.000987780000000','0.000976100000000','1.292236556889056','1.276956511753029','1308.2230424680151','1308.223042468015137','test','test','1.18'),('2018-08-14 11:59:59','2018-08-14 23:59:59','XRPETH','4h','0.000995260000000','0.000979220000000','1.288840991303272','1.268069525052740','1294.9791926765593','1294.979192676559251','test','test','1.61'),('2018-08-15 03:59:59','2018-08-15 19:59:59','XRPETH','4h','0.000999340000000','0.000991860000000','1.284225109914265','1.274612761942445','1285.07325826472','1285.073258264719925','test','test','0.74'),('2018-08-15 23:59:59','2018-08-31 15:59:59','XRPETH','4h','0.000998660000000','0.001186000000000','1.282089032587194','1.522597873799303','1283.8093370989068','1283.809337098906781','test','test','0.97'),('2018-08-31 19:59:59','2018-09-01 15:59:59','XRPETH','4h','0.001190000000000','0.001167880000000','1.335535441745441','1.310710194710643','1122.298690542387','1122.298690542387021','test','test','1.85'),('2018-09-01 19:59:59','2018-09-01 23:59:59','XRPETH','4h','0.001169310000000','0.001175590000000','1.330018720182152','1.337161836689104','1137.4389342280083','1137.438934228008293','test','test','0.0'),('2018-09-04 07:59:59','2018-09-04 11:59:59','XRPETH','4h','0.001169050000000','0.001168980000000','1.331606079405919','1.331526345925265','1139.0497236268075','1139.049723626807463','test','test','0.00'),('2018-09-05 11:59:59','2018-09-05 19:59:59','XRPETH','4h','0.001172280000000','0.001186520000000','1.331588360854663','1.347763522299515','1135.896168880014','1135.896168880014102','test','test','0.22'),('2018-09-05 23:59:59','2018-09-13 23:59:59','XRPETH','4h','0.001222490000000','0.001321790000000','1.335182841175741','1.443636616772066','1092.1830372238146','1092.183037223814608','test','test','0.0'),('2018-09-17 19:59:59','2018-10-02 23:59:59','XRPETH','4h','0.001370000000000','0.002294530000000','1.359283680197146','2.276581885199093','992.1778687570412','992.177868757041210','test','test','0.0'),('2018-10-03 03:59:59','2018-10-05 11:59:59','XRPETH','4h','0.002368040000000','0.002324530000000','1.563127725753135','1.534407059148044','660.0934636885925','660.093463688592465','test','test','1.83'),('2018-10-15 23:59:59','2018-10-16 03:59:59','XRPETH','4h','0.002157190000000','0.002156010000000','1.556745355396448','1.555893803368408','721.6542610509265','721.654261050926493','test','test','0.05'),('2018-10-16 07:59:59','2018-10-22 15:59:59','XRPETH','4h','0.002197600000000','0.002233800000000','1.556556121612439','1.582196516407839','708.2981987679462','708.298198767946246','test','test','0.46'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XRPETH','4h','0.002233680000000','0.002205610000000','1.562253987122528','1.542621600469771','699.408145805365','699.408145805365052','test','test','1.25'),('2018-10-23 23:59:59','2018-10-27 23:59:59','XRPETH','4h','0.002282400000000','0.002249540000000','1.557891234533026','1.535462078396172','682.5671374575124','682.567137457512445','test','test','1.43'),('2018-10-28 03:59:59','2018-10-28 15:59:59','XRPETH','4h','0.002253130000000','0.002253310000000','1.552906977613725','1.553031037590722','689.2220944258545','689.222094425854493','test','test','0.17'),('2018-10-28 19:59:59','2018-10-29 11:59:59','XRPETH','4h','0.002255790000000','0.002232930000000','1.552934546497503','1.537197228869119','688.4215935426181','688.421593542618098','test','test','1.01'),('2018-10-29 15:59:59','2018-10-29 19:59:59','XRPETH','4h','0.002256860000000','0.002252630000000','1.549437364802306','1.546533276798126','686.5456274657295','686.545627465729467','test','test','0.18'),('2018-10-29 23:59:59','2018-10-31 15:59:59','XRPETH','4h','0.002263810000000','0.002286340000000','1.548792011912488','1.564205975110984','684.1528272745893','684.152827274589299','test','test','0.06'),('2018-10-31 19:59:59','2018-11-04 07:59:59','XRPETH','4h','0.002287640000000','0.002256960000000','1.552217337067709','1.531400238266658','678.5234289782087','678.523428978208699','test','test','1.34'),('2018-11-05 15:59:59','2018-11-08 19:59:59','XRPETH','4h','0.002333720000000','0.002361690000000','1.547591315111920','1.566139439601439','663.1435284061157','663.143528406115706','test','test','0.0'),('2018-11-08 23:59:59','2018-11-09 03:59:59','XRPETH','4h','0.002331060000000','0.002417000000000','1.551713120554036','1.608920668013309','665.668460079979','665.668460079979013','test','test','0.0'),('2018-11-09 07:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002399320000000','0.002506570000000','1.564425908878319','1.634356005208613','652.0288702125263','652.028870212526272','test','test','0.97'),('2018-11-14 23:59:59','2018-11-29 15:59:59','XRPETH','4h','0.002586730000000','0.003208670000000','1.579965930285051','1.959844777587044','610.7966159147072','610.796615914707218','test','test','0.98'),('2018-11-29 19:59:59','2018-11-30 11:59:59','XRPETH','4h','0.003212460000000','0.003167190000000','1.664383451907716','1.640928953215791','518.102467239348','518.102467239348016','test','test','1.40'),('2018-11-30 15:59:59','2018-12-01 11:59:59','XRPETH','4h','0.003184440000000','0.003127700000000','1.659171341087288','1.629608409490746','521.0245258467071','521.024525846707093','test','test','1.78'),('2018-12-02 03:59:59','2018-12-02 07:59:59','XRPETH','4h','0.003172320000000','0.003148950000000','1.652601800732501','1.640427334069895','520.9442303211847','520.944230321184705','test','test','0.73'),('2018-12-02 23:59:59','2018-12-03 03:59:59','XRPETH','4h','0.003168150000000','0.003183900000000','1.649896363696366','1.658098585096305','520.7759619009095','520.775961900909465','test','test','0.0'),('2018-12-03 07:59:59','2018-12-04 11:59:59','XRPETH','4h','0.003196100000000','0.003203380000000','1.651719079563019','1.655481325706512','516.7920526776444','516.792052677644392','test','test','0.47'),('2018-12-04 15:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003187180000000','0.003203020000000','1.652555134261573','1.660768185713547','518.5007229781729','518.500722978172917','test','test','0.0'),('2018-12-07 23:59:59','2018-12-08 03:59:59','XRPETH','4h','0.003233320000000','0.003298690000000','1.654380256806457','1.687827870215410','511.6661069137779','511.666106913777924','test','test','0.0'),('2018-12-08 07:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003348520000000','0.003281549600000','1.661813059786224','1.628576798590500','496.2828532564308','496.282853256430826','test','test','2.00'),('2018-12-09 23:59:59','2018-12-16 03:59:59','XRPETH','4h','0.003314520000000','0.003361590000000','1.654427223964952','1.677921995283885','499.14534350824607','499.145343508246071','test','test','0.07'),('2018-12-16 23:59:59','2018-12-17 03:59:59','XRPETH','4h','0.003383980000000','0.003368010000000','1.659648284258048','1.651815914356453','490.44269891017325','490.442698910173249','test','test','0.47'),('2018-12-17 11:59:59','2018-12-17 15:59:59','XRPETH','4h','0.003371540000000','0.003380610000000','1.657907757613249','1.662367803574902','491.7360486938459','491.736048693845873','test','test','0.0'),('2018-12-17 19:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003446030000000','0.003413370000000','1.658898878938061','1.643176544139433','481.39420693901707','481.394206939017067','test','test','0.94'),('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.655405026760588','1.668294406592760','642.54136750607','642.541367506069946','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','XRPETH','4h','0.002590000000000','0.002587550000000','1.658269333389960','1.656700700236754','640.2584298802933','640.258429880293306','test','test','0.09'),('2019-01-15 11:59:59','2019-01-15 15:59:59','XRPETH','4h','0.002607890000000','0.002590000000000','1.657920748244803','1.646547491632715','635.7326222520132','635.732622252013243','test','test','0.68'),('2019-01-15 19:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002603960000000','0.002648540000000','1.655393357886561','1.683733822369342','635.721500286702','635.721500286702053','test','test','0.0'),('2019-01-19 15:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002654650000000','0.002688090000000','1.661691238882734','1.682623171539860','625.954923957107','625.954923957106985','test','test','0.17'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.666342779473207','1.679908905354432','614.1297365878243','614.129736587824254','test','test','0.25'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.669357474113479','1.704420114759116','606.095776069782','606.095776069782005','test','test','0.93'),('2019-02-03 11:59:59','2019-02-03 19:59:59','XRPETH','4h','0.002835600000000','0.002805030000000','1.677149172034732','1.659068183817388','591.4618324286681','591.461832428668117','test','test','1.07'),('2019-02-03 23:59:59','2019-02-04 03:59:59','XRPETH','4h','0.002816620000000','0.002801850000000','1.673131174653100','1.664357485816968','594.0209096907284','594.020909690728445','test','test','0.52'),('2019-02-04 07:59:59','2019-02-04 11:59:59','XRPETH','4h','0.002804000000000','0.002812320000000','1.671181466022848','1.676140178504057','595.9990962991614','595.999096299161351','test','test','0.0'),('2019-02-04 15:59:59','2019-02-04 19:59:59','XRPETH','4h','0.002798000000000','0.002792180000000','1.672283402129784','1.668804957025997','597.6709800320884','597.670980032088437','test','test','0.20'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.671510414328942','1.658981820104876','593.77223810738','593.772238107379962','test','test','0.74'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.668726282279150','1.647576362869204','589.7913945885626','589.791394588562639','test','test','1.26'),('2019-02-07 19:59:59','2019-02-07 23:59:59','XRPETH','4h','0.002805900000000','0.002789410000000','1.664026300188050','1.654246980294219','593.0454756719948','593.045475671994836','test','test','0.58'),('2019-02-25 19:59:59','2019-02-26 07:59:59','XRPETH','4h','0.002380130000000','0.002332527400000','1.661853117989421','1.628616055629633','698.2194745620708','698.219474562070786','test','test','2.00'),('2019-02-26 11:59:59','2019-02-27 03:59:59','XRPETH','4h','0.002346660000000','0.002309270000000','1.654467104131691','1.628106010056075','705.0305984385001','705.030598438500078','test','test','1.59'),('2019-02-27 07:59:59','2019-02-27 11:59:59','XRPETH','4h','0.002286200000000','0.002282650000000','1.648609083225998','1.646049131233411','721.1132373484377','721.113237348437679','test','test','0.15'),('2019-02-27 19:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002304900000000','0.002287290000000','1.648040205005423','1.635448774570200','715.0159247713234','715.015924771323398','test','test','0.76'),('2019-02-28 23:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002317970000000','0.002341950000000','1.645242109353152','1.662262565089114','709.7771366122736','709.777136612273580','test','test','0.08'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.649024432850032','1.642249353591440','710.9212233570298','710.921223357029817','test','test','0.41'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.647518859681456','1.649716215204771','711.1182923348828','711.118292334882767','test','test','0.0'),('2019-03-12 15:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002324780000000','0.002332830000000','1.648007160908859','1.653713704171153','708.8873617756775','708.887361775677505','test','test','0.03'),('2019-03-15 11:59:59','2019-03-15 15:59:59','XRPETH','4h','0.002331100000000','0.002308000000000','1.649275281633814','1.632931813311674','707.5094511749019','707.509451174901869','test','test','0.99'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002206244600000','1.645643399784449','1.612730531788760','730.9844664498034','730.984466449803449','test','test','1.99'),('2019-04-05 11:59:59','2019-04-05 15:59:59','XRPETH','4h','0.002215810000000','0.002199970000000','1.638329429118740','1.626617622530070','739.3817290827013','739.381729082701327','test','test','0.71'),('2019-04-05 19:59:59','2019-04-05 23:59:59','XRPETH','4h','0.002203470000000','0.002191210000000','1.635726805432369','1.626625700976851','742.3413095855036','742.341309585503609','test','test','0.55'),('2019-04-06 03:59:59','2019-04-06 07:59:59','XRPETH','4h','0.002192160000000','0.002162550000000','1.633704337775588','1.611637524476589','745.2486760891485','745.248676089148489','test','test','1.35');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:25:47
