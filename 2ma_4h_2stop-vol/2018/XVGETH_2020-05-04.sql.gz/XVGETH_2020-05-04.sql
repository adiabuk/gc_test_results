-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-19 15:59:59','2018-04-14 19:59:59','XVGETH','4h','0.000056730000000','0.000172950000000','1.297777777777778','3.956472178153828','22876.39305090389','22876.393050903890980','test','test','1.26'),('2018-04-16 23:59:59','2018-04-17 11:59:59','XVGETH','4h','0.000183780000000','0.000208460000000','1.888598755639122','2.142220571338183','10276.410684726967','10276.410684726966792','test','test','0.0'),('2018-04-30 23:59:59','2018-05-01 03:59:59','XVGETH','4h','0.000115250000000','0.000112945000000','1.944959159127803','1.906059975945247','16876.001380718462','16876.001380718462315','test','test','1.99'),('2018-05-01 11:59:59','2018-05-01 19:59:59','XVGETH','4h','0.000121250000000','0.000118825000000','1.936314896198345','1.897588598274378','15969.607391326559','15969.607391326559082','test','test','2.00'),('2018-07-01 23:59:59','2018-07-05 11:59:59','XVGETH','4h','0.000055360000000','0.000054280000000','1.927709052215242','1.890102011456708','34821.33403567995','34821.334035679952649','test','test','1.95'),('2018-07-16 15:59:59','2018-07-16 19:59:59','XVGETH','4h','0.000051710000000','0.000051860000000','1.919351932046679','1.924919574471877','37117.61616798838','37117.616167988380766','test','test','0.0'),('2018-07-16 23:59:59','2018-07-17 03:59:59','XVGETH','4h','0.000052200000000','0.000051210000000','1.920589185918945','1.884164218599792','36792.89628197212','36792.896281972120050','test','test','1.89'),('2018-07-17 11:59:59','2018-07-17 15:59:59','XVGETH','4h','0.000051800000000','0.000052000000000','1.912494748736911','1.919878898345934','36920.74804511412','36920.748045114116394','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 07:59:59','XVGETH','4h','0.000052160000000','0.000051120000000','1.914135670872249','1.875970389091054','36697.386328072265','36697.386328072265314','test','test','1.99'),('2018-07-25 07:59:59','2018-07-25 19:59:59','XVGETH','4h','0.000051960000000','0.000051270000000','1.905654497143095','1.880348461672950','36675.413724847866','36675.413724847865524','test','test','1.32'),('2018-07-26 03:59:59','2018-07-26 07:59:59','XVGETH','4h','0.000053570000000','0.000052498600000','1.900030933705285','1.862030315031179','35468.189914229704','35468.189914229704300','test','test','1.99'),('2018-07-30 07:59:59','2018-07-30 15:59:59','XVGETH','4h','0.000052400000000','0.000052000000000','1.891586351777706','1.877146761306121','36098.97617896385','36098.976178963850543','test','test','0.76'),('2018-07-30 23:59:59','2018-08-02 11:59:59','XVGETH','4h','0.000053110000000','0.000052047800000','1.888377553895132','1.850610002817229','35555.969758899104','35555.969758899103908','test','test','1.99'),('2018-08-17 03:59:59','2018-08-22 19:59:59','XVGETH','4h','0.000044330000000','0.000045950000000','1.879984764766708','1.948687118002036','42408.86002180709','42408.860021807093290','test','test','0.0'),('2018-08-24 19:59:59','2018-08-30 15:59:59','XVGETH','4h','0.000046810000000','0.000050000000000','1.895251954374559','2.024409265514376','40488.185310287525','40488.185310287524771','test','test','0.0'),('2018-09-01 03:59:59','2018-09-13 23:59:59','XVGETH','4h','0.000051930000000','0.000063800000000','1.923953579072297','2.363724982569085','37048.98091801072','37048.980918010718597','test','test','0.0'),('2018-09-17 19:59:59','2018-09-18 15:59:59','XVGETH','4h','0.000064960000000','0.000063660800000','2.021680557627138','1.981246946474595','31121.92976642762','31121.929766427620052','test','test','2.00'),('2018-09-18 23:59:59','2018-09-19 03:59:59','XVGETH','4h','0.000063760000000','0.000064400000000','2.012695310704351','2.032898023986201','31566.739502891327','31566.739502891326993','test','test','0.0'),('2018-09-19 19:59:59','2018-09-21 19:59:59','XVGETH','4h','0.000065010000000','0.000064050000000','2.017184802544762','1.987397117412583','31028.83867935336','31028.838679353360931','test','test','1.47'),('2018-09-21 23:59:59','2018-09-22 03:59:59','XVGETH','4h','0.000064400000000','0.000063430000000','2.010565316959833','1.980281957372084','31219.95833788561','31219.958337885611400','test','test','1.50'),('2018-09-25 07:59:59','2018-09-25 11:59:59','XVGETH','4h','0.000064350000000','0.000064930000000','2.003835681495889','2.021896671321338','31139.637630083744','31139.637630083743716','test','test','0.0'),('2018-09-25 15:59:59','2018-09-25 23:59:59','XVGETH','4h','0.000064770000000','0.000063740000000','2.007849234790433','1.975919565007599','30999.679400809524','30999.679400809523941','test','test','1.59'),('2018-09-26 03:59:59','2018-09-26 19:59:59','XVGETH','4h','0.000064950000000','0.000064360000000','2.000753752616470','1.982579084193934','30804.522750061114','30804.522750061114493','test','test','0.90'),('2018-09-27 15:59:59','2018-09-28 03:59:59','XVGETH','4h','0.000065550000000','0.000064239000000','1.996714937411462','1.956780638663233','30460.944888046717','30460.944888046717097','test','test','2.00'),('2018-09-28 07:59:59','2018-09-28 11:59:59','XVGETH','4h','0.000064950000000','0.000064440000000','1.987840648800745','1.972231738394457','30605.706678995295','30605.706678995295078','test','test','0.78'),('2018-09-28 19:59:59','2018-09-29 03:59:59','XVGETH','4h','0.000064590000000','0.000064400000000','1.984372002043791','1.978534710196936','30722.5886676543','30722.588667654301389','test','test','0.55'),('2018-09-30 15:59:59','2018-10-10 07:59:59','XVGETH','4h','0.000065880000000','0.000069190000000','1.983074826077823','2.082710188468801','30101.317942893496','30101.317942893496365','test','test','0.65'),('2018-10-10 11:59:59','2018-10-15 03:59:59','XVGETH','4h','0.000070300000000','0.000070410000000','2.005216017720263','2.008353624575871','28523.698687343713','28523.698687343712663','test','test','0.0'),('2018-10-19 19:59:59','2018-10-20 03:59:59','XVGETH','4h','0.000070520000000','0.000069680000000','2.005913263688176','1.982019798834261','28444.60101656518','28444.601016565178725','test','test','1.19'),('2018-10-21 11:59:59','2018-10-22 07:59:59','XVGETH','4h','0.000070710000000','0.000070430000000','2.000603604831750','1.992681542756331','28293.07884078278','28293.078840782778570','test','test','0.66'),('2018-10-23 15:59:59','2018-10-27 23:59:59','XVGETH','4h','0.000070180000000','0.000071810000000','1.998843146592769','2.045268258148002','28481.663530817452','28481.663530817451829','test','test','0.0'),('2018-10-28 15:59:59','2018-10-29 11:59:59','XVGETH','4h','0.000072440000000','0.000070991200000','2.009159838049487','1.968976641288497','27735.503010070224','27735.503010070224263','test','test','2.00'),('2018-11-27 23:59:59','2018-12-04 07:59:59','XVGETH','4h','0.000055290000000','0.000064780000000','2.000230238769267','2.343550639672149','36177.0706957726','36177.070695772599720','test','test','0.0'),('2018-12-05 03:59:59','2018-12-06 03:59:59','XVGETH','4h','0.000065830000000','0.000064513400000','2.076523661192130','2.034993187968287','31543.728713233024','31543.728713233023882','test','test','2.00'),('2018-12-06 07:59:59','2018-12-06 15:59:59','XVGETH','4h','0.000065040000000','0.000063739200000','2.067294667142387','2.025948773799539','31784.973357047766','31784.973357047765603','test','test','2.00'),('2018-12-07 07:59:59','2018-12-08 03:59:59','XVGETH','4h','0.000065220000000','0.000064820000000','2.058106690843977','2.045484141375446','31556.373671327456','31556.373671327455668','test','test','1.51'),('2018-12-12 11:59:59','2018-12-12 15:59:59','XVGETH','4h','0.000064700000000','0.000064700000000','2.055301679850969','2.055301679850969','31766.64111052503','31766.641110525029944','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 11:59:59','XVGETH','4h','0.000065250000000','0.000064050000000','2.055301679850969','2.017503028267503','31498.876319555086','31498.876319555085502','test','test','1.83'),('2018-12-13 19:59:59','2018-12-13 23:59:59','XVGETH','4h','0.000064960000000','0.000064020000000','2.046901979499088','2.017282400362248','31510.190571106647','31510.190571106646530','test','test','1.44'),('2018-12-14 19:59:59','2018-12-15 03:59:59','XVGETH','4h','0.000069210000000','0.000067825800000','2.040319850802013','1.999513453785973','29480.130773038763','29480.130773038763436','test','test','1.99'),('2018-12-15 15:59:59','2018-12-16 19:59:59','XVGETH','4h','0.000066820000000','0.000065483600000','2.031251762576226','1.990626727324701','30398.85906279895','30398.859062798950617','test','test','2.00'),('2018-12-17 15:59:59','2018-12-18 03:59:59','XVGETH','4h','0.000066180000000','0.000065350000000','2.022223976964776','1.996862147093504','30556.421531652697','30556.421531652697013','test','test','1.25'),('2018-12-18 19:59:59','2018-12-18 23:59:59','XVGETH','4h','0.000065930000000','0.000065000000000','2.016588014771160','1.988142286669579','30586.804410301225','30586.804410301225289','test','test','1.41'),('2018-12-19 03:59:59','2018-12-22 23:59:59','XVGETH','4h','0.000067260000000','0.000068960000000','2.010266741859697','2.061076338368193','29887.997946174506','29887.997946174506069','test','test','0.98'),('2019-01-10 15:59:59','2019-01-10 19:59:59','XVGETH','4h','0.000057520000000','0.000056369600000','2.021557763306030','1.981126608039909','35145.30186554294','35145.301865542940504','test','test','2.00'),('2019-01-10 23:59:59','2019-01-11 23:59:59','XVGETH','4h','0.000059140000000','0.000057957200000','2.012573062135780','1.972321600893064','34030.6571209973','34030.657120997297170','test','test','1.99'),('2019-01-15 15:59:59','2019-01-27 11:59:59','XVGETH','4h','0.000055350000000','0.000056570000000','2.003628292970733','2.047791373683006','36199.246485469426','36199.246485469426261','test','test','1.19'),('2019-01-28 03:59:59','2019-01-28 07:59:59','XVGETH','4h','0.000057070000000','0.000056520000000','2.013442310906794','1.994038188408130','35280.222724843064','35280.222724843064498','test','test','0.96'),('2019-01-28 11:59:59','2019-01-29 11:59:59','XVGETH','4h','0.000057450000000','0.000057470000000','2.009130283684868','2.009829719814958','34971.80650452338','34971.806504523381591','test','test','1.35'),('2019-01-29 15:59:59','2019-01-30 15:59:59','XVGETH','4h','0.000057510000000','0.000057030000000','2.009285713935999','1.992515462802469','34938.023194853056','34938.023194853056339','test','test','1.02'),('2019-03-02 15:59:59','2019-03-03 03:59:59','XVGETH','4h','0.000045280000000','0.000045260000000','2.005558991461881','2.004673143850811','44292.38055348678','44292.380553486778808','test','test','0.04'),('2019-03-03 11:59:59','2019-03-05 23:59:59','XVGETH','4h','0.000045220000000','0.000046020000000','2.005362136437199','2.040839573614328','44346.79647141087','44346.796471410867525','test','test','0.0'),('2019-03-08 11:59:59','2019-03-10 07:59:59','XVGETH','4h','0.000047270000000','0.000046324600000','2.013246011365450','1.972981091138141','42590.35353004972','42590.353530049716937','test','test','1.99'),('2019-03-12 11:59:59','2019-03-18 19:59:59','XVGETH','4h','0.000049210000000','0.000049580000000','2.004298251314937','2.019368162978959','40729.49098384346','40729.490983843461436','test','test','0.22'),('2019-03-19 15:59:59','2019-03-19 15:59:59','XVGETH','4h','0.000049680000000','0.000049680000000','2.007647120573608','2.007647120573608','40411.57650107908','40411.576501079078298','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:46:41
