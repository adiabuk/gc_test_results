-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-24 11:59:59','2018-03-24 23:59:59','MDABTC','4h','0.000104070000000','0.000102100000000','0.033333333333333','0.032702347778738','320.29723583485475','320.297235834854746','test','test','1.89'),('2018-03-25 15:59:59','2018-03-26 15:59:59','MDABTC','4h','0.000106800000000','0.000104664000000','0.033193114321201','0.032529252034777','310.7969505730441','310.796950573044114','test','test','2.00'),('2018-03-31 19:59:59','2018-03-31 23:59:59','MDABTC','4h','0.000106210000000','0.000106230000000','0.033045589368662','0.033051812057555','311.1344446724644','311.134444672464383','test','test','0.0'),('2018-04-02 15:59:59','2018-04-02 19:59:59','MDABTC','4h','0.000108890000000','0.000106712200000','0.033046972188416','0.032386032744648','303.48950489867246','303.489504898672465','test','test','2.00'),('2018-04-10 19:59:59','2018-04-10 23:59:59','MDABTC','4h','0.000103970000000','0.000103080000000','0.032900096756468','0.032618466612068','316.438364494258','316.438364494257996','test','test','0.85'),('2018-04-11 03:59:59','2018-04-15 07:59:59','MDABTC','4h','0.000103640000000','0.000108320000000','0.032837512279935','0.034320333174089','316.8420714003731','316.842071400373072','test','test','0.0'),('2018-04-15 11:59:59','2018-04-16 11:59:59','MDABTC','4h','0.000116920000000','0.000114581600000','0.033167028034191','0.032503687473507','283.6728364196982','283.672836419698228','test','test','2.00'),('2018-04-17 19:59:59','2018-04-21 15:59:59','MDABTC','4h','0.000120970000000','0.000122120000000','0.033019619020706','0.033333519672717','272.9570887055119','272.957088705511921','test','test','1.85'),('2018-04-22 23:59:59','2018-04-23 07:59:59','MDABTC','4h','0.000133020000000','0.000130359600000','0.033089374721153','0.032427587226730','248.75488438695433','248.754884386954330','test','test','2.00'),('2018-04-23 11:59:59','2018-04-24 03:59:59','MDABTC','4h','0.000138150000000','0.000135387000000','0.032942310833503','0.032283464616833','238.45320907349338','238.453209073493383','test','test','2.00'),('2018-04-24 19:59:59','2018-04-24 23:59:59','MDABTC','4h','0.000138060000000','0.000135298800000','0.032795900563132','0.032139982551869','237.54817154231492','237.548171542314918','test','test','2.00'),('2018-04-26 19:59:59','2018-04-26 23:59:59','MDABTC','4h','0.000128130000000','0.000126510000000','0.032650141005074','0.032237331917208','254.8204246083942','254.820424608394205','test','test','1.26'),('2018-04-28 15:59:59','2018-04-29 11:59:59','MDABTC','4h','0.000130550000000','0.000127939000000','0.032558405652214','0.031907237539170','249.39414517207538','249.394145172075383','test','test','1.99'),('2018-04-30 15:59:59','2018-04-30 23:59:59','MDABTC','4h','0.000139190000000','0.000136406200000','0.032413701627094','0.031765427594552','232.87378135709142','232.873781357091417','test','test','1.99'),('2018-05-01 15:59:59','2018-05-02 19:59:59','MDABTC','4h','0.000134470000000','0.000136300000000','0.032269640730973','0.032708797736533','239.97650577060392','239.976505770603922','test','test','0.64'),('2018-05-02 23:59:59','2018-05-03 07:59:59','MDABTC','4h','0.000137810000000','0.000135053800000','0.032367231176653','0.031719886553120','234.86852315980778','234.868523159807779','test','test','2.00'),('2018-05-05 19:59:59','2018-05-06 07:59:59','MDABTC','4h','0.000135380000000','0.000132672400000','0.032223376815868','0.031578909279551','238.02169312947257','238.021693129472567','test','test','2.00'),('2018-05-18 15:59:59','2018-05-18 19:59:59','MDABTC','4h','0.000118000000000','0.000119570000000','0.032080161807798','0.032506991079309','271.8657780321827','271.865778032182675','test','test','0.0'),('2018-06-01 15:59:59','2018-06-01 19:59:59','MDABTC','4h','0.000108150000000','0.000105987000000','0.032175012757022','0.031531512501882','297.5035853631273','297.503585363127286','test','test','1.99'),('2018-06-02 07:59:59','2018-06-02 11:59:59','MDABTC','4h','0.000106160000000','0.000104036800000','0.032032012700324','0.031391372446318','301.73335248986854','301.733352489868537','test','test','2.00'),('2018-06-05 23:59:59','2018-06-06 03:59:59','MDABTC','4h','0.000101780000000','0.000100370000000','0.031889648199434','0.031447867850041','313.3193967325036','313.319396732503606','test','test','1.38'),('2018-06-06 11:59:59','2018-06-06 19:59:59','MDABTC','4h','0.000101740000000','0.000101650000000','0.031791474788458','0.031763351801128','312.47763700076666','312.477637000766663','test','test','0.58'),('2018-06-08 03:59:59','2018-06-08 07:59:59','MDABTC','4h','0.000102310000000','0.000100263800000','0.031785225235718','0.031149520731004','310.6756449586355','310.675644958635473','test','test','2.00'),('2018-07-05 07:59:59','2018-07-09 07:59:59','MDABTC','4h','0.000084840000000','0.000083143200000','0.031643957568004','0.031011078416644','372.9839411598748','372.983941159874803','test','test','2.00'),('2018-07-09 11:59:59','2018-07-09 23:59:59','MDABTC','4h','0.000084130000000','0.000082447400000','0.031503317756590','0.030873251401458','374.4599757112855','374.459975711285495','test','test','2.00'),('2018-07-16 15:59:59','2018-07-17 19:59:59','MDABTC','4h','0.000079150000000','0.000079310000000','0.031363303011006','0.031426703244509','396.25145939362676','396.251459393626760','test','test','0.0'),('2018-07-19 23:59:59','2018-07-20 03:59:59','MDABTC','4h','0.000079590000000','0.000080480000000','0.031377391951784','0.031728263654725','394.2378684732252','394.237868473225205','test','test','0.0'),('2018-07-23 11:59:59','2018-07-26 23:59:59','MDABTC','4h','0.000079480000000','0.000080410000000','0.031455363441326','0.031823424437809','395.764512346835','395.764512346834977','test','test','0.0'),('2018-08-17 15:59:59','2018-08-18 19:59:59','MDABTC','4h','0.000065230000000','0.000063925400000','0.031537154773878','0.030906411678400','483.4762344608036','483.476234460803596','test','test','2.00'),('2018-08-19 07:59:59','2018-09-05 11:59:59','MDABTC','4h','0.000067100000000','0.000105600000000','0.031396989641550','0.049411655829325','467.91340747466137','467.913407474661369','test','test','0.68'),('2018-10-07 15:59:59','2018-10-17 11:59:59','MDABTC','4h','0.000072500000000','0.000240870000000','0.035400248794389','0.117611833477303','488.27929371570576','488.279293715705762','test','test','0.0'),('2018-10-17 15:59:59','2018-10-22 07:59:59','MDABTC','4h','0.000266990000000','0.000261650200000','0.053669489835036','0.052596100038335','201.01685394597638','201.016853945976379','test','test','1.99'),('2018-10-22 19:59:59','2018-10-22 23:59:59','MDABTC','4h','0.000276500000000','0.000270970000000','0.053430958769103','0.052362339593721','193.24035721194457','193.240357211944570','test','test','2.00'),('2018-11-12 07:59:59','2018-11-12 11:59:59','MDABTC','4h','0.000221990000000','0.000217550200000','0.053193487841240','0.052129618084415','239.6210993343844','239.621099334384411','test','test','1.99'),('2018-11-12 23:59:59','2018-11-13 03:59:59','MDABTC','4h','0.000218600000000','0.000214228000000','0.052957072339723','0.051897930892929','242.2555916730253','242.255591673025293','test','test','1.99'),('2018-11-25 19:59:59','2018-11-30 15:59:59','MDABTC','4h','0.000168090000000','0.000232000000000','0.052721707573769','0.072767185181239','313.6516602639605','313.651660263960480','test','test','0.0'),('2018-12-11 15:59:59','2018-12-12 03:59:59','MDABTC','4h','0.000193620000000','0.000193030000000','0.057176258153207','0.057002030323900','295.30140560482846','295.301405604828460','test','test','0.30'),('2018-12-12 11:59:59','2018-12-20 23:59:59','MDABTC','4h','0.000211000000000','0.000252550000000','0.057137540857805','0.068389032908240','270.794032501447','270.794032501447020','test','test','0.26'),('2018-12-22 19:59:59','2018-12-22 23:59:59','MDABTC','4h','0.000243560000000','0.000238688800000','0.059637872424569','0.058445114976078','244.8590590596513','244.859059059651287','test','test','2.00'),('2018-12-25 19:59:59','2018-12-25 23:59:59','MDABTC','4h','0.000247800000000','0.000242844000000','0.059372815213793','0.058185358909517','239.5997385544507','239.599738554450710','test','test','1.99'),('2018-12-26 23:59:59','2018-12-27 07:59:59','MDABTC','4h','0.000238700000000','0.000238430000000','0.059108936035065','0.059042076325264','247.62855481803473','247.628554818034729','test','test','0.11'),('2019-01-02 19:59:59','2019-01-02 23:59:59','MDABTC','4h','0.000224100000000','0.000223340000000','0.059094078321776','0.058893670024031','263.6951286112261','263.695128611226096','test','test','0.33'),('2019-01-03 15:59:59','2019-01-03 19:59:59','MDABTC','4h','0.000225740000000','0.000221225200000','0.059049543144499','0.057868552281609','261.5820995149247','261.582099514924721','test','test','2.00'),('2019-01-05 15:59:59','2019-01-05 19:59:59','MDABTC','4h','0.000225110000000','0.000220607800000','0.058787100730524','0.057611358715914','261.14833072952575','261.148330729525753','test','test','1.99'),('2019-01-17 07:59:59','2019-01-17 11:59:59','MDABTC','4h','0.000211360000000','0.000207132800000','0.058525824727277','0.057355308232731','276.9011389443456','276.901138944345576','test','test','1.99'),('2019-01-17 15:59:59','2019-01-18 03:59:59','MDABTC','4h','0.000206400000000','0.000202272000000','0.058265709950711','0.057100395751697','282.29510635034455','282.295106350344554','test','test','1.99'),('2019-01-19 19:59:59','2019-01-19 23:59:59','MDABTC','4h','0.000201460000000','0.000199400000000','0.058006751239819','0.057413611621264','287.93185366732416','287.931853667324162','test','test','1.02'),('2019-01-23 11:59:59','2019-01-23 15:59:59','MDABTC','4h','0.000203190000000','0.000199900000000','0.057874942435696','0.056937846315742','284.8316474024105','284.831647402410510','test','test','1.61'),('2019-01-23 19:59:59','2019-01-23 23:59:59','MDABTC','4h','0.000200400000000','0.000201290000000','0.057666698853484','0.057922803454181','287.7579783107973','287.757978310797284','test','test','0.0'),('2019-01-24 15:59:59','2019-01-24 19:59:59','MDABTC','4h','0.000200030000000','0.000199290000000','0.057723610986972','0.057510065658120','288.574768719552','288.574768719552026','test','test','0.36'),('2019-01-25 19:59:59','2019-01-25 23:59:59','MDABTC','4h','0.000201260000000','0.000197234800000','0.057676156469449','0.056522633340060','286.57535759440196','286.575357594401964','test','test','2.00'),('2019-01-26 07:59:59','2019-01-27 03:59:59','MDABTC','4h','0.000205880000000','0.000201762400000','0.057419817996252','0.056271421636327','278.89944626118023','278.899446261180231','test','test','2.00'),('2019-01-27 07:59:59','2019-01-28 11:59:59','MDABTC','4h','0.000207390000000','0.000203510000000','0.057164618805157','0.056095142355164','275.63826030742723','275.638260307427231','test','test','1.87'),('2019-01-31 15:59:59','2019-02-05 15:59:59','MDABTC','4h','0.000207030000000','0.000209070000000','0.056926957371826','0.057487895366506','274.96960523511353','274.969605235113534','test','test','0.53'),('2019-02-14 19:59:59','2019-02-15 03:59:59','MDABTC','4h','0.000209920000000','0.000205721600000','0.057051610259532','0.055910578054341','271.7778689954851','271.777868995485107','test','test','1.99'),('2019-02-18 03:59:59','2019-02-18 11:59:59','MDABTC','4h','0.000203080000000','0.000200400000000','0.056798047547268','0.056048496791769','279.68311772339746','279.683117723397459','test','test','1.31'),('2019-02-20 15:59:59','2019-02-20 23:59:59','MDABTC','4h','0.000202610000000','0.000203410000000','0.056631480712712','0.056855088553244','279.5098006648844','279.509800664884381','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 19:59:59','MDABTC','4h','0.000200540000000','0.000198720000000','0.056681171343942','0.056166761591045','282.6427213720034','282.642721372003393','test','test','0.90'),('2019-02-23 03:59:59','2019-02-24 19:59:59','MDABTC','4h','0.000207080000000','0.000207280000000','0.056566858065520','0.056621490920519','273.164274992853','273.164274992852995','test','test','0.0'),('2019-02-24 23:59:59','2019-03-02 11:59:59','MDABTC','4h','0.000217700000000','0.000227270000000','0.056578998699964','0.059066187572535','259.8943440512826','259.894344051282587','test','test','0.0'),('2019-03-07 19:59:59','2019-03-08 03:59:59','MDABTC','4h','0.000230410000000','0.000225801800000','0.057131707338313','0.055989073191547','247.95671775666563','247.956717756665626','test','test','2.00'),('2019-03-08 07:59:59','2019-03-08 23:59:59','MDABTC','4h','0.000225470000000','0.000220960600000','0.056877788639032','0.055740232866251','252.26322188775447','252.263221887754469','test','test','2.00'),('2019-03-09 19:59:59','2019-03-12 19:59:59','MDABTC','4h','0.000240210000000','0.000253770000000','0.056624998467303','0.059821513929676','235.73122878857205','235.731228788572054','test','test','1.38'),('2019-03-12 23:59:59','2019-03-13 03:59:59','MDABTC','4h','0.000281530000000','0.000275899400000','0.057335335236719','0.056188628531985','203.65621865065575','203.656218650655745','test','test','2.0'),('2019-03-13 07:59:59','2019-03-14 11:59:59','MDABTC','4h','0.000297500000000','0.000291550000000','0.057080511524556','0.055938901294065','191.8672656287597','191.867265628759696','test','test','2.00'),('2019-03-18 11:59:59','2019-03-18 19:59:59','MDABTC','4h','0.000279460000000','0.000273870800000','0.056826820362225','0.055690283954980','203.34509540622872','203.345095406228722','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:04:47
