-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 19:59:59','2018-05-10 19:59:59','GXSETH','4h','0.005591000000000','0.005514000000000','1.297777777777778','1.279904608597150','232.11908026789087','232.119080267890865','test','test','1.37'),('2018-05-12 11:59:59','2018-05-12 15:59:59','GXSETH','4h','0.005687000000000','0.005573260000000','1.293805962404305','1.267929843156219','227.50236722424913','227.502367224249127','test','test','2.00'),('2018-05-28 07:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005186000000000','0.005830000000000','1.288055713682508','1.448007098104323','248.3717149407073','248.371714940707307','test','test','0.44'),('2018-06-03 11:59:59','2018-06-14 19:59:59','GXSETH','4h','0.005840000000000','0.006392000000000','1.323600465776245','1.448707907061945','226.64391537264464','226.643915372644642','test','test','1.09'),('2018-07-02 19:59:59','2018-07-02 23:59:59','GXSETH','4h','0.005767000000000','0.005730000000000','1.351402119395289','1.342731774602914','234.3336430371578','234.333643037157799','test','test','0.64'),('2018-07-03 03:59:59','2018-07-03 07:59:59','GXSETH','4h','0.005772000000000','0.005668000000000','1.349475376108095','1.325160504466508','233.7968427075701','233.796842707570107','test','test','1.80'),('2018-07-11 15:59:59','2018-07-13 03:59:59','GXSETH','4h','0.005619000000000','0.005722000000000','1.344072071298853','1.368709804586588','239.2012940556777','239.201294055677693','test','test','1.58'),('2018-07-14 23:59:59','2018-07-15 11:59:59','GXSETH','4h','0.005947000000000','0.005828060000000','1.349547123140572','1.322556180677760','226.92906055836082','226.929060558360817','test','test','2.00'),('2018-07-16 03:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005886000000000','0.006489000000000','1.343549135926614','1.481191019882399','228.26183077244542','228.261830772445421','test','test','1.73'),('2018-08-17 19:59:59','2018-08-17 23:59:59','GXSETH','4h','0.005360000000000','0.005307000000000','1.374136221250121','1.360548680256416','256.36869799442564','256.368697994425645','test','test','0.98'),('2018-08-19 07:59:59','2018-08-19 11:59:59','GXSETH','4h','0.005217000000000','0.005215000000000','1.371116767695965','1.370591133512451','262.81709175694164','262.817091756941636','test','test','0.03'),('2018-08-20 23:59:59','2018-08-21 03:59:59','GXSETH','4h','0.005258000000000','0.005152840000000','1.370999960099629','1.343579960897636','260.7455230315003','260.745523031500284','test','test','1.99'),('2018-08-25 15:59:59','2018-08-25 19:59:59','GXSETH','4h','0.005110000000000','0.005067000000000','1.364906626943630','1.353421111296159','267.1050150574618','267.105015057461799','test','test','0.84'),('2018-08-26 15:59:59','2018-08-26 19:59:59','GXSETH','4h','0.005086000000000','0.005081000000000','1.362354290133081','1.361014972112895','267.86360403717674','267.863604037176742','test','test','0.09'),('2018-08-27 15:59:59','2018-08-27 19:59:59','GXSETH','4h','0.005066000000000','0.005113000000000','1.362056663906373','1.374693194345299','268.86234976438465','268.862349764384646','test','test','0.0'),('2018-08-28 15:59:59','2018-08-29 19:59:59','GXSETH','4h','0.005188000000000','0.005084240000000','1.364864781781690','1.337567486146056','263.08110674280834','263.081106742808345','test','test','2.00'),('2018-09-01 11:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005156000000000','0.005081000000000','1.358798716084882','1.339033412805912','263.53737705292514','263.537377052925137','test','test','1.45'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005119000000000','1.354406426467333','1.335877937781556','260.9646293771355','260.964629377135509','test','test','1.36'),('2018-09-04 15:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005235000000000','0.005130300000000','1.350288984537160','1.323283204846417','257.9348585553315','257.934858555331516','test','test','2.00'),('2018-09-05 19:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005258000000000','0.005152840000000','1.344287700161440','1.317401946158211','255.66521494131607','255.665214941316066','test','test','1.99'),('2018-09-06 19:59:59','2018-09-06 23:59:59','GXSETH','4h','0.005149000000000','0.005215000000000','1.338313088160722','1.355467615994983','259.9170883978874','259.917088397887426','test','test','0.0'),('2018-09-07 03:59:59','2018-09-13 03:59:59','GXSETH','4h','0.005273000000000','0.005515000000000','1.342125205457225','1.403720938383576','254.52782200971455','254.527822009714555','test','test','1.42'),('2018-09-20 15:59:59','2018-09-20 23:59:59','GXSETH','4h','0.005202000000000','0.005097960000000','1.355813146107525','1.328696883185374','260.63305384612164','260.633053846121641','test','test','1.99'),('2018-09-22 11:59:59','2018-09-22 15:59:59','GXSETH','4h','0.005267000000000','0.005161660000000','1.349787309902603','1.322791563704551','256.27250994923156','256.272509949231562','test','test','1.99'),('2018-09-24 07:59:59','2018-09-30 23:59:59','GXSETH','4h','0.005320000000000','0.005894000000000','1.343788255191924','1.488775935357368','252.59177729171512','252.591777291715118','test','test','1.89'),('2018-10-02 23:59:59','2018-10-03 07:59:59','GXSETH','4h','0.005830000000000','0.005889000000000','1.376007739673134','1.389933032407390','236.02191075010876','236.021910750108759','test','test','0.49'),('2018-10-04 07:59:59','2018-10-04 15:59:59','GXSETH','4h','0.006218000000000','0.006093640000000','1.379102249169635','1.351520204186242','221.7919345721511','221.791934572151092','test','test','2.00'),('2018-10-05 03:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006078000000000','0.005972000000000','1.372972905839992','1.349028330647652','225.89221879565522','225.892218795655225','test','test','1.74'),('2018-10-07 23:59:59','2018-10-18 03:59:59','GXSETH','4h','0.006081000000000','0.006814000000000','1.367651889130584','1.532507806698865','224.9057538448584','224.905753844858395','test','test','0.64'),('2018-10-23 11:59:59','2018-10-23 15:59:59','GXSETH','4h','0.007089000000000','0.007028000000000','1.404286537479090','1.392202819213294','198.09374206222182','198.093742062221821','test','test','0.86'),('2018-11-03 11:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006745000000000','0.006720000000000','1.401601266753358','1.396406302829142','207.79855696862242','207.798556968622421','test','test','0.37'),('2018-11-16 11:59:59','2018-11-16 19:59:59','GXSETH','4h','0.006514000000000','0.006383720000000','1.400446830325754','1.372437893719239','214.99030247555334','214.990302475553335','test','test','1.99'),('2018-11-17 15:59:59','2018-11-17 19:59:59','GXSETH','4h','0.006315000000000','0.006221000000000','1.394222622190973','1.373469348004757','220.77951261931486','220.779512619314858','test','test','1.48'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006234760000000','1.389610783482926','1.361818567813267','218.42357489514708','218.423574895147084','test','test','1.99'),('2018-11-20 07:59:59','2018-11-20 11:59:59','GXSETH','4h','0.006252000000000','0.006303000000000','1.383434735556335','1.394719951729299','221.2787484894969','221.278748489496905','test','test','0.0'),('2018-11-22 15:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006463000000000','0.006333740000000','1.385942561372549','1.358223710145098','214.44260581348425','214.442605813484249','test','test','1.99'),('2018-11-30 23:59:59','2018-12-01 11:59:59','GXSETH','4h','0.006356000000000','0.006228880000000','1.379782816655337','1.352187160322230','217.08351426295428','217.083514262954282','test','test','2.00'),('2018-12-03 15:59:59','2018-12-04 07:59:59','GXSETH','4h','0.006374000000000','0.006246520000000','1.373650448581314','1.346177439609687','215.50838540654433','215.508385406544335','test','test','2.00'),('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.367545335476508','1.416645572553035','345.7763174403306','345.776317440330615','test','test','0.0'),('2019-01-15 11:59:59','2019-01-15 15:59:59','GXSETH','4h','0.004129000000000','0.004171000000000','1.378456499271292','1.392478096018542','333.84754160118473','333.847541601184730','test','test','0.0'),('2019-01-15 23:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004275000000000','0.004999000000000','1.381572409659569','1.615550988511856','323.17483266890514','323.174832668905140','test','test','0.0'),('2019-02-07 11:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005179000000000','0.005075420000000','1.433567649404522','1.404896296416432','276.80394852375406','276.803948523754059','test','test','1.99'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.427196237629391','1.418083347131655','293.964209604406','293.964209604405994','test','test','0.63'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004472720000000','1.425171150852116','1.396667727835074','312.26361762754516','312.263617627545159','test','test','2.0'),('2019-02-26 07:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004550000000000','0.004911000000000','1.418837056848329','1.531408524435636','311.832320186446','311.832320186445997','test','test','0.0'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.443852938534397','1.447776451954327','301.8087246100329','301.808724610032925','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.444724830405493','2.151587161395387','292.45441911042366','292.454419110423657','test','test','0.16'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSETH','4h','0.007801000000000','0.007644980000000','1.601805348403247','1.569769241435182','205.33333526512592','205.333335265125925','test','test','1.99'),('2019-03-28 11:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007755000000000','0.008025000000000','1.594686213521455','1.650207203547347','205.6332963921928','205.633296392192790','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','GXSETH','4h','0.008023000000000','0.007862540000000','1.607024211304987','1.574883727078888','200.3021577097079','200.302157709707899','test','test','1.99'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007754740000000','1.599881881476964','1.567884243847425','202.18398603272647','202.183986032726466','test','test','2.00'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.592771295337067','1.595505486125312','210.3223683265637','210.322368326563691','test','test','1.79'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007708680000000','1.593378893290010','1.561511315424210','202.56533095474322','202.565330954743217','test','test','1.99'),('2019-04-22 23:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007823000000000','0.007666540000000','1.586297209319832','1.554571265133435','202.77351518852518','202.773515188525181','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:04:45
