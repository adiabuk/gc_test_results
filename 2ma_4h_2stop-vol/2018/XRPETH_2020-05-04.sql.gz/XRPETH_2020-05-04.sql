-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-19 23:59:59','2018-04-23 03:59:59','XRPETH','4h','0.001379080000000','0.001351498400000','1.297777777777778','1.271822222222222','941.0460435781664','941.046043578166405','test','test','2.00'),('2018-04-24 03:59:59','2018-04-24 07:59:59','XRPETH','4h','0.001358430000000','0.001337070000000','1.292009876543210','1.271694268846852','951.1052292302214','951.105229230221425','test','test','1.57'),('2018-05-23 19:59:59','2018-05-25 19:59:59','XRPETH','4h','0.001027800000000','0.001034590000000','1.287495297055130','1.296000933430888','1252.6710420851628','1252.671042085162753','test','test','1.12'),('2018-05-27 15:59:59','2018-06-10 11:59:59','XRPETH','4h','0.001058700000000','0.001095710000000','1.289385438471965','1.334459732490901','1217.8950018626288','1217.895001862628760','test','test','0.37'),('2018-06-10 19:59:59','2018-06-10 23:59:59','XRPETH','4h','0.001101010000000','0.001109660000000','1.299401948253951','1.309610599267472','1180.1908686151362','1180.190868615136196','test','test','0.0'),('2018-06-11 19:59:59','2018-06-12 15:59:59','XRPETH','4h','0.001111530000000','0.001098510000000','1.301670537368067','1.286423310215825','1171.0619932598013','1171.061993259801284','test','test','1.17'),('2018-06-12 19:59:59','2018-06-13 19:59:59','XRPETH','4h','0.001129000000000','0.001106420000000','1.298282264667569','1.272316619374217','1149.9400041342503','1149.940004134250330','test','test','2.00'),('2018-06-14 07:59:59','2018-06-14 19:59:59','XRPETH','4h','0.001131750000000','0.001109115000000','1.292512121269046','1.266661878843665','1142.0473790758083','1142.047379075808294','test','test','2.00'),('2018-06-24 19:59:59','2018-06-24 23:59:59','XRPETH','4h','0.001052870000000','0.001041280000000','1.286767622952295','1.272602876354883','1222.1524242805804','1222.152424280580362','test','test','1.10'),('2018-06-26 15:59:59','2018-06-27 03:59:59','XRPETH','4h','0.001060580000000','0.001059700000000','1.283619901486203','1.282554837546370','1210.2999316281687','1210.299931628168679','test','test','0.54'),('2018-06-28 03:59:59','2018-06-28 15:59:59','XRPETH','4h','0.001073370000000','0.001057100000000','1.283383220610685','1.263929868086080','1195.6578072898299','1195.657807289829861','test','test','1.71'),('2018-06-28 23:59:59','2018-06-29 11:59:59','XRPETH','4h','0.001060350000000','0.001042860000000','1.279060253382995','1.257962725367086','1206.2623222360492','1206.262322236049158','test','test','1.64'),('2018-07-03 03:59:59','2018-07-03 23:59:59','XRPETH','4h','0.001052550000000','0.001051360000000','1.274371913823904','1.272931124714170','1210.747151036914','1210.747151036913920','test','test','0.11'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XRPETH','4h','0.001048610000000','0.001065490000000','1.274051738466185','1.294560786964015','1214.9910247529444','1214.991024752944440','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','XRPETH','4h','0.001023610000000','0.001023710000000','1.278609304799036','1.278734216562774','1249.117637380483','1249.117637380483075','test','test','0.0'),('2018-07-17 15:59:59','2018-07-17 19:59:59','XRPETH','4h','0.001014080000000','0.001013990000000','1.278637062968756','1.278523583425064','1260.883818800051','1260.883818800050904','test','test','0.00'),('2018-07-17 23:59:59','2018-07-18 19:59:59','XRPETH','4h','0.001016060000000','0.001015460000000','1.278611845292380','1.277856804146015','1258.4019106080148','1258.401910608014759','test','test','0.05'),('2018-07-19 15:59:59','2018-07-19 23:59:59','XRPETH','4h','0.001028700000000','0.001018880000000','1.278444058370965','1.266239994355020','1242.77637636917','1242.776376369170066','test','test','0.95'),('2018-07-31 11:59:59','2018-08-06 23:59:59','XRPETH','4h','0.000999000000000','0.001017910000000','1.275732044145200','1.299880285341181','1277.009053198398','1277.009053198398078','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XRPETH','4h','0.000987780000000','0.000976100000000','1.281098319966529','1.265949978861010','1296.947012458775','1296.947012458774907','test','test','1.18'),('2018-08-14 11:59:59','2018-08-14 23:59:59','XRPETH','4h','0.000995260000000','0.000979220000000','1.277732021943080','1.257139592194103','1283.8173160210197','1283.817316021019678','test','test','1.61'),('2018-08-15 03:59:59','2018-08-15 19:59:59','XRPETH','4h','0.000999340000000','0.000991860000000','1.273155926443308','1.263626430646286','1273.9967643077507','1273.996764307750709','test','test','0.74'),('2018-08-17 11:59:59','2018-08-31 15:59:59','XRPETH','4h','0.001052000000000','0.001186000000000','1.271038260710636','1.432938571485565','1208.211274439768','1208.211274439767976','test','test','0.0'),('2018-08-31 19:59:59','2018-09-01 15:59:59','XRPETH','4h','0.001190000000000','0.001167880000000','1.307016107549509','1.282720984609177','1098.3328634869822','1098.332863486982205','test','test','1.85'),('2018-09-04 07:59:59','2018-09-04 11:59:59','XRPETH','4h','0.001169050000000','0.001168980000000','1.301617191340547','1.301539253524890','1113.3973665288452','1113.397366528845168','test','test','0.00'),('2018-09-05 11:59:59','2018-09-05 19:59:59','XRPETH','4h','0.001172280000000','0.001186520000000','1.301599871825956','1.317410755040548','1110.3148324853755','1110.314832485375518','test','test','0.22'),('2018-09-05 23:59:59','2018-09-13 23:59:59','XRPETH','4h','0.001222490000000','0.001321790000000','1.305113401429199','1.411124706848401','1067.5861572930646','1067.586157293064616','test','test','0.0'),('2018-09-17 19:59:59','2018-10-02 23:59:59','XRPETH','4h','0.001370000000000','0.002294530000000','1.328671469300132','2.225311347776082','969.8331892701696','969.833189270169555','test','test','0.0'),('2018-10-03 03:59:59','2018-10-05 11:59:59','XRPETH','4h','0.002368040000000','0.002324530000000','1.527924775628121','1.499850922573451','645.2276041064008','645.227604106400804','test','test','1.83'),('2018-10-16 07:59:59','2018-10-22 15:59:59','XRPETH','4h','0.002197600000000','0.002233800000000','1.521686141615972','1.546752140126392','692.4308980778906','692.430898077890561','test','test','0.46'),('2018-10-22 19:59:59','2018-10-23 11:59:59','XRPETH','4h','0.002233680000000','0.002205610000000','1.527256363507177','1.508063781703317','683.7400001375205','683.740000137520497','test','test','1.25'),('2018-10-23 23:59:59','2018-10-27 23:59:59','XRPETH','4h','0.002282400000000','0.002249540000000','1.522991345328541','1.501064647288103','667.276264164275','667.276264164274949','test','test','1.43'),('2018-10-29 15:59:59','2018-10-29 19:59:59','XRPETH','4h','0.002256860000000','0.002252630000000','1.518118745764000','1.515273357793731','672.6685508910608','672.668550891060818','test','test','0.18'),('2018-10-29 23:59:59','2018-10-31 15:59:59','XRPETH','4h','0.002263810000000','0.002286340000000','1.517486437326162','1.532588839662471','670.3241161255413','670.324116125541309','test','test','0.06'),('2018-10-31 19:59:59','2018-11-04 07:59:59','XRPETH','4h','0.002287640000000','0.002256960000000','1.520842526734230','1.500446201822878','664.8085042813688','664.808504281368755','test','test','1.34'),('2018-11-05 15:59:59','2018-11-08 19:59:59','XRPETH','4h','0.002333720000000','0.002361690000000','1.516310010087264','1.534483223232860','649.739476067079','649.739476067078954','test','test','0.0'),('2018-11-12 15:59:59','2018-11-14 19:59:59','XRPETH','4h','0.002478500000000','0.002506570000000','1.520348501897396','1.537567054428467','613.4147677617091','613.414767761709072','test','test','1.14'),('2018-11-14 23:59:59','2018-11-29 15:59:59','XRPETH','4h','0.002586730000000','0.003208670000000','1.524174846904301','1.890639574295123','589.2284261999902','589.228426199990167','test','test','0.98'),('2018-11-29 23:59:59','2018-11-30 11:59:59','XRPETH','4h','0.003235330000000','0.003170623400000','1.605611452991150','1.573499223931327','496.27439951756077','496.274399517560767','test','test','2.00'),('2018-12-03 07:59:59','2018-12-04 11:59:59','XRPETH','4h','0.003196100000000','0.003203380000000','1.598475402088967','1.602116371059653','500.13310036887674','500.133100368876740','test','test','0.47'),('2018-12-05 19:59:59','2018-12-07 19:59:59','XRPETH','4h','0.003296690000000','0.003230756200000','1.599284506304675','1.567298816178581','485.11825688938757','485.118256889387567','test','test','2.00'),('2018-12-08 03:59:59','2018-12-09 15:59:59','XRPETH','4h','0.003298690000000','0.003272750000000','1.592176575165543','1.579656132092749','482.66935515781813','482.669355157818131','test','test','0.78'),('2018-12-10 15:59:59','2018-12-16 03:59:59','XRPETH','4h','0.003332930000000','0.003361590000000','1.589394254482700','1.603061520021872','476.87597833818893','476.875978338188929','test','test','0.0'),('2018-12-17 15:59:59','2018-12-17 19:59:59','XRPETH','4h','0.003380610000000','0.003446030000000','1.592431424602516','1.623247420472343','471.0485458548948','471.048545854894826','test','test','0.0'),('2018-12-17 23:59:59','2018-12-20 15:59:59','XRPETH','4h','0.003479410000000','0.003413370000000','1.599279423684700','1.568924733337734','459.6409804204448','459.640980420444805','test','test','1.89'),('2019-01-10 07:59:59','2019-01-14 19:59:59','XRPETH','4h','0.002576340000000','0.002596400000000','1.592533936940929','1.604933787416811','618.1381094657264','618.138109465726416','test','test','0.0'),('2019-01-15 23:59:59','2019-01-19 11:59:59','XRPETH','4h','0.002702650000000','0.002648597000000','1.595289459268903','1.563383670083525','590.2686101673925','590.268610167392467','test','test','2.00'),('2019-01-20 11:59:59','2019-01-27 11:59:59','XRPETH','4h','0.002680000000000','0.002688090000000','1.588199283894375','1.592993512329713','592.611673094916','592.611673094916000','test','test','0.00'),('2019-01-27 15:59:59','2019-01-27 23:59:59','XRPETH','4h','0.002713340000000','0.002735430000000','1.589264667991117','1.602203281108501','585.7226399902396','585.722639990239600','test','test','0.25'),('2019-01-28 03:59:59','2019-02-03 07:59:59','XRPETH','4h','0.002754280000000','0.002812130000000','1.592139915350535','1.625580703543104','578.060297192201','578.060297192201006','test','test','0.93'),('2019-02-05 19:59:59','2019-02-05 23:59:59','XRPETH','4h','0.002815070000000','0.002793970000000','1.599571201615550','1.587581818632502','568.217202988043','568.217202988043027','test','test','0.74'),('2019-02-06 03:59:59','2019-02-06 19:59:59','XRPETH','4h','0.002829350000000','0.002793490000000','1.596906894285984','1.576667234565873','564.4076887928268','564.407688792826775','test','test','1.26'),('2019-02-25 19:59:59','2019-02-26 07:59:59','XRPETH','4h','0.002380130000000','0.002332527400000','1.592409192125960','1.560561008283441','669.0429481271862','669.042948127186150','test','test','2.00'),('2019-02-27 23:59:59','2019-02-28 03:59:59','XRPETH','4h','0.002300420000000','0.002287290000000','1.585331817938733','1.576283293421673','689.1488588773932','689.148858877393195','test','test','0.57'),('2019-03-04 03:59:59','2019-03-05 15:59:59','XRPETH','4h','0.002392200000000','0.002344356000000','1.583321034712720','1.551654614018465','661.8681693473454','661.868169347345429','test','test','2.00'),('2019-03-10 15:59:59','2019-03-10 23:59:59','XRPETH','4h','0.002319560000000','0.002310030000000','1.576284052336218','1.569807829682454','679.5616635638735','679.561663563873481','test','test','0.41'),('2019-03-11 07:59:59','2019-03-12 11:59:59','XRPETH','4h','0.002316800000000','0.002319890000000','1.574844891746493','1.576945319368858','679.7500396005237','679.750039600523678','test','test','0.0'),('2019-03-12 19:59:59','2019-03-15 07:59:59','XRPETH','4h','0.002341610000000','0.002332830000000','1.575311653440352','1.569404932715207','672.7472352101129','672.747235210112876','test','test','0.75'),('2019-04-02 03:59:59','2019-04-02 07:59:59','XRPETH','4h','0.002251270000000','0.002206244600000','1.573999048834765','1.542519067858070','699.1604955579581','699.160495557958143','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:23:25
