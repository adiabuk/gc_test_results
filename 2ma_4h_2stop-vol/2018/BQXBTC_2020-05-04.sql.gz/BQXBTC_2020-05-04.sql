-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-21 07:59:59','2018-03-21 11:59:59','BQXBTC','4h','0.000336980000000','0.000332860000000','0.033333333333333','0.032925791837300','98.91783884305696','98.917838843056956','test','test','1.22'),('2018-03-21 15:59:59','2018-03-21 19:59:59','BQXBTC','4h','0.000336710000000','0.000329975800000','0.033242768556437','0.032577913185308','98.72818911359066','98.728189113590659','test','test','2.00'),('2018-03-24 19:59:59','2018-03-24 23:59:59','BQXBTC','4h','0.000331340000000','0.000324713200000','0.033095022918408','0.032433122460040','99.88236529971763','99.882365299717634','test','test','2.00'),('2018-03-25 15:59:59','2018-03-28 03:59:59','BQXBTC','4h','0.000347060000000','0.000340118800000','0.032947933927660','0.032288975249107','94.93440306477267','94.934403064772667','test','test','2.00'),('2018-04-11 15:59:59','2018-04-12 11:59:59','BQXBTC','4h','0.000295720000000','0.000296240000000','0.032801498665759','0.032859177481213','110.92079895089724','110.920798950897236','test','test','0.0'),('2018-04-13 15:59:59','2018-04-21 11:59:59','BQXBTC','4h','0.000304190000000','0.000325790000000','0.032814316180305','0.035144403393871','107.8744080354537','107.874408035453698','test','test','0.74'),('2018-04-23 03:59:59','2018-04-25 15:59:59','BQXBTC','4h','0.000342080000000','0.000356310000000','0.033332113338875','0.034718677805702','97.43952683253886','97.439526832538860','test','test','0.0'),('2018-04-28 03:59:59','2018-05-03 19:59:59','BQXBTC','4h','0.000371940000000','0.000375610000000','0.033640238775948','0.033972173164042','90.44533735534642','90.445337355346425','test','test','0.0'),('2018-05-08 07:59:59','2018-05-11 15:59:59','BQXBTC','4h','0.000381490000000','0.000398170000000','0.033714001973302','0.035188089244042','88.37453661511908','88.374536615119084','test','test','0.0'),('2018-05-31 15:59:59','2018-05-31 19:59:59','BQXBTC','4h','0.000342300000000','0.000335454000000','0.034041576922355','0.033360745383908','99.44953818976077','99.449538189760773','test','test','2.00'),('2018-06-02 11:59:59','2018-06-02 19:59:59','BQXBTC','4h','0.000318870000000','0.000320380000000','0.033890281024922','0.034050767506396','106.28243806229008','106.282438062290083','test','test','0.78'),('2018-06-03 07:59:59','2018-06-03 19:59:59','BQXBTC','4h','0.000325610000000','0.000319097800000','0.033925944687472','0.033247425793723','104.19196181773354','104.191961817733542','test','test','1.99'),('2018-06-03 23:59:59','2018-06-04 03:59:59','BQXBTC','4h','0.000321970000000','0.000315530600000','0.033775162711084','0.033099659456862','104.90158310116952','104.901583101169521','test','test','1.99'),('2018-06-09 03:59:59','2018-06-09 07:59:59','BQXBTC','4h','0.000319120000000','0.000312737600000','0.033625050876812','0.032952549859276','105.36804611685885','105.368046116858849','test','test','2.00'),('2018-06-09 11:59:59','2018-06-10 03:59:59','BQXBTC','4h','0.000322350000000','0.000315903000000','0.033475606206248','0.032806094082123','103.8486310105427','103.848631010542704','test','test','2.00'),('2018-06-28 15:59:59','2018-06-28 19:59:59','BQXBTC','4h','0.000242090000000','0.000237248200000','0.033326825734221','0.032660289219537','137.66295895832403','137.662958958324026','test','test','2.00'),('2018-06-29 07:59:59','2018-06-30 15:59:59','BQXBTC','4h','0.000227610000000','0.000223057800000','0.033178706508735','0.032515132378560','145.76998597924225','145.769985979242250','test','test','1.99'),('2018-07-02 19:59:59','2018-07-02 23:59:59','BQXBTC','4h','0.000260250000000','0.000255045000000','0.033031245590919','0.032370620679101','126.92121264522058','126.921212645220578','test','test','1.99'),('2018-07-04 11:59:59','2018-07-07 23:59:59','BQXBTC','4h','0.000238620000000','0.000254330000000','0.032884440054959','0.035049449497853','137.81091297862338','137.810912978623378','test','test','0.0'),('2018-08-17 11:59:59','2018-08-17 15:59:59','BQXBTC','4h','0.000080770000000','0.000079154600000','0.033365553264491','0.032698242199201','413.0933919090146','413.093391909014599','test','test','2.00'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BQXBTC','4h','0.000081640000000','0.000080007200000','0.033217261916649','0.032552916678316','406.874839743372','406.874839743371979','test','test','2.00'),('2018-08-19 19:59:59','2018-08-19 23:59:59','BQXBTC','4h','0.000076880000000','0.000075490000000','0.033069629641464','0.032471726608144','430.1460671366256','430.146067136625618','test','test','1.80'),('2018-08-26 15:59:59','2018-08-29 19:59:59','BQXBTC','4h','0.000073090000000','0.000073580000000','0.032936762300726','0.033157572446127','450.63294979786554','450.632949797865535','test','test','1.34'),('2018-09-26 19:59:59','2018-09-28 07:59:59','BQXBTC','4h','0.000052020000000','0.000050979600000','0.032985831221926','0.032326114597487','634.0990238740143','634.099023874014279','test','test','1.99'),('2018-10-02 03:59:59','2018-10-02 19:59:59','BQXBTC','4h','0.000051730000000','0.000050695400000','0.032839227527606','0.032182442977054','634.8197859579826','634.819785957982617','test','test','1.99'),('2018-10-05 03:59:59','2018-10-05 23:59:59','BQXBTC','4h','0.000051080000000','0.000050710000000','0.032693275405262','0.032456460371982','640.0406304867179','640.040630486717873','test','test','0.72'),('2018-10-06 03:59:59','2018-10-09 11:59:59','BQXBTC','4h','0.000051330000000','0.000050770000000','0.032640649842310','0.032284546902281','635.8981071948265','635.898107194826480','test','test','1.09'),('2018-10-13 15:59:59','2018-10-15 07:59:59','BQXBTC','4h','0.000053100000000','0.000054200000000','0.032561515855637','0.033236048199162','613.2112213867671','613.211221386767079','test','test','0.0'),('2018-10-19 15:59:59','2018-10-26 15:59:59','BQXBTC','4h','0.000058270000000','0.000060550000000','0.032711411931976','0.033991350480198','561.3765562377934','561.376556237793352','test','test','0.0'),('2018-11-01 07:59:59','2018-11-01 11:59:59','BQXBTC','4h','0.000060980000000','0.000060240000000','0.032995842720470','0.032595434002642','541.092861929649','541.092861929648961','test','test','1.21'),('2018-11-01 19:59:59','2018-11-02 15:59:59','BQXBTC','4h','0.000061560000000','0.000061530000000','0.032906863005397','0.032890826522451','534.5494315366651','534.549431536665111','test','test','0.40'),('2018-11-12 03:59:59','2018-11-12 07:59:59','BQXBTC','4h','0.000055370000000','0.000055060000000','0.032903299342520','0.032719083651782','594.2441636720284','594.244163672028435','test','test','0.55'),('2018-12-15 15:59:59','2018-12-15 19:59:59','BQXBTC','4h','0.000028200000000','0.000027636000000','0.032862362522356','0.032205115271909','1165.3320043388728','1165.332004338872821','test','test','2.0'),('2018-12-15 23:59:59','2018-12-16 15:59:59','BQXBTC','4h','0.000028040000000','0.000027479200000','0.032716307577812','0.032061981426256','1166.7727381530829','1166.772738153082855','test','test','1.99'),('2018-12-21 03:59:59','2018-12-25 11:59:59','BQXBTC','4h','0.000027980000000','0.000028720000000','0.032570901766356','0.033432319468540','1164.0779759240727','1164.077975924072689','test','test','0.0'),('2018-12-28 03:59:59','2019-01-01 23:59:59','BQXBTC','4h','0.000028880000000','0.000030720000000','0.032762327922396','0.034849678454848','1134.4296372020926','1134.429637202092636','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 11:59:59','BQXBTC','4h','0.000032010000000','0.000031369800000','0.033226183596275','0.032561659924349','1037.9938643009891','1037.993864300989117','test','test','2.00'),('2019-01-15 03:59:59','2019-01-15 07:59:59','BQXBTC','4h','0.000029610000000','0.000029100000000','0.033078511669180','0.032508770333439','1117.139874001351','1117.139874001351018','test','test','1.72'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BQXBTC','4h','0.000029430000000','0.000029280000000','0.032951902483460','0.032783951910150','1119.6704887346166','1119.670488734616583','test','test','0.50'),('2019-01-15 23:59:59','2019-01-24 07:59:59','BQXBTC','4h','0.000029500000000','0.000047060000000','0.032914580133835','0.052507123427060','1115.7484791130619','1115.748479113061876','test','test','0.0'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BQXBTC','4h','0.000050120000000','0.000049117600000','0.037268478643441','0.036523109070572','743.5849689433536','743.584968943353601','test','test','2.00'),('2019-01-25 19:59:59','2019-01-26 07:59:59','BQXBTC','4h','0.000050100000000','0.000049098000000','0.037102840960581','0.036360784141369','740.5756678758704','740.575667875870408','test','test','2.00'),('2019-01-26 11:59:59','2019-01-26 19:59:59','BQXBTC','4h','0.000049760000000','0.000048764800000','0.036937939445201','0.036199180656297','742.3219341881163','742.321934188116302','test','test','2.00'),('2019-01-29 11:59:59','2019-01-29 15:59:59','BQXBTC','4h','0.000047280000000','0.000046334400000','0.036773770825444','0.036038295408935','777.7870309950131','777.787030995013083','test','test','1.99'),('2019-02-12 23:59:59','2019-02-13 03:59:59','BQXBTC','4h','0.000041550000000','0.000040719000000','0.036610331843998','0.035878125207118','881.1150864981414','881.115086498141409','test','test','1.99'),('2019-02-13 19:59:59','2019-02-13 23:59:59','BQXBTC','4h','0.000040520000000','0.000040170000000','0.036447619258024','0.036132795300958','899.4970201881649','899.497020188164925','test','test','0.86'),('2019-02-16 07:59:59','2019-02-16 11:59:59','BQXBTC','4h','0.000040480000000','0.000039670400000','0.036377658378676','0.035650105211102','898.6575686431927','898.657568643192690','test','test','1.99'),('2019-02-17 03:59:59','2019-02-17 15:59:59','BQXBTC','4h','0.000040660000000','0.000040320000000','0.036215979896993','0.035913140911135','890.7028995817346','890.702899581734641','test','test','0.83'),('2019-02-17 23:59:59','2019-02-18 15:59:59','BQXBTC','4h','0.000040540000000','0.000040050000000','0.036148682344580','0.035711759445003','891.679386891476','891.679386891476042','test','test','1.20'),('2019-02-18 19:59:59','2019-02-18 23:59:59','BQXBTC','4h','0.000040340000000','0.000040580000000','0.036051588366897','0.036266074762734','893.693315986531','893.693315986531047','test','test','0.0'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BQXBTC','4h','0.000040120000000','0.000039317600000','0.036099252010416','0.035377266970208','899.7819543972081','899.781954397208096','test','test','1.99'),('2019-03-08 03:59:59','2019-03-08 07:59:59','BQXBTC','4h','0.000038300000000','0.000038190000000','0.035938810890370','0.035835592373452','938.3501537955553','938.350153795555343','test','test','0.28'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BQXBTC','4h','0.000039030000000','0.000038249400000','0.035915873442166','0.035197555973323','920.2119764838784','920.211976483878402','test','test','2.00'),('2019-03-09 03:59:59','2019-03-09 15:59:59','BQXBTC','4h','0.000038660000000','0.000039170000000','0.035756247337978','0.036227941237160','924.8899983957176','924.889998395717612','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:26:36
