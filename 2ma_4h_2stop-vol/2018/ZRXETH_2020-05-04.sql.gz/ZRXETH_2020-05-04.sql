-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-20 03:59:59','2018-04-09 11:59:59','ZRXETH','4h','0.000893000000000','0.001362800000000','1.297777777777778','1.980528057732985','1453.278586537265','1453.278586537265028','test','test','0.0'),('2018-04-11 07:59:59','2018-04-11 11:59:59','ZRXETH','4h','0.001400000000000','0.001436990000000','1.449500062212268','1.487797924570291','1035.3571872944772','1035.357187294477171','test','test','0.0'),('2018-04-11 15:59:59','2018-04-11 23:59:59','ZRXETH','4h','0.001424860000000','0.001396362800000','1.458010698291829','1.428850484325992','1023.2659337000329','1023.265933700032861','test','test','2.00'),('2018-04-12 03:59:59','2018-04-12 07:59:59','ZRXETH','4h','0.001444240000000','0.001415355200000','1.451530650743865','1.422500037728988','1005.0480880905285','1005.048088090528495','test','test','2.00'),('2018-04-12 19:59:59','2018-04-12 23:59:59','ZRXETH','4h','0.001382620000000','0.001401240000000','1.445079403407226','1.464540555778407','1045.17467084754','1045.174670847540028','test','test','0.0'),('2018-04-13 15:59:59','2018-04-13 23:59:59','ZRXETH','4h','0.001388970000000','0.001388000000000','1.449404103934155','1.448391899220723','1043.5100138477826','1043.510013847782602','test','test','0.06'),('2018-04-14 11:59:59','2018-04-21 03:59:59','ZRXETH','4h','0.001437570000000','0.001523810000000','1.449179169553392','1.536115605053774','1008.07555079293','1008.075550792930017','test','test','0.95'),('2018-04-22 15:59:59','2018-04-23 19:59:59','ZRXETH','4h','0.001594820000000','0.001562923600000','1.468498377442366','1.439128409893519','920.792551787892','920.792551787891966','test','test','1.99'),('2018-04-24 11:59:59','2018-04-25 07:59:59','ZRXETH','4h','0.001602350000000','0.001605000000000','1.461971717987067','1.464389557443282','912.3922476282127','912.392247628212658','test','test','0.0'),('2018-04-26 07:59:59','2018-04-27 11:59:59','ZRXETH','4h','0.001756590000000','0.001721458200000','1.462509015644003','1.433258835331123','832.5841634325616','832.584163432561581','test','test','1.99'),('2018-04-29 15:59:59','2018-04-30 07:59:59','ZRXETH','4h','0.001810420000000','0.001774211600000','1.456008975574474','1.426888796062985','804.2382295679865','804.238229567986536','test','test','1.99'),('2018-04-30 11:59:59','2018-04-30 23:59:59','ZRXETH','4h','0.001806240000000','0.001770115200000','1.449537824571921','1.420547068080483','802.516733419657','802.516733419657044','test','test','2.00'),('2018-05-02 03:59:59','2018-05-06 11:59:59','ZRXETH','4h','0.001786950000000','0.001878430000000','1.443095434240490','1.516972358790321','807.5746015504018','807.574601550401781','test','test','1.09'),('2018-05-07 11:59:59','2018-05-14 19:59:59','ZRXETH','4h','0.002217220000000','0.002186510000000','1.459512528584898','1.439297290695630','658.2623864952045','658.262386495204510','test','test','1.67'),('2018-05-19 23:59:59','2018-05-20 03:59:59','ZRXETH','4h','0.002104750000000','0.002083500000000','1.455020253498393','1.440330062080485','691.3031255485894','691.303125548589378','test','test','1.00'),('2018-05-23 19:59:59','2018-05-24 03:59:59','ZRXETH','4h','0.002354770000000','0.002307674600000','1.451755766516636','1.422720651186303','616.5170129212773','616.517012921277342','test','test','2.00'),('2018-05-24 19:59:59','2018-05-25 07:59:59','ZRXETH','4h','0.002320000000000','0.002273600000000','1.445303518665451','1.416397448292142','622.9756545971771','622.975654597177140','test','test','1.99'),('2018-05-28 07:59:59','2018-05-28 11:59:59','ZRXETH','4h','0.002125350000000','0.002091700000000','1.438879947471382','1.416098612523062','677.0084680035676','677.008468003567600','test','test','1.58'),('2018-05-29 11:59:59','2018-06-01 15:59:59','ZRXETH','4h','0.002177980000000','0.002167680000000','1.433817428593978','1.427036687028620','658.3244238211452','658.324423821145160','test','test','0.94'),('2018-06-03 15:59:59','2018-06-03 19:59:59','ZRXETH','4h','0.002183070000000','0.002161000000000','1.432310597135009','1.417830486612319','656.0992534069037','656.099253406903699','test','test','1.01'),('2018-06-06 11:59:59','2018-06-06 15:59:59','ZRXETH','4h','0.002158050000000','0.002150460000000','1.429092794796634','1.424066583952350','662.2148674945594','662.214867494559371','test','test','0.35'),('2018-06-06 23:59:59','2018-06-07 11:59:59','ZRXETH','4h','0.002211310000000','0.002167083800000','1.427975859053460','1.399416341872391','645.7601417501207','645.760141750120738','test','test','2.00'),('2018-06-07 15:59:59','2018-06-07 23:59:59','ZRXETH','4h','0.002199630000000','0.002155637400000','1.421629299679889','1.393196713686291','646.3038327718248','646.303832771824773','test','test','1.99'),('2018-06-30 03:59:59','2018-07-10 03:59:59','ZRXETH','4h','0.001605700000000','0.001910000000000','1.415310947236867','1.683529868108872','881.4292503187813','881.429250318781328','test','test','0.0'),('2018-07-10 19:59:59','2018-07-10 23:59:59','ZRXETH','4h','0.001930100000000','0.001891498000000','1.474915151875090','1.445416848837588','764.1651478550804','764.165147855080363','test','test','1.99'),('2018-07-11 15:59:59','2018-07-11 19:59:59','ZRXETH','4h','0.001948990000000','0.001910010200000','1.468359973422312','1.438992773953866','753.3953347232731','753.395334723273095','test','test','2.00'),('2018-07-13 03:59:59','2018-07-13 07:59:59','ZRXETH','4h','0.001956070000000','0.001916948600000','1.461833929095991','1.432597250514071','747.3321144417075','747.332114441707517','test','test','1.99'),('2018-07-13 19:59:59','2018-07-21 03:59:59','ZRXETH','4h','0.002087150000000','0.002319540000000','1.455336889411120','1.617378783731246','697.2842821125073','697.284282112507299','test','test','0.0'),('2018-07-24 07:59:59','2018-07-24 11:59:59','ZRXETH','4h','0.002486400000000','0.002436672000000','1.491346199260037','1.461519275274836','599.8013993162953','599.801399316295260','test','test','2.00'),('2018-07-27 19:59:59','2018-07-30 11:59:59','ZRXETH','4h','0.002471310000000','0.002435400000000','1.484717993929992','1.463143920599642','600.7817691548175','600.781769154817539','test','test','1.57'),('2018-07-30 19:59:59','2018-07-31 11:59:59','ZRXETH','4h','0.002508630000000','0.002478750000000','1.479923755412136','1.462296555780578','589.9330532649839','589.933053264983869','test','test','1.19'),('2018-07-31 23:59:59','2018-08-01 03:59:59','ZRXETH','4h','0.002588100000000','0.002536338000000','1.476006599938457','1.446486467939688','570.3050886513106','570.305088651310598','test','test','1.99'),('2018-08-01 23:59:59','2018-08-02 11:59:59','ZRXETH','4h','0.002517650000000','0.002467297000000','1.469446570605397','1.440057639193289','583.6580027427946','583.658002742794565','test','test','1.99'),('2018-08-07 11:59:59','2018-08-07 23:59:59','ZRXETH','4h','0.002460000000000','0.002410800000000','1.462915696958262','1.433657383019097','594.6811776253098','594.681177625309829','test','test','2.00'),('2018-08-09 15:59:59','2018-08-10 11:59:59','ZRXETH','4h','0.002466000000000','0.002435210000000','1.456413849416226','1.438229347216905','590.5976680519974','590.597668051997402','test','test','1.24'),('2018-08-10 23:59:59','2018-08-14 03:59:59','ZRXETH','4h','0.002604410000000','0.002552321800000','1.452372848927487','1.423325391948937','557.6590663249976','557.659066324997639','test','test','2.00'),('2018-08-14 15:59:59','2018-08-14 23:59:59','ZRXETH','4h','0.002626280000000','0.002573754400000','1.445917858487809','1.416999501318053','550.5573885830183','550.557388583018337','test','test','2.00'),('2018-08-15 07:59:59','2018-08-15 11:59:59','ZRXETH','4h','0.002561390000000','0.002510162200000','1.439491556894531','1.410701725756641','561.9962430143518','561.996243014351762','test','test','1.99'),('2018-08-17 15:59:59','2018-08-17 23:59:59','ZRXETH','4h','0.002701320000000','0.002647293600000','1.433093816641666','1.404431940308833','530.5161242065604','530.516124206560448','test','test','2.00'),('2018-08-18 15:59:59','2018-08-18 19:59:59','ZRXETH','4h','0.002540000000000','0.002511110000000','1.426724510789925','1.410496923736098','561.7025633031202','561.702563303120201','test','test','1.13'),('2018-08-19 11:59:59','2018-08-19 15:59:59','ZRXETH','4h','0.002598570000000','0.002572170000000','1.423118380333520','1.408660303298533','547.6544331434287','547.654433143428719','test','test','1.01'),('2018-08-23 23:59:59','2018-08-25 15:59:59','ZRXETH','4h','0.002588850000000','0.002573660000000','1.419905474325745','1.411574221392973','548.469580827682','548.469580827681966','test','test','1.37'),('2018-08-26 15:59:59','2018-08-30 19:59:59','ZRXETH','4h','0.002617520000000','0.002632000000000','1.418054084785129','1.425898694624858','541.7548231857364','541.754823185736427','test','test','0.78'),('2018-09-01 03:59:59','2018-09-02 15:59:59','ZRXETH','4h','0.002738100000000','0.002698080000000','1.419797331416179','1.399045609710151','518.5337757628207','518.533775762820710','test','test','1.46'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ZRXETH','4h','0.002754040000000','0.002736120000000','1.415185837703729','1.405977500057344','513.8581275884623','513.858127588462253','test','test','0.65'),('2018-09-04 07:59:59','2018-09-05 19:59:59','ZRXETH','4h','0.002804180000000','0.002748096400000','1.413139540448976','1.384876749639996','503.94038201862094','503.940382018620937','test','test','1.99'),('2018-09-06 03:59:59','2018-09-06 07:59:59','ZRXETH','4h','0.002793960000000','0.002738080800000','1.406858920269203','1.378721741863819','503.53581306432557','503.535813064325566','test','test','2.00'),('2018-09-06 15:59:59','2018-09-10 23:59:59','ZRXETH','4h','0.002858290000000','0.002809000000000','1.400606213956896','1.376453353230400','490.0154336882876','490.015433688287601','test','test','1.72'),('2018-09-21 07:59:59','2018-09-21 19:59:59','ZRXETH','4h','0.002662500000000','0.002609250000000','1.395238911573230','1.367334133341765','524.0333940181146','524.033394018114564','test','test','1.99'),('2018-09-24 07:59:59','2018-09-24 11:59:59','ZRXETH','4h','0.002694850000000','0.002640953000000','1.389037849744015','1.361257092749135','515.4416200322895','515.441620032289507','test','test','2.00'),('2018-09-24 15:59:59','2018-09-25 03:59:59','ZRXETH','4h','0.002931780000000','0.002873144400000','1.382864348189597','1.355207061225805','471.6808042177781','471.680804217778075','test','test','2.00'),('2018-09-25 23:59:59','2018-09-29 03:59:59','ZRXETH','4h','0.002983000000000','0.002923340000000','1.376718284419866','1.349183918731469','461.521382641591','461.521382641591003','test','test','2.00'),('2018-10-04 15:59:59','2018-10-05 19:59:59','ZRXETH','4h','0.002827900000000','0.002812290000000','1.370599536489111','1.363033830925055','484.6704397217409','484.670439721740877','test','test','0.55'),('2018-10-07 03:59:59','2018-10-15 07:59:59','ZRXETH','4h','0.002898240000000','0.003421700000000','1.368918268585988','1.616162788320041','472.3274361633225','472.327436163322488','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','ZRXETH','4h','0.003615410000000','0.003543101800000','1.423861495193555','1.395384265289684','393.831265387205','393.831265387205008','test','test','2.00'),('2018-10-16 19:59:59','2018-10-25 07:59:59','ZRXETH','4h','0.004069980000000','0.004171840000000','1.417533221881584','1.453010038470574','348.2899724032019','348.289972403201887','test','test','0.0'),('2018-11-01 19:59:59','2018-11-02 23:59:59','ZRXETH','4h','0.004095010000000','0.004045140000000','1.425416958901359','1.408057894151722','348.0863194232392','348.086319423239217','test','test','1.28'),('2018-11-03 23:59:59','2018-11-04 03:59:59','ZRXETH','4h','0.004062670000000','0.004052540000000','1.421559388956995','1.418014824271669','349.9076688377336','349.907668837733581','test','test','0.24'),('2018-11-27 11:59:59','2018-11-27 23:59:59','ZRXETH','4h','0.003287520000000','0.003262630000000','1.420771707915812','1.410014964896751','432.1712743696804','432.171274369680418','test','test','0.75'),('2018-11-28 15:59:59','2018-12-03 11:59:59','ZRXETH','4h','0.003405150000000','0.003442700000000','1.418381320578243','1.434022399117430','416.54004099033597','416.540040990335967','test','test','0.0'),('2018-12-03 19:59:59','2018-12-03 23:59:59','ZRXETH','4h','0.003555140000000','0.003484037200000','1.421857115809173','1.393419973492990','399.94405728302485','399.944057283024847','test','test','2.00'),('2018-12-05 19:59:59','2018-12-05 23:59:59','ZRXETH','4h','0.003437140000000','0.003420110000000','1.415537750850021','1.408524184950181','411.8359307011123','411.835930701112318','test','test','0.49'),('2018-12-06 15:59:59','2018-12-06 19:59:59','ZRXETH','4h','0.003439330000000','0.003432420000000','1.413979180650057','1.411138337771272','411.12053238568467','411.120532385684669','test','test','0.20'),('2018-12-06 23:59:59','2018-12-07 03:59:59','ZRXETH','4h','0.003501490000000','0.003549080000000','1.413347882232549','1.432557197614128','403.64184453833917','403.641844538339171','test','test','0.0'),('2018-12-08 03:59:59','2018-12-09 19:59:59','ZRXETH','4h','0.003582000000000','0.003510360000000','1.417616618984011','1.389264286604331','395.7612001630405','395.761200163040485','test','test','1.99'),('2018-12-11 11:59:59','2018-12-11 15:59:59','ZRXETH','4h','0.003497130000000','0.003491340000000','1.411316100677415','1.408979464572117','403.5640941793457','403.564094179345716','test','test','0.16'),('2018-12-11 19:59:59','2018-12-11 23:59:59','ZRXETH','4h','0.003505340000000','0.003435233200000','1.410796848209571','1.382580911245380','402.47075838850765','402.470758388507647','test','test','2.00'),('2019-01-13 19:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002310750000000','0.002264535000000','1.404526639995307','1.376436107195401','607.8228453944853','607.822845394485284','test','test','2.00'),('2019-01-15 23:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002330220000000','0.002482570000000','1.398284299373105','1.489704256720262','600.0653583666372','600.065358366637156','test','test','0.0'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002306920000000','1.418599845450252','1.390227848541247','602.6337491292487','602.633749129248713','test','test','2.00'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.412294957248250','1.451979777380084','794.4908935302177','794.490893530217704','test','test','0.0'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZRXETH','4h','0.001827100000000','0.001790558000000','1.421113806166436','1.392691530043107','777.7974966703716','777.797496670371629','test','test','2.00'),('2019-02-27 07:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001824730000000','0.001813540000000','1.414797744805696','1.406121619151832','775.3463497644561','775.346349764456136','test','test','0.61');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 12:03:31
