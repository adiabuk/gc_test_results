-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-01-11 19:59:59','2018-01-11 23:59:59','EOSETH','4h','0.010079000000000','0.009877420000000','1.297777777777778','1.271822222222222','128.76056928046214','128.760569280462136','test','test','1.99'),('2018-01-12 07:59:59','2018-01-14 23:59:59','EOSETH','4h','0.010800000000000','0.010584000000000','1.292009876543210','1.266169679012346','119.63054412437127','119.630544124371269','test','test','2.00'),('2018-01-16 15:59:59','2018-01-16 19:59:59','EOSETH','4h','0.010560000000000','0.010348800000000','1.286267610425240','1.260542258216735','121.80564492663257','121.805644926632567','test','test','1.99'),('2018-01-18 03:59:59','2018-01-18 19:59:59','EOSETH','4h','0.010295000000000','0.010225000000000','1.280550865490017','1.271843865918934','124.3857081583309','124.385708158330900','test','test','0.70'),('2018-01-19 15:59:59','2018-01-28 07:59:59','EOSETH','4h','0.010424000000000','0.012165000000000','1.278615976696443','1.492168395674619','122.66078057333488','122.660780573334875','test','test','0.0'),('2018-02-28 03:59:59','2018-02-28 07:59:59','EOSETH','4h','0.009848000000000','0.009958000000000','1.326072069802704','1.340884003969875','134.65394697427942','134.653946974279421','test','test','0.0'),('2018-03-01 23:59:59','2018-03-02 03:59:59','EOSETH','4h','0.009811000000000','0.009694000000000','1.329363610728742','1.313510431393785','135.49725927313645','135.497259273136450','test','test','1.19'),('2018-03-19 03:59:59','2018-03-19 07:59:59','EOSETH','4h','0.008596000000000','0.008617000000000','1.325840681987640','1.329079706455037','154.239260352215','154.239260352215013','test','test','0.0'),('2018-03-19 11:59:59','2018-04-09 03:59:59','EOSETH','4h','0.008896000000000','0.014617000000000','1.326560465202618','2.179668875884293','149.11875732943096','149.118757329430963','test','test','0.0'),('2018-04-10 11:59:59','2018-04-10 19:59:59','EOSETH','4h','0.015077000000000','0.014775460000000','1.516140112020768','1.485817309780353','100.55980049219126','100.559800492191258','test','test','1.99'),('2018-04-11 07:59:59','2018-04-15 03:59:59','EOSETH','4h','0.015150000000000','0.015906000000000','1.509401711522898','1.584722351385031','99.63047600811205','99.630476008112055','test','test','0.0'),('2018-04-17 03:59:59','2018-04-17 11:59:59','EOSETH','4h','0.017344000000000','0.016997120000000','1.526139631492261','1.495616838862416','87.99236805190618','87.992368051906183','test','test','2.00'),('2018-04-18 23:59:59','2018-04-19 19:59:59','EOSETH','4h','0.017184000000000','0.016840320000000','1.519356788685628','1.488969652911916','88.4169453378508','88.416945337850805','test','test','1.99'),('2018-04-20 03:59:59','2018-05-03 07:59:59','EOSETH','4h','0.016963000000000','0.024492000000000','1.512604091847026','2.183970961358095','89.17078888445592','89.170788884455916','test','test','0.0'),('2018-05-07 11:59:59','2018-05-07 19:59:59','EOSETH','4h','0.024099000000000','0.023620000000000','1.661796729516152','1.628766287031475','68.95708243147651','68.957082431476508','test','test','1.98'),('2018-05-08 03:59:59','2018-05-09 19:59:59','EOSETH','4h','0.023940000000000','0.023489000000000','1.654456631186224','1.623288713865214','69.10846412640869','69.108464126408691','test','test','1.88'),('2018-05-10 15:59:59','2018-05-11 07:59:59','EOSETH','4h','0.024220000000000','0.023735600000000','1.647530427337110','1.614579818790368','68.0235519131755','68.023551913175496','test','test','1.99'),('2018-05-24 15:59:59','2018-05-25 07:59:59','EOSETH','4h','0.020631000000000','0.020218380000000','1.640208069882279','1.607403908484633','79.50211186478012','79.502111864780119','test','test','1.99'),('2018-05-25 23:59:59','2018-05-29 07:59:59','EOSETH','4h','0.020730000000000','0.021338000000000','1.632918256238358','1.680810890092334','78.77077936509203','78.770779365092025','test','test','1.06'),('2018-05-30 03:59:59','2018-06-01 07:59:59','EOSETH','4h','0.021447000000000','0.021018060000000','1.643561063761463','1.610689842486234','76.63361140306166','76.633611403061664','test','test','1.99'),('2018-06-01 23:59:59','2018-06-10 19:59:59','EOSETH','4h','0.021072000000000','0.023009000000000','1.636256347922523','1.786665827133131','77.65073784750015','77.650737847500153','test','test','0.0'),('2018-07-02 15:59:59','2018-07-06 07:59:59','EOSETH','4h','0.018815000000000','0.018438700000000','1.669680676635992','1.636287063103272','88.7419971637519','88.741997163751904','test','test','1.99'),('2018-07-16 23:59:59','2018-07-17 03:59:59','EOSETH','4h','0.016891000000000','0.016862000000000','1.662259873628721','1.659405955190782','98.41098061859694','98.410980618596938','test','test','0.17'),('2018-07-17 15:59:59','2018-07-21 03:59:59','EOSETH','4h','0.017077000000000','0.017092000000000','1.661625669531401','1.663085199018019','97.3019657745155','97.301965774515494','test','test','0.0'),('2018-07-22 11:59:59','2018-07-22 23:59:59','EOSETH','4h','0.017527000000000','0.017176460000000','1.661950009417316','1.628711009228970','94.82227474281486','94.822274742814855','test','test','1.99'),('2018-07-23 03:59:59','2018-07-23 19:59:59','EOSETH','4h','0.017408000000000','0.017470000000000','1.654563564931017','1.660456426892513','95.04616066929097','95.046160669290970','test','test','0.22'),('2018-07-24 15:59:59','2018-07-27 03:59:59','EOSETH','4h','0.017750000000000','0.017617000000000','1.655873089811349','1.643465702715861','93.2886247781042','93.288624778104193','test','test','0.74'),('2018-07-30 11:59:59','2018-07-30 15:59:59','EOSETH','4h','0.017677000000000','0.017330000000000','1.653115892679019','1.620665181881960','93.51789855060353','93.517898550603533','test','test','1.96'),('2018-08-07 15:59:59','2018-08-07 23:59:59','EOSETH','4h','0.017403000000000','0.017355000000000','1.645904623613006','1.641364979762324','94.57591355588151','94.575913555881513','test','test','0.27'),('2018-08-15 03:59:59','2018-08-15 07:59:59','EOSETH','4h','0.016567000000000','0.016491000000000','1.644895813868410','1.637349964779619','99.28748801040683','99.287488010406832','test','test','0.45'),('2018-08-17 15:59:59','2018-08-22 23:59:59','EOSETH','4h','0.016541000000000','0.017455000000000','1.643218958515345','1.734017708777301','99.34217752949309','99.342177529493085','test','test','0.0'),('2018-08-23 07:59:59','2018-09-14 07:59:59','EOSETH','4h','0.017404000000000','0.025149000000000','1.663396458573557','2.403628909254561','95.57552623382887','95.575526233828867','test','test','0.0'),('2018-09-17 19:59:59','2018-09-17 23:59:59','EOSETH','4h','0.024909000000000','0.024741000000000','1.827892558724892','1.815564245670743','73.38281579850222','73.382815798502222','test','test','0.67'),('2018-09-18 11:59:59','2018-09-18 15:59:59','EOSETH','4h','0.024630000000000','0.024137400000000','1.825152933601747','1.788649874929712','74.10283936669701','74.102839366697012','test','test','1.99'),('2018-09-19 19:59:59','2018-09-21 19:59:59','EOSETH','4h','0.025091000000000','0.024698000000000','1.817041142785740','1.788580851481496','72.4180440311562','72.418044031156199','test','test','1.56'),('2018-09-25 11:59:59','2018-09-25 15:59:59','EOSETH','4h','0.024872000000000','0.024567000000000','1.810716633607019','1.788512203997412','72.80140855608794','72.801408556087935','test','test','1.22'),('2018-09-25 19:59:59','2018-09-25 23:59:59','EOSETH','4h','0.025690000000000','0.025176200000000','1.805782315915995','1.769666669597675','70.29125402553503','70.291254025535025','test','test','2.00'),('2018-09-26 03:59:59','2018-09-29 11:59:59','EOSETH','4h','0.025288000000000','0.024782240000000','1.797756616734146','1.761801484399463','71.0912929743019','71.091292974301894','test','test','2.00'),('2018-10-03 23:59:59','2018-10-07 19:59:59','EOSETH','4h','0.025460000000000','0.025340000000000','1.789766587326439','1.781330923914060','70.29719510315942','70.297195103159424','test','test','0.94'),('2018-10-07 23:59:59','2018-10-14 23:59:59','EOSETH','4h','0.025507000000000','0.026467000000000','1.787891995457021','1.855182398704708','70.09417004967348','70.094170049673480','test','test','0.01'),('2018-10-15 19:59:59','2018-10-16 07:59:59','EOSETH','4h','0.026383000000000','0.026017000000000','1.802845418400952','1.777835320112859','68.33360188003455','68.333601880034550','test','test','1.38'),('2018-10-17 11:59:59','2018-10-26 11:59:59','EOSETH','4h','0.025990000000000','0.026482000000000','1.797287618781375','1.831310916528217','69.1530442008994','69.153044200899402','test','test','0.0'),('2018-10-31 15:59:59','2018-10-31 19:59:59','EOSETH','4h','0.026463000000000','0.026508000000000','1.804848351614007','1.807917473626728','68.20271139379537','68.202711393795369','test','test','0.0'),('2018-11-01 23:59:59','2018-11-03 23:59:59','EOSETH','4h','0.026416000000000','0.026584000000000','1.805530378727945','1.817013158241357','68.34987805602458','68.349878056024579','test','test','0.0'),('2018-11-04 07:59:59','2018-11-04 19:59:59','EOSETH','4h','0.026824000000000','0.026287520000000','1.808082107508703','1.771920465358529','67.40538724682013','67.405387246820126','test','test','1.99'),('2018-11-06 07:59:59','2018-11-06 11:59:59','EOSETH','4h','0.026514000000000','0.026543000000000','1.800046187030887','1.802015008763703','67.89040457987807','67.890404579878066','test','test','0.0'),('2018-11-19 03:59:59','2018-11-27 11:59:59','EOSETH','4h','0.026028000000000','0.028041000000000','1.800483702971513','1.939732730714008','69.17487716964473','69.174877169644731','test','test','0.0'),('2018-12-15 23:59:59','2018-12-20 19:59:59','EOSETH','4h','0.022515000000000','0.023718000000000','1.831427931358734','1.929283041348721','81.34256857023023','81.342568570230227','test','test','1.90'),('2019-01-09 23:59:59','2019-01-10 19:59:59','EOSETH','4h','0.019325000000000','0.018938500000000','1.853173511356508','1.816110041129378','95.8951364220703','95.895136422070294','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:50:17
