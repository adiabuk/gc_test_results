-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-07 23:59:59','2018-06-09 03:59:59','WAVESETH','4h','0.007544000000000','0.007426000000000','1.297777777777778','1.277478496524096','172.02780723459406','172.027807234594064','test','test','1.56'),('2018-06-09 11:59:59','2018-06-09 19:59:59','WAVESETH','4h','0.007555000000000','0.007411000000000','1.293266826388071','1.268616869670681','171.18025498187566','171.180254981875663','test','test','1.90'),('2018-06-13 03:59:59','2018-06-13 07:59:59','WAVESETH','4h','0.007534000000000','0.007383320000000','1.287789058228651','1.262033277064078','170.9303236300306','170.930323630030614','test','test','2.00'),('2018-06-13 11:59:59','2018-06-13 15:59:59','WAVESETH','4h','0.007408000000000','0.007259840000000','1.282065551303190','1.256424240277126','173.06500422559265','173.065004225592645','test','test','2.00'),('2018-06-18 19:59:59','2018-06-18 23:59:59','WAVESETH','4h','0.007108000000000','0.007038000000000','1.276367482186287','1.263797740521537','179.56773806785125','179.567738067851252','test','test','0.98'),('2018-06-30 11:59:59','2018-06-30 15:59:59','WAVESETH','4h','0.006394000000000','0.006296000000000','1.273574206260787','1.254054301316534','199.1827035127912','199.182703512791193','test','test','1.53'),('2018-07-02 15:59:59','2018-07-05 07:59:59','WAVESETH','4h','0.006500000000000','0.006379000000000','1.269236449606508','1.245609124929218','195.267146093309','195.267146093309009','test','test','1.86'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESETH','4h','0.006405000000000','0.006276900000000','1.263985933011555','1.238706214351324','197.34362732420846','197.343627324208455','test','test','1.99'),('2018-07-18 03:59:59','2018-07-18 07:59:59','WAVESETH','4h','0.006263000000000','0.006246000000000','1.258368217753726','1.254952560767966','200.92099916233846','200.920999162338461','test','test','0.27'),('2018-07-18 15:59:59','2018-07-19 03:59:59','WAVESETH','4h','0.006382000000000','0.006279000000000','1.257609182868001','1.237312450521495','197.05565384957717','197.055653849577169','test','test','1.61'),('2018-07-20 11:59:59','2018-07-20 19:59:59','WAVESETH','4h','0.006569000000000','0.006437620000000','1.253098797902111','1.228036821944069','190.7594455628119','190.759445562811891','test','test','2.00'),('2018-08-10 11:59:59','2018-08-11 03:59:59','WAVESETH','4h','0.005050000000000','0.005474000000000','1.247529469911435','1.352272538276276','247.03553859632385','247.035538596323846','test','test','0.29'),('2018-08-11 07:59:59','2018-08-28 19:59:59','WAVESETH','4h','0.005511000000000','0.007710000000000','1.270805707325845','1.777882780526631','230.5943943614307','230.594394361430687','test','test','0.0'),('2018-08-29 11:59:59','2018-08-29 15:59:59','WAVESETH','4h','0.007810000000000','0.007653800000000','1.383489501370463','1.355819711343054','177.14334204487366','177.143342044873663','test','test','2.00'),('2018-08-31 15:59:59','2018-08-31 19:59:59','WAVESETH','4h','0.007679000000000','0.007525420000000','1.377340659142150','1.349793845959307','179.3645864229913','179.364586422991295','test','test','2.00'),('2018-09-03 19:59:59','2018-09-15 15:59:59','WAVESETH','4h','0.007723000000000','0.010380000000000','1.371219145101519','1.842969665434905','177.55006410740884','177.550064107408843','test','test','0.10'),('2018-09-19 03:59:59','2018-09-20 15:59:59','WAVESETH','4h','0.010698000000000','0.010484040000000','1.476052594064493','1.446531542183203','137.97463021728296','137.974630217282964','test','test','2.00'),('2018-09-26 19:59:59','2018-09-27 19:59:59','WAVESETH','4h','0.010327000000000','0.010120460000000','1.469492360313095','1.440102513106833','142.2961518653138','142.296151865313789','test','test','1.99'),('2018-10-05 19:59:59','2018-10-05 23:59:59','WAVESETH','4h','0.009863000000000','0.009665740000000','1.462961283156148','1.433702057493025','148.32822499808864','148.328224998088643','test','test','1.99'),('2018-10-06 03:59:59','2018-10-06 07:59:59','WAVESETH','4h','0.009701000000000','0.009675000000000','1.456459233008788','1.452555724086179','150.13495856187896','150.134958561878960','test','test','0.26'),('2018-10-11 23:59:59','2018-10-12 11:59:59','WAVESETH','4h','0.009728000000000','0.009638000000000','1.455591786581541','1.442125168490223','149.62908990353014','149.629089903530144','test','test','1.54'),('2018-10-14 23:59:59','2018-10-15 07:59:59','WAVESETH','4h','0.009629000000000','0.009436420000000','1.452599204783471','1.423547220687802','150.8567042043276','150.856704204327599','test','test','1.99'),('2018-10-16 15:59:59','2018-10-16 19:59:59','WAVESETH','4h','0.009594000000000','0.009570000000000','1.446143208317767','1.442525589285077','150.73412636207698','150.734126362076978','test','test','0.25'),('2018-10-17 07:59:59','2018-10-19 15:59:59','WAVESETH','4h','0.009749000000000','0.009649000000000','1.445339292977169','1.430513779663217','148.2551331395188','148.255133139518790','test','test','1.02'),('2018-10-20 19:59:59','2018-10-20 23:59:59','WAVESETH','4h','0.009663000000000','0.009590000000000','1.442044734462957','1.431150678205501','149.23364736240887','149.233647362408874','test','test','0.75'),('2018-10-23 11:59:59','2018-10-23 23:59:59','WAVESETH','4h','0.009829000000000','0.009700000000000','1.439623833072411','1.420729594140033','146.46696846804468','146.466968468044684','test','test','1.61'),('2018-10-24 19:59:59','2018-10-24 23:59:59','WAVESETH','4h','0.009695000000000','0.009692000000000','1.435425113309661','1.434980938442211','148.05828915004236','148.058289150042356','test','test','0.03'),('2018-11-18 15:59:59','2018-11-18 19:59:59','WAVESETH','4h','0.008547000000000','0.008618000000000','1.435326407783561','1.447249676176287','167.9333576440342','167.933357644034203','test','test','0.0'),('2018-11-19 03:59:59','2018-11-20 03:59:59','WAVESETH','4h','0.008747000000000','0.008572060000000','1.437976022981944','1.409216502522305','164.3964814201377','164.396481420137690','test','test','2.00'),('2018-11-24 11:59:59','2018-11-24 23:59:59','WAVESETH','4h','0.009025000000000','0.008844500000000','1.431585018435358','1.402953318066651','158.62437877400083','158.624378774000832','test','test','2.00'),('2018-11-25 03:59:59','2018-12-22 07:59:59','WAVESETH','4h','0.008990000000000','0.029594000000000','1.425222418353423','4.691660984288231','158.53419558992468','158.534195589924678','test','test','1.09'),('2018-12-22 15:59:59','2018-12-22 19:59:59','WAVESETH','4h','0.033614000000000','0.032941720000000','2.151097655227824','2.108075702123268','63.994099340388665','63.994099340388665','test','test','1.99'),('2019-01-13 19:59:59','2019-01-14 15:59:59','WAVESETH','4h','0.022350000000000','0.021903000000000','2.141537221204590','2.098706476780498','95.81822018812483','95.818220188124826','test','test','1.99'),('2019-01-16 11:59:59','2019-01-16 15:59:59','WAVESETH','4h','0.021248000000000','0.021219000000000','2.132019277999236','2.129109424880732','100.33976270704237','100.339762707042368','test','test','0.13'),('2019-01-17 03:59:59','2019-01-17 07:59:59','WAVESETH','4h','0.021201000000000','0.021135000000000','2.131372643972902','2.124737551547912','100.53170340893834','100.531703408938341','test','test','0.31'),('2019-01-17 11:59:59','2019-01-17 19:59:59','WAVESETH','4h','0.021167000000000','0.021083000000000','2.129898178989571','2.121445802789112','100.62352619594516','100.623526195945161','test','test','0.39'),('2019-01-18 11:59:59','2019-01-18 15:59:59','WAVESETH','4h','0.021613000000000','0.021180740000000','2.128019873167247','2.085459475703902','98.46018013081232','98.460180130812319','test','test','2.00'),('2019-01-22 19:59:59','2019-01-24 23:59:59','WAVESETH','4h','0.022779000000000','0.023377000000000','2.118562007064281','2.174179026258471','93.00504881971469','93.005048819714688','test','test','0.0'),('2019-01-27 11:59:59','2019-01-27 15:59:59','WAVESETH','4h','0.025120000000000','0.024617600000000','2.130921344662990','2.088302917769730','84.82967136397254','84.829671363972537','test','test','2.00'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WAVESETH','4h','0.024754000000000','0.024258920000000','2.121450583131155','2.079021571468532','85.70132435691826','85.701324356918263','test','test','2.00'),('2019-01-28 07:59:59','2019-02-01 23:59:59','WAVESETH','4h','0.025285000000000','0.025468000000000','2.112021913872794','2.127307656812826','83.52864994553269','83.528649945532692','test','test','0.86'),('2019-02-03 11:59:59','2019-02-04 07:59:59','WAVESETH','4h','0.026232000000000','0.025707360000000','2.115418745637245','2.073110370724500','80.6426786229508','80.642678622950797','test','test','1.99'),('2019-02-04 11:59:59','2019-02-04 23:59:59','WAVESETH','4h','0.025830000000000','0.025313400000000','2.106016884545524','2.063896546854613','81.53375472495254','81.533754724952544','test','test','1.99'),('2019-02-28 15:59:59','2019-02-28 19:59:59','WAVESETH','4h','0.019848000000000','0.019465000000000','2.096656809503100','2.056198347288283','105.63567157915658','105.635671579156579','test','test','1.92'),('2019-03-01 07:59:59','2019-03-01 11:59:59','WAVESETH','4h','0.019820000000000','0.019707000000000','2.087666040122029','2.075763605079961','105.33128355812458','105.331283558124582','test','test','0.57'),('2019-03-03 23:59:59','2019-03-05 15:59:59','WAVESETH','4h','0.020321000000000','0.019914580000000','2.085021054557125','2.043320633465982','102.60425444402959','102.604254444029593','test','test','2.00'),('2019-03-08 15:59:59','2019-03-08 19:59:59','WAVESETH','4h','0.020062000000000','0.019660760000000','2.075754294314649','2.034239208428356','103.46696711766768','103.466967117667679','test','test','2.00'),('2019-03-08 23:59:59','2019-03-09 15:59:59','WAVESETH','4h','0.019865000000000','0.019750000000000','2.066528719673251','2.054565427311689','104.02862923097159','104.028629230971589','test','test','0.57'),('2019-03-10 11:59:59','2019-03-11 23:59:59','WAVESETH','4h','0.020057000000000','0.019897000000000','2.063870210259570','2.047406171089130','102.90024481525505','102.900244815255050','test','test','0.79'),('2019-03-12 11:59:59','2019-03-16 03:59:59','WAVESETH','4h','0.020149000000000','0.019794000000000','2.060211534888361','2.023913202718756','102.24882301297143','102.248823012971428','test','test','1.76'),('2019-03-20 15:59:59','2019-03-21 03:59:59','WAVESETH','4h','0.020224000000000','0.020035000000000','2.052145238850672','2.032967259709910','101.47078910456248','101.470789104562485','test','test','0.93'),('2019-03-21 11:59:59','2019-03-21 15:59:59','WAVESETH','4h','0.020272000000000','0.020318000000000','2.047883465708280','2.052530399381454','101.02029724291043','101.020297242910431','test','test','0.0'),('2019-03-22 11:59:59','2019-03-22 15:59:59','WAVESETH','4h','0.020126000000000','0.020116000000000','2.048916117635652','2.047898073256423','101.8044379228685','101.804437922868502','test','test','0.04'),('2019-03-25 15:59:59','2019-03-25 19:59:59','WAVESETH','4h','0.020258000000000','0.020136000000000','2.048689885551379','2.036352035514985','101.12991833109777','101.129918331097770','test','test','0.60'),('2019-04-01 15:59:59','2019-04-02 07:59:59','WAVESETH','4h','0.020357000000000','0.019949860000000','2.045948141098846','2.005029178276869','100.50342099026608','100.503420990266079','test','test','2.00'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESETH','4h','0.013536000000000','0.013265280000000','2.036855038249519','1.996117937484529','150.4768793033037','150.476879303303690','test','test','2.00'),('2019-05-23 19:59:59','2019-05-23 23:59:59','WAVESETH','4h','0.010850000000000','0.013332000000000','2.027802349190632','2.491673817457097','186.89422573185547','186.894225731855471','test','test','0.0'),('2019-05-25 15:59:59','2019-05-25 19:59:59','WAVESETH','4h','0.010762000000000','0.010755000000000','2.130884897694291','2.129498891906904','198.00082676958658','198.000826769586581','test','test','0.06');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:36:24
