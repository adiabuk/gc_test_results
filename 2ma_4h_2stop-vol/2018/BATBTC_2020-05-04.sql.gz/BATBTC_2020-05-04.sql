-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-30 19:59:59','2018-04-30 23:59:59','BATBTC','4h','0.000054290000000','0.000053204200000','0.033333333333333','0.032666666666666','613.986615091791','613.986615091791009','test','test','2.00'),('2018-05-01 15:59:59','2018-05-02 23:59:59','BATBTC','4h','0.000054840000000','0.000053743200000','0.033185185185185','0.032521481481481','605.1273739092836','605.127373909283619','test','test','1.99'),('2018-05-14 15:59:59','2018-05-15 07:59:59','BATBTC','4h','0.000047090000000','0.000046148200000','0.033037695473251','0.032376941563786','701.5862279305773','701.586227930577252','test','test','1.99'),('2018-05-16 07:59:59','2018-05-17 19:59:59','BATBTC','4h','0.000045470000000','0.000044860000000','0.032890861271148','0.032449615936303','723.3530079425458','723.353007942545787','test','test','1.34'),('2018-06-03 11:59:59','2018-06-03 19:59:59','BATBTC','4h','0.000040250000000','0.000039445000000','0.032792806752293','0.032136950617247','814.728118069394','814.728118069393986','test','test','2.00'),('2018-06-15 11:59:59','2018-06-20 03:59:59','BATBTC','4h','0.000035160000000','0.000037380000000','0.032647060944505','0.034708394144073','928.5284682737517','928.528468273751741','test','test','0.0'),('2018-06-20 15:59:59','2018-06-25 15:59:59','BATBTC','4h','0.000037900000000','0.000041520000000','0.033105134988854','0.036267155797816','873.4864113153973','873.486411315397277','test','test','0.0'),('2018-07-01 15:59:59','2018-07-03 23:59:59','BATBTC','4h','0.000039670000000','0.000038876600000','0.033807806279734','0.033131650154139','852.2260216721452','852.226021672145180','test','test','1.99'),('2018-07-04 15:59:59','2018-07-04 19:59:59','BATBTC','4h','0.000039790000000','0.000038994200000','0.033657549362935','0.032984398375676','845.8796019837929','845.879601983792895','test','test','2.00'),('2018-07-06 23:59:59','2018-07-07 03:59:59','BATBTC','4h','0.000040460000000','0.000039650800000','0.033507960254655','0.032837801049562','828.174993936118','828.174993936117971','test','test','1.99'),('2018-07-08 15:59:59','2018-07-09 03:59:59','BATBTC','4h','0.000041430000000','0.000040601400000','0.033359035986857','0.032691855267120','805.1903448432752','805.190344843275170','test','test','2.00'),('2018-07-09 15:59:59','2018-07-09 19:59:59','BATBTC','4h','0.000041970000000','0.000041130600000','0.033210773604693','0.032546558132599','791.2979176719825','791.297917671982532','test','test','1.99'),('2018-07-11 03:59:59','2018-07-19 03:59:59','BATBTC','4h','0.000040170000000','0.000047730000000','0.033063170166450','0.039285663730263','823.0811592345032','823.081159234503161','test','test','0.0'),('2018-07-23 11:59:59','2018-07-23 15:59:59','BATBTC','4h','0.000050000000000','0.000049000000000','0.034445946513964','0.033757027583685','688.9189302792798','688.918930279279834','test','test','2.00'),('2018-07-24 03:59:59','2018-07-24 07:59:59','BATBTC','4h','0.000047170000000','0.000046226600000','0.034292853418346','0.033606996349979','727.0055844466068','727.005584446606804','test','test','2.00'),('2018-08-06 19:59:59','2018-08-06 23:59:59','BATBTC','4h','0.000037990000000','0.000038840000000','0.034140440736487','0.034904309507901','898.6691428398817','898.669142839881715','test','test','0.0'),('2018-08-07 03:59:59','2018-08-08 11:59:59','BATBTC','4h','0.000039720000000','0.000038925600000','0.034310189352357','0.033623985565310','863.8013432114018','863.801343211401786','test','test','2.00'),('2018-08-17 19:59:59','2018-08-18 03:59:59','BATBTC','4h','0.000033910000000','0.000033350000000','0.034157699621902','0.033593609035401','1007.3046187526393','1007.304618752639271','test','test','1.65'),('2018-08-19 11:59:59','2018-08-19 19:59:59','BATBTC','4h','0.000034970000000','0.000034270600000','0.034032346158235','0.033351699235070','973.186907584647','973.186907584646974','test','test','2.00'),('2018-08-27 19:59:59','2018-08-28 19:59:59','BATBTC','4h','0.000032700000000','0.000032270000000','0.033881091286421','0.033435560116600','1036.1189995847296','1036.118999584729636','test','test','1.31'),('2018-08-28 23:59:59','2018-08-29 03:59:59','BATBTC','4h','0.000032800000000','0.000032144000000','0.033782084359794','0.033106442672598','1029.9415963351762','1029.941596335176200','test','test','2.00'),('2018-09-01 19:59:59','2018-09-01 23:59:59','BATBTC','4h','0.000032440000000','0.000031820000000','0.033631941762639','0.032989161124759','1036.7429643230303','1036.742964323030264','test','test','1.91'),('2018-09-03 03:59:59','2018-09-03 07:59:59','BATBTC','4h','0.000031940000000','0.000031620000000','0.033489101620888','0.033153581504461','1048.5003638349403','1048.500363834940345','test','test','1.00'),('2018-09-05 07:59:59','2018-09-05 11:59:59','BATBTC','4h','0.000032520000000','0.000031869600000','0.033414541595015','0.032746250763115','1027.5074291210126','1027.507429121012592','test','test','2.00'),('2018-09-20 23:59:59','2018-09-21 03:59:59','BATBTC','4h','0.000025060000000','0.000024990000000','0.033266032521260','0.033173110642709','1327.4554078714993','1327.455407871499347','test','test','0.27'),('2018-09-21 11:59:59','2018-09-21 15:59:59','BATBTC','4h','0.000026440000000','0.000025911200000','0.033245383214915','0.032580475550617','1257.3896828636573','1257.389682863657299','test','test','2.00'),('2018-09-21 19:59:59','2018-09-22 03:59:59','BATBTC','4h','0.000026120000000','0.000025597600000','0.033097625956182','0.032435673437058','1267.1372877558274','1267.137287755827401','test','test','2.00'),('2018-09-22 07:59:59','2018-09-24 07:59:59','BATBTC','4h','0.000026000000000','0.000025480000000','0.032950525396377','0.032291514888449','1267.3278998606495','1267.327899860649495','test','test','2.00'),('2018-09-24 19:59:59','2018-09-24 23:59:59','BATBTC','4h','0.000025410000000','0.000025030000000','0.032804078616837','0.032313502077113','1290.9908940117014','1290.990894011701357','test','test','1.49'),('2018-09-25 23:59:59','2018-09-26 03:59:59','BATBTC','4h','0.000025750000000','0.000025235000000','0.032695061608010','0.032041160375850','1269.7111304081466','1269.711130408146573','test','test','2.00'),('2018-09-26 15:59:59','2018-09-26 23:59:59','BATBTC','4h','0.000025640000000','0.000025350000000','0.032549750223085','0.032181597821966','1269.4910383418617','1269.491038341861668','test','test','1.13'),('2018-09-27 15:59:59','2018-09-28 11:59:59','BATBTC','4h','0.000025510000000','0.000025260000000','0.032467938578392','0.032149750234817','1272.7533742999692','1272.753374299969209','test','test','0.98'),('2018-09-28 23:59:59','2018-09-29 03:59:59','BATBTC','4h','0.000025490000000','0.000024980200000','0.032397230057598','0.031749285456446','1270.9780328598576','1270.978032859857649','test','test','1.99'),('2018-09-29 11:59:59','2018-10-03 03:59:59','BATBTC','4h','0.000025400000000','0.000025560000000','0.032253242368453','0.032456412399120','1269.8126916713732','1269.812691671373159','test','test','0.0'),('2018-10-04 11:59:59','2018-10-06 19:59:59','BATBTC','4h','0.000026180000000','0.000026090000000','0.032298391264157','0.032187357833532','1233.7047847271451','1233.704784727145125','test','test','0.38'),('2018-10-07 19:59:59','2018-10-10 07:59:59','BATBTC','4h','0.000026660000000','0.000026630000000','0.032273717168462','0.032237400157395','1210.5670355762272','1210.567035576227227','test','test','0.15'),('2018-10-10 11:59:59','2018-10-11 03:59:59','BATBTC','4h','0.000026920000000','0.000026381600000','0.032265646721558','0.031620333787127','1198.575286833523','1198.575286833523023','test','test','2.00'),('2018-10-12 03:59:59','2018-10-15 03:59:59','BATBTC','4h','0.000027190000000','0.000027570000000','0.032122243847240','0.032571175537639','1181.399185260774','1181.399185260773947','test','test','0.0'),('2018-10-15 15:59:59','2018-10-15 19:59:59','BATBTC','4h','0.000027350000000','0.000027150000000','0.032222006445107','0.031986379341304','1178.1355190167048','1178.135519016704848','test','test','0.73'),('2018-10-16 23:59:59','2018-10-27 23:59:59','BATBTC','4h','0.000028570000000','0.000037700000000','0.032169644866484','0.042449968899771','1125.993870020441','1125.993870020440909','test','test','0.0'),('2018-10-28 23:59:59','2018-10-29 03:59:59','BATBTC','4h','0.000038760000000','0.000037984800000','0.034454161318326','0.033765078091959','888.9102507307933','888.910250730793337','test','test','1.99'),('2018-10-30 07:59:59','2018-11-01 07:59:59','BATBTC','4h','0.000039140000000','0.000038560000000','0.034301031712466','0.033792738447437','876.367698325657','876.367698325656988','test','test','1.48'),('2018-11-01 15:59:59','2018-11-09 07:59:59','BATBTC','4h','0.000039530000000','0.000045540000000','0.034188077653571','0.039385910861210','864.8640944490484','864.864094449048366','test','test','0.0'),('2018-11-22 03:59:59','2018-11-22 11:59:59','BATBTC','4h','0.000039440000000','0.000040090000000','0.035343151699713','0.035925632648111','896.1245359967769','896.124535996776899','test','test','0.0'),('2018-11-28 03:59:59','2018-11-28 07:59:59','BATBTC','4h','0.000038660000000','0.000037886800000','0.035472591910468','0.034763140072259','917.5528171357475','917.552817135747546','test','test','2.00'),('2018-11-28 15:59:59','2018-11-28 23:59:59','BATBTC','4h','0.000038270000000','0.000039990000000','0.035314935946422','0.036902124078845','922.783797920605','922.783797920605025','test','test','0.0'),('2018-11-29 15:59:59','2018-12-05 03:59:59','BATBTC','4h','0.000040020000000','0.000040260000000','0.035667644420293','0.035881543337356','891.2454877634516','891.245487763451592','test','test','1.19'),('2018-12-11 03:59:59','2018-12-11 11:59:59','BATBTC','4h','0.000040180000000','0.000039920000000','0.035715177512974','0.035484068848131','888.8794801636137','888.879480163613721','test','test','0.64'),('2018-12-12 03:59:59','2018-12-13 03:59:59','BATBTC','4h','0.000040980000000','0.000040160400000','0.035663820031898','0.034950543631260','870.2737928720784','870.273792872078388','test','test','2.00'),('2018-12-14 19:59:59','2018-12-15 07:59:59','BATBTC','4h','0.000040430000000','0.000039950000000','0.035505314165089','0.035083781867309','878.1922870415367','878.192287041536702','test','test','1.18'),('2019-01-04 11:59:59','2019-01-05 03:59:59','BATBTC','4h','0.000035840000000','0.000035820000000','0.035411640321138','0.035391879361137','988.0480000317582','988.048000031758193','test','test','0.05'),('2019-01-05 19:59:59','2019-01-05 23:59:59','BATBTC','4h','0.000036380000000','0.000035652400000','0.035407248996694','0.034699104016760','973.2613797881679','973.261379788167915','test','test','2.00'),('2019-01-09 11:59:59','2019-01-09 15:59:59','BATBTC','4h','0.000035690000000','0.000035120000000','0.035249883445597','0.034686912485552','987.6683509553687','987.668350955368737','test','test','1.59'),('2019-01-11 23:59:59','2019-01-12 03:59:59','BATBTC','4h','0.000035280000000','0.000034730000000','0.035124778787809','0.034577198619632','995.6003057769084','995.600305776908385','test','test','1.55'),('2019-01-12 11:59:59','2019-01-13 03:59:59','BATBTC','4h','0.000035370000000','0.000035080000000','0.035003094305992','0.034716102579989','989.6266413907894','989.626641390789359','test','test','0.81'),('2019-01-18 03:59:59','2019-01-18 19:59:59','BATBTC','4h','0.000035280000000','0.000034590000000','0.034939318366880','0.034255981358004','990.3434911247292','990.343491124729212','test','test','1.95'),('2019-01-25 03:59:59','2019-01-25 07:59:59','BATBTC','4h','0.000034710000000','0.000034590000000','0.034787465698241','0.034667197882517','1002.2317977021415','1002.231797702141535','test','test','0.34'),('2019-01-25 11:59:59','2019-01-27 15:59:59','BATBTC','4h','0.000034790000000','0.000034690000000','0.034760739516969','0.034660823622985','999.1589398381526','999.158939838152605','test','test','0.28'),('2019-02-06 23:59:59','2019-02-08 03:59:59','BATBTC','4h','0.000034240000000','0.000033555200000','0.034738535984973','0.034043765265274','1014.5600462900959','1014.560046290095897','test','test','1.99'),('2019-02-10 11:59:59','2019-02-11 03:59:59','BATBTC','4h','0.000034590000000','0.000033898200000','0.034584142491706','0.033892459641872','999.8306589102758','999.830658910275815','test','test','1.99'),('2019-02-14 03:59:59','2019-02-14 07:59:59','BATBTC','4h','0.000034840000000','0.000034143200000','0.034430435191743','0.033741826487908','988.2444084886145','988.244408488614454','test','test','2.00'),('2019-02-14 11:59:59','2019-02-21 07:59:59','BATBTC','4h','0.000035360000000','0.000035460000000','0.034277411035336','0.034374349414961','969.3837962481772','969.383796248177191','test','test','1.61'),('2019-02-25 23:59:59','2019-02-26 03:59:59','BATBTC','4h','0.000039000000000','0.000038220000000','0.034298952897474','0.033612973839525','879.4603307044729','879.460330704472881','test','test','2.00'),('2019-02-26 07:59:59','2019-02-26 11:59:59','BATBTC','4h','0.000047510000000','0.000046559800000','0.034146513106819','0.033463582844683','718.7226501119576','718.722650111957591','test','test','2.00'),('2019-02-26 23:59:59','2019-02-27 03:59:59','BATBTC','4h','0.000042660000000','0.000041806800000','0.033994750826344','0.033314855809817','796.8764844431419','796.876484443141862','test','test','2.00'),('2019-03-02 07:59:59','2019-03-03 03:59:59','BATBTC','4h','0.000047080000000','0.000046138400000','0.033843663044894','0.033166789783996','718.8543552441374','718.854355244137423','test','test','1.99'),('2019-03-04 07:59:59','2019-03-17 07:59:59','BATBTC','4h','0.000043890000000','0.000048350000000','0.033693246764694','0.037117076351628','767.6747952767018','767.674795276701843','test','test','0.27'),('2019-03-18 11:59:59','2019-03-18 15:59:59','BATBTC','4h','0.000048730000000','0.000048560000000','0.034454097784013','0.034333900849408','707.0407917917731','707.040791791773131','test','test','0.34'),('2019-03-21 07:59:59','2019-03-21 15:59:59','BATBTC','4h','0.000048510000000','0.000047990000000','0.034427387354101','0.034058345065416','709.6967090105315','709.696709010531549','test','test','1.07'),('2019-03-21 19:59:59','2019-03-22 03:59:59','BATBTC','4h','0.000048720000000','0.000048520000000','0.034345377956615','0.034204387078304','704.954391556144','704.954391556143946','test','test','0.41'),('2019-03-22 07:59:59','2019-04-02 07:59:59','BATBTC','4h','0.000048740000000','0.000066050000000','0.034314046650324','0.046500672573941','704.0222948363562','704.022294836356195','test','test','0.0'),('2019-04-02 23:59:59','2019-04-03 03:59:59','BATBTC','4h','0.000065660000000','0.000064346800000','0.037022185744461','0.036281742029572','563.8468739637696','563.846873963769553','test','test','2.00'),('2019-04-05 19:59:59','2019-04-05 23:59:59','BATBTC','4h','0.000062730000000','0.000061475400000','0.036857642696708','0.036120489842774','587.560062118731','587.560062118731025','test','test','1.99'),('2019-04-13 07:59:59','2019-04-15 19:59:59','BATBTC','4h','0.000058460000000','0.000058220000000','0.036693830951389','0.036543189154804','627.6741524356711','627.674152435671090','test','test','0.41'),('2019-04-16 11:59:59','2019-04-26 03:59:59','BATBTC','4h','0.000061730000000','0.000072750000000','0.036660354996593','0.043204938052845','593.8823100047412','593.882310004741157','test','test','0.51'),('2019-04-28 03:59:59','2019-04-29 03:59:59','BATBTC','4h','0.000077790000000','0.000076234200000','0.038114706786871','0.037352412651134','489.969234951419','489.969234951419025','test','test','1.99'),('2019-04-30 15:59:59','2019-04-30 19:59:59','BATBTC','4h','0.000073140000000','0.000073640000000','0.037945308090040','0.038204709977448','518.8037748159755','518.803774815975544','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:46:53
