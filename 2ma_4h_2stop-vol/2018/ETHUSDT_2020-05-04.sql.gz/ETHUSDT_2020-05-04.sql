-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-01 03:59:59','2018-02-01 11:59:59','ETHUSDT','4h','1140.000000000000000','1117.200000000000045','222.222222222222200','217.777777777777771','0.1949317738791423','0.194931773879142','test','test','1.99'),('2018-02-14 15:59:59','2018-02-18 11:59:59','ETHUSDT','4h','903.059999999999945','929.179999999999950','221.234567901234556','227.633530222210197','0.24498324352892895','0.244983243528929','test','test','0.09'),('2018-02-27 11:59:59','2018-02-27 15:59:59','ETHUSDT','4h','885.169999999999959','873.070000000000050','222.656559528118038','219.612913256452458','0.2515410141872387','0.251541014187239','test','test','1.36'),('2018-03-05 07:59:59','2018-03-05 11:59:59','ETHUSDT','4h','867.799999999999955','869.139999999999986','221.980193689970150','222.322960986057467','0.255796489617389','0.255796489617389','test','test','0.0'),('2018-04-09 07:59:59','2018-04-09 11:59:59','ETHUSDT','4h','418.810000000000002','410.433800000000019','222.056364200211760','217.615236916207550','0.5302078847215008','0.530207884721501','test','test','1.99'),('2018-04-10 23:59:59','2018-05-01 03:59:59','ETHUSDT','4h','416.069999999999993','641.860000000000014','221.069447025988637','341.037890903216010','0.5313275338909045','0.531327533890904','test','test','0.73'),('2018-05-03 03:59:59','2018-05-07 11:59:59','ETHUSDT','4h','717.990000000000009','733.000000000000000','247.729101220928015','252.908022667363355','0.3450314088231424','0.345031408823142','test','test','0.0'),('2018-05-07 19:59:59','2018-05-08 11:59:59','ETHUSDT','4h','758.000000000000000','742.840000000000032','248.879972653469196','243.902373200399836','0.328337694793495','0.328337694793495','test','test','1.99'),('2018-05-13 15:59:59','2018-05-14 03:59:59','ETHUSDT','4h','727.009999999999991','712.469799999999964','247.773839441676017','242.818362652842495','0.3408121476206325','0.340812147620632','test','test','2.00'),('2018-05-14 15:59:59','2018-05-15 15:59:59','ETHUSDT','4h','733.250000000000000','718.585000000000036','246.672622377490796','241.739169929940999','0.3364099861950096','0.336409986195010','test','test','1.99'),('2018-05-19 15:59:59','2018-05-19 19:59:59','ETHUSDT','4h','706.919999999999959','703.659999999999968','245.576299611368569','244.443811159021692','0.3473890958119286','0.347389095811929','test','test','0.46'),('2018-05-20 11:59:59','2018-05-21 03:59:59','ETHUSDT','4h','712.500000000000000','712.720000000000027','245.324635510847088','245.400384871987313','0.3443152779099608','0.344315277909961','test','test','0.0'),('2018-06-03 11:59:59','2018-06-04 07:59:59','ETHUSDT','4h','619.929999999999950','607.531399999999962','245.341468702211586','240.434639328167350','0.3957567285051725','0.395756728505173','test','test','1.99'),('2018-06-05 19:59:59','2018-06-06 19:59:59','ETHUSDT','4h','607.240000000000009','598.259999999999991','244.251062174646194','240.639023214221453','0.4022315100695708','0.402231510069571','test','test','1.47'),('2018-06-19 11:59:59','2018-06-20 03:59:59','ETHUSDT','4h','534.000000000000000','523.319999999999936','243.448386850107340','238.579419113105160','0.4558958555245456','0.455895855524546','test','test','2.00'),('2018-06-20 15:59:59','2018-06-21 15:59:59','ETHUSDT','4h','535.289999999999964','528.610000000000014','242.366394019662465','239.341851225940673','0.4527758673236236','0.452775867323624','test','test','1.24'),('2018-07-02 15:59:59','2018-07-03 23:59:59','ETHUSDT','4h','474.430000000000007','464.941399999999987','241.694273398835350','236.860387930858650','0.5094413789154045','0.509441378915405','test','test','2.00'),('2018-07-04 15:59:59','2018-07-04 23:59:59','ETHUSDT','4h','473.449999999999989','467.379999999999995','240.620076628173905','237.535138693580990','0.508227007346444','0.508227007346444','test','test','1.28'),('2018-07-05 03:59:59','2018-07-05 19:59:59','ETHUSDT','4h','470.569999999999993','462.750000000000000','239.934534864931010','235.947268225230744','0.5098806444629513','0.509880644462951','test','test','1.66'),('2018-07-07 23:59:59','2018-07-09 23:59:59','ETHUSDT','4h','485.569999999999993','475.858599999999967','239.048475611664315','234.267506099431017','0.49230486976473903','0.492304869764739','test','test','2.00'),('2018-07-15 15:59:59','2018-07-15 19:59:59','ETHUSDT','4h','452.959999999999980','450.189999999999998','237.986037942279125','236.530674720140070','0.5254018852487617','0.525401885248762','test','test','0.61'),('2018-07-16 07:59:59','2018-07-19 19:59:59','ETHUSDT','4h','452.819999999999993','467.850000000000023','237.662623892914894','245.551120949384398','0.5248501035575172','0.524850103557517','test','test','0.0'),('2018-07-23 15:59:59','2018-07-23 19:59:59','ETHUSDT','4h','463.490000000000009','454.220199999999977','239.415623238796996','234.627310774021055','0.5165497060104792','0.516549706010479','test','test','2.00'),('2018-07-24 07:59:59','2018-07-25 15:59:59','ETHUSDT','4h','472.329999999999984','467.800000000000011','238.351553802180092','236.065583106429528','0.5046292926601742','0.504629292660174','test','test','0.95'),('2018-07-25 19:59:59','2018-07-26 23:59:59','ETHUSDT','4h','474.230000000000018','464.745400000000018','237.843560314235532','233.086689107950804','0.5015363016136379','0.501536301613638','test','test','2.0'),('2018-07-27 19:59:59','2018-07-27 23:59:59','ETHUSDT','4h','467.360000000000014','470.089999999999975','236.786477823950037','238.169623759544379','0.5066468628550796','0.506646862855080','test','test','0.0'),('2018-08-28 15:59:59','2018-08-28 19:59:59','ETHUSDT','4h','288.589999999999975','293.139999999999986','237.093843587415449','240.831939115059299','0.8215594566250233','0.821559456625023','test','test','0.0'),('2018-08-28 23:59:59','2018-08-29 15:59:59','ETHUSDT','4h','295.439999999999998','289.531200000000013','237.924531482447463','233.166040852798545','0.8053226762877317','0.805322676287732','test','test','1.99'),('2018-09-01 15:59:59','2018-09-03 07:59:59','ETHUSDT','4h','295.540000000000020','289.870000000000005','236.867089120303234','232.322741839691048','0.8014721835294824','0.801472183529482','test','test','1.91'),('2018-09-03 15:59:59','2018-09-03 19:59:59','ETHUSDT','4h','289.689999999999998','292.540000000000020','235.857234169056056','238.177621884827460','0.8141711283408335','0.814171128340833','test','test','0.0'),('2018-09-04 11:59:59','2018-09-04 15:59:59','ETHUSDT','4h','288.769999999999982','289.329999999999984','236.372875883671924','236.831264256753798','0.8185506662176539','0.818550666217654','test','test','0.0'),('2018-09-15 15:59:59','2018-09-16 03:59:59','ETHUSDT','4h','224.039999999999992','219.559199999999976','236.474739966579023','231.745245167247447','1.0555023208649306','1.055502320864931','test','test','2.00'),('2018-09-20 23:59:59','2018-09-24 23:59:59','ETHUSDT','4h','224.000000000000000','228.060000000000002','235.423741122283104','239.690796430124465','1.0509988442959066','1.050998844295907','test','test','0.56'),('2018-09-27 19:59:59','2018-09-28 11:59:59','ETHUSDT','4h','228.599999999999994','224.027999999999992','236.371975635136749','231.644536122434005','1.0339981436357688','1.033998143635769','test','test','2.00'),('2018-09-29 11:59:59','2018-10-01 15:59:59','ETHUSDT','4h','232.389999999999986','227.742199999999968','235.321433521202806','230.615004850778718','1.0126142842686985','1.012614284268698','test','test','2.00'),('2018-10-01 19:59:59','2018-10-02 15:59:59','ETHUSDT','4h','229.860000000000014','227.750000000000000','234.275560483330793','232.125027843376756','1.0192097819687236','1.019209781968724','test','test','0.91'),('2018-10-05 23:59:59','2018-10-06 11:59:59','ETHUSDT','4h','228.370000000000005','225.270000000000010','233.797664341118775','230.623986715084413','1.023766976140118','1.023766976140118','test','test','1.35'),('2018-10-07 23:59:59','2018-10-08 07:59:59','ETHUSDT','4h','226.139999999999986','224.979999999999990','233.092402646444498','231.896739839909287','1.0307437987372623','1.030743798737262','test','test','0.51'),('2018-10-08 11:59:59','2018-10-10 03:59:59','ETHUSDT','4h','226.330000000000013','226.500000000000000','232.826699800547743','233.001579573295913','1.0287045455774653','1.028704545577465','test','test','0.0'),('2018-10-15 11:59:59','2018-10-15 15:59:59','ETHUSDT','4h','221.750000000000000','217.314999999999998','232.865561972269575','228.208250732824183','1.0501265477892652','1.050126547789265','test','test','2.00'),('2018-11-04 15:59:59','2018-11-09 23:59:59','ETHUSDT','4h','205.840000000000003','210.770000000000010','231.830603919059484','237.383095550039684','1.1262660509087616','1.126266050908762','test','test','0.0'),('2018-11-10 15:59:59','2018-11-10 23:59:59','ETHUSDT','4h','213.969999999999999','213.250000000000000','233.064490948166195','232.280238793739500','1.089239103370408','1.089239103370408','test','test','0.33'),('2018-11-11 19:59:59','2018-11-13 03:59:59','ETHUSDT','4h','211.379999999999995','211.699999999999989','232.890212691626886','233.242776170013286','1.1017608699575498','1.101760869957550','test','test','0.0'),('2018-12-17 19:59:59','2018-12-18 11:59:59','ETHUSDT','4h','95.409999999999997','93.501799999999989','232.968560131268333','228.309188928642925','2.441762500065699','2.441762500065699','test','test','2.00'),('2018-12-18 15:59:59','2018-12-27 19:59:59','ETHUSDT','4h','93.819999999999993','114.099999999999994','231.933144308462687','282.067488441649857','2.4721076988751087','2.472107698875109','test','test','0.06'),('2018-12-28 15:59:59','2019-01-10 07:59:59','ETHUSDT','4h','126.620000000000005','135.449999999999989','243.074109671393188','260.025178921104157','1.9197133918132459','1.919713391813246','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:20:52
