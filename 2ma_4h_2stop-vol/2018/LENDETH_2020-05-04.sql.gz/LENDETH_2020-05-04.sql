-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 07:59:59','2018-05-30 15:59:59','LENDETH','4h','0.000081700000000','0.000080066000000','1.297777777777778','1.271822222222222','15884.672922616619','15884.672922616618962','test','test','2.00'),('2018-06-01 19:59:59','2018-06-02 03:59:59','LENDETH','4h','0.000080600000000','0.000080630000000','1.292009876543210','1.292490773519591','16029.89921269491','16029.899212694910602','test','test','0.23'),('2018-06-02 15:59:59','2018-06-03 11:59:59','LENDETH','4h','0.000080830000000','0.000079600000000','1.292116742537961','1.272454443969092','15985.608592576533','15985.608592576532828','test','test','1.52'),('2018-06-09 07:59:59','2018-06-09 11:59:59','LENDETH','4h','0.000077580000000','0.000077610000000','1.287747342855990','1.288245311666066','16598.960335859632','16598.960335859632323','test','test','0.0'),('2018-06-09 19:59:59','2018-06-10 03:59:59','LENDETH','4h','0.000077810000000','0.000076253800000','1.287858002591563','1.262100842539732','16551.317344705854','16551.317344705854339','test','test','1.99'),('2018-06-28 11:59:59','2018-06-28 19:59:59','LENDETH','4h','0.000059100000000','0.000057918000000','1.282134189246711','1.256491505461777','21694.317922956197','21694.317922956197435','test','test','2.00'),('2018-06-30 19:59:59','2018-06-30 23:59:59','LENDETH','4h','0.000061610000000','0.000060377800000','1.276435815072282','1.250907098770836','20717.997323036547','20717.997323036546732','test','test','1.99'),('2018-07-01 15:59:59','2018-07-07 11:59:59','LENDETH','4h','0.000064410000000','0.000064910000000','1.270762767005294','1.280627405780370','19729.277550152052','19729.277550152051845','test','test','1.73'),('2018-07-07 19:59:59','2018-07-07 23:59:59','LENDETH','4h','0.000065610000000','0.000065960000000','1.272954908955310','1.279745553950499','19401.842843397502','19401.842843397502293','test','test','0.0'),('2018-07-17 19:59:59','2018-07-20 03:59:59','LENDETH','4h','0.000061040000000','0.000061200000000','1.274463941176463','1.277804606815196','20879.160242078364','20879.160242078363808','test','test','0.0'),('2018-07-30 15:59:59','2018-07-31 11:59:59','LENDETH','4h','0.000059700000000','0.000058506000000','1.275206311318404','1.249702185092036','21360.239720576283','21360.239720576282707','test','test','2.00'),('2018-08-17 11:59:59','2018-08-17 15:59:59','LENDETH','4h','0.000048690000000','0.000047990000000','1.269538727712545','1.251286989996406','26073.911023054927','26073.911023054926773','test','test','1.43'),('2018-08-26 11:59:59','2018-08-30 11:59:59','LENDETH','4h','0.000047950000000','0.000048010000000','1.265482785997847','1.267066288962599','26391.716079204318','26391.716079204317793','test','test','0.66'),('2018-08-31 07:59:59','2018-09-02 23:59:59','LENDETH','4h','0.000051430000000','0.000050401400000','1.265834675545570','1.240517982034659','24612.76833648784','24612.768336487839406','test','test','1.99'),('2018-09-03 15:59:59','2018-09-12 11:59:59','LENDETH','4h','0.000050320000000','0.000057810000000','1.260208743654256','1.447787509353190','25043.893951793645','25043.893951793645101','test','test','0.0'),('2018-09-16 15:59:59','2018-09-21 19:59:59','LENDETH','4h','0.000056340000000','0.000058450000000','1.301892913809575','1.350650351653704','23107.790447454292','23107.790447454292007','test','test','0.0'),('2018-09-25 03:59:59','2018-09-25 07:59:59','LENDETH','4h','0.000059960000000','0.000059360000000','1.312727899997159','1.299591863639616','21893.39392923881','21893.393929238809505','test','test','1.00'),('2018-09-25 11:59:59','2018-09-25 15:59:59','LENDETH','4h','0.000064640000000','0.000063347200000','1.309808780806594','1.283612605190462','20263.130891191122','20263.130891191121918','test','test','2.00'),('2018-09-26 11:59:59','2018-09-26 15:59:59','LENDETH','4h','0.000062390000000','0.000061142200000','1.303987408447454','1.277907660278505','20900.58356222878','20900.583562228781375','test','test','1.99'),('2018-09-27 15:59:59','2018-10-01 03:59:59','LENDETH','4h','0.000062950000000','0.000063730000000','1.298191908854354','1.314277527423161','20622.58790872683','20622.587908726829482','test','test','1.84'),('2018-10-02 03:59:59','2018-10-02 07:59:59','LENDETH','4h','0.000062840000000','0.000062060000000','1.301766490758533','1.285608345265349','20715.571145107144','20715.571145107143820','test','test','1.24'),('2018-10-02 15:59:59','2018-10-11 23:59:59','LENDETH','4h','0.000064770000000','0.000073780000000','1.298175791760048','1.478761925521944','20042.856133395824','20042.856133395824145','test','test','1.25'),('2018-10-12 07:59:59','2018-10-13 11:59:59','LENDETH','4h','0.000074550000000','0.000073610000000','1.338306043707136','1.321431359856234','17951.79133074629','17951.791330746291351','test','test','1.26'),('2018-10-13 15:59:59','2018-10-15 07:59:59','LENDETH','4h','0.000075280000000','0.000073774400000','1.334556113962491','1.307864991683241','17727.89736932108','17727.897369321079168','test','test','1.99'),('2018-10-15 15:59:59','2018-10-15 19:59:59','LENDETH','4h','0.000075400000000','0.000073892000000','1.328624753455991','1.302052258386871','17621.017950344707','17621.017950344707060','test','test','1.99'),('2018-10-17 19:59:59','2018-10-26 11:59:59','LENDETH','4h','0.000075080000000','0.000090340000000','1.322719754551742','1.591562368489669','17617.471424503754','17617.471424503753951','test','test','0.0'),('2018-10-27 07:59:59','2018-11-04 07:59:59','LENDETH','4h','0.000099100000000','0.000102640000000','1.382462557649059','1.431846184834505','13950.17717102986','13950.177171029859892','test','test','0.0'),('2018-11-28 19:59:59','2018-11-30 11:59:59','LENDETH','4h','0.000076150000000','0.000074627000000','1.393436697023603','1.365567963083131','18298.57776787397','18298.577767873968696','test','test','2.00'),('2018-12-01 15:59:59','2018-12-02 11:59:59','LENDETH','4h','0.000081950000000','0.000080311000000','1.387243645036831','1.359498772136094','16927.92733418952','16927.927334189520479','test','test','2.00'),('2018-12-02 15:59:59','2018-12-05 23:59:59','LENDETH','4h','0.000081830000000','0.000080193400000','1.381078117725556','1.353456555371045','16877.405813583726','16877.405813583725831','test','test','1.99'),('2018-12-06 07:59:59','2018-12-06 11:59:59','LENDETH','4h','0.000079820000000','0.000078260000000','1.374939992757887','1.348068201368482','17225.507300900612','17225.507300900611881','test','test','1.95'),('2018-12-12 19:59:59','2018-12-13 11:59:59','LENDETH','4h','0.000078200000000','0.000076640000000','1.368968483560241','1.341659137852389','17505.99083836626','17505.990838366258686','test','test','1.99'),('2018-12-13 19:59:59','2018-12-13 23:59:59','LENDETH','4h','0.000078380000000','0.000077050000000','1.362899740069608','1.339773219856638','17388.36106238336','17388.361062383359240','test','test','1.69'),('2018-12-14 11:59:59','2018-12-14 15:59:59','LENDETH','4h','0.000076590000000','0.000077700000000','1.357760513355615','1.377438201954972','17727.64738680787','17727.647386807868315','test','test','0.0'),('2018-12-14 23:59:59','2018-12-19 15:59:59','LENDETH','4h','0.000078520000000','0.000080500000000','1.362133333044360','1.396481575523064','17347.597211466637','17347.597211466636509','test','test','0.02'),('2018-12-20 11:59:59','2018-12-20 19:59:59','LENDETH','4h','0.000081650000000','0.000080210000000','1.369766275817406','1.345608732190008','16776.07196347098','16776.071963470978517','test','test','1.76'),('2019-01-11 11:59:59','2019-01-11 15:59:59','LENDETH','4h','0.000056430000000','0.000056130000000','1.364397932789095','1.357144355262305','24178.591755964826','24178.591755964826007','test','test','0.53'),('2019-01-12 19:59:59','2019-01-27 19:59:59','LENDETH','4h','0.000057470000000','0.000071400000000','1.362786026672031','1.693108096474387','23712.998550061435','23712.998550061434798','test','test','0.0'),('2019-01-28 15:59:59','2019-01-28 19:59:59','LENDETH','4h','0.000070110000000','0.000069690000000','1.436190931072554','1.427587305469210','20484.82286510561','20484.822865105608798','test','test','0.59'),('2019-01-29 11:59:59','2019-01-30 15:59:59','LENDETH','4h','0.000070100000000','0.000070520000000','1.434279014271811','1.442872412074866','20460.47095965494','20460.470959654940089','test','test','0.0'),('2019-02-01 19:59:59','2019-02-02 07:59:59','LENDETH','4h','0.000072100000000','0.000070658000000','1.436188658228046','1.407464885063485','19919.398865853615','19919.398865853614552','test','test','2.00'),('2019-02-02 19:59:59','2019-02-02 23:59:59','LENDETH','4h','0.000073720000000','0.000072245600000','1.429805597524810','1.401209485574314','19395.084068432036','19395.084068432035565','test','test','2.00'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LENDETH','4h','0.000057260000000','0.000056114800000','1.423450905980255','1.394981887860650','24859.429025152902','24859.429025152901886','test','test','2.00'),('2019-03-01 19:59:59','2019-03-06 15:59:59','LENDETH','4h','0.000057900000000','0.000061610000000','1.417124457509232','1.507928114458442','24475.37923159295','24475.379231592949509','test','test','1.64'),('2019-03-08 07:59:59','2019-03-16 23:59:59','LENDETH','4h','0.000063930000000','0.000066770000000','1.437303047942390','1.501153206806090','22482.450304119968','22482.450304119967768','test','test','0.67'),('2019-03-26 19:59:59','2019-04-02 07:59:59','LENDETH','4h','0.000065560000000','0.000071990000000','1.451491972134323','1.593851541701493','22139.90195445886','22139.901954458859109','test','test','0.0'),('2019-04-04 15:59:59','2019-04-05 07:59:59','LENDETH','4h','0.000070120000000','0.000068740000000','1.483127432038138','1.453938671966651','21151.275414120628','21151.275414120627829','test','test','1.96'),('2019-04-05 15:59:59','2019-04-06 11:59:59','LENDETH','4h','0.000072970000000','0.000071510600000','1.476641040911141','1.447108220092918','20236.27574223847','20236.275742238471139','test','test','2.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','LENDETH','4h','0.000070280000000','0.000068874400000','1.470078191840425','1.440676628003617','20917.447237342418','20917.447237342417793','test','test','2.00'),('2019-04-14 15:59:59','2019-04-15 11:59:59','LENDETH','4h','0.000066910000000','0.000066740000000','1.463544510987801','1.459826044886054','21873.3300102795','21873.330010279500129','test','test','0.40'),('2019-04-18 23:59:59','2019-04-19 03:59:59','LENDETH','4h','0.000066800000000','0.000065464000000','1.462718185187413','1.433463821483665','21896.97882017085','21896.978820170850668','test','test','2.00'),('2019-04-19 07:59:59','2019-04-19 15:59:59','LENDETH','4h','0.000067210000000','0.000065865800000','1.456217215475469','1.427092871165959','21666.674832249202','21666.674832249202154','test','test','2.00'),('2019-05-20 15:59:59','2019-05-20 19:59:59','LENDETH','4h','0.000039490000000','0.000038700200000','1.449745138962244','1.420750236182999','36711.70268326777','36711.702683267772954','test','test','2.00'),('2019-05-22 19:59:59','2019-05-22 23:59:59','LENDETH','4h','0.000041190000000','0.000040366200000','1.443301827233523','1.414435790688852','35040.10262766505','35040.102627665051841','test','test','2.00'),('2019-05-26 11:59:59','2019-05-26 15:59:59','LENDETH','4h','0.000038600000000','0.000038980000000','1.436887152445818','1.451032673635699','37225.05576284503','37225.055762845033314','test','test','0.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:28:20
