-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-10 07:59:59','2018-04-12 11:59:59','OAXBTC','4h','0.000071170000000','0.000070990000000','0.033333333333333','0.033249028148564','468.36213760479603','468.362137604796033','test','test','0.25'),('2018-04-12 15:59:59','2018-04-14 15:59:59','OAXBTC','4h','0.000072730000000','0.000072540000000','0.033314598847829','0.033227567722006','458.0585569617641','458.058556961764111','test','test','1.62'),('2018-04-15 15:59:59','2018-04-16 03:59:59','OAXBTC','4h','0.000077400000000','0.000075852000000','0.033295258597646','0.032629353425693','430.1712997111916','430.171299711191580','test','test','2.00'),('2018-04-17 07:59:59','2018-04-21 11:59:59','OAXBTC','4h','0.000075770000000','0.000074254600000','0.033147279670546','0.032484334077135','437.47234618642676','437.472346186426762','test','test','2.00'),('2018-04-21 23:59:59','2018-04-22 03:59:59','OAXBTC','4h','0.000085560000000','0.000083848800000','0.032999958427565','0.032339959259014','385.6937637630357','385.693763763035690','test','test','1.99'),('2018-04-23 19:59:59','2018-04-25 03:59:59','OAXBTC','4h','0.000081660000000','0.000080026800000','0.032853291945665','0.032196226106752','402.3180497877187','402.318049787718678','test','test','2.00'),('2018-04-26 15:59:59','2018-05-03 19:59:59','OAXBTC','4h','0.000082050000000','0.000094540000000','0.032707277314796','0.037686118188188','398.62617080798964','398.626170807989638','test','test','0.30'),('2018-05-06 19:59:59','2018-05-06 23:59:59','OAXBTC','4h','0.000093470000000','0.000091600600000','0.033813686397772','0.033137412669817','361.7597774448653','361.759777444865279','test','test','2.00'),('2018-05-13 19:59:59','2018-05-13 23:59:59','OAXBTC','4h','0.000086900000000','0.000085162000000','0.033663403347115','0.032990135280173','387.3809361002864','387.380936100286419','test','test','2.00'),('2018-05-15 11:59:59','2018-05-15 19:59:59','OAXBTC','4h','0.000086960000000','0.000085220800000','0.033513788221128','0.032843512456705','385.3931488170168','385.393148817016822','test','test','2.00'),('2018-05-17 15:59:59','2018-05-17 19:59:59','OAXBTC','4h','0.000082440000000','0.000080791200000','0.033364838051256','0.032697541290231','404.7166187682677','404.716618768267722','test','test','1.99'),('2018-05-21 03:59:59','2018-05-21 15:59:59','OAXBTC','4h','0.000080890000000','0.000081130000000','0.033216549882139','0.033315103126937','410.6385199918325','410.638519991832482','test','test','0.27'),('2018-05-30 11:59:59','2018-05-30 15:59:59','OAXBTC','4h','0.000074200000000','0.000072716000000','0.033238450603206','0.032573681591142','447.9575552992662','447.957555299266176','test','test','2.00'),('2018-05-31 07:59:59','2018-06-04 11:59:59','OAXBTC','4h','0.000074400000000','0.000074100000000','0.033090724156080','0.032957293816741','444.76779779677713','444.767797796777131','test','test','0.40'),('2018-06-07 03:59:59','2018-06-07 07:59:59','OAXBTC','4h','0.000075010000000','0.000074110000000','0.033061072969560','0.032664392984590','440.75553885562516','440.755538855625161','test','test','1.19'),('2018-06-07 11:59:59','2018-06-07 15:59:59','OAXBTC','4h','0.000076450000000','0.000075040000000','0.032972921861789','0.032364788181931','431.30048216859814','431.300482168598137','test','test','1.84'),('2018-07-01 23:59:59','2018-07-02 07:59:59','OAXBTC','4h','0.000053950000000','0.000052871000000','0.032837781044043','0.032181025423162','608.67064029737','608.670640297370028','test','test','2.00'),('2018-07-02 15:59:59','2018-07-03 23:59:59','OAXBTC','4h','0.000053700000000','0.000053470000000','0.032691835350514','0.032551814454227','608.7865055961638','608.786505596163806','test','test','0.42'),('2018-07-04 15:59:59','2018-07-06 07:59:59','OAXBTC','4h','0.000056930000000','0.000055791400000','0.032660719595784','0.032007505203868','573.699624025708','573.699624025707976','test','test','2.00'),('2018-07-06 15:59:59','2018-07-06 23:59:59','OAXBTC','4h','0.000058370000000','0.000057202600000','0.032515560842024','0.031865249625184','557.0594627723907','557.059462772390702','test','test','1.99'),('2018-07-09 15:59:59','2018-07-09 19:59:59','OAXBTC','4h','0.000057790000000','0.000056634200000','0.032371047238282','0.031723626293516','560.1496320865585','560.149632086558540','test','test','2.0'),('2018-07-16 15:59:59','2018-07-16 19:59:59','OAXBTC','4h','0.000053930000000','0.000053730000000','0.032227175917223','0.032107661079777','597.5741872283164','597.574187228316418','test','test','0.37'),('2018-07-18 11:59:59','2018-07-18 15:59:59','OAXBTC','4h','0.000052550000000','0.000052670000000','0.032200617064457','0.032274148445004','612.7615045567522','612.761504556752243','test','test','0.0'),('2018-08-24 07:59:59','2018-08-24 11:59:59','OAXBTC','4h','0.000025720000000','0.000025210000000','0.032216957371246','0.031578129678426','1252.60331925527','1252.603319255269980','test','test','1.98'),('2018-08-24 15:59:59','2018-08-24 19:59:59','OAXBTC','4h','0.000026400000000','0.000025872000000','0.032074995661730','0.031433495748495','1214.961956883712','1214.961956883711991','test','test','1.99'),('2018-08-25 19:59:59','2018-08-26 03:59:59','OAXBTC','4h','0.000025400000000','0.000025320000000','0.031932440125456','0.031831865510888','1257.1826821045495','1257.182682104549485','test','test','0.35'),('2018-08-28 03:59:59','2018-08-28 23:59:59','OAXBTC','4h','0.000026200000000','0.000025676000000','0.031910090211107','0.031271888406885','1217.9423744697372','1217.942374469737160','test','test','2.00'),('2018-08-31 23:59:59','2018-09-01 11:59:59','OAXBTC','4h','0.000025450000000','0.000025520000000','0.031768267587947','0.031855645927089','1248.2619877385723','1248.261987738572316','test','test','0.0'),('2018-09-03 15:59:59','2018-09-04 23:59:59','OAXBTC','4h','0.000026500000000','0.000025970000000','0.031787684996645','0.031151931296712','1199.5352828922596','1199.535282892259602','test','test','2.0'),('2018-09-15 15:59:59','2018-09-15 23:59:59','OAXBTC','4h','0.000023710000000','0.000023235800000','0.031646406396660','0.031013478268727','1334.7282326722807','1334.728232672280683','test','test','1.99'),('2018-09-16 23:59:59','2018-09-18 03:59:59','OAXBTC','4h','0.000023730000000','0.000023255400000','0.031505755701564','0.030875640587533','1327.6761778998548','1327.676177899854792','test','test','2.00'),('2018-09-19 11:59:59','2018-09-19 23:59:59','OAXBTC','4h','0.000030320000000','0.000029713600000','0.031365730120668','0.030738415518255','1034.4897797054016','1034.489779705401588','test','test','2.00'),('2018-09-20 19:59:59','2018-09-21 15:59:59','OAXBTC','4h','0.000028410000000','0.000027841800000','0.031226326875687','0.030601800338173','1099.1315338151041','1099.131533815104149','test','test','1.99'),('2018-09-25 15:59:59','2018-09-25 19:59:59','OAXBTC','4h','0.000026960000000','0.000026420800000','0.031087543200684','0.030465792336670','1153.0987834081604','1153.098783408160443','test','test','1.99'),('2018-09-25 23:59:59','2018-09-29 07:59:59','OAXBTC','4h','0.000026450000000','0.000028000000000','0.030949376342014','0.032763044898918','1170.1087463899519','1170.108746389951875','test','test','0.0'),('2018-10-01 03:59:59','2018-10-01 23:59:59','OAXBTC','4h','0.000029060000000','0.000028478800000','0.031352413799104','0.030725365523122','1078.885540230695','1078.885540230694914','test','test','2.00'),('2018-10-04 03:59:59','2018-10-04 07:59:59','OAXBTC','4h','0.000028720000000','0.000028490000000','0.031213069737775','0.030963104346421','1086.806049365413','1086.806049365412946','test','test','0.80'),('2018-10-04 15:59:59','2018-10-04 19:59:59','OAXBTC','4h','0.000029310000000','0.000028723800000','0.031157521873029','0.030534371435568','1063.0338407720687','1063.033840772068743','test','test','2.00'),('2018-10-04 23:59:59','2018-10-05 03:59:59','OAXBTC','4h','0.000029470000000','0.000028880600000','0.031019043998038','0.030398663118077','1052.563420360977','1052.563420360977034','test','test','2.00'),('2018-10-05 19:59:59','2018-10-14 23:59:59','OAXBTC','4h','0.000029420000000','0.000035900000000','0.030881181580269','0.037683018991559','1049.6662671743334','1049.666267174333370','test','test','0.0'),('2018-10-16 15:59:59','2018-10-16 19:59:59','OAXBTC','4h','0.000037290000000','0.000036544200000','0.032392701005000','0.031744846984900','868.6699116385091','868.669911638509120','test','test','2.00'),('2018-10-17 19:59:59','2018-10-18 15:59:59','OAXBTC','4h','0.000039420000000','0.000038631600000','0.032248733444978','0.031603758776078','818.0805034240936','818.080503424093649','test','test','2.00'),('2018-10-20 11:59:59','2018-10-20 23:59:59','OAXBTC','4h','0.000040180000000','0.000039376400000','0.032105405740778','0.031463297625962','799.039465922792','799.039465922792033','test','test','2.00'),('2018-10-22 11:59:59','2018-10-23 03:59:59','OAXBTC','4h','0.000041340000000','0.000040513200000','0.031962715048596','0.031323460747624','773.1667887904316','773.166788790431610','test','test','2.00'),('2018-10-23 11:59:59','2018-10-24 07:59:59','OAXBTC','4h','0.000042920000000','0.000042061600000','0.031820658537269','0.031184245366524','741.3946537108419','741.394653710841908','test','test','1.99'),('2018-10-24 23:59:59','2018-10-25 07:59:59','OAXBTC','4h','0.000043290000000','0.000042424200000','0.031679233388215','0.031045648720451','731.791023058787','731.791023058787005','test','test','2.00'),('2018-10-26 03:59:59','2018-10-26 11:59:59','OAXBTC','4h','0.000042560000000','0.000041708800000','0.031538436795378','0.030907668059470','741.0346991395312','741.034699139531199','test','test','2.00'),('2018-10-28 19:59:59','2018-10-30 03:59:59','OAXBTC','4h','0.000042660000000','0.000041806800000','0.031398265965177','0.030770300645873','736.0118604120174','736.011860412017427','test','test','2.00'),('2018-10-30 11:59:59','2018-10-30 15:59:59','OAXBTC','4h','0.000043410000000','0.000042541800000','0.031258718116442','0.030633543754113','720.0810439171261','720.081043917126067','test','test','1.99'),('2018-11-06 15:59:59','2018-11-13 11:59:59','OAXBTC','4h','0.000040860000000','0.000044180000000','0.031119790480369','0.033648368659391','761.6199334402676','761.619933440267573','test','test','0.0'),('2018-12-17 11:59:59','2018-12-17 15:59:59','OAXBTC','4h','0.000026080000000','0.000025558400000','0.031681696742374','0.031048062807527','1214.788985520484','1214.788985520483948','test','test','2.00'),('2018-12-17 23:59:59','2018-12-18 15:59:59','OAXBTC','4h','0.000025990000000','0.000025470200000','0.031540889201297','0.030910071417271','1213.5778838513702','1213.577883851370188','test','test','2.00'),('2018-12-24 07:59:59','2018-12-25 03:59:59','OAXBTC','4h','0.000024780000000','0.000024284400000','0.031400707471514','0.030772693322084','1267.1794782693123','1267.179478269312312','test','test','1.99'),('2018-12-26 15:59:59','2018-12-26 19:59:59','OAXBTC','4h','0.000024480000000','0.000024340000000','0.031261148771640','0.031082367692064','1277.0077112598128','1277.007711259812822','test','test','0.57'),('2019-01-02 07:59:59','2019-01-07 11:59:59','OAXBTC','4h','0.000023730000000','0.000024190000000','0.031221419642846','0.031826638902674','1315.6940431034786','1315.694043103478634','test','test','0.0'),('2019-01-14 19:59:59','2019-01-27 11:59:59','OAXBTC','4h','0.000023820000000','0.000039560000000','0.031355912811696','0.052075563007166','1316.3691356715458','1316.369135671545791','test','test','0.0'),('2019-01-27 23:59:59','2019-01-28 03:59:59','OAXBTC','4h','0.000042060000000','0.000041218800000','0.035960279521801','0.035241073931365','854.9757375606434','854.975737560643438','test','test','2.00'),('2019-02-02 11:59:59','2019-02-02 15:59:59','OAXBTC','4h','0.000040000000000','0.000039200000000','0.035800456057259','0.035084446936114','895.0114014314831','895.011401431483137','test','test','1.99'),('2019-02-10 23:59:59','2019-02-11 03:59:59','OAXBTC','4h','0.000036180000000','0.000035456400000','0.035641342919227','0.034928516060842','985.1117445889195','985.111744588919464','test','test','2.00'),('2019-02-11 15:59:59','2019-02-11 19:59:59','OAXBTC','4h','0.000037480000000','0.000036730400000','0.035482936950697','0.034773278211683','946.7165675212676','946.716567521267621','test','test','2.00'),('2019-02-12 19:59:59','2019-02-12 23:59:59','OAXBTC','4h','0.000037340000000','0.000036593200000','0.035325235008694','0.034618730308520','946.0427158193359','946.042715819335854','test','test','1.99'),('2019-02-13 15:59:59','2019-02-14 15:59:59','OAXBTC','4h','0.000036040000000','0.000035880000000','0.035168233964211','0.035012104179686','975.8111532799915','975.811153279991458','test','test','0.44'),('2019-02-25 15:59:59','2019-02-25 19:59:59','OAXBTC','4h','0.000033860000000','0.000033182800000','0.035133538456539','0.034430867687408','1037.6118858989566','1037.611885898956643','test','test','2.00'),('2019-03-01 19:59:59','2019-03-01 23:59:59','OAXBTC','4h','0.000033160000000','0.000033270000000','0.034977389396732','0.035093418131160','1054.8066766203792','1054.806676620379221','test','test','0.0'),('2019-03-02 23:59:59','2019-03-04 03:59:59','OAXBTC','4h','0.000033720000000','0.000033045600000','0.035003173559938','0.034303110088739','1038.0537829163106','1038.053782916310638','test','test','2.00'),('2019-03-06 19:59:59','2019-03-11 11:59:59','OAXBTC','4h','0.000033860000000','0.000033840000000','0.034847603899672','0.034827020554191','1029.1672740599986','1029.167274059998590','test','test','1.18'),('2019-03-12 11:59:59','2019-03-18 07:59:59','OAXBTC','4h','0.000035100000000','0.000037600000000','0.034843029822898','0.037324727103731','992.6789123332763','992.678912333276344','test','test','0.0'),('2019-03-18 11:59:59','2019-03-18 19:59:59','OAXBTC','4h','0.000040500000000','0.000039690000000','0.035394518107528','0.034686627745377','873.9387187043839','873.938718704383859','test','test','2.00'),('2019-03-19 07:59:59','2019-03-19 11:59:59','OAXBTC','4h','0.000040490000000','0.000039680200000','0.035237209138161','0.034532464955398','870.2694279614883','870.269427961488304','test','test','2.00'),('2019-03-19 19:59:59','2019-03-20 15:59:59','OAXBTC','4h','0.000039730000000','0.000038935400000','0.035080599319769','0.034378987333374','882.9750646808177','882.975064680817695','test','test','2.00'),('2019-03-21 11:59:59','2019-03-21 15:59:59','OAXBTC','4h','0.000039480000000','0.000038690400000','0.034924685545014','0.034226191834114','884.6171617278228','884.617161727822804','test','test','2.00'),('2019-03-26 11:59:59','2019-03-26 15:59:59','OAXBTC','4h','0.000038230000000','0.000088340000000','0.034769464720370','0.080343565613327','909.4811593086581','909.481159308658107','test','test','0.0'),('2019-03-26 19:59:59','2019-03-27 03:59:59','OAXBTC','4h','0.000091990000000','0.000090150200000','0.044897042696583','0.043999101842651','488.06438413504367','488.064384135043667','test','test','1.99'),('2019-03-27 07:59:59','2019-03-27 11:59:59','OAXBTC','4h','0.000109800000000','0.000107604000000','0.044697500284598','0.043803550278906','407.0810590582676','407.081059058267613','test','test','2.00'),('2019-04-01 03:59:59','2019-04-02 03:59:59','OAXBTC','4h','0.000054970000000','0.000053870600000','0.044498844727777','0.043608867833221','809.5114558445939','809.511455844593911','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 11:52:03
