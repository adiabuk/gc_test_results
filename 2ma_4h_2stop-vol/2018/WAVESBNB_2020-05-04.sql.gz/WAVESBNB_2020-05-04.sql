-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-02 15:59:59','2018-07-07 11:59:59','WAVESBNB','4h','0.211400000000000','0.210400000000000','3.111111111111111','3.096394407652686','14.716703458425313','14.716703458425313','test','test','1.46'),('2018-07-07 23:59:59','2018-07-10 11:59:59','WAVESBNB','4h','0.211800000000000','0.210300000000000','3.107840732564794','3.085830529076375','14.673468992279481','14.673468992279481','test','test','0.70'),('2018-07-11 07:59:59','2018-07-11 11:59:59','WAVESBNB','4h','0.214900000000000','0.212900000000000','3.102949576234035','3.074071497348655','14.439039442689785','14.439039442689785','test','test','0.93'),('2018-07-12 11:59:59','2018-07-12 15:59:59','WAVESBNB','4h','0.215000000000000','0.212300000000000','3.096532225370617','3.057645541610149','14.402475466840079','14.402475466840079','test','test','1.25'),('2018-07-12 19:59:59','2018-07-16 07:59:59','WAVESBNB','4h','0.215900000000000','0.211582000000000','3.087890740090513','3.026132925288703','14.302411950396078','14.302411950396078','test','test','2.00'),('2018-07-16 11:59:59','2018-07-16 19:59:59','WAVESBNB','4h','0.217900000000000','0.218400000000000','3.074166781245666','3.081220858302219','14.108154113105396','14.108154113105396','test','test','0.36'),('2018-07-17 07:59:59','2018-07-17 15:59:59','WAVESBNB','4h','0.220700000000000','0.222200000000000','3.075734353924900','3.096638755967887','13.936268028658361','13.936268028658361','test','test','0.0'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESBNB','4h','0.235800000000000','0.231084000000000','3.080379776601120','3.018772181069098','13.063527466501778','13.063527466501778','test','test','1.99'),('2018-07-18 03:59:59','2018-07-18 07:59:59','WAVESBNB','4h','0.236000000000000','0.231280000000000','3.066689199816226','3.005355415819901','12.994445761933163','12.994445761933163','test','test','2.00'),('2018-07-18 15:59:59','2018-07-19 23:59:59','WAVESBNB','4h','0.228900000000000','0.224322000000000','3.053059470039265','2.991998280638480','13.337961861246244','13.337961861246244','test','test','1.99'),('2018-07-20 11:59:59','2018-07-21 03:59:59','WAVESBNB','4h','0.244000000000000','0.239120000000000','3.039490316839090','2.978700510502308','12.456927528029059','12.456927528029059','test','test','1.99'),('2018-07-22 03:59:59','2018-07-22 15:59:59','WAVESBNB','4h','0.245000000000000','0.240100000000000','3.025981470986472','2.965461841566742','12.350944779536622','12.350944779536622','test','test','2.00'),('2018-07-23 07:59:59','2018-07-23 19:59:59','WAVESBNB','4h','0.234600000000000','0.229908000000000','3.012532664448754','2.952282011159779','12.841145202253854','12.841145202253854','test','test','2.00'),('2018-08-11 15:59:59','2018-08-11 19:59:59','WAVESBNB','4h','0.151700000000000','0.156800000000000','2.999143630384538','3.099971794622910','19.770228282033866','19.770228282033866','test','test','0.0'),('2018-08-12 07:59:59','2018-08-12 11:59:59','WAVESBNB','4h','0.172500000000000','0.169050000000000','3.021549889104176','2.961118891322092','17.51623124118363','17.516231241183629','test','test','2.00'),('2018-08-12 15:59:59','2018-08-27 03:59:59','WAVESBNB','4h','0.166500000000000','0.214900000000000','3.008120778485935','3.882553485265029','18.06679146237799','18.066791462377989','test','test','0.0'),('2018-09-04 15:59:59','2018-09-05 07:59:59','WAVESBNB','4h','0.203500000000000','0.200500000000000','3.202439157770179','3.155228752495926','15.736801758084418','15.736801758084418','test','test','1.47'),('2018-09-08 19:59:59','2018-09-09 19:59:59','WAVESBNB','4h','0.201500000000000','0.197800000000000','3.191947956598122','3.133336505285898','15.840932787087455','15.840932787087455','test','test','1.83'),('2018-09-10 11:59:59','2018-09-10 15:59:59','WAVESBNB','4h','0.257700000000000','0.252546000000000','3.178923189639850','3.115344725847053','12.335751609002136','12.335751609002136','test','test','1.99'),('2018-09-10 23:59:59','2018-09-11 15:59:59','WAVESBNB','4h','0.242900000000000','0.238042000000000','3.164794642130339','3.101498749287732','13.029208077934703','13.029208077934703','test','test','2.00'),('2018-09-13 15:59:59','2018-09-13 19:59:59','WAVESBNB','4h','0.270800000000000','0.265384000000000','3.150728888165316','3.087714310402009','11.634892496917711','11.634892496917711','test','test','2.00'),('2018-09-15 11:59:59','2018-09-15 23:59:59','WAVESBNB','4h','0.228200000000000','0.229800000000000','3.136725648662359','3.158718466532034','13.745511168546711','13.745511168546711','test','test','0.04'),('2018-09-17 19:59:59','2018-09-17 23:59:59','WAVESBNB','4h','0.227300000000000','0.224300000000000','3.141612941522287','3.100148626412006','13.82143837009365','13.821438370093651','test','test','1.31'),('2018-09-18 15:59:59','2018-09-18 19:59:59','WAVESBNB','4h','0.227700000000000','0.224000000000000','3.132398649275558','3.081498890811265','13.756691476836','13.756691476836000','test','test','1.62'),('2018-09-19 03:59:59','2018-09-20 15:59:59','WAVESBNB','4h','0.233600000000000','0.228928000000000','3.121087591839048','3.058665840002267','13.36082017054387','13.360820170543869','test','test','2.00'),('2018-09-23 15:59:59','2018-09-23 23:59:59','WAVESBNB','4h','0.229100000000000','0.225500000000000','3.107216091430874','3.058390347523624','13.562706640902986','13.562706640902986','test','test','1.57'),('2018-09-24 11:59:59','2018-09-24 15:59:59','WAVESBNB','4h','0.225500000000000','0.223000000000000','3.096365926118152','3.062038144232141','13.731112754404219','13.731112754404219','test','test','1.10'),('2018-09-26 19:59:59','2018-09-27 11:59:59','WAVESBNB','4h','0.232600000000000','0.227948000000000','3.088737530143483','3.026962779540613','13.279181127014114','13.279181127014114','test','test','2.00'),('2018-10-17 07:59:59','2018-10-17 15:59:59','WAVESBNB','4h','0.206300000000000','0.204300000000000','3.075009807787290','3.045198757784505','14.905525001392581','14.905525001392581','test','test','0.96'),('2018-10-21 15:59:59','2018-10-21 19:59:59','WAVESBNB','4h','0.205000000000000','0.202600000000000','3.068385130008892','3.032462572389276','14.967732341506792','14.967732341506792','test','test','1.17'),('2018-11-17 07:59:59','2018-11-18 15:59:59','WAVESBNB','4h','0.192700000000000','0.189700000000000','3.060402339426756','3.012757258895981','15.881693510258206','15.881693510258206','test','test','1.55'),('2018-11-19 03:59:59','2018-11-20 11:59:59','WAVESBNB','4h','0.192700000000000','0.192200000000000','3.049814543753250','3.041901169223532','15.826749059435652','15.826749059435652','test','test','1.24'),('2018-11-20 19:59:59','2018-11-20 23:59:59','WAVESBNB','4h','0.197800000000000','0.193844000000000','3.048056016079979','2.987094895758379','15.409787745601514','15.409787745601514','test','test','2.00'),('2018-11-22 23:59:59','2018-12-25 11:59:59','WAVESBNB','4h','0.192500000000000','0.589400000000000','3.034509100452957','9.291115136659601','15.763683638716662','15.763683638716662','test','test','0.0'),('2018-12-26 15:59:59','2018-12-26 19:59:59','WAVESBNB','4h','0.623200000000000','0.610736000000000','4.424865997387767','4.336368677440011','7.100234270519523','7.100234270519523','test','test','2.00'),('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.467166000000000','4.405199926288266','4.317095927762501','9.241031941028458','9.241031941028458','test','test','1.99'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','4.385621259949207','4.389365653767733','9.360984546316342','9.360984546316342','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','4.386453347464434','4.325971751881259','10.251117895453223','10.251117895453223','test','test','1.37'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.442666000000000','4.373012992890397','4.285552733032588','9.68123310358733','9.681233103587330','test','test','1.99'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','4.353577379588661','4.274548211993352','23.24387282214982','23.243872822149822','test','test','1.81'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','4.336015342345259','4.263706863375730','24.933958265355137','24.933958265355137','test','test','1.66'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.160132000000000','4.319946791463141','4.233547855633879','26.43786286085154','26.437862860851538','test','test','1.99'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.160622000000000','4.300747027945527','4.214732087386617','26.240067284597483','26.240067284597483','test','test','2.00'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.161602000000000','4.281632596710215','4.195999944776010','25.965024843603487','25.965024843603487','test','test','1.99'),('2019-05-07 15:59:59','2019-05-07 23:59:59','WAVESBNB','4h','0.110200000000000','0.107996000000000','4.262603118502613','4.177351056132561','38.68060906082226','38.680609060822263','test','test','1.99'),('2019-05-08 11:59:59','2019-05-08 15:59:59','WAVESBNB','4h','0.106300000000000','0.104174000000000','4.243658215753713','4.158785051438638','39.92152601837923','39.921526018379232','test','test','2.00'),('2019-05-09 19:59:59','2019-05-11 15:59:59','WAVESBNB','4h','0.116100000000000','0.113778000000000','4.224797512572585','4.140301562321133','36.38929812724018','36.389298127240181','test','test','2.00'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WAVESBNB','4h','0.105000000000000','0.102900000000000','4.206020634738929','4.121900222044150','40.05733937846599','40.057339378465990','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-04 10:44:59
