-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-21 07:59:59','2018-05-21 11:59:59','NEOUSDT','4h','65.659999999999997','64.346800000000002','222.222222222222200','217.777777777777771','3.38443835245541','3.384438352455410','test','test','1.99'),('2018-06-01 23:59:59','2018-06-04 07:59:59','NEOUSDT','4h','55.500000000000000','54.704999999999998','221.234567901234556','218.065532198865498','3.9862084306528747','3.986208430652875','test','test','1.43'),('2018-07-02 11:59:59','2018-07-09 19:59:59','NEOUSDT','4h','32.973999999999997','37.619999999999997','220.530337745152565','251.602817552393986','6.68800684615614','6.688006846156140','test','test','0.0'),('2018-07-09 23:59:59','2018-07-10 03:59:59','NEOUSDT','4h','36.435000000000002','35.706299999999999','227.435333257872884','222.886626592715402','6.242221305279892','6.242221305279892','test','test','2.00'),('2018-07-16 11:59:59','2018-07-19 19:59:59','NEOUSDT','4h','35.218000000000004','35.810000000000002','226.424509554504539','230.230611821988958','6.42922680318316','6.429226803183160','test','test','0.0'),('2018-07-19 23:59:59','2018-07-20 03:59:59','NEOUSDT','4h','35.984000000000002','35.359999999999999','227.270310058389981','223.329206415758932','6.3158712221651285','6.315871222165129','test','test','1.73'),('2018-07-25 07:59:59','2018-07-25 11:59:59','NEOUSDT','4h','34.871000000000002','34.173580000000001','226.394509248916421','221.866619063938089','6.492343473055445','6.492343473055445','test','test','2.00'),('2018-07-26 07:59:59','2018-07-26 15:59:59','NEOUSDT','4h','35.174999999999997','34.471499999999999','225.388311430032331','220.880545201431715','6.407627901351311','6.407627901351311','test','test','1.99'),('2018-07-26 19:59:59','2018-07-26 23:59:59','NEOUSDT','4h','34.765000000000001','34.069699999999997','224.386585601454414','219.898853889425283','6.4543818668619135','6.454381866861914','test','test','2.00'),('2018-08-17 23:59:59','2018-08-18 03:59:59','NEOUSDT','4h','20.670000000000002','20.256600000000002','223.389311887670175','218.921525649916759','10.807417120835519','10.807417120835519','test','test','1.99'),('2018-08-27 19:59:59','2018-08-30 07:59:59','NEOUSDT','4h','19.946999999999999','19.548060000000000','222.396470501502762','217.948541091472691','11.149369353862875','11.149369353862875','test','test','1.99'),('2018-08-30 11:59:59','2018-08-30 15:59:59','NEOUSDT','4h','18.701000000000001','19.004999999999999','221.408041743718286','225.007209953444516','11.839369110941568','11.839369110941568','test','test','0.0'),('2018-08-30 23:59:59','2018-08-31 03:59:59','NEOUSDT','4h','19.559999999999999','19.356999999999999','222.207856901435207','219.901711965290474','11.360319882486463','11.360319882486463','test','test','1.03'),('2018-08-31 07:59:59','2018-09-05 11:59:59','NEOUSDT','4h','19.436000000000000','21.524999999999999','221.695380248958628','245.523413246492794','11.40643034826912','11.406430348269121','test','test','0.90'),('2018-09-05 15:59:59','2018-09-05 19:59:59','NEOUSDT','4h','21.532000000000000','21.101360000000000','226.990498692855112','222.450688718998009','10.54200718432357','10.542007184323570','test','test','2.00'),('2018-09-20 23:59:59','2018-09-21 03:59:59','NEOUSDT','4h','18.186000000000000','18.265000000000001','225.981652031997982','226.963316527243109','12.426132851204112','12.426132851204112','test','test','0.0'),('2018-09-21 07:59:59','2018-09-21 15:59:59','NEOUSDT','4h','19.149999999999999','18.766999999999999','226.199799697608000','221.675803703655873','11.811999984209296','11.811999984209296','test','test','1.99'),('2018-09-21 19:59:59','2018-09-22 03:59:59','NEOUSDT','4h','19.960000000000001','19.560800000000000','225.194467254507543','220.690577909417385','11.282287938602582','11.282287938602582','test','test','2.00'),('2018-09-22 07:59:59','2018-09-22 11:59:59','NEOUSDT','4h','19.068000000000001','18.686640000000001','224.193602955598607','219.709730896486633','11.75758354078029','11.757583540780290','test','test','2.00'),('2018-09-22 15:59:59','2018-09-24 07:59:59','NEOUSDT','4h','18.750000000000000','18.841999999999999','223.197186942462594','224.292341139726943','11.903849970264671','11.903849970264671','test','test','0.0'),('2018-09-24 11:59:59','2018-09-24 15:59:59','NEOUSDT','4h','18.315000000000001','18.655000000000001','223.440554541854681','227.588509144324263','12.199866477851742','12.199866477851742','test','test','0.0'),('2018-09-24 19:59:59','2018-09-24 23:59:59','NEOUSDT','4h','18.811000000000000','18.448000000000000','224.362322231292382','220.032753204129591','11.927187402652299','11.927187402652299','test','test','1.92'),('2018-09-26 15:59:59','2018-09-26 19:59:59','NEOUSDT','4h','18.559999999999999','18.188799999999997','223.400195780811714','218.932191865195449','12.036648479569598','12.036648479569598','test','test','2.00'),('2018-09-27 15:59:59','2018-09-29 03:59:59','NEOUSDT','4h','18.472999999999999','18.638999999999999','222.407306021785899','224.405877601909111','12.039587832067662','12.039587832067662','test','test','0.0'),('2018-09-29 07:59:59','2018-09-30 23:59:59','NEOUSDT','4h','18.890000000000001','18.936000000000000','222.851433039591058','223.394109901413231','11.79732308309111','11.797323083091110','test','test','0.34'),('2018-10-01 03:59:59','2018-10-01 11:59:59','NEOUSDT','4h','18.998999999999999','18.765999999999998','222.972027897773756','220.237542793285030','11.735987572912983','11.735987572912983','test','test','1.22'),('2018-10-01 23:59:59','2018-10-02 03:59:59','NEOUSDT','4h','18.713000000000001','18.690999999999999','222.364364541220738','222.102941144656455','11.882881662011474','11.882881662011474','test','test','0.11'),('2018-10-02 07:59:59','2018-10-02 11:59:59','NEOUSDT','4h','18.670999999999999','18.559000000000001','222.306270453095323','220.972742399389261','11.90650047951879','11.906500479518790','test','test','0.59'),('2018-10-08 11:59:59','2018-10-09 11:59:59','NEOUSDT','4h','18.408000000000001','18.297000000000001','222.009930885605058','220.671213896888077','12.060513411864681','12.060513411864681','test','test','0.60'),('2018-10-17 15:59:59','2018-10-18 19:59:59','NEOUSDT','4h','17.190999999999999','16.905000000000001','221.712438221445751','218.023894371097725','12.89700646974846','12.897006469748460','test','test','1.66'),('2018-10-20 11:59:59','2018-10-20 15:59:59','NEOUSDT','4h','17.088999999999999','16.885000000000002','220.892761810257298','218.255853658271121','12.926020352873621','12.926020352873621','test','test','1.19'),('2018-10-21 15:59:59','2018-10-21 19:59:59','NEOUSDT','4h','17.120000000000001','16.981000000000002','220.306782220927033','218.518076454063191','12.868386811970037','12.868386811970037','test','test','0.81'),('2018-10-22 15:59:59','2018-10-23 03:59:59','NEOUSDT','4h','17.143999999999998','16.884000000000000','219.909292050512846','216.574223458986182','12.827186890487217','12.827186890487217','test','test','1.51'),('2018-10-24 19:59:59','2018-10-24 23:59:59','NEOUSDT','4h','16.986000000000001','16.934000000000001','219.168165696840248','218.497216408235772','12.902870934701532','12.902870934701532','test','test','0.30'),('2018-11-02 15:59:59','2018-11-02 19:59:59','NEOUSDT','4h','16.138000000000002','16.180000000000000','219.019065854928158','219.589074577564588','13.571636253248737','13.571636253248737','test','test','0.0'),('2018-11-02 23:59:59','2018-11-03 11:59:59','NEOUSDT','4h','16.295999999999999','16.004999999999999','219.145734459958476','215.232417773173495','13.447823665927743','13.447823665927743','test','test','1.78'),('2018-11-04 07:59:59','2018-11-04 11:59:59','NEOUSDT','4h','16.152000000000001','16.559999999999999','218.276108529561810','223.789769517678508','13.513874970874307','13.513874970874307','test','test','0.0'),('2018-11-04 15:59:59','2018-11-08 19:59:59','NEOUSDT','4h','16.651000000000000','16.460000000000001','219.501366526921061','216.983514085227370','13.182473516720982','13.182473516720982','test','test','1.81'),('2018-11-08 23:59:59','2018-11-09 03:59:59','NEOUSDT','4h','16.408999999999999','16.405999999999999','218.941843762100262','218.901815391615372','13.342790161624736','13.342790161624736','test','test','0.01'),('2018-11-09 07:59:59','2018-11-09 11:59:59','NEOUSDT','4h','16.420000000000002','16.093000000000000','218.932948568659157','214.572956231146861','13.333309900649155','13.333309900649155','test','test','1.99'),('2018-12-17 19:59:59','2018-12-18 11:59:59','NEOUSDT','4h','6.592000000000000','6.460159999999999','217.964061382545310','213.604780154894399','33.06493649613855','33.064936496138550','test','test','2.00'),('2018-12-18 15:59:59','2018-12-27 19:59:59','NEOUSDT','4h','6.447000000000000','6.814000000000000','216.995332220845143','229.347943811515222','33.65834220891037','33.658342208910369','test','test','0.0'),('2018-12-28 15:59:59','2018-12-31 19:59:59','NEOUSDT','4h','7.372000000000000','7.418000000000000','219.740357018771789','221.111498693061492','29.80742770194951','29.807427701949511','test','test','0.0'),('2018-12-31 23:59:59','2019-01-01 03:59:59','NEOUSDT','4h','7.409000000000000','7.373000000000000','220.045055168613970','218.975866076149401','29.699697012905112','29.699697012905112','test','test','0.48'),('2019-01-01 07:59:59','2019-01-01 15:59:59','NEOUSDT','4h','7.445000000000000','7.361000000000000','219.807457592510701','217.327427177766452','29.524171604098147','29.524171604098147','test','test','1.12'),('2019-01-01 19:59:59','2019-01-03 19:59:59','NEOUSDT','4h','7.460000000000000','7.480000000000000','219.256339722567560','219.844158327721885','29.390930257716832','29.390930257716832','test','test','0.0'),('2019-01-03 23:59:59','2019-01-04 03:59:59','NEOUSDT','4h','7.522000000000000','7.600000000000000','219.386966079268518','221.661917336139396','29.166041754755188','29.166041754755188','test','test','0.0'),('2019-01-04 07:59:59','2019-01-04 11:59:59','NEOUSDT','4h','7.581000000000000','7.445000000000000','219.892510803017586','215.947730237233344','29.00573945429595','29.005739454295949','test','test','1.79'),('2019-01-05 03:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.579000000000000','8.327999999999999','219.015892899510021','240.660292395714379','28.89772963445178','28.897729634451778','test','test','0.42'),('2019-01-10 11:59:59','2019-01-10 15:59:59','NEOUSDT','4h','8.145000000000000','7.982099999999999','223.825759454222066','219.349244265137628','27.48014235165403','27.480142351654031','test','test','2.00'),('2019-01-19 11:59:59','2019-01-20 11:59:59','NEOUSDT','4h','7.900000000000000','7.742000000000000','222.830978301092188','218.374358735070331','28.20645294950534','28.206452949505341','test','test','2.00'),('2019-01-24 23:59:59','2019-01-25 07:59:59','NEOUSDT','4h','7.642000000000000','7.579000000000000','221.840618397531784','220.011783150339340','29.02913090781625','29.029130907816249','test','test','0.82'),('2019-02-02 23:59:59','2019-02-03 03:59:59','NEOUSDT','4h','7.237000000000000','7.119000000000000','221.434210564822365','217.823703884340233','30.597514241373823','30.597514241373823','test','test','1.63'),('2019-02-08 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','7.413000000000000','9.410000000000000','220.631875746937453','280.068251824994093','29.762832287459524','29.762832287459524','test','test','0.0'),('2019-02-24 23:59:59','2019-02-27 23:59:59','NEOUSDT','4h','8.907999999999999','8.856999999999999','233.839959319838925','232.501180926786418','26.250556726519864','26.250556726519864','test','test','0.71'),('2019-02-28 03:59:59','2019-02-28 11:59:59','NEOUSDT','4h','8.891999999999999','8.920000000000000','233.542453010271714','234.277854346786313','26.264333446949138','26.264333446949138','test','test','0.0'),('2019-02-28 15:59:59','2019-02-28 19:59:59','NEOUSDT','4h','8.945000000000000','8.864000000000001','233.705875529497149','231.589589792449743','26.12698440799297','26.126984407992971','test','test','0.90'),('2019-03-01 07:59:59','2019-03-01 11:59:59','NEOUSDT','4h','8.869999999999999','8.851000000000001','233.235589810153328','232.735987081134994','26.294880474650885','26.294880474650885','test','test','0.21'),('2019-03-01 19:59:59','2019-03-02 07:59:59','NEOUSDT','4h','8.971000000000000','8.791580000000000','233.124566981482531','228.462075641852863','25.98646382582572','25.986463825825719','test','test','2.00'),('2019-03-05 19:59:59','2019-03-05 23:59:59','NEOUSDT','4h','8.754000000000000','8.739000000000001','232.088457794898204','231.690773665708889','26.512275279289263','26.512275279289263','test','test','0.17'),('2019-03-06 11:59:59','2019-03-06 15:59:59','NEOUSDT','4h','8.736000000000001','8.689000000000000','232.000083543967207','230.751914596329073','26.556786119959614','26.556786119959614','test','test','0.53'),('2019-03-06 23:59:59','2019-03-07 03:59:59','NEOUSDT','4h','8.705000000000000','8.763999999999999','231.722712666714301','233.293262930624223','26.619495998473784','26.619495998473784','test','test','0.0'),('2019-03-07 07:59:59','2019-03-07 11:59:59','NEOUSDT','4h','8.779999999999999','8.669000000000000','232.071723836472046','229.137787464507568','26.431859206887477','26.431859206887477','test','test','1.26'),('2019-03-07 15:59:59','2019-03-08 23:59:59','NEOUSDT','4h','8.755000000000001','8.765000000000001','231.419737976035520','231.684066631633527','26.432865559798458','26.432865559798458','test','test','0.0'),('2019-03-09 03:59:59','2019-03-10 07:59:59','NEOUSDT','4h','8.848000000000001','8.755000000000001','231.478477677279471','229.045442141114592','26.16167243188059','26.161672431880589','test','test','1.05'),('2019-03-11 03:59:59','2019-03-11 07:59:59','NEOUSDT','4h','8.821000000000000','8.644579999999999','230.937803113687295','226.319047051413548','26.180456083628535','26.180456083628535','test','test','2.00'),('2019-03-12 15:59:59','2019-03-12 19:59:59','NEOUSDT','4h','8.789999999999999','8.811000000000000','229.911412877626503','230.460689290644751','26.156019667534302','26.156019667534302','test','test','0.0'),('2019-03-12 23:59:59','2019-03-13 11:59:59','NEOUSDT','4h','8.826000000000001','8.784000000000001','230.033474302741638','228.938821467854353','26.06316273541147','26.063162735411471','test','test','0.47'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.802359999999998','229.790218117211111','225.194413754866872','25.583413284035974','25.583413284035974','test','test','2.00'),('2019-03-14 15:59:59','2019-03-18 07:59:59','NEOUSDT','4h','9.090999999999999','9.053000000000001','228.768928258912439','227.812683701235812','25.16433046517572','25.164330465175720','test','test','0.41'),('2019-03-18 11:59:59','2019-03-19 07:59:59','NEOUSDT','4h','9.086000000000000','9.016999999999999','228.556429468317646','226.820748901146828','25.154790828562366','25.154790828562366','test','test','0.75'),('2019-03-19 11:59:59','2019-03-19 15:59:59','NEOUSDT','4h','9.063000000000001','9.125000000000000','228.170722675612978','229.731639017430041','25.1760700293074','25.176070029307400','test','test','0.0'),('2019-03-19 19:59:59','2019-03-20 03:59:59','NEOUSDT','4h','9.143000000000001','9.029999999999999','228.517592973794564','225.693302477673029','24.993721204614957','24.993721204614957','test','test','1.23'),('2019-03-20 07:59:59','2019-03-20 11:59:59','NEOUSDT','4h','9.101000000000001','9.084000000000000','227.889972863545353','227.464291121024701','25.04010250121364','25.040102501213639','test','test','0.18'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.183999999999999','9.000319999999999','227.795376920762948','223.239469382347664','24.80350358457785','24.803503584577850','test','test','2.00'),('2019-03-22 11:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.143000000000001','9.132000000000000','226.782953023337342','226.510109046168253','24.80399792445995','24.803997924459949','test','test','0.12'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NEOUSDT','4h','9.148000000000000','9.111000000000001','226.722321028410875','225.805319948606439','24.783812967688117','24.783812967688117','test','test','0.40'),('2019-03-24 23:59:59','2019-03-25 03:59:59','NEOUSDT','4h','9.124000000000001','9.085000000000001','226.518543010676581','225.550302855326265','24.826670650008392','24.826670650008392','test','test','0.42'),('2019-03-25 11:59:59','2019-03-25 15:59:59','NEOUSDT','4h','9.268000000000001','9.082640000000001','226.303378531709797','221.777310961075614','24.417714558881073','24.417714558881073','test','test','1.99'),('2019-03-27 07:59:59','2019-04-09 07:59:59','NEOUSDT','4h','9.125999999999999','12.166000000000000','225.297585738235540','300.347406102495484','24.68744090929603','24.687440909296029','test','test','0.0'),('2019-04-09 11:59:59','2019-04-09 23:59:59','NEOUSDT','4h','12.317000000000000','12.070660000000000','241.975323596960010','237.135817125020793','19.645638028493952','19.645638028493952','test','test','2.0'),('2019-04-10 03:59:59','2019-04-11 03:59:59','NEOUSDT','4h','12.340000000000000','12.093200000000000','240.899877714306825','236.081880160020688','19.521870155130213','19.521870155130213','test','test','2.00'),('2019-05-02 15:59:59','2019-05-02 19:59:59','NEOUSDT','4h','10.061999999999999','9.860759999999999','239.829211591132179','235.032627359309544','23.83514327083405','23.835143270834049','test','test','2.00'),('2019-05-03 11:59:59','2019-05-03 19:59:59','NEOUSDT','4h','10.016000000000000','9.948000000000000','238.763303984060457','237.142307111964215','23.838189295533194','23.838189295533194','test','test','0.67'),('2019-05-03 23:59:59','2019-05-04 07:59:59','NEOUSDT','4h','9.929000000000000','9.747999999999999','238.403082456927933','234.057130404888028','24.010784817899882','24.010784817899882','test','test','1.82');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:59:49
