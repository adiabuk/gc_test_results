-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-07-03 03:59:59','2019-07-03 15:59:59','LINKUSDT','4h','3.735100000000000','3.660398000000000','222.222222222222200','217.777777777777743','59.495655329769534','59.495655329769534','test','test','2.00'),('2019-07-03 19:59:59','2019-07-03 23:59:59','LINKUSDT','4h','3.609000000000000','3.536820000000000','221.234567901234556','216.809876543209867','61.300794652600324','61.300794652600324','test','test','1.99'),('2019-07-04 03:59:59','2019-07-04 07:59:59','LINKUSDT','4h','3.448700000000000','3.379726000000000','220.251303155006866','215.846277091906728','63.865022517182375','63.865022517182375','test','test','1.99'),('2019-07-04 11:59:59','2019-07-04 19:59:59','LINKUSDT','4h','3.444300000000000','3.375414000000000','219.272408474317928','214.886960304831575','63.66240120614288','63.662401206142881','test','test','2.0'),('2019-07-04 23:59:59','2019-07-07 07:59:59','LINKUSDT','4h','3.453000000000000','3.383940000000000','218.297864436654322','213.931907147921237','63.21976960227464','63.219769602274638','test','test','1.99'),('2019-07-07 11:59:59','2019-07-09 03:59:59','LINKUSDT','4h','3.316000000000000','3.249680000000000','217.327651705824763','212.981098671708253','65.53909882564076','65.539098825640764','test','test','2.00'),('2019-07-09 07:59:59','2019-07-09 11:59:59','LINKUSDT','4h','3.246900000000000','3.181962000000000','216.361751031576631','212.034516010945083','66.63640735211328','66.636407352113281','test','test','2.00'),('2019-07-12 19:59:59','2019-07-12 23:59:59','LINKUSDT','4h','3.288700000000000','3.222926000000000','215.400143249214040','211.092140384229765','65.49704845355734','65.497048453557341','test','test','2.00'),('2019-07-13 03:59:59','2019-07-13 11:59:59','LINKUSDT','4h','3.213900000000000','3.149622000000000','214.442809279217528','210.153953093633163','66.72354749034429','66.723547490344288','test','test','2.00'),('2019-07-13 15:59:59','2019-07-13 19:59:59','LINKUSDT','4h','3.173900000000000','3.228900000000000','213.489730126865453','217.189259146991333','67.26416400228912','67.264164002289121','test','test','0.0'),('2019-07-13 23:59:59','2019-07-14 03:59:59','LINKUSDT','4h','3.165200000000000','3.139400000000000','214.311847686893429','212.564961022441963','67.70878544385613','67.708785443856129','test','test','0.81'),('2019-07-14 07:59:59','2019-07-14 11:59:59','LINKUSDT','4h','3.149900000000000','3.086902000000000','213.923650650348662','209.645177637341675','67.91442606125548','67.914426061255483','test','test','1.99'),('2019-08-02 19:59:59','2019-08-02 23:59:59','LINKUSDT','4h','2.360500000000000','2.427100000000000','212.972878869680443','218.981772634866076','90.22363010789257','90.223630107892575','test','test','0.0'),('2019-08-03 03:59:59','2019-08-03 23:59:59','LINKUSDT','4h','2.523800000000000','2.473324000000000','214.308188595277244','210.022024823371709','84.91488572599938','84.914885725999383','test','test','2.00'),('2019-08-04 03:59:59','2019-08-06 11:59:59','LINKUSDT','4h','2.444000000000000','2.400000000000000','213.355707757076033','209.514606635426560','87.29775276476106','87.297752764761057','test','test','1.80'),('2019-08-06 15:59:59','2019-08-06 19:59:59','LINKUSDT','4h','2.386100000000000','2.428000000000000','212.502129730042810','216.233674609003771','89.05835033319761','89.058350333197609','test','test','0.0'),('2019-08-06 23:59:59','2019-08-07 07:59:59','LINKUSDT','4h','2.478500000000000','2.428930000000000','213.331361925367474','209.064734686860135','86.07277059728364','86.072770597283636','test','test','2.00'),('2019-08-07 11:59:59','2019-08-07 15:59:59','LINKUSDT','4h','2.400000000000000','2.397600000000000','212.383222539032516','212.170839316493499','88.49300939126356','88.493009391263556','test','test','0.09'),('2019-08-11 03:59:59','2019-08-11 07:59:59','LINKUSDT','4h','2.374800000000000','2.362500000000000','212.336026267357170','211.236256550712170','89.41217208495755','89.412172084957547','test','test','0.51'),('2019-08-11 11:59:59','2019-08-11 15:59:59','LINKUSDT','4h','2.344000000000000','2.363200000000000','212.091632996991592','213.828902345772406','90.4827785823343','90.482778582334305','test','test','0.0'),('2019-08-11 19:59:59','2019-08-12 19:59:59','LINKUSDT','4h','2.433200000000000','2.384536000000000','212.477692852276249','208.228138995230722','87.3243847000971','87.324384700097099','test','test','2.00'),('2019-08-12 23:59:59','2019-08-13 03:59:59','LINKUSDT','4h','2.390000000000000','2.356000000000000','211.533347550710573','208.524086539528895','88.50767679946048','88.507676799460484','test','test','1.42'),('2019-08-13 19:59:59','2019-08-14 19:59:59','LINKUSDT','4h','2.438900000000000','2.390122000000000','210.864622881559058','206.647330423927883','86.45890478558329','86.458904785583286','test','test','1.99'),('2019-08-15 23:59:59','2019-08-16 03:59:59','LINKUSDT','4h','2.423200000000000','2.374736000000000','209.927446779863232','205.728897844265958','86.63232369588282','86.632323695882818','test','test','2.00'),('2019-08-17 15:59:59','2019-08-17 19:59:59','LINKUSDT','4h','2.398100000000000','2.356000000000000','208.994435905286082','205.325420538281975','87.15000871743717','87.150008717437174','test','test','1.75'),('2019-08-17 23:59:59','2019-08-20 11:59:59','LINKUSDT','4h','2.403600000000000','2.411900000000000','208.179099157062979','208.897973563371693','86.61137425406181','86.611374254061815','test','test','0.53'),('2019-09-18 07:59:59','2019-09-18 11:59:59','LINKUSDT','4h','1.741500000000000','1.706670000000000','208.338849025131566','204.172072044628919','119.63183980771264','119.631839807712637','test','test','2.00'),('2019-09-18 15:59:59','2019-09-18 19:59:59','LINKUSDT','4h','1.779300000000000','1.743714000000000','207.412898585019860','203.264640613319472','116.56994244085868','116.569942440858682','test','test','2.00'),('2019-09-18 23:59:59','2019-09-24 19:59:59','LINKUSDT','4h','1.801000000000000','1.764980000000000','206.491063480197568','202.361242210593616','114.65356106618411','114.653561066184110','test','test','1.99'),('2019-09-30 19:59:59','2019-10-15 19:59:59','LINKUSDT','4h','1.741000000000000','2.433200000000000','205.573325420285556','287.306729128454208','118.07772855846385','118.077728558463846','test','test','0.0'),('2019-10-17 15:59:59','2019-10-17 23:59:59','LINKUSDT','4h','2.450000000000000','2.412400000000000','223.736304022100825','220.302636662414699','91.320940417184','91.320940417184005','test','test','1.53'),('2019-10-18 03:59:59','2019-10-18 07:59:59','LINKUSDT','4h','2.475600000000000','2.426088000000000','222.973266831059419','218.513801494438241','90.0683740632814','90.068374063281397','test','test','2.0'),('2019-10-18 11:59:59','2019-10-18 15:59:59','LINKUSDT','4h','2.418100000000000','2.380200000000000','221.982274534032513','218.503043648279316','91.80028722303979','91.800287223039788','test','test','1.56'),('2019-10-20 19:59:59','2019-10-23 15:59:59','LINKUSDT','4h','2.434800000000000','2.503500000000000','221.209112114976250','227.450719640152357','90.85309352512577','90.853093525125772','test','test','0.0'),('2019-10-23 19:59:59','2019-10-29 19:59:59','LINKUSDT','4h','2.601600000000000','2.672800000000000','222.596136009459855','228.688096681305495','85.56124539109004','85.561245391090040','test','test','0.0'),('2019-10-29 23:59:59','2019-10-30 03:59:59','LINKUSDT','4h','2.662000000000000','2.622500000000000','223.949905047647775','220.626831700772470','84.12843916140037','84.128439161400365','test','test','1.48'),('2019-10-31 19:59:59','2019-11-01 15:59:59','LINKUSDT','4h','2.719200000000000','2.664816000000000','223.211444303897679','218.747215417819689','82.08717428063316','82.087174280633164','test','test','2.00'),('2019-11-01 19:59:59','2019-11-03 11:59:59','LINKUSDT','4h','2.660000000000000','2.659900000000000','222.219393440324779','222.211039327789393','83.54112535350555','83.541125353505549','test','test','0.00'),('2019-11-03 15:59:59','2019-11-03 19:59:59','LINKUSDT','4h','2.670000000000000','2.641000000000000','222.217536970872487','219.803938254709465','83.22754193665637','83.227541936656365','test','test','1.08'),('2019-11-03 23:59:59','2019-11-04 03:59:59','LINKUSDT','4h','2.660500000000000','2.640400000000000','221.681181700614047','220.006386830408331','83.3231278709318','83.323127870931799','test','test','0.75'),('2019-11-04 11:59:59','2019-11-05 03:59:59','LINKUSDT','4h','2.669900000000000','2.660600000000000','221.309005062790561','220.538124600194976','82.8903723221059','82.890372322105904','test','test','0.34'),('2019-11-05 11:59:59','2019-11-06 03:59:59','LINKUSDT','4h','2.667500000000000','2.657700000000000','221.137698293324888','220.325271135583733','82.90073038175254','82.900730381752538','test','test','0.36'),('2019-11-06 07:59:59','2019-11-06 11:59:59','LINKUSDT','4h','2.679800000000000','2.663500000000000','220.957158924937943','219.613177400019453','82.45285428947605','82.452854289476051','test','test','0.60'),('2019-11-06 15:59:59','2019-11-06 19:59:59','LINKUSDT','4h','2.677500000000000','2.699200000000000','220.658496363844932','222.446839733068231','82.41213683056766','82.412136830567661','test','test','0.0'),('2019-11-06 23:59:59','2019-11-07 03:59:59','LINKUSDT','4h','2.744800000000000','2.689904000000000','221.055906001450126','216.634787881421147','80.5362525508052','80.536252550805202','test','test','1.99'),('2019-11-07 07:59:59','2019-11-07 11:59:59','LINKUSDT','4h','2.682400000000000','2.670000000000000','220.073435308110334','219.056096135048705','82.04348169852011','82.043481698520111','test','test','0.46'),('2019-11-07 15:59:59','2019-11-07 19:59:59','LINKUSDT','4h','2.679800000000000','2.687100000000000','219.847359936318867','220.446242587089472','82.03871928364761','82.038719283647609','test','test','0.0'),('2019-11-07 23:59:59','2019-11-08 03:59:59','LINKUSDT','4h','2.675700000000000','2.716300000000000','219.980444969823452','223.318340124652053','82.21416637508818','82.214166375088183','test','test','0.0'),('2019-11-08 07:59:59','2019-11-08 11:59:59','LINKUSDT','4h','2.693200000000000','2.677800000000000','220.722199448674274','219.460086768030578','81.95536887296683','81.955368872966829','test','test','0.57'),('2019-11-08 23:59:59','2019-11-11 07:59:59','LINKUSDT','4h','2.710000000000000','2.729600000000000','220.441729964086761','222.036068675266137','81.34381179486597','81.343811794865971','test','test','0.0'),('2019-11-11 11:59:59','2019-11-11 15:59:59','LINKUSDT','4h','2.704300000000000','2.719000000000000','220.796027455459949','221.996227730427648','81.64627720868985','81.646277208689853','test','test','0.0'),('2019-11-11 19:59:59','2019-11-15 15:59:59','LINKUSDT','4h','2.737800000000000','2.929900000000000','221.062738627675003','236.573788408658402','80.74466309725875','80.744663097258751','test','test','0.09'),('2019-11-15 19:59:59','2019-11-18 11:59:59','LINKUSDT','4h','2.939900000000000','2.881102000000000','224.509638579004672','220.019445807424574','76.36642014320374','76.366420143203740','test','test','1.99'),('2019-12-10 03:59:59','2019-12-11 23:59:59','LINKUSDT','4h','2.171400000000000','2.178600000000000','223.511817963097968','224.252945848026684','102.9344284623275','102.934428462327503','test','test','0.93'),('2019-12-27 15:59:59','2019-12-27 19:59:59','LINKUSDT','4h','1.925800000000000','1.889000000000000','223.676513048637702','219.402291592520839','116.14732217708885','116.147322177088853','test','test','1.91'),('2019-12-29 23:59:59','2019-12-30 03:59:59','LINKUSDT','4h','1.897600000000000','1.874300000000000','222.726686058389504','219.991899072111863','117.37283202908385','117.372832029083852','test','test','1.22'),('2019-12-30 07:59:59','2019-12-30 11:59:59','LINKUSDT','4h','1.890400000000000','1.873700000000000','222.118955616994441','220.156732511406290','117.49838955617564','117.498389556175638','test','test','0.88'),('2020-01-06 11:59:59','2020-01-23 07:59:59','LINKUSDT','4h','1.896400000000000','2.529300000000000','221.682906037974846','295.666828855647452','116.89670219256213','116.896702192562131','test','test','0.99'),('2020-01-24 15:59:59','2020-01-24 19:59:59','LINKUSDT','4h','2.519200000000000','2.519900000000000','238.123777775235453','238.189944274299705','94.52357009178924','94.523570091789239','test','test','0.0'),('2020-01-24 23:59:59','2020-01-25 03:59:59','LINKUSDT','4h','2.502400000000000','2.452352000000000','238.138481441694211','233.375711812860345','95.16403510297881','95.164035102978815','test','test','1.99'),('2020-01-26 15:59:59','2020-02-04 07:59:59','LINKUSDT','4h','2.507300000000000','2.741100000000000','237.080088190842190','259.187265081927762','94.5559319550282','94.555931955028200','test','test','0.0'),('2020-02-04 11:59:59','2020-02-04 15:59:59','LINKUSDT','4h','2.710700000000000','2.737300000000000','241.992794166639015','244.367460608824615','89.27317451825691','89.273174518256909','test','test','0.0'),('2020-02-04 19:59:59','2020-02-04 23:59:59','LINKUSDT','4h','2.712200000000000','2.739500000000000','242.520497820458019','244.961619268175156','89.41836804824791','89.418368048247913','test','test','0.0'),('2020-02-05 03:59:59','2020-02-16 15:59:59','LINKUSDT','4h','2.752000000000000','4.496100000000000','243.062969253284024','397.105892463550333','88.3222998740131','88.322299874013098','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:21:49
