-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-03-18 07:59:59','2018-03-18 15:59:59','IOTABTC','4h','0.000148070000000','0.000151180000000','0.033333333333333','0.034033452646271','225.1187501406992','225.118750140699206','test','test','0.0'),('2018-03-18 19:59:59','2018-03-18 23:59:59','IOTABTC','4h','0.000155520000000','0.000152409600000','0.033488915402875','0.032819137094817','215.33510418515374','215.335104185153739','test','test','1.99'),('2018-03-19 03:59:59','2018-03-19 07:59:59','IOTABTC','4h','0.000144990000000','0.000146980000000','0.033340075778862','0.033797671135783','229.9474155380524','229.947415538052411','test','test','0.0'),('2018-03-19 11:59:59','2018-03-22 11:59:59','IOTABTC','4h','0.000147760000000','0.000149090000000','0.033441763635956','0.033742775720660','226.32487571708026','226.324875717080261','test','test','0.0'),('2018-03-22 15:59:59','2018-03-22 19:59:59','IOTABTC','4h','0.000152700000000','0.000152010000000','0.033508655210334','0.033357240854767','219.4410950251109','219.441095025110911','test','test','0.45'),('2018-03-22 23:59:59','2018-03-23 07:59:59','IOTABTC','4h','0.000152230000000','0.000149185400000','0.033475007575764','0.032805507424249','219.89757324945148','219.897573249451483','test','test','1.99'),('2018-03-23 11:59:59','2018-03-23 15:59:59','IOTABTC','4h','0.000152740000000','0.000151500000000','0.033326229764316','0.033055675064121','218.1892743506365','218.189274350636509','test','test','0.81'),('2018-03-23 23:59:59','2018-03-25 11:59:59','IOTABTC','4h','0.000151200000000','0.000151820000000','0.033266106497606','0.033402515135361','220.013931862475','220.013931862475005','test','test','0.0'),('2018-03-25 15:59:59','2018-03-26 11:59:59','IOTABTC','4h','0.000152960000000','0.000150820000000','0.033296419528218','0.032830583114839','217.68056699933604','217.680566999336037','test','test','1.39'),('2018-03-28 07:59:59','2018-03-28 11:59:59','IOTABTC','4h','0.000152420000000','0.000153230000000','0.033192900325245','0.033369296134610','217.77260415460788','217.772604154607876','test','test','0.0'),('2018-03-28 19:59:59','2018-03-28 23:59:59','IOTABTC','4h','0.000152390000000','0.000149342200000','0.033232099393993','0.032567457406113','218.07270420626753','218.072704206267531','test','test','2.00'),('2018-03-29 23:59:59','2018-03-31 19:59:59','IOTABTC','4h','0.000153490000000','0.000154090000000','0.033084401174464','0.033213729734661','215.54760032877857','215.547600328778572','test','test','0.0'),('2018-03-31 23:59:59','2018-04-01 11:59:59','IOTABTC','4h','0.000154470000000','0.000154560000000','0.033113140854508','0.033132433808978','214.36616077237002','214.366160772370023','test','test','0.0'),('2018-04-09 03:59:59','2018-04-09 11:59:59','IOTABTC','4h','0.000148010000000','0.000146590000000','0.033117428177724','0.032799701348372','223.75128827595134','223.751288275951339','test','test','0.95'),('2018-04-10 15:59:59','2018-04-10 23:59:59','IOTABTC','4h','0.000148000000000','0.000147490000000','0.033046822215645','0.032932944652605','223.2893392949009','223.289339294900913','test','test','0.34'),('2018-04-11 03:59:59','2018-04-25 03:59:59','IOTABTC','4h','0.000150850000000','0.000198590000000','0.033021516090525','0.043471944848640','218.9029903249939','218.902990324993908','test','test','0.69'),('2018-04-25 07:59:59','2018-04-25 11:59:59','IOTABTC','4h','0.000211880000000','0.000207642400000','0.035343833592329','0.034636956920482','166.81061729435842','166.810617294358423','test','test','1.99'),('2018-04-26 11:59:59','2018-04-27 23:59:59','IOTABTC','4h','0.000212220000000','0.000211480000000','0.035186749887474','0.035064055537664','165.80317541925257','165.803175419252568','test','test','0.34'),('2018-04-28 03:59:59','2018-04-29 11:59:59','IOTABTC','4h','0.000218200000000','0.000213836000000','0.035159484476405','0.034456294786877','161.13420933274466','161.134209332744661','test','test','2.00'),('2018-04-29 15:59:59','2018-04-30 03:59:59','IOTABTC','4h','0.000216630000000','0.000212297400000','0.035003220100954','0.034303155698935','161.58066796359796','161.580667963597961','test','test','2.0'),('2018-04-30 11:59:59','2018-04-30 15:59:59','IOTABTC','4h','0.000213450000000','0.000211920000000','0.034847650233839','0.034597863844250','163.25907816274952','163.259078162749518','test','test','0.71'),('2018-04-30 19:59:59','2018-04-30 23:59:59','IOTABTC','4h','0.000213530000000','0.000211410000000','0.034792142147264','0.034446713676547','162.93795788537236','162.937957885372356','test','test','0.99'),('2018-05-01 23:59:59','2018-05-07 03:59:59','IOTABTC','4h','0.000216090000000','0.000232870000000','0.034715380264882','0.037411127781402','160.65241457208572','160.652414572085718','test','test','0.0'),('2018-05-07 07:59:59','2018-05-07 11:59:59','IOTABTC','4h','0.000231160000000','0.000230360000000','0.035314435268553','0.035192218846097','152.77052806953242','152.770528069532418','test','test','0.34'),('2018-05-07 15:59:59','2018-05-10 23:59:59','IOTABTC','4h','0.000231550000000','0.000236200000000','0.035287276063563','0.035995917107379','152.39592340126492','152.395923401264923','test','test','0.0'),('2018-05-15 11:59:59','2018-05-15 15:59:59','IOTABTC','4h','0.000234900000000','0.000231260000000','0.035444751851078','0.034895501545680','150.8929410433272','150.892941043327198','test','test','1.54'),('2018-05-15 23:59:59','2018-05-16 03:59:59','IOTABTC','4h','0.000234560000000','0.000229868800000','0.035322696227656','0.034616242303103','150.59130383550382','150.591303835503822','test','test','2.00'),('2018-05-29 19:59:59','2018-05-29 23:59:59','IOTABTC','4h','0.000217120000000','0.000212777600000','0.035165706466644','0.034462392337311','161.96438129441782','161.964381294417819','test','test','2.00'),('2018-05-30 03:59:59','2018-05-30 15:59:59','IOTABTC','4h','0.000214020000000','0.000209739600000','0.035009414437903','0.034309226149145','163.58010670920166','163.580106709201658','test','test','2.00'),('2018-05-30 19:59:59','2018-06-04 07:59:59','IOTABTC','4h','0.000212790000000','0.000229150000000','0.034853817040402','0.037533493936783','163.79443131914826','163.794431319148259','test','test','0.07'),('2018-06-04 11:59:59','2018-06-05 03:59:59','IOTABTC','4h','0.000229650000000','0.000225610000000','0.035449300795153','0.034825677127779','154.36229390443233','154.362293904432335','test','test','1.75'),('2018-06-05 11:59:59','2018-06-05 23:59:59','IOTABTC','4h','0.000229600000000','0.000228690000000','0.035310717757959','0.035170766742455','153.79232472978512','153.792324729785122','test','test','1.00'),('2018-06-06 03:59:59','2018-06-06 11:59:59','IOTABTC','4h','0.000230300000000','0.000226480000000','0.035279617532291','0.034694432386944','153.18982862479857','153.189828624798565','test','test','1.65'),('2018-06-09 03:59:59','2018-06-09 07:59:59','IOTABTC','4h','0.000225900000000','0.000225250000000','0.035149576388881','0.035048437722866','155.5979477152752','155.597947715275211','test','test','0.28'),('2018-07-01 23:59:59','2018-07-02 07:59:59','IOTABTC','4h','0.000167900000000','0.000165910000000','0.035127101129766','0.034710764433827','209.2144200700788','209.214420070078802','test','test','1.18'),('2018-07-02 11:59:59','2018-07-05 19:59:59','IOTABTC','4h','0.000168110000000','0.000174070000000','0.035034581864002','0.036276662096644','208.40272359765635','208.402723597656347','test','test','0.0'),('2018-07-05 23:59:59','2018-07-06 07:59:59','IOTABTC','4h','0.000176420000000','0.000172891600000','0.035310599693478','0.034604387699608','200.15077481849','200.150774818489992','test','test','2.00'),('2018-07-16 11:59:59','2018-07-17 07:59:59','IOTABTC','4h','0.000162310000000','0.000160530000000','0.035153663694840','0.034768145110792','216.58347418421675','216.583474184216755','test','test','1.09'),('2018-07-17 11:59:59','2018-07-17 15:59:59','IOTABTC','4h','0.000158630000000','0.000159990000000','0.035067992898385','0.035368645173124','221.06784907259106','221.067849072591059','test','test','0.0'),('2018-08-03 23:59:59','2018-08-04 03:59:59','IOTABTC','4h','0.000129550000000','0.000126959000000','0.035134804514994','0.034432108424694','271.2065188343788','271.206518834378812','test','test','2.00'),('2018-08-05 07:59:59','2018-08-06 03:59:59','IOTABTC','4h','0.000130990000000','0.000128370200000','0.034978649828260','0.034279076831695','267.0329783056756','267.032978305675613','test','test','2.00'),('2018-08-06 07:59:59','2018-08-06 19:59:59','IOTABTC','4h','0.000128010000000','0.000125449800000','0.034823189162357','0.034126725379110','272.03491260336784','272.034912603367843','test','test','1.99'),('2018-08-26 23:59:59','2018-09-03 11:59:59','IOTABTC','4h','0.000085530000000','0.000095620000000','0.034668419432747','0.038758263371440','405.33636657017024','405.336366570170242','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','IOTABTC','4h','0.000096610000000','0.000096200000000','0.035577273641345','0.035426288420426','368.2566363869694','368.256636386969376','test','test','0.42'),('2018-09-03 23:59:59','2018-09-04 03:59:59','IOTABTC','4h','0.000096040000000','0.000096650000000','0.035543721370030','0.035769478034292','370.09289223271327','370.092892232713268','test','test','0.0'),('2018-09-04 07:59:59','2018-09-04 23:59:59','IOTABTC','4h','0.000097410000000','0.000095660000000','0.035593889517644','0.034954434567887','365.4028284328462','365.402828432846206','test','test','1.79'),('2018-09-05 03:59:59','2018-09-05 07:59:59','IOTABTC','4h','0.000095670000000','0.000096010000000','0.035451788417698','0.035577779930837','370.56327393851325','370.563273938513248','test','test','0.0'),('2018-09-10 03:59:59','2018-09-10 07:59:59','IOTABTC','4h','0.000093110000000','0.000092130000000','0.035479786531728','0.035106355205328','381.0523738774401','381.052373877440118','test','test','1.05'),('2018-09-14 03:59:59','2018-09-14 11:59:59','IOTABTC','4h','0.000091590000000','0.000089758200000','0.035396801792528','0.034688865756677','386.47015823265036','386.470158232650363','test','test','2.00'),('2018-09-14 19:59:59','2018-09-14 23:59:59','IOTABTC','4h','0.000090750000000','0.000088935000000','0.035239482673450','0.034534693019981','388.31385866061095','388.313858660610947','test','test','1.99'),('2018-09-21 19:59:59','2018-09-22 11:59:59','IOTABTC','4h','0.000089740000000','0.000088000000000','0.035082862750457','0.034402628950749','390.9389653494243','390.938965349424279','test','test','1.93'),('2018-09-22 15:59:59','2018-09-24 07:59:59','IOTABTC','4h','0.000088840000000','0.000087063200000','0.034931699683856','0.034233065690179','393.19788027752764','393.197880277527645','test','test','2.00'),('2018-09-25 23:59:59','2018-09-26 03:59:59','IOTABTC','4h','0.000088490000000','0.000086720200000','0.034776447685261','0.034080918731556','392.9986177563642','392.998617756364183','test','test','2.00'),('2018-09-27 19:59:59','2018-09-27 23:59:59','IOTABTC','4h','0.000088470000000','0.000087550000000','0.034621885695548','0.034261852522270','391.34040573695546','391.340405736955461','test','test','1.03'),('2018-10-05 23:59:59','2018-10-06 15:59:59','IOTABTC','4h','0.000086740000000','0.000085860000000','0.034541878323709','0.034191441928449','398.2231764319678','398.223176431967772','test','test','1.01'),('2018-10-06 19:59:59','2018-10-06 23:59:59','IOTABTC','4h','0.000085920000000','0.000085840000000','0.034464003569207','0.034431914180409','401.1173599768001','401.117359976800117','test','test','0.09'),('2018-10-07 03:59:59','2018-10-07 07:59:59','IOTABTC','4h','0.000086230000000','0.000085610000000','0.034456872593918','0.034209125162534','399.5926312642725','399.592631264272484','test','test','0.71'),('2018-10-07 15:59:59','2018-10-10 07:59:59','IOTABTC','4h','0.000086200000000','0.000087690000000','0.034401817609166','0.034996466196610','399.09301170726485','399.093011707264850','test','test','0.08'),('2018-10-10 11:59:59','2018-10-11 03:59:59','IOTABTC','4h','0.000088030000000','0.000086269400000','0.034533961739709','0.033843282504915','392.2976455720701','392.297645572070110','test','test','1.99'),('2018-11-02 11:59:59','2018-11-03 07:59:59','IOTABTC','4h','0.000075350000000','0.000074500000000','0.034380477465311','0.033992641953094','456.2770731958947','456.277073195894673','test','test','1.12'),('2018-11-03 11:59:59','2018-11-03 19:59:59','IOTABTC','4h','0.000074970000000','0.000074620000000','0.034294291795929','0.034134187725920','457.4402000257318','457.440200025731826','test','test','0.46'),('2018-11-03 23:59:59','2018-11-04 03:59:59','IOTABTC','4h','0.000074980000000','0.000074510000000','0.034258713113705','0.034043967912806','456.90468276480243','456.904682764802430','test','test','0.62'),('2018-11-04 07:59:59','2018-11-04 11:59:59','IOTABTC','4h','0.000074940000000','0.000075190000000','0.034210991957950','0.034325119900164','456.51176885441095','456.511768854410946','test','test','0.0'),('2018-11-04 15:59:59','2018-11-08 07:59:59','IOTABTC','4h','0.000075850000000','0.000076000000000','0.034236353722886','0.034304059102694','451.3691987196573','451.369198719657277','test','test','0.0'),('2018-11-08 11:59:59','2018-11-08 15:59:59','IOTABTC','4h','0.000076400000000','0.000075710000000','0.034251399362843','0.033942060808388','448.31674558695465','448.316745586954653','test','test','0.90'),('2018-11-10 15:59:59','2018-11-10 19:59:59','IOTABTC','4h','0.000076490000000','0.000076390000000','0.034182657461853','0.034137968407778','446.8905407485074','446.890540748507419','test','test','0.13'),('2018-11-10 23:59:59','2018-11-11 03:59:59','IOTABTC','4h','0.000075540000000','0.000075300000000','0.034172726560948','0.034064155547252','452.37922373507786','452.379223735077858','test','test','0.31'),('2018-11-12 07:59:59','2018-11-14 11:59:59','IOTABTC','4h','0.000076300000000','0.000076150000000','0.034148599669015','0.034081466117896','447.55700745760595','447.557007457605948','test','test','0.19'),('2018-11-23 23:59:59','2018-11-24 19:59:59','IOTABTC','4h','0.000072690000000','0.000071900000000','0.034133681102100','0.033762713870422','469.57877427569133','469.578774275691330','test','test','1.08'),('2018-12-02 03:59:59','2018-12-02 07:59:59','IOTABTC','4h','0.000071490000000','0.000071250000000','0.034051243939505','0.033936930069796','476.3077904532787','476.307790453278699','test','test','0.33'),('2018-12-15 15:59:59','2019-01-06 07:59:59','IOTABTC','4h','0.000067190000000','0.000093400000000','0.034025840857347','0.047298906624144','506.41227648976536','506.412276489765361','test','test','0.0'),('2019-01-06 11:59:59','2019-01-06 19:59:59','IOTABTC','4h','0.000094670000000','0.000093610000000','0.036975411027747','0.036561405157995','390.57157523763254','390.571575237632544','test','test','1.11'),('2019-01-06 23:59:59','2019-01-07 03:59:59','IOTABTC','4h','0.000092840000000','0.000092350000000','0.036883409723357','0.036688742868936','397.27929473672265','397.279294736722647','test','test','0.52'),('2019-01-19 11:59:59','2019-01-19 19:59:59','IOTABTC','4h','0.000085130000000','0.000084920000000','0.036840150422375','0.036749272569812','432.751678872018','432.751678872017976','test','test','0.24'),('2019-01-21 15:59:59','2019-01-21 23:59:59','IOTABTC','4h','0.000085310000000','0.000085160000000','0.036819955344028','0.036755215063854','431.60186782355595','431.601867823555949','test','test','0.17'),('2019-02-08 11:59:59','2019-02-09 19:59:59','IOTABTC','4h','0.000075090000000','0.000075110000000','0.036805568615100','0.036815371669732','490.1527315900919','490.152731590091889','test','test','0.06'),('2019-02-09 23:59:59','2019-02-10 15:59:59','IOTABTC','4h','0.000075400000000','0.000075220000000','0.036807747071685','0.036719877118463','488.1664067862717','488.166406786271693','test','test','0.23'),('2019-02-10 19:59:59','2019-02-11 11:59:59','IOTABTC','4h','0.000075530000000','0.000074040000000','0.036788220415413','0.036062489600916','487.06766073630786','487.067660736307857','test','test','1.97'),('2019-02-12 19:59:59','2019-02-12 23:59:59','IOTABTC','4h','0.000075220000000','0.000075310000000','0.036626946901081','0.036670770687589','486.93096119490383','486.930961194903830','test','test','0.0'),('2019-02-13 03:59:59','2019-02-13 07:59:59','IOTABTC','4h','0.000075010000000','0.000075150000000','0.036636685520305','0.036705064882695','488.4240170684531','488.424017068453111','test','test','0.0'),('2019-02-13 11:59:59','2019-02-13 15:59:59','IOTABTC','4h','0.000074760000000','0.000074230000000','0.036651880934169','0.036392042826958','490.2605796437817','490.260579643781682','test','test','0.70'),('2019-02-15 11:59:59','2019-02-16 03:59:59','IOTABTC','4h','0.000075640000000','0.000074650000000','0.036594139132567','0.036115183583370','483.79348403710566','483.793484037105657','test','test','1.30'),('2019-02-16 07:59:59','2019-02-16 11:59:59','IOTABTC','4h','0.000074960000000','0.000075710000000','0.036487704566078','0.036852776316672','486.7623341259132','486.762334125913185','test','test','0.0'),('2019-02-16 15:59:59','2019-02-16 19:59:59','IOTABTC','4h','0.000074990000000','0.000075140000000','0.036568831621766','0.036641979037998','487.6494415490866','487.649441549086589','test','test','0.0'),('2019-02-16 23:59:59','2019-02-18 03:59:59','IOTABTC','4h','0.000075730000000','0.000074720000000','0.036585086603151','0.036097156622045','483.0989911943865','483.098991194386485','test','test','1.33'),('2019-02-18 07:59:59','2019-02-21 19:59:59','IOTABTC','4h','0.000075440000000','0.000076050000000','0.036476657718461','0.036771604181985','483.5187926625221','483.518792662522117','test','test','0.0'),('2019-02-22 03:59:59','2019-02-22 07:59:59','IOTABTC','4h','0.000076950000000','0.000076410000000','0.036542201377022','0.036285764876131','474.8824090581099','474.882409058109886','test','test','0.70'),('2019-02-22 11:59:59','2019-02-22 15:59:59','IOTABTC','4h','0.000076480000000','0.000077120000000','0.036485215487935','0.036790531098713','477.05564184015003','477.055641840150031','test','test','0.0'),('2019-02-22 19:59:59','2019-02-23 03:59:59','IOTABTC','4h','0.000077260000000','0.000076870000000','0.036553063401441','0.036368547549428','473.11756926534935','473.117569265349346','test','test','0.50'),('2019-02-23 19:59:59','2019-02-24 07:59:59','IOTABTC','4h','0.000077130000000','0.000076770000000','0.036512059878771','0.036341641863001','473.383377139522','473.383377139521997','test','test','0.46'),('2019-02-24 11:59:59','2019-02-24 15:59:59','IOTABTC','4h','0.000077510000000','0.000075959800000','0.036474189208600','0.035744705424428','470.5739802425522','470.573980242552182','test','test','1.99'),('2019-03-01 07:59:59','2019-03-02 07:59:59','IOTABTC','4h','0.000076390000000','0.000075390000000','0.036312081701006','0.035836730454756','475.3512462495933','475.351246249593316','test','test','1.30'),('2019-03-02 11:59:59','2019-03-02 15:59:59','IOTABTC','4h','0.000075720000000','0.000075360000000','0.036206448090729','0.036034309668745','478.16228329013035','478.162283290130347','test','test','0.47'),('2019-03-02 23:59:59','2019-03-03 11:59:59','IOTABTC','4h','0.000076280000000','0.000075630000000','0.036168195108066','0.035859997325944','474.15043403337114','474.150434033371141','test','test','0.85'),('2019-03-13 03:59:59','2019-03-13 11:59:59','IOTABTC','4h','0.000073980000000','0.000072570000000','0.036099706712038','0.035411674994493','487.9657571240665','487.965757124066499','test','test','1.90'),('2019-03-13 15:59:59','2019-03-17 11:59:59','IOTABTC','4h','0.000073190000000','0.000074870000000','0.035946810774806','0.036771932268202','491.1437460692202','491.143746069220185','test','test','0.0'),('2019-03-17 15:59:59','2019-03-17 19:59:59','IOTABTC','4h','0.000074460000000','0.000074420000000','0.036130171106672','0.036110761936053','485.229265466989','485.229265466988977','test','test','0.05');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:55:07
