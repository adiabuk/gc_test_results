-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-30 11:59:59','2018-05-31 03:59:59','LTCETH','4h','0.212700000000000','0.208446000000000','1.297777777777778','1.271822222222222','6.101447004126834','6.101447004126834','test','test','2.00'),('2018-05-31 07:59:59','2018-05-31 19:59:59','LTCETH','4h','0.209700000000000','0.206900000000000','1.292009876543210','1.274758433270339','6.161229740310967','6.161229740310967','test','test','1.41'),('2018-06-01 19:59:59','2018-06-01 23:59:59','LTCETH','4h','0.207230000000000','0.207420000000000','1.288176222482572','1.289357294153043','6.216166686689049','6.216166686689049','test','test','0.0'),('2018-06-02 03:59:59','2018-06-02 15:59:59','LTCETH','4h','0.207000000000000','0.207430000000000','1.288438682853787','1.291115149682904','6.2243414630617755','6.224341463061775','test','test','0.0'),('2018-06-02 19:59:59','2018-06-03 03:59:59','LTCETH','4h','0.207510000000000','0.206420000000000','1.289033453260258','1.282262471312141','6.2119100441436945','6.211910044143695','test','test','0.52'),('2018-06-03 07:59:59','2018-06-03 11:59:59','LTCETH','4h','0.206290000000000','0.204620000000000','1.287528790605121','1.277105730445586','6.241353388943336','6.241353388943336','test','test','0.80'),('2018-06-11 03:59:59','2018-06-11 07:59:59','LTCETH','4h','0.202240000000000','0.201430000000000','1.285212555014113','1.280065095710506','6.354888029144151','6.354888029144151','test','test','0.40'),('2018-06-11 19:59:59','2018-06-11 23:59:59','LTCETH','4h','0.203090000000000','0.201590000000000','1.284068675168867','1.274584687711320','6.322658305031598','6.322658305031598','test','test','0.73'),('2018-06-12 19:59:59','2018-06-12 23:59:59','LTCETH','4h','0.202240000000000','0.202100000000000','1.281961122400523','1.281073688870380','6.338810929591195','6.338810929591195','test','test','0.06'),('2018-06-14 15:59:59','2018-06-14 19:59:59','LTCETH','4h','0.203520000000000','0.199449600000000','1.281763914949380','1.256128636650392','6.2979752110327265','6.297975211032727','test','test','2.00'),('2018-06-27 19:59:59','2018-06-27 23:59:59','LTCETH','4h','0.184770000000000','0.182540000000000','1.276067186438494','1.260666256494467','6.906246611671237','6.906246611671237','test','test','1.20'),('2018-07-03 03:59:59','2018-07-05 03:59:59','LTCETH','4h','0.182600000000000','0.180830000000000','1.272644757562044','1.260308606297615','6.96957698555336','6.969576985553360','test','test','0.96'),('2018-07-11 11:59:59','2018-07-11 15:59:59','LTCETH','4h','0.179540000000000','0.176820000000000','1.269903390614393','1.250664573512515','7.073094522749208','7.073094522749208','test','test','1.51'),('2018-07-11 19:59:59','2018-07-11 23:59:59','LTCETH','4h','0.176710000000000','0.175760000000000','1.265628097925087','1.258824030848924','7.162175869645671','7.162175869645671','test','test','0.53'),('2018-07-12 19:59:59','2018-07-13 11:59:59','LTCETH','4h','0.177020000000000','0.176210000000000','1.264116083019273','1.258331798603695','7.141091871083903','7.141091871083903','test','test','0.45'),('2018-07-13 15:59:59','2018-07-13 19:59:59','LTCETH','4h','0.176740000000000','0.176620000000000','1.262830686482478','1.261973270603911','7.145132321390051','7.145132321390051','test','test','0.06'),('2018-07-13 23:59:59','2018-07-14 03:59:59','LTCETH','4h','0.177240000000000','0.176370000000000','1.262640149620574','1.256442356062856','7.1239006410549175','7.123900641054917','test','test','0.49'),('2018-07-14 07:59:59','2018-07-14 11:59:59','LTCETH','4h','0.176520000000000','0.175470000000000','1.261262862163303','1.253760448809170','7.145155575364283','7.145155575364283','test','test','0.59'),('2018-07-15 03:59:59','2018-07-15 07:59:59','LTCETH','4h','0.177350000000000','0.176580000000000','1.259595659195718','1.254126876237834','7.1023155297193','7.102315529719300','test','test','0.43'),('2018-07-17 19:59:59','2018-07-21 03:59:59','LTCETH','4h','0.178010000000000','0.177600000000000','1.258380374093966','1.255482020330815','7.069155519880715','7.069155519880715','test','test','0.23'),('2018-07-21 07:59:59','2018-07-21 11:59:59','LTCETH','4h','0.178450000000000','0.180170000000000','1.257736295479932','1.269859054954438','7.048115973549635','7.048115973549635','test','test','0.0'),('2018-07-21 15:59:59','2018-07-22 07:59:59','LTCETH','4h','0.181300000000000','0.179190000000000','1.260430242029823','1.245761142136371','6.952180044290252','6.952180044290252','test','test','1.16'),('2018-07-22 11:59:59','2018-07-22 15:59:59','LTCETH','4h','0.179150000000000','0.177460000000000','1.257170442053500','1.245311005564131','7.017418041046608','7.017418041046608','test','test','0.94'),('2018-07-22 19:59:59','2018-07-26 07:59:59','LTCETH','4h','0.179990000000000','0.180880000000000','1.254535011722529','1.260738335020673','6.970026177690588','6.970026177690588','test','test','0.18'),('2018-07-26 11:59:59','2018-07-26 19:59:59','LTCETH','4h','0.182790000000000','0.181230000000000','1.255913528011006','1.245195080045050','6.870799978177174','6.870799978177174','test','test','0.85'),('2018-07-26 23:59:59','2018-07-27 03:59:59','LTCETH','4h','0.180680000000000','0.179780000000000','1.253531650685237','1.247287581138985','6.93785505139051','6.937855051390510','test','test','0.49'),('2018-07-30 03:59:59','2018-07-30 07:59:59','LTCETH','4h','0.180970000000000','0.179630000000000','1.252144079674959','1.242872526009907','6.9190698992924755','6.919069899292476','test','test','0.74'),('2018-07-31 03:59:59','2018-07-31 07:59:59','LTCETH','4h','0.180800000000000','0.180590000000000','1.250083734416059','1.248631756627191','6.914179946991477','6.914179946991477','test','test','0.11'),('2018-07-31 11:59:59','2018-07-31 15:59:59','LTCETH','4h','0.180830000000000','0.180100000000000','1.249761072685199','1.244715861254241','6.911248535559362','6.911248535559362','test','test','0.40'),('2018-07-31 23:59:59','2018-08-01 03:59:59','LTCETH','4h','0.182380000000000','0.184150000000000','1.248639914589431','1.260757979337886','6.846364264664059','6.846364264664059','test','test','0.0'),('2018-08-01 07:59:59','2018-08-04 19:59:59','LTCETH','4h','0.183320000000000','0.179653600000000','1.251332817866865','1.226306161509528','6.825948166413186','6.825948166413186','test','test','2.00'),('2018-08-05 15:59:59','2018-08-05 19:59:59','LTCETH','4h','0.182610000000000','0.183130000000000','1.245771338676346','1.249318795530361','6.822032411567526','6.822032411567526','test','test','0.0'),('2018-08-05 23:59:59','2018-08-06 03:59:59','LTCETH','4h','0.182480000000000','0.184350000000000','1.246559662421683','1.259334029852243','6.831212529711106','6.831212529711106','test','test','0.0'),('2018-08-06 07:59:59','2018-08-06 11:59:59','LTCETH','4h','0.183730000000000','0.181220000000000','1.249398410739585','1.232329940642397','6.80018728971635','6.800187289716350','test','test','1.36'),('2018-08-07 07:59:59','2018-08-07 11:59:59','LTCETH','4h','0.183030000000000','0.182510000000000','1.245605417384654','1.242066572293467','6.805471329206438','6.805471329206438','test','test','0.28'),('2018-08-07 15:59:59','2018-08-07 19:59:59','LTCETH','4h','0.182230000000000','0.183210000000000','1.244819007364390','1.251513418971793','6.831032252452342','6.831032252452342','test','test','0.0'),('2018-08-11 15:59:59','2018-08-18 15:59:59','LTCETH','4h','0.180270000000000','0.195540000000000','1.246306654388258','1.351876647246241','6.913555524425903','6.913555524425903','test','test','0.0'),('2018-08-18 19:59:59','2018-08-19 15:59:59','LTCETH','4h','0.193820000000000','0.193950000000000','1.269766652801143','1.270618317566720','6.551267427515958','6.551267427515958','test','test','1.80'),('2018-08-19 19:59:59','2018-08-20 11:59:59','LTCETH','4h','0.193370000000000','0.193620000000000','1.269955911637938','1.271597784616733','6.567491915177834','6.567491915177834','test','test','0.95'),('2018-08-20 15:59:59','2018-09-13 23:59:59','LTCETH','4h','0.195860000000000','0.258530000000000','1.270320772299892','1.676789692957679','6.4858611880929855','6.485861188092986','test','test','0.18'),('2018-09-14 15:59:59','2018-09-14 19:59:59','LTCETH','4h','0.262000000000000','0.264460000000000','1.360647199112734','1.373422741516617','5.19330992027761','5.193309920277610','test','test','0.0'),('2018-09-14 23:59:59','2018-09-15 15:59:59','LTCETH','4h','0.269300000000000','0.263914000000000','1.363486208535819','1.336216484365103','5.063075412312733','5.063075412312733','test','test','2.00'),('2018-09-17 19:59:59','2018-09-18 03:59:59','LTCETH','4h','0.264870000000000','0.259572600000000','1.357426269831215','1.330277744434591','5.124877373168783','5.124877373168783','test','test','2.00'),('2018-09-18 07:59:59','2018-09-18 11:59:59','LTCETH','4h','0.259850000000000','0.262600000000000','1.351393264187521','1.365695097847385','5.200666785405122','5.200666785405122','test','test','0.0'),('2018-09-25 03:59:59','2018-09-29 11:59:59','LTCETH','4h','0.258220000000000','0.266050000000000','1.354571449445269','1.395646092963031','5.245803769829094','5.245803769829094','test','test','0.0'),('2018-09-29 15:59:59','2018-09-29 19:59:59','LTCETH','4h','0.265670000000000','0.263840000000000','1.363699148004771','1.354305654419313','5.133056604075625','5.133056604075625','test','test','0.68'),('2018-09-29 23:59:59','2018-09-30 03:59:59','LTCETH','4h','0.266250000000000','0.264200000000000','1.361611704985781','1.351127934111712','5.114034572716548','5.114034572716548','test','test','0.76'),('2018-10-01 11:59:59','2018-10-01 15:59:59','LTCETH','4h','0.265600000000000','0.263220000000000','1.359281978124876','1.347101665218486','5.117778532096673','5.117778532096673','test','test','0.89'),('2018-10-02 03:59:59','2018-10-02 11:59:59','LTCETH','4h','0.265280000000000','0.262000000000000','1.356575241923456','1.339802146350820','5.11374865019397','5.113748650193970','test','test','1.23'),('2018-10-02 23:59:59','2018-10-03 03:59:59','LTCETH','4h','0.264180000000000','0.260650000000000','1.352847887351760','1.334770996435144','5.1209322709961365','5.120932270996136','test','test','1.33'),('2018-10-11 11:59:59','2018-10-11 15:59:59','LTCETH','4h','0.261990000000000','0.262340000000000','1.348830800481400','1.350632742464562','5.14840566617581','5.148405666175810','test','test','0.0'),('2018-10-11 19:59:59','2018-10-15 07:59:59','LTCETH','4h','0.260360000000000','0.261250000000000','1.349231232033214','1.353843368292661','5.1821755724121','5.182175572412100','test','test','0.0'),('2018-10-15 19:59:59','2018-10-15 23:59:59','LTCETH','4h','0.268080000000000','0.262718400000000','1.350256151201980','1.323251028177940','5.036765708751046','5.036765708751046','test','test','2.00'),('2018-10-19 15:59:59','2018-10-19 19:59:59','LTCETH','4h','0.262500000000000','0.263360000000000','1.344255012752194','1.348659048222544','5.120971477151213','5.120971477151213','test','test','0.0'),('2018-10-19 23:59:59','2018-10-20 03:59:59','LTCETH','4h','0.261930000000000','0.261310000000000','1.345233687301160','1.342049459125210','5.135851896694384','5.135851896694384','test','test','0.23'),('2018-10-23 15:59:59','2018-10-23 19:59:59','LTCETH','4h','0.261240000000000','0.258220000000000','1.344526081039838','1.328983021918952','5.1467083181742375','5.146708318174237','test','test','1.15'),('2018-11-02 15:59:59','2018-11-02 23:59:59','LTCETH','4h','0.257180000000000','0.255880000000000','1.341072067901863','1.334293182730884','5.214527054599359','5.214527054599359','test','test','0.55'),('2018-11-03 03:59:59','2018-11-03 07:59:59','LTCETH','4h','0.255860000000000','0.255760000000000','1.339565648974979','1.339042094824672','5.235541503068003','5.235541503068003','test','test','0.03'),('2018-11-03 11:59:59','2018-11-03 15:59:59','LTCETH','4h','0.255890000000000','0.255230000000000','1.339449303608244','1.335994551408543','5.234473029849718','5.234473029849718','test','test','0.25'),('2018-11-03 19:59:59','2018-11-03 23:59:59','LTCETH','4h','0.256760000000000','0.255020000000000','1.338681580897199','1.329609661786897','5.213746615116059','5.213746615116059','test','test','0.67'),('2018-11-04 03:59:59','2018-11-04 07:59:59','LTCETH','4h','0.256280000000000','0.257430000000000','1.336665598872688','1.342663591063665','5.2156453834582805','5.215645383458281','test','test','0.0'),('2018-11-04 11:59:59','2018-11-04 19:59:59','LTCETH','4h','0.263280000000000','0.258014400000000','1.337998486026238','1.311238516305713','5.082036182111206','5.082036182111206','test','test','1.99'),('2018-11-04 23:59:59','2018-11-05 03:59:59','LTCETH','4h','0.257270000000000','0.256190000000000','1.332051826088344','1.326459973279329','5.177641489829144','5.177641489829144','test','test','0.41'),('2018-11-05 07:59:59','2018-11-05 11:59:59','LTCETH','4h','0.257530000000000','0.256240000000000','1.330809192130785','1.324143002336009','5.167588988198599','5.167588988198599','test','test','0.50'),('2018-11-05 19:59:59','2018-11-05 23:59:59','LTCETH','4h','0.256780000000000','0.255820000000000','1.329327816620835','1.324357979780131','5.176913375733448','5.176913375733448','test','test','0.37'),('2018-11-06 03:59:59','2018-11-06 11:59:59','LTCETH','4h','0.258360000000000','0.255660000000000','1.328223408434012','1.314342764360735','5.140979286398869','5.140979286398869','test','test','1.04'),('2018-11-20 03:59:59','2018-11-20 11:59:59','LTCETH','4h','0.251000000000000','0.245980000000000','1.325138820862172','1.298636044444929','5.279437533315428','5.279437533315428','test','test','1.99'),('2018-11-20 15:59:59','2018-11-20 19:59:59','LTCETH','4h','0.246030000000000','0.247730000000000','1.319249314991674','1.328364966885694','5.362148172953193','5.362148172953193','test','test','0.0'),('2018-11-20 23:59:59','2018-12-07 19:59:59','LTCETH','4h','0.252840000000000','0.263770000000000','1.321275015412567','1.378392306657858','5.225735704052235','5.225735704052235','test','test','1.83'),('2018-12-14 23:59:59','2018-12-19 19:59:59','LTCETH','4h','0.278400000000000','0.289990000000000','1.333967746800410','1.389501820742281','4.791550814656644','4.791550814656644','test','test','0.0'),('2018-12-19 23:59:59','2018-12-20 03:59:59','LTCETH','4h','0.292510000000000','0.290620000000000','1.346308652120825','1.337609724383283','4.60260726854065','4.602607268540650','test','test','0.64'),('2018-12-20 07:59:59','2018-12-20 11:59:59','LTCETH','4h','0.289160000000000','0.289960000000000','1.344375557068038','1.348094952716311','4.649244560340429','4.649244560340429','test','test','0.0'),('2019-01-06 07:59:59','2019-01-14 15:59:59','LTCETH','4h','0.232610000000000','0.251430000000000','1.345202089434321','1.454039642949449','5.7830793578707755','5.783079357870776','test','test','0.0'),('2019-01-15 19:59:59','2019-01-16 15:59:59','LTCETH','4h','0.253570000000000','0.256340000000000','1.369388212437683','1.384347416398926','5.400434643048007','5.400434643048007','test','test','0.0'),('2019-01-16 19:59:59','2019-01-17 11:59:59','LTCETH','4h','0.257580000000000','0.254460000000000','1.372712479984626','1.356085168323969','5.329266557902889','5.329266557902889','test','test','1.49'),('2019-01-17 15:59:59','2019-02-13 15:59:59','LTCETH','4h','0.255040000000000','0.338760000000000','1.369017521837813','1.818414271086016','5.367854147732956','5.367854147732956','test','test','0.0'),('2019-02-13 19:59:59','2019-02-13 23:59:59','LTCETH','4h','0.341570000000000','0.341510000000000','1.468883466115192','1.468625442846266','4.300387815426389','4.300387815426389','test','test','0.01'),('2019-02-14 15:59:59','2019-02-17 11:59:59','LTCETH','4h','0.341340000000000','0.342220000000000','1.468826127610986','1.472612871011401','4.303117500471629','4.303117500471629','test','test','0.14'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LTCETH','4h','0.346600000000000','0.339668000000000','1.469667626144411','1.440274273621523','4.240241275661891','4.240241275661891','test','test','1.99'),('2019-02-27 23:59:59','2019-02-28 03:59:59','LTCETH','4h','0.335070000000000','0.334360000000000','1.463135770028214','1.460035443539062','4.366657026974107','4.366657026974107','test','test','0.21'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LTCETH','4h','0.333050000000000','0.335310000000000','1.462446808586180','1.472370633199315','4.391072837670561','4.391072837670561','test','test','0.0'),('2019-02-28 15:59:59','2019-03-20 11:59:59','LTCETH','4h','0.336440000000000','0.432480000000000','1.464652102944655','1.882750985261872','4.353382781312135','4.353382781312135','test','test','0.0'),('2019-03-20 15:59:59','2019-03-29 07:59:59','LTCETH','4h','0.434530000000000','0.433750000000000','1.557562965681814','1.554767073307912','3.5844774024389894','3.584477402438989','test','test','1.23'),('2019-03-29 11:59:59','2019-03-29 15:59:59','LTCETH','4h','0.435560000000000','0.432430000000000','1.556941656265391','1.545753238173485','3.5745744702575797','3.574574470257580','test','test','0.71'),('2019-04-02 07:59:59','2019-04-08 07:59:59','LTCETH','4h','0.448070000000000','0.493540000000000','1.554455341133857','1.712200970971508','3.469224320159477','3.469224320159477','test','test','0.39'),('2019-04-08 11:59:59','2019-04-08 15:59:59','LTCETH','4h','0.498490000000000','0.489790000000000','1.589509925542224','1.561768674258914','3.188649572794286','3.188649572794286','test','test','1.74'),('2019-04-08 23:59:59','2019-04-09 03:59:59','LTCETH','4h','0.495640000000000','0.490560000000000','1.583345203034821','1.567116905013239','3.194546854642122','3.194546854642122','test','test','1.02'),('2019-04-09 11:59:59','2019-04-09 15:59:59','LTCETH','4h','0.498480000000000','0.493150000000000','1.579738914585581','1.562847548001684','3.16911192943665','3.169111929436650','test','test','1.06'),('2019-04-10 19:59:59','2019-04-10 23:59:59','LTCETH','4h','0.496650000000000','0.498150000000000','1.575985277566937','1.580745124373240','3.1732312042020285','3.173231204202029','test','test','0.0'),('2019-04-11 03:59:59','2019-04-11 07:59:59','LTCETH','4h','0.499910000000000','0.493730000000000','1.577043021301671','1.557547260321406','3.154653880301797','3.154653880301797','test','test','1.23'),('2019-04-14 23:59:59','2019-04-15 11:59:59','LTCETH','4h','0.499060000000000','0.489078800000000','1.572710629972723','1.541256417373268','3.1513457900307045','3.151345790030704','test','test','2.00'),('2019-04-15 15:59:59','2019-04-15 19:59:59','LTCETH','4h','0.493240000000000','0.484090000000000','1.565720804950622','1.536675420623929','3.174358942808009','3.174358942808009','test','test','1.85'),('2019-04-15 23:59:59','2019-04-16 03:59:59','LTCETH','4h','0.488330000000000','0.485630000000000','1.559266275100246','1.550645017051855','3.1930585364410256','3.193058536441026','test','test','0.55'),('2019-04-26 03:59:59','2019-04-27 07:59:59','LTCETH','4h','0.471700000000000','0.464160000000000','1.557350439978381','1.532456604240757','3.3015697264752624','3.301569726475262','test','test','1.59'),('2019-04-27 11:59:59','2019-04-27 15:59:59','LTCETH','4h','0.462750000000000','0.460580000000000','1.551818476481132','1.544541445483911','3.3534705056318352','3.353470505631835','test','test','0.46'),('2019-04-30 19:59:59','2019-05-01 03:59:59','LTCETH','4h','0.458280000000000','0.454640000000000','1.550201358481749','1.537888508379467','3.382651127000413','3.382651127000413','test','test','0.79'),('2019-05-01 07:59:59','2019-05-01 11:59:59','LTCETH','4h','0.456280000000000','0.455070000000000','1.547465169570131','1.543361476979660','3.3914814797276476','3.391481479727648','test','test','0.26'),('2019-05-01 15:59:59','2019-05-01 19:59:59','LTCETH','4h','0.456830000000000','0.456850000000000','1.546553237883360','1.546620945925208','3.3854020924268537','3.385402092426854','test','test','0.0'),('2019-05-01 23:59:59','2019-05-02 03:59:59','LTCETH','4h','0.457610000000000','0.457490000000000','1.546568284114882','1.546162724371664','3.379664526812966','3.379664526812966','test','test','0.02'),('2019-05-02 07:59:59','2019-05-02 15:59:59','LTCETH','4h','0.458290000000000','0.456460000000000','1.546478159727499','1.540302910360720','3.374453205890374','3.374453205890374','test','test','0.39'),('2019-05-03 03:59:59','2019-05-03 11:59:59','LTCETH','4h','0.460070000000000','0.470640000000000','1.545105882090438','1.580604326183067','3.358414767514591','3.358414767514591','test','test','0.69'),('2019-05-03 15:59:59','2019-05-06 03:59:59','LTCETH','4h','0.468990000000000','0.459610200000000','1.552994425222133','1.521934536717690','3.3113593578160154','3.311359357816015','test','test','1.99'),('2019-05-11 11:59:59','2019-05-12 03:59:59','LTCETH','4h','0.457700000000000','0.457310000000000','1.546092227776701','1.544774823431425','3.377959859682546','3.377959859682546','test','test','0.72'),('2019-05-12 07:59:59','2019-05-13 07:59:59','LTCETH','4h','0.458300000000000','0.452100000000000','1.545799471255529','1.524887499355498','3.372898693553412','3.372898693553412','test','test','1.79'),('2019-05-13 11:59:59','2019-05-13 15:59:59','LTCETH','4h','0.453940000000000','0.449710000000000','1.541152366388855','1.526791273491501','3.395057422542308','3.395057422542308','test','test','0.93'),('2019-05-24 11:59:59','2019-05-30 19:59:59','LTCETH','4h','0.395420000000000','0.421150000000000','1.537961012411665','1.638036215611686','3.8894365798686596','3.889436579868660','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:58:28
