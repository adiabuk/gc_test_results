-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-09 19:59:59','2018-05-10 19:59:59','GXSETH','4h','0.005591000000000','0.005514000000000','1.297777777777778','1.279904608597150','232.11908026789087','232.119080267890865','test','test','1.37'),('2018-05-12 11:59:59','2018-05-12 15:59:59','GXSETH','4h','0.005687000000000','0.005573260000000','1.293805962404305','1.267929843156219','227.50236722424913','227.502367224249127','test','test','2.00'),('2018-05-28 07:59:59','2018-06-02 07:59:59','GXSETH','4h','0.005186000000000','0.005830000000000','1.288055713682508','1.448007098104323','248.3717149407073','248.371714940707307','test','test','0.44'),('2018-06-02 11:59:59','2018-06-14 19:59:59','GXSETH','4h','0.005822000000000','0.006392000000000','1.323600465776245','1.453186907805180','227.3446351384824','227.344635138482403','test','test','1.45'),('2018-06-15 19:59:59','2018-06-16 03:59:59','GXSETH','4h','0.006567000000000','0.006555000000000','1.352397452893786','1.349926192130161','205.93839696875068','205.938396968750681','test','test','0.18'),('2018-06-16 07:59:59','2018-06-16 11:59:59','GXSETH','4h','0.006530000000000','0.006490000000000','1.351848283835203','1.343567436767300','207.02117669758078','207.021176697580785','test','test','0.61'),('2018-07-02 19:59:59','2018-07-02 23:59:59','GXSETH','4h','0.005767000000000','0.005730000000000','1.350008095597891','1.341346694603072','234.09191877889552','234.091918778895518','test','test','0.64'),('2018-07-03 03:59:59','2018-07-03 07:59:59','GXSETH','4h','0.005772000000000','0.005668000000000','1.348083339821264','1.323793549914575','233.5556721797062','233.555672179706193','test','test','1.80'),('2018-07-11 15:59:59','2018-07-13 03:59:59','GXSETH','4h','0.005619000000000','0.005722000000000','1.342685608730889','1.367297927239393','238.95454862624825','238.954548626248254','test','test','1.58'),('2018-07-13 07:59:59','2018-07-24 11:59:59','GXSETH','4h','0.005777000000000','0.006489000000000','1.348155012843890','1.514311559346374','233.36593609899424','233.365936098994240','test','test','1.35'),('2018-07-24 15:59:59','2018-07-24 19:59:59','GXSETH','4h','0.006585000000000','0.006453300000000','1.385078689844442','1.357377116047553','210.33844948283095','210.338449482830953','test','test','2.00'),('2018-08-17 19:59:59','2018-08-17 23:59:59','GXSETH','4h','0.005360000000000','0.005307000000000','1.378922784556244','1.365287913738803','257.2617135366127','257.261713536612717','test','test','0.98'),('2018-08-18 03:59:59','2018-08-18 07:59:59','GXSETH','4h','0.005322000000000','0.005215560000000','1.375892813263480','1.348374956998210','258.5292772009545','258.529277200954482','test','test','2.00'),('2018-08-19 07:59:59','2018-08-19 11:59:59','GXSETH','4h','0.005217000000000','0.005215000000000','1.369777734093420','1.369252613244621','262.5604243997354','262.560424399735382','test','test','0.03'),('2018-08-20 19:59:59','2018-08-20 23:59:59','GXSETH','4h','0.005211000000000','0.005258000000000','1.369661040571464','1.382014536811506','262.8403455328083','262.840345532808328','test','test','0.0'),('2018-08-25 15:59:59','2018-08-25 19:59:59','GXSETH','4h','0.005110000000000','0.005067000000000','1.372406261958140','1.360857637835988','268.57265400355','268.572654003549985','test','test','0.84'),('2018-08-25 23:59:59','2018-08-26 03:59:59','GXSETH','4h','0.005079000000000','0.004977420000000','1.369839901042107','1.342443103021265','269.70661568066674','269.706615680666744','test','test','2.00'),('2018-08-26 15:59:59','2018-08-26 19:59:59','GXSETH','4h','0.005086000000000','0.005081000000000','1.363751723704142','1.362411031879816','268.13836486514776','268.138364865147764','test','test','0.09'),('2018-08-26 23:59:59','2018-08-27 03:59:59','GXSETH','4h','0.005127000000000','0.005046000000000','1.363453792187625','1.341912977448558','265.93598443292854','265.935984432928535','test','test','1.57'),('2018-08-27 07:59:59','2018-08-27 11:59:59','GXSETH','4h','0.005018000000000','0.005020000000000','1.358666944467832','1.359208461783284','270.7586577257536','270.758657725753608','test','test','0.0'),('2018-08-27 15:59:59','2018-08-27 19:59:59','GXSETH','4h','0.005066000000000','0.005113000000000','1.358787281649043','1.371393480274685','268.21699203494734','268.216992034947339','test','test','0.0'),('2018-08-27 23:59:59','2018-08-28 03:59:59','GXSETH','4h','0.005019000000000','0.005055000000000','1.361588659121408','1.371354985427120','271.28684182534533','271.286841825345334','test','test','0.0'),('2018-08-28 07:59:59','2018-08-28 15:59:59','GXSETH','4h','0.005039000000000','0.005188000000000','1.363758953856011','1.404084431951773','270.64079258900796','270.640792589007958','test','test','0.0'),('2018-08-28 19:59:59','2018-08-29 19:59:59','GXSETH','4h','0.005200000000000','0.005096000000000','1.372720171210625','1.345265767786412','263.9846483097355','263.984648309735519','test','test','1.99'),('2018-08-29 23:59:59','2018-08-30 07:59:59','GXSETH','4h','0.005061000000000','0.005043000000000','1.366619192671911','1.361758662051856','270.0294788919009','270.029478891900908','test','test','0.35'),('2018-08-31 07:59:59','2018-09-01 15:59:59','GXSETH','4h','0.005141000000000','0.005081000000000','1.365539074756343','1.349602030507096','265.6174041541224','265.617404154122426','test','test','1.36'),('2018-09-01 19:59:59','2018-09-01 23:59:59','GXSETH','4h','0.005101000000000','0.005140000000000','1.361997509367622','1.372410742628813','267.0059810561893','267.005981056189285','test','test','0.0'),('2018-09-02 03:59:59','2018-09-02 07:59:59','GXSETH','4h','0.005076000000000','0.005102000000000','1.364311561203442','1.371299760689512','268.77690331037076','268.776903310370756','test','test','0.0'),('2018-09-02 11:59:59','2018-09-02 15:59:59','GXSETH','4h','0.005066000000000','0.005001000000000','1.365864494422569','1.348339584802066','269.6139941615809','269.613994161580877','test','test','1.28'),('2018-09-03 07:59:59','2018-09-03 11:59:59','GXSETH','4h','0.005080000000000','0.005141000000000','1.361970070062457','1.378324435076986','268.1043445004836','268.104344500483592','test','test','0.0'),('2018-09-03 15:59:59','2018-09-03 19:59:59','GXSETH','4h','0.005190000000000','0.005119000000000','1.365604373399019','1.346922695073137','263.12222994200744','263.122229942007436','test','test','1.36'),('2018-09-03 23:59:59','2018-09-05 11:59:59','GXSETH','4h','0.005097000000000','0.005129000000000','1.361452889326600','1.370000366756157','267.10866967365126','267.108669673651264','test','test','0.0'),('2018-09-05 15:59:59','2018-09-06 03:59:59','GXSETH','4h','0.005151000000000','0.005070000000000','1.363352328755391','1.341913474430175','264.67721389155327','264.677213891553265','test','test','1.57'),('2018-09-06 15:59:59','2018-09-06 19:59:59','GXSETH','4h','0.005129000000000','0.005149000000000','1.358588138905343','1.363885811507821','264.8836301238727','264.883630123872706','test','test','0.0'),('2018-09-06 23:59:59','2018-09-13 03:59:59','GXSETH','4h','0.005215000000000','0.005515000000000','1.359765399483671','1.437987761870076','260.7412079546829','260.741207954682920','test','test','0.32'),('2018-09-13 07:59:59','2018-09-13 11:59:59','GXSETH','4h','0.005403000000000','0.005397000000000','1.377148146680650','1.375618831692665','254.88583133086252','254.885831330862516','test','test','0.11'),('2018-09-20 11:59:59','2018-09-20 15:59:59','GXSETH','4h','0.005099000000000','0.005202000000000','1.376808298905542','1.404619880546505','270.01535573750584','270.015355737505843','test','test','0.0'),('2018-09-20 19:59:59','2018-09-20 23:59:59','GXSETH','4h','0.005202000000000','0.005097960000000','1.382988650381312','1.355328877373686','265.85710311059444','265.857103110594437','test','test','1.99'),('2018-09-22 11:59:59','2018-09-22 15:59:59','GXSETH','4h','0.005267000000000','0.005161660000000','1.376842034157395','1.349305193474247','261.4091578047076','261.409157804707604','test','test','1.99'),('2018-09-22 19:59:59','2018-09-22 23:59:59','GXSETH','4h','0.005067000000000','0.005333000000000','1.370722736227807','1.442680945787032','270.5195848091191','270.519584809119124','test','test','0.0'),('2018-09-23 03:59:59','2018-09-23 11:59:59','GXSETH','4h','0.005206000000000','0.005187000000000','1.386713449463190','1.381652451472449','266.3683153021879','266.368315302187909','test','test','0.36'),('2018-09-23 15:59:59','2018-09-30 23:59:59','GXSETH','4h','0.005219000000000','0.005894000000000','1.385588783243025','1.564794077109483','265.4893242466038','265.489324246603815','test','test','0.21'),('2018-10-01 03:59:59','2018-10-01 11:59:59','GXSETH','4h','0.005902000000000','0.005825000000000','1.425412181880016','1.406815648839562','241.51341610979605','241.513416109796054','test','test','1.30'),('2018-10-01 15:59:59','2018-10-01 23:59:59','GXSETH','4h','0.005833000000000','0.005875000000000','1.421279618982138','1.431513417027269','243.66185821740743','243.661858217407428','test','test','0.0'),('2018-10-02 03:59:59','2018-10-02 07:59:59','GXSETH','4h','0.005822000000000','0.005802000000000','1.423553796325500','1.418663539381751','244.5128471874785','244.512847187478513','test','test','0.34'),('2018-10-02 23:59:59','2018-10-03 07:59:59','GXSETH','4h','0.005830000000000','0.005889000000000','1.422467072560222','1.436862536930900','243.99092153691632','243.990921536916318','test','test','0.49'),('2018-10-03 11:59:59','2018-10-03 15:59:59','GXSETH','4h','0.005809000000000','0.005761000000000','1.425666064642595','1.413885728766739','245.4236640803228','245.423664080322794','test','test','0.82'),('2018-10-03 23:59:59','2018-10-04 03:59:59','GXSETH','4h','0.005861000000000','0.005785000000000','1.423048212225738','1.404595445781589','242.79955847564207','242.799558475642073','test','test','1.29'),('2018-10-04 07:59:59','2018-10-04 15:59:59','GXSETH','4h','0.006218000000000','0.006093640000000','1.418947597460372','1.390568645511165','228.19999959156834','228.199999591568343','test','test','2.00'),('2018-10-04 19:59:59','2018-10-06 15:59:59','GXSETH','4h','0.006061000000000','0.005972000000000','1.412641163693881','1.391897876518703','233.07064241773327','233.070642417733268','test','test','1.46'),('2018-10-06 19:59:59','2018-10-06 23:59:59','GXSETH','4h','0.005942000000000','0.006059000000000','1.408031544321620','1.435756164093688','236.96256215442943','236.962562154429435','test','test','0.0'),('2018-10-07 11:59:59','2018-10-18 03:59:59','GXSETH','4h','0.005971000000000','0.006814000000000','1.414192570937635','1.613851646017258','236.84350543252967','236.843505432529668','test','test','0.0'),('2018-10-19 05:59:59','2018-10-19 11:59:59','GXSETH','4h','0.006948000000000','0.006820000000000','1.458561254288662','1.431690810916620','209.92533884407914','209.925338844079135','test','test','1.84'),('2018-10-20 07:59:59','2018-10-20 11:59:59','GXSETH','4h','0.006948000000000','0.006934000000000','1.452590044650431','1.449663121704964','209.06592467622775','209.065924676227752','test','test','0.20'),('2018-10-20 15:59:59','2018-10-20 19:59:59','GXSETH','4h','0.006899000000000','0.006865000000000','1.451939617329216','1.444784095226129','210.45653244371874','210.456532443718743','test','test','0.49'),('2018-10-21 03:59:59','2018-10-21 07:59:59','GXSETH','4h','0.006906000000000','0.006869000000000','1.450349501306307','1.442579021788738','210.0129599343046','210.012959934304604','test','test','0.53'),('2018-10-21 11:59:59','2018-10-21 15:59:59','GXSETH','4h','0.006990000000000','0.006875000000000','1.448622728080181','1.424789879191881','207.24216424609173','207.242164246091733','test','test','1.64'),('2018-10-21 19:59:59','2018-10-21 23:59:59','GXSETH','4h','0.006956000000000','0.006887000000000','1.443326539438337','1.429009470545116','207.49375207566655','207.493752075666549','test','test','0.99'),('2018-10-23 11:59:59','2018-10-23 15:59:59','GXSETH','4h','0.007089000000000','0.007028000000000','1.440144968573176','1.427752692782096','203.15206214884702','203.152062148847023','test','test','0.86'),('2018-10-23 19:59:59','2018-10-24 03:59:59','GXSETH','4h','0.006941000000000','0.006883000000000','1.437391129508492','1.425380081314933','207.08703781998153','207.087037819981532','test','test','0.83'),('2018-10-25 15:59:59','2018-10-25 19:59:59','GXSETH','4h','0.006920000000000','0.006789000000000','1.434722007687701','1.407561807831185','207.32976989706663','207.329769897066626','test','test','1.89'),('2018-11-03 11:59:59','2018-11-04 11:59:59','GXSETH','4h','0.006745000000000','0.006720000000000','1.428686407719586','1.423391054095718','211.81414495471998','211.814144954719978','test','test','0.37'),('2018-11-16 03:59:59','2018-11-17 03:59:59','GXSETH','4h','0.006314000000000','0.006187720000000','1.427509662469838','1.398959469220441','226.0864210436867','226.086421043686698','test','test','2.00'),('2018-11-17 11:59:59','2018-11-17 15:59:59','GXSETH','4h','0.006270000000000','0.006315000000000','1.421165175081083','1.431364925141474','226.66111245312328','226.661112453123280','test','test','0.0'),('2018-11-17 19:59:59','2018-11-17 23:59:59','GXSETH','4h','0.006221000000000','0.006136000000000','1.423431786205614','1.403982870946415','228.8107677552828','228.810767755282797','test','test','1.36'),('2018-11-18 11:59:59','2018-11-18 15:59:59','GXSETH','4h','0.006230000000000','0.006201000000000','1.419109805036903','1.412503996955672','227.78648555969554','227.786485559695535','test','test','0.46'),('2018-11-19 07:59:59','2018-11-19 15:59:59','GXSETH','4h','0.006362000000000','0.006234760000000','1.417641847685519','1.389289010731809','222.8295893878527','222.829589387852707','test','test','1.99'),('2018-11-20 03:59:59','2018-11-20 07:59:59','GXSETH','4h','0.006286000000000','0.006252000000000','1.411341217251361','1.403707491291045','224.52135177399953','224.521351773999527','test','test','0.54'),('2018-11-20 11:59:59','2018-11-20 15:59:59','GXSETH','4h','0.006303000000000','0.006219000000000','1.409644833704624','1.390858515121221','223.64664980241537','223.646649802415368','test','test','1.33'),('2018-11-20 23:59:59','2018-11-24 23:59:59','GXSETH','4h','0.006270000000000','0.006313000000000','1.405470096241646','1.415108886375360','224.15791008638686','224.157910086386863','test','test','0.0'),('2018-11-25 03:59:59','2018-11-25 07:59:59','GXSETH','4h','0.006331000000000','0.006373000000000','1.407612049604693','1.416950180402892','222.3364475761638','222.336447576163806','test','test','0.0'),('2018-11-30 23:59:59','2018-12-01 11:59:59','GXSETH','4h','0.006356000000000','0.006228880000000','1.409687189782071','1.381493445986429','221.7884187825788','221.788418782578788','test','test','2.00'),('2018-12-01 15:59:59','2018-12-04 07:59:59','GXSETH','4h','0.006243000000000','0.006197000000000','1.403421913383039','1.393081146441565','224.79928133638302','224.799281336383018','test','test','0.73'),('2019-01-10 07:59:59','2019-01-15 03:59:59','GXSETH','4h','0.003955000000000','0.004097000000000','1.401123965173823','1.451429806654147','354.26648929805884','354.266489298058843','test','test','0.0'),('2019-01-15 07:59:59','2019-01-15 11:59:59','GXSETH','4h','0.004103000000000','0.004129000000000','1.412303041058339','1.421252560694585','344.2122937017644','344.212293701764395','test','test','0.0'),('2019-01-15 15:59:59','2019-01-31 15:59:59','GXSETH','4h','0.004171000000000','0.004999000000000','1.414291823199727','1.695047907977807','339.07739707497655','339.077397074976545','test','test','0.45'),('2019-01-31 19:59:59','2019-02-02 15:59:59','GXSETH','4h','0.005027000000000','0.004966000000000','1.476682064261523','1.458763304380888','293.75016197762534','293.750161977625339','test','test','1.21'),('2019-02-02 19:59:59','2019-02-03 03:59:59','GXSETH','4h','0.005023000000000','0.004963000000000','1.472700117621382','1.455108637020689','293.19134334488984','293.191343344889845','test','test','1.23'),('2019-02-03 07:59:59','2019-02-05 23:59:59','GXSETH','4h','0.004990000000000','0.005036000000000','1.468790899710116','1.482330855899829','294.34687368940206','294.346873689402059','test','test','0.0'),('2019-02-06 03:59:59','2019-02-06 23:59:59','GXSETH','4h','0.005146000000000','0.005050000000000','1.471799778863386','1.444342962157035','286.0085073578286','286.008507357828591','test','test','1.86'),('2019-02-07 03:59:59','2019-02-08 19:59:59','GXSETH','4h','0.005075000000000','0.004973500000000','1.465698264039752','1.436384298758957','288.80753971226653','288.807539712266532','test','test','2.00'),('2019-02-17 03:59:59','2019-02-17 07:59:59','GXSETH','4h','0.004855000000000','0.004824000000000','1.459184049532909','1.449866911420546','300.5528423342758','300.552842334275795','test','test','0.63'),('2019-02-23 15:59:59','2019-02-23 19:59:59','GXSETH','4h','0.004564000000000','0.004472720000000','1.457113574396828','1.427971302908891','319.26239579246896','319.262395792468965','test','test','2.0'),('2019-02-24 23:59:59','2019-02-25 03:59:59','GXSETH','4h','0.004657000000000','0.004563860000000','1.450637514066176','1.421624763784852','311.49613787119944','311.496137871199437','test','test','2.00'),('2019-02-25 19:59:59','2019-03-05 15:59:59','GXSETH','4h','0.004508000000000','0.004911000000000','1.444190236225881','1.573295973847671','320.3616318158566','320.361631815856583','test','test','0.0'),('2019-03-05 19:59:59','2019-03-05 23:59:59','GXSETH','4h','0.004803000000000','0.004790000000000','1.472880400141835','1.468893840657795','306.6584218492265','306.658421849226499','test','test','0.27'),('2019-03-06 03:59:59','2019-03-06 07:59:59','GXSETH','4h','0.004811000000000','0.004763000000000','1.471994498034270','1.457308209132660','305.9643521168718','305.964352116871794','test','test','0.99'),('2019-03-06 19:59:59','2019-03-06 23:59:59','GXSETH','4h','0.004784000000000','0.004797000000000','1.468730878278357','1.472721994795418','307.0089628508272','307.008962850827174','test','test','0.0'),('2019-03-07 11:59:59','2019-03-25 15:59:59','GXSETH','4h','0.004940000000000','0.007357000000000','1.469617793059926','2.188659535129934','297.4934803765032','297.493480376503214','test','test','0.16'),('2019-03-27 15:59:59','2019-03-27 19:59:59','GXSETH','4h','0.007801000000000','0.007644980000000','1.629404846853261','1.596816749916196','208.8712789197874','208.871278919787386','test','test','1.99'),('2019-03-27 23:59:59','2019-04-02 15:59:59','GXSETH','4h','0.007677000000000','0.008025000000000','1.622163047533913','1.695696034448307','211.30168653561464','211.301686535614635','test','test','0.0'),('2019-04-02 19:59:59','2019-04-02 23:59:59','GXSETH','4h','0.007904000000000','0.008023000000000','1.638503711292668','1.663172479213193','207.30057076071202','207.300570760712020','test','test','0.0'),('2019-04-03 03:59:59','2019-04-03 07:59:59','GXSETH','4h','0.007723000000000','0.007671000000000','1.643985659719451','1.632916482676150','212.8687892942446','212.868789294244607','test','test','0.67'),('2019-04-04 15:59:59','2019-04-04 19:59:59','GXSETH','4h','0.007913000000000','0.007754740000000','1.641525842598717','1.608695325746742','207.44671333232876','207.446713332328756','test','test','2.00'),('2019-04-04 23:59:59','2019-04-05 03:59:59','GXSETH','4h','0.007777000000000','0.007872000000000','1.634230172187167','1.654193122728222','210.1363214847843','210.136321484784304','test','test','0.0'),('2019-04-12 19:59:59','2019-04-18 19:59:59','GXSETH','4h','0.007573000000000','0.007586000000000','1.638666383418513','1.641479358855518','216.38272592347985','216.382725923479853','test','test','1.79'),('2019-04-21 19:59:59','2019-04-22 11:59:59','GXSETH','4h','0.007866000000000','0.007708680000000','1.639291489071181','1.606505659289757','208.4021725236691','208.402172523669094','test','test','1.99'),('2019-04-22 15:59:59','2019-04-23 15:59:59','GXSETH','4h','0.007728000000000','0.007612000000000','1.632005749119753','1.607508768413504','211.18086815731797','211.180868157317974','test','test','1.50');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:24:22
