-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-02-09 11:59:59','2018-02-09 15:59:59','BCCBTC','4h','0.158400000000000','0.155232000000000','0.033333333333333','0.032666666666666','0.21043771043771042','0.210437710437710','test','test','2.00'),('2018-02-09 19:59:59','2018-02-10 15:59:59','BCCBTC','4h','0.149490000000000','0.146500200000000','0.033185185185185','0.032521481481481','0.22198933162877188','0.221989331628772','test','test','2.00'),('2018-02-10 19:59:59','2018-02-13 03:59:59','BCCBTC','4h','0.144621000000000','0.142099000000000','0.033037695473251','0.032461561523247','0.228443279145151','0.228443279145151','test','test','1.74'),('2018-02-13 07:59:59','2018-02-13 11:59:59','BCCBTC','4h','0.141696000000000','0.142706000000000','0.032909665706583','0.033144243693002','0.2322554320981773','0.232255432098177','test','test','0.0'),('2018-02-13 15:59:59','2018-02-13 19:59:59','BCCBTC','4h','0.143819000000000','0.143545000000000','0.032961794148010','0.032898996245114','0.2291894266265916','0.229189426626592','test','test','0.19'),('2018-02-13 23:59:59','2018-02-14 07:59:59','BCCBTC','4h','0.143412000000000','0.142850000000000','0.032947839058477','0.032818723743504','0.22974255333219906','0.229742553332199','test','test','0.39'),('2018-02-14 11:59:59','2018-02-14 15:59:59','BCCBTC','4h','0.142381000000000','0.147018000000000','0.032919146766261','0.033991242646717','0.23120463240362904','0.231204632403629','test','test','0.0'),('2018-02-14 19:59:59','2018-02-15 03:59:59','BCCBTC','4h','0.143100000000000','0.140238000000000','0.033157390295251','0.032494242489346','0.23170782875787094','0.231707828757871','test','test','2.00'),('2018-02-16 03:59:59','2018-02-16 07:59:59','BCCBTC','4h','0.151163000000000','0.148139740000000','0.033010024116161','0.032349823633838','0.2183737033279396','0.218373703327940','test','test','2.0'),('2018-02-16 11:59:59','2018-02-16 19:59:59','BCCBTC','4h','0.149768000000000','0.146772640000000','0.032863312897867','0.032206046639910','0.21942813483432597','0.219428134834326','test','test','2.00'),('2018-02-16 23:59:59','2018-02-17 07:59:59','BCCBTC','4h','0.150449000000000','0.147440020000000','0.032717253729432','0.032062908654843','0.21746408237630319','0.217464082376303','test','test','1.99'),('2018-03-11 07:59:59','2018-03-12 11:59:59','BCCBTC','4h','0.115006000000000','0.114508000000000','0.032571843712857','0.032430800826668','0.28321864696500276','0.283218646965003','test','test','0.43'),('2018-03-13 03:59:59','2018-03-13 07:59:59','BCCBTC','4h','0.115586000000000','0.114360000000000','0.032540500849260','0.032195349584910','0.2815263167620608','0.281526316762061','test','test','1.06'),('2018-03-13 15:59:59','2018-03-14 03:59:59','BCCBTC','4h','0.116887000000000','0.114549260000000','0.032463800568293','0.031814524556927','0.2777366222787212','0.277736622278721','test','test','2.00'),('2018-03-14 11:59:59','2018-03-14 15:59:59','BCCBTC','4h','0.116661000000000','0.115360000000000','0.032319517010212','0.031959090718390','0.2770378876420702','0.277037887642070','test','test','1.11'),('2018-03-14 19:59:59','2018-03-14 23:59:59','BCCBTC','4h','0.115755000000000','0.115179000000000','0.032239422278696','0.032078998044473','0.2785142955267207','0.278514295526721','test','test','0.49'),('2018-03-16 15:59:59','2018-03-16 23:59:59','BCCBTC','4h','0.117816000000000','0.117788000000000','0.032203772448868','0.032196118941462','0.2733395502212621','0.273339550221262','test','test','0.02'),('2018-03-17 03:59:59','2018-03-18 11:59:59','BCCBTC','4h','0.118145000000000','0.117082000000000','0.032202071669445','0.031912336156435','0.2725639821358895','0.272563982135890','test','test','0.89'),('2018-03-18 15:59:59','2018-03-18 19:59:59','BCCBTC','4h','0.115216000000000','0.115339000000000','0.032137685999887','0.032171994909917','0.2789342278840342','0.278934227884034','test','test','0.0'),('2018-03-20 03:59:59','2018-03-20 07:59:59','BCCBTC','4h','0.117147000000000','0.115268000000000','0.032145310202116','0.031629709820802','0.274401480209615','0.274401480209615','test','test','1.60'),('2018-03-20 15:59:59','2018-03-21 07:59:59','BCCBTC','4h','0.119299000000000','0.116913020000000','0.032030732339602','0.031390117692810','0.26849120562285983','0.268491205622860','test','test','1.99'),('2018-03-21 11:59:59','2018-03-21 15:59:59','BCCBTC','4h','0.116300000000000','0.116130000000000','0.031888373529203','0.031841761117337','0.2741906580327028','0.274190658032703','test','test','0.14'),('2018-03-21 19:59:59','2018-03-21 23:59:59','BCCBTC','4h','0.115859000000000','0.115652000000000','0.031878015215455','0.031821060217142','0.2751449193886995','0.275144919388700','test','test','0.17'),('2018-03-22 03:59:59','2018-03-22 07:59:59','BCCBTC','4h','0.116577000000000','0.116581000000000','0.031865358549164','0.031866451916073','0.27334172734899304','0.273341727348993','test','test','0.0'),('2018-03-22 11:59:59','2018-03-22 15:59:59','BCCBTC','4h','0.115700000000000','0.116523000000000','0.031865601519588','0.032092268676465','0.27541574347094017','0.275415743470940','test','test','0.0'),('2018-03-23 11:59:59','2018-03-23 15:59:59','BCCBTC','4h','0.116654000000000','0.116618000000000','0.031915971998894','0.031906122572454','0.2735951788956554','0.273595178895655','test','test','0.03'),('2018-03-23 19:59:59','2018-03-23 23:59:59','BCCBTC','4h','0.116301000000000','0.115364000000000','0.031913783237463','0.031656664082052','0.2744067827229574','0.274406782722957','test','test','0.80'),('2018-04-12 03:59:59','2018-04-12 07:59:59','BCCBTC','4h','0.097410000000000','0.096690000000000','0.031856645647371','0.031621179218194','0.3270367071899326','0.327036707189933','test','test','0.73'),('2018-04-16 23:59:59','2018-04-17 03:59:59','BCCBTC','4h','0.095286000000000','0.094668000000000','0.031804319774221','0.031598045299267','0.33377746756313514','0.333777467563135','test','test','0.64'),('2018-04-17 07:59:59','2018-05-01 03:59:59','BCCBTC','4h','0.095811000000000','0.142845000000000','0.031758481002009','0.047348845317677','0.33147009218157514','0.331470092181575','test','test','0.0'),('2018-05-01 07:59:59','2018-05-11 07:59:59','BCCBTC','4h','0.145038000000000','0.160909000000000','0.035223006405491','0.039077336544224','0.24285364115259905','0.242853641152599','test','test','1.19'),('2018-05-12 11:59:59','2018-05-12 15:59:59','BCCBTC','4h','0.169999000000000','0.166599020000000','0.036079524214098','0.035357933729816','0.2122337438108342','0.212233743810834','test','test','1.99'),('2018-05-12 19:59:59','2018-05-14 03:59:59','BCCBTC','4h','0.170972000000000','0.167552560000000','0.035919170773146','0.035200787357683','0.2100880306316031','0.210088030631603','test','test','1.99'),('2018-05-14 19:59:59','2018-05-14 23:59:59','BCCBTC','4h','0.166330000000000','0.163003400000000','0.035759530014155','0.035044339413872','0.21499146283986453','0.214991462839865','test','test','2.00'),('2018-06-02 15:59:59','2018-06-10 03:59:59','BCCBTC','4h','0.140000000000000','0.141645000000000','0.035600598769647','0.036018905805190','0.25428999121176665','0.254289991211767','test','test','0.0'),('2018-07-03 03:59:59','2018-07-03 11:59:59','BCCBTC','4h','0.121932000000000','0.119493360000000','0.035693555888657','0.034979684770884','0.29273329305397183','0.292733293053972','test','test','2.00'),('2018-07-15 11:59:59','2018-07-18 19:59:59','BCCBTC','4h','0.114254000000000','0.114405000000000','0.035534917862485','0.035581881405094','0.3110168384694201','0.311016838469420','test','test','0.58'),('2018-08-05 23:59:59','2018-08-06 03:59:59','BCCBTC','4h','0.100893000000000','0.100361000000000','0.035545354205287','0.035357926648993','0.35230743664364345','0.352307436643643','test','test','0.52'),('2018-08-07 07:59:59','2018-08-07 11:59:59','BCCBTC','4h','0.100692000000000','0.100183000000000','0.035503703637222','0.035324231731298','0.35259706468460045','0.352597064684600','test','test','0.50'),('2018-08-17 23:59:59','2018-08-18 07:59:59','BCCBTC','4h','0.091687000000000','0.089853260000000','0.035463820991461','0.034754544571632','0.38679224962601993','0.386792249626020','test','test','2.00'),('2018-08-18 11:59:59','2018-08-18 15:59:59','BCCBTC','4h','0.089731000000000','0.087936380000000','0.035306204009277','0.034600079929091','0.39346718535708575','0.393467185357086','test','test','1.99'),('2018-08-19 15:59:59','2018-08-19 19:59:59','BCCBTC','4h','0.088949000000000','0.088500000000000','0.035149287547013','0.034971859693877','0.3951622564279881','0.395162256427988','test','test','0.50'),('2018-09-01 15:59:59','2018-09-05 11:59:59','BCCBTC','4h','0.085559000000000','0.083847820000000','0.035109859135205','0.034407661952501','0.4103584559801437','0.410358455980144','test','test','2.00'),('2018-09-21 07:59:59','2018-09-22 11:59:59','BCCBTC','4h','0.072141000000000','0.071084000000000','0.034953815316826','0.034441676827064','0.4845208039371016','0.484520803937102','test','test','1.46'),('2018-09-22 15:59:59','2018-09-24 07:59:59','BCCBTC','4h','0.071459000000000','0.071059000000000','0.034840006763546','0.034644985804599','0.48755239736836514','0.487552397368365','test','test','0.55'),('2018-09-24 11:59:59','2018-09-24 15:59:59','BCCBTC','4h','0.071013000000000','0.070682000000000','0.034796668772669','0.034634477380054','0.4900042072954091','0.490004207295409','test','test','0.46'),('2018-09-26 15:59:59','2018-10-04 19:59:59','BCCBTC','4h','0.080390000000000','0.078782200000000','0.034760626240977','0.034065413716157','0.43239987860401374','0.432399878604014','test','test','2.00'),('2018-10-06 03:59:59','2018-10-06 11:59:59','BCCBTC','4h','0.078589000000000','0.077842000000000','0.034606134568794','0.034277198171552','0.4403432359337114','0.440343235933711','test','test','0.95'),('2018-10-07 23:59:59','2018-10-09 11:59:59','BCCBTC','4h','0.078806000000000','0.078645000000000','0.034533037591630','0.034462486884168','0.4382031519380448','0.438203151938045','test','test','0.20'),('2018-11-02 15:59:59','2018-11-09 23:59:59','BCCBTC','4h','0.071251000000000','0.085150000000000','0.034517359656638','0.041250693671145','0.48444737135812843','0.484447371358128','test','test','0.0'),('2018-11-10 03:59:59','2018-11-11 15:59:59','BCCBTC','4h','0.085210000000000','0.083505800000000','0.036013656104306','0.035293382982220','0.42264588785713214','0.422645887857132','test','test','2.00'),('2018-11-13 11:59:59','2018-11-13 15:59:59','BCCBTC','4h','0.085258000000000','0.083552840000000','0.035853595410509','0.035136523502299','0.42053057086149503','0.420530570861495','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:42:59
