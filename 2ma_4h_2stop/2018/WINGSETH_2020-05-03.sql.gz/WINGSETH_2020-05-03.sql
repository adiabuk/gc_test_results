-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-07-01 15:59:59','2018-07-01 19:59:59','WINGSETH','4h','0.000477900000000','0.000484900000000','1.297777777777778','1.316786868475506','2715.5843853897836','2715.584385389783620','test','test','0.0'),('2018-07-01 23:59:59','2018-07-02 11:59:59','WINGSETH','4h','0.000489800000000','0.000480004000000','1.302002020155051','1.275961979751950','2658.231972550124','2658.231972550123828','test','test','2.00'),('2018-07-02 15:59:59','2018-07-03 19:59:59','WINGSETH','4h','0.000483000000000','0.000478600000000','1.296215344509917','1.284407171599268','2683.6756615112154','2683.675661511215367','test','test','0.91'),('2018-07-03 23:59:59','2018-07-04 00:22:27','WINGSETH','4h','0.000480700000000','0.000473000000000','1.293591306085328','1.272870163882588','2691.0574289272486','2691.057428927248566','test','test','1.60'),('2018-07-04 11:59:59','2018-07-04 15:59:59','WINGSETH','4h','0.000483000000000','0.000529400000000','1.288986607818053','1.412814720867241','2668.709332956631','2668.709332956630988','test','test','0.0'),('2018-07-04 19:59:59','2018-07-05 19:59:59','WINGSETH','4h','0.000522400000000','0.000511952000000','1.316503966273428','1.290173886947959','2520.107132988951','2520.107132988950980','test','test','2.00'),('2018-07-05 23:59:59','2018-07-06 03:59:59','WINGSETH','4h','0.000485800000000','0.000476084000000','1.310652837534435','1.284439780783746','2697.9267960774705','2697.926796077470499','test','test','2.0'),('2018-07-09 19:59:59','2018-07-09 23:59:59','WINGSETH','4h','0.000503800000000','0.000493724000000','1.304827713812060','1.278731159535819','2589.9716431362835','2589.971643136283546','test','test','2.00'),('2018-07-10 03:59:59','2018-07-10 07:59:59','WINGSETH','4h','0.000491100000000','0.000481278000000','1.299028479528450','1.273047909937881','2645.1404592312165','2645.140459231216482','test','test','1.99'),('2018-07-16 19:59:59','2018-07-16 23:59:59','WINGSETH','4h','0.000461400000000','0.000452172000000','1.293255019619435','1.267389919227046','2802.8934105319354','2802.893410531935388','test','test','2.00'),('2018-07-17 11:59:59','2018-07-17 15:59:59','WINGSETH','4h','0.000461700000000','0.000452466000000','1.287507219532237','1.261757075141592','2788.622957618015','2788.622957618014880','test','test','2.0'),('2018-07-17 19:59:59','2018-07-21 11:59:59','WINGSETH','4h','0.000460600000000','0.000493500000000','1.281784965223205','1.373341034167720','2782.859238435096','2782.859238435095904','test','test','0.0'),('2018-07-21 15:59:59','2018-07-23 03:59:59','WINGSETH','4h','0.000492100000000','0.000487300000000','1.302130758321987','1.289429625137786','2646.069413375303','2646.069413375303156','test','test','1.32'),('2018-07-23 07:59:59','2018-07-23 11:59:59','WINGSETH','4h','0.000490000000000','0.000480200000000','1.299308284281053','1.273322118595432','2651.649559757251','2651.649559757251154','test','test','2.00'),('2018-07-23 19:59:59','2018-07-24 03:59:59','WINGSETH','4h','0.000487500000000','0.000477750000000','1.293533580795359','1.267662909179452','2653.4022170161215','2653.402217016121540','test','test','1.99'),('2018-07-25 11:59:59','2018-07-25 15:59:59','WINGSETH','4h','0.000481600000000','0.000471968000000','1.287784542658491','1.262028851805321','2673.971226450355','2673.971226450355061','test','test','2.00'),('2018-07-25 23:59:59','2018-07-26 03:59:59','WINGSETH','4h','0.000484100000000','0.000484600000000','1.282061055802231','1.283385225452925','2648.3393013886202','2648.339301388620243','test','test','0.0'),('2018-07-26 07:59:59','2018-07-26 11:59:59','WINGSETH','4h','0.000486200000000','0.000478400000000','1.282355315724607','1.261782770552554','2637.5057912887855','2637.505791288785531','test','test','1.60'),('2018-07-26 15:59:59','2018-07-26 19:59:59','WINGSETH','4h','0.000482800000000','0.000480400000000','1.277783639019707','1.271431773374207','2646.6106856249107','2646.610685624910730','test','test','0.49'),('2018-07-27 19:59:59','2018-07-30 23:59:59','WINGSETH','4h','0.000484000000000','0.000511000000000','1.276372113320707','1.347574689890251','2637.132465538651','2637.132465538651104','test','test','0.28'),('2018-07-31 03:59:59','2018-07-31 11:59:59','WINGSETH','4h','0.000509500000000','0.000500000000000','1.292194908113939','1.268100989316918','2536.2019786338346','2536.201978633834642','test','test','1.86'),('2018-08-07 19:59:59','2018-08-07 23:59:59','WINGSETH','4h','0.000459300000000','0.000450114000000','1.286840703936823','1.261103889858087','2801.743313600747','2801.743313600747115','test','test','2.00'),('2018-08-08 15:59:59','2018-08-08 19:59:59','WINGSETH','4h','0.000463000000000','0.000453740000000','1.281121411919326','1.255498983680939','2767.0008896745708','2767.000889674570772','test','test','2.00'),('2018-08-10 15:59:59','2018-08-10 19:59:59','WINGSETH','4h','0.000447300000000','0.000438354000000','1.275427538977463','1.249918988197914','2851.391770573357','2851.391770573357007','test','test','2.00'),('2018-08-10 23:59:59','2018-08-15 03:59:59','WINGSETH','4h','0.000444300000000','0.000451800000000','1.269758972137563','1.291193120890729','2857.886500422153','2857.886500422152949','test','test','1.12'),('2018-08-15 07:59:59','2018-08-15 19:59:59','WINGSETH','4h','0.000458100000000','0.000448938000000','1.274522116304933','1.249031673978834','2782.191915094811','2782.191915094811066','test','test','2.00'),('2018-08-15 23:59:59','2018-08-16 07:59:59','WINGSETH','4h','0.000451900000000','0.000449100000000','1.268857573565800','1.260995654543928','2807.8282220973665','2807.828222097366506','test','test','0.61'),('2018-08-17 03:59:59','2018-08-17 07:59:59','WINGSETH','4h','0.000451600000000','0.000461500000000','1.267110480449828','1.294888145986704','2805.8248017046685','2805.824801704668516','test','test','0.0'),('2018-08-17 11:59:59','2018-08-23 11:59:59','WINGSETH','4h','0.000467800000000','0.000518000000000','1.273283295013578','1.409920365149708','2721.853986775499','2721.853986775498925','test','test','1.30'),('2018-08-23 15:59:59','2018-08-23 19:59:59','WINGSETH','4h','0.000527600000000','0.000517048000000','1.303647088377163','1.277574146609620','2470.9004707679355','2470.900470767935531','test','test','2.00'),('2018-08-23 23:59:59','2018-08-29 19:59:59','WINGSETH','4h','0.000513700000000','0.000519000000000','1.297853101317709','1.311243448674112','2526.480633283452','2526.480633283451880','test','test','1.28'),('2018-08-29 23:59:59','2018-08-30 15:59:59','WINGSETH','4h','0.000516400000000','0.000506072000000','1.300828734063576','1.274812159382305','2519.0331798287684','2519.033179828768425','test','test','1.99'),('2018-08-31 07:59:59','2018-08-31 19:59:59','WINGSETH','4h','0.000513100000000','0.000512800000000','1.295047273023294','1.294290083037118','2523.966620587203','2523.966620587203124','test','test','0.25'),('2018-08-31 23:59:59','2018-09-01 03:59:59','WINGSETH','4h','0.000512300000000','0.000507400000000','1.294879008581922','1.282493868737980','2527.579559988135','2527.579559988134861','test','test','0.95'),('2018-09-01 11:59:59','2018-09-01 15:59:59','WINGSETH','4h','0.000511800000000','0.000508700000000','1.292126755283267','1.284300274350523','2524.6712686269393','2524.671268626939309','test','test','0.60'),('2018-09-01 23:59:59','2018-09-02 15:59:59','WINGSETH','4h','0.000509400000000','0.000509100000000','1.290387537298213','1.289627591752101','2533.1518203734063','2533.151820373406281','test','test','0.05'),('2018-09-02 19:59:59','2018-09-02 23:59:59','WINGSETH','4h','0.000508200000000','0.000509100000000','1.290218660510189','1.292503581396571','2538.8009848685333','2538.800984868533305','test','test','0.0'),('2018-09-03 07:59:59','2018-09-13 23:59:59','WINGSETH','4h','0.000511700000000','0.000573600000000','1.290726420707162','1.446864715492726','2522.428025614935','2522.428025614934995','test','test','0.0'),('2018-09-16 07:59:59','2018-09-16 11:59:59','WINGSETH','4h','0.000585600000000','0.000574400000000','1.325423819548398','1.300074183655396','2263.3603475894784','2263.360347589478351','test','test','1.91'),('2018-09-16 15:59:59','2018-09-21 15:59:59','WINGSETH','4h','0.000582400000000','0.000603300000000','1.319790567127731','1.367152556916484','2266.123913337451','2266.123913337451086','test','test','0.0'),('2018-09-23 07:59:59','2018-09-23 11:59:59','WINGSETH','4h','0.000625600000000','0.000613088000000','1.330315453747454','1.303709144672505','2126.463321207568','2126.463321207567787','test','test','2.00'),('2018-09-24 23:59:59','2018-09-29 11:59:59','WINGSETH','4h','0.000604100000000','0.000619000000000','1.324402940619688','1.357069061816896','2192.357127329396','2192.357127329396008','test','test','1.05'),('2018-09-29 15:59:59','2018-09-29 19:59:59','WINGSETH','4h','0.000620000000000','0.000612600000000','1.331662078663512','1.315768047402044','2147.8420623605034','2147.842062360503405','test','test','1.19'),('2018-09-29 23:59:59','2018-09-30 03:59:59','WINGSETH','4h','0.000618800000000','0.000610100000000','1.328130071716519','1.309457266894390','2146.299404842468','2146.299404842467993','test','test','1.40'),('2018-10-01 07:59:59','2018-10-01 11:59:59','WINGSETH','4h','0.000612700000000','0.000620000000000','1.323980559533824','1.339755095333721','2160.8953150543884','2160.895315054388448','test','test','0.0'),('2018-10-01 15:59:59','2018-10-03 19:59:59','WINGSETH','4h','0.000620700000000','0.000631900000000','1.327486011933801','1.351439360304445','2138.691818807477','2138.691818807476920','test','test','0.0'),('2018-10-03 23:59:59','2018-10-11 15:59:59','WINGSETH','4h','0.000638500000000','0.000671200000000','1.332808978238389','1.401067167100402','2087.4063872175234','2087.406387217523388','test','test','0.0'),('2018-10-11 19:59:59','2018-10-11 23:59:59','WINGSETH','4h','0.000665700000000','0.000652386000000','1.347977464652169','1.321017915359125','2024.9023053209692','2024.902305320969162','test','test','2.00'),('2018-10-12 07:59:59','2018-10-17 07:59:59','WINGSETH','4h','0.000673600000000','0.000754800000000','1.341986453698159','1.503757979886239','1992.2601747300466','1992.260174730046629','test','test','0.0'),('2018-10-17 11:59:59','2018-10-17 15:59:59','WINGSETH','4h','0.000757700000000','0.000755400000000','1.377935681739955','1.373752954977381','1818.5768532928005','1818.576853292800479','test','test','0.30'),('2018-10-17 19:59:59','2018-10-27 15:59:59','WINGSETH','4h','0.000777000000000','0.000820300000000','1.377006186903827','1.453742825118673','1772.2087347539605','1772.208734753960471','test','test','0.41'),('2018-10-27 19:59:59','2018-10-27 23:59:59','WINGSETH','4h','0.000815700000000','0.000811500000000','1.394058773173793','1.386880831715745','1709.0336804876706','1709.033680487670608','test','test','0.51'),('2018-10-28 03:59:59','2018-11-03 11:59:59','WINGSETH','4h','0.000849800000000','0.000873200000000','1.392463675072005','1.430806402768739','1638.5781066980524','1638.578106698052352','test','test','0.0'),('2018-11-03 15:59:59','2018-11-04 11:59:59','WINGSETH','4h','0.000871700000000','0.000854266000000','1.400984281226835','1.372964595602298','1607.1862810907821','1607.186281090782131','test','test','1.99'),('2018-11-07 19:59:59','2018-11-07 23:59:59','WINGSETH','4h','0.001057500000000','0.001036350000000','1.394757684421382','1.366862530732954','1318.9197961431505','1318.919796143150506','test','test','1.99'),('2018-11-08 03:59:59','2018-11-08 19:59:59','WINGSETH','4h','0.001000600000000','0.000980588000000','1.388558761379509','1.360787586151919','1387.7261257040864','1387.726125704086371','test','test','2.00'),('2018-11-08 23:59:59','2018-11-09 11:59:59','WINGSETH','4h','0.000939000000000','0.000920220000000','1.382387389106711','1.354739641324577','1472.1910427121525','1472.191042712152466','test','test','2.00'),('2018-11-09 15:59:59','2018-11-12 11:59:59','WINGSETH','4h','0.000908100000000','0.000889938000000','1.376243445155126','1.348718576252024','1515.5197061503422','1515.519706150342245','test','test','2.00'),('2018-11-26 15:59:59','2018-11-26 19:59:59','WINGSETH','4h','0.000778700000000','0.000763126000000','1.370126807621103','1.342724271468681','1759.5053391821023','1759.505339182102261','test','test','1.99'),('2018-11-29 07:59:59','2018-11-30 03:59:59','WINGSETH','4h','0.000720200000000','0.000714100000000','1.364037355142787','1.352484136777928','1893.970223747274','1893.970223747274076','test','test','0.84'),('2018-11-30 07:59:59','2018-11-30 19:59:59','WINGSETH','4h','0.000765200000000','0.000749896000000','1.361469973283929','1.334240573818250','1779.2341522267768','1779.234152226776814','test','test','2.00'),('2018-11-30 23:59:59','2018-12-05 23:59:59','WINGSETH','4h','0.000774000000000','0.000765200000000','1.355418995624890','1.340008547095822','1751.1873328486947','1751.187332848694723','test','test','1.13'),('2018-12-06 11:59:59','2018-12-06 15:59:59','WINGSETH','4h','0.000784000000000','0.000768320000000','1.351994451507319','1.324954562477173','1724.4827187593355','1724.482718759335512','test','test','2.00'),('2018-12-07 15:59:59','2018-12-07 19:59:59','WINGSETH','4h','0.000804500000000','0.000788410000000','1.345985587278398','1.319065875532830','1673.0709599482882','1673.070959948288191','test','test','1.99'),('2018-12-08 11:59:59','2018-12-08 15:59:59','WINGSETH','4h','0.000788800000000','0.000773024000000','1.340003429112716','1.313203360530462','1698.7873087128753','1698.787308712875301','test','test','2.00'),('2018-12-12 11:59:59','2018-12-12 15:59:59','WINGSETH','4h','0.000771400000000','0.000762200000000','1.334047858316660','1.318137513104690','1729.3853491271188','1729.385349127118843','test','test','1.19'),('2018-12-12 19:59:59','2018-12-12 23:59:59','WINGSETH','4h','0.000758300000000','0.000866300000000','1.330512226047333','1.520008890181728','1754.598741985142','1754.598741985141942','test','test','0.0'),('2018-12-13 03:59:59','2018-12-13 07:59:59','WINGSETH','4h','0.000780100000000','0.000770900000000','1.372622595854976','1.356434763677222','1759.5469758428098','1759.546975842809843','test','test','1.17'),('2018-12-13 11:59:59','2018-12-13 15:59:59','WINGSETH','4h','0.000778700000000','0.000766600000000','1.369025299815475','1.347752401230953','1758.090792109253','1758.090792109253016','test','test','1.55'),('2018-12-13 19:59:59','2018-12-14 11:59:59','WINGSETH','4h','0.000773100000000','0.000759600000000','1.364297989018915','1.340474392004615','1764.7108899481505','1764.710889948150452','test','test','1.74'),('2018-12-14 23:59:59','2018-12-15 03:59:59','WINGSETH','4h','0.000767200000000','0.000752800000000','1.359003856349070','1.333495963320620','1771.3814603090073','1771.381460309007252','test','test','1.87'),('2018-12-15 07:59:59','2018-12-15 19:59:59','WINGSETH','4h','0.000768300000000','0.000761500000000','1.353335435676081','1.341357457070592','1761.467441983706','1761.467441983706067','test','test','0.88'),('2018-12-15 23:59:59','2018-12-16 03:59:59','WINGSETH','4h','0.000765300000000','0.000762500000000','1.350673662652639','1.345731958411913','1764.8943716877554','1764.894371687755438','test','test','0.36'),('2018-12-16 23:59:59','2018-12-17 19:59:59','WINGSETH','4h','0.000773800000000','0.000758324000000','1.349575506154700','1.322583996031606','1744.0882736555961','1744.088273655596140','test','test','2.00'),('2019-01-08 07:59:59','2019-01-10 19:59:59','WINGSETH','4h','0.000572400000000','0.000570700000000','1.343577392794013','1.339587033660977','2347.2700782564866','2347.270078256486613','test','test','1.29'),('2019-01-10 23:59:59','2019-01-14 15:59:59','WINGSETH','4h','0.000577100000000','0.000570200000000','1.342690646320005','1.326636989311500','2326.616957754297','2326.616957754296891','test','test','1.19'),('2019-01-14 19:59:59','2019-01-26 15:59:59','WINGSETH','4h','0.000600700000000','0.000818200000000','1.339123166984781','1.823989637467867','2229.2711286578683','2229.271128657868303','test','test','0.41'),('2019-01-26 19:59:59','2019-01-26 23:59:59','WINGSETH','4h','0.000806500000000','0.000809300000000','1.446871271536578','1.451894507197213','1794.0127359412004','1794.012735941200390','test','test','0.0'),('2019-01-27 03:59:59','2019-01-27 07:59:59','WINGSETH','4h','0.000810300000000','0.000794094000000','1.447987546127831','1.419027795205275','1786.9771024655445','1786.977102465544476','test','test','2.00'),('2019-01-27 19:59:59','2019-01-27 23:59:59','WINGSETH','4h','0.000845300000000','0.000828394000000','1.441552045922818','1.412721005004361','1705.3732945969693','1705.373294596969345','test','test','2.00'),('2019-01-28 15:59:59','2019-01-29 07:59:59','WINGSETH','4h','0.000851200000000','0.000834176000000','1.435145147940939','1.406442244982120','1686.0257847050505','1686.025784705050455','test','test','2.00'),('2019-01-29 11:59:59','2019-01-29 15:59:59','WINGSETH','4h','0.000800100000000','0.000811400000000','1.428766725061202','1.448945532701736','1785.7351894278233','1785.735189427823343','test','test','0.0'),('2019-01-29 19:59:59','2019-01-29 23:59:59','WINGSETH','4h','0.000816600000000','0.000824200000000','1.433250904536876','1.446590001860511','1755.1443846888017','1755.144384688801665','test','test','0.0'),('2019-01-30 03:59:59','2019-01-30 07:59:59','WINGSETH','4h','0.000811500000000','0.000802300000000','1.436215148386572','1.419932733888536','1769.8276628300334','1769.827662830033432','test','test','1.13'),('2019-01-30 11:59:59','2019-01-30 15:59:59','WINGSETH','4h','0.000822100000000','0.000805658000000','1.432596834053675','1.403944897372601','1742.6065369829403','1742.606536982940270','test','test','1.99'),('2019-02-02 07:59:59','2019-02-02 11:59:59','WINGSETH','4h','0.000813300000000','0.000797034000000','1.426229737013436','1.397705142273167','1753.6330222715314','1753.633022271531445','test','test','2.00'),('2019-02-02 15:59:59','2019-02-02 19:59:59','WINGSETH','4h','0.000826000000000','0.000809480000000','1.419890938182266','1.391493119418621','1718.996293198869','1718.996293198868898','test','test','2.00'),('2019-02-03 07:59:59','2019-02-03 11:59:59','WINGSETH','4h','0.000812100000000','0.000838200000000','1.413580311790344','1.459011226871896','1740.6480874157671','1740.648087415767122','test','test','0.0'),('2019-02-03 15:59:59','2019-02-03 19:59:59','WINGSETH','4h','0.000831300000000','0.000814674000000','1.423676070697356','1.395202549283409','1712.5900044476798','1712.590004447679803','test','test','2.00'),('2019-02-03 23:59:59','2019-02-04 03:59:59','WINGSETH','4h','0.000810400000000','0.000799200000000','1.417348621494257','1.397760387830960','1748.949434222923','1748.949434222922946','test','test','1.38'),('2019-02-04 07:59:59','2019-02-04 11:59:59','WINGSETH','4h','0.000807100000000','0.000796800000000','1.412995680680191','1.394963397801978','1750.7070755546906','1750.707075554690618','test','test','1.27'),('2019-02-07 19:59:59','2019-02-07 23:59:59','WINGSETH','4h','0.000824100000000','0.000807618000000','1.408988506707255','1.380808736573110','1709.730016632999','1709.730016632998968','test','test','2.00'),('2019-02-10 11:59:59','2019-02-10 15:59:59','WINGSETH','4h','0.000773400000000','0.000769000000000','1.402726335566334','1.394745994376145','1813.7139068610466','1813.713906861046553','test','test','0.56');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:46:29
