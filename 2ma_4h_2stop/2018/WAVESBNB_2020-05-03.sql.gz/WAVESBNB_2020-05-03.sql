-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-06-30 23:59:59','2018-07-01 15:59:59','WAVESBNB','4h','0.200600000000000','0.196588000000000','3.111111111111111','3.048888888888889','15.50902847014512','15.509028470145120','test','test','2.00'),('2018-07-01 19:59:59','2018-07-07 11:59:59','WAVESBNB','4h','0.197500000000000','0.210400000000000','3.097283950617284','3.299587560556337','15.682450382872323','15.682450382872323','test','test','0.0'),('2018-07-07 15:59:59','2018-07-07 19:59:59','WAVESBNB','4h','0.216000000000000','0.211680000000000','3.142240308381518','3.079395502213888','14.547408835099622','14.547408835099622','test','test','1.99'),('2018-07-07 23:59:59','2018-07-10 11:59:59','WAVESBNB','4h','0.211800000000000','0.210300000000000','3.128274795899822','3.106119875248973','14.769947100565734','14.769947100565734','test','test','0.70'),('2018-07-10 15:59:59','2018-07-10 19:59:59','WAVESBNB','4h','0.210800000000000','0.211900000000000','3.123351480199634','3.139649803862915','14.816657875709838','14.816657875709838','test','test','0.0'),('2018-07-11 03:59:59','2018-07-11 07:59:59','WAVESBNB','4h','0.215300000000000','0.214900000000000','3.126973329902585','3.121163811407643','14.523796237355251','14.523796237355251','test','test','0.18'),('2018-07-11 11:59:59','2018-07-12 07:59:59','WAVESBNB','4h','0.212900000000000','0.211300000000000','3.125682325792598','3.102191993611911','14.681457612929066','14.681457612929066','test','test','0.75'),('2018-07-12 11:59:59','2018-07-12 15:59:59','WAVESBNB','4h','0.215000000000000','0.212300000000000','3.120462251974668','3.081275051601033','14.513777916161247','14.513777916161247','test','test','1.25'),('2018-07-12 19:59:59','2018-07-16 07:59:59','WAVESBNB','4h','0.215900000000000','0.211582000000000','3.111753985224971','3.049518905520472','14.41294110803599','14.412941108035991','test','test','2.00'),('2018-07-16 11:59:59','2018-07-16 19:59:59','WAVESBNB','4h','0.217900000000000','0.218400000000000','3.097923967512860','3.105032558535147','14.217182044574852','14.217182044574852','test','test','0.36'),('2018-07-16 23:59:59','2018-07-17 03:59:59','WAVESBNB','4h','0.221000000000000','0.218200000000000','3.099503654406702','3.060233924848608','14.024903413604985','14.024903413604985','test','test','1.26'),('2018-07-17 07:59:59','2018-07-17 15:59:59','WAVESBNB','4h','0.220700000000000','0.222200000000000','3.090777047838236','3.111783688398986','14.004427040499484','14.004427040499484','test','test','0.0'),('2018-07-17 19:59:59','2018-07-17 23:59:59','WAVESBNB','4h','0.235800000000000','0.231084000000000','3.095445190185069','3.033536286381367','13.127418109351439','13.127418109351439','test','test','1.99'),('2018-07-18 03:59:59','2018-07-18 07:59:59','WAVESBNB','4h','0.236000000000000','0.231280000000000','3.081687656006469','3.020053902886340','13.057998542400293','13.057998542400293','test','test','2.00'),('2018-07-18 11:59:59','2018-07-20 03:59:59','WAVESBNB','4h','0.224700000000000','0.222100000000000','3.067991266424218','3.032491589999193','13.653721701932435','13.653721701932435','test','test','1.15'),('2018-07-20 07:59:59','2018-07-22 19:59:59','WAVESBNB','4h','0.226700000000000','0.228800000000000','3.060102449440879','3.088449229960622','13.49846691416356','13.498466914163560','test','test','0.0'),('2018-07-23 07:59:59','2018-07-23 19:59:59','WAVESBNB','4h','0.234600000000000','0.229908000000000','3.066401734000822','3.005073699320805','13.07076612958577','13.070766129585770','test','test','2.00'),('2018-08-11 15:59:59','2018-08-11 19:59:59','WAVESBNB','4h','0.151700000000000','0.156800000000000','3.052773281849707','3.155404420527581','20.123752681936104','20.123752681936104','test','test','0.0'),('2018-08-11 23:59:59','2018-08-27 03:59:59','WAVESBNB','4h','0.155100000000000','0.214900000000000','3.075580201555902','4.261393844708984','19.82965958449969','19.829659584499691','test','test','0.0'),('2018-09-04 11:59:59','2018-09-04 15:59:59','WAVESBNB','4h','0.201500000000000','0.203500000000000','3.339094344478809','3.372236720106390','16.571187813790612','16.571187813790612','test','test','0.0'),('2018-09-04 19:59:59','2018-09-05 07:59:59','WAVESBNB','4h','0.202500000000000','0.200500000000000','3.346459316840493','3.313407866797624','16.525725021434532','16.525725021434532','test','test','0.98'),('2018-09-06 11:59:59','2018-09-06 15:59:59','WAVESBNB','4h','0.203500000000000','0.201500000000000','3.339114550164300','3.306297699548435','16.40842530793268','16.408425307932681','test','test','0.98'),('2018-09-08 19:59:59','2018-09-09 19:59:59','WAVESBNB','4h','0.201500000000000','0.197800000000000','3.331821916694108','3.270642060159278','16.535096360764804','16.535096360764804','test','test','1.83'),('2018-09-10 11:59:59','2018-09-10 15:59:59','WAVESBNB','4h','0.257700000000000','0.252546000000000','3.318226393019701','3.251861865159307','12.876315067984873','12.876315067984873','test','test','1.99'),('2018-09-10 19:59:59','2018-09-12 03:59:59','WAVESBNB','4h','0.234200000000000','0.229516000000000','3.303478720161836','3.237409145758599','14.10537455235626','14.105374552356260','test','test','1.99'),('2018-09-12 07:59:59','2018-09-12 11:59:59','WAVESBNB','4h','0.230700000000000','0.226086000000000','3.288796592516672','3.223020660666338','14.255728619491428','14.255728619491428','test','test','2.00'),('2018-09-12 15:59:59','2018-09-14 15:59:59','WAVESBNB','4h','0.241800000000000','0.236964000000000','3.274179718772154','3.208696124396711','13.540859051994019','13.540859051994019','test','test','2.00'),('2018-09-14 19:59:59','2018-09-14 23:59:59','WAVESBNB','4h','0.239900000000000','0.235102000000000','3.259627808910944','3.194435252732725','13.587443972117315','13.587443972117315','test','test','1.99'),('2018-09-15 03:59:59','2018-09-15 23:59:59','WAVESBNB','4h','0.226200000000000','0.229800000000000','3.245140574204673','3.296787373794138','14.346333219295635','14.346333219295635','test','test','0.0'),('2018-09-16 03:59:59','2018-09-16 07:59:59','WAVESBNB','4h','0.230500000000000','0.225890000000000','3.256617640780110','3.191485287964508','14.128493018568806','14.128493018568806','test','test','2.00'),('2018-09-16 11:59:59','2018-09-16 15:59:59','WAVESBNB','4h','0.225700000000000','0.226800000000000','3.242143784598865','3.257945105658053','14.364837326534625','14.364837326534625','test','test','0.0'),('2018-09-16 19:59:59','2018-09-17 11:59:59','WAVESBNB','4h','0.229400000000000','0.224812000000000','3.245655189278684','3.180742085493110','14.148453309846053','14.148453309846053','test','test','2.00'),('2018-09-17 19:59:59','2018-09-17 23:59:59','WAVESBNB','4h','0.227300000000000','0.224300000000000','3.231230055104113','3.188582936031027','14.215706357695174','14.215706357695174','test','test','1.31'),('2018-09-18 11:59:59','2018-09-18 19:59:59','WAVESBNB','4h','0.227800000000000','0.224000000000000','3.221752917532315','3.168009892569089','14.142901306112007','14.142901306112007','test','test','1.66'),('2018-09-18 23:59:59','2018-09-20 15:59:59','WAVESBNB','4h','0.226800000000000','0.228400000000000','3.209810023096043','3.232454185516473','14.15260151276915','14.152601512769150','test','test','0.0'),('2018-09-20 19:59:59','2018-09-20 23:59:59','WAVESBNB','4h','0.228100000000000','0.223538000000000','3.214842059189472','3.150545218005683','14.094002889914389','14.094002889914389','test','test','2.00'),('2018-09-23 15:59:59','2018-09-23 23:59:59','WAVESBNB','4h','0.229100000000000','0.225500000000000','3.200553872259741','3.150261449998130','13.97011729489193','13.970117294891930','test','test','1.57'),('2018-09-24 11:59:59','2018-09-24 15:59:59','WAVESBNB','4h','0.225500000000000','0.223000000000000','3.189377778423828','3.154018823008930','14.143582165959323','14.143582165959323','test','test','1.10'),('2018-09-25 19:59:59','2018-09-25 23:59:59','WAVESBNB','4h','0.224400000000000','0.221800000000000','3.181520232776073','3.144657698884728','14.177897650517258','14.177897650517258','test','test','1.15'),('2018-09-26 19:59:59','2018-09-27 11:59:59','WAVESBNB','4h','0.232600000000000','0.227948000000000','3.173328558577996','3.109861987406436','13.642857087609613','13.642857087609613','test','test','2.00'),('2018-09-27 15:59:59','2018-09-27 19:59:59','WAVESBNB','4h','0.225900000000000','0.225800000000000','3.159224876095427','3.157826370174181','13.985059212463158','13.985059212463158','test','test','0.04'),('2018-09-27 23:59:59','2018-09-28 03:59:59','WAVESBNB','4h','0.231300000000000','0.226674000000000','3.158914097001817','3.095735815061781','13.657216156514556','13.657216156514556','test','test','1.99'),('2018-10-17 07:59:59','2018-10-17 15:59:59','WAVESBNB','4h','0.206300000000000','0.204300000000000','3.144874478792920','3.114386117389208','15.244180701856129','15.244180701856129','test','test','0.96'),('2018-10-17 19:59:59','2018-10-18 07:59:59','WAVESBNB','4h','0.209000000000000','0.204820000000000','3.138099287369873','3.075337301622475','15.014829126171641','15.014829126171641','test','test','2.00'),('2018-10-18 19:59:59','2018-10-18 23:59:59','WAVESBNB','4h','0.204900000000000','0.205900000000000','3.124152179426007','3.139399383815592','15.247204389585198','15.247204389585198','test','test','0.0'),('2018-10-19 03:59:59','2018-10-19 15:59:59','WAVESBNB','4h','0.205000000000000','0.202400000000000','3.127540447068137','3.087874080422395','15.25629486374701','15.256294863747010','test','test','1.26'),('2018-10-21 07:59:59','2018-10-21 11:59:59','WAVESBNB','4h','0.204300000000000','0.204300000000000','3.118725698924638','3.118725698924638','15.265421923272823','15.265421923272823','test','test','0.0'),('2018-10-21 15:59:59','2018-10-21 19:59:59','WAVESBNB','4h','0.205000000000000','0.202600000000000','3.118725698924638','3.082213788303082','15.213296092315309','15.213296092315309','test','test','1.17'),('2018-10-23 15:59:59','2018-10-23 19:59:59','WAVESBNB','4h','0.204000000000000','0.201500000000000','3.110611941008737','3.072491696633631','15.248097750042827','15.248097750042827','test','test','1.22'),('2018-10-24 07:59:59','2018-10-24 11:59:59','WAVESBNB','4h','0.203000000000000','0.201200000000000','3.102140775592046','3.074634108616352','15.281481653162789','15.281481653162789','test','test','0.88'),('2018-10-24 15:59:59','2018-10-24 19:59:59','WAVESBNB','4h','0.203000000000000','0.201900000000000','3.096028182930782','3.079251675535590','15.251370359264934','15.251370359264934','test','test','0.54'),('2018-11-02 11:59:59','2018-11-02 15:59:59','WAVESBNB','4h','0.196600000000000','0.196200000000000','3.092300070176294','3.086008513573697','15.728891506491832','15.728891506491832','test','test','0.20'),('2018-11-15 19:59:59','2018-11-15 23:59:59','WAVESBNB','4h','0.187000000000000','0.183800000000000','3.090901946486829','3.038009506760851','16.528887414368068','16.528887414368068','test','test','1.71'),('2018-11-16 03:59:59','2018-11-16 07:59:59','WAVESBNB','4h','0.188200000000000','0.187200000000000','3.079148070992166','3.062787029169678','16.3610418224876','16.361041822487600','test','test','0.53'),('2018-11-16 11:59:59','2018-11-18 15:59:59','WAVESBNB','4h','0.188900000000000','0.189700000000000','3.075512283920502','3.088537216832818','16.2811661403944','16.281166140394401','test','test','0.37'),('2018-11-18 19:59:59','2018-11-20 11:59:59','WAVESBNB','4h','0.192200000000000','0.192200000000000','3.078406713456573','3.078406713456573','16.016684253155944','16.016684253155944','test','test','0.98'),('2018-11-20 15:59:59','2018-11-20 23:59:59','WAVESBNB','4h','0.191000000000000','0.187180000000000','3.078406713456573','3.016838579187442','16.117312635898287','16.117312635898287','test','test','1.99'),('2018-11-21 11:59:59','2018-11-21 15:59:59','WAVESBNB','4h','0.191300000000000','0.190900000000000','3.064724905841210','3.058316699033387','16.02051701955677','16.020517019556770','test','test','0.20'),('2018-11-22 11:59:59','2018-12-25 11:59:59','WAVESBNB','4h','0.192000000000000','0.589400000000000','3.063300859883916','9.403695452164479','15.954691978562064','15.954691978562064','test','test','0.62'),('2018-12-25 15:59:59','2018-12-25 19:59:59','WAVESBNB','4h','0.632700000000000','0.620046000000000','4.472277435946263','4.382831887227337','7.068559247583789','7.068559247583789','test','test','2.00'),('2018-12-25 23:59:59','2018-12-26 03:59:59','WAVESBNB','4h','0.605600000000000','0.593488000000000','4.452400647342058','4.363352634395217','7.352048625069449','7.352048625069449','test','test','2.00'),('2018-12-26 07:59:59','2018-12-26 11:59:59','WAVESBNB','4h','0.574600000000000','0.578000000000000','4.432612200020538','4.458840674576872','7.714257222451336','7.714257222451336','test','test','0.0'),('2018-12-26 15:59:59','2018-12-26 19:59:59','WAVESBNB','4h','0.623200000000000','0.610736000000000','4.438440749921946','4.349671934923506','7.122016607705305','7.122016607705305','test','test','2.00'),('2018-12-27 07:59:59','2018-12-27 11:59:59','WAVESBNB','4h','0.590500000000000','0.589400000000000','4.418714346588959','4.410483041286253','7.483004820641759','7.483004820641759','test','test','0.18'),('2018-12-27 15:59:59','2018-12-27 19:59:59','WAVESBNB','4h','0.587600000000000','0.579300000000000','4.416885167632802','4.354495537116545','7.516822953765829','7.516822953765829','test','test','1.41'),('2019-01-13 23:59:59','2019-01-14 03:59:59','WAVESBNB','4h','0.476700000000000','0.467166000000000','4.403020805295855','4.314960389189937','9.236460678195627','9.236460678195627','test','test','1.99'),('2019-01-14 07:59:59','2019-01-14 15:59:59','WAVESBNB','4h','0.468500000000000','0.468900000000000','4.383451823938985','4.387194365517588','9.356353946507973','9.356353946507973','test','test','0.0'),('2019-01-22 23:59:59','2019-01-24 23:59:59','WAVESBNB','4h','0.427900000000000','0.422000000000000','4.384283499845341','4.323831822703281','10.246046973230523','10.246046973230523','test','test','1.37'),('2019-01-25 11:59:59','2019-01-25 15:59:59','WAVESBNB','4h','0.433700000000000','0.437100000000000','4.370849793813773','4.405115159963109','10.078048867451633','10.078048867451633','test','test','0.0'),('2019-01-28 19:59:59','2019-02-01 03:59:59','WAVESBNB','4h','0.451700000000000','0.442666000000000','4.378464319624736','4.290895033232241','9.693301571008934','9.693301571008934','test','test','1.99'),('2019-02-26 23:59:59','2019-02-27 03:59:59','WAVESBNB','4h','0.280700000000000','0.279400000000000','4.359004478204182','4.338816712540963','15.529050510168085','15.529050510168085','test','test','0.46'),('2019-03-21 11:59:59','2019-03-22 11:59:59','WAVESBNB','4h','0.187300000000000','0.183900000000000','4.354518308056799','4.275472060072853','23.248896465866522','23.248896465866522','test','test','1.81'),('2019-03-24 03:59:59','2019-03-24 11:59:59','WAVESBNB','4h','0.187400000000000','0.183652000000000','4.336952475171478','4.250213425668049','23.142756004116745','23.142756004116745','test','test','2.00'),('2019-03-30 03:59:59','2019-03-30 07:59:59','WAVESBNB','4h','0.173900000000000','0.171000000000000','4.317677130837383','4.245674464480693','24.82850564023797','24.828505640237971','test','test','1.66'),('2019-04-07 03:59:59','2019-04-07 15:59:59','WAVESBNB','4h','0.163400000000000','0.160132000000000','4.301676538313674','4.215643007547401','26.32604980608124','26.326049806081240','test','test','1.99'),('2019-04-08 19:59:59','2019-04-08 23:59:59','WAVESBNB','4h','0.163900000000000','0.160622000000000','4.282557975921169','4.196906816402746','26.129090762179192','26.129090762179192','test','test','2.00'),('2019-04-11 15:59:59','2019-04-11 19:59:59','WAVESBNB','4h','0.164900000000000','0.161602000000000','4.263524384917075','4.178253897218734','25.85521155195315','25.855211551953150','test','test','1.99'),('2019-05-07 11:59:59','2019-05-07 15:59:59','WAVESBNB','4h','0.098200000000000','0.110200000000000','4.244575387650777','4.763260771070424','43.223781951637235','43.223781951637235','test','test','0.0'),('2019-05-07 19:59:59','2019-05-07 23:59:59','WAVESBNB','4h','0.108000000000000','0.105840000000000','4.359838806188476','4.272642030064707','40.36887783507848','40.368877835078479','test','test','1.99'),('2019-05-08 03:59:59','2019-05-08 07:59:59','WAVESBNB','4h','0.099800000000000','0.099900000000000','4.340461744827638','4.344810904892596','43.49160064957553','43.491600649575531','test','test','0.0'),('2019-05-08 11:59:59','2019-05-08 15:59:59','WAVESBNB','4h','0.106300000000000','0.104174000000000','4.341428224842073','4.254599660345231','40.8412815130957','40.841281513095701','test','test','2.00'),('2019-05-08 19:59:59','2019-05-13 07:59:59','WAVESBNB','4h','0.104200000000000','0.105800000000000','4.322132988287220','4.388499713635200','41.479203342487715','41.479203342487715','test','test','0.0'),('2019-05-23 23:59:59','2019-05-24 03:59:59','WAVESBNB','4h','0.105000000000000','0.102900000000000','4.336881149475660','4.250143526486147','41.30362999500629','41.303629995006290','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:13:03
