-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-14 15:59:59','2018-05-15 15:59:59','TNTBTC','4h','0.000013190000000','0.000012940000000','0.033333333333333','0.032701541571898','2527.1670457417235','2527.167045741723541','test','test','1.89'),('2018-05-15 19:59:59','2018-05-15 23:59:59','TNTBTC','4h','0.000012640000000','0.000012480000000','0.033192935164126','0.032772771427871','2626.0233515922123','2626.023351592212293','test','test','1.26'),('2018-06-02 11:59:59','2018-06-04 03:59:59','TNTBTC','4h','0.000010440000000','0.000010380000000','0.033099565444958','0.032909338057343','3170.4564602449977','3170.456460244997743','test','test','0.57'),('2018-06-23 15:59:59','2018-06-23 19:59:59','TNTBTC','4h','0.000009220000000','0.000009035600000','0.033057292692154','0.032396146838311','3585.389662923475','3585.389662923475043','test','test','1.99'),('2018-06-23 23:59:59','2018-06-24 03:59:59','TNTBTC','4h','0.000008370000000','0.000008202600000','0.032910371391300','0.032252163963474','3931.944013297544','3931.944013297544188','test','test','1.99'),('2018-07-02 15:59:59','2018-07-02 23:59:59','TNTBTC','4h','0.000007440000000','0.000007291200000','0.032764103074006','0.032108821012526','4403.77729489325','4403.777294893249746','test','test','2.00'),('2018-07-03 03:59:59','2018-07-03 07:59:59','TNTBTC','4h','0.000008300000000','0.000008134000000','0.032618484838121','0.031966115141359','3929.937932303775','3929.937932303775142','test','test','1.99'),('2018-07-03 11:59:59','2018-07-03 23:59:59','TNTBTC','4h','0.000007430000000','0.000007281400000','0.032473513794396','0.031824043518508','4370.594050389831','4370.594050389830954','test','test','1.99'),('2018-07-04 00:22:27','2018-07-04 11:59:59','TNTBTC','4h','0.000007170000000','0.000007370000000','0.032329187066421','0.033230977500631','4508.952171049','4508.952171048999844','test','test','0.0'),('2018-07-04 15:59:59','2018-07-05 19:59:59','TNTBTC','4h','0.000007650000000','0.000007497000000','0.032529584940690','0.031878993241876','4252.233325580421','4252.233325580420569','test','test','2.00'),('2018-07-05 23:59:59','2018-07-06 07:59:59','TNTBTC','4h','0.000007510000000','0.000007359800000','0.032385009007620','0.031737308827468','4312.251532306317','4312.251532306317131','test','test','1.99'),('2018-07-08 15:59:59','2018-07-08 23:59:59','TNTBTC','4h','0.000007370000000','0.000007290000000','0.032241075634253','0.031891104664003','4374.637128121212','4374.637128121212299','test','test','1.08'),('2018-08-27 23:59:59','2018-08-28 03:59:59','TNTBTC','4h','0.000002940000000','0.000002930000000','0.032163304307531','0.032053905313288','10939.89942433031','10939.899424330309557','test','test','0.34'),('2018-08-28 07:59:59','2018-09-02 11:59:59','TNTBTC','4h','0.000002950000000','0.000003110000000','0.032138993419922','0.033882125266426','10894.574040651374','10894.574040651374162','test','test','0.0'),('2018-09-02 15:59:59','2018-09-03 03:59:59','TNTBTC','4h','0.000003300000000','0.000003234000000','0.032526356052478','0.031875828931428','9856.47153105394','9856.471531053939543','test','test','1.99'),('2018-09-03 07:59:59','2018-09-03 11:59:59','TNTBTC','4h','0.000003120000000','0.000003057600000','0.032381794470022','0.031734158580622','10378.780278853346','10378.780278853346317','test','test','2.00'),('2018-09-15 19:59:59','2018-09-25 03:59:59','TNTBTC','4h','0.000002780000000','0.000003930000000','0.032237875383489','0.045573687142846','11596.358051614789','11596.358051614788565','test','test','0.0'),('2018-09-25 07:59:59','2018-09-25 11:59:59','TNTBTC','4h','0.000003760000000','0.000003840000000','0.035201389107791','0.035950354833489','9362.071571220924','9362.071571220923943','test','test','0.0'),('2018-09-25 15:59:59','2018-09-26 03:59:59','TNTBTC','4h','0.000003910000000','0.000003831800000','0.035367825935724','0.034660469417010','9045.479778957431','9045.479778957431336','test','test','2.00'),('2018-09-26 07:59:59','2018-09-29 07:59:59','TNTBTC','4h','0.000003950000000','0.000003960000000','0.035210635598232','0.035299776447848','8914.084961577608','8914.084961577607828','test','test','1.26'),('2018-09-29 11:59:59','2018-10-08 03:59:59','TNTBTC','4h','0.000004030000000','0.000004370000000','0.035230444675924','0.038202740256523','8742.045825291314','8742.045825291314031','test','test','0.0'),('2018-10-08 07:59:59','2018-10-09 15:59:59','TNTBTC','4h','0.000004350000000','0.000004390000000','0.035890954804946','0.036220986573267','8250.794208033562','8250.794208033561517','test','test','0.0'),('2018-10-09 19:59:59','2018-10-10 03:59:59','TNTBTC','4h','0.000004380000000','0.000004292400000','0.035964295197906','0.035245009293948','8211.026300891832','8211.026300891831852','test','test','1.99'),('2018-10-10 11:59:59','2018-10-11 03:59:59','TNTBTC','4h','0.000004540000000','0.000004449200000','0.035804453885916','0.035088364808198','7886.44358720607','7886.443587206070333','test','test','2.00'),('2018-10-13 19:59:59','2018-10-14 03:59:59','TNTBTC','4h','0.000004430000000','0.000004341400000','0.035645322979756','0.034932416520161','8046.34830242799','8046.348302427990347','test','test','2.00'),('2018-10-14 07:59:59','2018-10-14 23:59:59','TNTBTC','4h','0.000004360000000','0.000004290000000','0.035486899322068','0.034917155525613','8139.197092217482','8139.197092217482350','test','test','1.60'),('2018-10-15 03:59:59','2018-10-15 07:59:59','TNTBTC','4h','0.000004350000000','0.000004300000000','0.035360289589523','0.034953849479299','8128.802204487969','8128.802204487968993','test','test','1.14'),('2018-10-15 11:59:59','2018-10-15 19:59:59','TNTBTC','4h','0.000004380000000','0.000004292400000','0.035269969565028','0.034564570173727','8052.504466901471','8052.504466901470551','test','test','1.99'),('2018-10-15 23:59:59','2018-10-16 03:59:59','TNTBTC','4h','0.000004410000000','0.000004350000000','0.035113214144739','0.034635483340049','7962.180078172185','7962.180078172184949','test','test','1.36'),('2018-10-16 07:59:59','2018-10-27 15:59:59','TNTBTC','4h','0.000004550000000','0.000005140000000','0.035007051743697','0.039546427684088','7693.857526087277','7693.857526087276710','test','test','0.0'),('2018-10-27 19:59:59','2018-10-27 23:59:59','TNTBTC','4h','0.000005140000000','0.000005230000000','0.036015801952673','0.036646428835113','7006.965360442196','7006.965360442195561','test','test','0.0'),('2018-10-28 03:59:59','2018-10-29 15:59:59','TNTBTC','4h','0.000005250000000','0.000005210000000','0.036155941259882','0.035880467421711','6886.845954263195','6886.845954263195381','test','test','0.95'),('2018-10-29 19:59:59','2018-10-30 11:59:59','TNTBTC','4h','0.000005160000000','0.000005160000000','0.036094724851399','0.036094724851399','6995.101715387467','6995.101715387467266','test','test','0.0'),('2018-10-30 15:59:59','2018-10-30 23:59:59','TNTBTC','4h','0.000005800000000','0.000005684000000','0.036094724851399','0.035372830354371','6223.228422655056','6223.228422655056420','test','test','2.00'),('2018-10-31 03:59:59','2018-10-31 07:59:59','TNTBTC','4h','0.000005530000000','0.000005419400000','0.035934303852060','0.035215617775019','6498.065796032509','6498.065796032508842','test','test','2.00'),('2018-10-31 11:59:59','2018-10-31 15:59:59','TNTBTC','4h','0.000005360000000','0.000005370000000','0.035774595834940','0.035841339483886','6674.364894578273','6674.364894578273379','test','test','0.0'),('2018-10-31 19:59:59','2018-11-04 07:59:59','TNTBTC','4h','0.000005440000000','0.000005380000000','0.035789427756928','0.035394691421374','6578.938925905801','6578.938925905800716','test','test','1.28'),('2018-11-08 19:59:59','2018-11-09 03:59:59','TNTBTC','4h','0.000005460000000','0.000005350800000','0.035701708571249','0.034987674399824','6538.774463598697','6538.774463598697366','test','test','1.99'),('2018-11-09 07:59:59','2018-11-12 11:59:59','TNTBTC','4h','0.000005260000000','0.000005320000000','0.035543034310932','0.035948468162387','6757.230857591677','6757.230857591676795','test','test','0.0'),('2018-11-12 15:59:59','2018-11-12 19:59:59','TNTBTC','4h','0.000005400000000','0.000005292000000','0.035633130722367','0.034920468107920','6598.727911549381','6598.727911549381133','test','test','2.00'),('2018-11-28 19:59:59','2018-11-28 23:59:59','TNTBTC','4h','0.000003820000000','0.000003880000000','0.035474761252490','0.036031956455409','9286.586715311403','9286.586715311403168','test','test','0.0'),('2018-11-29 07:59:59','2018-11-29 15:59:59','TNTBTC','4h','0.000003850000000','0.000003870000000','0.035598582408694','0.035783510109518','9246.38504121916','9246.385041219160485','test','test','0.0'),('2018-11-29 19:59:59','2018-11-29 23:59:59','TNTBTC','4h','0.000003940000000','0.000003861200000','0.035639677453321','0.034926883904255','9045.60341454856','9045.603414548559158','test','test','1.99'),('2018-11-30 03:59:59','2018-11-30 07:59:59','TNTBTC','4h','0.000003850000000','0.000003990000000','0.035481278886862','0.036771507210021','9215.916593990187','9215.916593990186811','test','test','0.0'),('2018-11-30 11:59:59','2018-12-03 03:59:59','TNTBTC','4h','0.000003990000000','0.000003950000000','0.035767996292009','0.035409419888079','8964.410098247785','8964.410098247784845','test','test','1.00'),('2018-12-03 07:59:59','2018-12-03 15:59:59','TNTBTC','4h','0.000003990000000','0.000003910200000','0.035688312646691','0.034974546393757','8944.439259822278','8944.439259822278473','test','test','2.00'),('2018-12-04 15:59:59','2018-12-04 19:59:59','TNTBTC','4h','0.000004060000000','0.000003978800000','0.035529697923817','0.034819103965341','8751.157124092775','8751.157124092775121','test','test','2.00'),('2018-12-04 23:59:59','2018-12-05 03:59:59','TNTBTC','4h','0.000003970000000','0.000003940000000','0.035371788155266','0.035104495045780','8909.770316188022','8909.770316188021752','test','test','0.75'),('2018-12-05 07:59:59','2018-12-05 19:59:59','TNTBTC','4h','0.000003980000000','0.000003960000000','0.035312389686492','0.035134940492088','8872.459720224064','8872.459720224063858','test','test','0.50'),('2018-12-12 19:59:59','2018-12-13 19:59:59','TNTBTC','4h','0.000003840000000','0.000003763200000','0.035272956532180','0.034567497401536','9185.665763588486','9185.665763588485788','test','test','2.00'),('2018-12-13 23:59:59','2018-12-15 03:59:59','TNTBTC','4h','0.000003740000000','0.000003665200000','0.035116187836481','0.034413864079751','9389.355036492274','9389.355036492273939','test','test','2.00'),('2018-12-15 07:59:59','2018-12-15 11:59:59','TNTBTC','4h','0.000003740000000','0.000003690000000','0.034960115890541','0.034492734662058','9347.624569663398','9347.624569663397779','test','test','1.33'),('2018-12-15 15:59:59','2018-12-16 03:59:59','TNTBTC','4h','0.000003810000000','0.000003740000000','0.034856253395323','0.034215849789635','9148.622938404898','9148.622938404898377','test','test','1.83'),('2018-12-16 07:59:59','2018-12-16 11:59:59','TNTBTC','4h','0.000003740000000','0.000003710000000','0.034713941482948','0.034435487406882','9281.802535547475','9281.802535547474690','test','test','0.80'),('2018-12-17 07:59:59','2018-12-17 15:59:59','TNTBTC','4h','0.000003750000000','0.000003860000000','0.034652062799377','0.035668523308159','9240.550079833954','9240.550079833954442','test','test','0.0'),('2018-12-17 19:59:59','2018-12-17 23:59:59','TNTBTC','4h','0.000003720000000','0.000003645600000','0.034877942912440','0.034180384054191','9375.791105494623','9375.791105494623480','test','test','2.00'),('2018-12-24 15:59:59','2018-12-24 23:59:59','TNTBTC','4h','0.000003570000000','0.000003570000000','0.034722929832829','0.034722929832829','9726.310877543168','9726.310877543168317','test','test','0.0'),('2019-01-05 23:59:59','2019-01-06 03:59:59','TNTBTC','4h','0.000003170000000','0.000003140000000','0.034722929832829','0.034394321664064','10953.605625498141','10953.605625498141308','test','test','0.94'),('2019-01-06 11:59:59','2019-01-07 23:59:59','TNTBTC','4h','0.000003240000000','0.000003180000000','0.034649905795326','0.034008240873190','10694.415368927708','10694.415368927708187','test','test','1.85'),('2019-01-08 15:59:59','2019-01-08 19:59:59','TNTBTC','4h','0.000003220000000','0.000003155600000','0.034507313590407','0.033817167318599','10716.557015654244','10716.557015654243514','test','test','2.00'),('2019-01-09 07:59:59','2019-01-10 07:59:59','TNTBTC','4h','0.000003220000000','0.000003160000000','0.034353947752227','0.033713812079825','10668.927873362456','10668.927873362456012','test','test','1.86'),('2019-01-12 15:59:59','2019-01-13 19:59:59','TNTBTC','4h','0.000003280000000','0.000003214400000','0.034211695380582','0.033527461472970','10430.394933104335','10430.394933104334996','test','test','1.99'),('2019-01-14 03:59:59','2019-01-14 07:59:59','TNTBTC','4h','0.000003230000000','0.000003200000000','0.034059643401113','0.033743299963951','10544.78123873464','10544.781238734640283','test','test','0.92'),('2019-01-14 15:59:59','2019-01-20 15:59:59','TNTBTC','4h','0.000003260000000','0.000004210000000','0.033989344859521','0.043894215294044','10426.179404761146','10426.179404761145634','test','test','0.0'),('2019-01-20 19:59:59','2019-01-23 23:59:59','TNTBTC','4h','0.000004270000000','0.000004390000000','0.036190427178304','0.037207488363643','8475.509877823002','8475.509877823002171','test','test','0.0'),('2019-01-24 03:59:59','2019-01-27 03:59:59','TNTBTC','4h','0.000004350000000','0.000004320000000','0.036416440775046','0.036165292907632','8371.595580470397','8371.595580470397181','test','test','0.68'),('2019-02-01 15:59:59','2019-02-01 19:59:59','TNTBTC','4h','0.000004230000000','0.000004150000000','0.036360630137843','0.035672958645874','8595.8936496083','8595.893649608300620','test','test','1.89'),('2019-02-09 19:59:59','2019-02-09 23:59:59','TNTBTC','4h','0.000004060000000','0.000004000000000','0.036207814250739','0.035672723399743','8918.180849935687','8918.180849935686638','test','test','1.47'),('2019-02-10 03:59:59','2019-02-10 07:59:59','TNTBTC','4h','0.000004140000000','0.000004130000000','0.036088905172740','0.036001733904207','8717.126853318785','8717.126853318784924','test','test','0.24'),('2019-02-10 11:59:59','2019-02-11 15:59:59','TNTBTC','4h','0.000004150000000','0.000004067000000','0.036069533779732','0.035348143104137','8691.453922827095','8691.453922827095084','test','test','1.99'),('2019-02-11 19:59:59','2019-02-12 03:59:59','TNTBTC','4h','0.000004050000000','0.000003990000000','0.035909224740711','0.035377236226034','8866.47524462008','8866.475244620080048','test','test','1.48'),('2019-02-18 15:59:59','2019-02-18 19:59:59','TNTBTC','4h','0.000004020000000','0.000003939600000','0.035791005070783','0.035075184969367','8903.235092234605','8903.235092234604963','test','test','2.00'),('2019-02-18 23:59:59','2019-02-19 03:59:59','TNTBTC','4h','0.000003950000000','0.000003900000000','0.035631933937135','0.035180896798690','9020.742768894965','9020.742768894964684','test','test','1.26'),('2019-02-19 19:59:59','2019-02-20 07:59:59','TNTBTC','4h','0.000003960000000','0.000003900000000','0.035531703461925','0.034993344318562','8972.652389375029','8972.652389375029088','test','test','1.51'),('2019-02-20 11:59:59','2019-02-20 15:59:59','TNTBTC','4h','0.000003930000000','0.000003940000000','0.035412068096733','0.035502175140236','9010.704350313825','9010.704350313824762','test','test','0.0'),('2019-02-20 19:59:59','2019-02-21 11:59:59','TNTBTC','4h','0.000003930000000','0.000003930000000','0.035432091884178','0.035432091884178','9015.799461623013','9015.799461623013485','test','test','0.0'),('2019-02-21 15:59:59','2019-02-21 23:59:59','TNTBTC','4h','0.000003960000000','0.000004020000000','0.035432091884178','0.035968941761211','8947.49795055011','8947.497950550110545','test','test','0.25'),('2019-02-22 03:59:59','2019-02-24 07:59:59','TNTBTC','4h','0.000004010000000','0.000004040000000','0.035551391856852','0.035817362369497','8865.683754826046','8865.683754826046425','test','test','0.0'),('2019-02-25 11:59:59','2019-02-25 15:59:59','TNTBTC','4h','0.000004130000000','0.000004047400000','0.035610496415218','0.034898286486914','8622.396226445035','8622.396226445034699','test','test','1.99'),('2019-02-26 07:59:59','2019-02-27 15:59:59','TNTBTC','4h','0.000004050000000','0.000004000000000','0.035452227542262','0.035014545720753','8753.636430188037','8753.636430188036684','test','test','1.23'),('2019-02-27 19:59:59','2019-02-27 23:59:59','TNTBTC','4h','0.000004040000000','0.000004050000000','0.035354964915260','0.035442477204654','8751.228939420682','8751.228939420681854','test','test','0.0'),('2019-02-28 03:59:59','2019-02-28 07:59:59','TNTBTC','4h','0.000004040000000','0.000004000000000','0.035374412090680','0.035024170386812','8756.042596703079','8756.042596703078743','test','test','0.99'),('2019-02-28 23:59:59','2019-03-01 03:59:59','TNTBTC','4h','0.000004040000000','0.000004110000000','0.035296580600932','0.035908155017285','8736.777376468317','8736.777376468317016','test','test','0.0'),('2019-03-01 07:59:59','2019-03-01 15:59:59','TNTBTC','4h','0.000004090000000','0.000004020000000','0.035432486026788','0.034826062060559','8663.199517552132','8663.199517552131510','test','test','1.71'),('2019-03-02 03:59:59','2019-03-02 07:59:59','TNTBTC','4h','0.000004100000000','0.000004020000000','0.035297725145404','0.034608989045006','8609.201254976584','8609.201254976584096','test','test','1.95'),('2019-03-04 03:59:59','2019-03-04 07:59:59','TNTBTC','4h','0.000004060000000','0.000004040000000','0.035144672678649','0.034971546212252','8656.323319864256','8656.323319864255609','test','test','0.49'),('2019-03-04 11:59:59','2019-03-04 15:59:59','TNTBTC','4h','0.000004040000000','0.000004190000000','0.035106200130561','0.036409648155211','8689.65349766353','8689.653497663530288','test','test','0.0'),('2019-03-04 19:59:59','2019-03-05 19:59:59','TNTBTC','4h','0.000004130000000','0.000004210000000','0.035395855247150','0.036081489247095','8570.424999309816','8570.424999309816485','test','test','0.0'),('2019-03-05 23:59:59','2019-03-06 11:59:59','TNTBTC','4h','0.000004170000000','0.000004120000000','0.035548218358248','0.035121980728053','8524.752603896508','8524.752603896507935','test','test','1.67'),('2019-03-06 15:59:59','2019-03-07 03:59:59','TNTBTC','4h','0.000004150000000','0.000004100000000','0.035453498884872','0.035026348295898','8543.011779487175','8543.011779487174863','test','test','1.20'),('2019-03-07 07:59:59','2019-03-07 11:59:59','TNTBTC','4h','0.000004100000000','0.000004100000000','0.035358576531766','0.035358576531766','8624.0430565284','8624.043056528400484','test','test','0.0'),('2019-03-07 15:59:59','2019-03-11 15:59:59','TNTBTC','4h','0.000004090000000','0.000004270000000','0.035358576531766','0.036914699704313','8645.128736373214','8645.128736373213542','test','test','0.0'),('2019-03-11 19:59:59','2019-03-12 01:59:59','TNTBTC','4h','0.000004280000000','0.000004270000000','0.035704381681221','0.035620960228695','8342.145252621807','8342.145252621807231','test','test','0.23'),('2019-03-12 11:59:59','2019-03-21 15:59:59','TNTBTC','4h','0.000004610000000','0.000004570000000','0.035685843580660','0.035376205024646','7740.963900360086','7740.963900360085972','test','test','0.86'),('2019-03-25 23:59:59','2019-03-26 03:59:59','TNTBTC','4h','0.000004660000000','0.000004740000000','0.035617035012657','0.036228486257509','7643.140560655983','7643.140560655982881','test','test','0.0'),('2019-03-26 07:59:59','2019-03-26 11:59:59','TNTBTC','4h','0.000004670000000','0.000004600000000','0.035752913067068','0.035217002164564','7655.870035774826','7655.870035774825737','test','test','1.49'),('2019-03-26 15:59:59','2019-04-02 07:59:59','TNTBTC','4h','0.000004820000000','0.000004880000000','0.035633821755401','0.036077396300074','7392.909077884002','7392.909077884001817','test','test','0.20'),('2019-04-20 15:59:59','2019-04-20 19:59:59','TNTBTC','4h','0.000004070000000','0.000004030000000','0.035732393876439','0.035381215558243','8779.457954899097','8779.457954899096876','test','test','0.98');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:00:52
