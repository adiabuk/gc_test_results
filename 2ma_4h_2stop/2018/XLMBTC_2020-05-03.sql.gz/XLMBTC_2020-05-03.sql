-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-05-25 15:59:59','2018-05-25 19:59:59','XLMBTC','4h','0.000039240000000','0.000038570000000','0.033333333333333','0.032764186204553','849.4733265375468','849.473326537546768','test','test','1.70'),('2018-05-26 03:59:59','2018-05-26 07:59:59','XLMBTC','4h','0.000038790000000','0.000038810000000','0.033206856193604','0.033223977542505','856.0674450529631','856.067445052963080','test','test','0.0'),('2018-05-26 11:59:59','2018-05-26 15:59:59','XLMBTC','4h','0.000038730000000','0.000038790000000','0.033210660937805','0.033262110451264','857.491890983854','857.491890983853978','test','test','0.0'),('2018-05-26 19:59:59','2018-05-26 23:59:59','XLMBTC','4h','0.000038590000000','0.000038570000000','0.033222094163018','0.033204876182109','860.899045426737','860.899045426736961','test','test','0.05'),('2018-05-31 11:59:59','2018-06-01 19:59:59','XLMBTC','4h','0.000038600000000','0.000038080000000','0.033218267945038','0.032770767962359','860.5768897678237','860.576889767823673','test','test','1.34'),('2018-06-01 23:59:59','2018-06-04 15:59:59','XLMBTC','4h','0.000038380000000','0.000038500000000','0.033118823504443','0.033222373760319','862.9187989693243','862.918798969324257','test','test','0.0'),('2018-06-04 19:59:59','2018-06-05 03:59:59','XLMBTC','4h','0.000038520000000','0.000038120000000','0.033141834672415','0.032797682702816','860.3799239983156','860.379923998315576','test','test','1.03'),('2018-06-05 15:59:59','2018-06-05 23:59:59','XLMBTC','4h','0.000038690000000','0.000038550000000','0.033065356456949','0.032945709263773','854.6228083987768','854.622808398776783','test','test','0.36'),('2018-06-06 03:59:59','2018-06-06 07:59:59','XLMBTC','4h','0.000038420000000','0.000038320000000','0.033038768191798','0.032952774521335','859.9367046277574','859.936704627757422','test','test','0.26'),('2018-06-06 15:59:59','2018-06-06 19:59:59','XLMBTC','4h','0.000038730000000','0.000038560000000','0.033019658487251','0.032874723244730','852.5602501226728','852.560250122672755','test','test','0.43'),('2018-06-06 23:59:59','2018-06-07 15:59:59','XLMBTC','4h','0.000039100000000','0.000038440000000','0.032987450655580','0.032430629237864','843.6688147207104','843.668814720710429','test','test','1.68'),('2018-06-07 19:59:59','2018-06-07 23:59:59','XLMBTC','4h','0.000038900000000','0.000038122000000','0.032863712562754','0.032206438311499','844.8255157520309','844.825515752030924','test','test','1.99'),('2018-07-02 15:59:59','2018-07-03 19:59:59','XLMBTC','4h','0.000032210000000','0.000031750000000','0.032717651618031','0.032250401703585','1015.760683577481','1015.760683577481018','test','test','1.42'),('2018-07-04 15:59:59','2018-07-04 19:59:59','XLMBTC','4h','0.000032060000000','0.000032110000000','0.032613818303709','0.032664682025331','1017.2744324301101','1017.274432430110096','test','test','0.0'),('2018-07-04 23:59:59','2018-07-05 03:59:59','XLMBTC','4h','0.000031940000000','0.000032150000000','0.032625121352959','0.032839625907878','1021.4502615203087','1021.450261520308686','test','test','0.0'),('2018-07-05 07:59:59','2018-07-05 11:59:59','XLMBTC','4h','0.000031810000000','0.000031940000000','0.032672789031830','0.032806315047993','1027.123201252108','1027.123201252107947','test','test','0.0'),('2018-07-08 19:59:59','2018-07-08 23:59:59','XLMBTC','4h','0.000031800000000','0.000031350000000','0.032702461479866','0.032239690798547','1028.3792918196787','1028.379291819678656','test','test','1.41'),('2018-07-09 03:59:59','2018-07-09 07:59:59','XLMBTC','4h','0.000031770000000','0.000031680000000','0.032599623550684','0.032507273342325','1026.1134262097505','1026.113426209750514','test','test','0.28'),('2018-07-09 11:59:59','2018-07-09 15:59:59','XLMBTC','4h','0.000031750000000','0.000031590000000','0.032579101282160','0.032414923133966','1026.1134262097496','1026.113426209749605','test','test','0.50'),('2018-07-13 23:59:59','2018-07-14 03:59:59','XLMBTC','4h','0.000033070000000','0.000032408600000','0.032542617249228','0.031891764904243','984.0525324834459','984.052532483445930','test','test','2.00'),('2018-07-14 07:59:59','2018-07-23 19:59:59','XLMBTC','4h','0.000032270000000','0.000036490000000','0.032397983394786','0.036634719989952','1003.9660178117894','1003.966017811789357','test','test','0.52'),('2018-07-23 23:59:59','2018-07-24 03:59:59','XLMBTC','4h','0.000037040000000','0.000036560000000','0.033339480415934','0.032907435313352','900.093963713133','900.093963713133007','test','test','1.29'),('2018-07-24 07:59:59','2018-07-24 11:59:59','XLMBTC','4h','0.000036830000000','0.000036093400000','0.033243470393138','0.032578600985275','902.6193427406582','902.619342740658226','test','test','2.00'),('2018-07-24 15:59:59','2018-07-24 19:59:59','XLMBTC','4h','0.000036770000000','0.000036270000000','0.033095721635836','0.032645684626918','900.0740178361585','900.074017836158532','test','test','1.35'),('2018-07-25 11:59:59','2018-07-26 23:59:59','XLMBTC','4h','0.000037250000000','0.000038850000000','0.032995713411632','0.034412978954145','885.7909640706459','885.790964070645941','test','test','0.0'),('2018-07-27 03:59:59','2018-07-29 15:59:59','XLMBTC','4h','0.000038690000000','0.000037916200000','0.033310661309968','0.032644448083769','860.9630734031474','860.963073403147405','test','test','2.00'),('2018-08-10 19:59:59','2018-08-11 03:59:59','XLMBTC','4h','0.000035980000000','0.000035260400000','0.033162613926368','0.032499361647841','921.6957733843248','921.695773384324752','test','test','1.99'),('2018-08-11 11:59:59','2018-08-11 15:59:59','XLMBTC','4h','0.000034700000000','0.000034006000000','0.033015224531140','0.032354920040517','951.4473928282355','951.447392828235479','test','test','2.00'),('2018-08-11 23:59:59','2018-08-13 23:59:59','XLMBTC','4h','0.000034680000000','0.000035480000000','0.032868490199890','0.033626702199887','947.7649999968346','947.764999996834604','test','test','0.0'),('2018-08-14 03:59:59','2018-08-14 07:59:59','XLMBTC','4h','0.000035810000000','0.000035260000000','0.033036981755445','0.032529572094303','922.5630202581713','922.563020258171264','test','test','1.53'),('2018-08-14 11:59:59','2018-08-14 15:59:59','XLMBTC','4h','0.000035020000000','0.000035010000000','0.032924224052969','0.032914822504125','940.1548844365823','940.154884436582279','test','test','0.02'),('2018-08-14 19:59:59','2018-08-14 23:59:59','XLMBTC','4h','0.000035190000000','0.000035030000000','0.032922134819893','0.032772446227362','935.553703321758','935.553703321758007','test','test','0.45'),('2018-08-15 03:59:59','2018-08-15 11:59:59','XLMBTC','4h','0.000036040000000','0.000035319200000','0.032888870688219','0.032231093274455','912.5657793623506','912.565779362350554','test','test','2.00'),('2018-08-17 15:59:59','2018-08-18 07:59:59','XLMBTC','4h','0.000035500000000','0.000034980000000','0.032742697929605','0.032263086579650','922.3295191437995','922.329519143799530','test','test','1.46'),('2018-08-18 11:59:59','2018-08-18 15:59:59','XLMBTC','4h','0.000035420000000','0.000035140000000','0.032636117629615','0.032378124604875','921.4036597858521','921.403659785852142','test','test','0.79'),('2018-08-18 19:59:59','2018-08-18 23:59:59','XLMBTC','4h','0.000034940000000','0.000034740000000','0.032578785846339','0.032392301668627','932.4208885615149','932.420888561514857','test','test','0.57'),('2018-08-19 03:59:59','2018-08-19 07:59:59','XLMBTC','4h','0.000035010000000','0.000035020000000','0.032537344917959','0.032546638646870','929.3728911156494','929.372891115649395','test','test','0.0'),('2018-08-19 11:59:59','2018-08-19 19:59:59','XLMBTC','4h','0.000035430000000','0.000035280000000','0.032539410191050','0.032401648081858','918.4140612771726','918.414061277172550','test','test','0.42'),('2018-08-19 23:59:59','2018-08-20 07:59:59','XLMBTC','4h','0.000035200000000','0.000035080000000','0.032508796389008','0.032397970946773','923.5453519604418','923.545351960441849','test','test','0.34'),('2018-09-06 23:59:59','2018-09-07 03:59:59','XLMBTC','4h','0.000031930000000','0.000032050000000','0.032484168512955','0.032606251200758','1017.3557316929324','1017.355731692932409','test','test','0.0'),('2018-09-07 07:59:59','2018-09-07 11:59:59','XLMBTC','4h','0.000031590000000','0.000031540000000','0.032511297999134','0.032459839787676','1029.1642291590306','1029.164229159030583','test','test','0.15'),('2018-09-07 15:59:59','2018-09-08 19:59:59','XLMBTC','4h','0.000031890000000','0.000031450000000','0.032499862841032','0.032051448301990','1019.1239523685167','1019.123952368516711','test','test','1.37'),('2018-09-11 23:59:59','2018-09-12 03:59:59','XLMBTC','4h','0.000031880000000','0.000031242400000','0.032400215165689','0.031752210862375','1016.3179161132165','1016.317916113216484','test','test','2.00'),('2018-09-12 19:59:59','2018-09-12 23:59:59','XLMBTC','4h','0.000031760000000','0.000031124800000','0.032256214209397','0.031611089925209','1015.6238730918554','1015.623873091855444','test','test','2.00'),('2018-09-13 03:59:59','2018-09-14 11:59:59','XLMBTC','4h','0.000031760000000','0.000031124800000','0.032112853257356','0.031470596192209','1011.109989211447','1011.109989211446987','test','test','2.00'),('2018-09-15 15:59:59','2018-09-15 19:59:59','XLMBTC','4h','0.000031310000000','0.000031220000000','0.031970129465101','0.031878231935498','1021.0836622516983','1021.083662251698343','test','test','0.28'),('2018-09-16 11:59:59','2018-09-17 07:59:59','XLMBTC','4h','0.000031780000000','0.000031610000000','0.031949707791856','0.031778799977991','1005.3400815561849','1005.340081556184941','test','test','0.53'),('2018-09-17 11:59:59','2018-09-17 23:59:59','XLMBTC','4h','0.000032180000000','0.000031536400000','0.031911728277663','0.031273493712110','991.6634020405013','991.663402040501296','test','test','2.00'),('2018-09-18 11:59:59','2018-10-02 23:59:59','XLMBTC','4h','0.000032350000000','0.000037790000000','0.031769898374207','0.037112348054445','982.0679559260311','982.067955926031118','test','test','0.71'),('2018-10-08 23:59:59','2018-10-09 03:59:59','XLMBTC','4h','0.000037490000000','0.000037140000000','0.032957109414260','0.032649427677931','879.0906752269938','879.090675226993767','test','test','0.93'),('2018-10-17 07:59:59','2018-10-18 19:59:59','XLMBTC','4h','0.000035690000000','0.000036470000000','0.032888735695076','0.033607514452211','921.5112270965475','921.511227096547486','test','test','0.0'),('2018-10-18 23:59:59','2018-10-24 11:59:59','XLMBTC','4h','0.000036970000000','0.000037070000000','0.033048464307772','0.033137856962107','893.9265433533254','893.926543353325428','test','test','1.37'),('2018-10-24 15:59:59','2018-10-24 19:59:59','XLMBTC','4h','0.000036980000000','0.000036720000000','0.033068329342069','0.032835831623601','894.2219941067904','894.221994106790362','test','test','0.70'),('2018-11-02 23:59:59','2018-11-14 01:59:59','XLMBTC','4h','0.000037030000000','0.000040050000000','0.033016663182410','0.035709353509466','891.6193135946409','891.619313594640857','test','test','0.24'),('2018-11-14 11:59:59','2018-11-14 15:59:59','XLMBTC','4h','0.000040050000000','0.000039249000000','0.033615038810644','0.032942738034431','839.3268117514164','839.326811751416358','test','test','2.00'),('2018-11-14 23:59:59','2018-11-15 03:59:59','XLMBTC','4h','0.000040760000000','0.000040300000000','0.033465638638152','0.033087959693757','821.0411834679206','821.041183467920632','test','test','1.12'),('2018-11-15 07:59:59','2018-11-15 15:59:59','XLMBTC','4h','0.000041210000000','0.000041010000000','0.033381709983842','0.033219702170283','810.0390677952547','810.039067795254709','test','test','0.48'),('2018-11-15 19:59:59','2018-11-20 11:59:59','XLMBTC','4h','0.000041980000000','0.000044250000000','0.033345708247496','0.035148823009807','794.3236838374465','794.323683837446538','test','test','0.0'),('2018-11-20 15:59:59','2018-11-20 23:59:59','XLMBTC','4h','0.000044590000000','0.000043698200000','0.033746400416898','0.033071472408560','756.8154388180859','756.815438818085909','test','test','2.00'),('2018-11-21 03:59:59','2018-11-22 23:59:59','XLMBTC','4h','0.000042970000000','0.000042740000000','0.033596416415046','0.033416589191973','781.8574916231222','781.857491623122201','test','test','0.53'),('2018-12-01 11:59:59','2018-12-01 15:59:59','XLMBTC','4h','0.000039980000000','0.000039730000000','0.033556454809918','0.033346622050977','839.3310357658385','839.331035765838465','test','test','0.62'),('2018-12-23 23:59:59','2018-12-24 03:59:59','XLMBTC','4h','0.000031720000000','0.000031810000000','0.033509825307931','0.033604903626901','1056.425766328226','1056.425766328226018','test','test','0.0'),('2018-12-24 07:59:59','2018-12-24 19:59:59','XLMBTC','4h','0.000033080000000','0.000032418400000','0.033530953823258','0.032860334746793','1013.6322195664451','1013.632219566445087','test','test','2.00'),('2018-12-24 23:59:59','2018-12-25 03:59:59','XLMBTC','4h','0.000032600000000','0.000031948000000','0.033381927361821','0.032714288814585','1023.98550189636','1023.985501896360006','test','test','1.99'),('2018-12-25 07:59:59','2018-12-25 11:59:59','XLMBTC','4h','0.000031780000000','0.000031580000000','0.033233563240213','0.033024415579796','1045.738302083491','1045.738302083490908','test','test','0.62'),('2018-12-25 23:59:59','2018-12-26 03:59:59','XLMBTC','4h','0.000031730000000','0.000031910000000','0.033187085982343','0.033375351834118','1045.9213987501698','1045.921398750169828','test','test','0.0'),('2018-12-26 07:59:59','2018-12-26 11:59:59','XLMBTC','4h','0.000031530000000','0.000030910000000','0.033228922838293','0.032575515538587','1053.8827414618743','1053.882741461874275','test','test','1.96'),('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.033083721216136','0.032616988928638','1085.4239244139108','1085.423924413910754','test','test','1.41'),('2019-01-08 07:59:59','2019-01-08 11:59:59','XLMBTC','4h','0.000030310000000','0.000030530000000','0.032980002930025','0.033219382693951','1088.0898360285494','1088.089836028549371','test','test','0.0'),('2019-01-08 15:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030690000000','0.000030460000000','0.033033198433120','0.032785637806218','1076.350551747149','1076.350551747148984','test','test','0.97'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.032978184960475','0.032476087554209','1068.2923537568872','1068.292353756887223','test','test','1.52'),('2019-01-13 03:59:59','2019-01-13 15:59:59','XLMBTC','4h','0.000030740000000','0.000030125200000','0.032866607759083','0.032209275603901','1069.1804736201257','1069.180473620125667','test','test','1.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.032720533946820','0.032381063882445','1095.0647237891567','1095.064723789156687','test','test','1.03'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.032645096154737','0.032805621884599','1459.3248169305616','1459.324816930561610','test','test','0.0'),('2019-02-20 07:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022410000000','0.000021961800000','0.032680768539150','0.032027153168367','1458.3118491365663','1458.311849136566252','test','test','2.00'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.032535520678976','0.032319767889328','1438.3519309892329','1438.351930989232869','test','test','0.66'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XLMBTC','4h','0.000022290000000','0.000022160000000','0.032487575614610','0.032298101194247','1457.4955412566273','1457.495541256627348','test','test','0.58'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.032445470187863','0.032270797400849','1455.606558450556','1455.606558450555895','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022393000000','0.032406654012971','0.031758520932712','1418.2343112897545','1418.234311289754487','test','test','1.99'),('2019-03-04 07:59:59','2019-03-04 11:59:59','XLMBTC','4h','0.000022260000000','0.000021980000000','0.032262624439580','0.031856805264239','1449.3541976451033','1449.354197645103341','test','test','1.25'),('2019-03-05 23:59:59','2019-03-06 03:59:59','XLMBTC','4h','0.000022210000000','0.000021920000000','0.032172442400615','0.031752360982507','1448.556614165481','1448.556614165481051','test','test','1.30'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.032079090974369','0.037580819841791','1432.7418925577986','1432.741892557798565','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026656000000','0.033301697389352','0.032635663441565','1224.327109902639','1224.327109902638995','test','test','2.00'),('2019-03-23 15:59:59','2019-03-23 19:59:59','XLMBTC','4h','0.000026680000000','0.000026850000000','0.033153689845399','0.033364938993589','1242.6420481783775','1242.642048178377536','test','test','0.0'),('2019-03-23 23:59:59','2019-03-24 03:59:59','XLMBTC','4h','0.000026640000000','0.000026490000000','0.033200634100552','0.033013693593229','1246.2700488195362','1246.270048819536214','test','test','0.56'),('2019-03-27 11:59:59','2019-03-27 15:59:59','XLMBTC','4h','0.000026370000000','0.000026410000000','0.033159091765592','0.033209389970773','1257.4551295256647','1257.455129525664688','test','test','0.0'),('2019-03-27 19:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026520000000','0.000026340000000','0.033170269144521','0.032945131571142','1250.7642965505615','1250.764296550561539','test','test','0.67'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XLMBTC','4h','0.000026440000000','0.000026380000000','0.033120238572659','0.033045079181042','1252.6565269538157','1252.656526953815728','test','test','0.22'),('2019-03-31 23:59:59','2019-04-01 03:59:59','XLMBTC','4h','0.000026380000000','0.000026650000000','0.033103536485633','0.033442352059974','1254.8724975600035','1254.872497560003467','test','test','0.0'),('2019-04-01 07:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026510000000','0.000025979800000','0.033178828835486','0.032515252258776','1251.5589903993377','1251.558990399337745','test','test','2.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.033031367373995','0.032475675356357','1292.3070177619459','1292.307017761945872','test','test','1.68'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.032907880258965','0.036771902328082','2123.089048965462','2123.089048965462098','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018051600000','0.033766551829880','0.033091220793282','1833.1461362583905','1833.146136258390470','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018531800000','0.033616478266191','0.032944148700867','1777.7090569112167','1777.709056911216749','test','test','1.99'),('2019-05-16 23:59:59','2019-05-17 07:59:59','XLMBTC','4h','0.000017540000000','0.000017189200000','0.033467071696119','0.032797730262197','1908.042856107133','1908.042856107133048','test','test','2.00'),('2019-05-17 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016920000000','0.000016581600000','0.033318329155248','0.032651962572143','1969.1683897900448','1969.168389790044785','test','test','2.0');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:24:46
