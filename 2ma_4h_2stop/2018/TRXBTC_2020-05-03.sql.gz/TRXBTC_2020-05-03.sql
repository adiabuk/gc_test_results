-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2018-04-17 15:59:59','2018-05-04 11:59:59','TRXBTC','4h','0.000005340000000','0.000008530000000','0.033333333333333','0.053245942571785','6242.197253433209','6242.197253433208971','test','test','1.12'),('2018-05-04 19:59:59','2018-05-06 03:59:59','TRXBTC','4h','0.000008870000000','0.000008692600000','0.037758357608545','0.037003190456374','4256.86106071532','4256.861060715319582','test','test','1.99'),('2018-05-06 15:59:59','2018-05-07 03:59:59','TRXBTC','4h','0.000008780000000','0.000008630000000','0.037590542685840','0.036948335236765','4281.38299383146','4281.382993831460226','test','test','1.70'),('2018-05-07 15:59:59','2018-05-09 07:59:59','TRXBTC','4h','0.000008700000000','0.000008750000000','0.037447829919379','0.037663047332709','4304.3482665953','4304.348266595299719','test','test','0.0'),('2018-05-09 11:59:59','2018-05-09 15:59:59','TRXBTC','4h','0.000008740000000','0.000008780000000','0.037495656011230','0.037667260844233','4290.12082508355','4290.120825083549789','test','test','0.0'),('2018-05-09 19:59:59','2018-05-09 23:59:59','TRXBTC','4h','0.000008680000000','0.000008610000000','0.037533790418564','0.037231098560350','4324.169403060394','4324.169403060393961','test','test','0.80'),('2018-05-13 15:59:59','2018-05-14 03:59:59','TRXBTC','4h','0.000008530000000','0.000008359400000','0.037466525561183','0.036717195049959','4392.324215847987','4392.324215847987034','test','test','1.99'),('2018-05-16 19:59:59','2018-05-17 15:59:59','TRXBTC','4h','0.000008410000000','0.000008300000000','0.037300007669800','0.036812135988031','4435.197106991702','4435.197106991701730','test','test','1.30'),('2018-05-18 19:59:59','2018-05-18 23:59:59','TRXBTC','4h','0.000008350000000','0.000008360000000','0.037191591740518','0.037236132568950','4454.082843175835','4454.082843175834569','test','test','0.0'),('2018-05-19 15:59:59','2018-05-19 19:59:59','TRXBTC','4h','0.000008340000000','0.000008320000000','0.037201489702392','0.037112277496871','4460.610276066187','4460.610276066186998','test','test','0.23'),('2018-05-19 23:59:59','2018-05-20 03:59:59','TRXBTC','4h','0.000008350000000','0.000008440000000','0.037181664767832','0.037582425226407','4452.893984171471','4452.893984171470947','test','test','0.0'),('2018-05-20 07:59:59','2018-05-23 19:59:59','TRXBTC','4h','0.000008570000000','0.000009190000000','0.037270722647515','0.039967087646518','4348.975804844237','4348.975804844237246','test','test','0.0'),('2018-05-23 23:59:59','2018-05-28 07:59:59','TRXBTC','4h','0.000009050000000','0.000008990000000','0.037869914869516','0.037618843610713','4184.520980056992','4184.520980056991903','test','test','0.66'),('2018-06-19 11:59:59','2018-06-20 03:59:59','TRXBTC','4h','0.000007130000000','0.000007010000000','0.037814121256448','0.037177698458303','5303.523317874956','5303.523317874955865','test','test','1.68'),('2018-06-20 07:59:59','2018-06-20 11:59:59','TRXBTC','4h','0.000007300000000','0.000007154000000','0.037672693967972','0.036919240088613','5160.643009311201','5160.643009311201240','test','test','1.99'),('2018-06-20 15:59:59','2018-06-22 07:59:59','TRXBTC','4h','0.000007290000000','0.000007144200000','0.037505259772559','0.036755154577108','5144.75442696278','5144.754426962779689','test','test','2.00'),('2018-06-22 11:59:59','2018-06-22 15:59:59','TRXBTC','4h','0.000007110000000','0.000007000000000','0.037338569729125','0.036760898467493','5251.556923927581','5251.556923927581011','test','test','1.54'),('2018-06-23 03:59:59','2018-06-23 07:59:59','TRXBTC','4h','0.000007070000000','0.000007100000000','0.037210198337651','0.037368091682790','5263.111504618293','5263.111504618293111','test','test','0.0'),('2018-06-23 11:59:59','2018-06-24 03:59:59','TRXBTC','4h','0.000007140000000','0.000007000000000','0.037245285747682','0.036514986027139','5216.4265753056325','5216.426575305632468','test','test','1.96'),('2018-07-16 11:59:59','2018-07-16 15:59:59','TRXBTC','4h','0.000005510000000','0.000005470000000','0.037082996920895','0.036813791861578','6730.126482921031','6730.126482921031311','test','test','0.72'),('2018-07-16 19:59:59','2018-07-17 07:59:59','TRXBTC','4h','0.000005510000000','0.000005470000000','0.037023173574380','0.036754402804330','6719.269251248638','6719.269251248638284','test','test','0.72'),('2018-07-17 15:59:59','2018-07-17 19:59:59','TRXBTC','4h','0.000005490000000','0.000005450000000','0.036963446736591','0.036694132006270','6732.868258031168','6732.868258031167898','test','test','0.72'),('2018-07-29 19:59:59','2018-07-30 03:59:59','TRXBTC','4h','0.000004820000000','0.000004723600000','0.036903599018742','0.036165527038367','7656.348344137345','7656.348344137344611','test','test','2.00'),('2018-08-18 03:59:59','2018-08-18 07:59:59','TRXBTC','4h','0.000003550000000','0.000003479000000','0.036739583023103','0.036004791362641','10349.178316367073','10349.178316367073421','test','test','2.00'),('2018-08-25 23:59:59','2018-08-26 03:59:59','TRXBTC','4h','0.000003330000000','0.000003263400000','0.036576295987445','0.035844770067696','10983.872668902368','10983.872668902367877','test','test','1.99'),('2018-08-26 11:59:59','2018-08-30 11:59:59','TRXBTC','4h','0.000003320000000','0.000003440000000','0.036413734671945','0.037729893756473','10967.992371067803','10967.992371067803106','test','test','0.0'),('2018-08-30 15:59:59','2018-08-30 19:59:59','TRXBTC','4h','0.000003480000000','0.000003460000000','0.036706214468507','0.036495259212941','10547.762778306575','10547.762778306574546','test','test','0.57'),('2018-08-30 23:59:59','2018-09-02 11:59:59','TRXBTC','4h','0.000003570000000','0.000003498600000','0.036659335522826','0.035926148812369','10268.72143496514','10268.721434965140361','test','test','1.99'),('2018-09-19 07:59:59','2018-09-19 11:59:59','TRXBTC','4h','0.000003150000000','0.000003087000000','0.036496405142724','0.035766477039870','11586.160362769522','11586.160362769522180','test','test','2.00'),('2018-09-19 15:59:59','2018-09-19 19:59:59','TRXBTC','4h','0.000003090000000','0.000003080000000','0.036334198897645','0.036216612493446','11758.640419949945','11758.640419949944771','test','test','0.32'),('2018-09-20 03:59:59','2018-09-25 03:59:59','TRXBTC','4h','0.000003100000000','0.000003270000000','0.036308068585601','0.038299156217715','11712.280188903584','11712.280188903583621','test','test','0.0'),('2018-09-25 23:59:59','2018-09-26 03:59:59','TRXBTC','4h','0.000003310000000','0.000003243800000','0.036750532503849','0.036015521853772','11102.879910528298','11102.879910528297842','test','test','1.99'),('2018-09-26 11:59:59','2018-09-26 15:59:59','TRXBTC','4h','0.000003290000000','0.000003350000000','0.036587196803832','0.037254440514540','11120.728511802903','11120.728511802903085','test','test','0.0'),('2018-09-26 19:59:59','2018-09-26 23:59:59','TRXBTC','4h','0.000003270000000','0.000003240000000','0.036735473183989','0.036398450494228','11234.089658712197','11234.089658712196979','test','test','0.91'),('2018-09-27 15:59:59','2018-09-28 11:59:59','TRXBTC','4h','0.000003380000000','0.000003312400000','0.036660579252931','0.035927367667872','10846.325222760619','10846.325222760618999','test','test','2.0'),('2018-09-28 15:59:59','2018-09-28 19:59:59','TRXBTC','4h','0.000003300000000','0.000003330000000','0.036497643345140','0.036829440102823','11059.891922769695','11059.891922769695157','test','test','0.0'),('2018-09-28 23:59:59','2018-09-29 03:59:59','TRXBTC','4h','0.000003310000000','0.000003290000000','0.036571375957958','0.036350400876641','11048.75406584847','11048.754065848470418','test','test','0.60'),('2018-09-29 07:59:59','2018-10-01 07:59:59','TRXBTC','4h','0.000003310000000','0.000003330000000','0.036522270384332','0.036742948755234','11033.91854511554','11033.918545115540837','test','test','0.0'),('2018-10-01 11:59:59','2018-10-01 15:59:59','TRXBTC','4h','0.000003340000000','0.000003320000000','0.036571310022311','0.036352320141938','10949.494018655887','10949.494018655886975','test','test','0.59'),('2018-10-01 19:59:59','2018-10-03 03:59:59','TRXBTC','4h','0.000003350000000','0.000003310000000','0.036522645604450','0.036086554313651','10902.282269985071','10902.282269985071252','test','test','1.19'),('2018-10-03 07:59:59','2018-10-03 11:59:59','TRXBTC','4h','0.000003310000000','0.000003320000000','0.036425736428717','0.036535783970798','11004.754208071565','11004.754208071564790','test','test','0.0'),('2018-10-03 15:59:59','2018-10-03 19:59:59','TRXBTC','4h','0.000003320000000','0.000003310000000','0.036450191438068','0.036340401704821','10978.973324719344','10978.973324719343509','test','test','0.30'),('2018-10-03 23:59:59','2018-10-11 03:59:59','TRXBTC','4h','0.000003320000000','0.000003630000000','0.036425793719569','0.039826997350011','10971.624614327977','10971.624614327976815','test','test','0.0'),('2018-10-12 15:59:59','2018-10-12 23:59:59','TRXBTC','4h','0.000003670000000','0.000003620000000','0.037181616748556','0.036675055212472','10131.230721677384','10131.230721677384281','test','test','1.36'),('2018-10-13 03:59:59','2018-10-15 03:59:59','TRXBTC','4h','0.000003730000000','0.000003730000000','0.037069047518315','0.037069047518315','9938.0824445885','9938.082444588499129','test','test','0.26'),('2018-10-15 07:59:59','2018-10-16 23:59:59','TRXBTC','4h','0.000003710000000','0.000003690000000','0.037069047518315','0.036869214378055','9991.657013022937','9991.657013022937463','test','test','0.53'),('2018-10-17 03:59:59','2018-10-17 07:59:59','TRXBTC','4h','0.000003690000000','0.000003710000000','0.037024640153813','0.037225315710202','10033.777819461486','10033.777819461485706','test','test','0.0'),('2018-10-17 11:59:59','2018-10-17 15:59:59','TRXBTC','4h','0.000003680000000','0.000003690000000','0.037069234721899','0.037169966337991','10073.161609211775','10073.161609211774703','test','test','0.0'),('2018-10-17 23:59:59','2018-10-18 07:59:59','TRXBTC','4h','0.000003710000000','0.000003760000000','0.037091619525475','0.037591506581074','9997.74111198796','9997.741111987959812','test','test','0.0'),('2018-10-18 11:59:59','2018-10-18 19:59:59','TRXBTC','4h','0.000003800000000','0.000003724000000','0.037202705537831','0.036458651427074','9790.185667850174','9790.185667850173559','test','test','2.00'),('2018-10-18 23:59:59','2018-10-19 11:59:59','TRXBTC','4h','0.000003740000000','0.000003710000000','0.037037360179885','0.036740269055447','9903.037481252582','9903.037481252582438','test','test','0.80'),('2018-10-19 15:59:59','2018-10-21 23:59:59','TRXBTC','4h','0.000003700000000','0.000003730000000','0.036971339930010','0.037271107551064','9992.254035137716','9992.254035137715618','test','test','0.0'),('2018-11-02 23:59:59','2018-11-03 03:59:59','TRXBTC','4h','0.000003580000000','0.000003570000000','0.037037954956910','0.036934496982170','10345.79747399733','10345.797473997330599','test','test','0.27'),('2018-11-04 11:59:59','2018-11-08 03:59:59','TRXBTC','4h','0.000003620000000','0.000003610000000','0.037014964295857','0.036912713013272','10225.128258524062','10225.128258524062403','test','test','0.27'),('2018-11-08 11:59:59','2018-11-08 15:59:59','TRXBTC','4h','0.000003650000000','0.000003630000000','0.036992241788616','0.036789544573336','10134.860764004381','10134.860764004381053','test','test','0.54'),('2018-11-28 15:59:59','2019-01-01 03:59:59','TRXBTC','4h','0.000003470000000','0.000005050000000','0.036947197962998','0.053770417784767','10647.60748213205','10647.607482132050791','test','test','0.86'),('2019-01-01 07:59:59','2019-01-02 03:59:59','TRXBTC','4h','0.000005130000000','0.000005060000000','0.040685691256725','0.040130525878953','7930.933968172448','7930.933968172447749','test','test','1.36'),('2019-01-02 07:59:59','2019-01-03 07:59:59','TRXBTC','4h','0.000005070000000','0.000005110000000','0.040562321172775','0.040882339485775','8000.457825004996','8000.457825004996266','test','test','0.0'),('2019-01-03 11:59:59','2019-01-13 03:59:59','TRXBTC','4h','0.000005120000000','0.000006210000000','0.040633436353442','0.049283914014624','7936.21803778164','7936.218037781640305','test','test','0.0'),('2019-01-13 07:59:59','2019-01-13 11:59:59','TRXBTC','4h','0.000006290000000','0.000006270000000','0.042555764722594','0.042420452275145','6765.622372431409','6765.622372431408621','test','test','0.31'),('2019-01-14 03:59:59','2019-01-19 03:59:59','TRXBTC','4h','0.000006470000000','0.000006620000000','0.042525695289827','0.043511607854506','6572.7504311942985','6572.750431194298471','test','test','0.0'),('2019-01-19 07:59:59','2019-01-19 19:59:59','TRXBTC','4h','0.000006650000000','0.000006600000000','0.042744786970867','0.042423397595146','6427.7875144160735','6427.787514416073464','test','test','0.75'),('2019-01-19 23:59:59','2019-01-20 03:59:59','TRXBTC','4h','0.000006590000000','0.000006620000000','0.042673367109596','0.042867631299776','6475.47300600843','6475.473006008430275','test','test','0.0'),('2019-01-20 11:59:59','2019-01-20 15:59:59','TRXBTC','4h','0.000006600000000','0.000006590000000','0.042716536929636','0.042651814903985','6472.202565096296','6472.202565096295984','test','test','0.15'),('2019-01-20 19:59:59','2019-01-28 15:59:59','TRXBTC','4h','0.000006680000000','0.000007590000000','0.042702154257269','0.048519363894113','6392.538062465368','6392.538062465368057','test','test','0.44'),('2019-01-28 19:59:59','2019-01-31 11:59:59','TRXBTC','4h','0.000007650000000','0.000007540000000','0.043994867509901','0.043362261571850','5750.9630731896295','5750.963073189629540','test','test','1.43'),('2019-01-31 15:59:59','2019-01-31 19:59:59','TRXBTC','4h','0.000007530000000','0.000007490000000','0.043854288412556','0.043621330705185','5823.942684270385','5823.942684270385143','test','test','0.53'),('2019-02-01 23:59:59','2019-02-02 03:59:59','TRXBTC','4h','0.000007560000000','0.000007470000000','0.043802520033140','0.043281061461317','5793.984131367754','5793.984131367754344','test','test','1.19'),('2019-02-04 11:59:59','2019-02-05 03:59:59','TRXBTC','4h','0.000007880000000','0.000007722400000','0.043686640350513','0.042812907543503','5543.989892197066','5543.989892197066183','test','test','1.99'),('2019-02-05 07:59:59','2019-02-05 19:59:59','TRXBTC','4h','0.000007800000000','0.000007644000000','0.043492477504511','0.042622627954421','5575.958654424443','5575.958654424443012','test','test','1.99'),('2019-02-05 23:59:59','2019-02-06 03:59:59','TRXBTC','4h','0.000007550000000','0.000007470000000','0.043299177604491','0.042840378371596','5734.990411190815','5734.990411190815394','test','test','1.05'),('2019-02-06 07:59:59','2019-02-06 11:59:59','TRXBTC','4h','0.000007680000000','0.000007570000000','0.043197222219403','0.042578512005323','5624.638309818084','5624.638309818084053','test','test','1.43'),('2019-02-06 15:59:59','2019-02-06 19:59:59','TRXBTC','4h','0.000007560000000','0.000007520000000','0.043059731060718','0.042831901795846','5695.7316217881535','5695.731621788153461','test','test','0.52'),('2019-02-07 03:59:59','2019-02-07 07:59:59','TRXBTC','4h','0.000007660000000','0.000007570000000','0.043009102335191','0.042503773456579','5614.765317910096','5614.765317910096201','test','test','1.17'),('2019-02-07 11:59:59','2019-02-07 15:59:59','TRXBTC','4h','0.000007580000000','0.000007550000000','0.042896807028833','0.042727030747716','5659.209370558457','5659.209370558456612','test','test','0.39'),('2019-02-07 19:59:59','2019-02-07 23:59:59','TRXBTC','4h','0.000007590000000','0.000007560000000','0.042859078966363','0.042689675492188','5646.782472511549','5646.782472511548804','test','test','0.39'),('2019-02-08 11:59:59','2019-02-08 15:59:59','TRXBTC','4h','0.000007580000000','0.000007590000000','0.042821433749879','0.042877926406541','5649.265666210992','5649.265666210992094','test','test','0.0'),('2019-03-23 11:59:59','2019-03-24 19:59:59','TRXBTC','4h','0.000005980000000','0.000005860400000','0.042833987673582','0.041977307920110','7162.874192906687','7162.874192906687313','test','test','2.00'),('2019-03-24 23:59:59','2019-03-25 03:59:59','TRXBTC','4h','0.000005820000000','0.000005730000000','0.042643614395033','0.041984177059027','7327.081511173997','7327.081511173996660','test','test','1.54'),('2019-03-27 15:59:59','2019-03-27 19:59:59','TRXBTC','4h','0.000005780000000','0.000005800000000','0.042497072764809','0.042644121459497','7352.434734396039','7352.434734396038948','test','test','0.0'),('2019-03-27 23:59:59','2019-03-28 03:59:59','TRXBTC','4h','0.000005770000000','0.000005710000000','0.042529750252518','0.042087499816617','7370.8405983565945','7370.840598356594455','test','test','1.03'),('2019-03-28 23:59:59','2019-03-29 03:59:59','TRXBTC','4h','0.000005750000000','0.000005750000000','0.042431472377873','0.042431472377873','7379.386500499633','7379.386500499633257','test','test','0.0'),('2019-03-29 07:59:59','2019-03-29 11:59:59','TRXBTC','4h','0.000005800000000','0.000005684000000','0.042431472377873','0.041582842930316','7315.771099633256','7315.771099633256199','test','test','2.00'),('2019-04-01 15:59:59','2019-04-02 07:59:59','TRXBTC','4h','0.000005810000000','0.000005693800000','0.042242888056194','0.041398030295070','7270.720835833658','7270.720835833658384','test','test','1.99'),('2019-04-07 23:59:59','2019-04-08 03:59:59','TRXBTC','4h','0.000005590000000','0.000005478200000','0.042055141887055','0.041214039049314','7523.2811962531105','7523.281196253110465','test','test','2.00'),('2019-04-08 15:59:59','2019-04-08 23:59:59','TRXBTC','4h','0.000005960000000','0.000005840800000','0.041868230145335','0.041030865542428','7024.870829754138','7024.870829754137958','test','test','2.00'),('2019-04-09 03:59:59','2019-04-10 19:59:59','TRXBTC','4h','0.000005670000000','0.000005650000000','0.041682149122466','0.041535122141434','7351.349051581382','7351.349051581381900','test','test','0.35'),('2019-04-10 23:59:59','2019-04-11 03:59:59','TRXBTC','4h','0.000005650000000','0.000005537000000','0.041649476460015','0.040816486930815','7371.5887539849355','7371.588753984935465','test','test','2.00');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 18:55:05
