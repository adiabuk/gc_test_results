-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-04 03:59:59','BNBUSDT','4h','5.854000000000000','5.893500000000000','222.222222222222200','223.721671791367726','37.96074858596211','37.960748585962108','test','test','1.05'),('2019-01-04 07:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.865900000000000','6.059900000000000','222.555433237587891','229.915898647515093','37.94054335014028','37.940543350140281','test','test','0.0'),('2019-01-14 23:59:59','2019-01-15 03:59:59','BNBUSDT','4h','6.058300000000000','5.937133999999999','224.191092217571736','219.707270373220268','37.00561085082808','37.005610850828077','test','test','2.00'),('2019-01-16 15:59:59','2019-01-16 19:59:59','BNBUSDT','4h','5.970200000000000','6.004800000000000','223.194687363271413','224.488201179017835','37.38479236261288','37.384792362612878','test','test','0.0'),('2019-01-16 23:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.091100000000000','6.739800000000000','223.482134877881691','247.282903358990495','36.689946787588724','36.689946787588724','test','test','1.64'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.663118000000000','228.771194540350308','224.195770649543306','33.6472760424689','33.647276042468903','test','test','2.00'),('2019-02-01 11:59:59','2019-02-24 15:59:59','BNBUSDT','4h','6.574400000000000','9.786300000000001','227.754433675726546','339.023061310653929','34.64261889689197','34.642618896891967','test','test','0.78'),('2019-02-24 19:59:59','2019-02-24 23:59:59','BNBUSDT','4h','9.932499999999999','9.947600000000000','252.480795372377088','252.864632272464974','25.41966225747567','25.419662257475672','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','BNBUSDT','4h','9.929600000000001','9.901700000000000','252.566092461285479','251.856437089501100','25.435676408041157','25.435676408041157','test','test','0.28'),('2019-02-27 23:59:59','2019-02-28 03:59:59','BNBUSDT','4h','9.846700000000000','9.825799999999999','252.408391267555658','251.872644735469549','25.633805362969895','25.633805362969895','test','test','0.21'),('2019-02-28 07:59:59','2019-02-28 11:59:59','BNBUSDT','4h','9.956300000000001','10.347600000000000','252.289336482647627','262.204748570035520','25.339667997413457','25.339667997413457','test','test','0.0'),('2019-02-28 15:59:59','2019-03-21 15:59:59','BNBUSDT','4h','10.341500000000000','14.458200000000000','254.492761390956019','355.800149179782466','24.608882791757097','24.608882791757097','test','test','1.26'),('2019-03-22 15:59:59','2019-03-22 19:59:59','BNBUSDT','4h','14.913500000000001','15.220000000000001','277.005514232917449','282.698489732457404','18.57414518610101','18.574145186101010','test','test','0.0'),('2019-03-22 23:59:59','2019-03-24 03:59:59','BNBUSDT','4h','15.150200000000000','14.847196000000000','278.270619899481915','272.705207501492282','18.367455208477903','18.367455208477903','test','test','1.99'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBUSDT','4h','17.040199999999999','16.699396000000000','277.033861588817501','271.493184357041173','16.257664909380026','16.257664909380026','test','test','1.99'),('2019-03-25 15:59:59','2019-03-26 07:59:59','BNBUSDT','4h','16.559300000000000','16.228114000000001','275.802599981756146','270.286547982121022','16.655450410449482','16.655450410449482','test','test','1.99'),('2019-03-26 11:59:59','2019-03-30 07:59:59','BNBUSDT','4h','16.079999999999998','16.367000000000001','274.576810648503908','279.477528599755260','17.075672304011437','17.075672304011437','test','test','1.09'),('2019-03-30 11:59:59','2019-04-08 11:59:59','BNBUSDT','4h','16.486999999999998','17.836900000000000','275.665859082115276','298.236450649710832','16.720195249718888','16.720195249718888','test','test','0.0'),('2019-04-09 23:59:59','2019-04-10 03:59:59','BNBUSDT','4h','18.298400000000001','18.105000000000000','280.681546097136561','277.714958252560734','15.339130530381702','15.339130530381702','test','test','1.05'),('2019-04-10 07:59:59','2019-04-10 23:59:59','BNBUSDT','4h','18.302099999999999','18.239999999999998','280.022304353897482','279.072173762305397','15.300009526442183','15.300009526442183','test','test','0.33'),('2019-04-12 19:59:59','2019-04-12 23:59:59','BNBUSDT','4h','18.270399999999999','18.333300000000001','279.811164222432524','280.774477681885628','15.314999355374406','15.314999355374406','test','test','0.0'),('2019-04-13 03:59:59','2019-04-13 11:59:59','BNBUSDT','4h','18.185700000000001','18.054700000000000','280.025233880088820','278.008082731752950','15.398100368976108','15.398100368976108','test','test','0.72'),('2019-04-13 15:59:59','2019-04-24 07:59:59','BNBUSDT','4h','18.379899999999999','21.444099999999999','279.576978069347490','326.186577479577920','15.211017365129708','15.211017365129708','test','test','0.04'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BNBUSDT','4h','22.004500000000000','22.086600000000001','289.934666827176500','291.016429018842302','13.176153369864187','13.176153369864187','test','test','0.0'),('2019-04-24 19:59:59','2019-04-24 23:59:59','BNBUSDT','4h','21.862200000000001','22.970300000000002','290.175058425324437','304.882772298635530','13.272912077710588','13.272912077710588','test','test','0.0'),('2019-04-25 03:59:59','2019-04-25 23:59:59','BNBUSDT','4h','23.097600000000000','22.635648000000000','293.443439286060197','287.574570500339007','12.704499137835109','12.704499137835109','test','test','2.00'),('2019-04-26 03:59:59','2019-04-26 15:59:59','BNBUSDT','4h','23.489899999999999','23.020101999999998','292.139246222566612','286.296461298115275','12.436802464998431','12.436802464998431','test','test','2.00'),('2019-04-26 19:59:59','2019-04-29 11:59:59','BNBUSDT','4h','22.763000000000002','22.307740000000003','290.840849572688569','285.024032581234849','12.776912075415742','12.776912075415742','test','test','1.99'),('2019-05-02 11:59:59','2019-05-04 15:59:59','BNBUSDT','4h','22.739300000000000','22.677000000000000','289.548223574587723','288.754933793077441','12.733383330823187','12.733383330823187','test','test','0.27'),('2019-05-04 19:59:59','2019-05-06 03:59:59','BNBUSDT','4h','22.831000000000000','22.419300000000000','289.371936956474372','284.153837598365669','12.674518722634767','12.674518722634767','test','test','1.80'),('2019-05-12 07:59:59','2019-05-12 11:59:59','BNBUSDT','4h','21.401000000000000','20.972980000000000','288.212359321339079','282.448112134912265','13.46723794782202','13.467237947822021','test','test','2.00'),('2019-05-13 03:59:59','2019-05-29 07:59:59','BNBUSDT','4h','21.890100000000000','32.824399999999997','286.931415502133120','430.256214225070551','13.107816570145093','13.107816570145093','test','test','0.0'),('2019-05-29 11:59:59','2019-05-30 19:59:59','BNBUSDT','4h','33.380000000000003','32.712400000000002','318.781370773896981','312.405743358419045','9.550071023783612','9.550071023783612','test','test','2.00'),('2019-05-30 23:59:59','2019-05-31 03:59:59','BNBUSDT','4h','31.666599999999999','31.477399999999999','317.364564681568595','315.468390932642194','10.022059983754763','10.022059983754763','test','test','0.59'),('2019-05-31 19:59:59','2019-06-03 03:59:59','BNBUSDT','4h','31.916899999999998','32.081499999999998','316.943192737362722','318.577713932233451','9.930262423273023','9.930262423273023','test','test','0.0'),('2019-06-06 11:59:59','2019-06-06 15:59:59','BNBUSDT','4h','31.897099999999998','31.259157999999999','317.306419669556192','310.960291276165037','9.947814054241803','9.947814054241803','test','test','1.99'),('2019-06-08 03:59:59','2019-06-08 07:59:59','BNBUSDT','4h','31.497800000000002','31.468399999999999','315.896168915469275','315.601311897959647','10.029150255429562','10.029150255429562','test','test','0.09'),('2019-06-08 11:59:59','2019-06-08 15:59:59','BNBUSDT','4h','32.249200000000002','31.722100000000001','315.830645133800488','310.668522257883353','9.793441236799687','9.793441236799687','test','test','1.63'),('2019-06-08 19:59:59','2019-06-09 03:59:59','BNBUSDT','4h','31.583300000000001','31.401900000000001','314.683506716929969','312.876108879514277','9.963604395896882','9.963604395896882','test','test','0.57'),('2019-06-09 07:59:59','2019-06-09 11:59:59','BNBUSDT','4h','31.476600000000001','31.356999999999999','314.281862753059784','313.087702304178208','9.984619137805854','9.984619137805854','test','test','0.37'),('2019-06-10 15:59:59','2019-06-11 11:59:59','BNBUSDT','4h','31.620000000000001','31.108499999999999','314.016493764419465','308.936815188818571','9.930945406844385','9.930945406844385','test','test','1.61'),('2019-06-11 19:59:59','2019-06-14 11:59:59','BNBUSDT','4h','31.672300000000000','31.729299999999999','312.887676303174828','313.450773948413087','9.878906056812257','9.878906056812257','test','test','0.0'),('2019-06-15 07:59:59','2019-06-15 19:59:59','BNBUSDT','4h','33.049999999999997','32.847499999999997','313.012809113227775','311.094954533940950','9.470886811292823','9.470886811292823','test','test','1.45'),('2019-06-15 23:59:59','2019-06-16 07:59:59','BNBUSDT','4h','32.674300000000002','33.170000000000002','312.586619206719604','317.328853535864255','9.566742645036607','9.566742645036607','test','test','0.05'),('2019-06-16 11:59:59','2019-06-16 15:59:59','BNBUSDT','4h','32.779200000000003','32.433900000000001','313.640449057640637','310.336523182097494','9.568276500269702','9.568276500269702','test','test','1.05'),('2019-06-17 07:59:59','2019-06-25 23:59:59','BNBUSDT','4h','33.579999999999998','36.094099999999997','312.906243307519901','336.333211333113582','9.318232379616436','9.318232379616436','test','test','1.27'),('2019-06-26 03:59:59','2019-06-26 19:59:59','BNBUSDT','4h','36.372799999999998','36.088200000000001','318.112236202096312','315.623158033159200','8.745882533159293','8.745882533159293','test','test','0.78'),('2019-06-26 23:59:59','2019-06-27 03:59:59','BNBUSDT','4h','36.118899999999996','35.396521999999997','317.559107720110262','311.207925565708024','8.792048144326385','8.792048144326385','test','test','1.99'),('2019-07-08 07:59:59','2019-07-08 19:59:59','BNBUSDT','4h','33.718499999999999','33.413400000000003','316.147733908020939','313.287088457738889','9.376091282471668','9.376091282471668','test','test','0.90'),('2019-07-20 03:59:59','2019-07-21 15:59:59','BNBUSDT','4h','30.428500000000000','29.819929999999999','315.512034919069322','309.201794220687930','10.368964455003347','10.368964455003347','test','test','2.00'),('2019-07-21 23:59:59','2019-07-22 15:59:59','BNBUSDT','4h','30.438800000000001','29.940700000000000','314.109759208317882','308.969672507736277','10.319387072036935','10.319387072036935','test','test','1.63'),('2019-07-22 19:59:59','2019-07-23 07:59:59','BNBUSDT','4h','30.199999999999999','29.858599999999999','312.967517719299792','309.429533926274360','10.36316283838741','10.363162838387410','test','test','1.13'),('2019-08-01 15:59:59','2019-08-01 19:59:59','BNBUSDT','4h','28.489899999999999','28.284800000000001','312.181299098627449','309.933892668800468','10.95761301719653','10.957613017196531','test','test','0.71'),('2019-08-01 23:59:59','2019-08-02 03:59:59','BNBUSDT','4h','28.708800000000000','28.239999999999998','311.681875447554773','306.592270057924623','10.856666786753705','10.856666786753705','test','test','1.63'),('2019-08-02 07:59:59','2019-08-02 11:59:59','BNBUSDT','4h','28.428799999999999','28.092099999999999','310.550852027636950','306.872804699655944','10.923811487914966','10.923811487914966','test','test','1.18'),('2019-08-05 11:59:59','2019-08-05 15:59:59','BNBUSDT','4h','28.300000000000001','28.049800000000001','309.733508176974567','306.995157514576022','10.94464693204857','10.944646932048570','test','test','0.88'),('2019-08-07 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','28.730000000000000','29.267199999999999','309.124985807552662','314.905074299575517','10.759658399149066','10.759658399149066','test','test','0.0'),('2019-08-13 19:59:59','2019-08-13 23:59:59','BNBUSDT','4h','29.411200000000001','29.451200000000000','310.409449916891049','310.831614874345178','10.554123936353873','10.554123936353873','test','test','0.0'),('2019-08-19 07:59:59','2019-08-19 19:59:59','BNBUSDT','4h','28.968299999999999','28.480599999999999','310.503264351880887','305.275741783265801','10.718725791706138','10.718725791706138','test','test','1.68'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BNBUSDT','4h','28.793099999999999','28.420100000000001','309.341592669966417','305.334229306316900','10.743601511124764','10.743601511124764','test','test','1.29'),('2019-08-20 07:59:59','2019-08-20 11:59:59','BNBUSDT','4h','28.444700000000001','27.985800000000001','308.451067478044308','303.474808460875010','10.843885415491965','10.843885415491965','test','test','1.61'),('2019-09-18 03:59:59','2019-09-19 03:59:59','BNBUSDT','4h','21.640699999999999','21.207885999999998','307.345232140895575','301.198327498077674','14.20218533323301','14.202185333233009','test','test','2.00'),('2019-09-19 23:59:59','2019-09-20 03:59:59','BNBUSDT','4h','21.537600000000001','21.389299999999999','305.979253331380448','303.872392619460641','14.206747888872503','14.206747888872503','test','test','0.68'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBUSDT','4h','21.431100000000001','21.294799999999999','305.511062062064923','303.568037310229499','14.255500747141534','14.255500747141534','test','test','0.63'),('2019-10-09 07:59:59','2019-10-11 23:59:59','BNBUSDT','4h','16.963500000000000','16.624230000000001','305.079278783879261','298.977693208201686','17.984453608269476','17.984453608269476','test','test','1.99'),('2019-10-12 03:59:59','2019-10-16 15:59:59','BNBUSDT','4h','16.789999999999999','17.608799999999999','303.723370878173171','318.535085951136125','18.08953965921222','18.089539659212221','test','test','0.0'),('2019-10-16 19:59:59','2019-10-20 07:59:59','BNBUSDT','4h','17.519300000000001','17.768100000000000','307.014863116609376','311.374928755271412','17.524379576616038','17.524379576616038','test','test','0.0'),('2019-10-20 11:59:59','2019-10-23 03:59:59','BNBUSDT','4h','17.968000000000000','17.800100000000000','307.983766591867607','305.105846154936671','17.14068157790893','17.140681577908929','test','test','0.93'),('2019-10-25 15:59:59','2019-11-07 11:59:59','BNBUSDT','4h','18.433199999999999','20.150900000000000','307.344228716994053','335.984138318538044','16.673406067150253','16.673406067150253','test','test','1.28'),('2019-11-07 15:59:59','2019-11-08 11:59:59','BNBUSDT','4h','20.233100000000000','20.014500000000002','313.708653072892787','310.319320169791752','15.504725082804551','15.504725082804551','test','test','1.08'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BNBUSDT','4h','20.195900000000002','20.069600000000001','312.955467983314691','310.998324424161979','15.495990175397713','15.495990175397713','test','test','0.62'),('2019-11-10 19:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.541799999999999','20.130963999999999','312.520547192391916','306.270136248544077','15.213883262050645','15.213883262050645','test','test','1.99'),('2019-11-11 11:59:59','2019-11-11 15:59:59','BNBUSDT','4h','19.986999999999998','20.074800000000000','311.131566982647939','312.498322953082607','15.566696701988691','15.566696701988691','test','test','0.0'),('2019-11-11 19:59:59','2019-11-12 03:59:59','BNBUSDT','4h','20.156099999999999','20.250000000000000','311.435290531633370','312.886155221772867','15.451168159099895','15.451168159099895','test','test','0.33'),('2019-11-12 07:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.326899999999998','20.219999999999999','311.757704907219988','310.118158362760141','15.33719873208507','15.337198732085071','test','test','0.52'),('2019-11-12 19:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.638600000000000','20.225828000000000','311.393361230673349','305.165494006059873','15.087911061344924','15.087911061344924','test','test','2.00'),('2019-12-28 19:59:59','2019-12-31 19:59:59','BNBUSDT','4h','13.693400000000000','13.668100000000001','310.009390736314799','309.436615707057740','22.639329219647042','22.639329219647042','test','test','0.58'),('2019-12-31 23:59:59','2020-01-01 15:59:59','BNBUSDT','4h','13.716100000000001','13.822300000000000','309.882107396479853','312.281439553981329','22.59258152072964','22.592581520729642','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:53:46
