-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-11 15:59:59','ZRXETH','4h','0.002295920000000','0.002259720000000','1.297777777777778','1.277315585908917','565.2539190293119','565.253919029311874','test','test','1.57'),('2019-01-11 19:59:59','2019-01-12 03:59:59','ZRXETH','4h','0.002289560000000','0.002243768800000','1.293230624029142','1.267366011548559','564.838057980198','564.838057980197959','test','test','1.99'),('2019-01-12 07:59:59','2019-01-12 11:59:59','ZRXETH','4h','0.002243850000000','0.002237890000000','1.287482932366790','1.284063185825397','573.7829767438956','573.782976743895574','test','test','0.26'),('2019-01-12 23:59:59','2019-01-14 15:59:59','ZRXETH','4h','0.002255510000000','0.002248650000000','1.286722988690925','1.282809496974010','570.4798421159405','570.479842115940528','test','test','0.30'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ZRXETH','4h','0.002249900000000','0.002213830000000','1.285853323864944','1.265238750154198','571.5157668629467','571.515766862946748','test','test','1.60'),('2019-01-15 11:59:59','2019-01-15 15:59:59','ZRXETH','4h','0.002273510000000','0.002267500000000','1.281272307484778','1.277885277487996','563.5657232582123','563.565723258212302','test','test','0.26'),('2019-01-15 19:59:59','2019-01-26 15:59:59','ZRXETH','4h','0.002266480000000','0.002482570000000','1.280519634152160','1.402606521194596','564.9816606156506','564.981660615650640','test','test','0.0'),('2019-01-26 19:59:59','2019-01-27 07:59:59','ZRXETH','4h','0.002477380000000','0.002427832400000','1.307650053494924','1.281497052425025','527.8358804442288','527.835880444228792','test','test','2.00'),('2019-01-28 23:59:59','2019-01-29 03:59:59','ZRXETH','4h','0.002451780000000','0.002446360000000','1.301838275479390','1.298960381274731','530.9767905274496','530.976790527449566','test','test','0.22'),('2019-02-08 03:59:59','2019-02-08 07:59:59','ZRXETH','4h','0.002354000000000','0.002306920000000','1.301198743433911','1.275174768565233','552.7607236337767','552.760723633776706','test','test','2.00'),('2019-02-26 11:59:59','2019-02-26 15:59:59','ZRXETH','4h','0.001777610000000','0.001827560000000','1.295415637907538','1.331816204462340','728.7400711672065','728.740071167206452','test','test','0.0'),('2019-02-26 19:59:59','2019-02-26 23:59:59','ZRXETH','4h','0.001827100000000','0.001790558000000','1.303504652697494','1.277434559643544','713.4281936935547','713.428193693554704','test','test','2.00'),('2019-02-27 03:59:59','2019-02-28 11:59:59','ZRXETH','4h','0.001807670000000','0.001813540000000','1.297711298685505','1.301925322994856','717.8917051704708','717.891705170470800','test','test','0.0'),('2019-02-28 15:59:59','2019-03-01 07:59:59','ZRXETH','4h','0.001822990000000','0.001814430000000','1.298647748532027','1.292549840848806','712.3723928995919','712.372392899591887','test','test','0.49'),('2019-03-01 11:59:59','2019-03-01 19:59:59','ZRXETH','4h','0.001811530000000','0.001815370000000','1.297292657935756','1.300042600694901','716.1309268605851','716.130926860585078','test','test','0.36'),('2019-03-01 23:59:59','2019-03-03 03:59:59','ZRXETH','4h','0.001836990000000','0.001821490000000','1.297903756326677','1.286952412975291','706.5382807346131','706.538280734613068','test','test','0.84'),('2019-03-03 07:59:59','2019-03-04 07:59:59','ZRXETH','4h','0.001817670000000','0.001795570000000','1.295470124470813','1.279719251237055','712.7091960976488','712.709196097648828','test','test','1.21'),('2019-03-04 19:59:59','2019-03-04 23:59:59','ZRXETH','4h','0.001818010000000','0.001803360000000','1.291969930418867','1.281558898862035','710.6506182137982','710.650618213798225','test','test','0.80'),('2019-03-09 03:59:59','2019-03-09 11:59:59','ZRXETH','4h','0.001800000000000','0.001792450000000','1.289656367850682','1.284246975863308','716.4757599170457','716.475759917045707','test','test','0.41'),('2019-03-09 15:59:59','2019-03-16 03:59:59','ZRXETH','4h','0.001849400000000','0.001927160000000','1.288454280742377','1.342628718327825','696.6877261503066','696.687726150306617','test','test','1.13'),('2019-03-16 07:59:59','2019-03-16 11:59:59','ZRXETH','4h','0.001939380000000','0.001912130000000','1.300493044650254','1.282219970025003','670.5715458807733','670.571545880773328','test','test','1.40'),('2019-03-16 15:59:59','2019-03-16 19:59:59','ZRXETH','4h','0.001926150000000','0.001919510000000','1.296432361400199','1.291963181492249','673.0692632454371','673.069263245437128','test','test','0.34'),('2019-03-19 11:59:59','2019-03-19 15:59:59','ZRXETH','4h','0.001915800000000','0.001946830000000','1.295439210309543','1.316421295441553','676.1870812765126','676.187081276512572','test','test','0.0'),('2019-03-19 19:59:59','2019-03-21 15:59:59','ZRXETH','4h','0.001941060000000','0.001907060000000','1.300101895894434','1.277329047831823','669.7896489003092','669.789648900309203','test','test','1.75'),('2019-03-21 19:59:59','2019-03-21 23:59:59','ZRXETH','4h','0.001925130000000','0.001917860000000','1.295041262991632','1.290150710155227','672.7032787352708','672.703278735270828','test','test','0.37'),('2019-03-22 15:59:59','2019-04-03 03:59:59','ZRXETH','4h','0.001940400000000','0.002203380000000','1.293954473472431','1.469322514821524','666.8493472853178','666.849347285317776','test','test','0.0'),('2019-04-03 07:59:59','2019-04-03 19:59:59','ZRXETH','4h','0.002212640000000','0.002200460000000','1.332925149327785','1.325587747708537','602.4139260466161','602.413926046616098','test','test','0.55'),('2019-04-03 23:59:59','2019-04-04 03:59:59','ZRXETH','4h','0.002192680000000','0.002148826400000','1.331294615634618','1.304668723321926','607.1540834205714','607.154083420571396','test','test','2.00'),('2019-04-04 07:59:59','2019-04-04 11:59:59','ZRXETH','4h','0.002195910000000','0.002163480000000','1.325377750676243','1.305804088525048','603.5665171506312','603.566517150631171','test','test','1.47'),('2019-04-06 07:59:59','2019-04-06 11:59:59','ZRXETH','4h','0.002210870000000','0.002210000000000','1.321028047975977','1.320508209902395','597.5150271051563','597.515027105156264','test','test','0.03'),('2019-05-31 19:59:59','2019-05-31 23:59:59','ZRXETH','4h','0.001291110000000','0.001277920000000','1.320912528404070','1.307418065306697','1023.0828731897901','1023.082873189790121','test','test','1.02'),('2019-06-03 07:59:59','2019-06-03 11:59:59','ZRXETH','4h','0.001286320000000','0.001276680000000','1.317913758826876','1.308036987389682','1024.5613524059922','1024.561352405992238','test','test','0.74'),('2019-06-03 15:59:59','2019-06-03 19:59:59','ZRXETH','4h','0.001275480000000','0.001283880000000','1.315718920729722','1.324383924441368','1031.548060910184','1031.548060910183949','test','test','0.0'),('2019-06-05 19:59:59','2019-06-11 07:59:59','ZRXETH','4h','0.001293000000000','0.001318410000000','1.317644477110087','1.343538789688097','1019.0599204254348','1019.059920425434825','test','test','1.16'),('2019-06-11 11:59:59','2019-06-11 15:59:59','ZRXETH','4h','0.001322970000000','0.001330110000000','1.323398768794090','1.330541082836880','1000.3240956288424','1000.324095628842429','test','test','0.0'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ZRXETH','4h','0.001333490000000','0.001326800000000','1.324985949692487','1.318338613751878','993.6227116007525','993.622711600752496','test','test','0.50'),('2019-06-15 15:59:59','2019-06-15 19:59:59','ZRXETH','4h','0.001333020000000','0.001326480000000','1.323508763927908','1.317015427506782','992.8648961965367','992.864896196536733','test','test','0.49'),('2019-06-15 23:59:59','2019-06-16 03:59:59','ZRXETH','4h','0.001333000000000','0.001312990000000','1.322065800278769','1.302219936315095','991.79729953396','991.797299533959972','test','test','1.50'),('2019-06-17 03:59:59','2019-06-17 07:59:59','ZRXETH','4h','0.001307330000000','0.001310000000000','1.317655608286841','1.320346696592109','1007.8982416733655','1007.898241673365533','test','test','0.0'),('2019-07-15 07:59:59','2019-07-15 11:59:59','ZRXETH','4h','0.000986640000000','0.000971290000000','1.318253627910234','1.297744431862616','1336.1039770435355','1336.103977043535451','test','test','1.55'),('2019-07-15 19:59:59','2019-07-18 15:59:59','ZRXETH','4h','0.001042710000000','0.001049060000000','1.313696028788541','1.321696306701678','1259.886285533409','1259.886285533408909','test','test','0.0'),('2019-07-18 19:59:59','2019-07-23 19:59:59','ZRXETH','4h','0.001058220000000','0.001065210000000','1.315473868324794','1.324163141197722','1243.1005540670121','1243.100554067012126','test','test','0.65'),('2019-07-23 23:59:59','2019-07-24 03:59:59','ZRXETH','4h','0.001052500000000','0.001064200000000','1.317404817852111','1.332049603000681','1251.6910383392978','1251.691038339297847','test','test','0.0'),('2019-07-24 07:59:59','2019-07-24 15:59:59','ZRXETH','4h','0.001071370000000','0.001057490000000','1.320659214551793','1.303549579320286','1232.682653566735','1232.682653566735098','test','test','1.29'),('2019-07-24 19:59:59','2019-07-24 23:59:59','ZRXETH','4h','0.001051750000000','0.001046920000000','1.316857073389236','1.310809609957365','1252.0628223334786','1252.062822333478607','test','test','0.45'),('2019-07-25 07:59:59','2019-07-25 11:59:59','ZRXETH','4h','0.001059530000000','0.001058720000000','1.315513192626598','1.314507496057339','1241.6007027895369','1241.600702789536854','test','test','0.07'),('2019-07-25 15:59:59','2019-07-25 19:59:59','ZRXETH','4h','0.001054600000000','0.001058250000000','1.315289704500096','1.319841958834844','1247.1929684241384','1247.192968424138371','test','test','0.0'),('2019-07-25 23:59:59','2019-07-27 03:59:59','ZRXETH','4h','0.001068770000000','0.001068860000000','1.316301316574485','1.316412160926864','1231.6039153180616','1231.603915318061581','test','test','0.42'),('2019-07-27 07:59:59','2019-07-27 11:59:59','ZRXETH','4h','0.001065920000000','0.001075860000000','1.316325948652791','1.328601053660305','1234.9200208766051','1234.920020876605122','test','test','0.0'),('2019-07-27 15:59:59','2019-07-29 11:59:59','ZRXETH','4h','0.001073840000000','0.001079670000000','1.319053749765572','1.326215043218166','1228.3522217141958','1228.352221714195821','test','test','0.93'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ZRXETH','4h','0.001074380000000','0.001054070000000','1.320645148310593','1.295679770174191','1229.2160579223298','1229.216057922329810','test','test','1.89'),('2019-07-30 11:59:59','2019-07-30 15:59:59','ZRXETH','4h','0.001068910000000','0.001055410000000','1.315097286502503','1.298488017838365','1230.3161973435588','1230.316197343558770','test','test','1.26'),('2019-07-30 23:59:59','2019-07-31 03:59:59','ZRXETH','4h','0.001066440000000','0.001045111200000','1.311406337910473','1.285178211152264','1229.704754051304','1229.704754051304008','test','test','1.99'),('2019-08-15 23:59:59','2019-08-17 23:59:59','ZRXETH','4h','0.000923980000000','0.000925320000000','1.305577865297537','1.307471276777762','1412.993641959282','1412.993641959282058','test','test','0.0'),('2019-08-18 03:59:59','2019-08-18 07:59:59','ZRXETH','4h','0.000917630000000','0.000916310000000','1.305998623404254','1.304119959691326','1423.230085551098','1423.230085551098000','test','test','0.14'),('2019-08-21 23:59:59','2019-08-22 15:59:59','ZRXETH','4h','0.000919420000000','0.000904640000000','1.305581142579159','1.284593466340530','1420.005158229274','1420.005158229274002','test','test','1.60'),('2019-08-22 19:59:59','2019-08-23 03:59:59','ZRXETH','4h','0.000925950000000','0.000908900000000','1.300917214526130','1.276962747753982','1404.9540628825857','1404.954062882585731','test','test','1.84'),('2019-08-23 11:59:59','2019-08-23 15:59:59','ZRXETH','4h','0.000917310000000','0.000922330000000','1.295593999687875','1.302684167546541','1412.3840355908856','1412.384035590885560','test','test','0.0'),('2019-08-23 19:59:59','2019-08-23 23:59:59','ZRXETH','4h','0.000977140000000','0.000957597200000','1.297169592545357','1.271226200694450','1327.516622536542','1327.516622536541945','test','test','2.00'),('2019-08-24 03:59:59','2019-08-24 23:59:59','ZRXETH','4h','0.000997000000000','0.000977060000000','1.291404394356266','1.265576306469141','1295.290265151721','1295.290265151721087','test','test','1.99'),('2019-08-25 03:59:59','2019-08-25 19:59:59','ZRXETH','4h','0.000984950000000','0.000965251000000','1.285664819270238','1.259951522884833','1305.3097307175374','1305.309730717537377','test','test','1.99'),('2019-08-25 23:59:59','2019-08-26 03:59:59','ZRXETH','4h','0.000958950000000','0.000939771000000','1.279950753406815','1.254351738338679','1334.7419087614733','1334.741908761473269','test','test','2.00'),('2019-08-26 07:59:59','2019-08-26 23:59:59','ZRXETH','4h','0.000941680000000','0.000943000000000','1.274262083391674','1.276048280348259','1353.1795125644312','1353.179512564431207','test','test','0.54'),('2019-08-30 11:59:59','2019-09-01 15:59:59','ZRXETH','4h','0.000938200000000','0.000926520000000','1.274659016048693','1.258790312885776','1358.621846140154','1358.621846140154048','test','test','1.24'),('2019-09-01 23:59:59','2019-09-02 19:59:59','ZRXETH','4h','0.000940250000000','0.000940460000000','1.271132637568044','1.271416538502784','1351.9092130476408','1351.909213047640833','test','test','0.0'),('2019-09-02 23:59:59','2019-09-03 03:59:59','ZRXETH','4h','0.000971970000000','0.000952530600000','1.271195726664653','1.245771812131360','1307.8548994975702','1307.854899497570159','test','test','2.00'),('2019-09-03 07:59:59','2019-09-03 15:59:59','ZRXETH','4h','0.000945340000000','0.000931190000000','1.265545967879477','1.246603073846119','1338.7204263857204','1338.720426385720430','test','test','1.49'),('2019-09-03 19:59:59','2019-09-04 15:59:59','ZRXETH','4h','0.000938430000000','0.000939960000000','1.261336435872064','1.263392896926042','1344.0921921422632','1344.092192142263229','test','test','0.0'),('2019-09-04 19:59:59','2019-09-04 23:59:59','ZRXETH','4h','0.000943300000000','0.000939980000000','1.261793427217392','1.257352470810775','1337.637471872567','1337.637471872566948','test','test','0.35'),('2019-09-05 03:59:59','2019-09-05 19:59:59','ZRXETH','4h','0.000939890000000','0.000935070000000','1.260806548015922','1.254340804618890','1341.4405388033938','1341.440538803393792','test','test','0.51'),('2019-09-18 15:59:59','2019-09-30 03:59:59','ZRXETH','4h','0.000897620000000','0.001142630000000','1.259369716149915','1.603121163481626','1403.0098662573416','1403.009866257341628','test','test','0.0'),('2019-09-30 07:59:59','2019-09-30 11:59:59','ZRXETH','4h','0.001146000000000','0.001153990000000','1.335758926668073','1.345071940476169','1165.5837056440425','1165.583705644042539','test','test','0.0'),('2019-10-01 15:59:59','2019-10-02 15:59:59','ZRXETH','4h','0.001167000000000','0.001164530000000','1.337828485292094','1.334996920288948','1146.382592366833','1146.382592366833023','test','test','0.21'),('2019-10-02 19:59:59','2019-10-02 23:59:59','ZRXETH','4h','0.001151150000000','0.001151510000000','1.337199248624728','1.337617431945324','1161.6203349908596','1161.620334990859646','test','test','0.0'),('2019-10-03 03:59:59','2019-10-25 15:59:59','ZRXETH','4h','0.001177380000000','0.001720930000000','1.337292178251528','1.954667336219744','1135.8203623736836','1135.820362373683565','test','test','0.28'),('2019-11-01 19:59:59','2019-11-01 23:59:59','ZRXETH','4h','0.001685000000000','0.001651300000000','1.474486657800020','1.444996924644020','875.0662657566885','875.066265756688495','test','test','2.00'),('2019-11-02 03:59:59','2019-11-02 07:59:59','ZRXETH','4h','0.001609900000000','0.001615730000000','1.467933383765353','1.473249273961857','911.8165002579993','911.816500257999337','test','test','0.0'),('2019-11-02 11:59:59','2019-11-02 19:59:59','ZRXETH','4h','0.001656880000000','0.001623742400000','1.469114692697910','1.439732398843952','886.6753734114179','886.675373411417922','test','test','2.00'),('2019-11-03 03:59:59','2019-11-03 23:59:59','ZRXETH','4h','0.001635000000000','0.001621280000000','1.462585294063697','1.450312101259688','894.547580467093','894.547580467092985','test','test','0.83'),('2019-11-04 03:59:59','2019-11-04 11:59:59','ZRXETH','4h','0.001642010000000','0.001609169800000','1.459857917885028','1.430660759527327','889.0676170577696','889.067617057769553','test','test','1.99'),('2019-11-07 11:59:59','2019-11-07 15:59:59','ZRXETH','4h','0.001654730000000','0.001621635400000','1.453369660472206','1.424302267262762','878.3122687521262','878.312268752126215','test','test','1.99'),('2019-11-07 19:59:59','2019-11-08 15:59:59','ZRXETH','4h','0.001637950000000','0.001605191000000','1.446910239758996','1.417972034963816','883.3665495033401','883.366549503340138','test','test','2.00'),('2019-11-09 07:59:59','2019-11-10 23:59:59','ZRXETH','4h','0.001637950000000','0.001627760000000','1.440479527582289','1.431518029132359','879.4404759499921','879.440475949992106','test','test','0.62'),('2019-11-11 11:59:59','2019-11-11 15:59:59','ZRXETH','4h','0.001623000000000','0.001671420000000','1.438488083482305','1.481403421130003','886.3142843390665','886.314284339066489','test','test','0.0'),('2019-11-11 19:59:59','2019-11-12 07:59:59','ZRXETH','4h','0.001640000000000','0.001635960000000','1.448024825181794','1.444457739636834','882.9419665742644','882.941966574264370','test','test','0.42'),('2019-11-12 11:59:59','2019-11-12 15:59:59','ZRXETH','4h','0.001620430000000','0.001620000000000','1.447232139505136','1.446848099577470','893.1161108502902','893.116110850290170','test','test','0.02'),('2019-11-12 19:59:59','2019-11-12 23:59:59','ZRXETH','4h','0.001624080000000','0.001611000000000','1.447146797298988','1.435491780237839','891.0563502407442','891.056350240744223','test','test','0.80'),('2019-11-21 19:59:59','2019-11-22 15:59:59','ZRXETH','4h','0.001584830000000','0.001596100000000','1.444556793507621','1.454829286496037','911.4900610839151','911.490061083915066','test','test','1.30'),('2019-11-22 19:59:59','2019-11-23 03:59:59','ZRXETH','4h','0.001612430000000','0.001580181400000','1.446839569727269','1.417902778332724','897.3038021664627','897.303802166462674','test','test','2.00'),('2019-11-23 07:59:59','2019-12-01 07:59:59','ZRXETH','4h','0.001575750000000','0.001696990000000','1.440409171639593','1.551235894133380','914.1102152242379','914.110215224237891','test','test','0.0'),('2019-12-01 11:59:59','2019-12-02 07:59:59','ZRXETH','4h','0.001702720000000','0.001675470000000','1.465037332193768','1.441591159421803','860.4100099803652','860.410009980365203','test','test','1.60'),('2019-12-02 11:59:59','2019-12-02 23:59:59','ZRXETH','4h','0.001718250000000','0.001683885000000','1.459827071577775','1.430630530146219','849.6010892348467','849.601089234846654','test','test','1.99'),('2019-12-03 11:59:59','2019-12-03 15:59:59','ZRXETH','4h','0.001687590000000','0.001662380000000','1.453338951259652','1.431628301776510','861.1919668045269','861.191966804526942','test','test','1.49'),('2019-12-18 23:59:59','2019-12-19 03:59:59','ZRXETH','4h','0.001518170000000','0.001487806600000','1.448514362485620','1.419544075235908','954.1186839982481','954.118683998248116','test','test','1.99'),('2019-12-20 15:59:59','2019-12-20 19:59:59','ZRXETH','4h','0.001542410000000','0.001530360000000','1.442076520874573','1.430810371098224','934.9501889086384','934.950188908638438','test','test','0.78'),('2019-12-20 23:59:59','2019-12-21 03:59:59','ZRXETH','4h','0.001502730000000','0.001508820000000','1.439572932035384','1.445406980171839','957.9717793851086','957.971779385108562','test','test','0.0'),('2019-12-27 19:59:59','2019-12-27 23:59:59','ZRXETH','4h','0.001477210000000','0.001470110000000','1.440869387176819','1.433944053169497','975.3991559607765','975.399155960776511','test','test','0.48'),('2019-12-29 11:59:59','2019-12-29 15:59:59','ZRXETH','4h','0.001482580000000','0.001493320000000','1.439330424064081','1.449757118579351','970.8281671573073','970.828167157307348','test','test','0.0'),('2019-12-29 19:59:59','2019-12-29 23:59:59','ZRXETH','4h','0.001470100000000','0.001467000000000','1.441647467289696','1.438607465147938','980.6458521799171','980.645852179917142','test','test','0.21');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:14:16
