-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 07:59:59','BNBBTC','4h','0.001584200000000','0.001552516000000','0.033333333333333','0.032666666666666','21.04111433741531','21.041114337415308','test','test','1.99'),('2019-01-03 11:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001533500000000','0.001570800000000','0.033185185185185','0.033992363148933','21.64015988600268','21.640159886002682','test','test','0.0'),('2019-01-06 23:59:59','2019-01-07 11:59:59','BNBBTC','4h','0.001571600000000','0.001548600000000','0.033364558066018','0.032876275528783','21.229675531953422','21.229675531953422','test','test','1.46'),('2019-01-07 15:59:59','2019-01-13 19:59:59','BNBBTC','4h','0.001554900000000','0.001596000000000','0.033256050835521','0.034135093661002','21.387903296367185','21.387903296367185','test','test','0.0'),('2019-01-14 03:59:59','2019-01-14 07:59:59','BNBBTC','4h','0.001616700000000','0.001608900000000','0.033451393685628','0.033290002660238','20.691157101273102','20.691157101273102','test','test','0.48'),('2019-01-14 11:59:59','2019-01-14 15:59:59','BNBBTC','4h','0.001610800000000','0.001627500000000','0.033415529013319','0.033761965153450','20.744679049738846','20.744679049738846','test','test','0.0'),('2019-01-14 19:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001629100000000','0.001624100000000','0.033492514822237','0.033389720288991','20.558906649215718','20.558906649215718','test','test','0.38'),('2019-01-15 15:59:59','2019-01-15 23:59:59','BNBBTC','4h','0.001618100000000','0.001632900000000','0.033469671592627','0.033775802943947','20.68455076486442','20.684550764864419','test','test','0.0'),('2019-01-16 03:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001641400000000','0.001800900000000','0.033537700781809','0.036796664638699','20.432375278304697','20.432375278304697','test','test','0.0'),('2019-02-01 07:59:59','2019-02-14 15:59:59','BNBBTC','4h','0.001860000000000','0.002378400000000','0.034261914972229','0.043811042241908','18.420384393671686','18.420384393671686','test','test','0.0'),('2019-02-14 19:59:59','2019-02-18 19:59:59','BNBBTC','4h','0.002427500000000','0.002485900000000','0.036383943254380','0.037259256245546','14.988236150105138','14.988236150105138','test','test','0.0'),('2019-02-18 23:59:59','2019-02-19 15:59:59','BNBBTC','4h','0.002463900000000','0.002630500000000','0.036578457252417','0.039051760137377','14.845755612004183','14.845755612004183','test','test','0.12'),('2019-02-19 19:59:59','2019-02-19 23:59:59','BNBBTC','4h','0.002750300000000','0.002695294000000','0.037128080115742','0.036385518513427','13.499647353285663','13.499647353285663','test','test','2.00'),('2019-02-20 03:59:59','2019-02-20 15:59:59','BNBBTC','4h','0.002775900000000','0.002720382000000','0.036963066426338','0.036223805097811','13.315705330285034','13.315705330285034','test','test','2.00'),('2019-02-20 19:59:59','2019-02-21 07:59:59','BNBBTC','4h','0.002696300000000','0.002642374000000','0.036798786131110','0.036062810408488','13.647882702633238','13.647882702633238','test','test','2.00'),('2019-02-21 11:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002614300000000','0.002635100000000','0.036635235970527','0.036926714725141','14.013401664127045','14.013401664127045','test','test','0.0'),('2019-02-23 23:59:59','2019-02-24 07:59:59','BNBBTC','4h','0.002603800000000','0.002597700000000','0.036700009027108','0.036614030820231','14.094788012561727','14.094788012561727','test','test','0.23'),('2019-02-24 11:59:59','2019-02-24 15:59:59','BNBBTC','4h','0.002630000000000','0.002591100000000','0.036680902758913','0.036138360128753','13.947111315176175','13.947111315176175','test','test','1.47'),('2019-02-24 19:59:59','2019-02-25 15:59:59','BNBBTC','4h','0.002628400000000','0.002585600000000','0.036560337729989','0.035965001230657','13.909731292797478','13.909731292797478','test','test','1.62'),('2019-02-27 15:59:59','2019-02-27 23:59:59','BNBBTC','4h','0.002584600000000','0.002582400000000','0.036428040730137','0.036397033344233','14.094266319793135','14.094266319793135','test','test','0.33'),('2019-02-28 03:59:59','2019-02-28 11:59:59','BNBBTC','4h','0.002574700000000','0.002699300000000','0.036421150199936','0.038183714892876','14.145784052486288','14.145784052486288','test','test','0.0'),('2019-02-28 15:59:59','2019-03-19 15:59:59','BNBBTC','4h','0.002685800000000','0.003857300000000','0.036812831242812','0.052869958281666','13.706467809521188','13.706467809521188','test','test','0.55'),('2019-03-19 19:59:59','2019-03-20 07:59:59','BNBBTC','4h','0.003814300000000','0.003776300000000','0.040381081695891','0.039978784785726','10.586760793826041','10.586760793826041','test','test','0.99'),('2019-03-20 11:59:59','2019-03-20 15:59:59','BNBBTC','4h','0.003771500000000','0.003756600000000','0.040291682382521','0.040132502727874','10.683198298427858','10.683198298427858','test','test','0.39'),('2019-03-22 19:59:59','2019-03-23 15:59:59','BNBBTC','4h','0.003799900000000','0.003779400000000','0.040256309125932','0.040039131216755','10.594044350096697','10.594044350096697','test','test','0.73'),('2019-03-23 19:59:59','2019-03-23 23:59:59','BNBBTC','4h','0.003773800000000','0.003780800000000','0.040208047368338','0.040282629045051','10.654525244670507','10.654525244670507','test','test','0.0'),('2019-03-24 11:59:59','2019-03-25 11:59:59','BNBBTC','4h','0.004268000000000','0.004182640000000','0.040224621074274','0.039420128652789','9.42470034542497','9.424700345424970','test','test','2.00'),('2019-03-25 15:59:59','2019-03-26 15:59:59','BNBBTC','4h','0.004172500000000','0.004089050000000','0.040045844980610','0.039244928080998','9.59756620266278','9.597566202662779','test','test','1.99'),('2019-03-26 19:59:59','2019-03-29 19:59:59','BNBBTC','4h','0.004107200000000','0.004025056000000','0.039867863447363','0.039070506178416','9.706823005298826','9.706823005298826','test','test','2.00'),('2019-03-29 23:59:59','2019-03-30 03:59:59','BNBBTC','4h','0.004018500000000','0.003938130000000','0.039690672943153','0.038896859484290','9.876987170126387','9.876987170126387','test','test','1.99'),('2019-03-30 11:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004026000000000','0.004032700000000','0.039514269952294','0.039580028921166','9.814771473495886','9.814771473495886','test','test','0.0'),('2019-04-02 19:59:59','2019-04-02 23:59:59','BNBBTC','4h','0.004200000000000','0.004116000000000','0.039528883056488','0.038738305395358','9.411638822973387','9.411638822973387','test','test','1.99'),('2019-04-13 23:59:59','2019-04-14 03:59:59','BNBBTC','4h','0.003687700000000','0.003674800000000','0.039353199131793','0.039215537101584','10.671475209966285','10.671475209966285','test','test','0.34'),('2019-04-14 07:59:59','2019-04-16 07:59:59','BNBBTC','4h','0.003783100000000','0.003771400000000','0.039322607569524','0.039200994472180','10.394281824303878','10.394281824303878','test','test','0.85'),('2019-04-16 11:59:59','2019-04-17 19:59:59','BNBBTC','4h','0.003825700000000','0.003749186000000','0.039295582436781','0.038509670788045','10.271475138348771','10.271475138348771','test','test','2.00'),('2019-04-17 23:59:59','2019-04-18 03:59:59','BNBBTC','4h','0.003744400000000','0.003718400000000','0.039120935403728','0.038849291263012','10.447851565999477','10.447851565999477','test','test','0.69'),('2019-04-18 07:59:59','2019-04-23 19:59:59','BNBBTC','4h','0.003929900000000','0.004150000000000','0.039060570039125','0.041248216408145','9.939329254974652','9.939329254974652','test','test','0.0'),('2019-04-24 23:59:59','2019-04-25 03:59:59','BNBBTC','4h','0.004245200000000','0.004271200000000','0.039546713676685','0.039788920064039','9.315630282833528','9.315630282833528','test','test','0.0'),('2019-04-25 07:59:59','2019-04-25 11:59:59','BNBBTC','4h','0.004229900000000','0.004203400000000','0.039600537318319','0.039352442980643','9.362050478337341','9.362050478337341','test','test','0.62'),('2019-04-25 15:59:59','2019-04-25 23:59:59','BNBBTC','4h','0.004175000000000','0.004305500000000','0.039545405243280','0.040781495155675','9.471953351683833','9.471953351683833','test','test','0.0'),('2019-04-26 03:59:59','2019-04-26 15:59:59','BNBBTC','4h','0.004394300000000','0.004306414000000','0.039820091890479','0.039023690052669','9.061759982358712','9.061759982358712','test','test','1.99'),('2019-04-26 19:59:59','2019-04-27 23:59:59','BNBBTC','4h','0.004323900000000','0.004237422000000','0.039643113704299','0.038850251430213','9.168369690394988','9.168369690394988','test','test','2.00'),('2019-04-28 03:59:59','2019-04-29 11:59:59','BNBBTC','4h','0.004318600000000','0.004232228000000','0.039466922087835','0.038677583646078','9.138823250089226','9.138823250089226','test','test','2.00'),('2019-05-02 15:59:59','2019-05-03 03:59:59','BNBBTC','4h','0.004283300000000','0.004197634000000','0.039291513545223','0.038505683274319','9.17318738944801','9.173187389448010','test','test','1.99'),('2019-05-17 07:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003397700000000','0.003871200000000','0.039116884596133','0.044568173661168','11.512754097222501','11.512754097222501','test','test','0.0'),('2019-05-27 03:59:59','2019-05-27 07:59:59','BNBBTC','4h','0.003947800000000','0.003914600000000','0.040328282166141','0.039989131508074','10.215381267070438','10.215381267070438','test','test','0.84'),('2019-05-27 11:59:59','2019-05-27 15:59:59','BNBBTC','4h','0.003936900000000','0.003858400000000','0.040252915353237','0.039450290482087','10.224520651588024','10.224520651588024','test','test','1.99'),('2019-05-29 23:59:59','2019-05-30 03:59:59','BNBBTC','4h','0.003887800000000','0.003989700000000','0.040074554270759','0.041124916192718','10.30777155994627','10.307771559946270','test','test','0.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','BNBBTC','4h','0.003913300000000','0.003877300000000','0.040307968031194','0.039937159033897','10.30024992492128','10.300249924921280','test','test','0.91'),('2019-06-01 07:59:59','2019-06-01 15:59:59','BNBBTC','4h','0.003899300000000','0.003873900000000','0.040225566031795','0.039963537109371','10.316099308028393','10.316099308028393','test','test','0.92'),('2019-06-01 19:59:59','2019-06-01 23:59:59','BNBBTC','4h','0.003864300000000','0.003900000000000','0.040167337382368','0.040538419840912','10.394466625874689','10.394466625874689','test','test','0.0'),('2019-06-04 15:59:59','2019-06-04 19:59:59','BNBBTC','4h','0.003876400000000','0.003825000000000','0.040249800150933','0.039716098848756','10.383293816668273','10.383293816668273','test','test','1.32'),('2019-06-05 11:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.003864000000000','0.004064800000000','0.040131199861560','0.042216692856436','10.385921289223662','10.385921289223662','test','test','0.0'),('2019-06-19 11:59:59','2019-06-19 19:59:59','BNBBTC','4h','0.003875000000000','0.003878100000000','0.040594642749310','0.040627118463509','10.476036838531728','10.476036838531728','test','test','0.00'),('2019-06-20 11:59:59','2019-06-20 15:59:59','BNBBTC','4h','0.003921300000000','0.003859400000000','0.040601859574688','0.039960935618940','10.354183453111979','10.354183453111979','test','test','1.57'),('2019-06-20 23:59:59','2019-06-21 03:59:59','BNBBTC','4h','0.003871000000000','0.003793580000000','0.040459432028966','0.039650243388387','10.45193284137593','10.451932841375930','test','test','1.99'),('2019-07-02 07:59:59','2019-07-02 11:59:59','BNBBTC','4h','0.003251400000000','0.003186372000000','0.040279612331060','0.039474020084439','12.388390333720789','12.388390333720789','test','test','1.99'),('2019-07-14 23:59:59','2019-07-15 03:59:59','BNBBTC','4h','0.002804200000000','0.002748116000000','0.040100591831811','0.039298579995175','14.30018965544921','14.300189655449209','test','test','2.00'),('2019-07-17 15:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002813600000000','0.002781700000000','0.039922366979225','0.039469735650451','14.189069867509557','14.189069867509557','test','test','1.13'),('2019-07-18 19:59:59','2019-07-18 23:59:59','BNBBTC','4h','0.002759800000000','0.002722800000000','0.039821782239497','0.039287900819517','14.429227567032875','14.429227567032875','test','test','1.34'),('2019-07-19 07:59:59','2019-07-19 15:59:59','BNBBTC','4h','0.002800600000000','0.002788500000000','0.039703141923946','0.039531604390103','14.176655689475904','14.176655689475904','test','test','0.58'),('2019-07-19 19:59:59','2019-07-19 23:59:59','BNBBTC','4h','0.002778400000000','0.002760600000000','0.039665022471981','0.039410905930086','14.276210218824183','14.276210218824183','test','test','0.64'),('2019-07-20 03:59:59','2019-07-27 07:59:59','BNBBTC','4h','0.002896800000000','0.002879000000000','0.039608552129338','0.039365169007306','13.673209102919696','13.673209102919696','test','test','1.69'),('2019-07-27 11:59:59','2019-07-28 23:59:59','BNBBTC','4h','0.002908400000000','0.002905500000000','0.039554466991108','0.039515026764772','13.600078046729628','13.600078046729628','test','test','0.30'),('2019-08-08 11:59:59','2019-08-08 15:59:59','BNBBTC','4h','0.002644900000000','0.002629300000000','0.039545702496367','0.039312456264395','14.951681536680823','14.951681536680823','test','test','0.58'),('2019-08-08 19:59:59','2019-08-08 23:59:59','BNBBTC','4h','0.002641700000000','0.002595600000000','0.039493870000373','0.038804667060214','14.950172237715613','14.950172237715613','test','test','1.74'),('2019-08-09 03:59:59','2019-08-09 07:59:59','BNBBTC','4h','0.002638800000000','0.002589600000000','0.039340713791449','0.038607212533855','14.908562146221431','14.908562146221431','test','test','1.86'),('2019-08-10 19:59:59','2019-08-16 19:59:59','BNBBTC','4h','0.002618700000000','0.002659600000000','0.039177713511984','0.039789608147735','14.960749040357346','14.960749040357346','test','test','0.95'),('2019-08-16 23:59:59','2019-08-18 11:59:59','BNBBTC','4h','0.002661000000000','0.002663700000000','0.039313690097706','0.039353579974919','14.774028597409327','14.774028597409327','test','test','0.0'),('2019-08-18 15:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002691800000000','0.002665700000000','0.039322554514865','0.038941278538627','14.608274951654904','14.608274951654904','test','test','0.96'),('2019-08-21 07:59:59','2019-08-21 15:59:59','BNBBTC','4h','0.002678200000000','0.002656900000000','0.039237826520145','0.038925764050994','14.650820147914686','14.650820147914686','test','test','0.79'),('2019-08-21 19:59:59','2019-08-21 23:59:59','BNBBTC','4h','0.002670600000000','0.002656200000000','0.039168479304778','0.038957281033982','14.666546583081788','14.666546583081788','test','test','0.53'),('2019-08-22 03:59:59','2019-08-22 07:59:59','BNBBTC','4h','0.002673100000000','0.002664800000000','0.039121546355712','0.039000073595713','14.635272288994967','14.635272288994967','test','test','0.31'),('2019-08-22 11:59:59','2019-08-22 19:59:59','BNBBTC','4h','0.002679400000000','0.002662400000000','0.039094552409046','0.038846509044504','14.590786149528252','14.590786149528252','test','test','0.63'),('2019-08-22 23:59:59','2019-08-23 07:59:59','BNBBTC','4h','0.002670000000000','0.002647900000000','0.039039431661370','0.038716296290690','14.621509985531837','14.621509985531837','test','test','0.82'),('2019-09-18 03:59:59','2019-09-19 07:59:59','BNBBTC','4h','0.002120800000000','0.002094900000000','0.038967623801219','0.038491736656532','18.374021030374806','18.374021030374806','test','test','1.22'),('2019-09-19 11:59:59','2019-09-19 23:59:59','BNBBTC','4h','0.002122900000000','0.002101200000000','0.038861871102400','0.038464630251243','18.30603000725402','18.306030007254019','test','test','1.02'),('2019-09-20 03:59:59','2019-09-20 07:59:59','BNBBTC','4h','0.002093500000000','0.002081000000000','0.038773595357698','0.038542083563109','18.520943567087652','18.520943567087652','test','test','0.59'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBBTC','4h','0.002106400000000','0.002091600000000','0.038722148292234','0.038450078507423','18.383093568284174','18.383093568284174','test','test','0.70'),('2019-09-21 03:59:59','2019-09-21 15:59:59','BNBBTC','4h','0.002110700000000','0.002091000000000','0.038661688340054','0.038300843473280','18.31699831338113','18.316998313381131','test','test','0.93'),('2019-09-21 23:59:59','2019-09-22 03:59:59','BNBBTC','4h','0.002100000000000','0.002065600000000','0.038581500591882','0.037949498867901','18.37214313899122','18.372143138991220','test','test','1.63'),('2019-10-05 23:59:59','2019-10-06 03:59:59','BNBBTC','4h','0.001929800000000','0.001929600000000','0.038441055764330','0.038437071822392','19.919709692367203','19.919709692367203','test','test','0.01'),('2019-10-07 11:59:59','2019-10-07 15:59:59','BNBBTC','4h','0.001945000000000','0.001932500000000','0.038440170443900','0.038193125646703','19.763583775783836','19.763583775783836','test','test','0.64'),('2019-10-07 19:59:59','2019-10-21 07:59:59','BNBBTC','4h','0.001938300000000','0.002195700000000','0.038385271600078','0.043482712094253','19.80357612344735','19.803576123447350','test','test','0.05'),('2019-10-21 11:59:59','2019-10-23 15:59:59','BNBBTC','4h','0.002221400000000','0.002218400000000','0.039518036154339','0.039464667058965','17.789698457882015','17.789698457882015','test','test','0.94'),('2019-10-23 19:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002230000000000','0.002231500000000','0.039506176355367','0.039532750016593','17.715774150388835','17.715774150388835','test','test','0.38'),('2019-10-28 23:59:59','2019-10-29 03:59:59','BNBBTC','4h','0.002165000000000','0.002187200000000','0.039512081613417','0.039917240140816','18.250384117051887','18.250384117051887','test','test','0.0'),('2019-10-29 07:59:59','2019-10-30 03:59:59','BNBBTC','4h','0.002203600000000','0.002189900000000','0.039602116841728','0.039355906549147','17.97155420299883','17.971554202998831','test','test','0.62'),('2019-10-30 07:59:59','2019-10-30 11:59:59','BNBBTC','4h','0.002187500000000','0.002163600000000','0.039547403443377','0.039115319812613','18.078813002686577','18.078813002686577','test','test','1.09'),('2019-10-30 23:59:59','2019-10-31 07:59:59','BNBBTC','4h','0.002189600000000','0.002175700000000','0.039451384858763','0.039200939914692','18.01762187557667','18.017621875576669','test','test','0.63'),('2019-10-31 11:59:59','2019-10-31 15:59:59','BNBBTC','4h','0.002186900000000','0.002166700000000','0.039395730426747','0.039031839185895','18.01441786398413','18.014417863984129','test','test','0.92'),('2019-10-31 19:59:59','2019-10-31 23:59:59','BNBBTC','4h','0.002169400000000','0.002176900000000','0.039314865706558','0.039450784159955','18.12246045291673','18.122460452916730','test','test','0.0'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.039345069807312','0.039155555043801','18.04902509624866','18.049025096248659','test','test','0.48'),('2019-11-01 11:59:59','2019-11-01 15:59:59','BNBBTC','4h','0.002169900000000','0.002172900000000','0.039302955415421','0.039357293802557','18.112795711978023','18.112795711978023','test','test','0.0'),('2019-11-02 03:59:59','2019-11-02 07:59:59','BNBBTC','4h','0.002173300000000','0.002180900000000','0.039315030612562','0.039452514730105','18.09001546614018','18.090015466140180','test','test','0.0'),('2019-11-02 11:59:59','2019-11-02 15:59:59','BNBBTC','4h','0.002180800000000','0.002169400000000','0.039345582638683','0.039139905986958','18.041811554788662','18.041811554788662','test','test','0.52'),('2019-11-02 19:59:59','2019-11-02 23:59:59','BNBBTC','4h','0.002174300000000','0.002173100000000','0.039299876716078','0.039278187044892','18.074725988169785','18.074725988169785','test','test','0.05'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.039295056789147','0.039118660125442','17.999659561700028','17.999659561700028','test','test','0.44'),('2019-11-03 19:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002180000000000','0.002195500000000','0.039255857530546','0.039534970279043','18.007274096580836','18.007274096580836','test','test','0.0'),('2019-11-05 03:59:59','2019-11-07 11:59:59','BNBBTC','4h','0.002201100000000','0.002190400000000','0.039317882585768','0.039126750268441','17.86283339501512','17.862833395015119','test','test','0.48'),('2019-11-07 15:59:59','2019-11-18 07:59:59','BNBBTC','4h','0.002200500000000','0.002326700000000','0.039275408737473','0.041527877077700','17.848402062019037','17.848402062019037','test','test','0.0'),('2019-12-29 15:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001910400000000','0.001910800000000','0.039775957257523','0.039784285556781','20.82074814568851','20.820748145688508','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:55:26
