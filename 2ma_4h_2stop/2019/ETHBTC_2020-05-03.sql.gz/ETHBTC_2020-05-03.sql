-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-08 03:59:59','ETHBTC','4h','0.036644000000000','0.037143000000000','0.033333333333333','0.033787250300185','0.9096532401848415','0.909653240184842','test','test','0.04'),('2019-01-08 11:59:59','2019-01-08 15:59:59','ETHBTC','4h','0.037406000000000','0.037186000000000','0.033434203770412','0.033237563530090','0.8938192741916151','0.893819274191615','test','test','0.58'),('2019-01-08 19:59:59','2019-01-08 23:59:59','ETHBTC','4h','0.037266000000000','0.037296000000000','0.033390505939229','0.033417386076034','0.89600456016822','0.896004560168220','test','test','0.0'),('2019-01-09 03:59:59','2019-01-09 23:59:59','ETHBTC','4h','0.037759000000000','0.037337000000000','0.033396479302963','0.033023235460016','0.8844640828137221','0.884464082813722','test','test','1.11'),('2019-02-08 11:59:59','2019-02-24 19:59:59','ETHBTC','4h','0.031576000000000','0.036752000000000','0.033313536226753','0.038774356581126','1.055027116378037','1.055027116378037','test','test','0.0'),('2019-02-25 03:59:59','2019-02-25 07:59:59','ETHBTC','4h','0.036534000000000','0.036269000000000','0.034527051861058','0.034276609294047','0.9450662906075984','0.945066290607598','test','test','0.72'),('2019-02-27 11:59:59','2019-02-27 15:59:59','ETHBTC','4h','0.036214000000000','0.035993000000000','0.034471397957278','0.034261032381850','0.9518804318020041','0.951880431802004','test','test','0.61'),('2019-03-05 19:59:59','2019-03-05 23:59:59','ETHBTC','4h','0.035449000000000','0.035450000000000','0.034424650051627','0.034425621155186','0.9711035586794298','0.971103558679430','test','test','0.0'),('2019-03-06 03:59:59','2019-03-06 07:59:59','ETHBTC','4h','0.035308000000000','0.035618000000000','0.034424865852418','0.034727112040654','0.9749877039882745','0.974987703988275','test','test','0.0'),('2019-03-06 11:59:59','2019-03-07 11:59:59','ETHBTC','4h','0.035893000000000','0.035317000000000','0.034492031672026','0.033938513987712','0.9609682019342487','0.960968201934249','test','test','1.60'),('2019-03-07 15:59:59','2019-03-07 19:59:59','ETHBTC','4h','0.035248000000000','0.035409000000000','0.034369027742178','0.034526012917691','0.975063201945598','0.975063201945598','test','test','0.0'),('2019-03-07 23:59:59','2019-03-08 03:59:59','ETHBTC','4h','0.035320000000000','0.035054000000000','0.034403913336737','0.034144812517157','0.9740632315044419','0.974063231504442','test','test','0.75'),('2019-03-15 15:59:59','2019-03-15 23:59:59','ETHBTC','4h','0.034832000000000','0.034804000000000','0.034346335376830','0.034318725782476','0.9860569412273259','0.986056941227326','test','test','0.08'),('2019-03-16 03:59:59','2019-03-17 03:59:59','ETHBTC','4h','0.035075000000000','0.034702000000000','0.034340199911418','0.033975014036380','0.9790506033191222','0.979050603319122','test','test','1.06'),('2019-03-17 07:59:59','2019-03-18 07:59:59','ETHBTC','4h','0.034891000000000','0.034651000000000','0.034259047494743','0.034023394420921','0.9818878075934511','0.981887807593451','test','test','0.68'),('2019-03-27 11:59:59','2019-03-27 15:59:59','ETHBTC','4h','0.034359000000000','0.034336000000000','0.034206680145005','0.034183782108295','0.9955668134987888','0.995566813498789','test','test','0.06'),('2019-03-27 19:59:59','2019-03-27 23:59:59','ETHBTC','4h','0.034357000000000','0.034521000000000','0.034201591692403','0.034364849865048','0.9954766624676971','0.995476662467697','test','test','0.0'),('2019-03-28 03:59:59','2019-03-28 07:59:59','ETHBTC','4h','0.034428000000000','0.034318000000000','0.034237871286324','0.034128478761591','0.9944774975695299','0.994477497569530','test','test','0.31'),('2019-03-29 15:59:59','2019-03-31 07:59:59','ETHBTC','4h','0.034477000000000','0.034388000000000','0.034213561836383','0.034125241883851','0.9923590172109845','0.992359017210985','test','test','0.25'),('2019-03-31 11:59:59','2019-03-31 19:59:59','ETHBTC','4h','0.034517000000000','0.034402000000000','0.034193935180265','0.034080011532621','0.9906404142962856','0.990640414296286','test','test','0.33'),('2019-03-31 23:59:59','2019-04-01 03:59:59','ETHBTC','4h','0.034482000000000','0.034527000000000','0.034168618814122','0.034213209842677','0.9909117456679362','0.990911745667936','test','test','0.0'),('2019-04-01 07:59:59','2019-04-01 11:59:59','ETHBTC','4h','0.034502000000000','0.034375000000000','0.034178527931578','0.034052718614805','0.990624541521606','0.990624541521606','test','test','0.36'),('2019-04-07 23:59:59','2019-04-10 19:59:59','ETHBTC','4h','0.033702000000000','0.033582000000000','0.034150570305629','0.034028973117430','1.013309901656545','1.013309901656545','test','test','0.35'),('2019-04-18 15:59:59','2019-04-18 23:59:59','ETHBTC','4h','0.032807000000000','0.032962000000000','0.034123548708251','0.034284768876196','1.040130115775637','1.040130115775637','test','test','0.0'),('2019-04-19 03:59:59','2019-04-19 15:59:59','ETHBTC','4h','0.032825000000000','0.032692000000000','0.034159375412239','0.034020968803562','1.0406511930613591','1.040651193061359','test','test','0.40'),('2019-04-19 19:59:59','2019-04-19 23:59:59','ETHBTC','4h','0.032620000000000','0.032829000000000','0.034128618388089','0.034347284275370','1.0462482645030247','1.046248264503025','test','test','0.0'),('2019-04-20 03:59:59','2019-04-20 11:59:59','ETHBTC','4h','0.032823000000000','0.032662000000000','0.034177210807484','0.034009568272067','1.0412579839589449','1.041257983958945','test','test','0.49'),('2019-05-06 19:59:59','2019-05-07 15:59:59','ETHBTC','4h','0.030215000000000','0.029610700000000','0.034139956910725','0.033457157772511','1.129900940285458','1.129900940285458','test','test','2.00'),('2019-05-15 15:59:59','2019-05-23 07:59:59','ETHBTC','4h','0.029813000000000','0.030991000000000','0.033988223768900','0.035331199235970','1.1400470857981342','1.140047085798134','test','test','0.72'),('2019-05-23 11:59:59','2019-05-23 19:59:59','ETHBTC','4h','0.031100000000000','0.031077000000000','0.034286662761582','0.034261306065649','1.1024650405653378','1.102465040565338','test','test','0.07'),('2019-05-23 23:59:59','2019-05-26 03:59:59','ETHBTC','4h','0.031163000000000','0.031070000000000','0.034281027940264','0.034178722783557','1.1000554484569378','1.100055448456938','test','test','0.29'),('2019-05-26 07:59:59','2019-05-26 19:59:59','ETHBTC','4h','0.031218000000000','0.030593640000000','0.034258293460995','0.033573127591775','1.0973891172078714','1.097389117207871','test','test','2.00'),('2019-05-28 15:59:59','2019-05-29 03:59:59','ETHBTC','4h','0.031169000000000','0.031048000000000','0.034106034378946','0.033973632628494','1.0942293425822596','1.094229342582260','test','test','0.38'),('2019-05-29 07:59:59','2019-05-29 11:59:59','ETHBTC','4h','0.031023000000000','0.031040000000000','0.034076611767735','0.034095285087532','1.0984305762735678','1.098430576273568','test','test','0.0'),('2019-05-29 15:59:59','2019-05-30 03:59:59','ETHBTC','4h','0.031298000000000','0.032502000000000','0.034080761394356','0.035391811196861','1.0889117961005954','1.088911796100595','test','test','0.63'),('2019-05-30 07:59:59','2019-05-30 19:59:59','ETHBTC','4h','0.032545000000000','0.031894100000000','0.034372105794913','0.033684663679015','1.0561409062809375','1.056140906280937','test','test','2.00'),('2019-05-31 23:59:59','2019-06-01 15:59:59','ETHBTC','4h','0.031314000000000','0.031134000000000','0.034219340880269','0.034022640319547','1.0927808928999523','1.092780892899952','test','test','0.57'),('2019-06-04 15:59:59','2019-06-04 19:59:59','ETHBTC','4h','0.031330000000000','0.031103000000000','0.034175629644553','0.033928011772567','1.090827629893173','1.090827629893173','test','test','0.72'),('2019-06-04 23:59:59','2019-06-05 03:59:59','ETHBTC','4h','0.031396000000000','0.031055000000000','0.034120603450778','0.033750010834626','1.0867818655490649','1.086781865549065','test','test','1.08'),('2019-06-05 07:59:59','2019-06-07 07:59:59','ETHBTC','4h','0.031399000000000','0.031223000000000','0.034038249536078','0.033847455819133','1.0840552099136278','1.084055209913628','test','test','0.56'),('2019-06-07 11:59:59','2019-06-07 15:59:59','ETHBTC','4h','0.031276000000000','0.031344000000000','0.033995850932312','0.034069764407929','1.0869628767205668','1.086962876720567','test','test','0.0'),('2019-06-07 19:59:59','2019-06-07 23:59:59','ETHBTC','4h','0.031224000000000','0.031196000000000','0.034012276149116','0.033981775773374','1.0892991336509166','1.089299133650917','test','test','0.08'),('2019-06-08 07:59:59','2019-06-08 11:59:59','ETHBTC','4h','0.031228000000000','0.031142000000000','0.034005498287840','0.033911849227613','1.0889425607736718','1.088942560773672','test','test','0.27'),('2019-06-12 03:59:59','2019-06-12 11:59:59','ETHBTC','4h','0.031089000000000','0.031110000000000','0.033984687385568','0.034007643364696','1.093141863217458','1.093141863217458','test','test','0.14'),('2019-06-12 15:59:59','2019-06-13 23:59:59','ETHBTC','4h','0.031134000000000','0.030996000000000','0.033989788714263','0.033839130564248','1.091725724746665','1.091725724746665','test','test','0.44'),('2019-07-01 19:59:59','2019-07-02 15:59:59','ETHBTC','4h','0.027624000000000','0.027285000000000','0.033956309125370','0.033539599423897','1.2292321577385767','1.229232157738577','test','test','1.22'),('2019-07-07 19:59:59','2019-07-08 11:59:59','ETHBTC','4h','0.026690000000000','0.026156200000000','0.033863706969488','0.033186432830098','1.2687788298796385','1.268778829879639','test','test','2.00'),('2019-07-24 23:59:59','2019-07-26 03:59:59','ETHBTC','4h','0.022155000000000','0.022153000000000','0.033713201605179','0.033710158210766','1.5216972062820429','1.521697206282043','test','test','0.80'),('2019-07-26 07:59:59','2019-07-27 03:59:59','ETHBTC','4h','0.022156000000000','0.021919000000000','0.033712525295309','0.033351906569231','1.5215980003298928','1.521598000329893','test','test','1.06'),('2019-07-27 19:59:59','2019-07-27 23:59:59','ETHBTC','4h','0.022025000000000','0.021871000000000','0.033632387800625','0.033397228312711','1.5270096617763953','1.527009661776395','test','test','0.69'),('2019-07-28 07:59:59','2019-07-28 11:59:59','ETHBTC','4h','0.022038000000000','0.022015000000000','0.033580130136644','0.033545084170897','1.5237376411944923','1.523737641194492','test','test','0.10'),('2019-07-28 23:59:59','2019-07-29 11:59:59','ETHBTC','4h','0.022165000000000','0.022031000000000','0.033572342144256','0.033369378289199','1.5146556347510036','1.514655634751004','test','test','0.60'),('2019-07-29 15:59:59','2019-07-29 19:59:59','ETHBTC','4h','0.021978000000000','0.022110000000000','0.033527239065354','0.033728603864545','1.52549090296453','1.525490902964530','test','test','0.0'),('2019-07-29 23:59:59','2019-07-30 03:59:59','ETHBTC','4h','0.022183000000000','0.021908000000000','0.033571986798508','0.033155798890218','1.5134105755987919','1.513410575598792','test','test','1.23'),('2019-08-14 03:59:59','2019-08-14 19:59:59','ETHBTC','4h','0.019593000000000','0.019201140000000','0.033479500596666','0.032809910584733','1.708748052705853','1.708748052705853','test','test','2.00'),('2019-08-18 19:59:59','2019-08-19 03:59:59','ETHBTC','4h','0.018877000000000','0.018891000000000','0.033330702816236','0.033355422307650','1.765677958162643','1.765677958162643','test','test','0.08'),('2019-08-19 07:59:59','2019-08-19 11:59:59','ETHBTC','4h','0.018760000000000','0.018740000000000','0.033336196036550','0.033300656381927','1.7769827311594057','1.776982731159406','test','test','0.10'),('2019-08-19 15:59:59','2019-08-19 19:59:59','ETHBTC','4h','0.018809000000000','0.018532000000000','0.033328298335523','0.032837472739322','1.7719335602915152','1.771933560291515','test','test','1.47'),('2019-08-22 11:59:59','2019-08-23 15:59:59','ETHBTC','4h','0.018688000000000','0.018712000000000','0.033219225980812','0.033261887658013','1.7775698833910412','1.777569883391041','test','test','0.0'),('2019-08-24 11:59:59','2019-08-25 11:59:59','ETHBTC','4h','0.018882000000000','0.018722000000000','0.033228706353523','0.032947136974402','1.759808619506573','1.759808619506573','test','test','0.84'),('2019-08-25 15:59:59','2019-08-25 19:59:59','ETHBTC','4h','0.018675000000000','0.018420000000000','0.033166135380385','0.032713264455512','1.7759644112656017','1.775964411265602','test','test','1.36'),('2019-09-08 03:59:59','2019-09-08 07:59:59','ETHBTC','4h','0.017357000000000','0.017220000000000','0.033065497397080','0.032804509142001','1.9050237596981043','1.905023759698104','test','test','0.78'),('2019-09-08 11:59:59','2019-09-09 07:59:59','ETHBTC','4h','0.017322000000000','0.017463000000000','0.033007500007062','0.033276178999153','1.9055247666009953','1.905524766600995','test','test','0.06'),('2019-09-09 11:59:59','2019-09-12 15:59:59','ETHBTC','4h','0.017554000000000','0.017409000000000','0.033067206449749','0.032794063864856','1.8837419647800688','1.883741964780069','test','test','0.82'),('2019-09-12 19:59:59','2019-09-12 23:59:59','ETHBTC','4h','0.017409000000000','0.017352000000000','0.033006508097551','0.032898439227337','1.8959450914785965','1.895945091478596','test','test','0.32'),('2019-09-13 19:59:59','2019-09-14 11:59:59','ETHBTC','4h','0.017485000000000','0.017520000000000','0.032982492793059','0.033048514368567','1.886330728799479','1.886330728799479','test','test','0.0'),('2019-09-14 15:59:59','2019-09-24 11:59:59','ETHBTC','4h','0.017868000000000','0.020317000000000','0.032997164254283','0.037519777599858','1.8467183934566198','1.846718393456620','test','test','0.0'),('2019-09-24 15:59:59','2019-09-24 19:59:59','ETHBTC','4h','0.020214000000000','0.019809720000000','0.034002189442188','0.033322145653344','1.6821108856331477','1.682110885633148','test','test','1.99'),('2019-09-25 19:59:59','2019-09-25 23:59:59','ETHBTC','4h','0.020207000000000','0.020163000000000','0.033851068600223','0.033777359142193','1.6752149552245812','1.675214955224581','test','test','0.21'),('2019-09-26 03:59:59','2019-09-26 15:59:59','ETHBTC','4h','0.020138000000000','0.020179000000000','0.033834688720661','0.033903574520519','1.680141459959325','1.680141459959325','test','test','0.10'),('2019-09-26 19:59:59','2019-10-11 19:59:59','ETHBTC','4h','0.020305000000000','0.021802000000000','0.033849996676185','0.036345610811829','1.6670769109177486','1.667076910917749','test','test','0.0'),('2019-10-11 23:59:59','2019-10-12 19:59:59','ETHBTC','4h','0.021873000000000','0.021619000000000','0.034404577595217','0.034005054772139','1.5729245003070857','1.572924500307086','test','test','1.16'),('2019-10-13 07:59:59','2019-10-13 11:59:59','ETHBTC','4h','0.021801000000000','0.021858000000000','0.034315794745644','0.034405515414444','1.5740468210469245','1.574046821046925','test','test','0.0'),('2019-10-13 15:59:59','2019-10-13 19:59:59','ETHBTC','4h','0.021845000000000','0.021697000000000','0.034335732672044','0.034103107886717','1.5717890900455027','1.571789090045503','test','test','0.67'),('2019-10-13 23:59:59','2019-10-15 23:59:59','ETHBTC','4h','0.021874000000000','0.022119000000000','0.034284038275305','0.034668037058218','1.5673419710754624','1.567341971075462','test','test','0.0'),('2019-10-16 03:59:59','2019-10-16 11:59:59','ETHBTC','4h','0.021998000000000','0.021939000000000','0.034369371338174','0.034277190553150','1.562386186843087','1.562386186843087','test','test','0.26'),('2019-10-17 15:59:59','2019-10-17 23:59:59','ETHBTC','4h','0.021955000000000','0.021952000000000','0.034348886719280','0.034344193179760','1.564513173276247','1.564513173276247','test','test','0.25'),('2019-10-23 23:59:59','2019-10-24 03:59:59','ETHBTC','4h','0.021742000000000','0.021602000000000','0.034347843710498','0.034126672791564','1.5797922781021885','1.579792278102188','test','test','0.64'),('2019-10-24 07:59:59','2019-10-24 23:59:59','ETHBTC','4h','0.021598000000000','0.021636000000000','0.034298694617401','0.034359040501069','1.5880495702102666','1.588049570210267','test','test','0.0'),('2019-10-25 03:59:59','2019-10-25 15:59:59','ETHBTC','4h','0.021679000000000','0.021261000000000','0.034312104813772','0.033650521723585','1.5827346655183356','1.582734665518336','test','test','1.92'),('2019-11-05 15:59:59','2019-11-07 11:59:59','ETHBTC','4h','0.020321000000000','0.020291000000000','0.034165086349286','0.034114648251236','1.681269935007431','1.681269935007431','test','test','0.49'),('2019-11-07 15:59:59','2019-11-07 19:59:59','ETHBTC','4h','0.020208000000000','0.020226000000000','0.034153877883053','0.034184299983305','1.6901166806736274','1.690116680673627','test','test','0.0'),('2019-11-07 23:59:59','2019-11-08 07:59:59','ETHBTC','4h','0.020258000000000','0.020225000000000','0.034160638349775','0.034104991145434','1.6862789194281436','1.686278919428144','test','test','0.16'),('2019-11-08 11:59:59','2019-11-21 11:59:59','ETHBTC','4h','0.020405000000000','0.021376000000000','0.034148272304366','0.035773264826176','1.6735247392485284','1.673524739248528','test','test','0.0'),('2019-12-10 23:59:59','2019-12-11 03:59:59','ETHBTC','4h','0.020149000000000','0.020172000000000','0.034509381753657','0.034548774069918','1.7127094026332488','1.712709402633249','test','test','0.0'),('2019-12-11 07:59:59','2019-12-11 15:59:59','ETHBTC','4h','0.020175000000000','0.019906000000000','0.034518135601715','0.034057893793692','1.710936089304354','1.710936089304354','test','test','1.33'),('2019-12-12 19:59:59','2019-12-12 23:59:59','ETHBTC','4h','0.020132000000000','0.020125000000000','0.034415859644377','0.034403893072873','1.709510214801157','1.709510214801157','test','test','0.03'),('2019-12-14 19:59:59','2019-12-14 23:59:59','ETHBTC','4h','0.020096000000000','0.020072000000000','0.034413200406265','0.034372101838901','1.7124403068404104','1.712440306840410','test','test','0.11'),('2019-12-15 11:59:59','2019-12-15 15:59:59','ETHBTC','4h','0.020073000000000','0.020109000000000','0.034404067391295','0.034465769499903','1.7139474613308978','1.713947461330898','test','test','0.0'),('2019-12-15 19:59:59','2019-12-15 23:59:59','ETHBTC','4h','0.020087000000000','0.020012000000000','0.034417778970986','0.034289271308178','1.713435504106426','1.713435504106426','test','test','0.37'),('2019-12-29 19:59:59','2019-12-31 15:59:59','ETHBTC','4h','0.018054000000000','0.018033000000000','0.034389221712584','0.034349220956189','1.9047979235949926','1.904797923594993','test','test','0.38'),('2019-12-31 19:59:59','2019-12-31 23:59:59','ETHBTC','4h','0.017915000000000','0.017953000000000','0.034380332655607','0.034453257726269','1.919080806899656','1.919080806899656','test','test','0.0'),('2020-01-01 03:59:59','2020-01-01 15:59:59','ETHBTC','4h','0.018021000000000','0.018253000000000','0.034396538226866','0.034839354766938','1.9086919830678406','1.908691983067841','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:08:43
