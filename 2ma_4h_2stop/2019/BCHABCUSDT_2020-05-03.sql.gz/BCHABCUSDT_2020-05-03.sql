-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-02 19:59:59','2019-05-02 23:59:59','BCHABCUSDT','4h','269.000000000000000','269.269999999999982','222.222222222222200','222.445270549359748','0.8261049153242461','0.826104915324246','test','test','0.0'),('2019-05-03 03:59:59','2019-05-03 11:59:59','BCHABCUSDT','4h','272.220000000000027','289.709999999999980','222.271788517141687','236.552640699805693','0.8165152763101229','0.816515276310123','test','test','0.0'),('2019-05-03 15:59:59','2019-05-04 15:59:59','BCHABCUSDT','4h','290.589999999999975','284.778199999999970','225.445311224400342','220.936404999912327','0.7758192340562317','0.775819234056232','test','test','2.00'),('2019-05-04 19:59:59','2019-05-06 07:59:59','BCHABCUSDT','4h','282.990000000000009','277.610000000000014','224.443332063403005','220.176378720524781','0.7931140042524577','0.793114004252458','test','test','1.90'),('2019-05-06 11:59:59','2019-05-08 03:59:59','BCHABCUSDT','4h','286.639999999999986','283.269999999999982','223.495120209430070','220.867508727760452','0.779706671118581','0.779706671118581','test','test','1.17'),('2019-05-08 07:59:59','2019-05-08 15:59:59','BCHABCUSDT','4h','285.089999999999975','286.129999999999995','222.911206546836837','223.724380122931109','0.7818976693213963','0.781897669321396','test','test','0.0'),('2019-05-08 19:59:59','2019-05-08 23:59:59','BCHABCUSDT','4h','284.660000000000025','286.209999999999980','223.091911785968904','224.306667857310998','0.7837135944142798','0.783713594414280','test','test','0.0'),('2019-05-09 03:59:59','2019-05-09 11:59:59','BCHABCUSDT','4h','291.000000000000000','285.180000000000007','223.361857579600468','218.894620428008466','0.7675665208920979','0.767566520892098','test','test','1.99'),('2019-05-09 15:59:59','2019-05-09 19:59:59','BCHABCUSDT','4h','282.509999999999991','279.000000000000000','222.369138212579998','219.606348664860775','0.787119529264734','0.787119529264734','test','test','1.24'),('2019-05-09 23:59:59','2019-05-10 03:59:59','BCHABCUSDT','4h','284.430000000000007','281.730000000000018','221.755184979753523','219.650136287824637','0.779647663677367','0.779647663677367','test','test','0.94'),('2019-05-10 07:59:59','2019-05-10 11:59:59','BCHABCUSDT','4h','292.420000000000016','286.571599999999989','221.287396381547097','216.861648453916132','0.756745080300756','0.756745080300756','test','test','2.00'),('2019-05-10 15:59:59','2019-05-17 11:59:59','BCHABCUSDT','4h','286.459999999999980','351.100000000000023','220.303896842073556','270.015702650464448','0.7690564017387195','0.769056401738719','test','test','0.0'),('2019-05-17 15:59:59','2019-05-17 19:59:59','BCHABCUSDT','4h','346.860000000000014','354.569999999999993','231.350964799493767','236.493431323751651','0.6669865790217775','0.666986579021777','test','test','0.0'),('2019-05-17 23:59:59','2019-05-18 07:59:59','BCHABCUSDT','4h','367.389999999999986','360.042199999999980','232.493735138217744','227.843860435453394','0.6328254311173895','0.632825431117390','test','test','2.00'),('2019-05-18 11:59:59','2019-05-23 07:59:59','BCHABCUSDT','4h','357.689999999999998','378.160000000000025','231.460429648714552','244.706522620028267','0.6470978491115619','0.647097849111562','test','test','0.15'),('2019-05-23 11:59:59','2019-05-26 11:59:59','BCHABCUSDT','4h','382.800000000000011','393.449999999999989','234.404005864562038','240.925433927408420','0.6123406631780617','0.612340663178062','test','test','0.0'),('2019-05-26 15:59:59','2019-05-30 23:59:59','BCHABCUSDT','4h','403.379999999999995','420.990000000000009','235.853212100750142','246.149644906278951','0.5846923796438845','0.584692379643885','test','test','0.0'),('2019-05-31 03:59:59','2019-05-31 07:59:59','BCHABCUSDT','4h','422.670000000000016','424.290000000000020','238.141308279756544','239.054050890808185','0.5634213648467044','0.563421364846704','test','test','0.0'),('2019-05-31 11:59:59','2019-06-03 07:59:59','BCHABCUSDT','4h','422.089999999999975','425.300000000000011','238.344139971101299','240.156750289533960','0.5646761116612602','0.564676111661260','test','test','0.0'),('2019-06-03 11:59:59','2019-06-03 15:59:59','BCHABCUSDT','4h','427.879999999999995','423.920000000000016','238.746942264086357','236.537355717938425','0.5579764005424099','0.557976400542410','test','test','0.92'),('2019-06-03 19:59:59','2019-06-03 23:59:59','BCHABCUSDT','4h','428.670000000000016','420.096600000000024','238.255923031609058','233.490804570976877','0.5558026524636878','0.555802652463688','test','test','1.99'),('2019-06-13 07:59:59','2019-06-13 11:59:59','BCHABCUSDT','4h','400.759999999999991','398.670000000000016','237.197007818135233','235.960003759995942','0.5918679704015751','0.591867970401575','test','test','0.52'),('2019-06-13 15:59:59','2019-06-14 03:59:59','BCHABCUSDT','4h','417.519999999999982','409.169600000000003','236.922118027437591','232.183675666888860','0.5674509437330849','0.567450943733085','test','test','1.99'),('2019-06-14 07:59:59','2019-06-14 19:59:59','BCHABCUSDT','4h','406.850000000000023','404.160000000000025','235.869130836204505','234.309617595576782','0.5797446991181135','0.579744699118114','test','test','0.66'),('2019-06-14 23:59:59','2019-06-18 07:59:59','BCHABCUSDT','4h','419.769999999999982','415.870000000000005','235.522572338287290','233.334378727216205','0.5610752848900286','0.561075284890029','test','test','0.92'),('2019-06-18 11:59:59','2019-06-18 15:59:59','BCHABCUSDT','4h','413.860000000000014','413.829999999999984','235.036307091382582','235.019269713494538','0.5679125962677779','0.567912596267778','test','test','0.00'),('2019-06-18 23:59:59','2019-06-19 03:59:59','BCHABCUSDT','4h','413.870000000000005','413.350000000000023','235.032521007407468','234.737218349752055','0.567889726260438','0.567889726260438','test','test','0.12'),('2019-06-19 07:59:59','2019-06-19 15:59:59','BCHABCUSDT','4h','419.560000000000002','411.680000000000007','234.966898194595160','230.553848433480141','0.5600316955729697','0.560031695572970','test','test','1.87'),('2019-06-19 19:59:59','2019-06-19 23:59:59','BCHABCUSDT','4h','411.540000000000020','415.389999999999986','233.986220469902946','236.175186181156107','0.5685625224034188','0.568562522403419','test','test','0.0'),('2019-06-20 03:59:59','2019-06-20 07:59:59','BCHABCUSDT','4h','415.680000000000007','410.259999999999991','234.472657294625861','231.415397377052528','0.5640700954932301','0.564070095493230','test','test','1.30'),('2019-06-21 03:59:59','2019-06-26 23:59:59','BCHABCUSDT','4h','422.740000000000009','488.550000000000011','233.793266201831813','270.189005542188852','0.5530426886545674','0.553042688654567','test','test','0.0'),('2019-06-27 03:59:59','2019-06-27 07:59:59','BCHABCUSDT','4h','484.360000000000014','474.672799999999995','241.881208277466641','237.043584111917312','0.4993831205662454','0.499383120566245','test','test','2.00'),('2019-07-09 03:59:59','2019-07-09 11:59:59','BCHABCUSDT','4h','423.000000000000000','414.930000000000007','240.806180685122399','236.212076954321134','0.5692817510286582','0.569281751028658','test','test','1.90'),('2019-07-10 03:59:59','2019-07-10 07:59:59','BCHABCUSDT','4h','417.930000000000007','414.240000000000009','239.785268744944318','237.668149510458051','0.5737450499962776','0.573745049996278','test','test','0.88'),('2019-07-20 19:59:59','2019-07-20 23:59:59','BCHABCUSDT','4h','334.230000000000018','327.545400000000029','239.314797803947386','234.528501847868426','0.7160183041736151','0.716018304173615','test','test','1.99'),('2019-07-26 19:59:59','2019-07-26 23:59:59','BCHABCUSDT','4h','319.560000000000002','317.160000000000025','238.251176480374284','236.461832308535207','0.7455600715996191','0.745560071599619','test','test','0.75'),('2019-07-27 03:59:59','2019-07-27 07:59:59','BCHABCUSDT','4h','320.790000000000020','318.850000000000023','237.853544442187854','236.415108467818811','0.7414618424582682','0.741461842458268','test','test','0.60'),('2019-07-30 15:59:59','2019-08-07 19:59:59','BCHABCUSDT','4h','319.509999999999991','336.759999999999991','237.533892003439149','250.358090423079602','0.7434317924429256','0.743431792442926','test','test','0.42'),('2019-08-07 23:59:59','2019-08-08 15:59:59','BCHABCUSDT','4h','338.339999999999975','331.573199999999986','240.383713874470345','235.576039596980934','0.7104797359888584','0.710479735988858','test','test','1.99'),('2019-08-08 23:59:59','2019-08-09 03:59:59','BCHABCUSDT','4h','333.620000000000005','330.490000000000009','239.315341812806054','237.070101659715476','0.71732912239316','0.717329122393160','test','test','0.93'),('2019-08-11 19:59:59','2019-08-12 11:59:59','BCHABCUSDT','4h','338.730000000000018','331.955399999999997','238.816399556563709','234.040071565432442','0.7050346870857724','0.705034687085772','test','test','2.00'),('2019-08-12 15:59:59','2019-08-13 03:59:59','BCHABCUSDT','4h','330.860000000000014','329.339999999999975','237.754993336312310','236.662725942637650','0.7185969695227961','0.718596969522796','test','test','0.45'),('2019-08-13 07:59:59','2019-08-14 19:59:59','BCHABCUSDT','4h','331.810000000000002','325.173799999999972','237.512267248829033','232.762021903852428','0.7158080445098973','0.715808044509897','test','test','2.00'),('2019-08-19 07:59:59','2019-08-19 11:59:59','BCHABCUSDT','4h','322.800000000000011','323.000000000000000','236.456657172167553','236.603160677230846','0.7325175253165042','0.732517525316504','test','test','0.0'),('2019-08-19 15:59:59','2019-08-19 19:59:59','BCHABCUSDT','4h','323.639999999999986','320.540000000000020','236.489213506626101','234.223991155030092','0.7307168876116243','0.730716887611624','test','test','0.95'),('2019-08-19 23:59:59','2019-08-20 03:59:59','BCHABCUSDT','4h','324.939999999999998','320.850000000000023','235.985830761826946','233.015491475140578','0.726244324373198','0.726244324373198','test','test','1.25'),('2019-09-03 03:59:59','2019-09-03 11:59:59','BCHABCUSDT','4h','296.120000000000005','296.379999999999995','235.325755364785550','235.532376654785679','0.7946972692313439','0.794697269231344','test','test','0.48'),('2019-09-03 15:59:59','2019-09-04 11:59:59','BCHABCUSDT','4h','301.129999999999995','297.220000000000027','235.371671207007807','232.315505317128356','0.7816281048285053','0.781628104828505','test','test','1.29'),('2019-09-04 15:59:59','2019-09-04 19:59:59','BCHABCUSDT','4h','293.149999999999977','297.379999999999995','234.692523231479043','238.079012650783682','0.8005885152020435','0.800588515202044','test','test','0.0'),('2019-09-04 23:59:59','2019-09-05 03:59:59','BCHABCUSDT','4h','294.149999999999977','292.850000000000023','235.445076435768925','234.404523658728351','0.8004252131081725','0.800425213108172','test','test','0.44'),('2019-09-06 07:59:59','2019-09-06 11:59:59','BCHABCUSDT','4h','295.069999999999993','299.000000000000000','235.213842485315467','238.346625895920710','0.7971459060064238','0.797145906006424','test','test','0.0'),('2019-09-06 15:59:59','2019-09-06 19:59:59','BCHABCUSDT','4h','297.920000000000016','291.961600000000033','235.910016576561105','231.191816245029912','0.79185692996966','0.791856929969660','test','test','1.99'),('2019-09-07 15:59:59','2019-09-07 19:59:59','BCHABCUSDT','4h','298.930000000000007','299.160000000000025','234.861527613998646','235.042232633070768','0.7856739959656062','0.785673995965606','test','test','0.0'),('2019-09-07 23:59:59','2019-09-08 11:59:59','BCHABCUSDT','4h','299.620000000000005','300.230000000000018','234.901684284903553','235.379923479262374','0.7839986792767624','0.783998679276762','test','test','0.0'),('2019-09-08 15:59:59','2019-09-09 07:59:59','BCHABCUSDT','4h','305.680000000000007','299.566399999999987','235.007959661427748','230.307800468199190','0.7688038460528256','0.768803846052826','test','test','2.00'),('2019-09-09 11:59:59','2019-09-10 15:59:59','BCHABCUSDT','4h','309.389999999999986','303.202200000000005','233.963479840710221','229.284210243896041','0.7562089267290806','0.756208926729081','test','test','1.99'),('2019-09-10 19:59:59','2019-09-11 07:59:59','BCHABCUSDT','4h','301.990000000000009','301.490000000000009','232.923642152529311','232.537994213603298','0.7712958778520127','0.771295877852013','test','test','0.16'),('2019-09-11 11:59:59','2019-09-11 15:59:59','BCHABCUSDT','4h','300.220000000000027','294.629999999999995','232.837942610545753','228.502574882902820','0.7755577330309298','0.775557733030930','test','test','1.86'),('2019-09-12 15:59:59','2019-09-12 19:59:59','BCHABCUSDT','4h','299.290000000000020','299.829999999999984','231.874527559958437','232.292891838358514','0.7747486637039608','0.774748663703961','test','test','0.0'),('2019-09-12 23:59:59','2019-09-13 03:59:59','BCHABCUSDT','4h','300.009999999999991','298.240000000000009','231.967497399602934','230.598934783699150','0.7731992180247423','0.773199218024742','test','test','0.58'),('2019-09-14 15:59:59','2019-09-19 03:59:59','BCHABCUSDT','4h','303.959999999999980','310.240000000000009','231.663372373846528','236.449679712008646','0.7621508500258144','0.762150850025814','test','test','1.03'),('2019-09-19 07:59:59','2019-09-20 19:59:59','BCHABCUSDT','4h','310.149999999999977','313.579999999999984','232.726996226771433','235.300762459426039','0.7503691640392438','0.750369164039244','test','test','0.0'),('2019-09-20 23:59:59','2019-09-22 03:59:59','BCHABCUSDT','4h','315.310000000000002','309.003800000000012','233.298944278472419','228.632965392902975','0.7399034102263563','0.739903410226356','test','test','1.99'),('2019-10-07 15:59:59','2019-10-08 11:59:59','BCHABCUSDT','4h','233.599999999999994','233.139999999999986','232.262060081679266','231.804694723641717','0.9942725174729421','0.994272517472942','test','test','0.37'),('2019-10-09 11:59:59','2019-10-09 15:59:59','BCHABCUSDT','4h','232.250000000000000','237.879999999999995','232.160423335448712','237.788251896820412','0.9996143093022549','0.999614309302255','test','test','0.0'),('2019-10-09 19:59:59','2019-10-10 11:59:59','BCHABCUSDT','4h','237.250000000000000','232.504999999999995','233.411051904642392','228.742830866549554','0.9838189753620332','0.983818975362033','test','test','2.00'),('2019-10-20 19:59:59','2019-10-23 03:59:59','BCHABCUSDT','4h','225.120000000000005','220.617600000000010','232.373669451732894','227.726196062698222','1.0322213461786287','1.032221346178629','test','test','1.99'),('2019-10-25 15:59:59','2019-11-08 15:59:59','BCHABCUSDT','4h','235.370000000000005','279.550000000000011','231.340897587502951','274.764617073486193','0.9828818353549855','0.982881835354986','test','test','0.0'),('2019-11-09 23:59:59','2019-11-10 03:59:59','BCHABCUSDT','4h','282.569999999999993','280.519999999999982','240.990613028832541','239.242264808182398','0.8528527905610381','0.852852790561038','test','test','0.72'),('2019-11-10 07:59:59','2019-11-10 15:59:59','BCHABCUSDT','4h','287.079999999999984','284.050000000000011','240.602091202021398','238.062644579678789','0.8381011954926202','0.838101195492620','test','test','1.05'),('2019-11-10 19:59:59','2019-11-11 11:59:59','BCHABCUSDT','4h','293.430000000000007','287.561399999999992','240.037769730389726','235.237014335781936','0.8180409969341571','0.818040996934157','test','test','2.00'),('2019-11-11 15:59:59','2019-11-12 15:59:59','BCHABCUSDT','4h','286.899999999999977','286.949999999999989','238.970935198254665','239.012582276539490','0.832941565696252','0.832941565696252','test','test','0.23'),('2019-11-12 19:59:59','2019-11-13 15:59:59','BCHABCUSDT','4h','288.449999999999989','285.290000000000020','238.980190104540156','236.362137059886521','0.8284977989410303','0.828497798941030','test','test','1.09'),('2019-11-13 19:59:59','2019-11-13 23:59:59','BCHABCUSDT','4h','285.120000000000005','285.420000000000016','238.398400539061612','238.649240606968874','0.8361335596908727','0.836133559690873','test','test','0.0'),('2019-11-14 03:59:59','2019-11-14 07:59:59','BCHABCUSDT','4h','284.300000000000011','278.614000000000033','238.454142776374283','233.685059920846811','0.8387412689988543','0.838741268998854','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:50:10
