-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 03:59:59','2019-05-23 15:59:59','RENBTC','4h','0.000004700000000','0.000004606000000','0.033333333333333','0.032666666666666','7092.198581560284','7092.198581560283856','test','test','2.00'),('2019-05-23 19:59:59','2019-05-24 03:59:59','RENBTC','4h','0.000004500000000','0.000004410000000','0.033185185185185','0.032521481481481','7374.485596707802','7374.485596707801960','test','test','1.99'),('2019-05-24 07:59:59','2019-05-24 15:59:59','RENBTC','4h','0.000004500000000','0.000004410000000','0.033037695473251','0.032376941563786','7341.710105166862','7341.710105166862377','test','test','1.99'),('2019-05-24 19:59:59','2019-05-24 23:59:59','RENBTC','4h','0.000004090000000','0.000004008200000','0.032890861271148','0.032233044045725','8041.7753719187185','8041.775371918718520','test','test','1.99'),('2019-05-29 23:59:59','2019-05-30 03:59:59','RENBTC','4h','0.000004040000000','0.000004020000000','0.032744679665498','0.032582577290916','8105.118729083663','8105.118729083663311','test','test','0.49'),('2019-05-30 07:59:59','2019-05-30 11:59:59','RENBTC','4h','0.000003910000000','0.000003970000000','0.032708656915591','0.033210580039615','8365.385400406878','8365.385400406878034','test','test','0.0'),('2019-05-30 23:59:59','2019-06-14 03:59:59','RENBTC','4h','0.000004260000000','0.000005810000000','0.032820195387596','0.044761815775102','7704.271217745592','7704.271217745592367','test','test','0.0'),('2019-06-14 07:59:59','2019-06-14 15:59:59','RENBTC','4h','0.000005740000000','0.000005625200000','0.035473888807042','0.034764411030901','6180.120001226829','6180.120001226829118','test','test','2.00'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBTC','4h','0.000005820000000','0.000005703600000','0.035316227079011','0.034609902537431','6068.080254125543','6068.080254125543433','test','test','2.00'),('2019-06-16 19:59:59','2019-06-17 11:59:59','RENBTC','4h','0.000005610000000','0.000005497800000','0.035159266069771','0.034456080748376','6267.248853791563','6267.248853791563306','test','test','2.00'),('2019-06-18 07:59:59','2019-06-18 15:59:59','RENBTC','4h','0.000005440000000','0.000005331200000','0.035003002665016','0.034302942611716','6434.375489892688','6434.375489892688165','test','test','1.99'),('2019-06-20 03:59:59','2019-06-20 11:59:59','RENBTC','4h','0.000005590000000','0.000005478200000','0.034847433764283','0.034150485088997','6233.887972143629','6233.887972143628758','test','test','2.00'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBTC','4h','0.000005450000000','0.000005341000000','0.034692556280886','0.033998705155268','6365.606657043302','6365.606657043302221','test','test','2.00'),('2019-06-22 15:59:59','2019-06-23 11:59:59','RENBTC','4h','0.000005430000000','0.000005400000000','0.034538367141860','0.034347547433894','6360.656932202537','6360.656932202537064','test','test','0.55'),('2019-06-23 15:59:59','2019-06-23 19:59:59','RENBTC','4h','0.000005400000000','0.000005340000000','0.034495962762312','0.034112674287175','6388.141252279959','6388.141252279959190','test','test','1.11'),('2019-06-23 23:59:59','2019-06-24 03:59:59','RENBTC','4h','0.000005420000000','0.000005311600000','0.034410787545615','0.033722571794703','6348.853790703813','6348.853790703812592','test','test','1.99'),('2019-06-25 11:59:59','2019-06-25 19:59:59','RENBTC','4h','0.000005380000000','0.000005340000000','0.034257850712079','0.034003145502324','6367.6302438807925','6367.630243880792477','test','test','0.74'),('2019-06-26 03:59:59','2019-06-26 07:59:59','RENBTC','4h','0.000005360000000','0.000005252800000','0.034201249554355','0.033517224563268','6380.830140737934','6380.830140737934016','test','test','2.00'),('2019-06-26 15:59:59','2019-06-26 19:59:59','RENBTC','4h','0.000005510000000','0.000005399800000','0.034049244000780','0.033368259120764','6179.536116294092','6179.536116294091698','test','test','2.00'),('2019-06-26 23:59:59','2019-06-27 03:59:59','RENBTC','4h','0.000005420000000','0.000005311600000','0.033897914027444','0.033219955746895','6254.22768034014','6254.227680340140068','test','test','1.99'),('2019-06-27 07:59:59','2019-06-27 11:59:59','RENBTC','4h','0.000005640000000','0.000005527200000','0.033747256631766','0.033072311499131','5983.556140384042','5983.556140384042010','test','test','2.0'),('2019-06-27 15:59:59','2019-07-04 11:59:59','RENBTC','4h','0.000005580000000','0.000008320000000','0.033597268824514','0.050094852440852','6021.015918371643','6021.015918371643238','test','test','0.0'),('2019-07-04 15:59:59','2019-07-07 15:59:59','RENBTC','4h','0.000008260000000','0.000008094800000','0.037263398517033','0.036518130546692','4511.307326517352','4511.307326517351612','test','test','1.99'),('2019-07-09 19:59:59','2019-07-10 03:59:59','RENBTC','4h','0.000008000000000','0.000008400000000','0.037097783412513','0.038952672583139','4637.222926564139','4637.222926564139016','test','test','0.0'),('2019-07-10 07:59:59','2019-07-10 11:59:59','RENBTC','4h','0.000008270000000','0.000008104600000','0.037509981005986','0.036759781385866','4535.668803625822','4535.668803625821965','test','test','2.00'),('2019-07-10 15:59:59','2019-07-13 03:59:59','RENBTC','4h','0.000007900000000','0.000008150000000','0.037343269979292','0.038525019029270','4726.996199910407','4726.996199910407086','test','test','0.0'),('2019-07-13 07:59:59','2019-07-13 11:59:59','RENBTC','4h','0.000008590000000','0.000008418200000','0.037605880879287','0.036853763261701','4377.867389905393','4377.867389905392884','test','test','2.00'),('2019-07-13 15:59:59','2019-07-13 23:59:59','RENBTC','4h','0.000008530000000','0.000008359400000','0.037438743630935','0.036689968758316','4389.0672486441845','4389.067248644184474','test','test','1.99'),('2019-07-14 03:59:59','2019-07-14 15:59:59','RENBTC','4h','0.000008740000000','0.000008565200000','0.037272349214797','0.036526902230501','4264.57084837498','4264.570848374980415','test','test','2.00'),('2019-07-14 19:59:59','2019-07-14 23:59:59','RENBTC','4h','0.000008420000000','0.000008251600000','0.037106694329398','0.036364560442810','4406.9708229689095','4406.970822968909488','test','test','1.99'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBTC','4h','0.000007760000000','0.000007604800000','0.036941775687934','0.036202940174175','4760.538104115234','4760.538104115234091','test','test','1.99'),('2019-07-19 23:59:59','2019-07-30 11:59:59','RENBTC','4h','0.000007810000000','0.000010690000000','0.036777590018210','0.050339620652326','4709.038414623559','4709.038414623559220','test','test','0.0'),('2019-08-02 11:59:59','2019-08-03 03:59:59','RENBTC','4h','0.000011380000000','0.000011152400000','0.039791374603569','0.038995547111498','3496.6058526862134','3496.605852686213439','test','test','2.00'),('2019-08-03 07:59:59','2019-08-03 15:59:59','RENBTC','4h','0.000011000000000','0.000010780000000','0.039614524049776','0.038822233568780','3601.3203681614136','3601.320368161413626','test','test','1.99'),('2019-08-04 15:59:59','2019-08-04 19:59:59','RENBTC','4h','0.000011240000000','0.000011550000000','0.039438459498443','0.040526175018418','3508.7597418543687','3508.759741854368713','test','test','0.0'),('2019-08-04 23:59:59','2019-08-05 19:59:59','RENBTC','4h','0.000011430000000','0.000011220000000','0.039680174058438','0.038951141989123','3471.581282452979','3471.581282452978940','test','test','1.83'),('2019-08-05 23:59:59','2019-08-06 07:59:59','RENBTC','4h','0.000012070000000','0.000011828600000','0.039518166931923','0.038727803593285','3274.0817673507127','3274.081767350712653','test','test','2.00'),('2019-08-06 11:59:59','2019-08-06 15:59:59','RENBTC','4h','0.000011800000000','0.000011564000000','0.039342530634448','0.038555680021759','3334.1127656311864','3334.112765631186448','test','test','2.00'),('2019-08-06 23:59:59','2019-08-07 03:59:59','RENBTC','4h','0.000011320000000','0.000011093600000','0.039167674942739','0.038384321443884','3460.041956072379','3460.041956072378980','test','test','2.00'),('2019-08-09 19:59:59','2019-08-09 23:59:59','RENBTC','4h','0.000010980000000','0.000010760400000','0.038993596387438','0.038213724459689','3551.329361333171','3551.329361333171164','test','test','2.00'),('2019-08-15 23:59:59','2019-08-16 03:59:59','RENBTC','4h','0.000010240000000','0.000010035200000','0.038820291514605','0.038043885684313','3791.044093223155','3791.044093223154960','test','test','2.00'),('2019-09-18 15:59:59','2019-09-18 19:59:59','RENBTC','4h','0.000004570000000','0.000004478600000','0.038647756885651','0.037874801747938','8456.839581105323','8456.839581105323305','test','test','1.99'),('2019-09-18 23:59:59','2019-09-19 03:59:59','RENBTC','4h','0.000004600000000','0.000004508000000','0.038475989077271','0.037706469295726','8364.345451580579','8364.345451580578811','test','test','2.00'),('2019-09-19 11:59:59','2019-09-22 23:59:59','RENBTC','4h','0.000004540000000','0.000004880000000','0.038304984681372','0.041173639921827','8437.22129545634','8437.221295456340158','test','test','0.0'),('2019-09-23 03:59:59','2019-09-23 07:59:59','RENBTC','4h','0.000004940000000','0.000004860000000','0.038942463623695','0.038311816439506','7883.089802367432','7883.089802367431730','test','test','1.61'),('2019-09-23 11:59:59','2019-09-23 15:59:59','RENBTC','4h','0.000004840000000','0.000004810000000','0.038802319804986','0.038561809558261','8017.008224170751','8017.008224170751419','test','test','0.61'),('2019-09-27 03:59:59','2019-09-27 11:59:59','RENBTC','4h','0.000004680000000','0.000004800000000','0.038748873083492','0.039742433931787','8279.673735788887','8279.673735788886916','test','test','0.0'),('2019-09-27 15:59:59','2019-09-27 23:59:59','RENBTC','4h','0.000004770000000','0.000004720000000','0.038969664383113','0.038561177335072','8169.740960820359','8169.740960820358850','test','test','1.04'),('2019-09-28 03:59:59','2019-09-28 07:59:59','RENBTC','4h','0.000004620000000','0.000004710000000','0.038878889483548','0.039636270447513','8415.344044058103','8415.344044058103464','test','test','0.0'),('2019-09-28 11:59:59','2019-09-28 23:59:59','RENBTC','4h','0.000004810000000','0.000004713800000','0.039047196364430','0.038266252437141','8117.920242085147','8117.920242085147038','test','test','2.00'),('2019-09-29 03:59:59','2019-09-29 07:59:59','RENBTC','4h','0.000004730000000','0.000004690000000','0.038873653269476','0.038544912015612','8218.531346612357','8218.531346612357083','test','test','0.84'),('2019-09-29 11:59:59','2019-09-30 07:59:59','RENBTC','4h','0.000004710000000','0.000004670000000','0.038800599657507','0.038471082887592','8237.919247878273','8237.919247878273382','test','test','0.84'),('2019-09-30 11:59:59','2019-09-30 15:59:59','RENBTC','4h','0.000004670000000','0.000004620000000','0.038727373708637','0.038312733733170','8292.799509344039','8292.799509344038597','test','test','1.07'),('2019-09-30 19:59:59','2019-10-01 03:59:59','RENBTC','4h','0.000004800000000','0.000004740000000','0.038635231491866','0.038152291098218','8049.006560805463','8049.006560805462868','test','test','1.24'),('2019-10-01 07:59:59','2019-10-01 11:59:59','RENBTC','4h','0.000004720000000','0.000004730000000','0.038527911404389','0.038609538335330','8162.693094150189','8162.693094150188699','test','test','0.0'),('2019-10-01 15:59:59','2019-10-04 03:59:59','RENBTC','4h','0.000004820000000','0.000004850000000','0.038546050722376','0.038785963901146','7997.105958999125','7997.105958999124596','test','test','0.0'),('2019-10-04 07:59:59','2019-10-16 15:59:59','RENBTC','4h','0.000004960000000','0.000006740000000','0.038599364762102','0.052451556148502','7782.129992359363','7782.129992359363314','test','test','0.0'),('2019-10-16 19:59:59','2019-10-16 23:59:59','RENBTC','4h','0.000006790000000','0.000007120000000','0.041677629514636','0.043703199137586','6138.089766514842','6138.089766514842267','test','test','0.0'),('2019-10-17 03:59:59','2019-10-18 11:59:59','RENBTC','4h','0.000006830000000','0.000006870000000','0.042127756097514','0.042374477948744','6168.046280748689','6168.046280748689242','test','test','0.0'),('2019-10-18 19:59:59','2019-10-18 23:59:59','RENBTC','4h','0.000006830000000','0.000006710000000','0.042182583175565','0.041441454334999','6176.073671385749','6176.073671385748639','test','test','1.75'),('2019-10-19 23:59:59','2019-10-20 03:59:59','RENBTC','4h','0.000006880000000','0.000006742400000','0.042017887877661','0.041177530120108','6107.251145008882','6107.251145008882304','test','test','2.00'),('2019-10-20 15:59:59','2019-10-20 19:59:59','RENBTC','4h','0.000006970000000','0.000006830600000','0.041831141709316','0.040994518875130','6001.598523574749','6001.598523574749379','test','test','1.99'),('2019-10-21 07:59:59','2019-10-21 11:59:59','RENBTC','4h','0.000006830000000','0.000006820000000','0.041645225523941','0.041584251548064','6097.397587692728','6097.397587692727939','test','test','0.14'),('2019-10-22 07:59:59','2019-10-22 11:59:59','RENBTC','4h','0.000006840000000','0.000006970000000','0.041631675751524','0.042422921050895','6086.502302854418','6086.502302854418303','test','test','0.0'),('2019-10-22 15:59:59','2019-10-23 07:59:59','RENBTC','4h','0.000007140000000','0.000006997200000','0.041807508040273','0.040971357879468','5855.393282951446','5855.393282951446054','test','test','1.99'),('2019-10-23 11:59:59','2019-10-23 15:59:59','RENBTC','4h','0.000007110000000','0.000006967800000','0.041621696893428','0.040789262955559','5853.965807795749','5853.965807795749242','test','test','2.00'),('2019-10-23 19:59:59','2019-10-23 23:59:59','RENBTC','4h','0.000006830000000','0.000006900000000','0.041436711573901','0.041861392366020','6066.8684588435335','6066.868458843533517','test','test','0.0'),('2019-10-24 03:59:59','2019-10-24 07:59:59','RENBTC','4h','0.000006840000000','0.000007030000000','0.041531085083261','0.042684726335574','6071.796064804256','6071.796064804256275','test','test','0.0'),('2019-10-24 11:59:59','2019-10-25 15:59:59','RENBTC','4h','0.000007030000000','0.000006889400000','0.041787449805997','0.040951700809877','5944.160712090658','5944.160712090658308','test','test','1.99'),('2019-11-02 07:59:59','2019-11-02 11:59:59','RENBTC','4h','0.000006020000000','0.000005899600000','0.041601727806860','0.040769693250723','6910.586014428497','6910.586014428497037','test','test','1.99'),('2019-11-06 15:59:59','2019-11-07 07:59:59','RENBTC','4h','0.000006360000000','0.000006232800000','0.041416831238829','0.040588494614052','6512.080383463696','6512.080383463696307','test','test','2.00'),('2019-11-07 11:59:59','2019-11-10 19:59:59','RENBTC','4h','0.000006150000000','0.000006200000000','0.041232756433323','0.041567982095383','6704.513241190748','6704.513241190747976','test','test','0.81'),('2019-11-10 23:59:59','2019-11-17 07:59:59','RENBTC','4h','0.000006180000000','0.000006610000000','0.041307251024892','0.044181380141511','6684.021201438835','6684.021201438835305','test','test','0.0'),('2019-11-17 11:59:59','2019-11-17 15:59:59','RENBTC','4h','0.000006520000000','0.000006570000000','0.041945946384141','0.042267617752118','6433.427359530777','6433.427359530776812','test','test','0.0'),('2019-11-17 19:59:59','2019-11-17 23:59:59','RENBTC','4h','0.000006540000000','0.000006580000000','0.042017428910358','0.042274416243143','6424.683319626572','6424.683319626571574','test','test','0.0'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBTC','4h','0.000006530000000','0.000006430000000','0.042074537206532','0.041430210449924','6443.267566084565','6443.267566084565260','test','test','1.53'),('2019-11-22 03:59:59','2019-11-22 07:59:59','RENBTC','4h','0.000006440000000','0.000006370000000','0.041931353482842','0.041475577901507','6511.07973336049','6511.079733360489627','test','test','1.08'),('2019-11-23 19:59:59','2019-11-23 23:59:59','RENBTC','4h','0.000006410000000','0.000006420000000','0.041830070020323','0.041895327539855','6525.751953248465','6525.751953248464815','test','test','0.0'),('2019-11-24 03:59:59','2019-11-24 07:59:59','RENBTC','4h','0.000006360000000','0.000006440000000','0.041844571691330','0.042370918505057','6579.335171592732','6579.335171592731967','test','test','0.0'),('2019-12-14 19:59:59','2019-12-14 23:59:59','RENBTC','4h','0.000005310000000','0.000005203800000','0.041961537649936','0.041122306896937','7902.361139347603','7902.361139347603057','test','test','1.99'),('2019-12-15 03:59:59','2019-12-15 07:59:59','RENBTC','4h','0.000004920000000','0.000005010000000','0.041775041927047','0.042539219523273','8490.862180294127','8490.862180294127029','test','test','0.0'),('2019-12-15 11:59:59','2019-12-15 15:59:59','RENBTC','4h','0.000004970000000','0.000004950000000','0.041944859170653','0.041776066980831','8439.60949107704','8439.609491077040730','test','test','0.40'),('2019-12-15 23:59:59','2019-12-16 07:59:59','RENBTC','4h','0.000005050000000','0.000004949000000','0.041907349795137','0.041069202799234','8298.485107947898','8298.485107947897632','test','test','2.00'),('2019-12-24 15:59:59','2019-12-25 15:59:59','RENBTC','4h','0.000004810000000','0.000004713800000','0.041721094907158','0.040886673009015','8673.824305022545','8673.824305022544650','test','test','2.00'),('2019-12-31 11:59:59','2019-12-31 15:59:59','RENBTC','4h','0.000004500000000','0.000004480000000','0.041535667818682','0.041351064850599','9230.148404151603','9230.148404151603245','test','test','0.44'),('2020-01-02 03:59:59','2020-01-05 03:59:59','RENBTC','4h','0.000004540000000','0.000004670000000','0.041494644936886','0.042682817589264','9139.789633675331','9139.789633675331061','test','test','0.66'),('2020-01-05 07:59:59','2020-01-05 15:59:59','RENBTC','4h','0.000004710000000','0.000004670000000','0.041758683304081','0.041404044804683','8865.962484942911','8865.962484942911033','test','test','0.84'),('2020-01-05 19:59:59','2020-01-07 19:59:59','RENBTC','4h','0.000004830000000','0.000004830000000','0.041679874748659','0.041679874748659','8629.373653966735','8629.373653966735219','test','test','0.82'),('2020-01-07 23:59:59','2020-01-08 03:59:59','RENBTC','4h','0.000004750000000','0.000004655000000','0.041679874748659','0.040846277253686','8774.710473401965','8774.710473401964919','test','test','1.99'),('2020-01-08 19:59:59','2020-01-08 23:59:59','RENBTC','4h','0.000005090000000','0.000004988200000','0.041494630860888','0.040664738243670','8152.1868096046255','8152.186809604625523','test','test','2.00'),('2020-01-09 03:59:59','2020-01-13 07:59:59','RENBTC','4h','0.000005090000000','0.000005400000000','0.041310210279284','0.043826156288435','8115.954868228594','8115.954868228594023','test','test','1.17'),('2020-01-13 11:59:59','2020-01-14 07:59:59','RENBTC','4h','0.000005590000000','0.000005478200000','0.041869309392428','0.041031923204579','7490.03745839503','7490.037458395029716','test','test','2.00'),('2020-01-14 11:59:59','2020-01-14 15:59:59','RENBTC','4h','0.000005230000000','0.000005125400000','0.041683223572906','0.040849559101448','7970.023627706734','7970.023627706734260','test','test','1.99'),('2020-01-15 07:59:59','2020-01-15 11:59:59','RENBTC','4h','0.000005240000000','0.000005330000000','0.041497964801471','0.042210716105313','7919.458931578456','7919.458931578456031','test','test','0.0'),('2020-01-15 15:59:59','2020-01-15 19:59:59','RENBTC','4h','0.000005200000000','0.000005270000000','0.041656353980103','0.042217112591374','8010.837303865897','8010.837303865897411','test','test','0.0'),('2020-01-15 23:59:59','2020-01-16 03:59:59','RENBTC','4h','0.000005260000000','0.000005250000000','0.041780967004830','0.041701535508623','7943.14962069003','7943.149620690030133','test','test','0.19'),('2020-01-16 07:59:59','2020-01-16 11:59:59','RENBTC','4h','0.000005230000000','0.000005125400000','0.041763315561228','0.040928049250003','7985.337583408795','7985.337583408794671','test','test','1.99'),('2020-01-26 07:59:59','2020-01-26 11:59:59','RENBTC','4h','0.000004930000000','0.000004890000000','0.041577700825400','0.041240356396796','8433.610715091323','8433.610715091323073','test','test','0.81'),('2020-02-02 11:59:59','2020-02-02 15:59:59','RENBTC','4h','0.000004780000000','0.000004770000000','0.041502735396822','0.041415909590552','8682.580626950115','8682.580626950115402','test','test','0.20'),('2020-02-02 19:59:59','2020-02-10 11:59:59','RENBTC','4h','0.000004890000000','0.000005710000000','0.041483440773206','0.048439764174848','8483.32122151452','8483.321221514519493','test','test','0.20'),('2020-02-10 15:59:59','2020-02-16 15:59:59','RENBTC','4h','0.000005710000000','0.000005840000000','0.043029290418015','0.044008941513346','7535.777656394979','7535.777656394979203','test','test','0.52');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:08:22
