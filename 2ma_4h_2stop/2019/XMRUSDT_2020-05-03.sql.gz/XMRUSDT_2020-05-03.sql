-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-09-03 15:59:59','2019-09-04 03:59:59','XMRUSDT','4h','74.879999999999995','73.980000000000004','222.222222222222200','219.551282051282072','2.967711301044634','2.967711301044634','test','test','1.20'),('2019-09-05 03:59:59','2019-09-07 03:59:59','XMRUSDT','4h','74.329999999999998','73.959999999999994','221.628679962013280','220.525456343205974','2.9816854562358843','2.981685456235884','test','test','0.49'),('2019-09-07 07:59:59','2019-09-07 11:59:59','XMRUSDT','4h','74.700000000000003','75.939999999999998','221.383519157833888','225.058426303158001','2.96363479461625','2.963634794616250','test','test','0.0'),('2019-09-07 15:59:59','2019-09-09 03:59:59','XMRUSDT','4h','77.569999999999993','76.049999999999997','222.200165190128132','217.846107550718642','2.86451160487467','2.864511604874670','test','test','1.95'),('2019-09-09 07:59:59','2019-09-09 11:59:59','XMRUSDT','4h','75.530000000000001','76.560000000000002','221.232596825814909','224.249538103857930','2.9290692019835154','2.929069201983515','test','test','0.0'),('2019-09-09 15:59:59','2019-09-09 19:59:59','XMRUSDT','4h','75.709999999999994','75.140000000000001','221.903028220935568','220.232380669939261','2.9309606157830617','2.930960615783062','test','test','0.75'),('2019-09-12 23:59:59','2019-09-13 03:59:59','XMRUSDT','4h','74.879999999999995','73.879999999999995','221.531773209603102','218.573282648577418','2.9584905610256826','2.958490561025683','test','test','1.33'),('2019-09-13 23:59:59','2019-09-14 07:59:59','XMRUSDT','4h','76.790000000000006','75.349999999999994','220.874330862708490','216.732397844837635','2.876342373521402','2.876342373521402','test','test','1.87'),('2019-09-14 11:59:59','2019-09-14 15:59:59','XMRUSDT','4h','74.620000000000005','74.739999999999995','219.953901303181624','220.307619718571345','2.947653461581099','2.947653461581099','test','test','0.0'),('2019-09-14 19:59:59','2019-09-15 03:59:59','XMRUSDT','4h','75.430000000000007','74.280000000000001','220.032505395490460','216.677906678735638','2.9170423623954718','2.917042362395472','test','test','1.52'),('2019-09-15 07:59:59','2019-09-15 11:59:59','XMRUSDT','4h','75.129999999999995','74.930000000000007','219.287039013989414','218.703285416188322','2.9187679890055827','2.918767989005583','test','test','0.26'),('2019-09-15 15:59:59','2019-09-16 11:59:59','XMRUSDT','4h','74.810000000000002','73.450000000000003','219.157315992255803','215.173170159486546','2.9295189946832747','2.929518994683275','test','test','1.81'),('2019-09-16 23:59:59','2019-09-17 03:59:59','XMRUSDT','4h','75.370000000000005','74.989999999999995','218.271950251640419','217.171468082400338','2.896005708526475','2.896005708526475','test','test','0.50'),('2019-09-18 07:59:59','2019-09-19 03:59:59','XMRUSDT','4h','75.099999999999994','74.310000000000002','218.027398658475960','215.733901388966046','2.9031611006454856','2.903161100645486','test','test','1.05'),('2019-09-19 19:59:59','2019-09-20 03:59:59','XMRUSDT','4h','76.040000000000006','75.840000000000003','217.517732598584871','216.945618625416586','2.860569865841463','2.860569865841463','test','test','0.35'),('2019-09-20 07:59:59','2019-09-20 15:59:59','XMRUSDT','4h','76.519999999999996','74.989599999999996','217.390596160103058','213.042784236900985','2.840964403555973','2.840964403555973','test','test','2.00'),('2019-10-17 03:59:59','2019-10-18 07:59:59','XMRUSDT','4h','57.039999999999999','58.079999999999998','216.424415732724782','220.370442948047923','3.794256937810743','3.794256937810743','test','test','1.96'),('2019-10-18 11:59:59','2019-10-18 23:59:59','XMRUSDT','4h','57.530000000000001','56.379399999999997','217.301310669463277','212.955284456073997','3.7771825251080005','3.777182525108000','test','test','2.00'),('2019-10-20 15:59:59','2019-10-23 11:59:59','XMRUSDT','4h','56.219999999999999','55.939999999999998','216.335527066487884','215.258082250077052','3.848017201467234','3.848017201467234','test','test','0.56'),('2019-10-25 15:59:59','2019-10-26 19:59:59','XMRUSDT','4h','57.079999999999998','55.938399999999994','216.096094885063252','211.774172987361993','3.785846091188915','3.785846091188915','test','test','2.00'),('2019-10-26 23:59:59','2019-10-27 03:59:59','XMRUSDT','4h','56.770000000000003','55.634599999999999','215.135667796685198','210.832954440751479','3.7896013351538698','3.789601335153870','test','test','2.00'),('2019-10-27 07:59:59','2019-10-30 11:59:59','XMRUSDT','4h','56.700000000000003','57.759999999999998','214.179509273144362','218.183570645799222','3.7774163892970787','3.777416389297079','test','test','0.14'),('2019-10-30 15:59:59','2019-10-31 07:59:59','XMRUSDT','4h','58.729999999999997','58.039999999999999','215.069300689289889','212.542520211244437','3.6620006928195115','3.662000692819511','test','test','1.17'),('2019-10-31 11:59:59','2019-11-08 15:59:59','XMRUSDT','4h','57.880000000000003','60.600000000000001','214.507793916390909','224.588326042385773','3.706077987498115','3.706077987498115','test','test','0.0'),('2019-11-09 03:59:59','2019-11-09 15:59:59','XMRUSDT','4h','61.630000000000003','61.109999999999999','216.747912166611968','214.919112648087889','3.51692215100782','3.516922151007820','test','test','0.84'),('2019-11-09 23:59:59','2019-11-11 07:59:59','XMRUSDT','4h','61.829999999999998','62.100000000000001','216.341512273606639','217.286235034626770','3.4989731889633937','3.498973188963394','test','test','0.0'),('2019-11-11 11:59:59','2019-11-11 15:59:59','XMRUSDT','4h','61.789999999999999','62.579999999999998','216.551450664944440','219.320113005538474','3.504635874169679','3.504635874169679','test','test','0.0'),('2019-11-11 19:59:59','2019-11-11 23:59:59','XMRUSDT','4h','62.130000000000003','61.719999999999999','217.166708962854244','215.733611414572096','3.4953598738589124','3.495359873858912','test','test','0.65'),('2019-11-12 03:59:59','2019-11-12 15:59:59','XMRUSDT','4h','62.140000000000001','63.000000000000000','216.848242841013757','219.849361103699181','3.4896723984714155','3.489672398471416','test','test','0.0'),('2019-11-12 19:59:59','2019-11-12 23:59:59','XMRUSDT','4h','63.210000000000001','62.259999999999998','217.515158010499391','214.246064510895309','3.44115105221483','3.441151052214830','test','test','1.50'),('2019-11-13 01:59:59','2019-11-13 07:59:59','XMRUSDT','4h','61.829999999999998','63.229999999999997','216.788692788365125','221.697380640600443','3.50620560873953','3.506205608739530','test','test','0.0'),('2019-11-13 11:59:59','2019-11-15 15:59:59','XMRUSDT','4h','63.399999999999999','62.649999999999999','217.879512311084113','215.302073285322081','3.436585367682715','3.436585367682715','test','test','1.18'),('2019-11-27 19:59:59','2019-11-28 03:59:59','XMRUSDT','4h','56.829999999999998','55.693399999999997','217.306748083136995','212.960613121474239','3.8238034151528595','3.823803415152859','test','test','2.00'),('2019-11-28 07:59:59','2019-11-28 15:59:59','XMRUSDT','4h','55.500000000000000','55.070000000000000','216.340940313878605','214.664785280816119','3.8980349606104254','3.898034960610425','test','test','0.77'),('2019-11-28 19:59:59','2019-11-28 23:59:59','XMRUSDT','4h','55.329999999999998','54.223399999999998','215.968461417642487','211.649092189289632','3.9032796207779232','3.903279620777923','test','test','2.00'),('2019-11-29 07:59:59','2019-11-29 15:59:59','XMRUSDT','4h','55.590000000000003','55.969999999999999','215.008601589119621','216.478349180482553','3.86775681937614','3.867756819376140','test','test','1.38'),('2019-11-29 19:59:59','2019-11-30 15:59:59','XMRUSDT','4h','55.689999999999998','54.576200000000000','215.335212164978060','211.028507921678511','3.8666764619317306','3.866676461931731','test','test','1.99'),('2019-12-03 03:59:59','2019-12-03 07:59:59','XMRUSDT','4h','54.710000000000001','54.850000000000001','214.378166777578173','214.926749182053783','3.918445746254399','3.918445746254399','test','test','0.0'),('2019-12-03 11:59:59','2019-12-03 15:59:59','XMRUSDT','4h','54.930000000000000','54.409999999999997','214.500073978572772','212.469488898127480','3.904971308548567','3.904971308548567','test','test','0.94'),('2019-12-04 15:59:59','2019-12-04 23:59:59','XMRUSDT','4h','54.700000000000003','53.606000000000002','214.048832849584898','209.767856192593200','3.913141368365354','3.913141368365354','test','test','2.00'),('2019-12-06 07:59:59','2019-12-06 11:59:59','XMRUSDT','4h','54.229999999999997','54.030000000000001','213.097504703586736','212.311602049323113','3.929513271318214','3.929513271318214','test','test','0.36'),('2019-12-06 23:59:59','2019-12-07 03:59:59','XMRUSDT','4h','54.030000000000001','53.880000000000003','212.922859669305922','212.331735683549937','3.9408265717065687','3.940826571706569','test','test','0.27'),('2019-12-07 07:59:59','2019-12-07 11:59:59','XMRUSDT','4h','53.930000000000000','54.729999999999997','212.791498783582369','215.948057267299532','3.9456981046464374','3.945698104646437','test','test','0.0'),('2019-12-07 15:59:59','2019-12-07 19:59:59','XMRUSDT','4h','53.850000000000001','54.479999999999997','213.492956224408431','215.990645405863887','3.964586002310277','3.964586002310277','test','test','0.0'),('2019-12-07 23:59:59','2019-12-08 03:59:59','XMRUSDT','4h','54.380000000000003','53.609999999999999','214.047998264731859','211.017160481284918','3.9361529655154808','3.936152965515481','test','test','1.41'),('2019-12-08 07:59:59','2019-12-08 11:59:59','XMRUSDT','4h','54.149999999999999','54.259999999999998','213.374478757299215','213.807926451912380','3.940433587392414','3.940433587392414','test','test','0.0'),('2019-12-08 15:59:59','2019-12-08 19:59:59','XMRUSDT','4h','54.270000000000003','53.789999999999999','213.470800467213252','211.582722630023966','3.933495494144338','3.933495494144338','test','test','0.88'),('2019-12-09 23:59:59','2019-12-10 03:59:59','XMRUSDT','4h','54.409999999999997','53.590000000000003','213.051227614504540','209.840383897469223','3.9156630695553125','3.915663069555313','test','test','1.50'),('2019-12-10 07:59:59','2019-12-10 11:59:59','XMRUSDT','4h','54.060000000000002','53.729999999999997','212.337706788496661','211.041527668256094','3.9278155158804413','3.927815515880441','test','test','0.61'),('2020-01-03 03:59:59','2020-01-20 15:59:59','XMRUSDT','4h','47.229999999999997','65.030000000000001','212.049666983998776','291.966755112628448','4.489724052170205','4.489724052170205','test','test','0.0'),('2020-01-20 19:59:59','2020-01-23 03:59:59','XMRUSDT','4h','65.349999999999994','64.042999999999992','229.809019901471999','225.212839503442552','3.516587909739434','3.516587909739434','test','test','2.00'),('2020-01-26 11:59:59','2020-02-16 15:59:59','XMRUSDT','4h','63.490000000000002','85.250000000000000','228.787646479687709','307.200297092351207','3.6035225465378438','3.603522546537844','test','test','0.26');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 19:55:54
