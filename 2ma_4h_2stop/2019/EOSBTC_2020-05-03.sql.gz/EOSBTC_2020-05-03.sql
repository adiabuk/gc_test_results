-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-07 03:59:59','EOSBTC','4h','0.000695300000000','0.000694000000000','0.033333333333333','0.033271010115537','47.940936765904404','47.940936765904404','test','test','0.92'),('2019-01-07 07:59:59','2019-01-07 11:59:59','EOSBTC','4h','0.000701400000000','0.000688400000000','0.033319483729379','0.032701928427865','47.50425396261572','47.504253962615721','test','test','1.85'),('2019-01-08 23:59:59','2019-01-09 03:59:59','EOSBTC','4h','0.000693400000000','0.000695200000000','0.033182249217931','0.033268387159368','47.85441190933243','47.854411909332427','test','test','0.0'),('2019-01-09 07:59:59','2019-01-09 11:59:59','EOSBTC','4h','0.000693500000000','0.000696400000000','0.033201390982695','0.033340228810885','47.87511316899047','47.875113168990467','test','test','0.0'),('2019-01-09 15:59:59','2019-01-10 11:59:59','EOSBTC','4h','0.000703400000000','0.000689332000000','0.033232243833404','0.032567598956736','47.24515756810318','47.245157568103181','test','test','2.00'),('2019-01-17 11:59:59','2019-01-17 15:59:59','EOSBTC','4h','0.000672400000000','0.000673000000000','0.033084544971922','0.033114067171481','49.203665930877456','49.203665930877456','test','test','0.0'),('2019-01-17 19:59:59','2019-01-18 11:59:59','EOSBTC','4h','0.000682700000000','0.000676900000000','0.033091105460713','0.032809974053547','48.4709322699764','48.470932269976402','test','test','0.84'),('2019-01-18 15:59:59','2019-01-18 19:59:59','EOSBTC','4h','0.000672400000000','0.000670300000000','0.033028631814676','0.032925478740894','49.12051132462226','49.120511324622257','test','test','0.31'),('2019-01-18 23:59:59','2019-01-19 03:59:59','EOSBTC','4h','0.000675700000000','0.000672700000000','0.033005708909391','0.032859168837276','48.84669070503345','48.846690705033453','test','test','0.44'),('2019-01-19 07:59:59','2019-01-19 11:59:59','EOSBTC','4h','0.000672400000000','0.000671100000000','0.032973144448921','0.032909395061973','49.03798995972801','49.037989959728009','test','test','0.19'),('2019-01-22 19:59:59','2019-01-26 23:59:59','EOSBTC','4h','0.000687900000000','0.000674500000000','0.032958977918488','0.032316951019073','47.91245518024163','47.912455180241629','test','test','1.94'),('2019-01-27 03:59:59','2019-01-27 11:59:59','EOSBTC','4h','0.000677300000000','0.000669500000000','0.032816305274174','0.032438382372744','48.451654029490285','48.451654029490285','test','test','1.15'),('2019-01-30 19:59:59','2019-01-31 11:59:59','EOSBTC','4h','0.000671900000000','0.000667900000000','0.032732322407189','0.032537458157109','48.716062520001984','48.716062520001984','test','test','0.59'),('2019-01-31 15:59:59','2019-02-01 03:59:59','EOSBTC','4h','0.000671400000000','0.000672200000000','0.032689019240505','0.032727969516633','48.68784516012048','48.687845160120482','test','test','0.10'),('2019-02-01 07:59:59','2019-02-01 11:59:59','EOSBTC','4h','0.000667200000000','0.000672300000000','0.032697674857422','0.032947612120271','49.00730644098055','49.007306440980550','test','test','0.0'),('2019-02-01 15:59:59','2019-02-02 23:59:59','EOSBTC','4h','0.000672400000000','0.000695900000000','0.032753216471389','0.033897922876918','48.710910873570285','48.710910873570285','test','test','0.29'),('2019-02-03 03:59:59','2019-02-06 03:59:59','EOSBTC','4h','0.000695900000000','0.000681982000000','0.033007595672617','0.032347443759165','47.43152129992432','47.431521299924320','test','test','2.00'),('2019-02-06 07:59:59','2019-02-06 11:59:59','EOSBTC','4h','0.000678500000000','0.000681200000000','0.032860895247406','0.032991660784868','48.431680541497094','48.431680541497094','test','test','0.0'),('2019-02-06 15:59:59','2019-02-25 11:59:59','EOSBTC','4h','0.000685800000000','0.000896200000000','0.032889954255731','0.042980427244074','47.95852180771459','47.958521807714590','test','test','0.0'),('2019-02-25 15:59:59','2019-02-25 23:59:59','EOSBTC','4h','0.000935800000000','0.000925700000000','0.035132281586474','0.034753102227612','37.54251077845005','37.542510778450051','test','test','1.07'),('2019-02-26 03:59:59','2019-02-26 07:59:59','EOSBTC','4h','0.000915800000000','0.000912700000000','0.035048019506726','0.034929381310099','38.270386008655215','38.270386008655215','test','test','0.33'),('2019-02-26 11:59:59','2019-02-26 15:59:59','EOSBTC','4h','0.000908700000000','0.000896100000000','0.035021655463032','0.034536046506463','38.54039337848746','38.540393378487458','test','test','1.38'),('2019-02-27 07:59:59','2019-02-27 11:59:59','EOSBTC','4h','0.000915600000000','0.000914500000000','0.034913742361572','0.034871797061662','38.13209082740474','38.132090827404738','test','test','0.12'),('2019-02-27 15:59:59','2019-02-27 19:59:59','EOSBTC','4h','0.000900000000000','0.000901400000000','0.034904421183814','0.034958716950100','38.782690204237774','38.782690204237774','test','test','0.0'),('2019-02-27 23:59:59','2019-03-01 23:59:59','EOSBTC','4h','0.000917600000000','0.000907400000000','0.034916486909655','0.034528356824129','38.051969169197186','38.051969169197186','test','test','1.11'),('2019-03-02 03:59:59','2019-03-02 07:59:59','EOSBTC','4h','0.000913400000000','0.000910200000000','0.034830235779538','0.034708211743525','38.13251125414763','38.132511254147630','test','test','0.35'),('2019-03-02 11:59:59','2019-03-02 15:59:59','EOSBTC','4h','0.000914100000000','0.000910800000000','0.034803119327091','0.034677476297029','38.07364547324265','38.073645473242649','test','test','0.36'),('2019-03-02 19:59:59','2019-03-02 23:59:59','EOSBTC','4h','0.000909500000000','0.000910100000000','0.034775198653744','0.034798139961267','38.23551253847608','38.235512538476080','test','test','0.0'),('2019-03-03 03:59:59','2019-03-03 07:59:59','EOSBTC','4h','0.000909800000000','0.000914100000000','0.034780296722082','0.034944679307161','38.22850815792751','38.228508157927507','test','test','0.0'),('2019-03-03 11:59:59','2019-03-04 03:59:59','EOSBTC','4h','0.000926000000000','0.000909000000000','0.034816826185433','0.034177640391532','37.59916434712024','37.599164347120237','test','test','1.83'),('2019-03-05 15:59:59','2019-03-08 23:59:59','EOSBTC','4h','0.000946300000000','0.000928400000000','0.034674784897900','0.034018884391007','36.642486418577384','36.642486418577384','test','test','1.89'),('2019-03-09 03:59:59','2019-03-11 07:59:59','EOSBTC','4h','0.000938900000000','0.000926900000000','0.034529029229701','0.034087716682298','36.77604561689353','36.776045616893533','test','test','1.27'),('2019-03-12 11:59:59','2019-03-12 15:59:59','EOSBTC','4h','0.000942400000000','0.000935900000000','0.034430959774723','0.034193479682898','36.535398742278105','36.535398742278105','test','test','0.68'),('2019-03-12 19:59:59','2019-03-12 23:59:59','EOSBTC','4h','0.000937900000000','0.000937800000000','0.034378186420984','0.034374520978355','36.6544262938309','36.654426293830902','test','test','0.01'),('2019-03-13 03:59:59','2019-03-13 07:59:59','EOSBTC','4h','0.000936100000000','0.000935800000000','0.034377371878178','0.034366354666808','36.724037899986705','36.724037899986705','test','test','0.03'),('2019-03-15 11:59:59','2019-03-18 03:59:59','EOSBTC','4h','0.000941600000000','0.000935700000000','0.034374923608984','0.034159532732505','36.50692821684815','36.506928216848152','test','test','0.62'),('2019-03-25 23:59:59','2019-03-26 03:59:59','EOSBTC','4h','0.000927300000000','0.000921400000000','0.034327058969767','0.034108651067339','37.01828854714403','37.018288547144031','test','test','0.63'),('2019-03-26 07:59:59','2019-04-02 07:59:59','EOSBTC','4h','0.000924800000000','0.000975800000000','0.034278523880338','0.036168883653151','37.06587789828959','37.065877898289592','test','test','0.01'),('2019-04-02 19:59:59','2019-04-03 23:59:59','EOSBTC','4h','0.001019500000000','0.001056400000000','0.034698603829852','0.035954492482448','34.03492283457795','34.034922834577948','test','test','0.0'),('2019-04-04 03:59:59','2019-04-04 15:59:59','EOSBTC','4h','0.001037800000000','0.001033200000000','0.034977690197096','0.034822653219926','33.7036906890497','33.703690689049701','test','test','0.44'),('2019-04-04 19:59:59','2019-04-08 11:59:59','EOSBTC','4h','0.001020000000000','0.001032600000000','0.034943237535502','0.035374889293294','34.25807601519847','34.258076015198469','test','test','0.0'),('2019-04-08 15:59:59','2019-04-09 03:59:59','EOSBTC','4h','0.001046600000000','0.001040600000000','0.035039160148345','0.034838285926207','33.47903702307004','33.479037023070042','test','test','0.57'),('2019-04-09 07:59:59','2019-04-10 23:59:59','EOSBTC','4h','0.001041500000000','0.001100600000000','0.034994521432314','0.036980288323000','33.60011659367685','33.600116593676852','test','test','0.0'),('2019-04-11 03:59:59','2019-04-11 11:59:59','EOSBTC','4h','0.001075000000000','0.001053500000000','0.035435802963578','0.034727086904306','32.96353764053767','32.963537640537673','test','test','2.00'),('2019-04-12 03:59:59','2019-04-12 07:59:59','EOSBTC','4h','0.001059600000000','0.001055400000000','0.035278310505962','0.035138475753107','33.29398877497357','33.293988774973570','test','test','0.39'),('2019-04-12 11:59:59','2019-04-12 19:59:59','EOSBTC','4h','0.001064900000000','0.001051900000000','0.035247236116439','0.034816947761182','33.09910425057627','33.099104250576268','test','test','1.37'),('2019-04-12 23:59:59','2019-04-13 11:59:59','EOSBTC','4h','0.001056600000000','0.001043500000000','0.035151616481937','0.034715797651809','33.26861298687972','33.268612986879717','test','test','1.23'),('2019-04-14 23:59:59','2019-04-15 11:59:59','EOSBTC','4h','0.001080600000000','0.001058988000000','0.035054767853020','0.034353672495960','32.44009610681082','32.440096106810820','test','test','2.00'),('2019-04-15 15:59:59','2019-04-15 19:59:59','EOSBTC','4h','0.001068400000000','0.001052600000000','0.034898968884784','0.034382866574432','32.66470318680665','32.664703186806648','test','test','1.47'),('2019-04-15 23:59:59','2019-04-16 15:59:59','EOSBTC','4h','0.001059900000000','0.001057700000000','0.034784279482484','0.034712078883502','32.81845408291706','32.818454082917057','test','test','0.20'),('2019-04-16 19:59:59','2019-04-17 03:59:59','EOSBTC','4h','0.001057400000000','0.001050500000000','0.034768234904932','0.034541356882571','32.880872805875','32.880872805875001','test','test','0.65'),('2019-05-16 03:59:59','2019-05-19 03:59:59','EOSBTC','4h','0.000818900000000','0.000802522000000','0.034717817566630','0.034023461215297','42.3956741563436','42.395674156343603','test','test','2.00'),('2019-05-24 11:59:59','2019-05-25 15:59:59','EOSBTC','4h','0.000798600000000','0.000792100000000','0.034563516155222','0.034282195274920','43.280135431032356','43.280135431032356','test','test','0.81'),('2019-05-26 03:59:59','2019-05-26 07:59:59','EOSBTC','4h','0.000793200000000','0.000794100000000','0.034501000404044','0.034540146773640','43.495966217907494','43.495966217907494','test','test','0.0'),('2019-05-27 03:59:59','2019-05-27 07:59:59','EOSBTC','4h','0.000798400000000','0.000794200000000','0.034509699597288','0.034328160596400','43.22357163988951','43.223571639889506','test','test','0.52'),('2019-05-27 11:59:59','2019-05-30 23:59:59','EOSBTC','4h','0.000800300000000','0.000882500000000','0.034469357597090','0.038009756440625','43.07054554178489','43.070545541784888','test','test','0.0'),('2019-05-31 03:59:59','2019-06-01 23:59:59','EOSBTC','4h','0.000889500000000','0.000902400000000','0.035256112895654','0.035767415713365','39.63587734193792','39.635877341937920','test','test','0.0'),('2019-06-02 03:59:59','2019-06-02 19:59:59','EOSBTC','4h','0.000890100000000','0.000872298000000','0.035369735744034','0.034662341029153','39.736811306632966','39.736811306632966','test','test','2.00'),('2019-06-02 23:59:59','2019-06-03 03:59:59','EOSBTC','4h','0.000884800000000','0.000874600000000','0.035212536918505','0.034806605774101','39.79717102001004','39.797171020010040','test','test','1.15'),('2019-07-23 19:59:59','2019-07-28 23:59:59','EOSBTC','4h','0.000419500000000','0.000448200000000','0.035122329997526','0.037525216459812','83.7242669786084','83.724266978608398','test','test','0.0'),('2019-07-29 03:59:59','2019-07-29 11:59:59','EOSBTC','4h','0.000445300000000','0.000438900000000','0.035656304766923','0.035143840472047','80.07254607438382','80.072546074383823','test','test','1.43'),('2019-07-29 15:59:59','2019-07-29 19:59:59','EOSBTC','4h','0.000439600000000','0.000436900000000','0.035542423812506','0.035324124121210','80.85173751707512','80.851737517075122','test','test','0.61'),('2019-07-29 23:59:59','2019-07-30 03:59:59','EOSBTC','4h','0.000443000000000','0.000441800000000','0.035493912769996','0.035397766730890','80.12169925507','80.121699255069998','test','test','0.27'),('2019-07-30 07:59:59','2019-07-30 11:59:59','EOSBTC','4h','0.000439200000000','0.000441500000000','0.035472546983528','0.035658309410810','80.76627273116578','80.766272731165785','test','test','0.0'),('2019-07-30 15:59:59','2019-07-30 19:59:59','EOSBTC','4h','0.000439000000000','0.000436600000000','0.035513827522924','0.035319674479518','80.89710141896128','80.897101418961284','test','test','0.54'),('2019-08-13 23:59:59','2019-08-14 03:59:59','EOSBTC','4h','0.000374500000000','0.000386600000000','0.035470682402167','0.036616731152678','94.71477276947161','94.714772769471608','test','test','0.0'),('2019-08-14 07:59:59','2019-08-14 19:59:59','EOSBTC','4h','0.000385600000000','0.000377888000000','0.035725359902281','0.035010852704235','92.6487549333005','92.648754933300495','test','test','1.99'),('2019-08-22 15:59:59','2019-08-23 15:59:59','EOSBTC','4h','0.000359600000000','0.000356600000000','0.035566580524937','0.035269862667387','98.90595251651033','98.905952516510325','test','test','0.83'),('2019-08-24 11:59:59','2019-08-24 19:59:59','EOSBTC','4h','0.000360700000000','0.000361200000000','0.035500643223259','0.035549853984589','98.42152265943814','98.421522659438139','test','test','0.19'),('2019-08-24 23:59:59','2019-08-25 15:59:59','EOSBTC','4h','0.000361200000000','0.000356100000000','0.035511578947999','0.035010169610693','98.31555633443892','98.315556334438924','test','test','1.41'),('2019-09-07 19:59:59','2019-09-22 19:59:59','EOSBTC','4h','0.000338900000000','0.000376700000000','0.035400154650820','0.039348593263393','104.45604795166783','104.456047951667827','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 23:59:59','EOSBTC','4h','0.000387300000000','0.000380700000000','0.036277585453614','0.035659377180973','93.6679200971191','93.667920097119094','test','test','1.70'),('2019-09-30 11:59:59','2019-09-30 15:59:59','EOSBTC','4h','0.000362600000000','0.000355348000000','0.036140205837472','0.035417401720723','99.66962448282345','99.669624482823451','test','test','2.00'),('2019-10-01 03:59:59','2019-10-01 15:59:59','EOSBTC','4h','0.000360800000000','0.000353584000000','0.035979582700416','0.035259991046408','99.7216815421742','99.721681542174196','test','test','1.99'),('2019-10-02 11:59:59','2019-10-02 15:59:59','EOSBTC','4h','0.000359100000000','0.000359300000000','0.035819673443970','0.035839623136782','99.74846406006746','99.748464060067462','test','test','0.0'),('2019-10-02 19:59:59','2019-10-03 03:59:59','EOSBTC','4h','0.000363700000000','0.000358000000000','0.035824106709040','0.035262662089184','98.49905611503866','98.499056115038655','test','test','1.56'),('2019-10-03 07:59:59','2019-10-03 11:59:59','EOSBTC','4h','0.000358500000000','0.000359200000000','0.035699341237960','0.035769047064645','99.57975240714211','99.579752407142109','test','test','0.0'),('2019-10-03 15:59:59','2019-10-03 19:59:59','EOSBTC','4h','0.000357600000000','0.000351700000000','0.035714831421668','0.035125576652686','99.8736896579089','99.873689657908898','test','test','1.64'),('2019-10-04 07:59:59','2019-10-06 19:59:59','EOSBTC','4h','0.000361600000000','0.000369100000000','0.035583885917450','0.036321936648592','98.40676415224006','98.406764152240058','test','test','0.0'),('2019-10-06 23:59:59','2019-10-10 07:59:59','EOSBTC','4h','0.000369900000000','0.000369600000000','0.035747897191037','0.035718904573688','96.64205782924336','96.642057829243356','test','test','0.08'),('2019-10-11 19:59:59','2019-10-11 23:59:59','EOSBTC','4h','0.000371300000000','0.000370200000000','0.035741454387182','0.035635568042378','96.26031345860969','96.260313458609687','test','test','0.29'),('2019-10-12 03:59:59','2019-10-12 11:59:59','EOSBTC','4h','0.000371700000000','0.000369800000000','0.035717924088336','0.035535346590978','96.09341966192211','96.093419661922113','test','test','0.51'),('2019-10-13 03:59:59','2019-10-13 07:59:59','EOSBTC','4h','0.000372200000000','0.000371800000000','0.035677351311146','0.035639009181849','95.85532324327184','95.855323243271840','test','test','0.10'),('2019-10-13 11:59:59','2019-10-13 15:59:59','EOSBTC','4h','0.000372200000000','0.000370100000000','0.035668830837969','0.035467582732757','95.83243105311304','95.832431053113041','test','test','0.56'),('2019-10-13 23:59:59','2019-10-15 11:59:59','EOSBTC','4h','0.000374700000000','0.000374700000000','0.035624109036810','0.035624109036810','95.07368304459686','95.073683044596862','test','test','0.0'),('2019-10-15 15:59:59','2019-10-15 19:59:59','EOSBTC','4h','0.000373300000000','0.000365834000000','0.035624109036810','0.034911626856074','95.43024119156293','95.430241191562928','test','test','2.00'),('2019-10-24 03:59:59','2019-10-24 07:59:59','EOSBTC','4h','0.000363300000000','0.000363300000000','0.035465779663314','0.035465779663314','97.62119367826469','97.621193678264689','test','test','0.0'),('2019-10-24 15:59:59','2019-10-26 03:59:59','EOSBTC','4h','0.000369700000000','0.000362306000000','0.035465779663314','0.034756464070048','95.93124063649867','95.931240636498671','test','test','2.00'),('2019-10-28 11:59:59','2019-10-28 15:59:59','EOSBTC','4h','0.000361100000000','0.000357300000000','0.035308153975921','0.034936592122948','97.77943499285826','97.779434992858256','test','test','1.05'),('2019-10-29 03:59:59','2019-10-29 15:59:59','EOSBTC','4h','0.000360000000000','0.000359700000000','0.035225584675260','0.035196230021364','97.84884632016792','97.848846320167922','test','test','0.08'),('2019-10-29 19:59:59','2019-10-29 23:59:59','EOSBTC','4h','0.000363800000000','0.000361600000000','0.035219061418839','0.035006081938021','96.80885491709488','96.808854917094877','test','test','0.60'),('2019-10-30 03:59:59','2019-10-30 11:59:59','EOSBTC','4h','0.000363800000000','0.000359500000000','0.035171732645324','0.034756013980192','96.6787593329412','96.678759332941198','test','test','1.18'),('2019-11-01 19:59:59','2019-11-02 15:59:59','EOSBTC','4h','0.000361100000000','0.000358800000000','0.035079350719739','0.034855915364836','97.14580647947693','97.145806479476931','test','test','0.63'),('2019-11-04 11:59:59','2019-11-15 15:59:59','EOSBTC','4h','0.000363900000000','0.000391800000000','0.035029698418650','0.037715404892627','96.2618807877152','96.261880787715199','test','test','0.0'),('2019-11-15 19:59:59','2019-11-18 19:59:59','EOSBTC','4h','0.000392600000000','0.000385700000000','0.035626522079533','0.035000380963005','90.74508935184244','90.745089351842438','test','test','1.75'),('2019-12-01 03:59:59','2019-12-02 15:59:59','EOSBTC','4h','0.000368700000000','0.000368400000000','0.035487379609194','0.035458504605444','96.25001250120364','96.250012501203642','test','test','0.13'),('2019-12-03 07:59:59','2019-12-03 11:59:59','EOSBTC','4h','0.000368500000000','0.000367100000000','0.035480962941694','0.035346164167967','96.2848383763739','96.284838376373898','test','test','0.37'),('2019-12-03 15:59:59','2019-12-03 19:59:59','EOSBTC','4h','0.000369200000000','0.000370400000000','0.035451007658643','0.035566233035648','96.0211475044511','96.021147504451093','test','test','0.0'),('2019-12-03 23:59:59','2019-12-04 03:59:59','EOSBTC','4h','0.000369500000000','0.000363300000000','0.035476613297978','0.034881335889460','96.01248524486546','96.012485244865459','test','test','1.67'),('2019-12-13 15:59:59','2019-12-13 19:59:59','EOSBTC','4h','0.000363500000000','0.000360900000000','0.035344329429418','0.035091522671463','97.23336844406666','97.233368444066656','test','test','0.71'),('2019-12-14 15:59:59','2019-12-14 19:59:59','EOSBTC','4h','0.000362700000000','0.000363200000000','0.035288150149873','0.035336796620992','97.29294223841377','97.292942238413772','test','test','0.0'),('2019-12-14 23:59:59','2019-12-15 03:59:59','EOSBTC','4h','0.000363000000000','0.000362100000000','0.035298960476788','0.035211442392961','97.24231536305237','97.242315363052370','test','test','0.24'),('2019-12-24 19:59:59','2019-12-25 15:59:59','EOSBTC','4h','0.000350900000000','0.000344300000000','0.035279512013715','0.034615947524429','100.54007413426999','100.540074134269986','test','test','1.88'),('2019-12-26 15:59:59','2020-01-01 15:59:59','EOSBTC','4h','0.000348400000000','0.000363100000000','0.035132053238318','0.036614375806066','100.83826991480612','100.838269914806119','test','test',NULL);
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:22:43
