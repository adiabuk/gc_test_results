-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-08 03:59:59','XLMBTC','4h','0.000030480000000','0.000030050000000','0.033333333333333','0.032863079615048','1093.6132983377079','1093.613298337707874','test','test','1.41'),('2019-01-08 07:59:59','2019-01-08 11:59:59','XLMBTC','4h','0.000030310000000','0.000030530000000','0.033228832507048','0.033470018358303','1096.2993238880824','1096.299323888082426','test','test','0.0'),('2019-01-08 15:59:59','2019-01-09 19:59:59','XLMBTC','4h','0.000030690000000','0.000030460000000','0.033282429362882','0.033033000925167','1084.471468324608','1084.471468324607940','test','test','0.97'),('2019-01-09 23:59:59','2019-01-10 07:59:59','XLMBTC','4h','0.000030870000000','0.000030400000000','0.033227000821168','0.032721115159168','1076.3524723410358','1076.352472341035764','test','test','1.52'),('2019-01-13 03:59:59','2019-01-13 15:59:59','XLMBTC','4h','0.000030740000000','0.000030125200000','0.033114581785168','0.032452290149465','1077.2472929462517','1077.247292946251719','test','test','1.99'),('2019-01-17 15:59:59','2019-01-17 19:59:59','XLMBTC','4h','0.000029880000000','0.000029570000000','0.032967405866123','0.032625374546896','1103.326836215618','1103.326836215617959','test','test','1.03'),('2019-02-19 11:59:59','2019-02-20 03:59:59','XLMBTC','4h','0.000022370000000','0.000022480000000','0.032891398906294','0.033053135780666','1470.3352215598768','1470.335221559876800','test','test','0.0'),('2019-02-20 07:59:59','2019-02-24 15:59:59','XLMBTC','4h','0.000022410000000','0.000021961800000','0.032927340433933','0.032268793625254','1469.3146110634832','1469.314611063483198','test','test','2.00'),('2019-02-25 19:59:59','2019-02-25 23:59:59','XLMBTC','4h','0.000022620000000','0.000022470000000','0.032780996698671','0.032563616083958','1449.204098084468','1449.204098084467887','test','test','0.66'),('2019-02-26 03:59:59','2019-02-26 07:59:59','XLMBTC','4h','0.000022290000000','0.000022160000000','0.032732689895401','0.032541785916648','1468.492144253078','1468.492144253078095','test','test','0.58'),('2019-03-01 19:59:59','2019-03-01 23:59:59','XLMBTC','4h','0.000022290000000','0.000022170000000','0.032690266789012','0.032514276119892','1466.5889093320573','1466.588909332057256','test','test','0.53'),('2019-03-03 15:59:59','2019-03-04 03:59:59','XLMBTC','4h','0.000022850000000','0.000022393000000','0.032651157751429','0.031998134596400','1428.9346937168195','1428.934693716819538','test','test','1.99'),('2019-03-04 07:59:59','2019-03-04 11:59:59','XLMBTC','4h','0.000022260000000','0.000021980000000','0.032506041494756','0.032097160469665','1460.2893753259757','1460.289375325975698','test','test','1.25'),('2019-03-05 23:59:59','2019-03-06 03:59:59','XLMBTC','4h','0.000022210000000','0.000021920000000','0.032415179044736','0.031991928170221','1459.4857741889236','1459.485774188923642','test','test','1.30'),('2019-03-08 07:59:59','2019-03-21 15:59:59','XLMBTC','4h','0.000022390000000','0.000026230000000','0.032321123294844','0.037864361948359','1443.551732686189','1443.551732686189098','test','test','0.31'),('2019-03-22 15:59:59','2019-03-23 11:59:59','XLMBTC','4h','0.000027200000000','0.000026656000000','0.033552954106736','0.032881895024601','1233.5644892182352','1233.564489218235167','test','test','2.00'),('2019-03-23 15:59:59','2019-03-23 19:59:59','XLMBTC','4h','0.000026680000000','0.000026850000000','0.033403829866262','0.033616672860162','1252.0176111792189','1252.017611179218875','test','test','0.0'),('2019-03-23 23:59:59','2019-03-24 03:59:59','XLMBTC','4h','0.000026640000000','0.000026490000000','0.033451128309350','0.033262777361662','1255.672984585227','1255.672984585226914','test','test','0.56'),('2019-03-27 11:59:59','2019-03-27 15:59:59','XLMBTC','4h','0.000026370000000','0.000026410000000','0.033409272543198','0.033459950241405','1266.9424551838283','1266.942455183828315','test','test','0.0'),('2019-03-27 19:59:59','2019-03-28 07:59:59','XLMBTC','4h','0.000026520000000','0.000026340000000','0.033420534253910','0.033193698048567','1260.2011407960113','1260.201140796011259','test','test','0.67'),('2019-03-28 23:59:59','2019-03-29 03:59:59','XLMBTC','4h','0.000026440000000','0.000026380000000','0.033370126208278','0.033294399749409','1262.107647816885','1262.107647816884992','test','test','0.22'),('2019-03-31 23:59:59','2019-04-01 03:59:59','XLMBTC','4h','0.000026380000000','0.000026650000000','0.033353298106308','0.033694669997464','1264.3403376159042','1264.340337615904218','test','test','0.0'),('2019-04-01 07:59:59','2019-04-02 07:59:59','XLMBTC','4h','0.000026510000000','0.000025979800000','0.033429158526564','0.032760575356033','1261.0018305003566','1261.001830500356618','test','test','2.00'),('2019-04-07 23:59:59','2019-04-08 03:59:59','XLMBTC','4h','0.000025560000000','0.000025130000000','0.033280584488669','0.032720699851340','1302.0572961137977','1302.057296113797747','test','test','1.68'),('2019-05-15 19:59:59','2019-05-15 23:59:59','XLMBTC','4h','0.000015500000000','0.000017320000000','0.033156165680373','0.037049341263488','2139.1074632498926','2139.107463249892589','test','test','0.0'),('2019-05-16 03:59:59','2019-05-16 11:59:59','XLMBTC','4h','0.000018420000000','0.000018051600000','0.034021315809954','0.033340889493755','1846.9769712244542','1846.976971224454246','test','test','2.00'),('2019-05-16 15:59:59','2019-05-16 19:59:59','XLMBTC','4h','0.000018910000000','0.000018531800000','0.033870109961910','0.033192707762672','1791.1216267535813','1791.121626753581268','test','test','1.99'),('2019-05-16 23:59:59','2019-05-17 07:59:59','XLMBTC','4h','0.000017540000000','0.000017189200000','0.033719576139857','0.033045184617060','1922.4387765026986','1922.438776502698602','test','test','2.00'),('2019-05-17 11:59:59','2019-05-22 11:59:59','XLMBTC','4h','0.000016920000000','0.000016581600000','0.033569711357014','0.032898317129874','1984.0254939133304','1984.025493913330365','test','test','2.0'),('2019-05-30 07:59:59','2019-05-30 11:59:59','XLMBTC','4h','0.000016190000000','0.000016280000000','0.033420512639871','0.033606296836140','2064.268847428742','2064.268847428741992','test','test','0.0'),('2019-05-30 15:59:59','2019-05-30 19:59:59','XLMBTC','4h','0.000015960000000','0.000015640800000','0.033461798016820','0.032792562056484','2096.603885765664','2096.603885765664018','test','test','2.00'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XLMBTC','4h','0.000015980000000','0.000015770000000','0.033313078914523','0.032875297527036','2084.6732737498814','2084.673273749881446','test','test','1.31'),('2019-06-05 03:59:59','2019-06-05 07:59:59','XLMBTC','4h','0.000015830000000','0.000015860000000','0.033215794161748','0.033278742602989','2098.281374715618','2098.281374715617858','test','test','0.0'),('2019-06-05 11:59:59','2019-06-05 15:59:59','XLMBTC','4h','0.000015830000000','0.000015680000000','0.033229782704246','0.032914907947099','2099.1650476466343','2099.165047646634321','test','test','0.94'),('2019-06-06 19:59:59','2019-06-06 23:59:59','XLMBTC','4h','0.000015860000000','0.000016030000000','0.033159810535991','0.033515243561913','2090.7825054218997','2090.782505421899714','test','test','0.0'),('2019-06-07 03:59:59','2019-06-08 15:59:59','XLMBTC','4h','0.000016120000000','0.000015840000000','0.033238795652863','0.032661446844997','2061.960028093231','2061.960028093230903','test','test','1.73'),('2019-07-18 11:59:59','2019-07-18 15:59:59','XLMBTC','4h','0.000009100000000','0.000008918000000','0.033110495917782','0.032448285999426','3638.5160349210505','3638.516034921050505','test','test','2.00'),('2019-07-19 07:59:59','2019-07-19 11:59:59','XLMBTC','4h','0.000008550000000','0.000008520000000','0.032963338158147','0.032847677322504','3855.3611880873555','3855.361188087355458','test','test','0.35'),('2019-07-19 15:59:59','2019-07-21 15:59:59','XLMBTC','4h','0.000008530000000','0.000008610000000','0.032937635750226','0.033246546753745','3861.387543989006','3861.387543989006190','test','test','0.0'),('2019-07-21 19:59:59','2019-07-21 23:59:59','XLMBTC','4h','0.000008600000000','0.000008620000000','0.033006282639897','0.033083041436734','3837.939841848501','3837.939841848501146','test','test','0.0'),('2019-07-22 03:59:59','2019-07-22 11:59:59','XLMBTC','4h','0.000008580000000','0.000008540000000','0.033023340150305','0.032869385184569','3848.87414339223','3848.874143392230053','test','test','0.46'),('2019-07-24 15:59:59','2019-07-25 07:59:59','XLMBTC','4h','0.000008720000000','0.000008560000000','0.032989127935697','0.032383822835959','3783.156873359785','3783.156873359785095','test','test','1.83'),('2019-07-25 11:59:59','2019-07-25 15:59:59','XLMBTC','4h','0.000008570000000','0.000008560000000','0.032854615691311','0.032816278916875','3833.6774435602233','3833.677443560223310','test','test','0.11'),('2019-07-25 19:59:59','2019-07-30 07:59:59','XLMBTC','4h','0.000008700000000','0.000008740000000','0.032846096408103','0.032997112943313','3775.4133802417373','3775.413380241737286','test','test','0.45'),('2019-07-30 11:59:59','2019-07-30 15:59:59','XLMBTC','4h','0.000008780000000','0.000008670000000','0.032879655638150','0.032467723733800','3744.8354940945073','3744.835494094507339','test','test','1.25'),('2019-07-30 19:59:59','2019-07-30 23:59:59','XLMBTC','4h','0.000008710000000','0.000008710000000','0.032788115214961','0.032788115214961','3764.4219534972312','3764.421953497231243','test','test','0.0'),('2019-08-14 11:59:59','2019-08-14 15:59:59','XLMBTC','4h','0.000007000000000','0.000007010000000','0.032788115214961','0.032834955379554','4684.016459280126','4684.016459280125673','test','test','0.0'),('2019-08-18 23:59:59','2019-08-19 03:59:59','XLMBTC','4h','0.000006860000000','0.000006820000000','0.032798524140426','0.032607279101706','4781.125967992127','4781.125967992126789','test','test','0.58'),('2019-08-22 19:59:59','2019-08-23 03:59:59','XLMBTC','4h','0.000006780000000','0.000006700000000','0.032756025242933','0.032369523470155','4831.272159724581','4831.272159724580888','test','test','1.17'),('2019-08-24 11:59:59','2019-08-26 03:59:59','XLMBTC','4h','0.000006790000000','0.000006790000000','0.032670135960093','0.032670135960093','4811.5075051683525','4811.507505168352509','test','test','0.0'),('2019-08-26 07:59:59','2019-08-26 11:59:59','XLMBTC','4h','0.000006770000000','0.000006760000000','0.032670135960093','0.032621878743018','4825.721707546988','4825.721707546988000','test','test','0.14'),('2019-09-17 15:59:59','2019-09-23 03:59:59','XLMBTC','4h','0.000006060000000','0.000006570000000','0.032659412134076','0.035407976521597','5389.341936316244','5389.341936316243846','test','test','0.0'),('2019-09-23 07:59:59','2019-09-23 11:59:59','XLMBTC','4h','0.000006690000000','0.000006830000000','0.033270204220192','0.033966441677715','4973.124696590766','4973.124696590765780','test','test','0.0'),('2019-09-23 15:59:59','2019-09-23 19:59:59','XLMBTC','4h','0.000006850000000','0.000006713000000','0.033424923655197','0.032756425182093','4879.550898568953','4879.550898568953016','test','test','1.99'),('2019-09-25 23:59:59','2019-10-01 19:59:59','XLMBTC','4h','0.000006800000000','0.000007070000000','0.033276368438952','0.034597636009322','4893.583593963529','4893.583593963528983','test','test','0.0'),('2019-10-01 23:59:59','2019-10-02 03:59:59','XLMBTC','4h','0.000007060000000','0.000007030000000','0.033569983454590','0.033427334799684','4754.955163539627','4754.955163539627392','test','test','0.42'),('2019-10-02 07:59:59','2019-10-09 15:59:59','XLMBTC','4h','0.000007050000000','0.000007360000000','0.033538283753500','0.035013016797980','4757.203369290717','4757.203369290717092','test','test','0.0'),('2019-10-09 19:59:59','2019-10-10 03:59:59','XLMBTC','4h','0.000007340000000','0.000007300000000','0.033866002207828','0.033681446337486','4613.896758559733','4613.896758559732916','test','test','0.54'),('2019-10-12 03:59:59','2019-10-12 07:59:59','XLMBTC','4h','0.000007320000000','0.000007350000000','0.033824989792197','0.033963616799542','4620.90024483564','4620.900244835639569','test','test','0.0'),('2019-10-12 11:59:59','2019-10-12 15:59:59','XLMBTC','4h','0.000007340000000','0.000007270000000','0.033855795793829','0.033532920357103','4612.506238941296','4612.506238941296033','test','test','0.95'),('2019-10-12 19:59:59','2019-10-12 23:59:59','XLMBTC','4h','0.000007330000000','0.000007320000000','0.033784045696779','0.033737955593509','4609.010326982113','4609.010326982112929','test','test','0.13'),('2019-10-13 03:59:59','2019-10-20 19:59:59','XLMBTC','4h','0.000007370000000','0.000007690000000','0.033773803451608','0.035240237251406','4582.60562437012','4582.605624370119585','test','test','0.0'),('2019-10-20 23:59:59','2019-10-21 03:59:59','XLMBTC','4h','0.000007680000000','0.000007660000000','0.034099677629341','0.034010876385515','4440.0621913203995','4440.062191320399506','test','test','0.26'),('2019-10-21 11:59:59','2019-10-21 15:59:59','XLMBTC','4h','0.000007720000000','0.000007680000000','0.034079944019602','0.033903363998775','4414.500520673776','4414.500520673776009','test','test','0.51'),('2019-10-21 19:59:59','2019-10-23 15:59:59','XLMBTC','4h','0.000007750000000','0.000007830000000','0.034040704014973','0.034392091927386','4392.348905157849','4392.348905157849003','test','test','0.38'),('2019-10-23 19:59:59','2019-10-25 15:59:59','XLMBTC','4h','0.000007870000000','0.000007712600000','0.034118790217732','0.033436414413377','4335.297359305181','4335.297359305181089','test','test','1.99'),('2019-11-01 03:59:59','2019-11-01 19:59:59','XLMBTC','4h','0.000007610000000','0.000007457800000','0.033967151150097','0.033287808127095','4463.488981615944','4463.488981615943885','test','test','2.0'),('2019-11-01 23:59:59','2019-11-04 23:59:59','XLMBTC','4h','0.000007480000000','0.000008450000000','0.033816186033875','0.038201440105113','4520.880485812121','4520.880485812121151','test','test','0.53'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XLMBTC','4h','0.000008860000000','0.000008682800000','0.034790686938594','0.034094873199822','3926.7141014214694','3926.714101421469422','test','test','2.00'),('2019-11-05 11:59:59','2019-11-06 15:59:59','XLMBTC','4h','0.000008580000000','0.000008408400000','0.034636061663312','0.033943340430046','4036.837023695986','4036.837023695985863','test','test','2.00'),('2019-11-06 19:59:59','2019-11-07 03:59:59','XLMBTC','4h','0.000008320000000','0.000008153600000','0.034482123611475','0.033792481139245','4144.48601099455','4144.486010994550270','test','test','2.00'),('2019-11-07 07:59:59','2019-11-08 15:59:59','XLMBTC','4h','0.000008140000000','0.000008000000000','0.034328869728757','0.033738446907869','4217.305863483647','4217.305863483647045','test','test','1.84'),('2019-11-08 19:59:59','2019-11-15 11:59:59','XLMBTC','4h','0.000008070000000','0.000008470000000','0.034197664657448','0.035892716189416','4237.628829919262','4237.628829919261989','test','test','0.0'),('2019-11-15 15:59:59','2019-11-16 15:59:59','XLMBTC','4h','0.000008480000000','0.000008420000000','0.034574342775664','0.034329712991874','4077.1630631678713','4077.163063167871314','test','test','0.70'),('2019-11-16 19:59:59','2019-11-16 23:59:59','XLMBTC','4h','0.000008410000000','0.000008390000000','0.034519980601488','0.034437887900890','4104.6350299034475','4104.635029903447503','test','test','0.23'),('2019-11-17 03:59:59','2019-11-17 19:59:59','XLMBTC','4h','0.000008470000000','0.000008420000000','0.034501737779133','0.034298067544309','4073.4046964737763','4073.404696473776312','test','test','0.59'),('2019-11-17 23:59:59','2019-11-18 03:59:59','XLMBTC','4h','0.000008420000000','0.000008350000000','0.034456477726950','0.034170022448935','4092.2182573574555','4092.218257357455514','test','test','0.83'),('2019-11-23 07:59:59','2019-11-23 11:59:59','XLMBTC','4h','0.000008230000000','0.000008360000000','0.034392820998502','0.034936085485720','4178.957593985662','4178.957593985662243','test','test','0.0'),('2019-11-23 15:59:59','2019-11-24 15:59:59','XLMBTC','4h','0.000008340000000','0.000008173200000','0.034513546440106','0.033823275511304','4138.31492087602','4138.314920876019642','test','test','1.99'),('2019-11-25 07:59:59','2019-11-25 15:59:59','XLMBTC','4h','0.000008330000000','0.000008163400000','0.034360152900372','0.033672949842365','4124.868295362811','4124.868295362811295','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:21:40
