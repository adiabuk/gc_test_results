-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance'),(5,'margin');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL,
  `drawdown_perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  `closed_by` varchar(10) DEFAULT NULL,
  `drawdown_perc` varchar(4) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-05-23 03:59:59','2019-05-23 11:59:59','RENBNB','4h','0.001170000000000','0.001146600000000','3.111111111111111','3.048888888888889','2659.069325735992','2659.069325735992152','test','test','2.00'),('2019-05-30 11:59:59','2019-05-30 15:59:59','RENBNB','4h','0.001030000000000','0.001030000000000','3.097283950617284','3.097283950617284','3007.0717967158093','3007.071796715809342','test','test','0.0'),('2019-05-30 23:59:59','2019-06-12 19:59:59','RENBNB','4h','0.001110000000000','0.001340000000000','3.097283950617284','3.739063507952396','2790.3459014570126','2790.345901457012587','test','test','0.0'),('2019-06-14 03:59:59','2019-06-14 15:59:59','RENBNB','4h','0.001380000000000','0.001352400000000','3.239901630025086','3.175103597424584','2347.754804366005','2347.754804366004919','test','test','2.00'),('2019-06-16 11:59:59','2019-06-16 15:59:59','RENBNB','4h','0.001610000000000','0.001577800000000','3.225502067224975','3.160992025880475','2003.4174330589906','2003.417433058990582','test','test','2.00'),('2019-06-16 19:59:59','2019-06-17 15:59:59','RENBNB','4h','0.001560000000000','0.001528800000000','3.211166502481753','3.146943172432118','2058.4400656934313','2058.440065693431279','test','test','2.00'),('2019-06-17 19:59:59','2019-06-18 03:59:59','RENBNB','4h','0.001410000000000','0.001400000000000','3.196894651359612','3.174221639647842','2267.3011711770296','2267.301171177029573','test','test','0.70'),('2019-06-18 07:59:59','2019-06-18 15:59:59','RENBNB','4h','0.001440000000000','0.001411200000000','3.191856204312552','3.128019080226301','2216.566808550383','2216.566808550383030','test','test','2.00'),('2019-06-18 19:59:59','2019-06-18 23:59:59','RENBNB','4h','0.001390000000000','0.001362200000000','3.177670176737829','3.114116773203072','2286.0936523293735','2286.093652329373526','test','test','1.99'),('2019-06-20 03:59:59','2019-06-20 11:59:59','RENBNB','4h','0.001500000000000','0.001470000000000','3.163547198174550','3.100276254211059','2109.0314654497','2109.031465449700136','test','test','2.00'),('2019-06-20 23:59:59','2019-06-21 07:59:59','RENBNB','4h','0.001410000000000','0.001381800000000','3.149486988404885','3.086497248636788','2233.6787151807694','2233.678715180769359','test','test','1.99'),('2019-06-22 03:59:59','2019-07-07 15:59:59','RENBNB','4h','0.001450000000000','0.002660000000000','3.135489268456420','5.752001002823501','2162.4063920389103','2162.406392038910326','test','test','0.0'),('2019-07-07 19:59:59','2019-07-07 23:59:59','RENBNB','4h','0.002610000000000','0.002557800000000','3.716936320537993','3.642597594127233','1424.1135327731772','1424.113532773177212','test','test','2.00'),('2019-07-09 15:59:59','2019-07-13 03:59:59','RENBNB','4h','0.002890000000000','0.002979000000000','3.700416603557824','3.814374069895763','1280.4209700892125','1280.420970089212460','test','test','0.0'),('2019-07-13 07:59:59','2019-07-13 23:59:59','RENBNB','4h','0.003130000000000','0.003067400000000','3.725740484966255','3.651225675266930','1190.3324233119026','1190.332423311902630','test','test','1.99'),('2019-07-14 03:59:59','2019-07-14 15:59:59','RENBNB','4h','0.003147000000000','0.003084060000000','3.709181638366405','3.634998005599077','1178.640495191104','1178.640495191104037','test','test','2.00'),('2019-07-14 19:59:59','2019-07-14 23:59:59','RENBNB','4h','0.003020000000000','0.002959600000000','3.692696386640332','3.618842458907525','1222.7471478941497','1222.747147894149748','test','test','1.99'),('2019-07-19 15:59:59','2019-07-19 19:59:59','RENBNB','4h','0.002797000000000','0.002741060000000','3.676284402699708','3.602758714645714','1314.3669655701494','1314.366965570149432','test','test','1.99'),('2019-07-19 23:59:59','2019-07-20 11:59:59','RENBNB','4h','0.002821000000000','0.002764580000000','3.659945360909932','3.586746453691733','1297.3928964586783','1297.392896458678251','test','test','2.00'),('2019-07-20 15:59:59','2019-07-30 11:59:59','RENBNB','4h','0.003119000000000','0.003809000000000','3.643678937083665','4.449750904569310','1168.22024273282','1168.220242732819997','test','test','1.79'),('2019-07-30 23:59:59','2019-07-31 03:59:59','RENBNB','4h','0.003967000000000','0.003916000000000','3.822806040969364','3.773659807521056','963.6516362413321','963.651636241332085','test','test','1.28'),('2019-08-02 07:59:59','2019-08-03 23:59:59','RENBNB','4h','0.003874000000000','0.003943000000000','3.811884655758629','3.879778316380040','983.9660959624753','983.966095962475265','test','test','0.0'),('2019-08-04 03:59:59','2019-08-04 07:59:59','RENBNB','4h','0.003988000000000','0.003937000000000','3.826972135896721','3.778031419013388','959.6218996731997','959.621899673199664','test','test','1.27'),('2019-08-04 11:59:59','2019-08-07 15:59:59','RENBNB','4h','0.004012000000000','0.004200000000000','3.816096421033758','3.994916492607623','951.1705934780053','951.170593478005344','test','test','0.0'),('2019-08-09 19:59:59','2019-08-10 03:59:59','RENBNB','4h','0.004330000000000','0.004243400000000','3.855834214716838','3.778717530422501','890.4928902348357','890.492890234835727','test','test','2.00'),('2019-08-28 03:59:59','2019-08-28 07:59:59','RENBNB','4h','0.003257000000000','0.003191860000000','3.838697173762542','3.761923230287291','1178.5990708512563','1178.599070851256329','test','test','1.99'),('2019-08-30 23:59:59','2019-08-31 03:59:59','RENBNB','4h','0.003199000000000','0.003135020000000','3.821636297434708','3.745203571486014','1194.6346662815592','1194.634666281559248','test','test','1.99'),('2019-08-31 07:59:59','2019-08-31 11:59:59','RENBNB','4h','0.003160000000000','0.003096800000000','3.804651247223887','3.728558222279409','1204.0035592480656','1204.003559248065585','test','test','2.00'),('2019-09-19 15:59:59','2019-09-23 19:59:59','RENBNB','4h','0.002346000000000','0.002349000000000','3.787741686125115','3.792585345570288','1614.553148390927','1614.553148390926935','test','test','0.0'),('2019-09-25 23:59:59','2019-09-26 03:59:59','RENBNB','4h','0.002406000000000','0.002371000000000','3.788818054890708','3.733702247774675','1574.7373461723641','1574.737346172364141','test','test','1.45'),('2019-09-26 07:59:59','2019-09-26 11:59:59','RENBNB','4h','0.002341000000000','0.002328000000000','3.776570097753812','3.755598115152018','1613.2294309072242','1613.229430907224241','test','test','0.55'),('2019-09-26 15:59:59','2019-09-28 03:59:59','RENBNB','4h','0.002317000000000','0.002408000000000','3.771909657175636','3.920051124073773','1627.9282076718323','1627.928207671832297','test','test','0.0'),('2019-09-28 07:59:59','2019-09-30 07:59:59','RENBNB','4h','0.002455000000000','0.002455000000000','3.804829983152999','3.804829983152999','1549.8289137079425','1549.828913707942547','test','test','0.48'),('2019-09-30 11:59:59','2019-10-16 11:59:59','RENBNB','4h','0.002445000000000','0.003018000000000','3.804829983152999','4.696514065094377','1556.1676822711652','1556.167682271165177','test','test','0.0'),('2019-10-22 15:59:59','2019-10-22 19:59:59','RENBNB','4h','0.003191000000000','0.003150000000000','4.002982001362194','3.951549139545883','1254.4600443002803','1254.460044300280288','test','test','1.28'),('2019-10-22 23:59:59','2019-10-23 07:59:59','RENBNB','4h','0.003140000000000','0.003079000000000','3.991552476514125','3.914009578085029','1271.1950562146894','1271.195056214689430','test','test','1.94'),('2019-10-23 11:59:59','2019-10-23 15:59:59','RENBNB','4h','0.003186000000000','0.003122280000000','3.974320721307660','3.894834306881507','1247.4327436621656','1247.432743662165649','test','test','2.00'),('2019-10-24 07:59:59','2019-10-24 23:59:59','RENBNB','4h','0.003147000000000','0.003100000000000','3.956657073657404','3.897564959751494','1257.2790192746754','1257.279019274675420','test','test','1.49'),('2019-11-02 07:59:59','2019-11-02 11:59:59','RENBNB','4h','0.002759000000000','0.002703820000000','3.943525492789423','3.864654982933635','1429.3314580606825','1429.331458060682507','test','test','2.00'),('2019-11-06 15:59:59','2019-11-07 07:59:59','RENBNB','4h','0.002875000000000','0.002817500000000','3.925998712821471','3.847478738565041','1365.5647696770334','1365.564769677033382','test','test','2.00'),('2019-11-07 11:59:59','2019-11-08 15:59:59','RENBNB','4h','0.002808000000000','0.002751840000000','3.908549829653375','3.830378833060307','1391.933700019008','1391.933700019008029','test','test','1.99'),('2019-11-08 19:59:59','2019-11-09 03:59:59','RENBNB','4h','0.002813000000000','0.002756740000000','3.891178497077137','3.813354927135594','1383.2842151002976','1383.284215100297615','test','test','2.00'),('2019-11-09 07:59:59','2019-11-10 19:59:59','RENBNB','4h','0.002855000000000','0.002797900000000','3.873884370423461','3.796406683014992','1356.8771875388657','1356.877187538865655','test','test','2.00'),('2019-11-11 03:59:59','2019-11-11 07:59:59','RENBNB','4h','0.002754000000000','0.002771000000000','3.856667106554913','3.880473693632413','1400.387475147027','1400.387475147027089','test','test','0.0'),('2019-11-11 11:59:59','2019-11-11 15:59:59','RENBNB','4h','0.002785000000000','0.002782000000000','3.861957459238802','3.857797361437108','1386.6992672311674','1386.699267231167369','test','test','0.10'),('2019-11-11 19:59:59','2019-11-11 23:59:59','RENBNB','4h','0.002773000000000','0.002773000000000','3.861032993060647','3.861032993060647','1392.3667483089243','1392.366748308924343','test','test','0.0'),('2019-11-12 03:59:59','2019-11-12 23:59:59','RENBNB','4h','0.002763000000000','0.002763000000000','3.861032993060647','3.861032993060647','1397.40607783592','1397.406077835920087','test','test','0.0'),('2019-11-14 19:59:59','2019-11-15 07:59:59','RENBNB','4h','0.002869000000000','0.002811620000000','3.861032993060647','3.783812333199434','1345.776574785865','1345.776574785865023','test','test','2.00'),('2019-11-15 11:59:59','2019-11-17 07:59:59','RENBNB','4h','0.002844000000000','0.002798000000000','3.843872846424822','3.781700500807543','1351.5727308104156','1351.572730810415578','test','test','1.61'),('2019-11-18 03:59:59','2019-11-18 07:59:59','RENBNB','4h','0.002791000000000','0.002761000000000','3.830056769620983','3.788888119284677','1372.2883445435266','1372.288344543526591','test','test','1.07'),('2019-11-19 15:59:59','2019-11-19 23:59:59','RENBNB','4h','0.002798000000000','0.002819000000000','3.820908180657359','3.849585475794530','1365.5854827224298','1365.585482722429788','test','test','0.53'),('2019-11-20 03:59:59','2019-11-20 07:59:59','RENBNB','4h','0.002796000000000','0.002788000000000','3.827280912910063','3.816330180684284','1368.841528222483','1368.841528222483021','test','test','0.28'),('2019-11-20 15:59:59','2019-11-20 19:59:59','RENBNB','4h','0.002787000000000','0.002768000000000','3.824847416859891','3.798772030810254','1372.3887394545716','1372.388739454571578','test','test','0.68'),('2019-11-21 07:59:59','2019-11-21 11:59:59','RENBNB','4h','0.002789000000000','0.002799000000000','3.819052886626638','3.832746156209379','1369.326958274162','1369.326958274162052','test','test','0.0'),('2019-11-21 15:59:59','2019-11-24 07:59:59','RENBNB','4h','0.002770000000000','0.002873000000000','3.822095835422802','3.964217088508921','1379.8179911273655','1379.817991127365531','test','test','0.0'),('2019-11-24 11:59:59','2019-11-24 15:59:59','RENBNB','4h','0.002832000000000','0.002820000000000','3.853678336108606','3.837349190616621','1360.762124332135','1360.762124332135045','test','test','0.42'),('2019-11-24 19:59:59','2019-11-24 23:59:59','RENBNB','4h','0.002839000000000','0.002824000000000','3.850049637110388','3.829707705248234','1356.128790810281','1356.128790810281089','test','test','0.52'),('2019-11-25 03:59:59','2019-11-25 07:59:59','RENBNB','4h','0.002823000000000','0.002766540000000','3.845529207807687','3.768618623651533','1362.2136761628362','1362.213676162836236','test','test','1.99'),('2019-12-07 07:59:59','2019-12-07 15:59:59','RENBNB','4h','0.002567000000000','0.002518000000000','3.828437966884097','3.755359096460520','1491.4055188484992','1491.405518848499241','test','test','1.90'),('2019-12-14 15:59:59','2019-12-15 03:59:59','RENBNB','4h','0.002457000000000','0.002448000000000','3.812198217901079','3.798234121864811','1551.5662262519656','1551.566226251965645','test','test','0.36'),('2019-12-15 07:59:59','2019-12-16 07:59:59','RENBNB','4h','0.002485000000000','0.002435300000000','3.809095085448575','3.732913183739603','1532.8350444461068','1532.835044446106849','test','test','2.00'),('2019-12-16 11:59:59','2019-12-16 15:59:59','RENBNB','4h','0.002408000000000','0.002428000000000','3.792165773957693','3.823662167429103','1574.8196735704707','1574.819673570470741','test','test','0.0'),('2019-12-17 03:59:59','2019-12-17 15:59:59','RENBNB','4h','0.002469000000000','0.002419620000000','3.799164972506896','3.723181673056758','1538.7464449197635','1538.746444919763462','test','test','1.99'),('2019-12-18 19:59:59','2019-12-18 23:59:59','RENBNB','4h','0.002455000000000','0.002405900000000','3.782279794851310','3.706634198954284','1540.6435009577635','1540.643500957763536','test','test','1.99'),('2019-12-21 23:59:59','2019-12-22 03:59:59','RENBNB','4h','0.002401000000000','0.002417000000000','3.765469662429748','3.790562338231029','1568.2922375800702','1568.292237580070150','test','test','0.0'),('2019-12-22 07:59:59','2019-12-22 19:59:59','RENBNB','4h','0.002502000000000','0.002451960000000','3.771045812607810','3.695624896355654','1507.2125549991247','1507.212554999124677','test','test','1.99'),('2019-12-23 15:59:59','2019-12-23 19:59:59','RENBNB','4h','0.002421000000000','0.002431000000000','3.754285608996220','3.769792777971834','1550.7168975614293','1550.716897561429278','test','test','0.0'),('2019-12-23 23:59:59','2019-12-25 19:59:59','RENBNB','4h','0.002470000000000','0.002471000000000','3.757731646546356','3.759252995391112','1521.34884475561','1521.348844755609889','test','test','0.0'),('2019-12-25 23:59:59','2019-12-26 03:59:59','RENBNB','4h','0.002491000000000','0.002460000000000','3.758069724067413','3.711301293137629','1508.6590622510691','1508.659062251069145','test','test','1.24'),('2019-12-26 07:59:59','2019-12-26 11:59:59','RENBNB','4h','0.002455000000000','0.002505000000000','3.747676739416351','3.824004167917702','1526.5485700270267','1526.548570027026699','test','test','0.0'),('2019-12-26 15:59:59','2019-12-26 19:59:59','RENBNB','4h','0.002488000000000','0.002475000000000','3.764638390194428','3.744967851981997','1513.1183240331302','1513.118324033130193','test','test','0.52'),('2019-12-26 23:59:59','2019-12-27 15:59:59','RENBNB','4h','0.002464000000000','0.002478000000000','3.760267159480555','3.781632313795785','1526.0824510878876','1526.082451087887648','test','test','0.0'),('2020-01-02 03:59:59','2020-01-05 15:59:59','RENBNB','4h','0.002390000000000','0.002452000000000','3.765014971550606','3.862684816000873','1575.3200717784962','1575.320071778496185','test','test','0.0'),('2020-01-05 19:59:59','2020-01-06 03:59:59','RENBNB','4h','0.002550000000000','0.002513000000000','3.786719381428443','3.731774825697913','1484.9879927170364','1484.987992717036377','test','test','1.68'),('2020-01-06 07:59:59','2020-01-06 11:59:59','RENBNB','4h','0.002678000000000','0.002624440000000','3.774509480154992','3.699019290551892','1409.4508887808036','1409.450888780803552','test','test','2.00'),('2020-01-06 15:59:59','2020-01-06 19:59:59','RENBNB','4h','0.002644000000000','0.002591120000000','3.757733882465414','3.682579204816106','1421.2306665905498','1421.230666590549845','test','test','1.99'),('2020-01-06 23:59:59','2020-01-07 19:59:59','RENBNB','4h','0.002679000000000','0.002625420000000','3.741032842987790','3.666212186128034','1396.4288327688653','1396.428832768865277','test','test','2.00'),('2020-01-07 23:59:59','2020-01-08 03:59:59','RENBNB','4h','0.002572000000000','0.002520560000000','3.724406030352289','3.649917909745243','1448.0583321742959','1448.058332174295856','test','test','2.00'),('2020-01-08 07:59:59','2020-01-08 11:59:59','RENBNB','4h','0.002631000000000','0.002578380000000','3.707853114661834','3.633696052368597','1409.2942283017235','1409.294228301723479','test','test','2.00'),('2020-01-08 15:59:59','2020-01-13 07:59:59','RENBNB','4h','0.002701000000000','0.002920000000000','3.691373767485559','3.990674343227631','1366.6692956259012','1366.669295625901213','test','test','0.0'),('2020-01-13 11:59:59','2020-01-14 07:59:59','RENBNB','4h','0.003020000000000','0.002959600000000','3.757885006539353','3.682727306408566','1244.3327836223025','1244.332783622302486','test','test','1.99'),('2020-01-14 11:59:59','2020-01-14 15:59:59','RENBNB','4h','0.002832000000000','0.002775360000000','3.741183295399178','3.666359629491194','1321.0392992228735','1321.039299222873524','test','test','2.00'),('2020-01-31 19:59:59','2020-02-01 07:59:59','RENBNB','4h','0.002454000000000','0.002424000000000','3.724555814086294','3.679023346921425','1517.748905495637','1517.748905495637018','test','test','1.22'),('2020-02-01 11:59:59','2020-02-02 07:59:59','RENBNB','4h','0.002432000000000','0.002432000000000','3.714437488049655','3.714437488049655','1527.3180460730487','1527.318046073048663','test','test','0.0'),('2020-02-02 11:59:59','2020-02-02 19:59:59','RENBNB','4h','0.002432000000000','0.002474000000000','3.714437488049655','3.778584845984724','1527.3180460730487','1527.318046073048663','test','test','0.32'),('2020-02-02 23:59:59','2020-02-07 11:59:59','RENBNB','4h','0.002507000000000','0.002628000000000','3.728692456479671','3.908657269895722','1487.3125075706703','1487.312507570670277','test','test','0.91'),('2020-02-07 15:59:59','2020-02-07 19:59:59','RENBNB','4h','0.002638000000000','0.002599000000000','3.768684637238792','3.712968677855808','1428.6143431534465','1428.614343153446498','test','test','1.47'),('2020-02-08 03:59:59','2020-02-08 07:59:59','RENBNB','4h','0.002651000000000','0.002684000000000','3.756303312931463','3.803062275333099','1416.9382545950443','1416.938254595044327','test','test','0.0'),('2020-02-08 11:59:59','2020-02-08 19:59:59','RENBNB','4h','0.002907000000000','0.002848860000000','3.766694193465160','3.691360309595857','1295.7324366925216','1295.732436692521560','test','test','1.99'),('2020-02-13 23:59:59','2020-02-14 03:59:59','RENBNB','4h','0.002507000000000','0.002472000000000','3.749953330383093','3.697600571482651','1495.7931114412017','1495.793111441201745','test','test','1.39'),('2020-02-14 11:59:59','2020-02-14 19:59:59','RENBNB','4h','0.002590000000000','0.002551000000000','3.738319383960772','3.682028088217733','1443.3665575138116','1443.366557513811586','test','test','1.50'),('2020-02-14 23:59:59','2020-02-15 15:59:59','RENBNB','4h','0.002561000000000','0.002509780000000','3.725810207128986','3.651294002986406','1454.826320628265','1454.826320628264966','test','test','2.00'),('2020-02-15 19:59:59','2020-02-15 23:59:59','RENBNB','4h','0.002538000000000','0.002498000000000','3.709251050652858','3.650791617230433','1461.4858355606216','1461.485835560621581','test','test','1.57'),('2020-02-16 03:59:59','2020-02-16 15:59:59','RENBNB','4h','0.002542000000000','0.002491160000000','3.696260065447873','3.622334864138915','1454.0755568244979','1454.075556824497880','test','test','1.99');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit`,`trades`.`drawdown_perc` AS `drawdown_perc` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-03 20:39:56
