-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 23:59:59','2019-01-06 19:59:59','VIABTC','4h','0.000093700000000','0.000082700000000','0.001467500000000','0.001295221451441','15.661686232657418','15.661686232657418','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','VIABTC','4h','0.000083100000000','0.000083000000000','0.001467500000000','0.001465734055355','17.65944645006017','17.659446450060170','test'),('2019-01-16 11:59:59','2019-01-22 07:59:59','VIABTC','4h','0.000083700000000','0.000085800000000','0.001467500000000','0.001504318996416','17.532855436081242','17.532855436081242','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','VIABTC','4h','0.000088400000000','0.000085800000000','0.001467500000000','0.001424338235294','16.600678733031675','16.600678733031675','test'),('2019-01-25 15:59:59','2019-01-27 03:59:59','VIABTC','4h','0.000091700000000','0.000087400000000','0.001467500000000','0.001398685932388','16.00327153762268','16.003271537622680','test'),('2019-02-05 11:59:59','2019-02-05 15:59:59','VIABTC','4h','0.000084900000000','0.000083500000000','0.001467500000000','0.001443300942285','17.285041224970552','17.285041224970552','test'),('2019-02-10 03:59:59','2019-02-10 07:59:59','VIABTC','4h','0.000083600000000','0.000083000000000','0.001467500000000','0.001456967703349','17.553827751196174','17.553827751196174','test'),('2019-02-10 11:59:59','2019-02-10 15:59:59','VIABTC','4h','0.000083400000000','0.000083200000000','0.001467500000000','0.001463980815348','17.59592326139089','17.595923261390890','test'),('2019-02-11 19:59:59','2019-02-11 23:59:59','VIABTC','4h','0.000084000000000','0.000083700000000','0.001467500000000','0.001462258928571','17.4702380952381','17.470238095238098','test'),('2019-02-12 03:59:59','2019-02-12 11:59:59','VIABTC','4h','0.000083900000000','0.000083400000000','0.001467500000000','0.001458754469607','17.491060786650774','17.491060786650774','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','VIABTC','4h','0.000084300000000','0.000084400000000','0.001467500000000','0.001469240806643','17.408066429418742','17.408066429418742','test'),('2019-02-12 23:59:59','2019-02-18 07:59:59','VIABTC','4h','0.000084900000000','0.000086400000000','0.001467500000000','0.001493427561837','17.285041224970552','17.285041224970552','test'),('2019-02-18 11:59:59','2019-02-18 15:59:59','VIABTC','4h','0.000086900000000','0.000085000000000','0.001467500000000','0.001435414269275','16.88722669735328','16.887226697353281','test'),('2019-02-21 15:59:59','2019-02-23 23:59:59','VIABTC','4h','0.000087100000000','0.000087200000000','0.001467500000000','0.001469184845006','16.84845005740528','16.848450057405280','test'),('2019-02-26 19:59:59','2019-02-27 23:59:59','VIABTC','4h','0.000089300000000','0.000087600000000','0.001467500000000','0.001439563269877','16.43337066069429','16.433370660694290','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','VIABTC','4h','0.000088800000000','0.000088100000000','0.001467500000000','0.001455931869369','16.5259009009009','16.525900900900901','test'),('2019-03-02 11:59:59','2019-03-04 07:59:59','VIABTC','4h','0.000088300000000','0.000088400000000','0.001467500000000','0.001469161947905','16.61947904869762','16.619479048697620','test'),('2019-03-04 23:59:59','2019-03-05 19:59:59','VIABTC','4h','0.000092300000000','0.000090800000000','0.001467500000000','0.001443651137595','15.899241603466956','15.899241603466956','test'),('2019-03-06 07:59:59','2019-03-09 03:59:59','VIABTC','4h','0.000091000000000','0.000092500000000','0.001467500000000','0.001491689560440','16.126373626373628','16.126373626373628','test'),('2019-03-09 07:59:59','2019-03-11 23:59:59','VIABTC','4h','0.000093700000000','0.000198000000000','0.001467500000000','0.003101013874066','15.661686232657418','15.661686232657418','test'),('2019-03-12 11:59:59','2019-03-12 19:59:59','VIABTC','4h','0.000174300000000','0.000132600000000','0.001790460168017','0.001362105669989','10.272290120578024','10.272290120578024','test'),('2019-03-12 23:59:59','2019-03-14 07:59:59','VIABTC','4h','0.000133300000000','0.000112900000000','0.001790460168017','0.001516451260083','13.43180921243061','13.431809212430609','test'),('2019-03-14 19:59:59','2019-03-16 23:59:59','VIABTC','4h','0.000132300000000','0.000123000000000','0.001790460168017','0.001664600156206','13.5333346033031','13.533334603303100','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','VIABTC','4h','0.000122800000000','0.000120600000000','0.001790460168017','0.001758383520056','14.580294527825734','14.580294527825734','test'),('2019-03-21 23:59:59','2019-03-25 19:59:59','VIABTC','4h','0.000121300000000','0.000127500000000','0.001790460168017','0.001881975856737','14.760594954798023','14.760594954798023','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','VIABTC','4h','0.000128000000000','0.000127300000000','0.001790460168017','0.001780668588973','13.987970062632813','13.987970062632813','test'),('2019-03-27 11:59:59','2019-03-28 19:59:59','VIABTC','4h','0.000133900000000','0.000130600000000','0.001790460168017','0.001746333815855','13.371621867191935','13.371621867191935','test'),('2019-03-28 23:59:59','2019-03-29 15:59:59','VIABTC','4h','0.000131600000000','0.000129200000000','0.001790460168017','0.001757807398995','13.605320425661095','13.605320425661095','test'),('2019-03-30 11:59:59','2019-04-02 07:59:59','VIABTC','4h','0.000145000000000','0.000131800000000','0.001790460168017','0.001627466552722','12.348001158737931','12.348001158737931','test'),('2019-05-02 19:59:59','2019-05-08 03:59:59','VIABTC','4h','0.000099600000000','0.000103500000000','0.001790460168017','0.001860568548090','17.976507711014058','17.976507711014058','test'),('2019-05-09 03:59:59','2019-05-10 03:59:59','VIABTC','4h','0.000106200000000','0.000097700000000','0.001790460168017','0.001647155917281','16.859323615979285','16.859323615979285','test'),('2019-05-22 07:59:59','2019-05-22 11:59:59','VIABTC','4h','0.000096800000000','0.000092700000000','0.001790460168017','0.001714624561727','18.496489339018595','18.496489339018595','test'),('2019-06-10 15:59:59','2019-06-11 11:59:59','VIABTC','4h','0.000075700000000','0.000071400000000','0.001790460168017','0.001688756353982','23.6520497756539','23.652049775653900','test'),('2019-06-11 15:59:59','2019-06-12 11:59:59','VIABTC','4h','0.000072200000000','0.000071300000000','0.001790460168017','0.001768141412460','24.798617285554016','24.798617285554016','test'),('2019-07-24 11:59:59','2019-07-25 03:59:59','VIABTC','4h','0.000034500000000','0.000034000000000','0.001790460168017','0.001764511469930','51.8973961744058','51.897396174405799','test'),('2019-07-25 19:59:59','2019-07-27 23:59:59','VIABTC','4h','0.000033700000000','0.000033400000000','0.001790460168017','0.001774521353465','53.129381840267065','53.129381840267065','test'),('2019-07-29 07:59:59','2019-07-30 15:59:59','VIABTC','4h','0.000034200000000','0.000033900000000','0.001790460168017','0.001774754377069','52.35263649172515','52.352636491725150','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','VIABTC','4h','0.000034000000000','0.000034100000000','0.001790460168017','0.001795726227335','52.66059317697059','52.660593176970593','test'),('2019-08-23 07:59:59','2019-08-23 15:59:59','VIABTC','4h','0.000026200000000','0.000025800000000','0.001790460168017','0.001763124898276','68.3381743517939','68.338174351793896','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','VIABTC','4h','0.000025900000000','0.000027200000000','0.001790460168017','0.001880328825099','69.12973621687259','69.129736216872587','test'),('2019-08-26 07:59:59','2019-08-28 19:59:59','VIABTC','4h','0.000027300000000','0.000026800000000','0.001790460168017','0.001757667857247','65.58462153908425','65.584621539084253','test'),('2019-09-14 15:59:59','2019-09-15 19:59:59','VIABTC','4h','0.000023900000000','0.000022700000000','0.001790460168017','0.001700562586359','74.91465138146444','74.914651381464438','test'),('2019-09-15 23:59:59','2019-09-16 07:59:59','VIABTC','4h','0.000022900000000','0.000022500000000','0.001790460168017','0.001759185754602','78.18603353786027','78.186033537860268','test'),('2019-09-18 03:59:59','2019-09-19 03:59:59','VIABTC','4h','0.000022940000000','0.000023080000000','0.001790460168017','0.001801387126322','78.04970218034002','78.049702180340020','test'),('2019-09-19 11:59:59','2019-09-19 23:59:59','VIABTC','4h','0.000023010000000','0.000022660000000','0.001790460168017','0.001763225876022','77.81226284298131','77.812262842981312','test'),('2019-09-20 03:59:59','2019-09-22 07:59:59','VIABTC','4h','0.000022930000000','0.000023530000000','0.001790460168017','0.001837310412274','78.08374042812909','78.083740428129090','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','VIABTC','4h','0.000024460000000','0.000022520000000','0.001790460168017','0.001648453106449','73.19951627215863','73.199516272158633','test'),('2019-10-02 07:59:59','2019-10-09 15:59:59','VIABTC','4h','0.000023690000000','0.000024710000000','0.001790460168017','0.001867550474956','75.57873229282399','75.578732292823986','test'),('2019-10-09 19:59:59','2019-10-10 07:59:59','VIABTC','4h','0.000025860000000','0.000024700000000','0.001790460168017','0.001710145636118','69.23666542989173','69.236665429891730','test'),('2019-10-13 23:59:59','2019-10-16 07:59:59','VIABTC','4h','0.000025320000000','0.000025660000000','0.001790460168017','0.001814502682121','70.71327677792259','70.713276777922587','test'),('2019-10-18 15:59:59','2019-10-19 03:59:59','VIABTC','4h','0.000025790000000','0.000025110000000','0.001790460168017','0.001743251447030','69.42458968658396','69.424589686583957','test'),('2019-10-19 07:59:59','2019-10-21 07:59:59','VIABTC','4h','0.000026100000000','0.000026050000000','0.001790460168017','0.001787030167695','68.60000643743295','68.600006437432953','test'),('2019-10-21 11:59:59','2019-10-21 15:59:59','VIABTC','4h','0.000027070000000','0.000026270000000','0.001790460168017','0.001737546679490','66.1418606581825','66.141860658182495','test'),('2019-10-21 19:59:59','2019-10-23 07:59:59','VIABTC','4h','0.000026690000000','0.000026710000000','0.001790460168017','0.001791801839181','67.08355818722369','67.083558187223687','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','VIABTC','4h','0.000026810000000','0.000025580000000','0.001790460168017','0.001708316713833','66.78329608418501','66.783296084185011','test'),('2019-11-05 19:59:59','2019-11-07 11:59:59','VIABTC','4h','0.000023900000000','0.000023080000000','0.001790460168017','0.001729030153884','74.91465138146444','74.914651381464438','test'),('2019-11-07 15:59:59','2019-11-08 07:59:59','VIABTC','4h','0.000023300000000','0.000023020000000','0.001790460168017','0.001768943908487','76.84378403506437','76.843784035064374','test'),('2019-11-09 07:59:59','2019-11-09 19:59:59','VIABTC','4h','0.000023540000000','0.000023420000000','0.001193640112011','0.001187555285612','50.70688666148399','50.706886661483992','test'),('2019-11-09 23:59:59','2019-11-10 15:59:59','VIABTC','4h','0.000023470000000','0.000023210000000','0.001340662203860','0.001325810385666','57.122377667650156','57.122377667650156','test'),('2019-11-17 03:59:59','2019-11-20 15:59:59','VIABTC','4h','0.000023220000000','0.000023780000000','0.001340662203860','0.001372995142454','57.73739034711455','57.737390347114548','test'),('2019-11-26 11:59:59','2019-11-27 19:59:59','VIABTC','4h','0.000024820000000','0.000023850000000','0.001345032483960','0.001292466750300','54.1914779999899','54.191477999989900','test'),('2019-11-27 23:59:59','2019-11-28 07:59:59','VIABTC','4h','0.000024010000000','0.000024000000000','0.001345032483960','0.001344472287174','56.01967863223657','56.019678632236570','test'),('2019-11-29 03:59:59','2019-12-02 19:59:59','VIABTC','4h','0.000026480000000','0.000025760000000','0.001345032483960','0.001308460603731','50.79427809516616','50.794278095166163','test'),('2019-12-06 19:59:59','2019-12-14 19:59:59','VIABTC','4h','0.000027830000000','0.000030360000000','0.001345032483960','0.001467308164320','48.33030844268775','48.330308442687752','test'),('2019-12-17 07:59:59','2019-12-17 19:59:59','VIABTC','4h','0.000030910000000','0.000029990000000','0.001353176951381','0.001312901221997','43.77796672212874','43.777966722128738','test'),('2019-12-18 11:59:59','2019-12-18 15:59:59','VIABTC','4h','0.000030450000000','0.000028900000000','0.001353176951381','0.001284296022821','44.4393087481445','44.439308748144498','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  6:05:14
