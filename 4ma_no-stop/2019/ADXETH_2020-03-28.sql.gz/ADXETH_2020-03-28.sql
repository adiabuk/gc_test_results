-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 19:59:59','2019-01-14 15:59:59','ADXETH','4h','0.000755300000000','0.000721000000000','0.072144500000000','0.068868243744208','95.51767509598835','95.517675095988352','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','ADXETH','4h','0.000721700000000','0.000725900000000','0.072144500000000','0.072564351600388','99.96466675904115','99.964666759041151','test'),('2019-01-15 07:59:59','2019-01-15 11:59:59','ADXETH','4h','0.000744100000000','0.000738500000000','0.072144500000000','0.071601549858890','96.95538234108318','96.955382341083180','test'),('2019-01-15 15:59:59','2019-01-25 15:59:59','ADXETH','4h','0.000762800000000','0.000905500000000','0.072144500000000','0.085640855728894','94.57852648138437','94.578526481384372','test'),('2019-02-06 11:59:59','2019-02-09 03:59:59','ADXETH','4h','0.000882900000000','0.000938500000000','0.074668750233095','0.079370961710001','84.57214886521122','84.572148865211219','test'),('2019-02-09 07:59:59','2019-02-09 11:59:59','ADXETH','4h','0.000962300000000','0.000947200000000','0.075844303102322','0.074654186738563','78.81565322905695','78.815653229056949','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','ADXETH','4h','0.000963000000000','0.000913300000000','0.075844303102322','0.071930012485307','78.75836251539148','78.758362515391482','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ADXETH','4h','0.000982200000000','0.000930000000000','0.075844303102322','0.071813481862309','77.21879770140706','77.218797701407055','test'),('2019-02-26 19:59:59','2019-02-27 15:59:59','ADXETH','4h','0.000907400000000','0.000853000000000','0.075844303102322','0.071297322620984','83.58420002459995','83.584200024599951','test'),('2019-02-27 19:59:59','2019-03-04 07:59:59','ADXETH','4h','0.000878200000000','0.000911000000000','0.075844303102322','0.078677021323406','86.36336039890914','86.363360398909137','test'),('2019-03-07 15:59:59','2019-03-16 03:59:59','ADXETH','4h','0.000966900000000','0.001050900000000','0.075844303102322','0.082433321057224','78.44068993931327','78.440689939313273','test'),('2019-03-24 23:59:59','2019-03-25 07:59:59','ADXETH','4h','0.001042500000000','0.001051500000000','0.075844303102322','0.076499074064356','72.75232911493717','72.752329114937169','test'),('2019-03-25 15:59:59','2019-03-26 03:59:59','ADXETH','4h','0.001043200000000','0.001033100000000','0.075844303102322','0.075109997637087','72.70351140943443','72.703511409434427','test'),('2019-03-26 07:59:59','2019-03-26 11:59:59','ADXETH','4h','0.001037800000000','0.001030900000000','0.075844303102322','0.075340038608772','73.08181065939681','73.081810659396808','test'),('2019-03-26 15:59:59','2019-03-29 03:59:59','ADXETH','4h','0.001420000000000','0.001171500000000','0.075844303102322','0.062571550059416','53.41148105797324','53.411481057973241','test'),('2019-04-01 19:59:59','2019-04-02 07:59:59','ADXETH','4h','0.001151900000000','0.001146200000000','0.075844303102322','0.075468999232469','65.84278418467055','65.842784184670549','test'),('2019-04-21 03:59:59','2019-04-21 11:59:59','ADXETH','4h','0.001062600000000','0.000996300000000','0.075844303102322','0.071112063975949','71.37615575223226','71.376155752232265','test'),('2019-04-21 23:59:59','2019-04-22 15:59:59','ADXETH','4h','0.001042500000000','0.001020000000000','0.075844303102322','0.074207375697236','72.75232911493717','72.752329114937169','test'),('2019-04-22 19:59:59','2019-04-23 07:59:59','ADXETH','4h','0.001045800000000','0.001009800000000','0.075844303102322','0.073233483718421','72.52276066391471','72.522760663914710','test'),('2019-04-23 11:59:59','2019-04-23 15:59:59','ADXETH','4h','0.001041000000000','0.001034800000000','0.075844303102322','0.075392588713048','72.85715956034774','72.857159560347739','test'),('2019-04-23 23:59:59','2019-04-24 03:59:59','ADXETH','4h','0.001029600000000','0.000981900000000','0.075844303102322','0.072330537311742','73.66385305198328','73.663853051983281','test'),('2019-05-24 03:59:59','2019-05-24 19:59:59','ADXETH','4h','0.000676000000000','0.000631300000000','0.075844303102322','0.070829154657538','112.19571464840533','112.195714648405328','test'),('2019-05-24 23:59:59','2019-05-25 15:59:59','ADXETH','4h','0.000642000000000','0.000640000000000','0.075844303102322','0.075608028014776','118.13754377308723','118.137543773087231','test'),('2019-05-25 19:59:59','2019-05-26 23:59:59','ADXETH','4h','0.000643300000000','0.000626700000000','0.075844303102322','0.073887182891692','117.89880786930205','117.898807869302047','test'),('2019-05-27 03:59:59','2019-05-27 07:59:59','ADXETH','4h','0.000638600000000','0.000632500000000','0.075844303102322','0.075119827297555','118.76652537162856','118.766525371628560','test'),('2019-05-29 03:59:59','2019-05-30 03:59:59','ADXETH','4h','0.000681200000000','0.000619800000000','0.075844303102322','0.069008072611302','111.3392588113946','111.339258811394600','test'),('2019-05-31 03:59:59','2019-06-01 03:59:59','ADXETH','4h','0.000651600000000','0.000649200000000','0.075844303102322','0.075564950236383','116.39702747440454','116.397027474404538','test'),('2019-06-01 07:59:59','2019-06-01 15:59:59','ADXETH','4h','0.000651800000000','0.000642100000000','0.075844303102322','0.074715598376804','116.36131190905492','116.361311909054919','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','ADXETH','4h','0.000647600000000','0.000644300000000','0.075844303102322','0.075457820396581','117.11597143656887','117.115971436568870','test'),('2019-06-02 23:59:59','2019-06-03 07:59:59','ADXETH','4h','0.000655200000000','0.000643200000000','0.075844303102322','0.074455213301913','115.75748336740232','115.757483367402315','test'),('2019-06-03 11:59:59','2019-06-03 23:59:59','ADXETH','4h','0.000651800000000','0.000632100000000','0.075844303102322','0.073551985257714','116.36131190905492','116.361311909054919','test'),('2019-06-08 19:59:59','2019-06-12 23:59:59','ADXETH','4h','0.000660900000000','0.000655000000000','0.075844303102322','0.075167224288124','114.75912105057044','114.759121050570442','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','ADXETH','4h','0.000676500000000','0.000651300000000','0.075844303102322','0.073019060769464','112.11279098643311','112.112790986433112','test'),('2019-07-06 19:59:59','2019-07-07 15:59:59','ADXETH','4h','0.000471300000000','0.000461600000000','0.075844303102322','0.074283323386446','160.92574390477827','160.925743904778273','test'),('2019-07-15 03:59:59','2019-07-16 23:59:59','ADXETH','4h','0.000513300000000','0.000459200000000','0.075844303102322','0.067850582475329','147.75823709784143','147.758237097841430','test'),('2019-07-22 03:59:59','2019-07-24 23:59:59','ADXETH','4h','0.000458700000000','0.000484200000000','0.075844303102322','0.080060631266938','165.34620253394812','165.346202533948116','test'),('2019-07-26 07:59:59','2019-07-31 03:59:59','ADXETH','4h','0.000503100000000','0.000502200000000','0.075844303102322','0.075708624563677','150.75393182731463','150.753931827314631','test'),('2019-08-15 11:59:59','2019-08-15 15:59:59','ADXETH','4h','0.000440100000000','0.000436800000000','0.075844303102322','0.075275600079742','172.33424926680755','172.334249266807547','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','ADXETH','4h','0.000441100000000','0.000435200000000','0.075844303102322','0.074829836114556','171.94355724851962','171.943557248519625','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','ADXETH','4h','0.000436600000000','0.000438200000000','0.075844303102322','0.076122248326701','173.7157652366514','173.715765236651407','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','ADXETH','4h','0.000436000000000','0.000433300000000','0.075844303102322','0.075374625078523','173.9548236291789','173.954823629178890','test'),('2019-08-17 03:59:59','2019-08-17 23:59:59','ADXETH','4h','0.000448100000000','0.000439200000000','0.075844303102322','0.074337911007676','169.25753872421782','169.257538724217824','test'),('2019-08-18 03:59:59','2019-08-18 11:59:59','ADXETH','4h','0.000443400000000','0.000433000000000','0.075844303102322','0.074065365907319','171.05165336563374','171.051653365633740','test'),('2019-08-22 23:59:59','2019-08-27 11:59:59','ADXETH','4h','0.000447800000000','0.000481200000000','0.075844303102322','0.081501292212678','169.37093144779365','169.370931447793652','test'),('2019-09-05 15:59:59','2019-09-06 11:59:59','ADXETH','4h','0.000498100000000','0.000459500000000','0.075844303102322','0.069966788346752','152.26722164690221','152.267221646902215','test'),('2019-09-06 19:59:59','2019-09-06 23:59:59','ADXETH','4h','0.000458100000000','0.000463600000000','0.075844303102322','0.076754898315295','165.5627659950273','165.562765995027291','test'),('2019-10-03 07:59:59','2019-10-07 07:59:59','ADXETH','4h','0.000381700000000','0.000463500000000','0.075844303102322','0.092098073062421','198.70134425549384','198.701344255493836','test'),('2019-10-12 19:59:59','2019-10-13 11:59:59','ADXETH','4h','0.000466200000000','0.000439600000000','0.075844303102322','0.071516850372760','162.68619284067353','162.686192840673527','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','ADXETH','4h','0.000441100000000','0.000441900000000','0.075844303102322','0.075981857948121','171.94355724851962','171.943557248519625','test'),('2019-10-22 03:59:59','2019-10-23 15:59:59','ADXETH','4h','0.000459100000000','0.000433600000000','0.075844303102322','0.071631648497423','165.20214136859508','165.202141368595079','test'),('2019-10-28 23:59:59','2019-10-29 15:59:59','ADXETH','4h','0.000444000000000','0.000440100000000','0.075844303102322','0.075178103142639','170.8205024827072','170.820502482707212','test'),('2019-10-29 23:59:59','2019-10-30 03:59:59','ADXETH','4h','0.000439800000000','0.000425400000000','0.075844303102322','0.073360997134442','172.45180332497043','172.451803324970427','test'),('2019-10-30 07:59:59','2019-10-30 11:59:59','ADXETH','4h','0.000429000000000','0.000427000000000','0.075844303102322','0.075490716607672','176.7932473247599','176.793247324759903','test'),('2019-10-31 15:59:59','2019-11-03 11:59:59','ADXETH','4h','0.000449300000000','0.000454000000000','0.075844303102322','0.076637688868138','168.80548208840864','168.805482088408638','test'),('2019-11-03 19:59:59','2019-11-04 07:59:59','ADXETH','4h','0.000461300000000','0.000452600000000','0.075844303102322','0.074413898946696','164.41427076159115','164.414270761591155','test'),('2019-11-08 15:59:59','2019-11-10 03:59:59','ADXETH','4h','0.000473000000000','0.000446100000000','0.075844303102322','0.071530959014685','160.34736385268923','160.347363852689227','test'),('2019-11-15 15:59:59','2019-11-16 15:59:59','ADXETH','4h','0.000454300000000','0.000446300000000','0.075844303102322','0.074508722154009','166.94761853911953','166.947618539119532','test'),('2019-11-16 19:59:59','2019-11-17 11:59:59','ADXETH','4h','0.000457400000000','0.000450400000000','0.075844303102322','0.074683590112125','165.81614145675994','165.816141456759937','test'),('2019-11-17 15:59:59','2019-11-18 15:59:59','ADXETH','4h','0.000451700000000','0.000463200000000','0.075844303102322','0.077775251709089','167.90857450148772','167.908574501487720','test'),('2019-11-18 23:59:59','2019-11-19 07:59:59','ADXETH','4h','0.000458900000000','0.000440700000000','0.075844303102322','0.072836313744156','165.27414055855743','165.274140558557434','test'),('2019-11-24 03:59:59','2019-11-24 15:59:59','ADXETH','4h','0.000458500000000','0.000449000000000','0.075844303102322','0.074272828992241','165.4183273769291','165.418327376929113','test'),('2019-11-24 19:59:59','2019-11-25 03:59:59','ADXETH','4h','0.000458700000000','0.000446300000000','0.075844303102322','0.073794010190901','165.34620253394812','165.346202533948116','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','ADXETH','4h','0.000453000000000','0.000445500000000','0.075844303102322','0.074588602719833','167.42671766516997','167.426717665169974','test'),('2019-11-25 19:59:59','2019-11-30 15:59:59','ADXETH','4h','0.000469400000000','0.000480100000000','0.075844303102322','0.077573178354122','161.57712633643374','161.577126336433736','test'),('2019-12-01 15:59:59','2019-12-03 15:59:59','ADXETH','4h','0.000543100000000','0.000518000000000','0.075844303102322','0.072339070165720','139.650714605638','139.650714605638001','test'),('2019-12-07 11:59:59','2019-12-08 15:59:59','ADXETH','4h','0.000531100000000','0.000523600000000','0.050562868734881','0.049848838391233','95.2040458197728','95.204045819772801','test'),('2019-12-08 23:59:59','2019-12-09 07:59:59','ADXETH','4h','0.000524900000000','0.000522900000000','0.056701064487820','0.056485019281160','108.02260332981425','108.022603329814245','test'),('2019-12-09 11:59:59','2019-12-10 03:59:59','ADXETH','4h','0.000531200000000','0.000531900000000','0.056701064487820','0.056775783511053','106.74146176170935','106.741461761709346','test'),('2019-12-10 07:59:59','2019-12-10 15:59:59','ADXETH','4h','0.000542800000000','0.000512200000000','0.056701064487820','0.053504578538433','104.46032514336774','104.460325143367740','test'),('2019-12-11 23:59:59','2019-12-12 07:59:59','ADXETH','4h','0.000530000000000','0.000531400000000','0.056701064487820','0.056850840884580','106.9831405430566','106.983140543056606','test'),('2019-12-13 15:59:59','2019-12-14 19:59:59','ADXETH','4h','0.000538800000000','0.000528300000000','0.056701064487820','0.055596088286777','105.23582867078694','105.235828670786944','test'),('2019-12-14 23:59:59','2019-12-22 11:59:59','ADXETH','4h','0.000533700000000','0.000603400000000','0.056701064487820','0.064106093895354','106.24145491440885','106.241454914408848','test'),('2019-12-26 23:59:59','2019-12-29 19:59:59','ADXETH','4h','0.000596900000000','0.000607900000000','0.057479068855429','0.058538324605822','96.29597730847503','96.295977308475031','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:30:07
