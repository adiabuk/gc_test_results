-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 19:59:59','NEOUSDT','4h','7.789000000000000','7.480000000000000','15.000000000000000','14.404930029528824','1.9257927846963667','1.925792784696367','test'),('2019-01-05 19:59:59','2019-01-06 07:59:59','NEOUSDT','4h','7.762000000000000','7.586000000000000','15.000000000000000','14.659881473846948','1.9324916258696214','1.932491625869621','test'),('2019-01-06 11:59:59','2019-01-10 07:59:59','NEOUSDT','4h','7.763000000000000','8.327999999999999','15.000000000000000','16.091717119670228','1.932242689681824','1.932242689681824','test'),('2019-01-20 03:59:59','2019-01-20 11:59:59','NEOUSDT','4h','8.044000000000000','7.522000000000000','15.039132155761500','14.063196429094729','1.8696086717754226','1.869608671775423','test'),('2019-02-09 07:59:59','2019-02-14 11:59:59','NEOUSDT','4h','7.625000000000000','7.756000000000000','15.039132155761500','15.297509377060486','1.9723452007556066','1.972345200755607','test'),('2019-02-15 23:59:59','2019-02-16 23:59:59','NEOUSDT','4h','8.087000000000000','7.887000000000000','15.039132155761500','14.667198628971306','1.8596676339509708','1.859667633950971','test'),('2019-02-17 03:59:59','2019-02-21 15:59:59','NEOUSDT','4h','8.128000000000000','8.654000000000000','15.039132155761500','16.012383080211617','1.8502869286123893','1.850286928612389','test'),('2019-02-23 15:59:59','2019-02-24 19:59:59','NEOUSDT','4h','8.823000000000000','9.410000000000000','15.039132155761500','16.039695521445733','1.7045372498879632','1.704537249887963','test'),('2019-02-25 03:59:59','2019-02-25 11:59:59','NEOUSDT','4h','9.195000000000000','8.843999999999999','15.260212720255593','14.677685839906520','1.6596207417352467','1.659620741735247','test'),('2019-03-07 23:59:59','2019-03-08 23:59:59','NEOUSDT','4h','9.175000000000001','8.765000000000001','15.260212720255593','14.578284958369512','1.6632384436245877','1.663238443624588','test'),('2019-03-09 03:59:59','2019-03-09 19:59:59','NEOUSDT','4h','8.848000000000001','8.940000000000000','15.260212720255593','15.418885818160600','1.7247075859240044','1.724707585924004','test'),('2019-03-09 23:59:59','2019-03-10 07:59:59','NEOUSDT','4h','8.962999999999999','8.755000000000001','15.260212720255593','14.906076354550679','1.7025786812736354','1.702578681273635','test'),('2019-03-13 15:59:59','2019-03-14 07:59:59','NEOUSDT','4h','8.981999999999999','8.779000000000000','15.260212720255593','14.915320359733229','1.6989771454303713','1.698977145430371','test'),('2019-03-14 15:59:59','2019-03-18 03:59:59','NEOUSDT','4h','9.090999999999999','9.173000000000000','15.260212720255593','15.397858462534877','1.6786066131619837','1.678606613161984','test'),('2019-03-20 23:59:59','2019-03-21 15:59:59','NEOUSDT','4h','9.305999999999999','8.920000000000000','15.260212720255593','14.627240217567151','1.6398251364985594','1.639825136498559','test'),('2019-03-23 07:59:59','2019-03-24 07:59:59','NEOUSDT','4h','9.311999999999999','9.132000000000000','15.260212720255593','14.965234381590859','1.6387685481374135','1.638768548137413','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NEOUSDT','4h','9.148000000000000','9.111000000000001','15.260212720255593','15.198491265221767','1.6681474333466981','1.668147433346698','test'),('2019-03-28 07:59:59','2019-04-07 19:59:59','NEOUSDT','4h','9.208000000000000','12.766000000000000','15.260212720255593','21.156806644959048','1.6572776629295822','1.657277662929582','test'),('2019-05-13 03:59:59','2019-05-17 11:59:59','NEOUSDT','4h','9.364000000000001','10.747999999999999','16.070151995265171','18.445321833095903','1.7161631776233628','1.716163177623363','test'),('2019-05-19 23:59:59','2019-05-20 11:59:59','NEOUSDT','4h','11.654999999999999','11.052000000000000','16.663944454722852','15.801794432741053','1.4297678639830849','1.429767863983085','test'),('2019-05-20 15:59:59','2019-05-22 23:59:59','NEOUSDT','4h','12.199999999999999','11.154000000000000','16.663944454722852','15.235216102293336','1.365897086452693','1.365897086452693','test'),('2019-05-27 03:59:59','2019-05-30 23:59:59','NEOUSDT','4h','12.039000000000000','12.574999999999999','16.663944454722852','17.405856094205486','1.3841635064974542','1.384163506497454','test'),('2019-05-31 23:59:59','2019-06-03 07:59:59','NEOUSDT','4h','13.542999999999999','13.190000000000000','16.663944454722852','16.229596644598274','1.2304470541772763','1.230447054177276','test'),('2019-06-12 15:59:59','2019-06-18 07:59:59','NEOUSDT','4h','12.875999999999999','13.465000000000000','16.663944454722852','17.426220261171419','1.2941864286053784','1.294186428605378','test'),('2019-06-21 19:59:59','2019-06-27 15:59:59','NEOUSDT','4h','13.887000000000000','17.695000000000000','16.663944454722852','21.233419538152294','1.1999671962787393','1.199967196278739','test'),('2019-06-29 23:59:59','2019-06-30 07:59:59','NEOUSDT','4h','18.434000000000001','17.803000000000001','17.501053540929043','16.901988509773233','0.9493899067445504','0.949389906744550','test'),('2019-07-03 23:59:59','2019-07-04 23:59:59','NEOUSDT','4h','17.904000000000000','17.010999999999999','17.501053540929043','16.628151350801158','0.977494053894607','0.977494053894607','test'),('2019-07-09 03:59:59','2019-07-09 11:59:59','NEOUSDT','4h','17.907000000000000','17.366000000000000','17.501053540929043','16.972317852894051','0.9773302921164373','0.977330292116437','test'),('2019-07-09 19:59:59','2019-07-09 23:59:59','NEOUSDT','4h','17.311000000000000','17.245000000000001','17.501053540929043','17.434328941905225','1.0109787730881545','1.010978773088155','test'),('2019-07-10 07:59:59','2019-07-10 11:59:59','NEOUSDT','4h','17.251999999999999','17.247000000000000','17.501053540929043','17.495981359865709','1.0144362126668818','1.014436212666882','test'),('2019-08-03 23:59:59','2019-08-04 23:59:59','NEOUSDT','4h','12.121000000000000','11.880000000000001','17.501053540929043','17.153082754412758','1.4438621847148785','1.443862184714878','test'),('2019-08-05 03:59:59','2019-08-06 03:59:59','NEOUSDT','4h','12.279000000000000','11.813000000000001','17.501053540929043','16.836871526915449','1.4252832918746676','1.425283291874668','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','NEOUSDT','4h','12.113000000000000','11.740000000000000','17.501053540929043','16.962137255057126','1.4448157798174723','1.444815779817472','test'),('2019-09-08 23:59:59','2019-09-09 03:59:59','NEOUSDT','4h','9.262000000000000','8.981000000000000','17.501053540929043','16.970088733651881','1.889554474295945','1.889554474295945','test'),('2019-09-15 11:59:59','2019-09-16 15:59:59','NEOUSDT','4h','9.103000000000000','8.903000000000000','17.501053540929043','17.116541763692329','1.9225588861835705','1.922558886183571','test'),('2019-09-17 03:59:59','2019-09-20 15:59:59','NEOUSDT','4h','9.125999999999999','9.496000000000000','17.501053540929043','18.210607541602258','1.9177135153330094','1.917713515333009','test'),('2019-10-09 19:59:59','2019-10-10 11:59:59','NEOUSDT','4h','7.682000000000000','7.514000000000000','17.501053540929043','17.118317665522106','2.2781897345650926','2.278189734565093','test'),('2019-10-22 03:59:59','2019-10-22 23:59:59','NEOUSDT','4h','7.457000000000000','7.264000000000000','17.501053540929043','17.048096140714573','2.346929534790002','2.346929534790002','test'),('2019-10-26 03:59:59','2019-10-30 11:59:59','NEOUSDT','4h','8.653000000000000','10.436999999999999','17.501053540929043','21.109267977195930','2.0225417243648494','2.022541724364849','test'),('2019-10-30 19:59:59','2019-10-31 11:59:59','NEOUSDT','4h','11.244999999999999','10.464000000000000','17.501053540929043','16.285551289664877','1.5563409107095636','1.556340910709564','test'),('2019-11-02 03:59:59','2019-11-06 19:59:59','NEOUSDT','4h','10.940000000000000','10.984000000000000','17.501053540929043','17.571441690453803','1.59973067101728','1.599730671017280','test'),('2019-11-11 15:59:59','2019-11-15 15:59:59','NEOUSDT','4h','11.146000000000001','11.888000000000000','17.501053540929043','18.666115601522023','1.5701645021468726','1.570164502146873','test'),('2019-12-22 19:59:59','2019-12-23 19:59:59','NEOUSDT','4h','8.789000000000000','8.686000000000000','17.501053540929043','17.295955291444951','1.99124514062226','1.991245140622260','test'),('2019-12-28 03:59:59','2019-12-31 11:59:59','NEOUSDT','4h','8.779000000000000','8.891999999999999','17.501053540929043','17.726320547436046','1.993513331920383','1.993513331920383','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:18:01
