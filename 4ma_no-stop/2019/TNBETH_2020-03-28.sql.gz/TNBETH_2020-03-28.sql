-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','TNBETH','4h','0.000022750000000','0.000022090000000','0.072144500000000','0.070051516703297','3171.186813186813','3171.186813186813197','test'),('2019-01-16 07:59:59','2019-01-18 11:59:59','TNBETH','4h','0.000023320000000','0.000024740000000','0.072144500000000','0.076537518439108','3093.674957118353','3093.674957118353177','test'),('2019-01-18 15:59:59','2019-01-20 19:59:59','TNBETH','4h','0.000024860000000','0.000024220000000','0.072719508785601','0.070847405582754','2925.1612544489644','2925.161254448964428','test'),('2019-01-22 19:59:59','2019-01-23 23:59:59','TNBETH','4h','0.000025430000000','0.000024970000000','0.072719508785601','0.071404094942055','2859.5953120566655','2859.595312056665534','test'),('2019-01-24 03:59:59','2019-01-27 15:59:59','TNBETH','4h','0.000025130000000','0.000025200000000','0.072719508785601','0.072922070091410','2893.7329401353363','2893.732940135336321','test'),('2019-01-27 19:59:59','2019-01-28 11:59:59','TNBETH','4h','0.000026680000000','0.000026020000000','0.072719508785601','0.070920600397352','2725.618770075','2725.618770075000157','test'),('2019-01-28 19:59:59','2019-01-28 23:59:59','TNBETH','4h','0.000026080000000','0.000025730000000','0.072719508785601','0.071743595132420','2788.3247233742713','2788.324723374271343','test'),('2019-01-29 19:59:59','2019-01-30 23:59:59','TNBETH','4h','0.000026890000000','0.000026400000000','0.072719508785601','0.071394385717362','2704.3327923243214','2704.332792324321417','test'),('2019-03-03 11:59:59','2019-03-06 15:59:59','TNBETH','4h','0.000020070000000','0.000021920000000','0.072719508785601','0.079422602520198','3623.293910592975','3623.293910592974953','test'),('2019-03-09 11:59:59','2019-03-14 11:59:59','TNBETH','4h','0.000022500000000','0.000023770000000','0.072719508785601','0.076824121059277','3231.9781682489333','3231.978168248933343','test'),('2019-03-14 15:59:59','2019-03-14 19:59:59','TNBETH','4h','0.000024080000000','0.000024020000000','0.073650210075106','0.073466696262627','3058.56354132501','3058.563541325010192','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','TNBETH','4h','0.000023930000000','0.000023320000000','0.073650210075106','0.071772791431319','3077.7354816174675','3077.735481617467485','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','TNBETH','4h','0.000023440000000','0.000023640000000','0.073650210075106','0.074278624836839','3142.0738086649317','3142.073808664931676','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','TNBETH','4h','0.000023320000000','0.000023370000000','0.073650210075106','0.073808122189332','3158.242284524271','3158.242284524270872','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','TNBETH','4h','0.000023460000000','0.000023310000000','0.073650210075106','0.073179300803526','3139.3951438664108','3139.395143866410763','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','TNBETH','4h','0.000023600000000','0.000023420000000','0.073650210075106','0.073088471184703','3120.771613351949','3120.771613351948872','test'),('2019-03-23 07:59:59','2019-03-23 11:59:59','TNBETH','4h','0.000023430000000','0.000023600000000','0.073650210075106','0.074184590600619','3143.414855958429','3143.414855958429143','test'),('2019-03-23 15:59:59','2019-03-24 15:59:59','TNBETH','4h','0.000023610000000','0.000023830000000','0.073650210075106','0.074336489033874','3119.449812583905','3119.449812583904986','test'),('2019-03-24 19:59:59','2019-03-26 15:59:59','TNBETH','4h','0.000024100000000','0.000024060000000','0.073650210075106','0.073527969062533','3056.025314319751','3056.025314319751033','test'),('2019-03-26 19:59:59','2019-03-30 11:59:59','TNBETH','4h','0.000024390000000','0.000027470000000','0.073650210075106','0.082950851609806','3019.6888099674456','3019.688809967445650','test'),('2019-03-31 03:59:59','2019-04-03 03:59:59','TNBETH','4h','0.000028120000000','0.000026930000000','0.075673161641136','0.072470776777944','2691.079716967843','2691.079716967843069','test'),('2019-04-06 15:59:59','2019-04-09 23:59:59','TNBETH','4h','0.000030450000000','0.000035460000000','0.075673161641136','0.088123819763372','2485.1613018435464','2485.161301843546426','test'),('2019-04-13 07:59:59','2019-04-14 07:59:59','TNBETH','4h','0.000038340000000','0.000034850000000','0.077985229955897','0.070886417943740','2034.0435564918296','2034.043556491829577','test'),('2019-04-14 11:59:59','2019-04-14 23:59:59','TNBETH','4h','0.000035400000000','0.000033660000000','0.077985229955897','0.074152057636031','2202.9725976242094','2202.972597624209357','test'),('2019-04-18 19:59:59','2019-04-18 23:59:59','TNBETH','4h','0.000033970000000','0.000034080000000','0.077985229955897','0.078237757930438','2295.708859461201','2295.708859461200973','test'),('2019-04-21 07:59:59','2019-04-23 19:59:59','TNBETH','4h','0.000035670000000','0.000034920000000','0.077985229955897','0.076345506870197','2186.29744760014','2186.297447600140003','test'),('2019-06-08 07:59:59','2019-06-10 11:59:59','TNBETH','4h','0.000020040000000','0.000020340000000','0.077985229955897','0.079152673518111','3891.478540713423','3891.478540713423172','test'),('2019-06-10 15:59:59','2019-06-11 11:59:59','TNBETH','4h','0.000020810000000','0.000020390000000','0.077985229955897','0.076411284901525','3747.4882246947145','3747.488224694714518','test'),('2019-06-16 07:59:59','2019-06-17 03:59:59','TNBETH','4h','0.000024460000000','0.000020740000000','0.077985229955897','0.066124843388606','3188.2759589491825','3188.275958949182495','test'),('2019-06-17 11:59:59','2019-06-17 19:59:59','TNBETH','4h','0.000021770000000','0.000020710000000','0.077985229955897','0.074188062121572','3582.2338059667895','3582.233805966789532','test'),('2019-06-17 23:59:59','2019-06-18 07:59:59','TNBETH','4h','0.000020780000000','0.000020370000000','0.077985229955897','0.076446541588143','3752.8984579353705','3752.898457935370516','test'),('2019-06-18 11:59:59','2019-06-18 15:59:59','TNBETH','4h','0.000021080000000','0.000020210000000','0.077985229955897','0.074766674450127','3699.489087091888','3699.489087091887995','test'),('2019-06-25 03:59:59','2019-06-25 11:59:59','TNBETH','4h','0.000022930000000','0.000021050000000','0.077985229955897','0.071591325362915','3401.0130813736155','3401.013081373615478','test'),('2019-06-26 07:59:59','2019-06-26 15:59:59','TNBETH','4h','0.000020610000000','0.000019880000000','0.077985229955897','0.075223016570754','3783.8539522511887','3783.853952251188730','test'),('2019-06-30 07:59:59','2019-06-30 19:59:59','TNBETH','4h','0.000019960000000','0.000021550000000','0.077985229955897','0.084197480237955','3907.0756490930366','3907.075649093036645','test'),('2019-06-30 23:59:59','2019-07-01 19:59:59','TNBETH','4h','0.000023560000000','0.000019900000000','0.077985229955897','0.065870376745431','3310.0691831874788','3310.069183187478757','test'),('2019-07-02 03:59:59','2019-07-02 07:59:59','TNBETH','4h','0.000020280000000','0.000019750000000','0.077985229955897','0.075947154419574','3845.425540231608','3845.425540231608011','test'),('2019-07-14 07:59:59','2019-07-14 15:59:59','TNBETH','4h','0.000020490000000','0.000019140000000','0.077985229955897','0.072847110851921','3806.0141510930703','3806.014151093070268','test'),('2019-07-14 19:59:59','2019-07-15 03:59:59','TNBETH','4h','0.000020300000000','0.000019700000000','0.077985229955897','0.075680247789713','3841.6369436402465','3841.636943640246500','test'),('2019-07-15 11:59:59','2019-07-15 15:59:59','TNBETH','4h','0.000019460000000','0.000019890000000','0.077985229955897','0.079708439045364','4007.462998761408','4007.462998761408016','test'),('2019-08-15 23:59:59','2019-08-16 07:59:59','TNBETH','4h','0.000015840000000','0.000015540000000','0.077985229955897','0.076508236964308','4923.309971963195','4923.309971963194585','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','TNBETH','4h','0.000015660000000','0.000015840000000','0.077985229955897','0.078881611909413','4979.899741755876','4979.899741755875766','test'),('2019-08-16 23:59:59','2019-08-17 03:59:59','TNBETH','4h','0.000015920000000','0.000015850000000','0.077985229955897','0.077642330075438','4898.569720847801','4898.569720847801364','test'),('2019-08-17 07:59:59','2019-08-17 15:59:59','TNBETH','4h','0.000015890000000','0.000015840000000','0.077985229955897','0.077739839049805','4907.818121831152','4907.818121831151984','test'),('2019-08-17 19:59:59','2019-08-18 11:59:59','TNBETH','4h','0.000015980000000','0.000015930000000','0.077985229955897','0.077741221101216','4880.177093610576','4880.177093610575866','test'),('2019-08-22 19:59:59','2019-08-23 15:59:59','TNBETH','4h','0.000016320000000','0.000015510000000','0.077985229955897','0.074114639498527','4778.506737493689','4778.506737493688888','test'),('2019-08-24 07:59:59','2019-08-28 03:59:59','TNBETH','4h','0.000016880000000','0.000018140000000','0.077985229955897','0.083806402334122','4619.978077955983','4619.978077955983281','test'),('2019-09-05 11:59:59','2019-09-08 03:59:59','TNBETH','4h','0.000019070000000','0.000017700000000','0.077985229955897','0.072382725234367','4089.4195047664925','4089.419504766492537','test'),('2019-09-09 19:59:59','2019-09-10 19:59:59','TNBETH','4h','0.000019990000000','0.000018140000000','0.077985229955897','0.070767987563780','3901.2121038467735','3901.212103846773516','test'),('2019-09-11 03:59:59','2019-09-11 15:59:59','TNBETH','4h','0.000018500000000','0.000018770000000','0.077985229955897','0.079123392771470','4215.417835453893','4215.417835453892621','test'),('2019-09-11 19:59:59','2019-09-13 03:59:59','TNBETH','4h','0.000021000000000','0.000018610000000','0.077985229955897','0.069109768070440','3713.5823788522384','3713.582378852238435','test'),('2019-09-13 15:59:59','2019-09-14 15:59:59','TNBETH','4h','0.000020340000000','0.000019140000000','0.077985229955897','0.073384331433425','3834.0821020598332','3834.082102059833232','test'),('2019-09-22 15:59:59','2019-09-22 23:59:59','TNBETH','4h','0.000019090000000','0.000017010000000','0.051990153303931','0.046325432566782','2723.4234313217044','2723.423431321704356','test'),('2019-10-09 03:59:59','2019-10-09 15:59:59','TNBETH','4h','0.000016810000000','0.000015740000000','0.056424689446989','0.052833111950958','3356.6144822718006','3356.614482271800625','test'),('2019-11-07 07:59:59','2019-11-08 15:59:59','TNBETH','4h','0.000015180000000','0.000014520000000','0.056424689446989','0.053971442079729','3717.041465546047','3717.041465546047220','test'),('2019-11-16 23:59:59','2019-11-18 15:59:59','TNBETH','4h','0.000015370000000','0.000014500000000','0.056424689446989','0.053230839100933','3671.092351788484','3671.092351788483938','test'),('2019-11-22 15:59:59','2019-11-25 03:59:59','TNBETH','4h','0.000015470000000','0.000014690000000','0.056424689446989','0.053579747121931','3647.361955202909','3647.361955202909030','test'),('2019-11-26 15:59:59','2019-11-26 19:59:59','TNBETH','4h','0.000015400000000','0.000014940000000','0.056424689446989','0.054739276645326','3663.9408731811036','3663.940873181103598','test'),('2019-12-08 11:59:59','2019-12-08 19:59:59','TNBETH','4h','0.000014970000000','0.000014450000000','0.056424689446989','0.054464713594455','3769.1843317961925','3769.184331796192510','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','TNBETH','4h','0.000014660000000','0.000014440000000','0.056424689446989','0.055577934216543','3848.88741111794','3848.887411117939791','test'),('2019-12-22 15:59:59','2019-12-22 19:59:59','TNBETH','4h','0.000013480000000','0.000013280000000','0.056424689446989','0.055587527882494','4185.807822476929','4185.807822476928777','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 22:42:42
