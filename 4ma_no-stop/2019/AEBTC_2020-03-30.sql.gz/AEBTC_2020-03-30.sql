-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 19:59:59','2019-01-18 15:59:59','AEBTC','4h','0.000113600000000','0.000116900000000','0.001467500000000','0.001510129841549','12.918133802816902','12.918133802816902','test'),('2019-02-16 03:59:59','2019-02-18 11:59:59','AEBTC','4h','0.000112800000000','0.000111300000000','0.001478157460387','0.001458501111180','13.104232804851506','13.104232804851506','test'),('2019-02-18 15:59:59','2019-02-19 07:59:59','AEBTC','4h','0.000112200000000','0.000114600000000','0.001478157460387','0.001509775801786','13.174308916105169','13.174308916105169','test'),('2019-02-23 03:59:59','2019-02-24 15:59:59','AEBTC','4h','0.000115300000000','0.000111700000000','0.001481147958435','0.001434902228597','12.84603606622073','12.846036066220730','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','AEBTC','4h','0.000113300000000','0.000111800000000','0.001481147958435','0.001461538762163','13.07279751487202','13.072797514872020','test'),('2019-02-25 03:59:59','2019-02-25 07:59:59','AEBTC','4h','0.000112700000000','0.000110600000000','0.001481147958435','0.001453548928154','13.142395372094054','13.142395372094054','test'),('2019-02-27 07:59:59','2019-03-02 07:59:59','AEBTC','4h','0.000114800000000','0.000115100000000','0.001481147958435','0.001485018554145','12.90198570065331','12.901985700653309','test'),('2019-03-13 15:59:59','2019-03-13 23:59:59','AEBTC','4h','0.000113800000000','0.000112600000000','0.001481147958435','0.001465529526536','13.015359915949032','13.015359915949032','test'),('2019-03-14 03:59:59','2019-03-14 07:59:59','AEBTC','4h','0.000113000000000','0.000112000000000','0.001481147958435','0.001468040454378','13.107504056946903','13.107504056946903','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AEBTC','4h','0.000113400000000','0.000117500000000','0.001481147958435','0.001534699163281','13.061269474735449','13.061269474735449','test'),('2019-03-14 19:59:59','2019-03-16 15:59:59','AEBTC','4h','0.000118900000000','0.000116400000000','0.001481147958435','0.001450005234330','12.457089642010091','12.457089642010091','test'),('2019-03-16 19:59:59','2019-03-17 07:59:59','AEBTC','4h','0.000117900000000','0.000115800000000','0.001481147958435','0.001454766188183','12.562747739058523','12.562747739058523','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','AEBTC','4h','0.000116600000000','0.000116300000000','0.001481147958435','0.001477337114631','12.702812679545454','12.702812679545454','test'),('2019-03-21 23:59:59','2019-03-24 23:59:59','AEBTC','4h','0.000117400000000','0.000118900000000','0.001481147958435','0.001500072336098','12.616251775425894','12.616251775425894','test'),('2019-03-28 07:59:59','2019-03-28 11:59:59','AEBTC','4h','0.000118800000000','0.000116200000000','0.001481147958435','0.001448732262375','12.46757540770202','12.467575407702020','test'),('2019-03-28 15:59:59','2019-03-28 23:59:59','AEBTC','4h','0.000117500000000','0.000117100000000','0.001481147958435','0.001476105752619','12.60551453987234','12.605514539872340','test'),('2019-03-30 03:59:59','2019-03-30 07:59:59','AEBTC','4h','0.000118200000000','0.000117900000000','0.001481147958435','0.001477388699657','12.53086259251269','12.530862592512690','test'),('2019-03-30 11:59:59','2019-04-02 07:59:59','AEBTC','4h','0.000119800000000','0.000118900000000','0.001481147958435','0.001470020803488','12.363505496118531','12.363505496118531','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','AEBTC','4h','0.000130200000000','0.000127300000000','0.001481147958435','0.001448157719729','11.375944381221197','11.375944381221197','test'),('2019-04-04 07:59:59','2019-04-04 11:59:59','AEBTC','4h','0.000128300000000','0.000128800000000','0.001481147958435','0.001486920164041','11.544411211496492','11.544411211496492','test'),('2019-04-04 23:59:59','2019-04-07 19:59:59','AEBTC','4h','0.000126100000000','0.000131500000000','0.001481147958435','0.001544575388852','11.745820447541632','11.745820447541632','test'),('2019-05-22 23:59:59','2019-05-23 07:59:59','AEBTC','4h','0.000073800000000','0.000068000000000','0.001481147958435','0.001364743376336','20.069755534349593','20.069755534349593','test'),('2019-05-23 11:59:59','2019-05-23 15:59:59','AEBTC','4h','0.000069300000000','0.000069700000000','0.001481147958435','0.001489697153000','21.37298641320346','21.372986413203460','test'),('2019-05-24 07:59:59','2019-05-24 19:59:59','AEBTC','4h','0.000071900000000','0.000069000000000','0.001481147958435','0.001421407637441','20.600110687552156','20.600110687552156','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','AEBTC','4h','0.000070500000000','0.000066300000000','0.001481147958435','0.001392909356656','21.00919089978723','21.009190899787232','test'),('2019-06-10 19:59:59','2019-06-11 11:59:59','AEBTC','4h','0.000065900000000','0.000064100000000','0.001481147958435','0.001440691716778','22.47568980933232','22.475689809332319','test'),('2019-06-11 15:59:59','2019-06-11 19:59:59','AEBTC','4h','0.000064200000000','0.000064300000000','0.001481147958435','0.001483455042482','23.07084047406542','23.070840474065420','test'),('2019-06-11 23:59:59','2019-06-12 03:59:59','AEBTC','4h','0.000064400000000','0.000063700000000','0.001481147958435','0.001465048524104','22.999191901164597','22.999191901164597','test'),('2019-07-26 19:59:59','2019-07-27 03:59:59','AEBTC','4h','0.000031200000000','0.000030800000000','0.001481147958435','0.001462158882045','47.472690975480766','47.472690975480766','test'),('2019-07-27 11:59:59','2019-07-30 15:59:59','AEBTC','4h','0.000031100000000','0.000031200000000','0.001481147958435','0.001485910492063','47.6253362840836','47.625336284083602','test'),('2019-07-30 19:59:59','2019-07-31 15:59:59','AEBTC','4h','0.000031600000000','0.000031000000000','0.001481147958435','0.001453024895933','46.871770836550624','46.871770836550624','test'),('2019-08-24 11:59:59','2019-08-26 03:59:59','AEBTC','4h','0.000024000000000','0.000024000000000','0.001481147958435','0.001481147958435','61.714498268125','61.714498268124999','test'),('2019-08-28 03:59:59','2019-08-28 07:59:59','AEBTC','4h','0.000024000000000','0.000023700000000','0.001481147958435','0.001462633608955','61.714498268125','61.714498268124999','test'),('2019-08-28 23:59:59','2019-08-29 03:59:59','AEBTC','4h','0.000024300000000','0.000023800000000','0.001481147958435','0.001450671662994','60.95259088209876','60.952590882098761','test'),('2019-09-17 15:59:59','2019-09-22 03:59:59','AEBTC','4h','0.000020600000000','0.000021100000000','0.001481147958435','0.001517098151601','71.90038633179611','71.900386331796113','test'),('2019-10-05 07:59:59','2019-10-09 15:59:59','AEBTC','4h','0.000019760000000','0.000020480000000','0.001481147958435','0.001535116912386','74.95688048760121','74.956880487601211','test'),('2019-10-10 19:59:59','2019-10-11 07:59:59','AEBTC','4h','0.000021850000000','0.000020820000000','0.001481147958435','0.001411327253758','67.78709191922196','67.787091919221965','test'),('2019-10-11 23:59:59','2019-10-12 07:59:59','AEBTC','4h','0.000021190000000','0.000020880000000','0.001481147958435','0.001459479441818','69.89844070009438','69.898440700094383','test'),('2019-10-13 03:59:59','2019-10-16 15:59:59','AEBTC','4h','0.000021190000000','0.000022560000000','0.001481147958435','0.001576908822194','69.89844070009438','69.898440700094383','test'),('2019-10-16 23:59:59','2019-10-17 03:59:59','AEBTC','4h','0.000022970000000','0.000022650000000','0.001481147958435','0.001460513768331','64.481844076404','64.481844076404002','test'),('2019-10-17 11:59:59','2019-10-19 03:59:59','AEBTC','4h','0.000023370000000','0.000022750000000','0.001481147958435','0.001441853489705','63.378175371630284','63.378175371630284','test'),('2019-10-22 23:59:59','2019-10-26 03:59:59','AEBTC','4h','0.000023210000000','0.000022610000000','0.001481147958435','0.001442858911685','63.81507791619991','63.815077916199911','test'),('2019-10-28 23:59:59','2019-10-29 07:59:59','AEBTC','4h','0.000024610000000','0.000024400000000','0.001481147958435','0.001468509150175','60.1848012366924','60.184801236692401','test'),('2019-10-29 23:59:59','2019-10-30 07:59:59','AEBTC','4h','0.000023990000000','0.000023500000000','0.001481147958435','0.001450895248988','61.740223361192164','61.740223361192164','test'),('2019-11-02 03:59:59','2019-11-02 15:59:59','AEBTC','4h','0.000024100000000','0.000024140000000','0.001481147958435','0.001483606295295','61.458421511825726','61.458421511825726','test'),('2019-11-02 19:59:59','2019-11-03 07:59:59','AEBTC','4h','0.000024240000000','0.000023920000000','0.001481147958435','0.001461594850073','61.10346363180693','61.103463631806932','test'),('2019-11-03 19:59:59','2019-11-03 23:59:59','AEBTC','4h','0.000023900000000','0.000023910000000','0.001481147958435','0.001481767685614','61.97271792615062','61.972717926150622','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','AEBTC','4h','0.000024090000000','0.000028540000000','0.001481147958435','0.001754751462588','61.483933517434615','61.483933517434615','test'),('2019-11-05 07:59:59','2019-11-08 07:59:59','AEBTC','4h','0.000026000000000','0.000025660000000','0.001481147958435','0.001461779100517','56.96722917057692','56.967229170576921','test'),('2019-11-09 15:59:59','2019-11-10 23:59:59','AEBTC','4h','0.000026240000000','0.000025500000000','0.001481147958435','0.001439377779729','56.44618744035823','56.446187440358230','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','AEBTC','4h','0.000025990000000','0.000025800000000','0.001481147958435','0.001470320020301','56.98914807368218','56.989148073682180','test'),('2019-11-11 19:59:59','2019-11-15 15:59:59','AEBTC','4h','0.000026950000000','0.000025980000000','0.001481147958435','0.001427837623753','54.959107919666046','54.959107919666046','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  9:58:24
