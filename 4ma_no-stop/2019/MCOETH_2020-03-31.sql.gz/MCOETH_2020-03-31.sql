-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 11:59:59','2019-01-10 19:59:59','MCOETH','4h','0.017415000000000','0.017081000000000','0.072144500000000','0.070760850100488','4.142664369796153','4.142664369796153','test'),('2019-01-11 11:59:59','2019-01-14 15:59:59','MCOETH','4h','0.018092000000000','0.017550000000000','0.072144500000000','0.069983195611320','3.9876464735794825','3.987646473579483','test'),('2019-01-16 03:59:59','2019-01-16 15:59:59','MCOETH','4h','0.018607000000000','0.018306000000000','0.072144500000000','0.070977439512012','3.877277368732198','3.877277368732198','test'),('2019-01-17 03:59:59','2019-01-22 15:59:59','MCOETH','4h','0.018184000000000','0.018887000000000','0.072144500000000','0.074933632396612','3.9674714034315883','3.967471403431588','test'),('2019-01-23 19:59:59','2019-01-24 07:59:59','MCOETH','4h','0.019292000000000','0.018816000000000','0.072144500000000','0.070364447024673','3.7396070910221852','3.739607091022185','test'),('2019-01-24 11:59:59','2019-01-28 03:59:59','MCOETH','4h','0.019006000000000','0.018618000000000','0.072144500000000','0.070671698463643','3.795880248342629','3.795880248342629','test'),('2019-02-15 07:59:59','2019-02-17 23:59:59','MCOETH','4h','0.021744000000000','0.019622000000000','0.072144500000000','0.065103908158572','3.3179037895511407','3.317903789551141','test'),('2019-02-20 15:59:59','2019-02-22 19:59:59','MCOETH','4h','0.021769000000000','0.020457000000000','0.072144500000000','0.067796409412467','3.314093435619459','3.314093435619459','test'),('2019-02-26 23:59:59','2019-02-27 07:59:59','MCOETH','4h','0.020386000000000','0.019797000000000','0.072144500000000','0.070060073898754','3.53892377121554','3.538923771215540','test'),('2019-02-27 11:59:59','2019-02-28 03:59:59','MCOETH','4h','0.020055000000000','0.020022000000000','0.072144500000000','0.072025788032910','3.5973323360757914','3.597332336075791','test'),('2019-03-09 19:59:59','2019-03-16 23:59:59','MCOETH','4h','0.020719000000000','0.023073000000000','0.072144500000000','0.080341235025822','3.482045465514745','3.482045465514745','test'),('2019-03-17 03:59:59','2019-03-17 07:59:59','MCOETH','4h','0.023369000000000','0.023222000000000','0.072144500000000','0.071690683341178','3.087188155248406','3.087188155248406','test'),('2019-03-17 11:59:59','2019-03-21 15:59:59','MCOETH','4h','0.023551000000000','0.023714000000000','0.072144500000000','0.072643822894994','3.063330644134007','3.063330644134007','test'),('2019-03-26 15:59:59','2019-03-30 03:59:59','MCOETH','4h','0.024055000000000','0.023988000000000','0.072144500000000','0.071943557098316','2.9991477863230096','2.999147786323010','test'),('2019-03-31 19:59:59','2019-04-02 03:59:59','MCOETH','4h','0.025554000000000','0.024362000000000','0.072144500000000','0.068779224739767','2.823217500195664','2.823217500195664','test'),('2019-04-11 23:59:59','2019-04-23 11:59:59','MCOETH','4h','0.024289000000000','0.028813000000000','0.072144500000000','0.085581929206637','2.9702540244555147','2.970254024455515','test'),('2019-04-25 15:59:59','2019-04-28 19:59:59','MCOETH','4h','0.030135000000000','0.028721000000000','0.072144500000000','0.068759322531940','2.3940434710469556','2.394043471046956','test'),('2019-04-30 03:59:59','2019-05-02 11:59:59','MCOETH','4h','0.029798000000000','0.029424000000000','0.072144500000000','0.071239001543728','2.4211188670380563','2.421118867038056','test'),('2019-05-04 19:59:59','2019-05-06 07:59:59','MCOETH','4h','0.030457000000000','0.029736000000000','0.072144500000000','0.070436643530223','2.3687329677906557','2.368732967790656','test'),('2019-05-26 15:59:59','2019-05-30 03:59:59','MCOETH','4h','0.022336000000000','0.023611000000000','0.072144500000000','0.076262705475466','3.2299650787965613','3.229965078796561','test'),('2019-05-31 03:59:59','2019-06-01 07:59:59','MCOETH','4h','0.025118000000000','0.024363000000000','0.072144500000000','0.069975971554264','2.8722231069352655','2.872223106935266','test'),('2019-06-02 11:59:59','2019-06-03 11:59:59','MCOETH','4h','0.025001000000000','0.024657000000000','0.072144500000000','0.071151831386745','2.8856645734170634','2.885664573417063','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','MCOETH','4h','0.024720000000000','0.024476000000000','0.072144500000000','0.071432394093851','2.9184668284789645','2.918466828478965','test'),('2019-06-08 15:59:59','2019-06-12 23:59:59','MCOETH','4h','0.024981000000000','0.025239000000000','0.072144500000000','0.072889597514111','2.8879748608942797','2.887974860894280','test'),('2019-07-02 23:59:59','2019-07-03 03:59:59','MCOETH','4h','0.021039000000000','0.020388000000000','0.072144500000000','0.069912166262655','3.4290840819430586','3.429084081943059','test'),('2019-07-06 07:59:59','2019-07-06 15:59:59','MCOETH','4h','0.021485000000000','0.020500000000000','0.072144500000000','0.068836967651850','3.35790086106586','3.357900861065860','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','MCOETH','4h','0.020574000000000','0.020832000000000','0.072144500000000','0.073049199183435','3.5065859823077674','3.506585982307767','test'),('2019-07-07 07:59:59','2019-07-07 11:59:59','MCOETH','4h','0.020986000000000','0.020719000000000','0.072144500000000','0.071226622295816','3.4377442104259983','3.437744210425998','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','MCOETH','4h','0.020885000000000','0.019905000000000','0.072144500000000','0.068759218218817','3.454369164472109','3.454369164472109','test'),('2019-07-13 03:59:59','2019-07-16 19:59:59','MCOETH','4h','0.020601000000000','0.020795000000000','0.072144500000000','0.072823886097762','3.501990194650745','3.501990194650745','test'),('2019-07-17 03:59:59','2019-07-17 15:59:59','MCOETH','4h','0.024511000000000','0.021357000000000','0.072144500000000','0.062861167904206','2.943351964424136','2.943351964424136','test'),('2019-07-24 03:59:59','2019-07-25 03:59:59','MCOETH','4h','0.024535000000000','0.021377000000000','0.072144500000000','0.062858486916650','2.940472793967801','2.940472793967801','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','MCOETH','4h','0.021498000000000','0.021001000000000','0.072144500000000','0.070476632454182','3.3558703135175367','3.355870313517537','test'),('2019-07-30 03:59:59','2019-07-30 07:59:59','MCOETH','4h','0.021810000000000','0.021116000000000','0.072144500000000','0.069848842824392','3.3078633654287026','3.307863365428703','test'),('2019-07-30 11:59:59','2019-07-30 15:59:59','MCOETH','4h','0.021211000000000','0.020920000000000','0.072144500000000','0.071154728207062','3.4012776389609165','3.401277638960917','test'),('2019-08-23 11:59:59','2019-08-25 15:59:59','MCOETH','4h','0.018185000000000','0.018297000000000','0.072144500000000','0.072588832361837','3.9672532306846304','3.967253230684630','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','MCOETH','4h','0.018474000000000','0.018334000000000','0.072144500000000','0.071597773248890','3.905191079354769','3.905191079354769','test'),('2019-08-26 15:59:59','2019-08-29 07:59:59','MCOETH','4h','0.019555000000000','0.018786000000000','0.072144500000000','0.069307418920992','3.6893121963692153','3.689312196369215','test'),('2019-08-30 07:59:59','2019-09-01 23:59:59','MCOETH','4h','0.019141000000000','0.019025000000000','0.072144500000000','0.071707283449141','3.7691081970638947','3.769108197063895','test'),('2019-09-25 23:59:59','2019-09-26 23:59:59','MCOETH','4h','0.017175000000000','0.016486000000000','0.072144500000000','0.069250318893741','4.200553129548763','4.200553129548763','test'),('2019-09-27 03:59:59','2019-09-27 07:59:59','MCOETH','4h','0.016489000000000','0.016570000000000','0.072144500000000','0.072498900175875','4.3753108132694525','4.375310813269452','test'),('2019-09-27 11:59:59','2019-09-27 23:59:59','MCOETH','4h','0.016917000000000','0.016672000000000','0.072144500000000','0.071099669208488','4.2646154755571315','4.264615475557131','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','MCOETH','4h','0.016928000000000','0.016747000000000','0.072144500000000','0.071373106185019','4.2618442816635165','4.261844281663516','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','MCOETH','4h','0.016848000000000','0.016662000000000','0.072144500000000','0.071348032941595','4.2820809591642925','4.282080959164293','test'),('2019-10-06 15:59:59','2019-10-07 19:59:59','MCOETH','4h','0.016821000000000','0.016985000000000','0.072144500000000','0.072847888502467','4.288954283336306','4.288954283336306','test'),('2019-10-08 15:59:59','2019-10-08 19:59:59','MCOETH','4h','0.016697000000000','0.016580000000000','0.072144500000000','0.071638965682458','4.320806132838235','4.320806132838235','test'),('2019-10-08 23:59:59','2019-10-15 03:59:59','MCOETH','4h','0.017141000000000','0.019350000000000','0.072144500000000','0.081441927250452','4.208885129222333','4.208885129222333','test'),('2019-10-15 07:59:59','2019-10-15 15:59:59','MCOETH','4h','0.019655000000000','0.019431000000000','0.072144500000000','0.071322298626304','3.670541846858306','3.670541846858306','test'),('2019-10-16 03:59:59','2019-10-18 03:59:59','MCOETH','4h','0.019996000000000','0.019693000000000','0.072144500000000','0.071051292183437','3.6079465893178635','3.607946589317863','test'),('2019-10-20 23:59:59','2019-10-28 11:59:59','MCOETH','4h','0.020019000000000','0.021819000000000','0.072144500000000','0.078631342499625','3.6038013886807536','3.603801388680754','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','MCOETH','4h','0.022315000000000','0.021881000000000','0.072144500000000','0.070741375957876','3.233004705355142','3.233004705355142','test'),('2019-10-29 11:59:59','2019-11-03 11:59:59','MCOETH','4h','0.022443000000000','0.023121000000000','0.072144500000000','0.074323975604866','3.2145657888874033','3.214565788887403','test'),('2019-11-03 23:59:59','2019-11-04 15:59:59','MCOETH','4h','0.023450000000000','0.022864000000000','0.072144500000000','0.070341656631130','3.0765245202558638','3.076524520255864','test'),('2019-11-07 19:59:59','2019-11-08 11:59:59','MCOETH','4h','0.023291000000000','0.023033000000000','0.072144500000000','0.071345338049032','3.0975269417371516','3.097526941737152','test'),('2019-11-10 23:59:59','2019-11-13 07:59:59','MCOETH','4h','0.023251000000000','0.023271000000000','0.072144500000000','0.072206557115823','3.1028557911487678','3.102855791148768','test'),('2019-11-13 11:59:59','2019-11-14 07:59:59','MCOETH','4h','0.023676000000000','0.022945000000000','0.072144500000000','0.069917027897449','3.0471574590302417','3.047157459030242','test'),('2019-11-15 15:59:59','2019-11-16 11:59:59','MCOETH','4h','0.023555000000000','0.023410000000000','0.072144500000000','0.071700392485672','3.062810443642539','3.062810443642539','test'),('2019-11-17 03:59:59','2019-11-17 11:59:59','MCOETH','4h','0.023462000000000','0.023300000000000','0.072144500000000','0.071646357940500','3.0749509845707954','3.074950984570795','test'),('2019-11-17 15:59:59','2019-11-17 19:59:59','MCOETH','4h','0.023536000000000','0.023383000000000','0.072144500000000','0.071675511705472','3.065282970768185','3.065282970768185','test'),('2019-11-17 23:59:59','2019-11-18 15:59:59','MCOETH','4h','0.023544000000000','0.023362000000000','0.072144500000000','0.071586808061502','3.064241420319402','3.064241420319402','test'),('2019-11-19 03:59:59','2019-11-19 07:59:59','MCOETH','4h','0.024017000000000','0.023950000000000','0.072144500000000','0.071943239163926','3.003893075738019','3.003893075738019','test'),('2019-11-19 15:59:59','2019-11-25 23:59:59','MCOETH','4h','0.024225000000000','0.025814000000000','0.072144500000000','0.076876702703818','2.9781011351909186','2.978101135190919','test'),('2019-11-27 11:59:59','2019-11-27 15:59:59','MCOETH','4h','0.026158000000000','0.025852000000000','0.072144500000000','0.071300543390167','2.7580281367076993','2.758028136707699','test'),('2019-11-27 23:59:59','2019-12-01 07:59:59','MCOETH','4h','0.026272000000000','0.026421000000000','0.072144500000000','0.072553663006242','2.746060444579781','2.746060444579781','test'),('2019-12-03 23:59:59','2019-12-04 03:59:59','MCOETH','4h','0.026710000000000','0.026738000000000','0.072144500000000','0.072220128828154','2.7010295769374766','2.701029576937477','test'),('2019-12-04 11:59:59','2019-12-15 15:59:59','MCOETH','4h','0.027026000000000','0.029541000000000','0.072144500000000','0.078858161566640','2.6694479390216825','2.669447939021683','test'),('2019-12-16 19:59:59','2019-12-20 11:59:59','MCOETH','4h','0.030593000000000','0.030490000000000','0.072144500000000','0.071901605105743','2.358202856862681','2.358202856862681','test'),('2019-12-21 15:59:59','2019-12-26 19:59:59','MCOETH','4h','0.031046000000000','0.030899000000000','0.072144500000000','0.071802902322360','2.3237937254396703','2.323793725439670','test'),('2019-12-27 19:59:59','2019-12-28 19:59:59','MCOETH','4h','0.031808000000000','0.031328000000000','0.072144500000000','0.071055800301811','2.2681243712273638','2.268124371227364','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  8:12:53
