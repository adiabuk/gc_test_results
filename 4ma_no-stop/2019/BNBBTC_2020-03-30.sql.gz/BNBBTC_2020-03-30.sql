-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-02 07:59:59','BNBBTC','4h','0.001584200000000','0.001563700000000','0.001467500000000','0.001448510131297','0.926335058704709','0.926335058704709','test'),('2019-01-04 15:59:59','2019-01-06 19:59:59','BNBBTC','4h','0.001591300000000','0.001570800000000','0.001467500000000','0.001448594859549','0.9222019732294351','0.922201973229435','test'),('2019-01-06 23:59:59','2019-01-07 03:59:59','BNBBTC','4h','0.001571600000000','0.001559400000000','0.001467500000000','0.001456108106388','0.9337617714431153','0.933761771443115','test'),('2019-01-08 11:59:59','2019-01-10 07:59:59','BNBBTC','4h','0.001623900000000','0.001605100000000','0.001467500000000','0.001450510653365','0.903688650778989','0.903688650778989','test'),('2019-01-10 11:59:59','2019-01-10 15:59:59','BNBBTC','4h','0.001606000000000','0.001607700000000','0.001467500000000','0.001469053393524','0.913760896637609','0.913760896637609','test'),('2019-01-11 11:59:59','2019-01-13 07:59:59','BNBBTC','4h','0.001662800000000','0.001634500000000','0.001467500000000','0.001442523905461','0.882547510223719','0.882547510223719','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BNBBTC','4h','0.001669900000000','0.001624100000000','0.001467500000000','0.001427251182706','0.8787951374333793','0.878795137433379','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','BNBBTC','4h','0.001634200000000','0.001632900000000','0.001467500000000','0.001466332609228','0.8979929017256151','0.897992901725615','test'),('2019-01-16 03:59:59','2019-01-24 19:59:59','BNBBTC','4h','0.001641400000000','0.001805500000000','0.001467500000000','0.001614214237846','0.8940538564639942','0.894053856463994','test'),('2019-01-25 07:59:59','2019-01-28 15:59:59','BNBBTC','4h','0.001826100000000','0.001800900000000','0.001471399769841','0.001451094598054','0.8057607851930343','0.805760785193034','test'),('2019-02-01 19:59:59','2019-02-13 03:59:59','BNBBTC','4h','0.001893000000000','0.002497000000000','0.001471399769841','0.001940879675274','0.7772846116434231','0.777284611643423','test'),('2019-02-15 15:59:59','2019-02-17 03:59:59','BNBBTC','4h','0.002560000000000','0.002474200000000','0.001583693453252','0.001530614977358','0.6186302551767577','0.618630255176758','test'),('2019-02-18 03:59:59','2019-02-18 11:59:59','BNBBTC','4h','0.002526000000000','0.002492200000000','0.001583693453252','0.001562502305699','0.6269570282074426','0.626957028207443','test'),('2019-02-19 15:59:59','2019-02-23 19:59:59','BNBBTC','4h','0.002630500000000','0.002635100000000','0.001583693453252','0.001586462884875','0.602050352880441','0.602050352880441','test'),('2019-02-28 23:59:59','2019-03-10 03:59:59','BNBBTC','4h','0.002695900000000','0.003658200000000','0.001583693453252','0.002148991947285','0.5874451772142882','0.587445177214288','test'),('2019-03-11 15:59:59','2019-03-15 23:59:59','BNBBTC','4h','0.003714200000000','0.003804100000000','0.001707143028805','0.001748463409584','0.4596260375867616','0.459626037586762','test'),('2019-03-16 11:59:59','2019-03-18 11:59:59','BNBBTC','4h','0.003948100000000','0.003844500000000','0.001717473124000','0.001672405821843','0.4350125690837365','0.435012569083736','test'),('2019-03-24 11:59:59','2019-03-29 11:59:59','BNBBTC','4h','0.004268000000000','0.004057500000000','0.001717473124000','0.001632766448133','0.4024070112464854','0.402407011246485','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','BNBBTC','4h','0.004189800000000','0.004032700000000','0.001717473124000','0.001653075055410','0.4099176867630913','0.409917686763091','test'),('2019-04-15 03:59:59','2019-04-17 15:59:59','BNBBTC','4h','0.003799800000000','0.003753500000000','0.001717473124000','0.001696545968455','0.4519904005473972','0.451990400547397','test'),('2019-04-18 07:59:59','2019-04-22 23:59:59','BNBBTC','4h','0.003929900000000','0.004438900000000','0.001717473124000','0.001939919959827','0.43702718237105265','0.437027182371053','test'),('2019-04-26 19:59:59','2019-04-27 11:59:59','BNBBTC','4h','0.004323900000000','0.004248500000000','0.001719310032417','0.001689328770953','0.3976294623873124','0.397629462387312','test'),('2019-04-28 07:59:59','2019-04-29 07:59:59','BNBBTC','4h','0.004332200000000','0.004271900000000','0.001719310032417','0.001695378913135','0.3968676497892526','0.396867649789253','test'),('2019-05-18 03:59:59','2019-05-26 19:59:59','BNBBTC','4h','0.003598300000000','0.003871200000000','0.001719310032417','0.001849704859932','0.47781175344384846','0.477811753443848','test'),('2019-06-06 03:59:59','2019-06-09 23:59:59','BNBBTC','4h','0.003991000000000','0.003948200000000','0.001738430644109','0.001719787489118','0.4355877334273992','0.435587733427399','test'),('2019-06-10 07:59:59','2019-06-14 07:59:59','BNBBTC','4h','0.004022300000000','0.004064800000000','0.001738430644109','0.001756799065752','0.4321981563058449','0.432198156305845','test'),('2019-07-18 07:59:59','2019-07-18 15:59:59','BNBBTC','4h','0.002949900000000','0.002781700000000','0.001738430644109','0.001639307272354','0.5893185003250958','0.589318500325096','test'),('2019-07-19 03:59:59','2019-07-19 07:59:59','BNBBTC','4h','0.002743100000000','0.002800600000000','0.001738430644109','0.001774871080854','0.6337467260067078','0.633746726006708','test'),('2019-07-19 15:59:59','2019-07-19 23:59:59','BNBBTC','4h','0.002788500000000','0.002760600000000','0.001738430644109','0.001721036986239','0.6234285974929173','0.623428597492917','test'),('2019-07-20 03:59:59','2019-07-25 07:59:59','BNBBTC','4h','0.002896800000000','0.002911700000000','0.001738430644109','0.001747372447684','0.6001210453289837','0.600121045328984','test'),('2019-07-26 19:59:59','2019-07-27 03:59:59','BNBBTC','4h','0.002945600000000','0.002890200000000','0.001738430644109','0.001705734739138','0.5901787900967546','0.590178790096755','test'),('2019-08-12 03:59:59','2019-08-16 15:59:59','BNBBTC','4h','0.002661100000000','0.002662600000000','0.001738430644109','0.001739410556914','0.6532752035282402','0.653275203528240','test'),('2019-08-18 23:59:59','2019-08-19 19:59:59','BNBBTC','4h','0.002706300000000','0.002665700000000','0.001738430644109','0.001712350651443','0.6423643513686583','0.642364351368658','test'),('2019-08-22 15:59:59','2019-08-22 19:59:59','BNBBTC','4h','0.002689400000000','0.002662400000000','0.001738430644109','0.001720977819170','0.646400923666617','0.646400923666617','test'),('2019-08-22 23:59:59','2019-08-23 03:59:59','BNBBTC','4h','0.002670000000000','0.002661800000000','0.001738430644109','0.001733091643629','0.6510976195164794','0.651097619516479','test'),('2019-09-18 23:59:59','2019-09-19 23:59:59','BNBBTC','4h','0.002184400000000','0.002101200000000','0.001738430644109','0.001672216841880','0.7958389691031863','0.795838969103186','test'),('2019-09-20 11:59:59','2019-09-20 15:59:59','BNBBTC','4h','0.002106400000000','0.002091600000000','0.001738430644109','0.001726216072550','0.8253088891516331','0.825308889151633','test'),('2019-10-07 19:59:59','2019-10-11 23:59:59','BNBBTC','4h','0.001938300000000','0.002005200000000','0.001738430644109','0.001798432197063','0.8968841996125472','0.896884199612547','test'),('2019-10-12 07:59:59','2019-10-20 07:59:59','BNBBTC','4h','0.002031000000000','0.002250000000000','0.001738430644109','0.001925883283725','0.8559481260999509','0.855948126099951','test'),('2019-10-24 23:59:59','2019-10-25 15:59:59','BNBBTC','4h','0.002284200000000','0.002231500000000','0.001742687765578','0.001702481283989','0.7629313394528717','0.762931339452872','test'),('2019-11-01 03:59:59','2019-11-01 07:59:59','BNBBTC','4h','0.002179900000000','0.002169400000000','0.001742687765578','0.001734293700924','0.7994347289224277','0.799434728922428','test'),('2019-11-01 11:59:59','2019-11-01 15:59:59','BNBBTC','4h','0.002169900000000','0.002172900000000','0.001742687765578','0.001745097122367','0.8031189297101248','0.803118929710125','test'),('2019-11-02 07:59:59','2019-11-02 15:59:59','BNBBTC','4h','0.002180900000000','0.002169400000000','0.001742687765578','0.001733498481657','0.7990681670768949','0.799068167076895','test'),('2019-11-02 19:59:59','2019-11-02 23:59:59','BNBBTC','4h','0.002174300000000','0.002173100000000','0.001742687765578','0.001741725973130','0.801493706286161','0.801493706286161','test'),('2019-11-03 03:59:59','2019-11-03 15:59:59','BNBBTC','4h','0.002183100000000','0.002173300000000','0.001742687765578','0.001734864789030','0.79826291309514','0.798262913095140','test'),('2019-11-03 19:59:59','2019-11-04 23:59:59','BNBBTC','4h','0.002180000000000','0.002195500000000','0.001742687765578','0.001755078435471','0.7993980576045872','0.799398057604587','test'),('2019-11-05 03:59:59','2019-11-07 07:59:59','BNBBTC','4h','0.002201100000000','0.002206600000000','0.001742687765578','0.001747042307721','0.7917349350679206','0.791734935067921','test'),('2019-11-07 23:59:59','2019-11-08 07:59:59','BNBBTC','4h','0.002217300000000','0.002201400000000','0.001742687765578','0.001730191154622','0.7859503745898164','0.785950374589816','test'),('2019-11-08 11:59:59','2019-11-15 19:59:59','BNBBTC','4h','0.002215500000000','0.002375000000000','0.001742687765578','0.001868148699277','0.7865889260112842','0.786588926011284','test'),('2019-12-30 03:59:59','2020-01-01 15:59:59','BNBBTC','4h','0.001943700000000','0.001910800000000','0.001759073838680','0.001729298909785','0.9050130363123166','0.905013036312317','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  5:16:03
