-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-08 11:59:59','STEEMBNB','4h','0.048190000000000','0.047700000000000','0.711908500000000','0.704669754098361','14.772950819672133','14.772950819672133','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','STEEMBNB','4h','0.048290000000000','0.046720000000000','0.711908500000000','0.688762996893767','14.742358666390558','14.742358666390558','test'),('2019-01-16 15:59:59','2019-01-24 07:59:59','STEEMBNB','4h','0.049940000000000','0.058160000000000','0.711908500000000','0.829086871445735','14.25527633159792','14.255276331597919','test'),('2019-02-17 07:59:59','2019-02-17 15:59:59','STEEMBNB','4h','0.036390000000000','0.035390000000000','0.733607030609466','0.713447452961500','20.159577647965534','20.159577647965534','test'),('2019-02-17 23:59:59','2019-02-18 11:59:59','STEEMBNB','4h','0.035340000000000','0.035250000000000','0.733607030609466','0.731738761431343','20.758546423584207','20.758546423584207','test'),('2019-02-18 23:59:59','2019-02-19 03:59:59','STEEMBNB','4h','0.035240000000000','0.034080000000000','0.733607030609466','0.709458785561027','20.817452627964414','20.817452627964414','test'),('2019-02-26 07:59:59','2019-03-01 19:59:59','STEEMBNB','4h','0.036400000000000','0.036030000000000','0.733607030609466','0.726150036067556','20.154039302457857','20.154039302457857','test'),('2019-03-10 11:59:59','2019-03-11 11:59:59','STEEMBNB','4h','0.037570000000000','0.035600000000000','0.733607030609466','0.695140013034256','19.5264048605128','19.526404860512802','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','STEEMBNB','4h','0.036070000000000','0.033540000000000','0.733607030609466','0.682150812493526','20.338426132782534','20.338426132782534','test'),('2019-04-07 23:59:59','2019-04-08 11:59:59','STEEMBNB','4h','0.026590000000000','0.026340000000000','0.733607030609466','0.726709634684217','27.589583700995338','27.589583700995338','test'),('2019-04-08 15:59:59','2019-04-09 11:59:59','STEEMBNB','4h','0.027160000000000','0.026060000000000','0.733607030609466','0.703895405658420','27.010568137314653','27.010568137314653','test'),('2019-05-10 15:59:59','2019-05-11 07:59:59','STEEMBNB','4h','0.015930000000000','0.015810000000000','0.733607030609466','0.728080800623707','46.05191654798907','46.051916547989073','test'),('2019-05-11 11:59:59','2019-05-11 15:59:59','STEEMBNB','4h','0.015900000000000','0.015150000000000','0.733607030609466','0.699002925392038','46.138806956570185','46.138806956570185','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','STEEMBNB','4h','0.015470000000000','0.015570000000000','0.733607030609466','0.738349157504162','47.421268946959664','47.421268946959664','test'),('2019-05-30 15:59:59','2019-05-30 19:59:59','STEEMBNB','4h','0.012790000000000','0.012670000000000','0.733607030609466','0.726724087398118','57.35786009456341','57.357860094563407','test'),('2019-06-09 03:59:59','2019-06-12 03:59:59','STEEMBNB','4h','0.012910000000000','0.012490000000000','0.733607030609466','0.709740651612101','56.82471189848691','56.824711898486910','test'),('2019-06-12 07:59:59','2019-06-12 11:59:59','STEEMBNB','4h','0.012640000000000','0.012740000000000','0.733607030609466','0.739410883699731','58.03853090264762','58.038530902647622','test'),('2019-06-16 15:59:59','2019-06-17 07:59:59','STEEMBNB','4h','0.012840000000000','0.012320000000000','0.733607030609466','0.703897088559861','57.13450394154719','57.134503941547187','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','STEEMBNB','4h','0.012730000000000','0.012260000000000','0.733607030609466','0.706521774962455','57.62820350427855','57.628203504278552','test'),('2019-07-29 15:59:59','2019-07-31 07:59:59','STEEMBNB','4h','0.008680000000000','0.008700000000000','0.733607030609466','0.735297369389672','84.51693901030714','84.516939010307141','test'),('2019-07-31 11:59:59','2019-08-01 03:59:59','STEEMBNB','4h','0.008740000000000','0.008760000000000','0.733607030609466','0.735285765233286','83.93673119101442','83.936731191014417','test'),('2019-08-23 23:59:59','2019-08-27 11:59:59','STEEMBNB','4h','0.006650000000000','0.006950000000000','0.733607030609466','0.766702084621923','110.31684670819038','110.316846708190383','test'),('2019-08-27 19:59:59','2019-08-28 19:59:59','STEEMBNB','4h','0.007160000000000','0.007050000000000','0.733607030609466','0.722336531535857','102.45908248735559','102.459082487355587','test'),('2019-08-29 03:59:59','2019-09-02 15:59:59','STEEMBNB','4h','0.007160000000000','0.007350000000000','0.733607030609466','0.753074256282064','102.45908248735559','102.459082487355587','test'),('2019-09-04 11:59:59','2019-09-05 19:59:59','STEEMBNB','4h','0.007560000000000','0.007690000000000','0.733607030609466','0.746221966321004','97.03796701183413','97.037967011834127','test'),('2019-09-05 23:59:59','2019-09-06 11:59:59','STEEMBNB','4h','0.007700000000000','0.007510000000000','0.733607030609466','0.715505038945077','95.27364033889168','95.273640338891681','test'),('2019-09-10 23:59:59','2019-09-11 03:59:59','STEEMBNB','4h','0.007570000000000','0.007460000000000','0.733607030609466','0.722946954867453','96.90977947284887','96.909779472848868','test'),('2019-09-11 11:59:59','2019-09-11 15:59:59','STEEMBNB','4h','0.007570000000000','0.007440000000000','0.733607030609466','0.721008759277996','96.90977947284887','96.909779472848868','test'),('2019-09-11 19:59:59','2019-09-12 15:59:59','STEEMBNB','4h','0.007610000000000','0.007540000000000','0.733607030609466','0.726859002732638','96.4003982404029','96.400398240402893','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','STEEMBNB','4h','0.007730000000000','0.007500000000000','0.733607030609466','0.711779137072574','94.90388494300983','94.903884943009828','test'),('2019-09-13 03:59:59','2019-09-13 07:59:59','STEEMBNB','4h','0.007680000000000','0.007700000000000','0.733607030609466','0.735517465585012','95.52174877727421','95.521748777274212','test'),('2019-09-13 19:59:59','2019-09-13 23:59:59','STEEMBNB','4h','0.007700000000000','0.007650000000000','0.733607030609466','0.728843348592521','95.27364033889168','95.273640338891681','test'),('2019-09-14 07:59:59','2019-09-14 11:59:59','STEEMBNB','4h','0.007650000000000','0.007490000000000','0.733607030609466','0.718263615590183','95.89634387051844','95.896343870518436','test'),('2019-09-14 15:59:59','2019-09-17 03:59:59','STEEMBNB','4h','0.007760000000000','0.007730000000000','0.733607030609466','0.730770920955048','94.53698848060128','94.536988480601281','test'),('2019-09-19 15:59:59','2019-09-20 11:59:59','STEEMBNB','4h','0.008050000000000','0.007670000000000','0.733607030609466','0.698977133512373','91.13130815024422','91.131308150244223','test'),('2019-09-20 19:59:59','2019-09-21 07:59:59','STEEMBNB','4h','0.007860000000000','0.007710000000000','0.733607030609466','0.719606896437530','93.33422781290915','93.334227812909148','test'),('2019-09-21 11:59:59','2019-09-22 03:59:59','STEEMBNB','4h','0.007810000000000','0.008030000000000','0.733607030609466','0.754272017387197','93.93175808059743','93.931758080597433','test'),('2019-09-22 15:59:59','2019-09-24 19:59:59','STEEMBNB','4h','0.008070000000000','0.007890000000000','0.733607030609466','0.717244048514087','90.90545608543567','90.905456085435674','test'),('2019-09-25 03:59:59','2019-09-29 15:59:59','STEEMBNB','4h','0.008500000000000','0.008400000000000','0.733607030609466','0.724976359661119','86.30670948346658','86.306709483466577','test'),('2019-10-02 03:59:59','2019-10-07 23:59:59','STEEMBNB','4h','0.008660000000000','0.008960000000000','0.733607030609466','0.759020669083235','84.71212824589676','84.712128245896764','test'),('2019-10-08 11:59:59','2019-10-09 07:59:59','STEEMBNB','4h','0.009510000000000','0.008610000000000','0.733607030609466','0.664180497744217','77.14059207249906','77.140592072499061','test'),('2019-11-01 15:59:59','2019-11-03 15:59:59','STEEMBNB','4h','0.007880000000000','0.007510000000000','0.733607030609466','0.699161015212829','93.09733890983071','93.097338909830711','test'),('2019-11-03 19:59:59','2019-11-04 03:59:59','STEEMBNB','4h','0.007630000000000','0.007250000000000','0.733607030609466','0.697070900644643','96.14771043374391','96.147710433743910','test'),('2019-11-16 15:59:59','2019-11-19 07:59:59','STEEMBNB','4h','0.007340000000000','0.007030000000000','0.733607030609466','0.702623627409339','99.94646193589455','99.946461935894547','test'),('2019-11-20 19:59:59','2019-11-21 15:59:59','STEEMBNB','4h','0.007420000000000','0.007470000000000','0.733607030609466','0.738550474211956','98.86887204979325','98.868872049793254','test'),('2019-11-21 23:59:59','2019-11-22 07:59:59','STEEMBNB','4h','0.007510000000000','0.007200000000000','0.733607030609466','0.703324982741432','97.68402538075445','97.684025380754449','test'),('2019-11-23 11:59:59','2019-11-24 07:59:59','STEEMBNB','4h','0.007460000000000','0.007420000000000','0.733607030609466','0.729673480847485','98.33874404952627','98.338744049526269','test'),('2019-11-24 11:59:59','2019-11-24 19:59:59','STEEMBNB','4h','0.007460000000000','0.007360000000000','0.733607030609466','0.723773156204513','98.33874404952627','98.338744049526269','test'),('2019-11-25 23:59:59','2019-11-29 19:59:59','STEEMBNB','4h','0.007660000000000','0.007890000000000','0.733607030609466','0.755634395758314','95.77115282107911','95.771152821079113','test'),('2019-12-08 19:59:59','2019-12-13 23:59:59','STEEMBNB','4h','0.007910000000000','0.008930000000000','0.733607030609466','0.828206167299941','92.74425165732818','92.744251657328178','test'),('2019-12-15 15:59:59','2019-12-22 19:59:59','STEEMBNB','4h','0.009240000000000','0.010110000000000','0.733607030609466','0.802680419855162','79.39470028240974','79.394700282409744','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 10:58:27
