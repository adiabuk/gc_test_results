-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 23:59:59','2019-01-18 11:59:59','OSTETH','4h','0.000177800000000','0.000177110000000','0.072144500000000','0.071864524156355','405.7620922384702','405.762092238470188','test'),('2019-01-18 15:59:59','2019-01-22 15:59:59','OSTETH','4h','0.000179530000000','0.000190400000000','0.072144500000000','0.076512631872111','401.8520581518409','401.852058151840879','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','OSTETH','4h','0.000196150000000','0.000192000000000','0.073166539007117','0.071618534230775','373.0131991186159','373.013199118615887','test'),('2019-01-24 03:59:59','2019-01-24 07:59:59','OSTETH','4h','0.000193020000000','0.000192600000000','0.073166539007117','0.073007332985031','379.06195734699514','379.061957346995143','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','OSTETH','4h','0.000188900000000','0.000186070000000','0.073166539007117','0.072070396575195','387.32948124466384','387.329481244663839','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','OSTETH','4h','0.000193150000000','0.000167470000000','0.073166539007117','0.063438779640289','378.80682892631114','378.806828926311141','test'),('2019-02-26 15:59:59','2019-02-28 07:59:59','OSTETH','4h','0.000171180000000','0.000163450000000','0.073166539007117','0.069862547030689','427.42457651078985','427.424576510789848','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','OSTETH','4h','0.000167030000000','0.000162020000000','0.073166539007117','0.070971937076771','438.04429747420824','438.044297474208236','test'),('2019-03-01 15:59:59','2019-03-05 23:59:59','OSTETH','4h','0.000166850000000','0.000176990000000','0.073166539007117','0.077613100023192','438.5168654906623','438.516865490662326','test'),('2019-03-08 07:59:59','2019-03-16 03:59:59','OSTETH','4h','0.000187000000000','0.000199340000000','0.073166539007117','0.077994748051758','391.26491447656156','391.264914476561557','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','OSTETH','4h','0.000200070000000','0.000198540000000','0.073166539007117','0.072607010818579','365.7046983911481','365.704698391148099','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','OSTETH','4h','0.000200430000000','0.000196940000000','0.073166539007117','0.071892522037927','365.04784217490896','365.047842174908965','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','OSTETH','4h','0.000199880000000','0.000199000000000','0.073166539007117','0.072844412959857','366.05232643144393','366.052326431443930','test'),('2019-03-22 19:59:59','2019-03-23 07:59:59','OSTETH','4h','0.000200950000000','0.000199210000000','0.073166539007117','0.072532999430743','364.1032048127246','364.103204812724584','test'),('2019-03-26 23:59:59','2019-03-30 03:59:59','OSTETH','4h','0.000207870000000','0.000203000000000','0.073166539007117','0.071452385714364','351.9821956372589','351.982195637258883','test'),('2019-05-23 15:59:59','2019-05-24 19:59:59','OSTETH','4h','0.000110260000000','0.000102940000000','0.073166539007117','0.068309119584551','663.5818883286505','663.581888328650507','test'),('2019-05-25 03:59:59','2019-05-25 11:59:59','OSTETH','4h','0.000101410000000','0.000099120000000','0.073166539007117','0.071514321530277','721.4923479648654','721.492347964865417','test'),('2019-05-26 03:59:59','2019-05-27 03:59:59','OSTETH','4h','0.000107540000000','0.000105020000000','0.073166539007117','0.071452017170610','680.3658081375953','680.365808137595309','test'),('2019-05-27 11:59:59','2019-05-27 15:59:59','OSTETH','4h','0.000107430000000','0.000102280000000','0.073166539007117','0.069659067389444','681.0624500336685','681.062450033668483','test'),('2019-05-29 03:59:59','2019-05-30 03:59:59','OSTETH','4h','0.000119010000000','0.000103590000000','0.073166539007117','0.063686427827470','614.7932023117133','614.793202311713344','test'),('2019-06-04 07:59:59','2019-06-04 19:59:59','OSTETH','4h','0.000105700000000','0.000101640000000','0.073166539007117','0.070356168634658','692.2094513445318','692.209451344531772','test'),('2019-06-05 11:59:59','2019-06-06 15:59:59','OSTETH','4h','0.000109900000000','0.000105300000000','0.073166539007117','0.070104063307092','665.7555869619382','665.755586961938207','test'),('2019-06-06 19:59:59','2019-06-06 23:59:59','OSTETH','4h','0.000105720000000','0.000104900000000','0.073166539007117','0.072599034637217','692.0784998781404','692.078499878140406','test'),('2019-06-07 03:59:59','2019-06-07 07:59:59','OSTETH','4h','0.000106290000000','0.000108730000000','0.073166539007117','0.074846154729926','688.3670995118732','688.367099511873221','test'),('2019-06-07 11:59:59','2019-06-10 15:59:59','OSTETH','4h','0.000109960000000','0.000113620000000','0.073166539007117','0.075601874881672','665.3923154521372','665.392315452137154','test'),('2019-06-11 15:59:59','2019-06-12 15:59:59','OSTETH','4h','0.000115470000000','0.000111770000000','0.073166539007117','0.070822066898982','633.6411103067204','633.641110306720407','test'),('2019-07-22 07:59:59','2019-07-25 03:59:59','OSTETH','4h','0.000067870000000','0.000069460000000','0.073166539007117','0.074880621768592','1078.0394726258583','1078.039472625858252','test'),('2019-07-26 23:59:59','2019-07-27 11:59:59','OSTETH','4h','0.000071330000000','0.000067850000000','0.073166539007117','0.069596939178927','1025.7470770659893','1025.747077065989288','test'),('2019-07-30 07:59:59','2019-07-30 11:59:59','OSTETH','4h','0.000069390000000','0.000069180000000','0.073166539007117','0.072945109792655','1054.4248307698085','1054.424830769808523','test'),('2019-08-21 15:59:59','2019-08-27 19:59:59','OSTETH','4h','0.000057090000000','0.000065150000000','0.073166539007117','0.083496234302219','1281.5999125436506','1281.599912543650589','test'),('2019-08-31 07:59:59','2019-08-31 15:59:59','OSTETH','4h','0.000063890000000','0.000061800000000','0.073166539007117','0.070773080460789','1145.1954767118016','1145.195476711801575','test'),('2019-09-01 23:59:59','2019-09-02 07:59:59','OSTETH','4h','0.000064150000000','0.000062960000000','0.073166539007117','0.071809279748840','1140.5539985520968','1140.553998552096800','test'),('2019-09-05 23:59:59','2019-09-06 03:59:59','OSTETH','4h','0.000063100000000','0.000062180000000','0.073166539007117','0.072099768549327','1159.533106293455','1159.533106293454921','test'),('2019-09-06 15:59:59','2019-09-07 19:59:59','OSTETH','4h','0.000061070000000','0.000062670000000','0.073166539007117','0.075083461594498','1198.0766171134273','1198.076617113427346','test'),('2019-09-07 23:59:59','2019-09-09 11:59:59','OSTETH','4h','0.000065300000000','0.000061920000000','0.073166539007117','0.069379358274436','1120.4676723907658','1120.467672390765756','test'),('2019-09-09 23:59:59','2019-09-12 07:59:59','OSTETH','4h','0.000064780000000','0.000064480000000','0.073166539007117','0.072827700450431','1129.4618556208245','1129.461855620824508','test'),('2019-09-21 11:59:59','2019-09-22 03:59:59','OSTETH','4h','0.000064380000000','0.000060940000000','0.073166539007117','0.069257050125718','1136.4793259881485','1136.479325988148503','test'),('2019-09-22 07:59:59','2019-09-22 15:59:59','OSTETH','4h','0.000062160000000','0.000065900000000','0.073166539007117','0.077568772853427','1177.067873344868','1177.067873344868076','test'),('2019-09-23 03:59:59','2019-09-23 11:59:59','OSTETH','4h','0.000062240000000','0.000064370000000','0.073166539007117','0.075670471013627','1175.554932633628','1175.554932633627914','test'),('2019-09-24 03:59:59','2019-09-24 19:59:59','OSTETH','4h','0.000062570000000','0.000064140000000','0.073166539007117','0.075002426273238','1169.3549465737094','1169.354946573709412','test'),('2019-09-27 11:59:59','2019-09-27 23:59:59','OSTETH','4h','0.000063280000000','0.000061300000000','0.073166539007117','0.070877194076110','1156.2348136396492','1156.234813639649246','test'),('2019-09-28 03:59:59','2019-09-28 07:59:59','OSTETH','4h','0.000062460000000','0.000062520000000','0.073166539007117','0.073236823866874','1171.4143292846143','1171.414329284614269','test'),('2019-09-28 11:59:59','2019-09-28 19:59:59','OSTETH','4h','0.000063240000000','0.000061980000000','0.073166539007117','0.071708761664470','1156.9661449575744','1156.966144957574443','test'),('2019-09-29 03:59:59','2019-09-29 07:59:59','OSTETH','4h','0.000062110000000','0.000061500000000','0.073166539007117','0.072447949588435','1178.0154404623572','1178.015440462357219','test'),('2019-10-03 23:59:59','2019-10-06 07:59:59','OSTETH','4h','0.000064340000000','0.000063460000000','0.073166539007117','0.072165815439721','1137.1858720409855','1137.185872040985487','test'),('2019-10-06 11:59:59','2019-10-09 15:59:59','OSTETH','4h','0.000063580000000','0.000064970000000','0.073166539007117','0.074766122039830','1150.779160225181','1150.779160225180931','test'),('2019-10-12 11:59:59','2019-10-13 23:59:59','OSTETH','4h','0.000068390000000','0.000070340000000','0.073166539007117','0.075252732179567','1069.8426525386315','1069.842652538631455','test'),('2019-10-14 15:59:59','2019-10-14 19:59:59','OSTETH','4h','0.000067970000000','0.000065890000000','0.073166539007117','0.070927515891996','1076.453420731455','1076.453420731455026','test'),('2019-10-15 19:59:59','2019-10-16 11:59:59','OSTETH','4h','0.000068270000000','0.000065890000000','0.073166539007117','0.070615837925574','1071.7231435054491','1071.723143505449116','test'),('2019-10-22 03:59:59','2019-10-23 03:59:59','OSTETH','4h','0.000067630000000','0.000066480000000','0.073166539007117','0.071922394103107','1081.865133921588','1081.865133921588040','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','OSTETH','4h','0.000068210000000','0.000065890000000','0.073166539007117','0.070677954188227','1072.665870211362','1072.665870211362062','test'),('2019-10-30 23:59:59','2019-10-31 11:59:59','OSTETH','4h','0.000067180000000','0.000067650000000','0.073166539007117','0.073678421611067','1089.1119232973654','1089.111923297365365','test'),('2019-10-31 23:59:59','2019-11-02 15:59:59','OSTETH','4h','0.000065810000000','0.000064130000000','0.073166539007117','0.071298741020003','1111.784516139143','1111.784516139143079','test'),('2019-11-03 07:59:59','2019-11-04 19:59:59','OSTETH','4h','0.000066620000000','0.000065160000000','0.073166539007117','0.071563069374118','1098.2668719170972','1098.266871917097205','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','OSTETH','4h','0.000068040000000','0.000065150000000','0.073166539007117','0.070058789187444','1075.3459583644474','1075.345958364447370','test'),('2019-11-17 03:59:59','2019-11-19 03:59:59','OSTETH','4h','0.000073440000000','0.000064300000000','0.073166539007117','0.064060572687331','996.2764026023557','996.276402602355688','test'),('2019-11-24 23:59:59','2019-11-30 11:59:59','OSTETH','4h','0.000069000000000','0.000070000000000','0.073166539007117','0.074226923630409','1060.3846232915507','1060.384623291550724','test'),('2019-12-07 11:59:59','2019-12-10 03:59:59','OSTETH','4h','0.000072400000000','0.000068230000000','0.073166539007117','0.068952388901320','1010.58755534692','1010.587555346919999','test'),('2019-12-12 11:59:59','2019-12-22 11:59:59','OSTETH','4h','0.000074470000000','0.000094980000000','0.073166539007117','0.093317549011628','982.4968310342018','982.496831034201819','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:12:22
