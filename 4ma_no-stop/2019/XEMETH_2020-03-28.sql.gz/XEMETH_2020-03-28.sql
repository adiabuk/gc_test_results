-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 23:59:59','2019-01-14 15:59:59','XEMETH','4h','0.000451910000000','0.000447160000000','0.072144500000000','0.071386193312828','159.6435130888894','159.643513088889392','test'),('2019-01-14 19:59:59','2019-01-14 23:59:59','XEMETH','4h','0.000451880000000','0.000451050000000','0.072144500000000','0.072011987087280','159.65411171107374','159.654111711073739','test'),('2019-01-16 15:59:59','2019-01-16 19:59:59','XEMETH','4h','0.000458520000000','0.000458730000000','0.072144500000000','0.072177541841141','157.34210067172643','157.342100671726428','test'),('2019-01-17 03:59:59','2019-01-19 11:59:59','XEMETH','4h','0.000465250000000','0.000460980000000','0.072144500000000','0.071482367780763','155.0660934981193','155.066093498119301','test'),('2019-01-20 11:59:59','2019-01-23 07:59:59','XEMETH','4h','0.000464690000000','0.000467630000000','0.072144500000000','0.072600943715165','155.25296434181928','155.252964341819279','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','XEMETH','4h','0.000471960000000','0.000471650000000','0.072144500000000','0.072097112943894','152.86147131112807','152.861471311128071','test'),('2019-01-23 19:59:59','2019-01-23 23:59:59','XEMETH','4h','0.000473370000000','0.000470780000000','0.072144500000000','0.071749768067262','152.40615163614086','152.406151636140862','test'),('2019-01-24 03:59:59','2019-01-25 11:59:59','XEMETH','4h','0.000474780000000','0.000470110000000','0.072144500000000','0.071434876985130','151.953536374742','151.953536374741986','test'),('2019-01-25 15:59:59','2019-01-26 11:59:59','XEMETH','4h','0.000476070000000','0.000471740000000','0.072144500000000','0.071488324048984','151.54179007288843','151.541790072888432','test'),('2019-02-27 03:59:59','2019-02-28 11:59:59','XEMETH','4h','0.000318350000000','0.000310270000000','0.072144500000000','0.070313409816240','226.6200722475263','226.620072247526309','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','XEMETH','4h','0.000311070000000','0.000310300000000','0.072144500000000','0.071965918764265','231.92368277236636','231.923682772366362','test'),('2019-03-01 11:59:59','2019-03-01 19:59:59','XEMETH','4h','0.000314290000000','0.000313740000000','0.072144500000000','0.072018248846607','229.54755162429603','229.547551624296034','test'),('2019-03-01 23:59:59','2019-03-05 03:59:59','XEMETH','4h','0.000315100000000','0.000314810000000','0.072144500000000','0.072078102332593','228.9574738178356','228.957473817835591','test'),('2019-03-09 15:59:59','2019-03-16 11:59:59','XEMETH','4h','0.000342500000000','0.000353920000000','0.072144500000000','0.074550018802920','210.64087591240877','210.640875912408774','test'),('2019-03-17 23:59:59','2019-03-18 15:59:59','XEMETH','4h','0.000363620000000','0.000356550000000','0.072144500000000','0.070741767435785','198.40630328364776','198.406303283647759','test'),('2019-03-18 23:59:59','2019-03-19 03:59:59','XEMETH','4h','0.000359690000000','0.000357840000000','0.072144500000000','0.071773437904863','200.57410547971864','200.574105479718639','test'),('2019-03-20 11:59:59','2019-03-21 15:59:59','XEMETH','4h','0.000358510000000','0.000355170000000','0.072144500000000','0.071472377520850','201.23427519455527','201.234275194555266','test'),('2019-03-21 19:59:59','2019-03-26 03:59:59','XEMETH','4h','0.000359350000000','0.000369600000000','0.072144500000000','0.074202329762070','200.76387922638096','200.763879226380965','test'),('2019-03-28 15:59:59','2019-04-06 15:59:59','XEMETH','4h','0.000374480000000','0.000422840000000','0.072144500000000','0.081461173841060','192.65247810296944','192.652478102969440','test'),('2019-05-16 03:59:59','2019-05-20 07:59:59','XEMETH','4h','0.000359530000000','0.000358500000000','0.073709600202425','0.073498433155980','205.01654994694465','205.016549946944650','test'),('2019-05-30 11:59:59','2019-06-02 19:59:59','XEMETH','4h','0.000344430000000','0.000349860000000','0.073709600202425','0.074871645114596','214.0045878768545','214.004587876854487','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','XEMETH','4h','0.000355500000000','0.000350810000000','0.073947319668857','0.072971755873507','208.00933802772576','208.009338027725761','test'),('2019-06-08 19:59:59','2019-06-10 03:59:59','XEMETH','4h','0.000347450000000','0.000353000000000','0.073947319668857','0.075128518759840','212.82866504204057','212.828665042040569','test'),('2019-06-29 07:59:59','2019-06-29 23:59:59','XEMETH','4h','0.000320050000000','0.000309090000000','0.073998728492765','0.071464667988842','231.20989999301597','231.209899993015966','test'),('2019-06-30 03:59:59','2019-06-30 15:59:59','XEMETH','4h','0.000316700000000','0.000308000000000','0.073998728492765','0.071965924773513','233.65559991400377','233.655599914003773','test'),('2019-06-30 23:59:59','2019-07-01 15:59:59','XEMETH','4h','0.000310930000000','0.000311610000000','0.073998728492765','0.074160562781432','237.99160098017236','237.991600980172365','test'),('2019-07-01 19:59:59','2019-07-01 23:59:59','XEMETH','4h','0.000314580000000','0.000312060000000','0.073998728492765','0.073405948291221','235.23023870800748','235.230238708007477','test'),('2019-07-05 15:59:59','2019-07-05 23:59:59','XEMETH','4h','0.000316270000000','0.000311140000000','0.073998728492765','0.072798445578901','233.97327755640748','233.973277556407481','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','XEMETH','4h','0.000309180000000','0.000308450000000','0.073998728492765','0.073824011267202','239.3386651554596','239.338665155459609','test'),('2019-07-06 19:59:59','2019-07-06 23:59:59','XEMETH','4h','0.000310230000000','0.000311110000000','0.073998728492765','0.074208633663360','238.5286029486671','238.528602948667100','test'),('2019-07-16 23:59:59','2019-07-20 03:59:59','XEMETH','4h','0.000301670000000','0.000300340000000','0.073998728492765','0.073672483559907','245.29694199875692','245.296941998756921','test'),('2019-07-20 23:59:59','2019-07-21 23:59:59','XEMETH','4h','0.000305030000000','0.000299940000000','0.073998728492765','0.072763920349211','242.59492014806736','242.594920148067359','test'),('2019-07-22 15:59:59','2019-07-23 19:59:59','XEMETH','4h','0.000308850000000','0.000301000000000','0.073998728492765','0.072117912502258','239.59439369520803','239.594393695208026','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','XEMETH','4h','0.000307230000000','0.000303020000000','0.073998728492765','0.072984717338403','240.85775638044782','240.857756380447825','test'),('2019-07-24 19:59:59','2019-07-25 03:59:59','XEMETH','4h','0.000311580000000','0.000303340000000','0.073998728492765','0.072041768730327','237.49511680070927','237.495116800709269','test'),('2019-07-27 19:59:59','2019-07-28 07:59:59','XEMETH','4h','0.000305860000000','0.000303530000000','0.073998728492765','0.073435016214637','241.93660005481266','241.936600054812658','test'),('2019-07-30 19:59:59','2019-07-31 15:59:59','XEMETH','4h','0.000306730000000','0.000303060000000','0.073998728492765','0.073113339604921','241.25037815917906','241.250378159179064','test'),('2019-08-16 03:59:59','2019-08-18 15:59:59','XEMETH','4h','0.000292090000000','0.000284850000000','0.073998728492765','0.072164530833524','253.3422181271697','253.342218127169701','test'),('2019-08-21 15:59:59','2019-08-22 11:59:59','XEMETH','4h','0.000294890000000','0.000290750000000','0.073998728492765','0.072959850484151','250.93671705641083','250.936717056410828','test'),('2019-08-22 19:59:59','2019-08-22 23:59:59','XEMETH','4h','0.000286740000000','0.000291180000000','0.073998728492765','0.075144555215608','258.069081721298','258.069081721298005','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','XEMETH','4h','0.000289010000000','0.000288980000000','0.073998728492765','0.073991047229643','256.04210405440983','256.042104054409833','test'),('2019-08-23 19:59:59','2019-08-23 23:59:59','XEMETH','4h','0.000288990000000','0.000289070000000','0.073998728492765','0.074019213278673','256.05982384430257','256.059823844302571','test'),('2019-08-24 03:59:59','2019-08-26 03:59:59','XEMETH','4h','0.000291840000000','0.000292290000000','0.073998728492765','0.074112830150597','253.55923962707303','253.559239627073026','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','XEMETH','4h','0.000292530000000','0.000290040000000','0.073998728492765','0.073368855201318','252.96116122368645','252.961161223686446','test'),('2019-08-31 03:59:59','2019-08-31 19:59:59','XEMETH','4h','0.000297120000000','0.000286280000000','0.073998728492765','0.071298990283080','249.05334037683426','249.053340376834257','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','XEMETH','4h','0.000286760000000','0.000283530000000','0.073998728492765','0.073165223495444','258.0510827617694','258.051082761769408','test'),('2019-09-25 19:59:59','2019-09-28 07:59:59','XEMETH','4h','0.000236400000000','0.000239770000000','0.073998728492765','0.075053617304189','313.02338617920896','313.023386179208956','test'),('2019-10-17 19:59:59','2019-10-21 23:59:59','XEMETH','4h','0.000235800000000','0.000230010000000','0.073998728492765','0.072181711368197','313.81988334505934','313.819883345059338','test'),('2019-10-22 19:59:59','2019-10-22 23:59:59','XEMETH','4h','0.000236550000000','0.000225030000000','0.073998728492765','0.070394985722794','312.82489322665396','312.824893226653955','test'),('2019-10-24 15:59:59','2019-10-25 15:59:59','XEMETH','4h','0.000233470000000','0.000229750000000','0.073998728492765','0.072819667928268','316.951764649698','316.951764649698021','test'),('2019-10-28 19:59:59','2019-10-28 23:59:59','XEMETH','4h','0.000232800000000','0.000229570000000','0.073998728492765','0.072972027921323','317.8639540067225','317.863954006722508','test'),('2019-10-29 03:59:59','2019-10-29 07:59:59','XEMETH','4h','0.000230500000000','0.000230070000000','0.073998728492765','0.073860683142431','321.0356984501735','321.035698450173527','test'),('2019-11-02 19:59:59','2019-11-03 11:59:59','XEMETH','4h','0.000229500000000','0.000226740000000','0.073998728492765','0.073108809143571','322.4345468094335','322.434546809433527','test'),('2019-11-03 15:59:59','2019-11-03 19:59:59','XEMETH','4h','0.000232130000000','0.000231480000000','0.073998728492765','0.073791520576855','318.78140909302977','318.781409093029765','test'),('2019-11-05 03:59:59','2019-11-05 07:59:59','XEMETH','4h','0.000234620000000','0.000229340000000','0.073998728492765','0.072333425933555','315.3982119715497','315.398211971549699','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','XEMETH','4h','0.000231150000000','0.000226140000000','0.073998728492765','0.072394862476115','320.1329374551806','320.132937455180581','test'),('2019-11-16 11:59:59','2019-11-16 15:59:59','XEMETH','4h','0.000220030000000','0.000220970000000','0.073998728492765','0.074314861769060','336.31199605856017','336.311996058560169','test'),('2019-11-16 19:59:59','2019-11-18 11:59:59','XEMETH','4h','0.000224720000000','0.000221680000000','0.073998728492765','0.072997677697918','329.29302462070575','329.293024620705751','test'),('2019-11-19 19:59:59','2019-11-27 23:59:59','XEMETH','4h','0.000226610000000','0.000241830000000','0.073998728492765','0.078968767977606','326.546615298376','326.546615298376025','test'),('2019-12-02 19:59:59','2019-12-02 23:59:59','XEMETH','4h','0.000244240000000','0.000240510000000','0.073998728492765','0.072868629994247','302.9754687715566','302.975468771556621','test'),('2019-12-04 23:59:59','2019-12-06 23:59:59','XEMETH','4h','0.000242610000000','0.000243530000000','0.073998728492765','0.074279338649862','305.0110403230081','305.011040323008103','test'),('2019-12-07 03:59:59','2019-12-08 07:59:59','XEMETH','4h','0.000246740000000','0.000244870000000','0.073998728492765','0.073437904863514','299.9056840916146','299.905684091614603','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','XEMETH','4h','0.000245260000000','0.000243170000000','0.073998728492765','0.073368143225906','301.7154386885957','301.715438688595725','test'),('2019-12-11 15:59:59','2019-12-12 23:59:59','XEMETH','4h','0.000249060000000','0.000244090000000','0.073998728492765','0.072522081577929','297.11205529898416','297.112055298984160','test'),('2019-12-13 03:59:59','2019-12-15 15:59:59','XEMETH','4h','0.000248450000000','0.000248490000000','0.073998728492765','0.074010642154024','297.8415314661501','297.841531466150116','test'),('2019-12-16 03:59:59','2019-12-16 11:59:59','XEMETH','4h','0.000248490000000','0.000246800000000','0.073998728492765','0.073495457330333','297.7935872379774','297.793587237977420','test'),('2019-12-16 19:59:59','2019-12-19 11:59:59','XEMETH','4h','0.000257520000000','0.000252270000000','0.073998728492765','0.072490133725030','287.3513843304015','287.351384330401515','test'),('2019-12-19 15:59:59','2019-12-19 23:59:59','XEMETH','4h','0.000256200000000','0.000253130000000','0.073998728492765','0.073112014611138','288.83188326606165','288.831883266061652','test'),('2019-12-20 03:59:59','2019-12-22 03:59:59','XEMETH','4h','0.000258430000000','0.000254650000000','0.073998728492765','0.072916365014443','286.33954452952446','286.339544529524460','test'),('2019-12-25 07:59:59','2019-12-26 11:59:59','XEMETH','4h','0.000261410000000','0.000252750000000','0.073998728492765','0.071547295920379','283.07535477894874','283.075354778948736','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','XEMETH','4h','0.000255620000000','0.000248420000000','0.073998728492765','0.071914420359020','289.48724079792265','289.487240797922652','test'),('2019-12-27 07:59:59','2019-12-27 15:59:59','XEMETH','4h','0.000257500000000','0.000255430000000','0.073998728492765','0.073403864927794','287.3737028845242','287.373702884524221','test'),('2019-12-27 19:59:59','2019-12-28 03:59:59','XEMETH','4h','0.000256180000000','0.000255240000000','0.073998728492765','0.073727205326307','288.85443240208053','288.854432402080533','test'),('2019-12-28 07:59:59','2019-12-28 19:59:59','XEMETH','4h','0.000256900000000','0.000257330000000','0.073998728492765','0.074122587789191','288.04487540975083','288.044875409750830','test'),('2019-12-28 23:59:59','2019-12-29 03:59:59','XEMETH','4h','0.000257560000000','0.000252140000000','0.073998728492765','0.072441525866461','287.30675762061264','287.306757620612643','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:06:49
