-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 19:59:59','2019-01-06 11:59:59','INSBTC','4h','0.000074100000000','0.000078000000000','0.001467500000000','0.001544736842105','19.804318488529017','19.804318488529017','test'),('2019-01-07 23:59:59','2019-01-09 19:59:59','INSBTC','4h','0.000083700000000','0.000078900000000','0.001486809210526','0.001401544166195','17.763550902344683','17.763550902344683','test'),('2019-01-13 07:59:59','2019-01-13 19:59:59','INSBTC','4h','0.000080700000000','0.000076800000000','0.001486809210526','0.001414955977304','18.42390595447336','18.423905954473359','test'),('2019-01-13 23:59:59','2019-01-14 03:59:59','INSBTC','4h','0.000078800000000','0.000078300000000','0.001486809210526','0.001477375141931','18.86813718941624','18.868137189416242','test'),('2019-01-14 07:59:59','2019-01-17 03:59:59','INSBTC','4h','0.000081900000000','0.000080600000000','0.001486809210526','0.001463209064327','18.153958614481073','18.153958614481073','test'),('2019-01-18 15:59:59','2019-01-22 11:59:59','INSBTC','4h','0.000084900000000','0.000083900000000','0.001486809210526','0.001469296734548','17.51247597792697','17.512475977926972','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','INSBTC','4h','0.000088000000000','0.000085400000000','0.001486809210526','0.001442880756579','16.895559210522727','16.895559210522727','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','INSBTC','4h','0.000075900000000','0.000071800000000','0.001486809210526','0.001406494088482','19.589054157127798','19.589054157127798','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','INSBTC','4h','0.000072000000000','0.000071000000000','0.001486809210526','0.001466159082602','20.65012792397222','20.650127923972221','test'),('2019-03-01 15:59:59','2019-03-04 07:59:59','INSBTC','4h','0.000074200000000','0.000073000000000','0.001486809210526','0.001462763778550','20.037859980134773','20.037859980134773','test'),('2019-03-04 15:59:59','2019-03-04 19:59:59','INSBTC','4h','0.000073500000000','0.000073600000000','0.001486809210526','0.001488832080200','20.228696741850342','20.228696741850342','test'),('2019-03-13 03:59:59','2019-03-14 15:59:59','INSBTC','4h','0.000073400000000','0.000072300000000','0.001486809210526','0.001464527328624','20.256256274196186','20.256256274196186','test'),('2019-03-14 19:59:59','2019-03-15 07:59:59','INSBTC','4h','0.000072900000000','0.000073600000000','0.001486809210526','0.001501085842177','20.395188073058986','20.395188073058986','test'),('2019-03-15 15:59:59','2019-03-16 07:59:59','INSBTC','4h','0.000074000000000','0.000072500000000','0.001486809210526','0.001456671185988','20.09201635845946','20.092016358459460','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','INSBTC','4h','0.000073800000000','0.000072800000000','0.001486809210526','0.001466662744259','20.146466267289973','20.146466267289973','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','INSBTC','4h','0.000074000000000','0.000069800000000','0.001486809210526','0.001402422741820','20.09201635845946','20.092016358459460','test'),('2019-03-26 15:59:59','2019-03-27 07:59:59','INSBTC','4h','0.000073300000000','0.000073200000000','0.001486809210526','0.001484780821426','20.28389100308322','20.283891003083220','test'),('2019-03-27 11:59:59','2019-03-30 07:59:59','INSBTC','4h','0.000074600000000','0.000075400000000','0.001486809210526','0.001502753545223','19.9304183716622','19.930418371662199','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','INSBTC','4h','0.000078100000000','0.000074400000000','0.001486809210526','0.001416371386212','19.037249814673494','19.037249814673494','test'),('2019-05-23 23:59:59','2019-05-24 19:59:59','INSBTC','4h','0.000046400000000','0.000042700000000','0.001486809210526','0.001368248993307','32.04330195099138','32.043301950991378','test'),('2019-05-27 19:59:59','2019-05-28 19:59:59','INSBTC','4h','0.000043700000000','0.000042500000000','0.001486809210526','0.001445981497651','34.02309406237986','34.023094062379862','test'),('2019-05-28 23:59:59','2019-05-29 07:59:59','INSBTC','4h','0.000042900000000','0.000043000000000','0.001486809210526','0.001490274966261','34.65755735491842','34.657557354918417','test'),('2019-05-29 11:59:59','2019-05-30 15:59:59','INSBTC','4h','0.000043400000000','0.000041500000000','0.001486809210526','0.001421718484720','34.258276740230414','34.258276740230414','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','INSBTC','4h','0.000043600000000','0.000042600000000','0.001486809210526','0.001452708081844','34.10112868178899','34.101128681788992','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','INSBTC','4h','0.000042300000000','0.000042500000000','0.001486809210526','0.001493839041309','35.14915391314421','35.149153913144211','test'),('2019-06-04 15:59:59','2019-06-04 19:59:59','INSBTC','4h','0.000043100000000','0.000042000000000','0.001486809210526','0.001448862803761','34.496733422877035','34.496733422877035','test'),('2019-06-04 23:59:59','2019-06-08 15:59:59','INSBTC','4h','0.000043100000000','0.000044200000000','0.001486809210526','0.001524755617291','34.496733422877035','34.496733422877035','test'),('2019-06-09 11:59:59','2019-06-14 11:59:59','INSBTC','4h','0.000045800000000','0.000045300000000','0.001486809210526','0.001470577668926','32.46308319925764','32.463083199257639','test'),('2019-07-16 23:59:59','2019-07-18 19:59:59','INSBTC','4h','0.000028000000000','0.000027700000000','0.001486809210526','0.001470879111842','53.10032894735714','53.100328947357141','test'),('2019-07-19 03:59:59','2019-07-19 11:59:59','INSBTC','4h','0.000028000000000','0.000027600000000','0.001486809210526','0.001465569078947','53.10032894735714','53.100328947357141','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','INSBTC','4h','0.000028300000000','0.000028000000000','0.001486809210526','0.001471047982146','52.53742793378092','52.537427933780918','test'),('2019-07-31 07:59:59','2019-07-31 15:59:59','INSBTC','4h','0.000028600000000','0.000026500000000','0.001486809210526','0.001377637904858','51.98633603237762','51.986336032377622','test'),('2019-07-31 19:59:59','2019-08-01 11:59:59','INSBTC','4h','0.000027100000000','0.000026600000000','0.001486809210526','0.001459377306273','54.863808506494465','54.863808506494465','test'),('2019-08-21 19:59:59','2019-08-24 07:59:59','INSBTC','4h','0.000022200000000','0.000021300000000','0.001486809210526','0.001426533161451','66.97338786153153','66.973387861531535','test'),('2019-08-24 11:59:59','2019-08-24 15:59:59','INSBTC','4h','0.000021600000000','0.000021300000000','0.001486809210526','0.001466159082602','68.83375974657407','68.833759746574074','test'),('2019-08-28 15:59:59','2019-08-28 19:59:59','INSBTC','4h','0.000021000000000','0.000022000000000','0.001486809210526','0.001557609649122','70.8004385964762','70.800438596476198','test'),('2019-08-28 23:59:59','2019-08-31 15:59:59','INSBTC','4h','0.000029400000000','0.000024400000000','0.001486809210526','0.001233950501253','50.57174185462585','50.571741854625849','test'),('2019-09-02 11:59:59','2019-09-03 07:59:59','INSBTC','4h','0.000025700000000','0.000024400000000','0.001486809210526','0.001411600962523','57.85249846404669','57.852498464046690','test'),('2019-09-03 11:59:59','2019-09-03 15:59:59','INSBTC','4h','0.000024800000000','0.000024000000000','0.001486809210526','0.001438847623090','59.95198429540323','59.951984295403228','test'),('2019-09-03 23:59:59','2019-09-05 15:59:59','INSBTC','4h','0.000027600000000','0.000025500000000','0.001486809210526','0.001373682422769','53.86989893210145','53.869898932101449','test'),('2019-09-07 07:59:59','2019-09-07 15:59:59','INSBTC','4h','0.000027400000000','0.000025300000000','0.000991206140351','0.000915237786528','36.17540658214112','36.175406582141122','test'),('2019-09-07 19:59:59','2019-09-07 23:59:59','INSBTC','4h','0.000025900000000','0.000025900000000','0.001086089421540','0.001086089421540','41.93395449962354','41.933954499623539','test'),('2019-09-08 07:59:59','2019-09-09 15:59:59','INSBTC','4h','0.000026500000000','0.000025800000000','0.001086089421540','0.001057400267009','40.98450647321697','40.984506473216967','test'),('2019-09-09 19:59:59','2019-09-09 23:59:59','INSBTC','4h','0.000025900000000','0.000025900000000','0.001086089421540','0.001086089421540','41.933954499613904','41.933954499613904','test'),('2019-09-11 15:59:59','2019-09-12 15:59:59','INSBTC','4h','0.000027800000000','0.000025800000000','0.001086089421540','0.001007953491933','39.06796480359712','39.067964803597121','test'),('2019-10-03 19:59:59','2019-10-04 03:59:59','INSBTC','4h','0.000022520000000','0.000022190000000','0.001086089421540','0.001070174256837','48.22777182682061','48.227771826820607','test'),('2019-10-04 11:59:59','2019-10-05 15:59:59','INSBTC','4h','0.000023280000000','0.000023110000000','0.001086089421540','0.001078158356177','46.65332566752578','46.653325667525777','test'),('2019-10-05 19:59:59','2019-10-09 15:59:59','INSBTC','4h','0.000023300000000','0.000024120000000','0.001086089421540','0.001124312311053','46.61327989442061','46.613279894420607','test'),('2019-10-09 19:59:59','2019-10-10 07:59:59','INSBTC','4h','0.000024710000000','0.000023310000000','0.001086089421540','0.001024554610121','43.953436727640636','43.953436727640636','test'),('2019-10-15 07:59:59','2019-10-15 19:59:59','INSBTC','4h','0.000024490000000','0.000023510000000','0.001086089421540','0.001042628105366','44.348281810534914','44.348281810534914','test'),('2019-10-20 07:59:59','2019-10-22 07:59:59','INSBTC','4h','0.000025120000000','0.000024030000000','0.001086089421540','0.001038962133742','43.23604385111465','43.236043851114651','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','INSBTC','4h','0.000024660000000','0.000023990000000','0.001086089421540','0.001056580909276','44.04255561800487','44.042555618004869','test'),('2019-10-24 15:59:59','2019-10-25 15:59:59','INSBTC','4h','0.000025030000000','0.000024660000000','0.001086089421540','0.001070034563930','43.391507053136245','43.391507053136245','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','INSBTC','4h','0.000024250000000','0.000020920000000','0.001086089421540','0.000936948070046','44.78719264082475','44.787192640824749','test'),('2019-11-10 03:59:59','2019-11-10 19:59:59','INSBTC','4h','0.000022310000000','0.000021230000000','0.001086089421540','0.001033513151918','48.68173113133124','48.681731131331240','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','INSBTC','4h','0.000021250000000','0.000021040000000','0.001086089421540','0.001075356302551','51.11009042541177','51.110090425411769','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','INSBTC','4h','0.000021580000000','0.000021630000000','0.001086089421540','0.001088605847447','50.328518143651536','50.328518143651536','test'),('2019-11-15 19:59:59','2019-11-16 15:59:59','INSBTC','4h','0.000021890000000','0.000021780000000','0.001086089421540','0.001080631685753','49.61577987848333','49.615779878483330','test'),('2019-11-16 23:59:59','2019-11-17 11:59:59','INSBTC','4h','0.000021910000000','0.000021600000000','0.001086089421540','0.001070722569843','49.57048934459152','49.570489344591522','test'),('2019-11-17 15:59:59','2019-11-17 19:59:59','INSBTC','4h','0.000021670000000','0.000021760000000','0.001086089421540','0.001090600175944','50.11949337978773','50.119493379787727','test'),('2019-11-17 23:59:59','2019-11-21 07:59:59','INSBTC','4h','0.000021910000000','0.000022010000000','0.001086089421540','0.001091046470474','49.57048934459152','49.570489344591522','test'),('2019-11-24 11:59:59','2019-11-24 15:59:59','INSBTC','4h','0.000022080000000','0.000021900000000','0.001086089421540','0.001077235431690','49.18883249728262','49.188832497282618','test'),('2019-11-26 11:59:59','2019-11-27 11:59:59','INSBTC','4h','0.000023030000000','0.000022440000000','0.001086089421540','0.001058265159329','47.15976645853235','47.159766458532353','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','INSBTC','4h','0.000022550000000','0.000022260000000','0.001086089421540','0.001072121974434','48.16361071130821','48.163610711308209','test'),('2019-12-01 23:59:59','2019-12-02 03:59:59','INSBTC','4h','0.000022130000000','0.000022170000000','0.001086089421540','0.001088052529396','49.07769640939901','49.077696409399010','test'),('2019-12-02 11:59:59','2019-12-05 11:59:59','INSBTC','4h','0.000022570000000','0.000022560000000','0.001086089421540','0.001085608212226','48.120931392999566','48.120931392999566','test'),('2019-12-06 15:59:59','2019-12-10 03:59:59','INSBTC','4h','0.000022890000000','0.000024130000000','0.001086089421540','0.001144925196232','47.44820539711665','47.448205397116652','test'),('2019-12-13 23:59:59','2019-12-21 23:59:59','INSBTC','4h','0.000024750000000','0.000028750000000','0.001086089421540','0.001261619025021','43.88240087030304','43.882400870303037','test'),('2019-12-28 15:59:59','2019-12-29 15:59:59','INSBTC','4h','0.000028730000000','0.000028200000000','0.001086089421540','0.001066053661240','37.80332132057083','37.803321320570831','test'),('2019-12-30 11:59:59','2020-01-01 15:59:59','INSBTC','4h','0.000028900000000','0.000030390000000','0.001086089421540','0.001142085035315','37.58094884221453','37.580948842214532','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  0:53:57
