-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-17 19:59:59','2019-01-20 15:59:59','NASBTC','4h','0.000157300000000','0.000154200000000','0.001467500000000','0.001438579148125','9.329307056579784','9.329307056579784','test'),('2019-01-22 03:59:59','2019-01-23 03:59:59','NASBTC','4h','0.000156700000000','0.000155800000000','0.001467500000000','0.001459071474154','9.365028717294194','9.365028717294194','test'),('2019-01-23 07:59:59','2019-01-23 11:59:59','NASBTC','4h','0.000156100000000','0.000155900000000','0.001467500000000','0.001465619795003','9.401024983984625','9.401024983984625','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','NASBTC','4h','0.000159500000000','0.000155500000000','0.001467500000000','0.001430697492163','9.20062695924765','9.200626959247650','test'),('2019-01-24 07:59:59','2019-01-24 15:59:59','NASBTC','4h','0.000156300000000','0.000155800000000','0.001467500000000','0.001462805502239','9.388995521433142','9.388995521433142','test'),('2019-01-24 19:59:59','2019-01-24 23:59:59','NASBTC','4h','0.000156300000000','0.000155600000000','0.001467500000000','0.001460927703135','9.388995521433142','9.388995521433142','test'),('2019-01-25 03:59:59','2019-01-25 11:59:59','NASBTC','4h','0.000157300000000','0.000153500000000','0.001467500000000','0.001432048633185','9.329307056579784','9.329307056579784','test'),('2019-01-26 19:59:59','2019-01-27 19:59:59','NASBTC','4h','0.000160600000000','0.000157500000000','0.001467500000000','0.001439173412204','9.13760896637609','9.137608966376090','test'),('2019-02-16 03:59:59','2019-02-19 03:59:59','NASBTC','4h','0.000155000000000','0.000153600000000','0.001467500000000','0.001454245161290','9.467741935483872','9.467741935483872','test'),('2019-02-19 07:59:59','2019-02-19 11:59:59','NASBTC','4h','0.000155900000000','0.000155200000000','0.001467500000000','0.001460910840282','9.413085311096857','9.413085311096857','test'),('2019-02-23 03:59:59','2019-02-24 19:59:59','NASBTC','4h','0.000167300000000','0.000160400000000','0.001467500000000','0.001406975493126','8.771667662881052','8.771667662881052','test'),('2019-02-25 03:59:59','2019-02-25 11:59:59','NASBTC','4h','0.000160500000000','0.000156900000000','0.001467500000000','0.001434584112150','9.143302180685358','9.143302180685358','test'),('2019-02-25 23:59:59','2019-02-26 19:59:59','NASBTC','4h','0.000166300000000','0.000159700000000','0.001467500000000','0.001409258869513','8.824413710162357','8.824413710162357','test'),('2019-02-27 11:59:59','2019-03-02 07:59:59','NASBTC','4h','0.000163900000000','0.000161300000000','0.001467500000000','0.001444220561318','8.953630262355095','8.953630262355095','test'),('2019-03-06 23:59:59','2019-03-08 03:59:59','NASBTC','4h','0.000162800000000','0.000161200000000','0.001467500000000','0.001453077395577','9.014127764127764','9.014127764127764','test'),('2019-03-08 19:59:59','2019-03-08 23:59:59','NASBTC','4h','0.000168600000000','0.000162900000000','0.001467500000000','0.001417887010676','8.704033214709371','8.704033214709371','test'),('2019-03-09 03:59:59','2019-03-18 19:59:59','NASBTC','4h','0.000172500000000','0.000204400000000','0.001467500000000','0.001738881159420','8.507246376811596','8.507246376811596','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','NASBTC','4h','0.000220700000000','0.000207900000000','0.001467500000000','0.001382388989579','6.649297689170821','6.649297689170821','test'),('2019-03-21 19:59:59','2019-03-26 07:59:59','NASBTC','4h','0.000208400000000','0.000218400000000','0.001467500000000','0.001537917466411','7.041746641074856','7.041746641074856','test'),('2019-03-27 15:59:59','2019-03-30 15:59:59','NASBTC','4h','0.000230600000000','0.000229100000000','0.001467500000000','0.001457954249783','6.363833477883782','6.363833477883782','test'),('2019-03-31 23:59:59','2019-04-02 07:59:59','NASBTC','4h','0.000231000000000','0.000245700000000','0.001467500000000','0.001560886363636','6.352813852813853','6.352813852813853','test'),('2019-04-02 15:59:59','2019-04-03 03:59:59','NASBTC','4h','0.000234400000000','0.000231800000000','0.001467500000000','0.001451222269625','6.260665529010239','6.260665529010239','test'),('2019-04-04 07:59:59','2019-04-06 19:59:59','NASBTC','4h','0.000248100000000','0.000241000000000','0.001467500000000','0.001425503829101','5.914953647722692','5.914953647722692','test'),('2019-04-11 23:59:59','2019-04-15 11:59:59','NASBTC','4h','0.000248800000000','0.000260500000000','0.001467500000000','0.001536510249196','5.89831189710611','5.898311897106110','test'),('2019-04-16 19:59:59','2019-04-17 07:59:59','NASBTC','4h','0.000270200000000','0.000258100000000','0.001467500000000','0.001401782938564','5.431162102146558','5.431162102146558','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','NASBTC','4h','0.000158400000000','0.000148600000000','0.001467500000000','0.001376707702020','9.264520202020202','9.264520202020202','test'),('2019-06-01 19:59:59','2019-06-01 23:59:59','NASBTC','4h','0.000141100000000','0.000138700000000','0.001467500000000','0.001442538979447','10.400425230333099','10.400425230333099','test'),('2019-06-07 07:59:59','2019-06-08 15:59:59','NASBTC','4h','0.000140800000000','0.000138000000000','0.001467500000000','0.001438316761364','10.422585227272727','10.422585227272727','test'),('2019-06-08 23:59:59','2019-06-13 19:59:59','NASBTC','4h','0.000139200000000','0.000196300000000','0.001467500000000','0.002069470186782','10.542385057471265','10.542385057471265','test'),('2019-07-05 15:59:59','2019-07-06 07:59:59','NASBTC','4h','0.000151500000000','0.000142100000000','0.001550665937267','0.001454453001225','10.235418727834983','10.235418727834983','test'),('2019-07-06 11:59:59','2019-07-06 15:59:59','NASBTC','4h','0.000142300000000','0.000138100000000','0.001550665937267','0.001504897863223','10.897160486767394','10.897160486767394','test'),('2019-07-26 15:59:59','2019-07-27 11:59:59','NASBTC','4h','0.000095500000000','0.000093800000000','0.001550665937267','0.001523062459850','16.23733965724607','16.237339657246071','test'),('2019-07-27 19:59:59','2019-07-28 11:59:59','NASBTC','4h','0.000095500000000','0.000093500000000','0.001550665937267','0.001518191257953','16.23733965724607','16.237339657246071','test'),('2019-08-24 03:59:59','2019-08-26 11:59:59','NASBTC','4h','0.000070900000000','0.000069200000000','0.001550665937267','0.001513484948644','21.871169778095908','21.871169778095908','test'),('2019-08-27 19:59:59','2019-08-28 19:59:59','NASBTC','4h','0.000072300000000','0.000070300000000','0.001550665937267','0.001507770613968','21.447661649612726','21.447661649612726','test'),('2019-09-17 11:59:59','2019-09-19 23:59:59','NASBTC','4h','0.000064400000000','0.000064900000000','0.001550665937267','0.001562705269078','24.078663622158388','24.078663622158388','test'),('2019-10-01 23:59:59','2019-10-02 03:59:59','NASBTC','4h','0.000059400000000','0.000059200000000','0.001550665937267','0.001545444839835','26.105487159377105','26.105487159377105','test'),('2019-10-05 19:59:59','2019-10-05 23:59:59','NASBTC','4h','0.000060400000000','0.000060100000000','0.001550665937267','0.001542963954135','25.673277107069538','25.673277107069538','test'),('2019-10-06 07:59:59','2019-10-06 11:59:59','NASBTC','4h','0.000060300000000','0.000062700000000','0.001550665937267','0.001612383984521','25.715853022669982','25.715853022669982','test'),('2019-10-06 15:59:59','2019-10-10 23:59:59','NASBTC','4h','0.000063300000000','0.000064100000000','0.001550665937267','0.001570263611040','24.497092215908374','24.497092215908374','test'),('2019-10-27 19:59:59','2019-10-29 23:59:59','NASBTC','4h','0.000072600000000','0.000062900000000','0.001550665937267','0.001343483298266','21.359034948581268','21.359034948581268','test'),('2019-10-30 15:59:59','2019-10-31 15:59:59','NASBTC','4h','0.000065600000000','0.000063800000000','0.001550665937267','0.001508117176793','23.638200263216465','23.638200263216465','test'),('2019-11-02 03:59:59','2019-11-03 11:59:59','NASBTC','4h','0.000067100000000','0.000064500000000','0.001550665937267','0.001490580520920','23.10977551813711','23.109775518137109','test'),('2019-11-03 15:59:59','2019-11-04 23:59:59','NASBTC','4h','0.000065800000000','0.000064800000000','0.001550665937267','0.001527099585637','23.56635163019757','23.566351630197570','test'),('2019-11-05 15:59:59','2019-11-05 19:59:59','NASBTC','4h','0.000066000000000','0.000064900000000','0.001550665937267','0.001524821504979','23.49493844343939','23.494938443439391','test'),('2019-11-06 03:59:59','2019-11-06 15:59:59','NASBTC','4h','0.000065900000000','0.000065100000000','0.001550665937267','0.001531841464584','23.530590853823973','23.530590853823973','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','NASBTC','4h','0.000065400000000','0.000064700000000','0.001550665937267','0.001534068595431','23.7104883374159','23.710488337415899','test'),('2019-11-07 15:59:59','2019-11-08 15:59:59','NASBTC','4h','0.000066800000000','0.000065700000000','0.001550665937267','0.001525131019138','23.21356193513473','23.213561935134731','test'),('2019-11-08 23:59:59','2019-11-09 11:59:59','NASBTC','4h','0.000065900000000','0.000065700000000','0.001550665937267','0.001545959819096','23.530590853823973','23.530590853823973','test'),('2019-11-09 15:59:59','2019-11-10 19:59:59','NASBTC','4h','0.000066000000000','0.000067000000000','0.001550665937267','0.001574160875710','23.49493844343939','23.494938443439391','test'),('2019-11-11 11:59:59','2019-11-15 15:59:59','NASBTC','4h','0.000066700000000','0.000068600000000','0.001550665937267','0.001594837830532','23.24836487656672','23.248364876566718','test'),('2019-12-09 19:59:59','2019-12-10 03:59:59','NASBTC','4h','0.000058600000000','0.000056800000000','0.001550665937267','0.001503034560354','26.461876062576792','26.461876062576792','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  9:26:06
