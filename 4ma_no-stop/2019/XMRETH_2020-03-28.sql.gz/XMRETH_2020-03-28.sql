-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 11:59:59','XMRETH','4h','0.348500000000000','0.351250000000000','0.072144500000000','0.072713789454806','0.20701434720229556','0.207014347202296','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','XMRETH','4h','0.358000000000000','0.350220000000000','0.072286822363702','0.070715896447530','0.2019184982226299','0.201918498222630','test'),('2019-01-10 23:59:59','2019-01-12 11:59:59','XMRETH','4h','0.353990000000000','0.354840000000000','0.072286822363702','0.072460397320648','0.20420583170061865','0.204205831700619','test'),('2019-01-12 19:59:59','2019-01-14 15:59:59','XMRETH','4h','0.357250000000000','0.356640000000000','0.072286822363702','0.072163393499764','0.20234239989839609','0.202342399898396','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','XMRETH','4h','0.367600000000000','0.370360000000000','0.072286822363702','0.072829563467412','0.19664532743118063','0.196645327431181','test'),('2019-01-16 19:59:59','2019-01-30 19:59:59','XMRETH','4h','0.372160000000000','0.407470000000000','0.072286822363702','0.079145291026810','0.19423587264537295','0.194235872645373','test'),('2019-02-01 03:59:59','2019-02-01 23:59:59','XMRETH','4h','0.414200000000000','0.406000000000000','0.073756929849615','0.072296749200733','0.17807081083924434','0.178070810839244','test'),('2019-02-06 03:59:59','2019-02-08 19:59:59','XMRETH','4h','0.413890000000000','0.401170000000000','0.073756929849615','0.071490172625021','0.1782041843234072','0.178204184323407','test'),('2019-03-02 15:59:59','2019-03-05 15:59:59','XMRETH','4h','0.364510000000000','0.363350000000000','0.073756929849615','0.073522209159852','0.20234542220958274','0.202345422209583','test'),('2019-03-08 03:59:59','2019-03-08 07:59:59','XMRETH','4h','0.364470000000000','0.363720000000000','0.073756929849615','0.073605154127643','0.20236762929627952','0.202367629296280','test'),('2019-03-08 11:59:59','2019-03-08 15:59:59','XMRETH','4h','0.365190000000000','0.360620000000000','0.073756929849615','0.072833933137184','0.20196864604620882','0.201968646046209','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','XMRETH','4h','0.367560000000000','0.364930000000000','0.073756929849615','0.073229177304440','0.20066636698665524','0.200666366986655','test'),('2019-03-10 07:59:59','2019-03-10 15:59:59','XMRETH','4h','0.365360000000000','0.364350000000000','0.073756929849615','0.073553036431758','0.20187467114521293','0.201874671145213','test'),('2019-03-10 19:59:59','2019-03-11 03:59:59','XMRETH','4h','0.365980000000000','0.365180000000000','0.073756929849615','0.073595703706439','0.20153267897047653','0.201532678970477','test'),('2019-03-11 07:59:59','2019-03-16 07:59:59','XMRETH','4h','0.365940000000000','0.378530000000000','0.073756929849615','0.076294503623476','0.20155470801119038','0.201554708011190','test'),('2019-03-19 19:59:59','2019-03-23 11:59:59','XMRETH','4h','0.382910000000000','0.384380000000000','0.073756929849615','0.074040084342522','0.19262210401821578','0.192622104018216','test'),('2019-03-24 19:59:59','2019-03-25 19:59:59','XMRETH','4h','0.387250000000000','0.380460000000000','0.073756929849615','0.072463683745861','0.19046334370462234','0.190463343704622','test'),('2019-03-31 23:59:59','2019-04-04 07:59:59','XMRETH','4h','0.395790000000000','0.405410000000000','0.073756929849615','0.075549652417526','0.18635369728799364','0.186353697287994','test'),('2019-04-05 19:59:59','2019-04-06 19:59:59','XMRETH','4h','0.415000000000000','0.405420000000000','0.073756929849615','0.072054299999111','0.1777275418063012','0.177727541806301','test'),('2019-04-06 23:59:59','2019-04-07 19:59:59','XMRETH','4h','0.410390000000000','0.408450000000000','0.073756929849615','0.073408265301482','0.17972399388292845','0.179723993882928','test'),('2019-04-12 15:59:59','2019-04-12 23:59:59','XMRETH','4h','0.412540000000000','0.401360000000000','0.073756929849615','0.071758087371992','0.1787873414689848','0.178787341468985','test'),('2019-04-15 19:59:59','2019-04-15 23:59:59','XMRETH','4h','0.405390000000000','0.399610000000000','0.073756929849615','0.072705312753656','0.18194067404133057','0.181940674041331','test'),('2019-04-16 11:59:59','2019-04-16 15:59:59','XMRETH','4h','0.400460000000000','0.406950000000000','0.073756929849615','0.074952261405136','0.18418051702945365','0.184180517029454','test'),('2019-04-16 19:59:59','2019-04-17 23:59:59','XMRETH','4h','0.409500000000000','0.405220000000000','0.073756929849615','0.072986039349599','0.18011460280736266','0.180114602807363','test'),('2019-04-21 11:59:59','2019-04-22 03:59:59','XMRETH','4h','0.403810000000000','0.406070000000000','0.073756929849615','0.074169724632954','0.18265255899956664','0.182652558999567','test'),('2019-04-22 11:59:59','2019-04-22 15:59:59','XMRETH','4h','0.403420000000000','0.399780000000000','0.073756929849615','0.073091431796339','0.182829135515381','0.182829135515381','test'),('2019-04-23 23:59:59','2019-04-24 11:59:59','XMRETH','4h','0.403610000000000','0.399860000000000','0.073756929849615','0.073071643342997','0.18274306843144372','0.182743068431444','test'),('2019-04-24 15:59:59','2019-04-24 19:59:59','XMRETH','4h','0.401670000000000','0.405500000000000','0.073756929849615','0.074460216232277','0.1836256873792292','0.183625687379229','test'),('2019-04-24 23:59:59','2019-04-25 23:59:59','XMRETH','4h','0.409100000000000','0.397870000000000','0.073756929849615','0.071732265165647','0.18029071094992666','0.180290710949927','test'),('2019-04-26 11:59:59','2019-04-26 19:59:59','XMRETH','4h','0.409880000000000','0.402800000000000','0.073756929849615','0.072482900711001','0.17994761844836293','0.179947618448363','test'),('2019-05-02 23:59:59','2019-05-03 07:59:59','XMRETH','4h','0.402210000000000','0.398630000000000','0.073756929849615','0.073100432475453','0.18337915479380174','0.183379154793802','test'),('2019-05-03 15:59:59','2019-05-06 11:59:59','XMRETH','4h','0.404410000000000','0.404450000000000','0.073756929849615','0.073764225112329','0.18238156783861675','0.182381567838617','test'),('2019-05-13 07:59:59','2019-05-13 19:59:59','XMRETH','4h','0.404700000000000','0.401790000000000','0.073756929849615','0.073226579798065','0.18225087682138622','0.182250876821386','test'),('2019-05-13 23:59:59','2019-05-14 03:59:59','XMRETH','4h','0.405210000000000','0.398150000000000','0.073756929849615','0.072471858097343','0.18202149465614126','0.182021494656141','test'),('2019-05-14 11:59:59','2019-05-14 19:59:59','XMRETH','4h','0.400280000000000','0.398920000000000','0.073756929849615','0.073506331706826','0.1842633402858374','0.184263340285837','test'),('2019-05-28 11:59:59','2019-05-28 19:59:59','XMRETH','4h','0.361570000000000','0.353560000000000','0.073756929849615','0.072122964066792','0.2039907344348674','0.203990734434867','test'),('2019-06-03 03:59:59','2019-06-04 03:59:59','XMRETH','4h','0.354090000000000','0.351190000000000','0.073756929849615','0.073152859990077','0.20829995156489875','0.208299951564899','test'),('2019-06-04 07:59:59','2019-06-04 11:59:59','XMRETH','4h','0.351990000000000','0.351810000000000','0.073756929849615','0.073719212166235','0.20954268544451546','0.209542685444515','test'),('2019-06-08 03:59:59','2019-06-08 11:59:59','XMRETH','4h','0.353350000000000','0.353870000000000','0.073756929849615','0.073865472664167','0.20873618182995615','0.208736181829956','test'),('2019-06-08 15:59:59','2019-06-10 11:59:59','XMRETH','4h','0.355090000000000','0.355620000000000','0.073756929849615','0.073867017919739','0.20771333985641668','0.207713339856417','test'),('2019-06-11 11:59:59','2019-06-11 23:59:59','XMRETH','4h','0.358520000000000','0.353110000000000','0.073756929849615','0.072643951520689','0.20572612364614248','0.205726123646142','test'),('2019-06-17 03:59:59','2019-06-21 19:59:59','XMRETH','4h','0.360770000000000','0.365620000000000','0.073756929849615','0.074748478785975','0.204443079661876','0.204443079661876','test'),('2019-06-23 19:59:59','2019-06-25 07:59:59','XMRETH','4h','0.379110000000000','0.368750000000000','0.073756929849615','0.071741362354054','0.19455284706184223','0.194552847061842','test'),('2019-07-07 07:59:59','2019-07-08 23:59:59','XMRETH','4h','0.342430000000000','0.324190000000000','0.073756929849615','0.069828166597397','0.21539272216106942','0.215392722161069','test'),('2019-07-09 03:59:59','2019-07-09 07:59:59','XMRETH','4h','0.328980000000000','0.326930000000000','0.073756929849615','0.073297322255866','0.22419882621926865','0.224198826219269','test'),('2019-07-11 15:59:59','2019-07-12 03:59:59','XMRETH','4h','0.341410000000000','0.323080000000000','0.073756929849615','0.069796985723364','0.2160362316558244','0.216036231655824','test'),('2019-07-12 07:59:59','2019-07-17 23:59:59','XMRETH','4h','0.331180000000000','0.364380000000000','0.073756929849615','0.081150885012992','0.22270949287280334','0.222709492872803','test'),('2019-07-18 19:59:59','2019-07-24 19:59:59','XMRETH','4h','0.375360000000000','0.376720000000000','0.073756929849615','0.074024165102693','0.19649650961640824','0.196496509616408','test'),('2019-07-28 03:59:59','2019-07-29 15:59:59','XMRETH','4h','0.385150000000000','0.376440000000000','0.073756929849615','0.072088948909747','0.19150183006520838','0.191501830065208','test'),('2019-08-01 19:59:59','2019-08-11 19:59:59','XMRETH','4h','0.377770000000000','0.424090000000000','0.073756929849615','0.082800583370631','0.1952429516626916','0.195242951662692','test'),('2019-08-15 23:59:59','2019-08-18 19:59:59','XMRETH','4h','0.439220000000000','0.429730000000000','0.073756929849615','0.072163301908554','0.1679270749274054','0.167927074927405','test'),('2019-08-18 23:59:59','2019-08-19 07:59:59','XMRETH','4h','0.451660000000000','0.429160000000000','0.073756929849615','0.070082637413676','0.163301886041746','0.163301886041746','test'),('2019-09-05 03:59:59','2019-09-08 07:59:59','XMRETH','4h','0.425990000000000','0.431580000000000','0.073756929849615','0.074724795850834','0.1731423973558417','0.173142397355842','test'),('2019-10-17 11:59:59','2019-10-19 11:59:59','XMRETH','4h','0.339670000000000','0.312780000000000','0.073756929849615','0.067917957188926','0.2171429029635087','0.217142902963509','test'),('2019-10-20 11:59:59','2019-10-24 07:59:59','XMRETH','4h','0.323680000000000','0.324800000000000','0.073756929849615','0.074012144139752','0.22786990190810366','0.227869901908104','test'),('2019-10-24 19:59:59','2019-10-25 07:59:59','XMRETH','4h','0.335450000000000','0.326390000000000','0.073756929849615','0.071764866101105','0.21987458592820092','0.219874585928201','test'),('2019-10-28 15:59:59','2019-10-28 23:59:59','XMRETH','4h','0.331920000000000','0.327080000000000','0.073756929849615','0.072681419062461','0.22221297255246747','0.222212972552467','test'),('2019-10-29 07:59:59','2019-10-29 19:59:59','XMRETH','4h','0.334950000000000','0.316890000000000','0.073756929849615','0.069780067174338','0.22020280594003583','0.220202805940036','test'),('2019-11-01 15:59:59','2019-11-05 07:59:59','XMRETH','4h','0.332150000000000','0.336540000000000','0.073756929849615','0.074731769295768','0.22205909935154297','0.222059099351543','test'),('2019-11-07 07:59:59','2019-11-08 15:59:59','XMRETH','4h','0.342660000000000','0.330440000000000','0.073756929849615','0.071126597500458','0.21524814641223078','0.215248146412231','test'),('2019-11-10 11:59:59','2019-11-10 19:59:59','XMRETH','4h','0.339620000000000','0.339510000000000','0.073756929849615','0.073733040613753','0.21717487147286677','0.217174871472867','test'),('2019-11-12 11:59:59','2019-11-12 23:59:59','XMRETH','4h','0.340930000000000','0.332560000000000','0.073756929849615','0.071946160768451','0.21634039201482708','0.216340392014827','test'),('2019-11-13 07:59:59','2019-11-16 03:59:59','XMRETH','4h','0.339980000000000','0.340300000000000','0.073756929849615','0.073826352220201','0.21694490808169598','0.216944908081696','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','XMRETH','4h','0.340030000000000','0.338080000000000','0.073756929849615','0.073333949485510','0.21691300723352352','0.216913007233524','test'),('2019-11-24 07:59:59','2019-11-24 11:59:59','XMRETH','4h','0.339890000000000','0.337120000000000','0.073756929849615','0.073155833331084','0.21700235326021652','0.217002353260217','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','XMRETH','4h','0.338440000000000','0.339660000000000','0.073756929849615','0.074022806975299','0.2179320702328773','0.217932070232877','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','XMRETH','4h','0.346230000000000','0.339650000000000','0.073756929849615','0.072355200945677','0.21302870880517288','0.213028708805173','test'),('2019-11-25 15:59:59','2019-12-01 15:59:59','XMRETH','4h','0.349100000000000','0.354140000000000','0.073756929849615','0.074821767794164','0.21127736995020052','0.211277369950201','test'),('2019-12-02 15:59:59','2019-12-05 07:59:59','XMRETH','4h','0.361760000000000','0.359350000000000','0.073756929849615','0.073265570382185','0.20388359644409276','0.203883596444093','test'),('2019-12-06 07:59:59','2019-12-07 07:59:59','XMRETH','4h','0.367470000000000','0.363140000000000','0.073756929849615','0.072887831674937','0.2007155137823904','0.200715513782390','test'),('2019-12-07 11:59:59','2019-12-08 15:59:59','XMRETH','4h','0.368510000000000','0.360920000000000','0.073756929849615','0.072237798489384','0.20014905931891944','0.200149059318919','test'),('2019-12-10 07:59:59','2019-12-10 19:59:59','XMRETH','4h','0.367660000000000','0.363530000000000','0.073756929849615','0.072928403166596','0.20061178765602733','0.200611787656027','test'),('2019-12-11 11:59:59','2019-12-12 23:59:59','XMRETH','4h','0.365000000000000','0.365650000000000','0.073756929849615','0.073888277806881','0.20207378040990412','0.202073780409904','test'),('2019-12-13 07:59:59','2019-12-13 23:59:59','XMRETH','4h','0.367590000000000','0.362350000000000','0.073756929849615','0.072705523901651','0.2006499900694116','0.200649990069412','test'),('2019-12-17 03:59:59','2019-12-17 15:59:59','XMRETH','4h','0.372500000000000','0.366010000000000','0.073756929849615','0.072471876226195','0.19800518080433557','0.198005180804336','test'),('2019-12-17 19:59:59','2019-12-18 03:59:59','XMRETH','4h','0.366970000000000','0.371460000000000','0.073756929849615','0.074659370417031','0.20098899051588684','0.200988990515887','test'),('2019-12-18 07:59:59','2019-12-18 15:59:59','XMRETH','4h','0.372360000000000','0.366340000000000','0.073756929849615','0.072564490496047','0.19807962683858363','0.198079626838584','test'),('2019-12-19 11:59:59','2019-12-20 15:59:59','XMRETH','4h','0.375000000000000','0.366450000000000','0.073756929849615','0.072075271849044','0.19668514626564002','0.196685146265640','test'),('2019-12-24 11:59:59','2019-12-24 15:59:59','XMRETH','4h','0.369620000000000','0.363020000000000','0.073756929849615','0.072439913083727','0.1995479948314891','0.199547994831489','test'),('2019-12-25 07:59:59','2019-12-25 15:59:59','XMRETH','4h','0.372000000000000','0.364880000000000','0.073756929849615','0.072345238073999','0.19827131680004034','0.198271316800040','test'),('2019-12-25 19:59:59','2019-12-26 15:59:59','XMRETH','4h','0.366020000000000','0.363000000000000','0.073756929849615','0.073148367672286','0.20151065474459046','0.201510654744590','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 23:14:44
