-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 07:59:59','2019-01-12 11:59:59','WPRETH','4h','0.000093190000000','0.000093990000000','0.072144500000000','0.072763832546411','774.1656830131989','774.165683013198873','test'),('2019-01-12 15:59:59','2019-01-14 19:59:59','WPRETH','4h','0.000094320000000','0.000094490000000','0.072299333136603','0.072429643639500','766.5323699809452','766.532369980945191','test'),('2019-01-15 15:59:59','2019-01-20 15:59:59','WPRETH','4h','0.000102570000000','0.000108450000000','0.072331910762327','0.076478460779705','705.19558118677','705.195581186770028','test'),('2019-01-21 23:59:59','2019-01-25 11:59:59','WPRETH','4h','0.000112840000000','0.000110970000000','0.073368548266671','0.072152674593694','650.1998251211583','650.199825121158256','test'),('2019-01-25 23:59:59','2019-01-26 23:59:59','WPRETH','4h','0.000113570000000','0.000112220000000','0.073368548266671','0.072496420590700','646.0205007191247','646.020500719124698','test'),('2019-01-28 11:59:59','2019-01-29 03:59:59','WPRETH','4h','0.000114170000000','0.000111210000000','0.073368548266671','0.071466376918074','642.6254556071735','642.625455607173535','test'),('2019-01-30 11:59:59','2019-01-31 11:59:59','WPRETH','4h','0.000115840000000','0.000112670000000','0.073368548266671','0.071360793622288','633.3610865562068','633.361086556206828','test'),('2019-02-02 15:59:59','2019-02-03 11:59:59','WPRETH','4h','0.000115160000000','0.000112300000000','0.073368548266671','0.071546439478527','637.1009748755731','637.100974875573115','test'),('2019-03-02 03:59:59','2019-03-06 03:59:59','WPRETH','4h','0.000082790000000','0.000087540000000','0.073368548266671','0.077578001150675','886.2006071587268','886.200607158726825','test'),('2019-03-10 03:59:59','2019-03-11 15:59:59','WPRETH','4h','0.000089820000000','0.000086720000000','0.073368548266671','0.070836344975347','816.8397713946893','816.839771394689251','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','WPRETH','4h','0.000090000000000','0.000089840000000','0.073368548266671','0.073238115291975','815.2060918518999','815.206091851899942','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','WPRETH','4h','0.000092490000000','0.000089230000000','0.073368548266671','0.070782523103417','793.259252531852','793.259252531851985','test'),('2019-03-26 19:59:59','2019-03-29 11:59:59','WPRETH','4h','0.000094900000000','0.000094690000000','0.073368548266671','0.073206194261023','773.1143126098102','773.114312609810213','test'),('2019-03-29 15:59:59','2019-03-30 03:59:59','WPRETH','4h','0.000097190000000','0.000095880000000','0.073368548266671','0.072379631729688','754.8981198340467','754.898119834046724','test'),('2019-03-30 11:59:59','2019-04-02 03:59:59','WPRETH','4h','0.000100360000000','0.000097820000000','0.073368548266671','0.071511671895633','731.0536893849243','731.053689384924269','test'),('2019-05-23 07:59:59','2019-05-24 19:59:59','WPRETH','4h','0.000057430000000','0.000050470000000','0.073368548266671','0.064476939422234','1277.5300063846596','1277.530006384659600','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','WPRETH','4h','0.000053510000000','0.000048810000000','0.073368548266671','0.066924291551041','1371.1184501340122','1371.118450134012164','test'),('2019-06-06 11:59:59','2019-06-06 15:59:59','WPRETH','4h','0.000049530000000','0.000047760000000','0.073368548266671','0.070746655869497','1481.295139646093','1481.295139646093048','test'),('2019-06-06 19:59:59','2019-06-12 19:59:59','WPRETH','4h','0.000048010000000','0.000056820000000','0.073368548266671','0.086831929025458','1528.193048670506','1528.193048670505959','test'),('2019-06-15 07:59:59','2019-06-16 19:59:59','WPRETH','4h','0.000061740000000','0.000058160000000','0.073368548266671','0.069114265746511','1188.3470726704081','1188.347072670408124','test'),('2019-07-23 11:59:59','2019-07-24 03:59:59','WPRETH','4h','0.000033500000000','0.000033310000000','0.073368548266671','0.072952428142173','2190.1059184080896','2190.105918408089565','test'),('2019-07-24 07:59:59','2019-07-24 15:59:59','WPRETH','4h','0.000034320000000','0.000032780000000','0.073368548266671','0.070076369818808','2137.7782128983395','2137.778212898339461','test'),('2019-07-29 15:59:59','2019-07-30 11:59:59','WPRETH','4h','0.000034150000000','0.000033040000000','0.073368548266671','0.070983801895485','2148.420154221698','2148.420154221697885','test'),('2019-07-30 15:59:59','2019-07-31 03:59:59','WPRETH','4h','0.000033660000000','0.000033210000000','0.073368548266671','0.072387685321929','2179.6954327590906','2179.695432759090636','test'),('2019-07-31 11:59:59','2019-07-31 15:59:59','WPRETH','4h','0.000033200000000','0.000031520000000','0.073368548266671','0.069655922932695','2209.8960321286445','2209.896032128644492','test'),('2019-08-13 07:59:59','2019-08-15 15:59:59','WPRETH','4h','0.000032430000000','0.000028880000000','0.073368548266671','0.065337146899212','2262.366582382701','2262.366582382700926','test'),('2019-08-17 19:59:59','2019-08-18 23:59:59','WPRETH','4h','0.000031870000000','0.000029850000000','0.073368548266671','0.068718266889242','2302.1194937769374','2302.119493776937361','test'),('2019-08-19 03:59:59','2019-08-20 11:59:59','WPRETH','4h','0.000030300000000','0.000029920000000','0.073368548266671','0.072448414658046','2421.4042332234653','2421.404233223465326','test'),('2019-08-22 07:59:59','2019-08-23 15:59:59','WPRETH','4h','0.000030830000000','0.000030110000000','0.073368548266671','0.071655108281202','2379.777757595556','2379.777757595556068','test'),('2019-08-24 11:59:59','2019-08-25 15:59:59','WPRETH','4h','0.000033030000000','0.000032560000000','0.073368548266671','0.072324551364299','2221.270005046049','2221.270005046048936','test'),('2019-08-26 03:59:59','2019-08-28 11:59:59','WPRETH','4h','0.000032730000000','0.000034500000000','0.073368548266671','0.077336233278342','2241.6299500968835','2241.629950096883476','test'),('2019-09-10 11:59:59','2019-09-10 15:59:59','WPRETH','4h','0.000034070000000','0.000035000000000','0.073368548266671','0.075371270599750','2153.4648742785735','2153.464874278573461','test'),('2019-09-10 19:59:59','2019-09-11 23:59:59','WPRETH','4h','0.000035550000000','0.000032240000000','0.073368548266671','0.066537327598241','2063.812890764304','2063.812890764304029','test'),('2019-09-14 07:59:59','2019-09-14 11:59:59','WPRETH','4h','0.000034290000000','0.000033920000000','0.073368548266671','0.072576878308705','2139.648535044357','2139.648535044356777','test'),('2019-09-18 19:59:59','2019-09-20 03:59:59','WPRETH','4h','0.000039530000000','0.000034620000000','0.073368548266671','0.064255480419736','1856.021964752618','1856.021964752618032','test'),('2019-09-20 07:59:59','2019-09-20 15:59:59','WPRETH','4h','0.000035760000000','0.000034270000000','0.073368548266671','0.070311525422226','2051.693184191023','2051.693184191023192','test'),('2019-09-20 19:59:59','2019-09-24 15:59:59','WPRETH','4h','0.000035690000000','0.000037930000000','0.073368548266671','0.077973354882455','2055.717239189437','2055.717239189436896','test'),('2019-09-27 15:59:59','2019-09-30 23:59:59','WPRETH','4h','0.000038840000000','0.000038660000000','0.073368548266671','0.073028529247927','1888.9945485754633','1888.994548575463341','test'),('2019-10-03 07:59:59','2019-10-06 07:59:59','WPRETH','4h','0.000044030000000','0.000043560000000','0.073368548266671','0.072585372757124','1666.3308713756758','1666.330871375675770','test'),('2019-10-09 03:59:59','2019-10-09 15:59:59','WPRETH','4h','0.000044020000000','0.000039540000000','0.073368548266671','0.065901690105956','1666.7094108739434','1666.709410873943398','test'),('2019-10-18 23:59:59','2019-10-19 15:59:59','WPRETH','4h','0.000044030000000','0.000041970000000','0.073368548266671','0.069935906671637','1666.3308713756758','1666.330871375675770','test'),('2019-10-19 19:59:59','2019-10-19 23:59:59','WPRETH','4h','0.000043140000000','0.000042110000000','0.073368548266671','0.071616818903790','1700.7081193015995','1700.708119301599481','test'),('2019-10-20 03:59:59','2019-10-20 19:59:59','WPRETH','4h','0.000042680000000','0.000043740000000','0.073368548266671','0.075190728706284','1719.0381505780458','1719.038150578045816','test'),('2019-10-21 07:59:59','2019-10-24 19:59:59','WPRETH','4h','0.000043600000000','0.000047100000000','0.073368548266671','0.079258225306427','1682.7648685016281','1682.764868501628143','test'),('2019-11-17 07:59:59','2019-11-17 19:59:59','WPRETH','4h','0.000042240000000','0.000040190000000','0.073368548266671','0.069807811430812','1736.9447979799004','1736.944797979900386','test'),('2019-11-18 07:59:59','2019-11-18 15:59:59','WPRETH','4h','0.000040680000000','0.000039900000000','0.073368548266671','0.071961776692236','1803.5533005573009','1803.553300557300872','test'),('2019-11-19 07:59:59','2019-11-19 11:59:59','WPRETH','4h','0.000041890000000','0.000040190000000','0.073368548266671','0.070391070776737','1751.4573470200762','1751.457347020076213','test'),('2019-11-19 15:59:59','2019-11-20 03:59:59','WPRETH','4h','0.000040510000000','0.000040700000000','0.073368548266671','0.073712661428129','1811.1219024110344','1811.121902411034398','test'),('2019-11-20 11:59:59','2019-11-22 11:59:59','WPRETH','4h','0.000040810000000','0.000041180000000','0.073368548266671','0.074033737261002','1797.8080927878216','1797.808092787821579','test'),('2019-11-25 15:59:59','2019-11-27 19:59:59','WPRETH','4h','0.000044980000000','0.000043560000000','0.073368548266671','0.071052333537043','1631.1371335409292','1631.137133540929199','test'),('2019-11-28 11:59:59','2019-12-01 15:59:59','WPRETH','4h','0.000050270000000','0.000053730000000','0.073368548266671','0.078418382700780','1459.4897208408793','1459.489720840879272','test'),('2019-12-01 19:59:59','2019-12-02 07:59:59','WPRETH','4h','0.000058910000000','0.000055120000000','0.073368548266671','0.068648351391256','1245.4345317717025','1245.434531771702495','test'),('2019-12-02 15:59:59','2019-12-05 03:59:59','WPRETH','4h','0.000059250000000','0.000056510000000','0.073368548266671','0.069975639874254','1238.2877344585822','1238.287734458582236','test'),('2019-12-20 19:59:59','2019-12-21 07:59:59','WPRETH','4h','0.000051700000000','0.000051310000000','0.048912365511114','0.048543394088496','946.080570814584','946.080570814584007','test'),('2019-12-21 11:59:59','2019-12-22 11:59:59','WPRETH','4h','0.000051720000000','0.000050480000000','0.054436970260060','0.053131830215155','1052.5322942780363','1052.532294278036261','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 12:57:23
