-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 11:59:59','2019-01-03 11:59:59','NEOBTC','4h','0.002057000000000','0.002004000000000','0.001467500000000','0.001429688867282','0.7134175984443365','0.713417598444336','test'),('2019-01-05 23:59:59','2019-01-06 07:59:59','NEOBTC','4h','0.002046000000000','0.002010000000000','0.001467500000000','0.001441678885630','0.7172531769305963','0.717253176930596','test'),('2019-01-06 11:59:59','2019-01-10 11:59:59','NEOBTC','4h','0.002034000000000','0.002178000000000','0.001467500000000','0.001571393805310','0.7214847590953787','0.721484759095379','test'),('2019-01-19 19:59:59','2019-01-20 07:59:59','NEOBTC','4h','0.002174000000000','0.002135000000000','0.001477565389555','0.001451058926725','0.6796528930798067','0.679652893079807','test'),('2019-01-20 19:59:59','2019-01-20 23:59:59','NEOBTC','4h','0.002109000000000','0.002105000000000','0.001477565389555','0.001474762989575','0.7005999950474158','0.700599995047416','test'),('2019-01-23 11:59:59','2019-01-23 15:59:59','NEOBTC','4h','0.002116000000000','0.002109000000000','0.001477565389555','0.001472677413314','0.6982823202055766','0.698282320205577','test'),('2019-01-23 19:59:59','2019-01-23 23:59:59','NEOBTC','4h','0.002111000000000','0.002100000000000','0.001477565389555','0.001469866090983','0.6999362338015158','0.699936233801516','test'),('2019-01-24 19:59:59','2019-01-25 11:59:59','NEOBTC','4h','0.002124000000000','0.002107000000000','0.001477565389555','0.001465739301221','0.6956522549693973','0.695652254969397','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','NEOBTC','4h','0.002112000000000','0.002088000000000','0.001477565389555','0.001460774873765','0.6996048245999053','0.699604824599905','test'),('2019-02-08 15:59:59','2019-02-08 23:59:59','NEOBTC','4h','0.002115000000000','0.002061000000000','0.001477565389555','0.001439840315779','0.6986124773309692','0.698612477330969','test'),('2019-02-09 07:59:59','2019-02-14 11:59:59','NEOBTC','4h','0.002082000000000','0.002163000000000','0.001477565389555','0.001535049922002','0.7096855857612872','0.709685585761287','test'),('2019-02-15 19:59:59','2019-02-16 19:59:59','NEOBTC','4h','0.002243000000000','0.002210000000000','0.001477565389555','0.001455826799339','0.6587451580717788','0.658745158071779','test'),('2019-02-17 07:59:59','2019-02-20 07:59:59','NEOBTC','4h','0.002368000000000','0.002250000000000','0.001477565389555','0.001403936708825','0.6239718705891047','0.623971870589105','test'),('2019-02-20 11:59:59','2019-02-21 07:59:59','NEOBTC','4h','0.002291000000000','0.002261000000000','0.001477565389555','0.001458217086767','0.6449434262570929','0.644943426257093','test'),('2019-02-23 23:59:59','2019-02-26 19:59:59','NEOBTC','4h','0.002464000000000','0.002355000000000','0.001477565389555','0.001412202310228','0.5996612782284902','0.599661278228490','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','NEOBTC','4h','0.002313000000000','0.002266000000000','0.001477565389555','0.001447541363049','0.6388090746022481','0.638809074602248','test'),('2019-03-09 03:59:59','2019-03-09 07:59:59','NEOBTC','4h','0.002284000000000','0.002304000000000','0.001477565389555','0.001490503790514','0.6469200479662872','0.646920047966287','test'),('2019-03-14 15:59:59','2019-03-16 19:59:59','NEOBTC','4h','0.002341000000000','0.002340000000000','0.001477565389555','0.001476934221084','0.6311684705489107','0.631168470548911','test'),('2019-03-16 23:59:59','2019-03-17 03:59:59','NEOBTC','4h','0.002351000000000','0.002312000000000','0.001477565389555','0.001453054521757','0.6284837896873671','0.628483789687367','test'),('2019-03-17 15:59:59','2019-03-17 19:59:59','NEOBTC','4h','0.002355000000000','0.002327000000000','0.001477565389555','0.001459997733119','0.6274163012972399','0.627416301297240','test'),('2019-03-23 23:59:59','2019-03-24 03:59:59','NEOBTC','4h','0.002335000000000','0.002303000000000','0.001477565389555','0.001457316099420','0.6327903167259101','0.632790316725910','test'),('2019-03-24 11:59:59','2019-03-24 15:59:59','NEOBTC','4h','0.002294000000000','0.002282000000000','0.001477565389555','0.001469836189610','0.6440999954468177','0.644099995446818','test'),('2019-03-29 15:59:59','2019-04-02 07:59:59','NEOBTC','4h','0.002312000000000','0.002319000000000','0.001477565389555','0.001482038987188','0.6390853761051039','0.639085376105104','test'),('2019-04-03 15:59:59','2019-04-07 07:59:59','NEOBTC','4h','0.002500000000000','0.002555000000000','0.001477565389555','0.001510071828125','0.5910261558219999','0.591026155822000','test'),('2019-05-17 07:59:59','2019-05-18 11:59:59','NEOBTC','4h','0.001535000000000','0.001483000000000','0.001477565389555','0.001427511057140','0.9625833156710097','0.962583315671010','test'),('2019-05-18 15:59:59','2019-05-18 23:59:59','NEOBTC','4h','0.001500000000000','0.001476000000000','0.001477565389555','0.001453924343322','0.9850435930366666','0.985043593036667','test'),('2019-05-21 07:59:59','2019-05-22 11:59:59','NEOBTC','4h','0.001499000000000','0.001491000000000','0.001477565389555','0.001469679783740','0.9857007268545698','0.985700726854570','test'),('2019-05-22 19:59:59','2019-05-22 23:59:59','NEOBTC','4h','0.001486000000000','0.001462000000000','0.001477565389555','0.001453701614757','0.9943239499024227','0.994323949902423','test'),('2019-05-29 19:59:59','2019-06-03 07:59:59','NEOBTC','4h','0.001625000000000','0.001558000000000','0.001477565389555','0.001416644231955','0.909271008956923','0.909271008956923','test'),('2019-06-10 07:59:59','2019-06-11 03:59:59','NEOBTC','4h','0.001600000000000','0.001520000000000','0.001477565389555','0.001403687120077','0.9234783684718749','0.923478368471875','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','NEOBTC','4h','0.001526000000000','0.001522000000000','0.001477565389555','0.001473692347905','0.9682604125524246','0.968260412552425','test'),('2019-06-11 15:59:59','2019-06-12 11:59:59','NEOBTC','4h','0.001534000000000','0.001585000000000','0.001477565389555','0.001526689141098','0.9632108145730117','0.963210814573012','test'),('2019-06-12 19:59:59','2019-06-14 11:59:59','NEOBTC','4h','0.001585000000000','0.001555000000000','0.001477565389555','0.001449598852213','0.9322179113911672','0.932217911391167','test'),('2019-06-15 11:59:59','2019-06-16 03:59:59','NEOBTC','4h','0.001621000000000','0.001556000000000','0.001477565389555','0.001418316931615','0.9115147375416409','0.911514737541641','test'),('2019-06-24 03:59:59','2019-06-26 07:59:59','NEOBTC','4h','0.001558000000000','0.001561000000000','0.001477565389555','0.001480410509047','0.9483731640275995','0.948373164027600','test'),('2019-06-26 11:59:59','2019-06-26 15:59:59','NEOBTC','4h','0.001611000000000','0.001561000000000','0.001477565389555','0.001431706749283','0.9171728054345126','0.917172805434513','test'),('2019-07-01 19:59:59','2019-07-03 07:59:59','NEOBTC','4h','0.001576000000000','0.001559000000000','0.001477565389555','0.001461627184211','0.9375414908343909','0.937541490834391','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','NEOBTC','4h','0.001567000000000','0.001525000000000','0.001477565389555','0.001437962488240','0.9429262217964263','0.942926221796426','test'),('2019-08-23 11:59:59','2019-08-23 19:59:59','NEOBTC','4h','0.000977000000000','0.000948000000000','0.001477565389555','0.001433707256191','1.51234942636131','1.512349426361310','test'),('2019-08-23 23:59:59','2019-08-24 03:59:59','NEOBTC','4h','0.000951000000000','0.000955000000000','0.001477565389555','0.001483780175631','1.5536965189852785','1.553696518985278','test'),('2019-08-24 07:59:59','2019-08-25 19:59:59','NEOBTC','4h','0.000959000000000','0.000959000000000','0.001477565389555','0.001477565389555','1.5407355469812303','1.540735546981230','test'),('2019-09-16 03:59:59','2019-09-16 15:59:59','NEOBTC','4h','0.000888000000000','0.000878000000000','0.001477565389555','0.001460926139673','1.6639249882376126','1.663924988237613','test'),('2019-09-16 19:59:59','2019-09-20 11:59:59','NEOBTC','4h','0.000882000000000','0.000940000000000','0.001477565389555','0.001574729553494','1.6752442058446713','1.675244205844671','test'),('2019-09-30 23:59:59','2019-10-01 19:59:59','NEOBTC','4h','0.000917000000000','0.000903000000000','0.001477565389555','0.001455007139333','1.6113035873009816','1.611303587300982','test'),('2019-10-02 07:59:59','2019-10-02 15:59:59','NEOBTC','4h','0.000903000000000','0.000898000000000','0.001477565389555','0.001469383964364','1.636285038266888','1.636285038266888','test'),('2019-10-02 23:59:59','2019-10-03 07:59:59','NEOBTC','4h','0.000912000000000','0.000904000000000','0.001477565389555','0.001464604289647','1.620137488547149','1.620137488547149','test'),('2019-10-05 03:59:59','2019-10-05 11:59:59','NEOBTC','4h','0.000906000000000','0.000911000000000','0.001477565389555','0.001485719723934','1.630866875888521','1.630866875888521','test'),('2019-10-06 03:59:59','2019-10-06 19:59:59','NEOBTC','4h','0.000908000000000','0.000901000000000','0.001477565389555','0.001466174466948','1.6272746581002202','1.627274658100220','test'),('2019-10-06 23:59:59','2019-10-07 19:59:59','NEOBTC','4h','0.000908000000000','0.000905000000000','0.001477565389555','0.001472683565581','1.6272746581002202','1.627274658100220','test'),('2019-10-07 23:59:59','2019-10-08 11:59:59','NEOBTC','4h','0.000911000000000','0.000902000000000','0.001477565389555','0.001462968146409','1.6219159051097694','1.621915905109769','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','NEOBTC','4h','0.000917000000000','0.000890000000000','0.001477565389555','0.001434060192698','1.6113035873009816','1.611303587300982','test'),('2019-10-15 23:59:59','2019-10-16 07:59:59','NEOBTC','4h','0.000902000000000','0.000896000000000','0.001477565389555','0.001467736794946','1.6380991015022173','1.638099101502217','test'),('2019-10-19 03:59:59','2019-10-19 15:59:59','NEOBTC','4h','0.000900000000000','0.000890000000000','0.001477565389555','0.001461147996338','1.6417393217277778','1.641739321727778','test'),('2019-10-19 23:59:59','2019-10-20 19:59:59','NEOBTC','4h','0.000895000000000','0.000886000000000','0.001477565389555','0.001462707190107','1.6509110497821229','1.650911049782123','test'),('2019-10-21 23:59:59','2019-10-25 15:59:59','NEOBTC','4h','0.000902000000000','0.000906000000000','0.001477565389555','0.001484117785961','1.6380991015022173','1.638099101502217','test'),('2019-10-26 19:59:59','2019-10-31 19:59:59','NEOBTC','4h','0.000984000000000','0.001146000000000','0.001477565389555','0.001720823106128','1.501590843043699','1.501590843043699','test'),('2019-11-02 03:59:59','2019-11-06 03:59:59','NEOBTC','4h','0.001184000000000','0.001193000000000','0.001477565389555','0.001488796883226','1.2479437411782095','1.247943741178209','test'),('2019-11-08 11:59:59','2019-11-15 19:59:59','NEOBTC','4h','0.001201000000000','0.001407000000000','0.001477565389555','0.001731002916823','1.2302792585803497','1.230279258580350','test'),('2019-11-16 11:59:59','2019-11-17 11:59:59','NEOBTC','4h','0.001459000000000','0.001420000000000','0.001477565389555','0.001438069124858','1.012724735815627','1.012724735815627','test'),('2019-11-20 03:59:59','2019-11-21 07:59:59','NEOBTC','4h','0.001454000000000','0.001419000000000','0.001477565389555','0.001441998134648','1.0162072830502062','1.016207283050206','test'),('2019-11-21 11:59:59','2019-11-22 11:59:59','NEOBTC','4h','0.001429000000000','0.001395000000000','0.001477565389555','0.001442409879936','1.0339855770153954','1.033985577015395','test'),('2019-12-14 03:59:59','2019-12-16 19:59:59','NEOBTC','4h','0.001255000000000','0.001210000000000','0.001477565389555','0.001424584957260','1.1773429398844621','1.177342939884462','test'),('2019-12-29 03:59:59','2019-12-31 19:59:59','NEOBTC','4h','0.001224000000000','0.001208000000000','0.001477565389555','0.001458250809299','1.2071612659763071','1.207161265976307','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 18:02:48
