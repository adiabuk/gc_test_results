-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 19:59:59','2019-01-14 15:59:59','AMBETH','4h','0.000508640000000','0.000507000000000','0.072144500000000','0.071911885616546','141.8380386914124','141.838038691412407','test'),('2019-01-15 19:59:59','2019-01-20 11:59:59','AMBETH','4h','0.000540790000000','0.000552230000000','0.072144500000000','0.073670661874295','133.40575824257107','133.405758242571068','test'),('2019-01-22 15:59:59','2019-01-23 19:59:59','AMBETH','4h','0.000579710000000','0.000560410000000','0.072467886872710','0.070055249145841','125.0071361072092','125.007136107209206','test'),('2019-01-25 03:59:59','2019-01-27 07:59:59','AMBETH','4h','0.000593440000000','0.000579780000000','0.072467886872710','0.070799796864148','122.11493474101847','122.114934741018473','test'),('2019-03-02 07:59:59','2019-03-05 19:59:59','AMBETH','4h','0.000399790000000','0.000401440000000','0.072467886872710','0.072766973926763','181.2648812444283','181.264881244428295','test'),('2019-03-09 03:59:59','2019-03-10 07:59:59','AMBETH','4h','0.000415440000000','0.000398430000000','0.072467886872710','0.069500722527185','174.436469460596','174.436469460595987','test'),('2019-03-10 11:59:59','2019-03-11 07:59:59','AMBETH','4h','0.000409080000000','0.000403410000000','0.072467886872710','0.071463455175809','177.14844742522246','177.148447425222457','test'),('2019-03-11 15:59:59','2019-03-11 19:59:59','AMBETH','4h','0.000411980000000','0.000406160000000','0.072467886872710','0.071444140327734','175.9014682089179','175.901468208917890','test'),('2019-03-11 23:59:59','2019-03-12 01:59:59','AMBETH','4h','0.000417270000000','0.000408690000000','0.072467886872710','0.070977785812562','173.67145223167253','173.671452231672532','test'),('2019-03-12 11:59:59','2019-03-16 07:59:59','AMBETH','4h','0.000424500000000','0.000432230000000','0.072467886872710','0.073787502339202','170.7135144233451','170.713514423345089','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','AMBETH','4h','0.000433940000000','0.000407180000000','0.072467886872710','0.067998972615638','166.99978539132138','166.999785391321382','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','AMBETH','4h','0.000429080000000','0.000469970000000','0.072467886872710','0.079373852879574','168.89131833856158','168.891318338561575','test'),('2019-05-21 19:59:59','2019-05-21 23:59:59','AMBETH','4h','0.000187990000000','0.000191450000000','0.072467886872710','0.073801675311348','385.4879880456939','385.487988045693896','test'),('2019-05-22 15:59:59','2019-05-25 07:59:59','AMBETH','4h','0.000188630000000','0.000203610000000','0.072467886872710','0.078222904342642','384.18007142400467','384.180071424004666','test'),('2019-06-07 15:59:59','2019-06-09 15:59:59','AMBETH','4h','0.000207550000000','0.000186840000000','0.072612484071692','0.065366979156613','349.85537977206343','349.855379772063429','test'),('2019-06-10 15:59:59','2019-06-12 03:59:59','AMBETH','4h','0.000191500000000','0.000186870000000','0.072612484071692','0.070856892420246','379.17746251536295','379.177462515362947','test'),('2019-07-14 19:59:59','2019-07-17 15:59:59','AMBETH','4h','0.000131190000000','0.000129490000000','0.072612484071692','0.071671549374521','553.4909983359403','553.490998335940276','test'),('2019-07-19 11:59:59','2019-07-20 03:59:59','AMBETH','4h','0.000136260000000','0.000131980000000','0.072612484071692','0.070331686832393','532.8965512380156','532.896551238015604','test'),('2019-07-20 07:59:59','2019-07-20 19:59:59','AMBETH','4h','0.000140200000000','0.000134360000000','0.072612484071692','0.069587827103228','517.920713778117','517.920713778117033','test'),('2019-07-21 03:59:59','2019-07-21 07:59:59','AMBETH','4h','0.000134260000000','0.000134240000000','0.072612484071692','0.072601667375122','540.8348284797557','540.834828479755743','test'),('2019-07-21 11:59:59','2019-07-21 15:59:59','AMBETH','4h','0.000134620000000','0.000132500000000','0.072612484071692','0.071468980385524','539.3885312114991','539.388531211499071','test'),('2019-07-23 11:59:59','2019-07-23 19:59:59','AMBETH','4h','0.000137850000000','0.000134800000000','0.072612484071692','0.071005896647545','526.749975130156','526.749975130156031','test'),('2019-07-24 03:59:59','2019-07-24 15:59:59','AMBETH','4h','0.000135310000000','0.000133110000000','0.072612484071692','0.071431880531985','536.6379725939842','536.637972593984159','test'),('2019-07-24 19:59:59','2019-07-24 23:59:59','AMBETH','4h','0.000134570000000','0.000130940000000','0.072612484071692','0.070653776208273','539.5889430905254','539.588943090525390','test'),('2019-07-26 15:59:59','2019-07-26 19:59:59','AMBETH','4h','0.000136120000000','0.000134710000000','0.072612484071692','0.071860327132660','533.4446376116075','533.444637611607504','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','AMBETH','4h','0.000134680000000','0.000135010000000','0.072612484071692','0.072790402988708','539.1482333805465','539.148233380546458','test'),('2019-07-27 23:59:59','2019-07-28 03:59:59','AMBETH','4h','0.000134060000000','0.000133440000000','0.072612484071692','0.072276666228007','541.6416833633597','541.641683363359675','test'),('2019-07-28 11:59:59','2019-07-28 15:59:59','AMBETH','4h','0.000134540000000','0.000132940000000','0.072612484071692','0.071748949252941','539.7092617191319','539.709261719131860','test'),('2019-07-28 19:59:59','2019-07-29 07:59:59','AMBETH','4h','0.000138360000000','0.000137980000000','0.072612484071692','0.072413056896589','524.8083555340561','524.808355534056091','test'),('2019-07-29 11:59:59','2019-07-31 15:59:59','AMBETH','4h','0.000138690000000','0.000128560000000','0.072612484071692','0.067308825093783','523.559622695883','523.559622695883036','test'),('2019-08-13 03:59:59','2019-08-13 19:59:59','AMBETH','4h','0.000129910000000','0.000129180000000','0.072612484071692','0.072204454563784','558.9445313808944','558.944531380894432','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','AMBETH','4h','0.000129710000000','0.000128100000000','0.072612484071692','0.071711195818239','559.8063686045178','559.806368604517843','test'),('2019-08-14 19:59:59','2019-08-15 15:59:59','AMBETH','4h','0.000131120000000','0.000127490000000','0.072612484071692','0.070602239126754','553.7864862087554','553.786486208755377','test'),('2019-08-15 23:59:59','2019-08-16 07:59:59','AMBETH','4h','0.000128020000000','0.000126270000000','0.072612484071692','0.071619890358792','567.196407371442','567.196407371441978','test'),('2019-08-24 15:59:59','2019-08-25 15:59:59','AMBETH','4h','0.000128000000000','0.000128770000000','0.072612484071692','0.073049293546186','567.2850318100938','567.285031810093756','test'),('2019-08-26 07:59:59','2019-08-26 15:59:59','AMBETH','4h','0.000128930000000','0.000128270000000','0.072612484071692','0.072240776637524','563.193082073156','563.193082073156006','test'),('2019-08-26 19:59:59','2019-08-28 07:59:59','AMBETH','4h','0.000131440000000','0.000127620000000','0.072612484071692','0.070502169942402','552.4382537408095','552.438253740809500','test'),('2019-09-22 03:59:59','2019-09-23 23:59:59','AMBETH','4h','0.000099850000000','0.000097650000000','0.072612484071692','0.071012609610423','727.2156642132398','727.215664213239847','test'),('2019-09-24 07:59:59','2019-09-25 03:59:59','AMBETH','4h','0.000101050000000','0.000094790000000','0.072612484071692','0.068114174815989','718.5797533071944','718.579753307194437','test'),('2019-09-27 19:59:59','2019-09-27 23:59:59','AMBETH','4h','0.000099190000000','0.000096030000000','0.072612484071692','0.070299191908505','732.0544820212925','732.054482021292529','test'),('2019-09-28 03:59:59','2019-09-29 11:59:59','AMBETH','4h','0.000099130000000','0.000100200000000','0.072612484071692','0.073396256471134','732.4975695721982','732.497569572198245','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','AMBETH','4h','0.000096900000000','0.000096300000000','0.072612484071692','0.072162871167223','749.3548407811353','749.354840781135294','test'),('2019-10-01 11:59:59','2019-10-16 15:59:59','AMBETH','4h','0.000098660000000','0.000189790000000','0.072612484071692','0.139682985525709','735.9870674203528','735.987067420352787','test'),('2019-10-17 11:59:59','2019-10-18 03:59:59','AMBETH','4h','0.000203990000000','0.000191030000000','0.078665342832125','0.073667534885146','385.6333292422434','385.633329242243406','test'),('2019-10-21 15:59:59','2019-10-22 23:59:59','AMBETH','4h','0.000200810000000','0.000191220000000','0.078665342832125','0.074908554635521','391.74016648635524','391.740166486355236','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','AMBETH','4h','0.000194910000000','0.000187350000000','0.078665342832125','0.075614139754752','403.5982906578677','403.598290657867722','test'),('2019-10-30 07:59:59','2019-10-30 15:59:59','AMBETH','4h','0.000176700000000','0.000174280000000','0.078665342832125','0.077587979336631','445.19152706352565','445.191527063525655','test'),('2019-10-30 19:59:59','2019-11-02 15:59:59','AMBETH','4h','0.000180470000000','0.000181540000000','0.078665342832125','0.079131746759816','435.89152120643314','435.891521206433140','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','AMBETH','4h','0.000161270000000','0.000160300000000','0.078665342832125','0.078192189843056','487.78658666909524','487.786586669095243','test'),('2019-11-16 03:59:59','2019-11-16 11:59:59','AMBETH','4h','0.000162250000000','0.000160820000000','0.078665342832125','0.077972021166486','484.84032562172575','484.840325621725754','test'),('2019-11-16 15:59:59','2019-11-16 19:59:59','AMBETH','4h','0.000161020000000','0.000158980000000','0.078665342832125','0.077668713224762','488.5439251777729','488.543925177772905','test'),('2019-11-17 03:59:59','2019-11-17 11:59:59','AMBETH','4h','0.000164080000000','0.000160330000000','0.078665342832125','0.076867469626247','479.4328549008106','479.432854900810582','test'),('2019-11-25 15:59:59','2019-11-25 23:59:59','AMBETH','4h','0.000182420000000','0.000158770000000','0.078665342832125','0.068466705851642','431.23200763142745','431.232007631427450','test'),('2019-11-26 03:59:59','2019-11-27 03:59:59','AMBETH','4h','0.000162240000000','0.000153890000000','0.078665342832125','0.074616676580595','484.87020976408405','484.870209764084052','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','AMBETH','4h','0.000159620000000','0.000154090000000','0.078665342832125','0.075939999229433','492.82886124624105','492.828861246241047','test'),('2019-11-29 07:59:59','2019-11-29 15:59:59','AMBETH','4h','0.000157690000000','0.000153100000000','0.078665342832125','0.076375572246803','498.8606939699727','498.860693969972715','test'),('2019-11-30 07:59:59','2019-11-30 11:59:59','AMBETH','4h','0.000156290000000','0.000154080000000','0.078665342832125','0.077552984986716','503.3293418140955','503.329341814095528','test'),('2019-12-03 11:59:59','2019-12-03 15:59:59','AMBETH','4h','0.000155240000000','0.000153370000000','0.078665342832125','0.077717750774047','506.73372089748125','506.733720897481248','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  8:48:17
