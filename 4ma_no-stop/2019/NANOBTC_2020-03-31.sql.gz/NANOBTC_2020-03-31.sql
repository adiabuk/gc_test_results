-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 23:59:59','2019-01-10 11:59:59','NANOBTC','4h','0.000256900000000','0.000241700000000','0.001467500000000','0.001380672440638','5.71233943168548','5.712339431685480','test'),('2019-01-10 15:59:59','2019-01-10 19:59:59','NANOBTC','4h','0.000244800000000','0.000243300000000','0.001467500000000','0.001458507965686','5.994689542483661','5.994689542483661','test'),('2019-01-20 11:59:59','2019-01-20 15:59:59','NANOBTC','4h','0.000243800000000','0.000244100000000','0.001467500000000','0.001469305783429','6.019278096800657','6.019278096800657','test'),('2019-01-21 03:59:59','2019-01-21 15:59:59','NANOBTC','4h','0.000246300000000','0.000247300000000','0.001467500000000','0.001473458181080','5.958181079983759','5.958181079983759','test'),('2019-01-21 19:59:59','2019-01-22 15:59:59','NANOBTC','4h','0.000248400000000','0.000246100000000','0.001467500000000','0.001453912037037','5.90780998389694','5.907809983896940','test'),('2019-01-22 19:59:59','2019-01-27 11:59:59','NANOBTC','4h','0.000250700000000','0.000268900000000','0.001467500000000','0.001574035700040','5.853609892301555','5.853609892301555','test'),('2019-02-13 23:59:59','2019-02-14 11:59:59','NANOBTC','4h','0.000236900000000','0.000232800000000','0.001468723026977','0.001443304013002','6.199759506025749','6.199759506025749','test'),('2019-02-18 03:59:59','2019-02-18 11:59:59','NANOBTC','4h','0.000236500000000','0.000232500000000','0.001468723026977','0.001443882045548','6.210245357196617','6.210245357196617','test'),('2019-02-18 15:59:59','2019-02-18 19:59:59','NANOBTC','4h','0.000234600000000','0.000235600000000','0.001468723026977','0.001474983568439','6.260541461965047','6.260541461965047','test'),('2019-02-24 07:59:59','2019-02-24 15:59:59','NANOBTC','4h','0.000238900000000','0.000230500000000','0.001468723026977','0.001417081028540','6.147856956789451','6.147856956789451','test'),('2019-03-02 11:59:59','2019-03-03 23:59:59','NANOBTC','4h','0.000233600000000','0.000231700000000','0.001468723026977','0.001456777077699','6.287341725072774','6.287341725072774','test'),('2019-03-10 07:59:59','2019-03-11 23:59:59','NANOBTC','4h','0.000241500000000','0.000232200000000','0.001468723026977','0.001412163506683','6.0816688487660455','6.081668848766046','test'),('2019-03-12 01:59:59','2019-03-12 11:59:59','NANOBTC','4h','0.000234100000000','0.000244200000000','0.001468723026977','0.001532089548004','6.273912972990175','6.273912972990175','test'),('2019-03-12 19:59:59','2019-03-16 11:59:59','NANOBTC','4h','0.000249000000000','0.000252500000000','0.001468723026977','0.001489367728159','5.898486052116466','5.898486052116466','test'),('2019-03-17 23:59:59','2019-03-18 11:59:59','NANOBTC','4h','0.000257600000000','0.000250100000000','0.001468723026977','0.001425961292884','5.701564545718168','5.701564545718168','test'),('2019-03-28 15:59:59','2019-03-31 11:59:59','NANOBTC','4h','0.000252700000000','0.000258600000000','0.001468723026977','0.001503014542051','5.81212119895924','5.812121198959240','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','NANOBTC','4h','0.000268500000000','0.000264900000000','0.001468723026977','0.001449030651196','5.470104383527001','5.470104383527001','test'),('2019-04-02 11:59:59','2019-04-03 23:59:59','NANOBTC','4h','0.000283900000000','0.000273100000000','0.001468723026977','0.001412850506049','5.173381567372314','5.173381567372314','test'),('2019-04-04 03:59:59','2019-04-04 11:59:59','NANOBTC','4h','0.000274100000000','0.000279000000000','0.001468723026977','0.001494978929320','5.358347416917184','5.358347416917184','test'),('2019-04-05 15:59:59','2019-04-06 19:59:59','NANOBTC','4h','0.000286800000000','0.000275000000000','0.001468723026977','0.001408294394765','5.121070526419108','5.121070526419108','test'),('2019-04-08 07:59:59','2019-04-11 03:59:59','NANOBTC','4h','0.000313700000000','0.000293600000000','0.001468723026977','0.001374616132357','4.681935055712464','4.681935055712464','test'),('2019-04-12 23:59:59','2019-04-13 19:59:59','NANOBTC','4h','0.000322900000000','0.000306300000000','0.001468723026977','0.001393217290688','4.548538330681326','4.548538330681326','test'),('2019-04-15 07:59:59','2019-04-15 15:59:59','NANOBTC','4h','0.000312300000000','0.000305700000000','0.001468723026977','0.001437683731498','4.702923557403138','4.702923557403138','test'),('2019-04-17 23:59:59','2019-04-21 11:59:59','NANOBTC','4h','0.000309300000000','0.000306000000000','0.001468723026977','0.001453052849192','4.748538722848368','4.748538722848368','test'),('2019-04-22 03:59:59','2019-04-24 11:59:59','NANOBTC','4h','0.000319100000000','0.000316900000000','0.001468723026977','0.001458597076932','4.602704565894704','4.602704565894704','test'),('2019-06-13 23:59:59','2019-06-14 11:59:59','NANOBTC','4h','0.000214000000000','0.000195000000000','0.001468723026977','0.001338322384395','6.863191714845795','6.863191714845795','test'),('2019-07-18 11:59:59','2019-07-18 19:59:59','NANOBTC','4h','0.000116300000000','0.000104400000000','0.001468723026977','0.001318440963168','12.628744857927773','12.628744857927773','test'),('2019-07-19 11:59:59','2019-07-19 15:59:59','NANOBTC','4h','0.000103500000000','0.000104400000000','0.001468723026977','0.001481494531559','14.190560647120773','14.190560647120773','test'),('2019-07-19 19:59:59','2019-07-19 23:59:59','NANOBTC','4h','0.000105800000000','0.000105000000000','0.001468723026977','0.001457617370818','13.882070198270322','13.882070198270322','test'),('2019-07-20 03:59:59','2019-07-20 11:59:59','NANOBTC','4h','0.000106400000000','0.000104700000000','0.001468723026977','0.001445256587636','13.803787847528195','13.803787847528195','test'),('2019-07-20 23:59:59','2019-07-30 07:59:59','NANOBTC','4h','0.000110800000000','0.000135800000000','0.001468723026977','0.001800113601656','13.25562298715704','13.255622987157039','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','NANOBTC','4h','0.000104500000000','0.000100900000000','0.001468723026977','0.001418125870067','14.054765808392343','14.054765808392343','test'),('2019-08-22 15:59:59','2019-08-23 15:59:59','NANOBTC','4h','0.000102100000000','0.000099800000000','0.001468723026977','0.001435637199729','14.385142281851126','14.385142281851126','test'),('2019-08-24 11:59:59','2019-08-25 15:59:59','NANOBTC','4h','0.000100900000000','0.000101800000000','0.001468723026977','0.001481823628803','14.556224251506443','14.556224251506443','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','NANOBTC','4h','0.000101700000000','0.000101000000000','0.001468723026977','0.001458613822268','14.441721012556538','14.441721012556538','test'),('2019-08-30 23:59:59','2019-08-31 11:59:59','NANOBTC','4h','0.000101500000000','0.000100200000000','0.001468723026977','0.001449911796090','14.470177605684729','14.470177605684729','test'),('2019-08-31 15:59:59','2019-08-31 19:59:59','NANOBTC','4h','0.000100300000000','0.000099800000000','0.001468723026977','0.001461401376793','14.643300368664008','14.643300368664008','test'),('2019-09-18 15:59:59','2019-09-22 19:59:59','NANOBTC','4h','0.000094400000000','0.000090000000000','0.001468723026977','0.001400265597753','15.558506641705508','15.558506641705508','test'),('2019-09-26 23:59:59','2019-09-27 03:59:59','NANOBTC','4h','0.000093000000000','0.000092000000000','0.001468723026977','0.001452930306257','15.792720720182796','15.792720720182796','test'),('2019-09-27 15:59:59','2019-09-27 19:59:59','NANOBTC','4h','0.000090500000000','0.000090600000000','0.001468723026977','0.001470345925349','16.22898372350276','16.228983723502761','test'),('2019-10-05 03:59:59','2019-10-06 11:59:59','NANOBTC','4h','0.000090900000000','0.000091300000000','0.001468723026977','0.001475186054598','16.157569053652363','16.157569053652363','test'),('2019-10-06 19:59:59','2019-10-06 23:59:59','NANOBTC','4h','0.000090600000000','0.000091100000000','0.001468723026977','0.001476828562446','16.21107093793598','16.211070937935979','test'),('2019-10-07 03:59:59','2019-10-07 19:59:59','NANOBTC','4h','0.000091700000000','0.000091200000000','0.001468723026977','0.001460714722577','16.016608800185384','16.016608800185384','test'),('2019-10-07 23:59:59','2019-10-09 15:59:59','NANOBTC','4h','0.000092100000000','0.000093200000000','0.001468723026977','0.001486264778656','15.947046981292074','15.947046981292074','test'),('2019-10-09 23:59:59','2019-10-10 07:59:59','NANOBTC','4h','0.000094600000000','0.000092600000000','0.001468723026977','0.001437671800191','15.525613392991543','15.525613392991543','test'),('2019-10-12 23:59:59','2019-10-19 03:59:59','NANOBTC','4h','0.000093300000000','0.000098500000000','0.001468723026977','0.001550581116369','15.741940267706322','15.741940267706322','test'),('2019-10-20 15:59:59','2019-10-20 19:59:59','NANOBTC','4h','0.000102900000000','0.000098000000000','0.001468723026977','0.001398783835216','14.273304440981535','14.273304440981535','test'),('2019-10-24 19:59:59','2019-10-25 15:59:59','NANOBTC','4h','0.000101100000000','0.000097500000000','0.001468723026977','0.001416424284177','14.527428555657764','14.527428555657764','test'),('2019-11-04 23:59:59','2019-11-05 11:59:59','NANOBTC','4h','0.000097900000000','0.000097100000000','0.001468723026977','0.001456721204489','15.002278110081717','15.002278110081717','test'),('2019-11-05 15:59:59','2019-11-13 23:59:59','NANOBTC','4h','0.000102600000000','0.000113000000000','0.001468723026977','0.001617599435170','14.315039249288498','14.315039249288498','test'),('2019-11-21 03:59:59','2019-11-22 07:59:59','NANOBTC','4h','0.000112600000000','0.000109700000000','0.001468723026977','0.001430896234986','13.043721376349911','13.043721376349911','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','NANOBTC','4h','0.000110900000000','0.000109300000000','0.001468723026977','0.001447533154631','13.243670216203787','13.243670216203787','test'),('2019-11-26 19:59:59','2019-11-27 19:59:59','NANOBTC','4h','0.000112000000000','0.000110600000000','0.001468723026977','0.001450363989140','13.113598455151786','13.113598455151786','test'),('2019-11-27 23:59:59','2019-11-28 03:59:59','NANOBTC','4h','0.000110900000000','0.000109600000000','0.001468723026977','0.001451506255696','13.243670216203787','13.243670216203787','test'),('2019-11-28 07:59:59','2019-11-28 23:59:59','NANOBTC','4h','0.000111200000000','0.000110800000000','0.001468723026977','0.001463439850621','13.207940890080934','13.207940890080934','test'),('2019-11-29 03:59:59','2019-11-30 15:59:59','NANOBTC','4h','0.000113300000000','0.000113400000000','0.001468723026977','0.001470019340328','12.96313351259488','12.963133512594879','test'),('2019-11-30 23:59:59','2019-12-02 23:59:59','NANOBTC','4h','0.000118200000000','0.000114600000000','0.001468723026977','0.001423990345952','12.425744729077834','12.425744729077834','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:47:43
