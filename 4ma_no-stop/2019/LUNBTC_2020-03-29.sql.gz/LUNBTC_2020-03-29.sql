-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 03:59:59','2019-01-09 07:59:59','LUNBTC','4h','0.000416900000000','0.000416500000000','0.001467500000000','0.001466091988486','3.5200287838810267','3.520028783881027','test'),('2019-01-09 19:59:59','2019-01-09 23:59:59','LUNBTC','4h','0.000414100000000','0.000411000000000','0.001467500000000','0.001456514127022','3.5438299927553736','3.543829992755374','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','LUNBTC','4h','0.000414000000000','0.000405100000000','0.001467500000000','0.001435952294686','3.5446859903381647','3.544685990338165','test'),('2019-01-17 11:59:59','2019-01-20 23:59:59','LUNBTC','4h','0.000413400000000','0.000445700000000','0.001467500000000','0.001582159530721','3.549830672472182','3.549830672472182','test'),('2019-01-21 15:59:59','2019-01-25 07:59:59','LUNBTC','4h','0.000480900000000','0.000602700000000','0.001485179485229','0.001861338481488','3.0883333026174884','3.088333302617488','test'),('2019-02-11 07:59:59','2019-02-12 03:59:59','LUNBTC','4h','0.000492800000000','0.000474000000000','0.001579219234293','0.001518973045972','3.204584485173498','3.204584485173498','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','LUNBTC','4h','0.000477000000000','0.000472900000000','0.001579219234293','0.001565645232489','3.3107321473647797','3.310732147364780','test'),('2019-02-17 19:59:59','2019-02-18 03:59:59','LUNBTC','4h','0.000533200000000','0.000472900000000','0.001579219234293','0.001400624110835','2.9617765084264818','2.961776508426482','test'),('2019-02-18 07:59:59','2019-02-18 11:59:59','LUNBTC','4h','0.000474900000000','0.000481200000000','0.001579219234293','0.001600169078841','3.3253721505432723','3.325372150543272','test'),('2019-02-19 19:59:59','2019-02-19 23:59:59','LUNBTC','4h','0.000484100000000','0.000473400000000','0.001579219234293','0.001544313954791','3.2621756543957856','3.262175654395786','test'),('2019-02-20 11:59:59','2019-02-21 11:59:59','LUNBTC','4h','0.000482400000000','0.000469200000000','0.001579219234293','0.001536006767683','3.273671712879353','3.273671712879353','test'),('2019-02-22 15:59:59','2019-02-24 15:59:59','LUNBTC','4h','0.000482400000000','0.000490200000000','0.001579219234293','0.001604753873653','3.273671712879353','3.273671712879353','test'),('2019-02-26 11:59:59','2019-02-28 11:59:59','LUNBTC','4h','0.000591500000000','0.000519900000000','0.001579219234293','0.001388057616076','2.669855003031276','2.669855003031276','test'),('2019-03-01 15:59:59','2019-03-02 11:59:59','LUNBTC','4h','0.000582200000000','0.000539200000000','0.001579219234293','0.001462581606202','2.7125029788612163','2.712502978861216','test'),('2019-03-06 07:59:59','2019-03-06 11:59:59','LUNBTC','4h','0.000539100000000','0.000533500000000','0.001579219234293','0.001562814805222','2.9293623340623256','2.929362334062326','test'),('2019-03-06 15:59:59','2019-03-08 23:59:59','LUNBTC','4h','0.000544500000000','0.000543900000000','0.001579219234293','0.001577479047809','2.900310806782369','2.900310806782369','test'),('2019-03-09 23:59:59','2019-03-12 01:59:59','LUNBTC','4h','0.000570300000000','0.000573800000000','0.001579219234293','0.001588911093525','2.769102637722251','2.769102637722251','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','LUNBTC','4h','0.000640900000000','0.000635200000000','0.001579219234293','0.001565174064008','2.464064962229677','2.464064962229677','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','LUNBTC','4h','0.000686500000000','0.000624100000000','0.001579219234293','0.001435674762013','2.3003921839664963','2.300392183966496','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','LUNBTC','4h','0.000627400000000','0.000639000000000','0.001579219234293','0.001608417422240','2.5170851678243547','2.517085167824355','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','LUNBTC','4h','0.000627300000000','0.000630100000000','0.001579219234293','0.001586268196283','2.5174864248254423','2.517486424825442','test'),('2019-03-22 15:59:59','2019-03-24 07:59:59','LUNBTC','4h','0.000640500000000','0.000628000000000','0.001579219234293','0.001548399186785','2.4656038006135828','2.465603800613583','test'),('2019-03-26 11:59:59','2019-04-01 19:59:59','LUNBTC','4h','0.000670800000000','0.000713900000000','0.001579219234293','0.001680686659752','2.3542326092620747','2.354232609262075','test'),('2019-05-22 15:59:59','2019-05-24 15:59:59','LUNBTC','4h','0.000391700000000','0.000344600000000','0.001579219234293','0.001389325882403','4.031705984919581','4.031705984919581','test'),('2019-06-06 11:59:59','2019-06-06 19:59:59','LUNBTC','4h','0.000319200000000','0.000315700000000','0.001579219234293','0.001561903233917','4.9474286788627815','4.947428678862781','test'),('2019-06-07 15:59:59','2019-06-09 23:59:59','LUNBTC','4h','0.000314700000000','0.000315900000000','0.001579219234293','0.001585241042622','5.018173607540515','5.018173607540515','test'),('2019-06-10 03:59:59','2019-06-11 11:59:59','LUNBTC','4h','0.000318900000000','0.000317300000000','0.001579219234293','0.001571295901666','4.952082892107243','4.952082892107243','test'),('2019-06-11 15:59:59','2019-06-13 19:59:59','LUNBTC','4h','0.000322400000000','0.000325200000000','0.001579219234293','0.001592934537817','4.898322687013027','4.898322687013027','test'),('2019-07-24 07:59:59','2019-07-25 03:59:59','LUNBTC','4h','0.000153300000000','0.000142500000000','0.001579219234293','0.001467963084715','10.301495331330722','10.301495331330722','test'),('2019-07-25 11:59:59','2019-07-31 03:59:59','LUNBTC','4h','0.000142700000000','0.000147500000000','0.001579219234293','0.001632339432784','11.066708018871758','11.066708018871758','test'),('2019-08-13 19:59:59','2019-08-14 19:59:59','LUNBTC','4h','0.000116700000000','0.000108800000000','0.001579219234293','0.001472314076187','13.53229849437018','13.532298494370179','test'),('2019-08-14 23:59:59','2019-08-15 11:59:59','LUNBTC','4h','0.000110500000000','0.000102900000000','0.001579219234293','0.001470603250758','14.291576780932125','14.291576780932125','test'),('2019-08-23 11:59:59','2019-08-26 03:59:59','LUNBTC','4h','0.000105000000000','0.000106900000000','0.001579219234293','0.001607795582342','15.040183183742856','15.040183183742856','test'),('2019-08-26 07:59:59','2019-08-27 15:59:59','LUNBTC','4h','0.000114200000000','0.000111200000000','0.001579219234293','0.001537733615178','13.828539704842381','13.828539704842381','test'),('2019-08-27 19:59:59','2019-08-28 11:59:59','LUNBTC','4h','0.000113200000000','0.000110900000000','0.001579219234293','0.001547132624409','13.950699949584806','13.950699949584806','test'),('2019-09-11 03:59:59','2019-09-12 03:59:59','LUNBTC','4h','0.000102200000000','0.000094300000000','0.001579219234293','0.001457146514617','15.452242996996084','15.452242996996084','test'),('2019-09-12 07:59:59','2019-09-12 15:59:59','LUNBTC','4h','0.000095300000000','0.000093700000000','0.001579219234293','0.001552705585029','16.57103079006296','16.571030790062959','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','LUNBTC','4h','0.000095800000000','0.000092100000000','0.001579219234293','0.001518226424618','16.48454315545929','16.484543155459288','test'),('2019-09-14 23:59:59','2019-09-22 07:59:59','LUNBTC','4h','0.000096900000000','0.000105900000000','0.001579219234293','0.001725895943360','16.29741211860681','16.297412118606811','test'),('2019-09-22 15:59:59','2019-09-23 03:59:59','LUNBTC','4h','0.000113100000000','0.000105100000000','0.001579219234293','0.001467514956005','13.96303478596817','13.963034785968169','test'),('2019-09-23 11:59:59','2019-09-23 23:59:59','LUNBTC','4h','0.000112700000000','0.000106100000000','0.001579219234293','0.001486736120306','14.012593028331853','14.012593028331853','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','LUNBTC','4h','0.000111900000000','0.000105100000000','0.001579219234293','0.001483252381807','14.112772424423593','14.112772424423593','test'),('2019-09-27 11:59:59','2019-09-28 23:59:59','LUNBTC','4h','0.000109000000000','0.000110100000000','0.001579219234293','0.001595156309134','14.488249855899081','14.488249855899081','test'),('2019-09-29 03:59:59','2019-09-29 11:59:59','LUNBTC','4h','0.000111200000000','0.000106400000000','0.001579219234293','0.001511051497561','14.201611819181654','14.201611819181654','test'),('2019-10-01 19:59:59','2019-10-09 15:59:59','LUNBTC','4h','0.000109300000000','0.000122500000000','0.001052812822862','0.001179959476675','9.632322258572735','9.632322258572735','test'),('2019-10-22 15:59:59','2019-10-22 19:59:59','LUNBTC','4h','0.000114200000000','0.000113100000000','0.001215922993744','0.001204210950897','10.647311679014894','10.647311679014894','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','LUNBTC','4h','0.000117300000000','0.000115000000000','0.001215922993744','0.001192081366416','10.365924925353793','10.365924925353793','test'),('2019-10-23 19:59:59','2019-10-24 03:59:59','LUNBTC','4h','0.000116800000000','0.000114000000000','0.001215922993744','0.001186774154853','10.410299603972602','10.410299603972602','test'),('2019-10-24 07:59:59','2019-10-25 03:59:59','LUNBTC','4h','0.000115700000000','0.000114700000000','0.001215922993744','0.001205413719814','10.509273930371652','10.509273930371652','test'),('2019-10-29 11:59:59','2019-10-31 15:59:59','LUNBTC','4h','0.000136300000000','0.000117600000000','0.001215922993744','0.001049101570538','8.92093172225972','8.920931722259720','test'),('2019-11-01 07:59:59','2019-11-02 11:59:59','LUNBTC','4h','0.000123400000000','0.000119800000000','0.001215922993744','0.001180450361836','9.853508863403567','9.853508863403567','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','LUNBTC','4h','0.000121300000000','0.000119600000000','0.001215922993744','0.001198882028457','10.024097227897775','10.024097227897775','test'),('2019-11-12 07:59:59','2019-11-13 07:59:59','LUNBTC','4h','0.000117900000000','0.000116300000000','0.001215922993744','0.001199421918341','10.313172126751484','10.313172126751484','test'),('2019-11-13 15:59:59','2019-11-14 07:59:59','LUNBTC','4h','0.000116400000000','0.000115800000000','0.001215922993744','0.001209655349446','10.446073829415807','10.446073829415807','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','LUNBTC','4h','0.000117600000000','0.000118500000000','0.001215922993744','0.001225228526859','10.339481239319728','10.339481239319728','test'),('2019-11-17 15:59:59','2019-11-21 15:59:59','LUNBTC','4h','0.000119000000000','0.000122000000000','0.001215922993744','0.001246576514595','10.217840283563024','10.217840283563024','test'),('2019-11-21 19:59:59','2019-11-22 11:59:59','LUNBTC','4h','0.000130500000000','0.000125000000000','0.001215922993744','0.001164677197073','9.317417576582375','9.317417576582375','test'),('2019-11-25 15:59:59','2019-11-27 23:59:59','LUNBTC','4h','0.000135100000000','0.000131800000000','0.001215922993744','0.001186222432091','9.000170197957068','9.000170197957068','test'),('2019-11-28 19:59:59','2019-11-29 03:59:59','LUNBTC','4h','0.000137600000000','0.000132800000000','0.001215922993744','0.001173507075358','8.836649663837209','8.836649663837209','test'),('2019-12-03 03:59:59','2019-12-03 19:59:59','LUNBTC','4h','0.000137600000000','0.000131000000000','0.001215922993744','0.001157601105963','8.836649663837209','8.836649663837209','test'),('2019-12-22 03:59:59','2019-12-23 19:59:59','LUNBTC','4h','0.000127400000000','0.000120700000000','0.001215922993744','0.001151977279002','9.544136528602825','9.544136528602825','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  3:26:32
