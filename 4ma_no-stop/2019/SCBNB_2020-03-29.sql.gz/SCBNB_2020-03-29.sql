-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-31 03:59:59','2019-01-31 15:59:59','SCBNB','4h','0.000385000000000','0.000378000000000','0.711908500000000','0.698964709090909','1849.1129870129873','1849.112987012987332','test'),('2019-02-26 19:59:59','2019-02-27 07:59:59','SCBNB','4h','0.000257000000000','0.000248000000000','0.711908500000000','0.686977852140078','2770.0719844357977','2770.071984435797731','test'),('2019-03-21 07:59:59','2019-03-22 11:59:59','SCBNB','4h','0.000183000000000','0.000178000000000','0.711908500000000','0.692457448087432','3890.2103825136614','3890.210382513661443','test'),('2019-04-03 19:59:59','2019-04-04 23:59:59','SCBNB','4h','0.000182000000000','0.000170000000000','0.711908500000000','0.664969478021978','3911.585164835165','3911.585164835164960','test'),('2019-04-05 03:59:59','2019-04-10 15:59:59','SCBNB','4h','0.000171000000000','0.000190000000000','0.711908500000000','0.791009444444445','4163.207602339181','4163.207602339180994','test'),('2019-04-10 19:59:59','2019-04-10 23:59:59','SCBNB','4h','0.000193000000000','0.000189000000000','0.711908500000000','0.697153919689119','3688.6450777202076','3688.645077720207610','test'),('2019-05-08 23:59:59','2019-05-09 03:59:59','SCBNB','4h','0.000125000000000','0.000120000000000','0.711908500000000','0.683432160000000','5695.268','5695.268000000000029','test'),('2019-05-09 23:59:59','2019-05-11 15:59:59','SCBNB','4h','0.000127000000000','0.000125000000000','0.711908500000000','0.700697342519685','5605.578740157481','5605.578740157480752','test'),('2019-05-11 19:59:59','2019-05-13 07:59:59','SCBNB','4h','0.000149000000000','0.000126000000000','0.711908500000000','0.602016583892618','4777.909395973155','4777.909395973155370','test'),('2019-05-16 15:59:59','2019-05-17 03:59:59','SCBNB','4h','0.000138000000000','0.000131000000000','0.711908500000000','0.675797199275362','5158.757246376812','5158.757246376811963','test'),('2019-06-03 03:59:59','2019-06-03 15:59:59','SCBNB','4h','0.000112000000000','0.000108000000000','0.711908500000000','0.686483196428571','6356.325892857143','6356.325892857143117','test'),('2019-06-03 19:59:59','2019-06-04 03:59:59','SCBNB','4h','0.000112000000000','0.000108000000000','0.711908500000000','0.686483196428571','6356.325892857143','6356.325892857143117','test'),('2019-06-26 11:59:59','2019-06-27 19:59:59','SCBNB','4h','0.000093000000000','0.000092000000000','0.711908500000000','0.704253569892473','7654.930107526882','7654.930107526882239','test'),('2019-06-28 15:59:59','2019-06-29 19:59:59','SCBNB','4h','0.000095000000000','0.000093000000000','0.711908500000000','0.696920952631579','7493.773684210527','7493.773684210526881','test'),('2019-06-30 03:59:59','2019-07-02 07:59:59','SCBNB','4h','0.000097000000000','0.000093000000000','0.711908500000000','0.682551448453608','7339.262886597939','7339.262886597938632','test'),('2019-07-07 07:59:59','2019-07-07 23:59:59','SCBNB','4h','0.000097000000000','0.000094000000000','0.711908500000000','0.689890711340206','7339.262886597939','7339.262886597938632','test'),('2019-07-08 03:59:59','2019-07-08 07:59:59','SCBNB','4h','0.000095000000000','0.000092000000000','0.711908500000000','0.689427178947368','7493.773684210527','7493.773684210526881','test'),('2019-07-08 11:59:59','2019-07-08 15:59:59','SCBNB','4h','0.000093000000000','0.000093000000000','0.711908500000000','0.711908500000000','7654.930107526882','7654.930107526882239','test'),('2019-07-08 19:59:59','2019-07-12 03:59:59','SCBNB','4h','0.000096000000000','0.000098800000000','0.711908500000000','0.732672497916667','7415.713541666667','7415.713541666666970','test'),('2019-07-15 19:59:59','2019-07-16 15:59:59','SCBNB','4h','0.000103800000000','0.000101300000000','0.711908500000000','0.694762341522158','6858.463391136802','6858.463391136801874','test'),('2019-07-16 23:59:59','2019-07-17 03:59:59','SCBNB','4h','0.000102300000000','0.000102900000000','0.711908500000000','0.716083916422287','6959.027370478983','6959.027370478983357','test'),('2019-07-29 11:59:59','2019-07-30 23:59:59','SCBNB','4h','0.000098100000000','0.000097100000000','0.711908500000000','0.704651532619776','7256.967380224261','7256.967380224261433','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','SCBNB','4h','0.000097600000000','0.000097500000000','0.711908500000000','0.711179085553279','7294.144467213116','7294.144467213115604','test'),('2019-07-31 15:59:59','2019-08-01 07:59:59','SCBNB','4h','0.000099000000000','0.000098400000000','0.711908500000000','0.707593903030303','7190.994949494951','7190.994949494950561','test'),('2019-08-01 19:59:59','2019-08-02 15:59:59','SCBNB','4h','0.000099800000000','0.000099000000000','0.711908500000000','0.706201818637275','7133.3517034068145','7133.351703406814522','test'),('2019-08-03 03:59:59','2019-08-03 07:59:59','SCBNB','4h','0.000099800000000','0.000097100000000','0.711908500000000','0.692648450400802','7133.3517034068145','7133.351703406814522','test'),('2019-08-04 15:59:59','2019-08-05 03:59:59','SCBNB','4h','0.000099400000000','0.000099800000000','0.711908500000000','0.714773322937626','7162.057344064387','7162.057344064386598','test'),('2019-08-05 07:59:59','2019-08-05 11:59:59','SCBNB','4h','0.000101000000000','0.000098300000000','0.711908500000000','0.692877282673267','7048.5990099009905','7048.599009900990495','test'),('2019-08-05 19:59:59','2019-08-05 23:59:59','SCBNB','4h','0.000099100000000','0.000097000000000','0.711908500000000','0.696822648839556','7183.738647830475','7183.738647830475202','test'),('2019-08-24 15:59:59','2019-08-26 11:59:59','SCBNB','4h','0.000079600000000','0.000076900000000','0.711908500000000','0.687760849874372','8943.574120603016','8943.574120603016127','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','SCBNB','4h','0.000079600000000','0.000081900000000','0.711908500000000','0.732478720477387','8943.574120603016','8943.574120603016127','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','SCBNB','4h','0.000082900000000','0.000081800000000','0.711908500000000','0.702462186972256','8587.557297949337','8587.557297949337226','test'),('2019-09-04 03:59:59','2019-09-05 15:59:59','SCBNB','4h','0.000085100000000','0.000082000000000','0.711908500000000','0.685975287896592','8365.552291421858','8365.552291421858172','test'),('2019-09-09 03:59:59','2019-09-09 15:59:59','SCBNB','4h','0.000082700000000','0.000082300000000','0.711908500000000','0.708465169891173','8608.325272067716','8608.325272067715559','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','SCBNB','4h','0.000081700000000','0.000082000000000','0.711908500000000','0.714522607099143','8713.690330477357','8713.690330477356838','test'),('2019-09-10 15:59:59','2019-09-10 19:59:59','SCBNB','4h','0.000082600000000','0.000082800000000','0.711908500000000','0.713632249394673','8618.746973365618','8618.746973365618032','test'),('2019-09-11 07:59:59','2019-09-12 11:59:59','SCBNB','4h','0.000082900000000','0.000083400000000','0.711908500000000','0.716202278648975','8587.557297949337','8587.557297949337226','test'),('2019-09-13 23:59:59','2019-09-17 15:59:59','SCBNB','4h','0.000084900000000','0.000084900000000','0.711908500000000','0.711908500000000','8385.259128386337','8385.259128386336670','test'),('2019-09-19 15:59:59','2019-09-24 19:59:59','SCBNB','4h','0.000085500000000','0.000094700000000','0.711908500000000','0.788511519883041','8326.415204678362','8326.415204678361988','test'),('2019-09-24 23:59:59','2019-09-26 03:59:59','SCBNB','4h','0.000097100000000','0.000095300000000','0.711908500000000','0.698711432028836','7331.704428424306','7331.704428424305661','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','SCBNB','4h','0.000097100000000','0.000095300000000','0.711908500000000','0.698711432028836','7331.704428424306','7331.704428424305661','test'),('2019-09-27 15:59:59','2019-09-27 23:59:59','SCBNB','4h','0.000096700000000','0.000095100000000','0.711908500000000','0.700129248707342','7362.032057911065','7362.032057911064840','test'),('2019-09-28 03:59:59','2019-09-28 15:59:59','SCBNB','4h','0.000097100000000','0.000098900000000','0.711908500000000','0.725105567971164','7331.704428424306','7331.704428424305661','test'),('2019-09-28 19:59:59','2019-10-04 11:59:59','SCBNB','4h','0.000099700000000','0.000102500000000','0.711908500000000','0.731901918254764','7140.506519558677','7140.506519558676700','test'),('2019-10-04 15:59:59','2019-10-06 23:59:59','SCBNB','4h','0.000107900000000','0.000107000000000','0.711908500000000','0.705970430954588','6597.854494902688','6597.854494902688202','test'),('2019-10-08 19:59:59','2019-10-09 23:59:59','SCBNB','4h','0.000121500000000','0.000108900000000','0.711908500000000','0.638080951851852','5859.329218106996','5859.329218106996450','test'),('2019-10-10 03:59:59','2019-10-15 07:59:59','SCBNB','4h','0.000111900000000','0.000118200000000','0.711908500000000','0.751989139410188','6362.006255585345','6362.006255585344661','test'),('2019-11-19 11:59:59','2019-11-20 11:59:59','SCBNB','4h','0.000099900000000','0.000096600000000','0.711908500000000','0.688392003003003','7126.211211211212','7126.211211211211776','test'),('2019-11-20 19:59:59','2019-11-21 19:59:59','SCBNB','4h','0.000101000000000','0.000098400000000','0.711908500000000','0.693582142574258','7048.5990099009905','7048.599009900990495','test'),('2019-11-22 11:59:59','2019-11-22 15:59:59','SCBNB','4h','0.000102300000000','0.000104000000000','0.711908500000000','0.723738846529814','6959.027370478983','6959.027370478983357','test'),('2019-11-23 03:59:59','2019-11-23 15:59:59','SCBNB','4h','0.000101500000000','0.000098100000000','0.711908500000000','0.688061318719212','7013.876847290641','7013.876847290641308','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','SCBNB','4h','0.000100400000000','0.000098200000000','0.711908500000000','0.696308911354582','7090.722111553785','7090.722111553784998','test'),('2019-11-28 03:59:59','2019-11-29 19:59:59','SCBNB','4h','0.000100800000000','0.000100100000000','0.711908500000000','0.706964690972222','7062.584325396826','7062.584325396825989','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','SCBNB','4h','0.000100600000000','0.000099600000000','0.711908500000000','0.704831874751491','7076.625248508946','7076.625248508946243','test'),('2019-11-30 11:59:59','2019-12-01 23:59:59','SCBNB','4h','0.000100700000000','0.000097500000000','0.711908500000000','0.689285786991063','7069.59781529295','7069.597815292950145','test'),('2019-12-11 23:59:59','2019-12-12 15:59:59','SCBNB','4h','0.000098200000000','0.000098200000000','0.711908500000000','0.711908500000000','7249.577393075357','7249.577393075356667','test'),('2019-12-13 03:59:59','2019-12-13 19:59:59','SCBNB','4h','0.000098000000000','0.000098100000000','0.711908500000000','0.712634937244898','7264.372448979592','7264.372448979592264','test'),('2019-12-13 23:59:59','2019-12-14 07:59:59','SCBNB','4h','0.000098500000000','0.000097900000000','0.711908500000000','0.707572001522843','7227.497461928935','7227.497461928935081','test'),('2019-12-14 11:59:59','2019-12-18 11:59:59','SCBNB','4h','0.000098100000000','0.000101900000000','0.711908500000000','0.739484976044852','7256.967380224261','7256.967380224261433','test'),('2019-12-18 19:59:59','2019-12-20 11:59:59','SCBNB','4h','0.000102600000000','0.000101500000000','0.711908500000000','0.704275952729045','6938.679337231969','6938.679337231968930','test'),('2019-12-23 03:59:59','2019-12-23 19:59:59','SCBNB','4h','0.000104100000000','0.000103000000000','0.711908500000000','0.704385931796350','6838.698366954852','6838.698366954851735','test'),('2019-12-24 03:59:59','2019-12-25 03:59:59','SCBNB','4h','0.000103700000000','0.000103000000000','0.711908500000000','0.707102945998071','6865.077145612344','6865.077145612343884','test'),('2019-12-25 07:59:59','2019-12-25 11:59:59','SCBNB','4h','0.000103200000000','0.000103400000000','0.711908500000000','0.713288167635659','6898.338178294574','6898.338178294574391','test'),('2019-12-25 19:59:59','2019-12-26 11:59:59','SCBNB','4h','0.000104900000000','0.000102500000000','0.711908500000000','0.695620793612965','6786.544327931364','6786.544327931364023','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 22:09:01
