-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-07 03:59:59','NEBLBTC','4h','0.000346800000000','0.000341800000000','0.001467500000000','0.001446342272203','4.231545559400231','4.231545559400231','test'),('2019-01-20 03:59:59','2019-01-20 11:59:59','NEBLBTC','4h','0.000325000000000','0.000313000000000','0.001467500000000','0.001413315384615','4.515384615384615','4.515384615384615','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','NEBLBTC','4h','0.000314300000000','0.000313600000000','0.001467500000000','0.001464231625835','4.669105949729558','4.669105949729558','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','NEBLBTC','4h','0.000321600000000','0.000310600000000','0.001467500000000','0.001417305659204','4.563121890547264','4.563121890547264','test'),('2019-01-24 23:59:59','2019-01-25 15:59:59','NEBLBTC','4h','0.000321400000000','0.000319600000000','0.001467500000000','0.001459281269446','4.5659614187927815','4.565961418792782','test'),('2019-01-25 23:59:59','2019-01-27 11:59:59','NEBLBTC','4h','0.000324400000000','0.000313700000000','0.001467500000000','0.001419096023428','4.523736128236744','4.523736128236744','test'),('2019-02-10 03:59:59','2019-02-11 23:59:59','NEBLBTC','4h','0.000303400000000','0.000291400000000','0.001467500000000','0.001409457811470','4.836849044166118','4.836849044166118','test'),('2019-02-12 23:59:59','2019-02-14 23:59:59','NEBLBTC','4h','0.000309400000000','0.000296700000000','0.001467500000000','0.001407263251454','4.743051066580478','4.743051066580478','test'),('2019-02-18 03:59:59','2019-02-18 11:59:59','NEBLBTC','4h','0.000301300000000','0.000297500000000','0.001467500000000','0.001448991868570','4.87056090275473','4.870560902754730','test'),('2019-02-21 07:59:59','2019-02-21 19:59:59','NEBLBTC','4h','0.000307700000000','0.000293900000000','0.001467500000000','0.001401684270393','4.7692557686057855','4.769255768605785','test'),('2019-02-21 23:59:59','2019-02-22 03:59:59','NEBLBTC','4h','0.000295000000000','0.000293900000000','0.001467500000000','0.001462027966102','4.97457627118644','4.974576271186440','test'),('2019-02-22 11:59:59','2019-02-22 15:59:59','NEBLBTC','4h','0.000297400000000','0.000305000000000','0.001467500000000','0.001505001681237','4.934431741761936','4.934431741761936','test'),('2019-02-23 11:59:59','2019-02-23 19:59:59','NEBLBTC','4h','0.000301800000000','0.000300400000000','0.001467500000000','0.001460692511597','4.862491716368456','4.862491716368456','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','NEBLBTC','4h','0.000300000000000','0.000292100000000','0.001467500000000','0.001428855833333','4.8916666666666675','4.891666666666667','test'),('2019-02-27 23:59:59','2019-03-01 23:59:59','NEBLBTC','4h','0.000308200000000','0.000300000000000','0.001467500000000','0.001428455548345','4.761518494484101','4.761518494484101','test'),('2019-03-02 03:59:59','2019-03-02 07:59:59','NEBLBTC','4h','0.000301200000000','0.000300700000000','0.001467500000000','0.001465063911023','4.8721779548472774','4.872177954847277','test'),('2019-03-02 19:59:59','2019-03-03 19:59:59','NEBLBTC','4h','0.000303200000000','0.000301400000000','0.001467500000000','0.001458787928760','4.840039577836412','4.840039577836412','test'),('2019-03-06 07:59:59','2019-03-06 23:59:59','NEBLBTC','4h','0.000304800000000','0.000301000000000','0.001467500000000','0.001449204396325','4.814632545931759','4.814632545931759','test'),('2019-03-07 03:59:59','2019-03-11 15:59:59','NEBLBTC','4h','0.000303900000000','0.000316600000000','0.001467500000000','0.001528826916749','4.828891082592958','4.828891082592958','test'),('2019-03-12 11:59:59','2019-03-18 11:59:59','NEBLBTC','4h','0.000340300000000','0.000367300000000','0.001467500000000','0.001583934028798','4.312371436967382','4.312371436967382','test'),('2019-03-28 23:59:59','2019-03-31 23:59:59','NEBLBTC','4h','0.000382000000000','0.000369600000000','0.001467500000000','0.001419863874346','3.8416230366492146','3.841623036649215','test'),('2019-04-01 19:59:59','2019-04-02 03:59:59','NEBLBTC','4h','0.000374500000000','0.000363100000000','0.001467500000000','0.001422828437917','3.9185580774365825','3.918558077436582','test'),('2019-06-02 23:59:59','2019-06-03 03:59:59','NEBLBTC','4h','0.000160900000000','0.000158900000000','0.001467500000000','0.001449258856433','9.120571783716594','9.120571783716594','test'),('2019-06-08 03:59:59','2019-06-12 15:59:59','NEBLBTC','4h','0.000160000000000','0.000170500000000','0.001467500000000','0.001563804687500','9.171875','9.171875000000000','test'),('2019-07-28 03:59:59','2019-07-30 07:59:59','NEBLBTC','4h','0.000087500000000','0.000087800000000','0.001467500000000','0.001472531428571','16.771428571428572','16.771428571428572','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','NEBLBTC','4h','0.000055700000000','0.000054000000000','0.001467500000000','0.001422710951526','26.346499102333933','26.346499102333933','test'),('2019-08-23 23:59:59','2019-08-25 19:59:59','NEBLBTC','4h','0.000054100000000','0.000055800000000','0.001467500000000','0.001513613678373','27.12569316081331','27.125693160813309','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','NEBLBTC','4h','0.000056200000000','0.000054800000000','0.001467500000000','0.001430943060498','26.112099644128115','26.112099644128115','test'),('2019-08-28 15:59:59','2019-09-01 11:59:59','NEBLBTC','4h','0.000056700000000','0.000058200000000','0.001467500000000','0.001506322751323','25.881834215167547','25.881834215167547','test'),('2019-09-01 19:59:59','2019-09-01 23:59:59','NEBLBTC','4h','0.000059400000000','0.000057700000000','0.001467500000000','0.001425500841751','24.705387205387208','24.705387205387208','test'),('2019-09-19 19:59:59','2019-09-19 23:59:59','NEBLBTC','4h','0.000049510000000','0.000045950000000','0.001467500000000','0.001361979903050','29.64047667137952','29.640476671379520','test'),('2019-09-21 15:59:59','2019-09-22 23:59:59','NEBLBTC','4h','0.000048800000000','0.000046930000000','0.001467500000000','0.001411265881148','30.07172131147541','30.071721311475411','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','NEBLBTC','4h','0.000047750000000','0.000046000000000','0.001467500000000','0.001413717277487','30.732984293193716','30.732984293193716','test'),('2019-10-01 07:59:59','2019-10-01 19:59:59','NEBLBTC','4h','0.000046610000000','0.000045470000000','0.001467500000000','0.001431607487664','31.484659944217977','31.484659944217977','test'),('2019-10-02 03:59:59','2019-10-02 07:59:59','NEBLBTC','4h','0.000045510000000','0.000045240000000','0.001467500000000','0.001458793671721','32.24566029444078','32.245660294440782','test'),('2019-10-02 11:59:59','2019-10-06 19:59:59','NEBLBTC','4h','0.000046300000000','0.000051110000000','0.001467500000000','0.001619955183585','31.695464362850974','31.695464362850974','test'),('2019-10-07 11:59:59','2019-10-10 11:59:59','NEBLBTC','4h','0.000055590000000','0.000054000000000','0.001467500000000','0.001425526173772','26.398632847634467','26.398632847634467','test'),('2019-10-10 19:59:59','2019-10-11 07:59:59','NEBLBTC','4h','0.000056100000000','0.000055050000000','0.001467500000000','0.001440033422460','26.158645276292336','26.158645276292336','test'),('2019-10-11 11:59:59','2019-10-13 15:59:59','NEBLBTC','4h','0.000056960000000','0.000055050000000','0.001467500000000','0.001418291344803','25.76369382022472','25.763693820224720','test'),('2019-10-22 11:59:59','2019-10-23 11:59:59','NEBLBTC','4h','0.000055150000000','0.000056160000000','0.001467500000000','0.001494375339982','26.60924750679964','26.609247506799640','test'),('2019-10-23 15:59:59','2019-10-25 19:59:59','NEBLBTC','4h','0.000056430000000','0.000055180000000','0.001467500000000','0.001434992911572','26.005670742512848','26.005670742512848','test'),('2019-10-27 07:59:59','2019-10-27 19:59:59','NEBLBTC','4h','0.000056980000000','0.000054420000000','0.001467500000000','0.001401568094068','25.754650754650754','25.754650754650754','test'),('2019-11-03 19:59:59','2019-11-04 11:59:59','NEBLBTC','4h','0.000055160000000','0.000053140000000','0.001467500000000','0.001413759064540','26.60442349528644','26.604423495286440','test'),('2019-11-05 15:59:59','2019-11-06 23:59:59','NEBLBTC','4h','0.000056450000000','0.000053250000000','0.001467500000000','0.001384311337467','25.99645704162976','25.996457041629760','test'),('2019-11-13 23:59:59','2019-11-14 11:59:59','NEBLBTC','4h','0.000053900000000','0.000053350000000','0.001467500000000','0.001452525510204','27.226345083487942','27.226345083487942','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','NEBLBTC','4h','0.000053540000000','0.000053440000000','0.001467500000000','0.001464759058648','27.409413522599927','27.409413522599927','test'),('2019-11-14 23:59:59','2019-11-15 07:59:59','NEBLBTC','4h','0.000053980000000','0.000053460000000','0.001467500000000','0.001453363282697','27.185994812893664','27.185994812893664','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','NEBLBTC','4h','0.000053910000000','0.000053270000000','0.001467500000000','0.001450078371360','27.22129475051011','27.221294750510111','test'),('2019-11-15 19:59:59','2019-11-20 15:59:59','NEBLBTC','4h','0.000054030000000','0.000056720000000','0.001467500000000','0.001540562650379','27.16083657227466','27.160836572274661','test'),('2019-11-26 03:59:59','2019-11-28 07:59:59','NEBLBTC','4h','0.000061240000000','0.000059100000000','0.001467500000000','0.001416218974526','23.96309601567603','23.963096015676030','test'),('2019-11-29 19:59:59','2019-12-01 15:59:59','NEBLBTC','4h','0.000063770000000','0.000060570000000','0.001467500000000','0.001393860357535','23.012388270346563','23.012388270346563','test'),('2019-12-01 19:59:59','2019-12-01 23:59:59','NEBLBTC','4h','0.000061840000000','0.000060930000000','0.001467500000000','0.001445905158473','23.73059508408797','23.730595084087970','test'),('2019-12-02 19:59:59','2019-12-09 23:59:59','NEBLBTC','4h','0.000066380000000','0.000068580000000','0.001467500000000','0.001516136637541','22.107562518830974','22.107562518830974','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:00:51
