-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 03:59:59','2019-01-14 15:59:59','BLZETH','4h','0.000317360000000','0.000301880000000','0.072144500000000','0.068625477880010','227.32701033526595','227.327010335265953','test'),('2019-01-15 15:59:59','2019-01-20 23:59:59','BLZETH','4h','0.000328390000000','0.000348420000000','0.072144500000000','0.076544921252170','219.69152532050305','219.691525320503047','test'),('2019-01-21 07:59:59','2019-01-24 03:59:59','BLZETH','4h','0.000361040000000','0.000359020000000','0.072364849783045','0.071959972216676','200.43443879637988','200.434438796379879','test'),('2019-02-07 03:59:59','2019-02-08 15:59:59','BLZETH','4h','0.000353210000000','0.000347770000000','0.072364849783045','0.071250315135612','204.87769254280738','204.877692542807381','test'),('2019-02-27 15:59:59','2019-02-28 11:59:59','BLZETH','4h','0.000321980000000','0.000311900000000','0.072364849783045','0.070099374642312','224.74951792982483','224.749517929824833','test'),('2019-03-01 07:59:59','2019-03-05 19:59:59','BLZETH','4h','0.000319630000000','0.000355470000000','0.072364849783045','0.080479095054842','226.4019328068235','226.401932806823510','test'),('2019-03-06 07:59:59','2019-03-07 07:59:59','BLZETH','4h','0.000387140000000','0.000359170000000','0.073447189262361','0.068140793943695','189.71738715286588','189.717387152865882','test'),('2019-03-09 07:59:59','2019-03-17 03:59:59','BLZETH','4h','0.000391190000000','0.000416530000000','0.073447189262361','0.078204856319055','187.75323822787138','187.753238227871378','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','BLZETH','4h','0.000414000000000','0.000400020000000','0.073447189262361','0.070967016059733','177.40866971584785','177.408669715847850','test'),('2019-03-27 03:59:59','2019-04-02 07:59:59','BLZETH','4h','0.000423640000000','0.000464780000000','0.073447189262361','0.080579701221226','173.37170536861723','173.371705368617228','test'),('2019-04-04 23:59:59','2019-04-08 07:59:59','BLZETH','4h','0.000473170000000','0.000481650000000','0.074473091885927','0.075807774598679','157.39182933391115','157.391829333911147','test'),('2019-05-23 07:59:59','2019-05-24 19:59:59','BLZETH','4h','0.000261330000000','0.000255140000000','0.074806762564115','0.073034850191743','286.2540181537319','286.254018153731920','test'),('2019-05-24 23:59:59','2019-05-25 03:59:59','BLZETH','4h','0.000259980000000','0.000265320000000','0.074806762564115','0.076343296574779','287.7404514351681','287.740451435168097','test'),('2019-06-07 07:59:59','2019-06-09 19:59:59','BLZETH','4h','0.000256380000000','0.000259070000000','0.074806762564115','0.075591652927238','291.78080413493643','291.780804134936432','test'),('2019-06-10 03:59:59','2019-06-11 15:59:59','BLZETH','4h','0.000257640000000','0.000256430000000','0.074944140564468','0.074592167229260','290.88705389096606','290.887053890966058','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','BLZETH','4h','0.000263590000000','0.000238940000000','0.074944140564468','0.067935630890679','284.3208792612315','284.320879261231482','test'),('2019-07-23 23:59:59','2019-07-24 19:59:59','BLZETH','4h','0.000169580000000','0.000169640000000','0.074944140564468','0.074970656948675','441.939736787758','441.939736787758022','test'),('2019-07-25 07:59:59','2019-07-25 15:59:59','BLZETH','4h','0.000168490000000','0.000167610000000','0.074944140564468','0.074552717668767','444.7987451152472','444.798745115247186','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','BLZETH','4h','0.000168280000000','0.000165310000000','0.074944140564468','0.073621439723747','445.35381842445923','445.353818424459234','test'),('2019-07-26 03:59:59','2019-08-01 11:59:59','BLZETH','4h','0.000170520000000','0.000190160000000','0.074944140564468','0.083575989735745','439.50352195911336','439.503521959113357','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','BLZETH','4h','0.000203330000000','0.000161770000000','0.074944140564468','0.059625798549717','368.58378283808594','368.583782838085938','test'),('2019-08-16 03:59:59','2019-08-16 23:59:59','BLZETH','4h','0.000165190000000','0.000162920000000','0.074944140564468','0.073914276776821','453.6844879500454','453.684487950045423','test'),('2019-08-17 03:59:59','2019-08-19 03:59:59','BLZETH','4h','0.000163940000000','0.000163940000000','0.074944140564468','0.074944140564468','457.1437145569599','457.143714556959878','test'),('2019-08-21 03:59:59','2019-08-28 03:59:59','BLZETH','4h','0.000167530000000','0.000184700000000','0.074944140564468','0.082625098562987','447.347582907348','447.347582907347999','test'),('2019-08-30 15:59:59','2019-08-31 15:59:59','BLZETH','4h','0.000195340000000','0.000186370000000','0.074944140564468','0.071502710540595','383.6599803648408','383.659980364840806','test'),('2019-08-31 19:59:59','2019-08-31 23:59:59','BLZETH','4h','0.000186900000000','0.000184570000000','0.074944140564468','0.074009844965136','400.98523576494387','400.985235764943866','test'),('2019-09-02 15:59:59','2019-09-02 19:59:59','BLZETH','4h','0.000189060000000','0.000183680000000','0.074944140564468','0.072811487035235','396.40400171621707','396.404001716217067','test'),('2019-09-12 07:59:59','2019-09-12 15:59:59','BLZETH','4h','0.000180040000000','0.000175580000000','0.074944140564468','0.073087603867526','416.2638333951789','416.263833395178892','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','BLZETH','4h','0.000175600000000','0.000171120000000','0.074944140564468','0.073032126044372','426.78895537851935','426.788955378519347','test'),('2019-09-13 19:59:59','2019-09-14 19:59:59','BLZETH','4h','0.000183460000000','0.000179130000000','0.074944140564468','0.073175318321777','408.50398214579747','408.503982145797465','test'),('2019-09-14 23:59:59','2019-09-15 03:59:59','BLZETH','4h','0.000179440000000','0.000177620000000','0.074944140564468','0.074184007172653','417.65570978860904','417.655709788609045','test'),('2019-09-23 19:59:59','2019-09-23 23:59:59','BLZETH','4h','0.000174320000000','0.000169330000000','0.074944140564468','0.072798825847759','429.9227889196191','429.922788919619109','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','BLZETH','4h','0.000160470000000','0.000141400000000','0.074944140564468','0.066037897898771','467.0289808965415','467.028980896541498','test'),('2019-10-14 15:59:59','2019-10-14 19:59:59','BLZETH','4h','0.000154650000000','0.000150360000000','0.074944140564468','0.072865185743766','484.6048533104947','484.604853310494718','test'),('2019-10-14 23:59:59','2019-10-16 03:59:59','BLZETH','4h','0.000153160000000','0.000149120000000','0.074944140564468','0.072967290682773','489.3192776473492','489.319277647349224','test'),('2019-10-20 07:59:59','2019-10-21 07:59:59','BLZETH','4h','0.000155150000000','0.000151380000000','0.074944140564468','0.073123067990004','483.04312319992266','483.043123199922661','test'),('2019-10-21 15:59:59','2019-10-23 07:59:59','BLZETH','4h','0.000155290000000','0.000154020000000','0.074944140564468','0.074331228860451','482.6076409586451','482.607640958645106','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','BLZETH','4h','0.000154410000000','0.000149350000000','0.074944140564468','0.072488228698292','485.35807631933164','485.358076319331644','test'),('2019-11-10 11:59:59','2019-11-13 11:59:59','BLZETH','4h','0.000147580000000','0.000161820000000','0.074944140564468','0.082175503632892','507.8204401983196','507.820440198319602','test'),('2019-11-27 03:59:59','2019-11-27 23:59:59','BLZETH','4h','0.000149290000000','0.000141820000000','0.074944140564468','0.071194172515593','502.00375486950236','502.003754869502359','test'),('2019-11-28 03:59:59','2019-11-28 07:59:59','BLZETH','4h','0.000142380000000','0.000144050000000','0.074944140564468','0.075823173537798','526.3670498979351','526.367049897935090','test'),('2019-11-28 11:59:59','2019-11-28 15:59:59','BLZETH','4h','0.000144270000000','0.000142860000000','0.074944140564468','0.074211685873986','519.4714116896653','519.471411689665274','test'),('2019-11-29 23:59:59','2019-11-30 07:59:59','BLZETH','4h','0.000145680000000','0.000143260000000','0.074944140564468','0.073699187103691','514.4435788335255','514.443578833525521','test'),('2019-12-02 23:59:59','2019-12-03 07:59:59','BLZETH','4h','0.000147200000000','0.000143440000000','0.074944140564468','0.073029806539180','509.1313897042663','509.131389704266326','test'),('2019-12-03 11:59:59','2019-12-04 03:59:59','BLZETH','4h','0.000145350000000','0.000143100000000','0.074944140564468','0.073784014549538','515.6115621910424','515.611562191042367','test'),('2019-12-07 15:59:59','2019-12-10 03:59:59','BLZETH','4h','0.000147170000000','0.000140630000000','0.074944140564468','0.071613742526202','509.2351740468031','509.235174046803081','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 17:44:36
