-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-21 03:59:59','CNDETH','4h','0.000073060000000','0.000092310000000','0.072144500000000','0.091153282165344','987.4692033944704','987.469203394470355','test'),('2019-01-21 07:59:59','2019-01-21 11:59:59','CNDETH','4h','0.000093950000000','0.000092520000000','0.076896695541336','0.075726261537886','818.4853170977756','818.485317097775578','test'),('2019-01-21 15:59:59','2019-01-24 07:59:59','CNDETH','4h','0.000093840000000','0.000094080000000','0.076896695541336','0.077093362281851','819.4447521455244','819.444752145524376','test'),('2019-01-29 23:59:59','2019-01-30 03:59:59','CNDETH','4h','0.000092930000000','0.000095410000000','0.076896695541336','0.078948818697932','827.4690147566555','827.469014756655497','test'),('2019-02-02 19:59:59','2019-02-03 23:59:59','CNDETH','4h','0.000093940000000','0.000094320000000','0.077166284514751','0.077478432567930','821.4422452070603','821.442245207060296','test'),('2019-02-04 15:59:59','2019-02-05 07:59:59','CNDETH','4h','0.000094490000000','0.000092750000000','0.077244321528046','0.075821894610290','817.4867343427453','817.486734342745308','test'),('2019-02-06 03:59:59','2019-02-06 15:59:59','CNDETH','4h','0.000094810000000','0.000093200000000','0.077244321528046','0.075932610129880','814.7275765008544','814.727576500854411','test'),('2019-02-09 15:59:59','2019-02-10 23:59:59','CNDETH','4h','0.000102190000000','0.000093100000000','0.077244321528046','0.070373288328223','755.8892409046482','755.889240904648204','test'),('2019-02-11 03:59:59','2019-02-11 11:59:59','CNDETH','4h','0.000096000000000','0.000094070000000','0.077244321528046','0.075691388813993','804.6283492504791','804.628349250479118','test'),('2019-02-26 15:59:59','2019-03-05 15:59:59','CNDETH','4h','0.000096590000000','0.000096180000000','0.077244321528046','0.076916439016124','799.7134437110053','799.713443711005311','test'),('2019-03-09 07:59:59','2019-03-16 03:59:59','CNDETH','4h','0.000097270000000','0.000108300000000','0.077244321528046','0.086003495646010','794.1227668144958','794.122766814495776','test'),('2019-03-17 23:59:59','2019-03-18 07:59:59','CNDETH','4h','0.000111000000000','0.000108670000000','0.077244321528046','0.075622886670746','695.894788540955','695.894788540955005','test'),('2019-03-19 23:59:59','2019-03-22 19:59:59','CNDETH','4h','0.000111090000000','0.000112350000000','0.077244321528046','0.078120438596417','695.3310066436763','695.331006643676346','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','CNDETH','4h','0.000113840000000','0.000111770000000','0.077244321528046','0.075839755948609','678.5340963461525','678.534096346152523','test'),('2019-03-25 19:59:59','2019-03-26 11:59:59','CNDETH','4h','0.000114950000000','0.000112510000000','0.077244321528046','0.075604685646981','671.9819184692997','671.981918469299671','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','CNDETH','4h','0.000113060000000','0.000113550000000','0.077244321528046','0.077579097023789','683.2152974353971','683.215297435397133','test'),('2019-03-30 19:59:59','2019-04-03 03:59:59','CNDETH','4h','0.000120000000000','0.000115180000000','0.077244321528046','0.074141674613336','643.7026794003833','643.702679400383317','test'),('2019-04-03 07:59:59','2019-04-03 19:59:59','CNDETH','4h','0.000126890000000','0.000116930000000','0.077244321528046','0.071181168857076','608.750268169643','608.750268169643050','test'),('2019-04-14 15:59:59','2019-04-20 03:59:59','CNDETH','4h','0.000119780000000','0.000120070000000','0.077244321528046','0.077431338168914','644.8849685093171','644.884968509317105','test'),('2019-05-23 07:59:59','2019-05-24 19:59:59','CNDETH','4h','0.000080500000000','0.000076690000000','0.077244321528046','0.073588410161315','959.5567891682732','959.556789168273212','test'),('2019-05-24 23:59:59','2019-05-25 07:59:59','CNDETH','4h','0.000078880000000','0.000078330000000','0.077244321528046','0.076705726486966','979.2637110553499','979.263711055349859','test'),('2019-06-03 11:59:59','2019-06-05 15:59:59','CNDETH','4h','0.000074510000000','0.000074690000000','0.077244321528046','0.077430927055828','1036.6973765675211','1036.697376567521133','test'),('2019-06-08 07:59:59','2019-06-10 03:59:59','CNDETH','4h','0.000075300000000','0.000075510000000','0.077244321528046','0.077459743938682','1025.8210030284993','1025.821003028499263','test'),('2019-06-10 07:59:59','2019-06-10 15:59:59','CNDETH','4h','0.000076110000000','0.000075800000000','0.077244321528046','0.076929701377295','1014.9037121015109','1014.903712101510905','test'),('2019-06-10 19:59:59','2019-06-11 19:59:59','CNDETH','4h','0.000077100000000','0.000075330000000','0.077244321528046','0.075471008310087','1001.8718745531257','1001.871874553125735','test'),('2019-07-15 07:59:59','2019-07-15 11:59:59','CNDETH','4h','0.000045650000000','0.000047260000000','0.077244321528046','0.079968600994862','1692.0990477118512','1692.099047711851199','test'),('2019-07-15 19:59:59','2019-07-15 23:59:59','CNDETH','4h','0.000045580000000','0.000046530000000','0.077244321528046','0.078854284350592','1694.697707943089','1694.697707943088972','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','CNDETH','4h','0.000046040000000','0.000045610000000','0.077244321528046','0.076522882382584','1677.7654545622502','1677.765454562250170','test'),('2019-07-22 23:59:59','2019-07-23 19:59:59','CNDETH','4h','0.000045650000000','0.000044820000000','0.077244321528046','0.075839879318445','1692.0990477118512','1692.099047711851199','test'),('2019-07-23 23:59:59','2019-07-24 03:59:59','CNDETH','4h','0.000045320000000','0.000045140000000','0.077244321528046','0.076937525899735','1704.4201572825684','1704.420157282568425','test'),('2019-07-24 11:59:59','2019-07-24 15:59:59','CNDETH','4h','0.000045490000000','0.000044760000000','0.077244321528046','0.076004744594314','1698.0505941535723','1698.050594153572320','test'),('2019-07-24 19:59:59','2019-07-27 03:59:59','CNDETH','4h','0.000047400000000','0.000046280000000','0.077244321528046','0.075419139247215','1629.6270364566667','1629.627036456666701','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','CNDETH','4h','0.000047210000000','0.000045620000000','0.077244321528046','0.074642786445869','1636.185586275069','1636.185586275068999','test'),('2019-07-29 11:59:59','2019-07-29 23:59:59','CNDETH','4h','0.000047830000000','0.000045500000000','0.077244321528046','0.073481426500650','1614.976406607694','1614.976406607693889','test'),('2019-07-30 03:59:59','2019-07-31 15:59:59','CNDETH','4h','0.000046000000000','0.000046350000000','0.077244321528046','0.077832050061412','1679.2243810444784','1679.224381044478378','test'),('2019-08-03 03:59:59','2019-08-03 19:59:59','CNDETH','4h','0.000048810000000','0.000045470000000','0.077244321528046','0.071958600694125','1582.5511478804754','1582.551147880475355','test'),('2019-08-04 03:59:59','2019-08-04 07:59:59','CNDETH','4h','0.000045770000000','0.000045550000000','0.077244321528046','0.076873035735252','1687.6626945170638','1687.662694517063755','test'),('2019-08-24 15:59:59','2019-08-28 19:59:59','CNDETH','4h','0.000038830000000','0.000039550000000','0.077244321528046','0.078676613866449','1989.2949144487768','1989.294914448776808','test'),('2019-08-31 07:59:59','2019-08-31 19:59:59','CNDETH','4h','0.000043250000000','0.000039150000000','0.077244321528046','0.069921738446775','1785.9958734808324','1785.995873480832415','test'),('2019-09-11 15:59:59','2019-09-11 23:59:59','CNDETH','4h','0.000039620000000','0.000037490000000','0.077244321528046','0.073091610653368','1949.6295186281172','1949.629518628117239','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','CNDETH','4h','0.000035500000000','0.000036000000000','0.077244321528046','0.078332269718582','2175.896381071718','2175.896381071718224','test'),('2019-09-14 03:59:59','2019-09-14 07:59:59','CNDETH','4h','0.000037170000000','0.000036360000000','0.077244321528046','0.075561031228403','2078.1361723983323','2078.136172398332292','test'),('2019-09-14 11:59:59','2019-09-14 15:59:59','CNDETH','4h','0.000036470000000','0.000036640000000','0.077244321528046','0.077604385543943','2118.0236229242114','2118.023622924211395','test'),('2019-09-19 15:59:59','2019-09-19 23:59:59','CNDETH','4h','0.000039380000000','0.000034490000000','0.077244321528046','0.067652530459683','1961.511465922956','1961.511465922955949','test'),('2019-09-20 03:59:59','2019-09-21 07:59:59','CNDETH','4h','0.000035130000000','0.000036920000000','0.077244321528046','0.081180197859819','2198.813593169542','2198.813593169541946','test'),('2019-09-21 11:59:59','2019-09-25 11:59:59','CNDETH','4h','0.000039730000000','0.000042800000000','0.077244321528046','0.083213112544686','1944.2316015113515','1944.231601511351528','test'),('2019-09-26 11:59:59','2019-09-26 15:59:59','CNDETH','4h','0.000047990000000','0.000043210000000','0.077244321528046','0.069550471623815','1609.5920301739113','1609.592030173911326','test'),('2019-09-27 19:59:59','2019-09-29 15:59:59','CNDETH','4h','0.000046230000000','0.000045420000000','0.077244321528046','0.075890916803025','1670.870030890028','1670.870030890027920','test'),('2019-10-03 07:59:59','2019-10-07 19:59:59','CNDETH','4h','0.000045640000000','0.000046580000000','0.077244321528046','0.078835243137081','1692.4697968458809','1692.469796845880865','test'),('2019-10-20 15:59:59','2019-10-23 15:59:59','CNDETH','4h','0.000044160000000','0.000044170000000','0.077244321528046','0.077261813448682','1749.1920635879983','1749.192063587998291','test'),('2019-11-02 07:59:59','2019-11-02 11:59:59','CNDETH','4h','0.000042640000000','0.000041820000000','0.077244321528046','0.075758853806353','1811.5460020648688','1811.546002064868844','test'),('2019-11-02 15:59:59','2019-11-02 19:59:59','CNDETH','4h','0.000041880000000','0.000041550000000','0.077244321528046','0.076635662834057','1844.420284814852','1844.420284814852039','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','CNDETH','4h','0.000042000000000','0.000041800000000','0.077244321528046','0.076876491425531','1839.150512572524','1839.150512572523894','test'),('2019-11-03 15:59:59','2019-11-04 23:59:59','CNDETH','4h','0.000043460000000','0.000043860000000','0.077244321528046','0.077955267883573','1777.3658888183618','1777.365888818361782','test'),('2019-11-05 03:59:59','2019-11-05 19:59:59','CNDETH','4h','0.000046830000000','0.000042940000000','0.077244321528046','0.070827913013331','1649.4623431143712','1649.462343114371151','test'),('2019-11-05 23:59:59','2019-11-06 03:59:59','CNDETH','4h','0.000043150000000','0.000042650000000','0.077244321528046','0.076349254071174','1790.134913743824','1790.134913743823972','test'),('2019-11-12 19:59:59','2019-11-12 23:59:59','CNDETH','4h','0.000043030000000','0.000043090000000','0.077244321528046','0.077352029157413','1795.1271561247038','1795.127156124703788','test'),('2019-11-13 01:59:59','2019-11-14 03:59:59','CNDETH','4h','0.000043350000000','0.000042800000000','0.077244321528046','0.076264289767021','1781.875929136009','1781.875929136009063','test'),('2019-11-14 11:59:59','2019-11-14 15:59:59','CNDETH','4h','0.000042550000000','0.000042340000000','0.077244321528046','0.076863092209106','1815.3777092372738','1815.377709237273848','test'),('2019-11-14 19:59:59','2019-11-14 23:59:59','CNDETH','4h','0.000042500000000','0.000042400000000','0.077244321528046','0.077062570183274','1817.5134477187294','1817.513447718729367','test'),('2019-11-15 03:59:59','2019-11-15 07:59:59','CNDETH','4h','0.000042710000000','0.000042470000000','0.077244321528046','0.076810263060082','1808.5769498488878','1808.576949848887807','test'),('2019-11-15 15:59:59','2019-11-21 11:59:59','CNDETH','4h','0.000045460000000','0.000044630000000','0.077244321528046','0.075834009454393','1699.171173076243','1699.171173076242894','test'),('2019-11-22 11:59:59','2019-11-22 19:59:59','CNDETH','4h','0.000048230000000','0.000045940000000','0.077244321528046','0.073576697719229','1601.5824492648974','1601.582449264897377','test'),('2019-11-24 07:59:59','2019-11-24 15:59:59','CNDETH','4h','0.000047360000000','0.000045840000000','0.077244321528046','0.074765196343869','1631.0034106428632','1631.003410642863173','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','CNDETH','4h','0.000046910000000','0.000045950000000','0.077244321528046','0.075663538141414','1646.6493610753782','1646.649361075378238','test'),('2019-11-25 07:59:59','2019-11-30 23:59:59','CNDETH','4h','0.000056260000000','0.000053100000000','0.077244321528046','0.072905678512962','1372.9882959126555','1372.988295912655531','test'),('2019-12-04 07:59:59','2019-12-05 07:59:59','CNDETH','4h','0.000054230000000','0.000052290000000','0.077244321528046','0.074481017383395','1424.3835797168726','1424.383579716872646','test'),('2019-12-05 11:59:59','2019-12-05 15:59:59','CNDETH','4h','0.000052690000000','0.000051660000000','0.051496214352031','0.050489550833667','977.3432217124819','977.343221712481864','test'),('2019-12-05 19:59:59','2019-12-10 07:59:59','CNDETH','4h','0.000052990000000','0.000060430000000','0.057439270945268','0.065503965714711','1083.9643507316096','1083.964350731609557','test'),('2019-12-10 15:59:59','2019-12-12 03:59:59','CNDETH','4h','0.000075450000000','0.000062700000000','0.059455444637629','0.049408301905624','788.0111946670474','788.011194667047448','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  8:07:34
