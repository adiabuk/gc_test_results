-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 23:59:59','2019-01-06 07:59:59','APPCBNB','4h','0.007760000000000','0.008280000000000','0.711908500000000','0.759613708762886','91.74078608247423','91.740786082474230','test'),('2019-01-06 11:59:59','2019-01-08 03:59:59','APPCBNB','4h','0.008470000000000','0.007310000000000','0.723834802190721','0.624702763165782','85.45865433184433','85.458654331844329','test'),('2019-01-16 03:59:59','2019-01-17 19:59:59','APPCBNB','4h','0.007280000000000','0.007340000000000','0.723834802190721','0.729800473637348','99.42785744378037','99.427857443780368','test'),('2019-01-18 15:59:59','2019-01-18 19:59:59','APPCBNB','4h','0.008050000000000','0.007330000000000','0.723834802190721','0.659094298143849','89.91736673176659','89.917366731766592','test'),('2019-01-19 03:59:59','2019-01-20 03:59:59','APPCBNB','4h','0.007560000000000','0.007350000000000','0.723834802190721','0.703728279907645','95.74534420512184','95.745344205121839','test'),('2019-01-20 07:59:59','2019-01-20 15:59:59','APPCBNB','4h','0.007410000000000','0.007170000000000','0.723834802190721','0.700390760014503','97.6835090675737','97.683509067573695','test'),('2019-01-21 07:59:59','2019-01-21 19:59:59','APPCBNB','4h','0.007640000000000','0.007310000000000','0.723834802190721','0.692569686389289','94.74277515585354','94.742775155853536','test'),('2019-01-24 11:59:59','2019-01-25 11:59:59','APPCBNB','4h','0.007620000000000','0.007270000000000','0.723834802190721','0.690587796840754','94.99144385705','94.991443857050001','test'),('2019-01-25 15:59:59','2019-01-25 19:59:59','APPCBNB','4h','0.007320000000000','0.007160000000000','0.723834802190721','0.708013276459776','98.88453581840452','98.884535818404515','test'),('2019-02-14 07:59:59','2019-02-18 03:59:59','APPCBNB','4h','0.005920000000000','0.006650000000000','0.723834802190721','0.813091458541942','122.26939226194612','122.269392261946123','test'),('2019-02-27 03:59:59','2019-02-27 15:59:59','APPCBNB','4h','0.006850000000000','0.005810000000000','0.723834802190721','0.613938715434758','105.66931418842643','105.669314188426426','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','APPCBNB','4h','0.006530000000000','0.005860000000000','0.723834802190721','0.649566912838840','110.84759604758362','110.847596047583622','test'),('2019-03-04 11:59:59','2019-03-04 15:59:59','APPCBNB','4h','0.005900000000000','0.006010000000000','0.723834802190721','0.737330027316311','122.68386477808832','122.683864778088321','test'),('2019-03-09 07:59:59','2019-03-10 07:59:59','APPCBNB','4h','0.005750000000000','0.005990000000000','0.723834802190721','0.754047037412595','125.88431342447323','125.884313424473234','test'),('2019-03-10 15:59:59','2019-03-10 23:59:59','APPCBNB','4h','0.006110000000000','0.005680000000000','0.723834802190721','0.672893891398248','118.46723440110001','118.467234401100015','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','APPCBNB','4h','0.005380000000000','0.005090000000000','0.723834802190721','0.684817684600515','134.54178479381432','134.541784793814315','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','APPCBNB','4h','0.005170000000000','0.005240000000000','0.723834802190721','0.733635273400267','140.00673156493636','140.006731564936359','test'),('2019-03-29 07:59:59','2019-04-01 03:59:59','APPCBNB','4h','0.005500000000000','0.005110000000000','0.723834802190721','0.672508334399015','131.6063276710402','131.606327671040191','test'),('2019-04-07 19:59:59','2019-04-08 15:59:59','APPCBNB','4h','0.005090000000000','0.004910000000000','0.723834802190721','0.698237500738004','142.2072302928725','142.207230292872509','test'),('2019-04-08 19:59:59','2019-04-09 07:59:59','APPCBNB','4h','0.005020000000000','0.004840000000000','0.723834802190721','0.697880566255596','144.19019963958587','144.190199639585870','test'),('2019-05-07 11:59:59','2019-05-09 07:59:59','APPCBNB','4h','0.003120000000000','0.003020000000000','0.723834802190721','0.700634968787172','231.99833403548752','231.998334035487517','test'),('2019-05-09 11:59:59','2019-05-09 15:59:59','APPCBNB','4h','0.003130000000000','0.003100000000000','0.723834802190721','0.716897088431705','231.25712530054986','231.257125300549859','test'),('2019-05-09 19:59:59','2019-05-10 03:59:59','APPCBNB','4h','0.003130000000000','0.003130000000000','0.723834802190721','0.723834802190721','231.25712530054986','231.257125300549859','test'),('2019-05-10 07:59:59','2019-05-11 15:59:59','APPCBNB','4h','0.003160000000000','0.003180000000000','0.723834802190721','0.728416035115979','229.0616462628864','229.061646262886399','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','APPCBNB','4h','0.003190000000000','0.003290000000000','0.723834802190721','0.746525548340900','226.90746150179342','226.907461501793421','test'),('2019-05-12 11:59:59','2019-05-12 15:59:59','APPCBNB','4h','0.003210000000000','0.003110000000000','0.723834802190721','0.701285431405963','225.49370784757664','225.493707847576644','test'),('2019-05-25 03:59:59','2019-05-25 07:59:59','APPCBNB','4h','0.002800000000000','0.002740000000000','0.723834802190721','0.708324056429491','258.51242935382896','258.512429353828963','test'),('2019-05-26 15:59:59','2019-05-26 23:59:59','APPCBNB','4h','0.002990000000000','0.002880000000000','0.723834802190721','0.697205428197083','242.08521812398698','242.085218123986976','test'),('2019-05-28 11:59:59','2019-05-29 07:59:59','APPCBNB','4h','0.003070000000000','0.002920000000000','0.723834802190721','0.688468280911044','235.7768085311795','235.776808531179512','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','APPCBNB','4h','0.002960000000000','0.002860000000000','0.723834802190721','0.699380923738332','244.53878452389225','244.538784523892247','test'),('2019-05-30 07:59:59','2019-05-30 19:59:59','APPCBNB','4h','0.002890000000000','0.002940000000000','0.723834802190721','0.736357895654228','250.46186927014568','250.461869270145684','test'),('2019-05-31 11:59:59','2019-06-01 03:59:59','APPCBNB','4h','0.002980000000000','0.002850000000000','0.723834802190721','0.692258116189112','242.89758462775873','242.897584627758732','test'),('2019-06-02 03:59:59','2019-06-03 23:59:59','APPCBNB','4h','0.002980000000000','0.002980000000000','0.723834802190721','0.723834802190721','242.89758462775873','242.897584627758732','test'),('2019-06-08 11:59:59','2019-06-09 19:59:59','APPCBNB','4h','0.003100000000000','0.002920000000000','0.723834802190721','0.681805684644163','233.49509748087777','233.495097480877774','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','APPCBNB','4h','0.003100000000000','0.002980000000000','0.723834802190721','0.695815390493016','233.49509748087777','233.495097480877774','test'),('2019-06-10 15:59:59','2019-06-12 03:59:59','APPCBNB','4h','0.003080000000000','0.002910000000000','0.482556534793814','0.455921920860389','156.6741996083812','156.674199608381201','test'),('2019-07-27 07:59:59','2019-07-31 03:59:59','APPCBNB','4h','0.001813000000000','0.001804000000000','0.534050127489903','0.531399023713064','294.5670863154458','294.567086315445806','test'),('2019-08-22 19:59:59','2019-09-02 19:59:59','APPCBNB','4h','0.001373000000000','0.001649000000000','0.534050127489903','0.641404705193627','388.96586124537725','388.965861245377255','test'),('2019-09-04 19:59:59','2019-09-05 19:59:59','APPCBNB','4h','0.001719000000000','0.001560000000000','0.560225995971624','0.508407535611247','325.90226641746625','325.902266417466251','test'),('2019-09-08 11:59:59','2019-09-11 11:59:59','APPCBNB','4h','0.001661000000000','0.002012000000000','0.560225995971624','0.678612103488807','337.2823575988104','337.282357598810393','test'),('2019-09-11 23:59:59','2019-09-12 07:59:59','APPCBNB','4h','0.001804000000000','0.001746000000000','0.576867907760826','0.558321156846121','319.77156749491456','319.771567494914564','test'),('2019-09-12 11:59:59','2019-09-12 15:59:59','APPCBNB','4h','0.001782000000000','0.001719000000000','0.576867907760826','0.556473587789484','323.7193646244815','323.719364624481500','test'),('2019-09-12 19:59:59','2019-09-12 23:59:59','APPCBNB','4h','0.001837000000000','0.001714000000000','0.576867907760826','0.538242566087129','314.0271680788383','314.027168078838315','test'),('2019-09-15 19:59:59','2019-09-17 07:59:59','APPCBNB','4h','0.001815000000000','0.001729000000000','0.576867907760826','0.549534221773261','317.83355799494547','317.833557994945465','test'),('2019-09-19 11:59:59','2019-09-24 15:59:59','APPCBNB','4h','0.001805000000000','0.001868000000000','0.576867907760826','0.597002355510927','319.59440873175953','319.594408731759529','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','APPCBNB','4h','0.001951000000000','0.001851000000000','0.576867907760826','0.547300101109835','295.67806650990565','295.678066509905648','test'),('2019-09-26 23:59:59','2019-10-07 23:59:59','APPCBNB','4h','0.001967000000000','0.002339000000000','0.576867907760826','0.685965448018593','293.2729576821688','293.272957682168794','test'),('2019-10-08 19:59:59','2019-10-09 11:59:59','APPCBNB','4h','0.002401000000000','0.002277000000000','0.576867907760826','0.547075479371679','240.26151926731612','240.261519267316118','test'),('2019-10-22 03:59:59','2019-10-25 07:59:59','APPCBNB','4h','0.002049000000000','0.002075000000000','0.576867907760826','0.584187851929582','281.53631418293116','281.536314182931164','test'),('2019-11-18 07:59:59','2019-11-18 23:59:59','APPCBNB','4h','0.001851000000000','0.001782000000000','0.576867907760826','0.555363917682221','311.6520301247034','311.652030124703401','test'),('2019-11-20 03:59:59','2019-11-21 03:59:59','APPCBNB','4h','0.001811000000000','0.001800000000000','0.576867907760826','0.573364016548585','318.5355647492137','318.535564749213677','test'),('2019-11-21 07:59:59','2019-11-21 11:59:59','APPCBNB','4h','0.001811000000000','0.001715000000000','0.576867907760826','0.546288493544901','318.5355647492137','318.535564749213677','test'),('2019-11-26 15:59:59','2019-12-03 15:59:59','APPCBNB','4h','0.001900000000000','0.001876000000000','0.576867907760826','0.569581155241742','303.61468829517156','303.614688295171561','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','APPCBNB','4h','0.001899000000000','0.001919000000000','0.576867907760826','0.582943399153778','303.7745696476177','303.774569647617682','test'),('2019-12-08 11:59:59','2019-12-10 03:59:59','APPCBNB','4h','0.001911000000000','0.001875000000000','0.576867907760826','0.566000694427812','301.8670370281664','301.867037028166408','test'),('2019-12-17 03:59:59','2019-12-17 23:59:59','APPCBNB','4h','0.001882000000000','0.001838000000000','0.576867907760826','0.563381091638894','306.51854822573114','306.518548225731138','test'),('2019-12-19 19:59:59','2019-12-19 23:59:59','APPCBNB','4h','0.001863000000000','0.001880000000000','0.576867907760826','0.582131866124720','309.64460964080837','309.644609640808369','test'),('2019-12-20 03:59:59','2019-12-20 19:59:59','APPCBNB','4h','0.001901000000000','0.001906000000000','0.576867907760826','0.578385182636578','303.4549751503556','303.454975150355608','test'),('2019-12-21 15:59:59','2019-12-21 19:59:59','APPCBNB','4h','0.001893000000000','0.001841000000000','0.576867907760826','0.561021562698194','304.73740505062125','304.737405050621248','test'),('2019-12-28 07:59:59','2019-12-30 11:59:59','APPCBNB','4h','0.001875000000000','0.001848000000000','0.576867907760826','0.568561009889070','307.6628841391072','307.662884139107177','test'),('2019-12-30 15:59:59','2019-12-30 19:59:59','APPCBNB','4h','0.001896000000000','0.001840000000000','0.576867907760826','0.559829615126540','304.25522561225','304.255225612250001','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  1:19:56
