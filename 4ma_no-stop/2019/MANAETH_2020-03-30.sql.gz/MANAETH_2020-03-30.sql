-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-16 19:59:59','2019-01-18 15:59:59','MANAETH','4h','0.000328000000000','0.000323210000000','0.072144500000000','0.071090926356707','219.952743902439','219.952743902439011','test'),('2019-01-18 19:59:59','2019-01-20 11:59:59','MANAETH','4h','0.000324080000000','0.000319400000000','0.072144500000000','0.071102670019748','222.61324364354482','222.613243643544820','test'),('2019-01-22 11:59:59','2019-01-24 07:59:59','MANAETH','4h','0.000335760000000','0.000327800000000','0.072144500000000','0.070434140755301','214.86925184655706','214.869251846557063','test'),('2019-01-24 15:59:59','2019-01-27 15:59:59','MANAETH','4h','0.000333950000000','0.000332520000000','0.072144500000000','0.071835571612517','216.0338374008085','216.033837400808494','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','MANAETH','4h','0.000306960000000','0.000293480000000','0.072144500000000','0.068976309160803','235.02899400573364','235.028994005733637','test'),('2019-02-26 15:59:59','2019-03-02 03:59:59','MANAETH','4h','0.000362480000000','0.000308450000000','0.072144500000000','0.061390893359634','199.03029132641802','199.030291326418023','test'),('2019-03-04 23:59:59','2019-03-05 19:59:59','MANAETH','4h','0.000316050000000','0.000307980000000','0.072144500000000','0.070302367062174','228.26926119284923','228.269261192849228','test'),('2019-03-05 23:59:59','2019-03-06 07:59:59','MANAETH','4h','0.000314110000000','0.000302070000000','0.072144500000000','0.069379163716532','229.6790933112604','229.679093311260402','test'),('2019-03-08 07:59:59','2019-03-11 23:59:59','MANAETH','4h','0.000341100000000','0.000335290000000','0.072144500000000','0.070915653488713','211.50542362943418','211.505423629434176','test'),('2019-03-12 19:59:59','2019-03-14 11:59:59','MANAETH','4h','0.000352120000000','0.000341340000000','0.072144500000000','0.069935827643985','204.88611836873795','204.886118368737954','test'),('2019-03-14 23:59:59','2019-03-16 07:59:59','MANAETH','4h','0.000352450000000','0.000339000000000','0.072144500000000','0.069391361895304','204.69428287700384','204.694282877003843','test'),('2019-03-17 07:59:59','2019-03-19 23:59:59','MANAETH','4h','0.000351830000000','0.000354970000000','0.072144500000000','0.072788372694199','205.05499815251682','205.054998152516816','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','MANAETH','4h','0.000363620000000','0.000358920000000','0.072144500000000','0.071211990374567','198.40630328364776','198.406303283647759','test'),('2019-03-21 19:59:59','2019-03-26 03:59:59','MANAETH','4h','0.000360580000000','0.000371510000000','0.072144500000000','0.074331363899828','200.07903932553108','200.079039325531085','test'),('2019-03-28 03:59:59','2019-03-30 03:59:59','MANAETH','4h','0.000394960000000','0.000399190000000','0.072144500000000','0.072917163649483','182.66280129633378','182.662801296333782','test'),('2019-05-24 07:59:59','2019-05-24 19:59:59','MANAETH','4h','0.000249040000000','0.000244730000000','0.072144500000000','0.070895934327819','289.6904111789271','289.690411178927093','test'),('2019-05-25 07:59:59','2019-05-25 11:59:59','MANAETH','4h','0.000236880000000','0.000232560000000','0.072144500000000','0.070828794832827','304.5613812901047','304.561381290104691','test'),('2019-05-25 15:59:59','2019-05-26 11:59:59','MANAETH','4h','0.000239190000000','0.000233660000000','0.072144500000000','0.070476541117940','301.62005100547685','301.620051005476853','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','MANAETH','4h','0.000239980000000','0.000225930000000','0.072144500000000','0.067920688744895','300.6271355946329','300.627135594632875','test'),('2019-06-07 11:59:59','2019-06-11 07:59:59','MANAETH','4h','0.000233850000000','0.000239870000000','0.072144500000000','0.074001715693821','308.5075903356853','308.507590335685279','test'),('2019-07-04 03:59:59','2019-07-06 07:59:59','MANAETH','4h','0.000207690000000','0.000181220000000','0.072144500000000','0.062949714911647','347.3662670325966','347.366267032596625','test'),('2019-07-14 19:59:59','2019-07-23 11:59:59','MANAETH','4h','0.000179890000000','0.000198240000000','0.072144500000000','0.079503728278392','401.04786258268945','401.047862582689447','test'),('2019-08-09 15:59:59','2019-08-10 11:59:59','MANAETH','4h','0.000194910000000','0.000189340000000','0.072144500000000','0.070082805551280','370.1426299317634','370.142629931763395','test'),('2019-08-10 23:59:59','2019-08-11 15:59:59','MANAETH','4h','0.000193260000000','0.000187600000000','0.072144500000000','0.070031606126462','373.3028045120563','373.302804512056298','test'),('2019-08-12 11:59:59','2019-08-13 03:59:59','MANAETH','4h','0.000194020000000','0.000189180000000','0.072144500000000','0.070344791825585','371.84053190392746','371.840531903927456','test'),('2019-08-13 11:59:59','2019-08-13 19:59:59','MANAETH','4h','0.000192870000000','0.000190060000000','0.072144500000000','0.071093397988282','374.0576554155649','374.057655415564909','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','MANAETH','4h','0.000192500000000','0.000190610000000','0.072144500000000','0.071436172181818','374.7766233766234','374.776623376623377','test'),('2019-08-14 19:59:59','2019-08-15 15:59:59','MANAETH','4h','0.000195890000000','0.000190500000000','0.072144500000000','0.070159412170095','368.2908775333095','368.290877533309526','test'),('2019-08-15 19:59:59','2019-08-15 23:59:59','MANAETH','4h','0.000193000000000','0.000189230000000','0.072144500000000','0.070735252512953','373.8056994818653','373.805699481865304','test'),('2019-08-16 07:59:59','2019-08-16 11:59:59','MANAETH','4h','0.000192430000000','0.000191290000000','0.072144500000000','0.071717099230889','374.9129553603908','374.912955360390811','test'),('2019-08-16 15:59:59','2019-08-16 19:59:59','MANAETH','4h','0.000192120000000','0.000188930000000','0.072144500000000','0.070946597881532','375.5179054757443','375.517905475744328','test'),('2019-08-17 19:59:59','2019-08-18 03:59:59','MANAETH','4h','0.000193940000000','0.000191820000000','0.072144500000000','0.071355872898835','371.9939156440136','371.993915644013612','test'),('2019-08-18 07:59:59','2019-08-18 15:59:59','MANAETH','4h','0.000194980000000','0.000190840000000','0.072144500000000','0.070612659657401','370.00974458918864','370.009744589188642','test'),('2019-08-24 19:59:59','2019-08-25 15:59:59','MANAETH','4h','0.000200860000000','0.000193020000000','0.072144500000000','0.069328544209897','359.178034451857','359.178034451857002','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','MANAETH','4h','0.000195330000000','0.000188010000000','0.072144500000000','0.069440881815389','369.3467465315108','369.346746531510803','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','MANAETH','4h','0.000189000000000','0.000186120000000','0.072144500000000','0.071045155238095','381.7169312169312','381.716931216931187','test'),('2019-08-31 11:59:59','2019-08-31 19:59:59','MANAETH','4h','0.000192990000000','0.000188090000000','0.072144500000000','0.070312757163584','373.82506865640704','373.825068656407041','test'),('2019-09-04 19:59:59','2019-09-06 03:59:59','MANAETH','4h','0.000202620000000','0.000183700000000','0.072144500000000','0.065407880021716','356.0581383871286','356.058138387128622','test'),('2019-09-26 19:59:59','2019-09-27 11:59:59','MANAETH','4h','0.000161300000000','0.000166750000000','0.072144500000000','0.074582116398016','447.26906385616866','447.269063856168657','test'),('2019-10-03 23:59:59','2019-10-06 15:59:59','MANAETH','4h','0.000167790000000','0.000165380000000','0.072144500000000','0.071108274688599','429.96900888014784','429.969008880147840','test'),('2019-10-06 19:59:59','2019-10-06 23:59:59','MANAETH','4h','0.000166250000000','0.000164930000000','0.072144500000000','0.071571683518797','433.95187969924814','433.951879699248138','test'),('2019-10-08 07:59:59','2019-10-09 15:59:59','MANAETH','4h','0.000173950000000','0.000158070000000','0.072144500000000','0.065558385254383','414.74274216728946','414.742742167289464','test'),('2019-10-12 11:59:59','2019-10-18 03:59:59','MANAETH','4h','0.000174980000000','0.000178850000000','0.072144500000000','0.073740106440736','412.30140587495714','412.301405874957140','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','MANAETH','4h','0.000176200000000','0.000171500000000','0.072144500000000','0.070220100737798','409.4466515323496','409.446651532349620','test'),('2019-10-27 15:59:59','2019-10-27 19:59:59','MANAETH','4h','0.000173060000000','0.000172370000000','0.072144500000000','0.071856855801456','416.87565006356175','416.875650063561750','test'),('2019-10-27 23:59:59','2019-10-28 03:59:59','MANAETH','4h','0.000174100000000','0.000173840000000','0.072144500000000','0.072036759793222','414.3854106835152','414.385410683515204','test'),('2019-10-28 11:59:59','2019-10-28 15:59:59','MANAETH','4h','0.000173890000000','0.000172690000000','0.072144500000000','0.071646636983150','414.88584737477714','414.885847374777143','test'),('2019-10-28 19:59:59','2019-10-29 03:59:59','MANAETH','4h','0.000174930000000','0.000174100000000','0.072144500000000','0.071802192019665','412.41925341565195','412.419253415651951','test'),('2019-11-01 15:59:59','2019-11-02 15:59:59','MANAETH','4h','0.000176630000000','0.000170500000000','0.048096333333333','0.046427134877050','272.2999113023458','272.299911302345777','test'),('2019-11-02 19:59:59','2019-11-02 23:59:59','MANAETH','4h','0.000171290000000','0.000171860000000','0.053681923312547','0.053860560105636','313.39788261163517','313.397882611635168','test'),('2019-11-03 03:59:59','2019-11-03 07:59:59','MANAETH','4h','0.000173290000000','0.000171740000000','0.053726582510819','0.053246022738808','310.038562587681','310.038562587680985','test'),('2019-11-27 23:59:59','2019-12-01 11:59:59','MANAETH','4h','0.000161830000000','0.000164570000000','0.053726582510819','0.054636245960610','331.99395977766176','331.993959777661757','test'),('2019-12-04 07:59:59','2019-12-04 15:59:59','MANAETH','4h','0.000168400000000','0.000166550000000','0.053833858430264','0.053242453215917','319.6784942414741','319.678494241474084','test'),('2019-12-05 23:59:59','2019-12-06 07:59:59','MANAETH','4h','0.000166200000000','0.000167630000000','0.053833858430264','0.054297049871631','323.9100988583875','323.910098858387528','test'),('2019-12-06 15:59:59','2019-12-10 11:59:59','MANAETH','4h','0.000168420000000','0.000184680000000','0.053833858430264','0.059031213483560','319.6405321830187','319.640532183018706','test'),('2019-12-10 19:59:59','2019-12-12 19:59:59','MANAETH','4h','0.000182630000000','0.000178450000000','0.055101143750343','0.053839999464758','301.70915923092167','301.709159230921671','test'),('2019-12-15 23:59:59','2019-12-22 19:59:59','MANAETH','4h','0.000186100000000','0.000217420000000','0.055101143750343','0.064374479710906','296.08352364504566','296.083523645045659','test'),('2019-12-24 15:59:59','2019-12-29 15:59:59','MANAETH','4h','0.000230520000000','0.000249430000000','0.057104191669088','0.061788558598042','247.7190337892058','247.719033789205810','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:10:06
