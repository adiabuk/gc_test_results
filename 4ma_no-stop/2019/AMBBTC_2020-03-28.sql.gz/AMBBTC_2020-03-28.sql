-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-06 15:59:59','AMBBTC','4h','0.000019430000000','0.000018490000000','0.001467500000000','0.001396504117344','75.52753474009265','75.527534740092648','test'),('2019-01-09 19:59:59','2019-01-10 07:59:59','AMBBTC','4h','0.000019010000000','0.000018520000000','0.001467500000000','0.001429673855865','77.19621251972647','77.196212519726473','test'),('2019-01-16 07:59:59','2019-01-18 11:59:59','AMBBTC','4h','0.000019900000000','0.000018580000000','0.001467500000000','0.001370158291457','73.74371859296483','73.743718592964825','test'),('2019-01-18 15:59:59','2019-01-20 11:59:59','AMBBTC','4h','0.000019060000000','0.000018390000000','0.001467500000000','0.001415914218258','76.99370409233998','76.993704092339982','test'),('2019-01-23 03:59:59','2019-01-23 19:59:59','AMBBTC','4h','0.000019030000000','0.000018400000000','0.001467500000000','0.001418917498686','77.11508145034158','77.115081450341577','test'),('2019-01-25 07:59:59','2019-01-25 11:59:59','AMBBTC','4h','0.000019530000000','0.000019140000000','0.001467500000000','0.001438195084485','75.14080901177675','75.140809011776753','test'),('2019-01-25 23:59:59','2019-01-26 19:59:59','AMBBTC','4h','0.000019410000000','0.000018810000000','0.001467500000000','0.001422136785162','75.60535806285421','75.605358062854208','test'),('2019-03-03 19:59:59','2019-03-03 23:59:59','AMBBTC','4h','0.000013790000000','0.000013830000000','0.001467500000000','0.001471756707759','106.41769398114576','106.417693981145760','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','AMBBTC','4h','0.000013970000000','0.000013520000000','0.001467500000000','0.001420229062276','105.04652827487473','105.046528274874731','test'),('2019-03-04 19:59:59','2019-03-06 11:59:59','AMBBTC','4h','0.000014490000000','0.000013910000000','0.001467500000000','0.001408759489303','101.2767425810904','101.276742581090403','test'),('2019-03-06 15:59:59','2019-03-06 23:59:59','AMBBTC','4h','0.000014090000000','0.000013790000000','0.001467500000000','0.001436254435770','104.15188076650107','104.151880766501066','test'),('2019-03-09 03:59:59','2019-03-10 07:59:59','AMBBTC','4h','0.000014410000000','0.000013820000000','0.001467500000000','0.001407414989591','101.83900069396253','101.839000693962532','test'),('2019-03-10 11:59:59','2019-03-10 19:59:59','AMBBTC','4h','0.000014130000000','0.000014140000000','0.001467500000000','0.001468538570418','103.85704175513094','103.857041755130936','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','AMBBTC','4h','0.000014210000000','0.000013880000000','0.001467500000000','0.001433420126671','103.27234342012667','103.272343420126674','test'),('2019-03-12 11:59:59','2019-03-16 11:59:59','AMBBTC','4h','0.000014660000000','0.000014860000000','0.001467500000000','0.001487520463847','100.10231923601637','100.102319236016370','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','AMBBTC','4h','0.000015030000000','0.000013880000000','0.001467500000000','0.001355216234198','97.63805721889554','97.638057218895540','test'),('2019-03-27 07:59:59','2019-04-02 07:59:59','AMBBTC','4h','0.000014810000000','0.000015130000000','0.001467500000000','0.001499208305199','99.08845374746792','99.088453747467923','test'),('2019-05-18 15:59:59','2019-05-19 23:59:59','AMBBTC','4h','0.000006350000000','0.000005800000000','0.001467500000000','0.001340393700787','231.10236220472441','231.102362204724415','test'),('2019-05-20 07:59:59','2019-05-20 19:59:59','AMBBTC','4h','0.000005820000000','0.000005920000000','0.001467500000000','0.001492714776632','252.14776632302406','252.147766323024058','test'),('2019-05-21 03:59:59','2019-05-25 07:59:59','AMBBTC','4h','0.000005870000000','0.000006390000000','0.001467500000000','0.001597500000000','250.00000000000003','250.000000000000028','test'),('2019-06-07 15:59:59','2019-06-09 15:59:59','AMBBTC','4h','0.000006490000000','0.000005680000000','0.001467500000000','0.001284345146379','226.11710323574732','226.117103235747322','test'),('2019-06-10 19:59:59','2019-06-12 07:59:59','AMBBTC','4h','0.000005930000000','0.000005770000000','0.001467500000000','0.001427904721754','247.47048903878584','247.470489038785843','test'),('2019-06-12 11:59:59','2019-06-12 15:59:59','AMBBTC','4h','0.000005810000000','0.000005790000000','0.001467500000000','0.001462448364888','252.5817555938038','252.581755593803791','test'),('2019-06-12 19:59:59','2019-06-13 15:59:59','AMBBTC','4h','0.000005860000000','0.000005800000000','0.001467500000000','0.001452474402730','250.42662116040958','250.426621160409582','test'),('2019-06-14 07:59:59','2019-06-14 11:59:59','AMBBTC','4h','0.000005920000000','0.000005560000000','0.001467500000000','0.001378260135135','247.88851351351352','247.888513513513516','test'),('2019-07-26 03:59:59','2019-07-27 11:59:59','AMBBTC','4h','0.000002960000000','0.000002920000000','0.001467500000000','0.001447668918919','495.77702702702703','495.777027027027032','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','AMBBTC','4h','0.000002940000000','0.000002920000000','0.001467500000000','0.001457517006803','499.14965986394566','499.149659863945658','test'),('2019-07-28 19:59:59','2019-07-31 11:59:59','AMBBTC','4h','0.000003010000000','0.000003000000000','0.001467500000000','0.001462624584718','487.5415282392027','487.541528239202705','test'),('2019-08-14 23:59:59','2019-08-15 11:59:59','AMBBTC','4h','0.000002430000000','0.000002330000000','0.001467500000000','0.001407109053498','603.9094650205761','603.909465020576135','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','AMBBTC','4h','0.000002370000000','0.000002270000000','0.001467500000000','0.001405580168776','619.1983122362869','619.198312236286938','test'),('2019-08-23 19:59:59','2019-08-23 23:59:59','AMBBTC','4h','0.000002290000000','0.000002300000000','0.001467500000000','0.001473908296943','640.829694323144','640.829694323144054','test'),('2019-08-24 07:59:59','2019-08-25 15:59:59','AMBBTC','4h','0.000002350000000','0.000002420000000','0.001467500000000','0.001511212765957','624.468085106383','624.468085106383000','test'),('2019-08-27 03:59:59','2019-08-28 07:59:59','AMBBTC','4h','0.000002380000000','0.000002320000000','0.001467500000000','0.001430504201681','616.5966386554621','616.596638655462129','test'),('2019-09-17 19:59:59','2019-09-24 03:59:59','AMBBTC','4h','0.000001780000000','0.000002010000000','0.001467500000000','0.001657120786517','824.438202247191','824.438202247191043','test'),('2019-09-24 11:59:59','2019-09-24 15:59:59','AMBBTC','4h','0.000002150000000','0.000002070000000','0.001467500000000','0.001412895348837','682.5581395348837','682.558139534883708','test'),('2019-09-27 19:59:59','2019-09-30 07:59:59','AMBBTC','4h','0.000002060000000','0.000001960000000','0.001467500000000','0.001396262135922','712.378640776699','712.378640776698944','test'),('2019-09-30 19:59:59','2019-10-13 03:59:59','AMBBTC','4h','0.000002100000000','0.000003930000000','0.001467500000000','0.002746321428571','698.8095238095239','698.809523809523853','test'),('2019-10-13 15:59:59','2019-10-16 15:59:59','AMBBTC','4h','0.000004500000000','0.000004150000000','0.001524271045434','0.001405716630789','338.7268989853332','338.726898985333207','test'),('2019-10-21 23:59:59','2019-10-22 07:59:59','AMBBTC','4h','0.000004270000000','0.000004170000000','0.001524271045434','0.001488573831255','356.97214178782207','356.972141787822068','test'),('2019-11-01 15:59:59','2019-11-01 23:59:59','AMBBTC','4h','0.000003640000000','0.000003620000000','0.001524271045434','0.001515895929800','418.75578171263743','418.755781712637429','test'),('2019-11-02 03:59:59','2019-11-02 15:59:59','AMBBTC','4h','0.000003630000000','0.000003580000000','0.001524271045434','0.001503275576489','419.90937890743805','419.909378907438054','test'),('2019-11-14 11:59:59','2019-11-15 11:59:59','AMBBTC','4h','0.000003560000000','0.000003430000000','0.001524271045434','0.001468609462314','428.16602399831464','428.166023998314643','test'),('2019-11-15 19:59:59','2019-11-17 23:59:59','AMBBTC','4h','0.000003420000000','0.000003390000000','0.001524271045434','0.001510900246790','445.69328813859653','445.693288138596529','test'),('2019-11-26 11:59:59','2019-11-26 15:59:59','AMBBTC','4h','0.000003320000000','0.000003260000000','0.001524271045434','0.001496723978348','459.11778476927714','459.117784769277137','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:08:36
