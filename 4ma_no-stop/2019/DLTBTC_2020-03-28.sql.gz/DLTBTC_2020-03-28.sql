-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 23:59:59','2019-01-05 07:59:59','DLTBTC','4h','0.000010790000000','0.000012340000000','0.001467500000000','0.001678308619092','136.0055607043559','136.005560704355901','test'),('2019-01-07 15:59:59','2019-01-10 15:59:59','DLTBTC','4h','0.000013290000000','0.000014170000000','0.001520202154773','0.001620862643577','114.38691909503386','114.386919095033861','test'),('2019-01-11 15:59:59','2019-01-17 03:59:59','DLTBTC','4h','0.000015820000000','0.000026440000000','0.001545367276974','0.002582775651276','97.68440435992413','97.684404359924130','test'),('2019-01-17 15:59:59','2019-01-19 23:59:59','DLTBTC','4h','0.000037860000000','0.000030190000000','0.001804719370550','0.001439104009427','47.668234826980985','47.668234826980985','test'),('2019-01-21 03:59:59','2019-01-27 15:59:59','DLTBTC','4h','0.000035020000000','0.000036220000000','0.001804719370550','0.001866560125680','51.53396260850942','51.533962608509420','test'),('2019-02-03 03:59:59','2019-02-03 15:59:59','DLTBTC','4h','0.000036630000000','0.000034660000000','0.001804719370550','0.001707659661023','49.26888808490308','49.268888084903082','test'),('2019-03-06 15:59:59','2019-03-07 07:59:59','DLTBTC','4h','0.000027760000000','0.000024870000000','0.001804719370550','0.001616836121959','65.0115047028098','65.011504702809802','test'),('2019-03-07 11:59:59','2019-03-07 15:59:59','DLTBTC','4h','0.000025260000000','0.000025920000000','0.001804719370550','0.001851873558379','71.44573913499605','71.445739134996046','test'),('2019-03-09 19:59:59','2019-03-10 15:59:59','DLTBTC','4h','0.000026010000000','0.000025310000000','0.001804719370550','0.001756149452850','69.38559671472511','69.385596714725111','test'),('2019-03-10 19:59:59','2019-03-11 07:59:59','DLTBTC','4h','0.000025590000000','0.000025400000000','0.001804719370550','0.001791319734739','70.52439900547088','70.524399005470883','test'),('2019-03-12 23:59:59','2019-03-17 07:59:59','DLTBTC','4h','0.000026410000000','0.000027390000000','0.001804719370550','0.001871687374455','68.33469786255206','68.334697862552062','test'),('2019-03-27 07:59:59','2019-04-02 07:59:59','DLTBTC','4h','0.000028280000000','0.000027580000000','0.001804719370550','0.001760048099002','63.81610221181047','63.816102211810467','test'),('2019-05-06 15:59:59','2019-05-07 23:59:59','DLTBTC','4h','0.000019450000000','0.000015080000000','0.001804719370550','0.001399237434853','92.7876283059126','92.787628305912605','test'),('2019-05-18 07:59:59','2019-05-20 03:59:59','DLTBTC','4h','0.000015130000000','0.000014780000000','0.001804719370550','0.001762971070504','119.28085727362854','119.280857273628541','test'),('2019-05-20 11:59:59','2019-05-20 19:59:59','DLTBTC','4h','0.000015270000000','0.000014840000000','0.001804719370550','0.001753898851275','118.18725412901112','118.187254129011123','test'),('2019-05-21 03:59:59','2019-05-24 19:59:59','DLTBTC','4h','0.000015440000000','0.000016310000000','0.001804719370550','0.001906410164098','116.88596959520724','116.885969595207243','test'),('2019-06-08 03:59:59','2019-06-14 07:59:59','DLTBTC','4h','0.000014030000000','0.000015260000000','0.001804719370550','0.001962937818574','128.63288457234498','128.632884572344977','test'),('2019-07-27 19:59:59','2019-07-27 23:59:59','DLTBTC','4h','0.000006180000000','0.000006140000000','0.001804719370550','0.001793038339025','292.0257881148867','292.025788114886723','test'),('2019-07-28 15:59:59','2019-07-30 15:59:59','DLTBTC','4h','0.000006420000000','0.000006250000000','0.001804719370550','0.001756930851392','281.1089362227414','281.108936222741420','test'),('2019-08-22 15:59:59','2019-08-23 15:59:59','DLTBTC','4h','0.000004870000000','0.000004510000000','0.001804719370550','0.001671310957121','370.5789261909651','370.578926190965092','test'),('2019-08-24 07:59:59','2019-08-25 15:59:59','DLTBTC','4h','0.000004760000000','0.000004980000000','0.001804719370550','0.001888130770029','379.14272490546216','379.142724905462160','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','DLTBTC','4h','0.000005210000000','0.000004760000000','0.001804719370550','0.001648841497854','346.3952726583493','346.395272658349313','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','DLTBTC','4h','0.000004790000000','0.000004710000000','0.001804719370550','0.001774577919685','376.7681358141962','376.768135814196228','test'),('2019-09-14 19:59:59','2019-09-15 03:59:59','DLTBTC','4h','0.000005870000000','0.000004550000000','0.001804719370550','0.001398888098126','307.44793365417377','307.447933654173767','test'),('2019-09-15 11:59:59','2019-09-17 07:59:59','DLTBTC','4h','0.000004420000000','0.000004040000000','0.001804719370550','0.001649562501589','408.30754989819','408.307549898190018','test'),('2019-09-17 23:59:59','2019-09-22 19:59:59','DLTBTC','4h','0.000004330000000','0.000004490000000','0.001804719370550','0.001871406460455','416.79431190531176','416.794311905311758','test'),('2019-09-23 11:59:59','2019-09-24 15:59:59','DLTBTC','4h','0.000004930000000','0.000004390000000','0.001804719370550','0.001607042198117','366.06883783975655','366.068837839756554','test'),('2019-09-26 03:59:59','2019-09-26 19:59:59','DLTBTC','4h','0.000004820000000','0.000004740000000','0.001203146247033','0.001183177014717','249.61540394882434','249.615403948824337','test'),('2019-09-26 23:59:59','2019-09-29 23:59:59','DLTBTC','4h','0.000004890000000','0.000005110000000','0.001348016606723','0.001408663570625','275.66801773481603','275.668017734816033','test'),('2019-09-30 19:59:59','2019-10-06 07:59:59','DLTBTC','4h','0.000005410000000','0.000005550000000','0.001363178347699','0.001398454682020','251.97381658017565','251.973816580175651','test'),('2019-10-07 15:59:59','2019-10-07 19:59:59','DLTBTC','4h','0.000005730000000','0.000005590000000','0.001371997431279','0.001338475679031','239.4410874832461','239.441087483246093','test'),('2019-10-07 23:59:59','2019-10-09 15:59:59','DLTBTC','4h','0.000005680000000','0.000005320000000','0.001371997431279','0.001285039847606','241.54884353503522','241.548843535035218','test'),('2019-10-24 19:59:59','2019-10-25 03:59:59','DLTBTC','4h','0.000005160000000','0.000005050000000','0.001371997431279','0.001342749424023','265.89097505406977','265.890975054069770','test'),('2019-11-06 07:59:59','2019-11-06 11:59:59','DLTBTC','4h','0.000004590000000','0.000004560000000','0.001371997431279','0.001363030127807','298.9101157470588','298.910115747058796','test'),('2019-11-06 19:59:59','2019-11-07 11:59:59','DLTBTC','4h','0.000004580000000','0.000004570000000','0.001371997431279','0.001369001803700','299.562757921179','299.562757921179013','test'),('2019-11-07 15:59:59','2019-11-08 11:59:59','DLTBTC','4h','0.000004660000000','0.000004550000000','0.001371997431279','0.001339611225820','294.42004963068666','294.420049630686663','test'),('2019-11-09 15:59:59','2019-11-18 19:59:59','DLTBTC','4h','0.000004670000000','0.000005350000000','0.001371997431279','0.001571774359174','293.78959984561027','293.789599845610269','test'),('2019-11-25 11:59:59','2019-11-29 15:59:59','DLTBTC','4h','0.000005650000000','0.000005650000000','0.001373422543331','0.001373422543331','243.08363598778763','243.083635987787630','test'),('2019-11-30 23:59:59','2019-12-02 19:59:59','DLTBTC','4h','0.000005900000000','0.000005640000000','0.001373422543331','0.001312898838032','232.7834819205085','232.783481920508507','test'),('2019-12-07 19:59:59','2019-12-08 03:59:59','DLTBTC','4h','0.000005830000000','0.000005570000000','0.001373422543331','0.001312172138311','235.5784808457976','235.578480845797600','test'),('2019-12-08 07:59:59','2019-12-08 11:59:59','DLTBTC','4h','0.000005640000000','0.000005720000000','0.001373422543331','0.001392903714158','243.51463534237587','243.514635342375868','test'),('2019-12-08 15:59:59','2019-12-10 03:59:59','DLTBTC','4h','0.000005790000000','0.000005530000000','0.001373422543331','0.001311748992162','237.20596603298793','237.205966032987931','test'),('2019-12-27 11:59:59','2019-12-29 15:59:59','DLTBTC','4h','0.000005320000000','0.000005100000000','0.001373422543331','0.001316626874246','258.1621322050752','258.162132205075181','test'),('2019-12-30 07:59:59','2019-12-31 23:59:59','DLTBTC','4h','0.000005330000000','0.000005310000000','0.001373422543331','0.001368268987821','257.67777548424016','257.677775484240158','test'),('2020-01-01 03:59:59','2020-01-01 15:59:59','DLTBTC','4h','0.000005320000000','0.000005360000000','0.001373422543331','0.001383749028619','258.1621322050752','258.162132205075181','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:03:21
