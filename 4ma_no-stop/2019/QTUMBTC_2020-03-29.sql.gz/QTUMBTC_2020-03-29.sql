-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 19:59:59','2019-01-10 23:59:59','QTUMBTC','4h','0.000578000000000','0.000579000000000','0.001467500000000','0.001470038927336','2.5389273356401385','2.538927335640139','test'),('2019-01-12 19:59:59','2019-01-13 19:59:59','QTUMBTC','4h','0.000630000000000','0.000581000000000','0.001468134731834','0.001353946474914','2.3303725902126984','2.330372590212698','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','QTUMBTC','4h','0.000592000000000','0.000588000000000','0.001468134731834','0.001458214902565','2.479957317287162','2.479957317287162','test'),('2019-02-16 03:59:59','2019-02-17 03:59:59','QTUMBTC','4h','0.000544000000000','0.000532000000000','0.001468134731834','0.001435749406867','2.6987770805772056','2.698777080577206','test'),('2019-02-17 07:59:59','2019-02-20 03:59:59','QTUMBTC','4h','0.000535000000000','0.000536000000000','0.001468134731834','0.001470878908903','2.744177068848598','2.744177068848598','test'),('2019-02-23 03:59:59','2019-02-24 15:59:59','QTUMBTC','4h','0.000572000000000','0.000540000000000','0.001468134731834','0.001386001320263','2.5666691115979017','2.566669111597902','test'),('2019-02-24 19:59:59','2019-02-24 23:59:59','QTUMBTC','4h','0.000546000000000','0.000534000000000','0.001468134731834','0.001435868034431','2.688891450245421','2.688891450245421','test'),('2019-03-01 03:59:59','2019-03-01 15:59:59','QTUMBTC','4h','0.000565000000000','0.000554000000000','0.001468134731834','0.001439551577763','2.598468551918584','2.598468551918584','test'),('2019-03-01 19:59:59','2019-03-02 07:59:59','QTUMBTC','4h','0.000555000000000','0.000543000000000','0.001468134731834','0.001436391278173','2.645287805106306','2.645287805106306','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','QTUMBTC','4h','0.000545000000000','0.000545000000000','0.001468134731834','0.001468134731834','2.693825196025688','2.693825196025688','test'),('2019-03-09 07:59:59','2019-03-10 11:59:59','QTUMBTC','4h','0.000556000000000','0.000547000000000','0.001468134731834','0.001444369960995','2.640530093226619','2.640530093226619','test'),('2019-03-10 23:59:59','2019-03-11 03:59:59','QTUMBTC','4h','0.000544000000000','0.000548000000000','0.001468134731834','0.001478929840156','2.6987770805772056','2.698777080577206','test'),('2019-03-12 19:59:59','2019-03-13 11:59:59','QTUMBTC','4h','0.000556000000000','0.000551000000000','0.001468134731834','0.001454932081368','2.640530093226619','2.640530093226619','test'),('2019-03-13 23:59:59','2019-03-14 03:59:59','QTUMBTC','4h','0.000549000000000','0.000548000000000','0.001468134731834','0.001465460533780','2.674198054342441','2.674198054342441','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','QTUMBTC','4h','0.000546000000000','0.000698000000000','0.001468134731834','0.001876846232271','2.688891450245421','2.688891450245421','test'),('2019-03-14 23:59:59','2019-03-17 07:59:59','QTUMBTC','4h','0.000687000000000','0.000612000000000','0.001480981991486','0.001319302734774','2.1557234228322417','2.155723422832242','test'),('2019-03-17 15:59:59','2019-03-18 23:59:59','QTUMBTC','4h','0.000637000000000','0.000616000000000','0.001480981991486','0.001432158409349','2.3249324827095763','2.324932482709576','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','QTUMBTC','4h','0.000636000000000','0.000613000000000','0.001480981991486','0.001427424466637','2.3285880369276732','2.328588036927673','test'),('2019-03-22 15:59:59','2019-03-25 11:59:59','QTUMBTC','4h','0.000628000000000','0.000635000000000','0.001480981991486','0.001497489752538','2.358251578799363','2.358251578799363','test'),('2019-03-28 15:59:59','2019-04-02 07:59:59','QTUMBTC','4h','0.000671000000000','0.000681000000000','0.001480981991486','0.001503053258125','2.2071266639135616','2.207126663913562','test'),('2019-04-07 19:59:59','2019-04-08 07:59:59','QTUMBTC','4h','0.000697000000000','0.000673000000000','0.001480981991486','0.001429986915739','2.1247948227919653','2.124794822791965','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','QTUMBTC','4h','0.000667000000000','0.000657000000000','0.001480981991486','0.001458778363428','2.220362805826087','2.220362805826087','test'),('2019-05-17 11:59:59','2019-05-18 07:59:59','QTUMBTC','4h','0.000391000000000','0.000383000000000','0.001480981991486','0.001450680569665','3.7876777275856774','3.787677727585677','test'),('2019-05-18 11:59:59','2019-05-18 15:59:59','QTUMBTC','4h','0.000384000000000','0.000386000000000','0.001480981991486','0.001488695439358','3.8567239361614583','3.856723936161458','test'),('2019-05-18 23:59:59','2019-05-19 03:59:59','QTUMBTC','4h','0.000389000000000','0.000378000000000','0.001480981991486','0.001439103323346','3.807151649064267','3.807151649064267','test'),('2019-05-19 19:59:59','2019-05-19 23:59:59','QTUMBTC','4h','0.000396000000000','0.000385000000000','0.001480981991486','0.001439843602834','3.7398535138535354','3.739853513853535','test'),('2019-05-20 15:59:59','2019-05-20 23:59:59','QTUMBTC','4h','0.000399000000000','0.000391000000000','0.001480981991486','0.001451288116970','3.7117343145012534','3.711734314501253','test'),('2019-05-21 07:59:59','2019-05-22 11:59:59','QTUMBTC','4h','0.000392000000000','0.000388000000000','0.001480981991486','0.001465869930348','3.7780152844030614','3.778015284403061','test'),('2019-05-30 03:59:59','2019-05-30 23:59:59','QTUMBTC','4h','0.000402000000000','0.000377000000000','0.001480981991486','0.001388881121369','3.6840348046915423','3.684034804691542','test'),('2019-05-31 11:59:59','2019-05-31 19:59:59','QTUMBTC','4h','0.000379000000000','0.000384000000000','0.001480981991486','0.001500520012482','3.907604199171504','3.907604199171504','test'),('2019-05-31 23:59:59','2019-06-03 07:59:59','QTUMBTC','4h','0.000386000000000','0.000395000000000','0.001480981991486','0.001515512659681','3.836740910585492','3.836740910585492','test'),('2019-06-08 03:59:59','2019-06-08 15:59:59','QTUMBTC','4h','0.000398000000000','0.000386000000000','0.001480981991486','0.001436329268125','3.7210602801155774','3.721060280115577','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','QTUMBTC','4h','0.000420000000000','0.000394000000000','0.001480981991486','0.001389302153918','3.5261475987761903','3.526147598776190','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','QTUMBTC','4h','0.000395000000000','0.000396000000000','0.001480981991486','0.001484731312983','3.7493214974329114','3.749321497432911','test'),('2019-06-13 11:59:59','2019-06-14 15:59:59','QTUMBTC','4h','0.000399000000000','0.000399000000000','0.001480981991486','0.001480981991486','3.7117343145012534','3.711734314501253','test'),('2019-06-15 11:59:59','2019-06-15 15:59:59','QTUMBTC','4h','0.000406000000000','0.000397000000000','0.001480981991486','0.001448152341428','3.6477388952857144','3.647738895285714','test'),('2019-06-25 19:59:59','2019-06-26 19:59:59','QTUMBTC','4h','0.000444000000000','0.000385000000000','0.001480981991486','0.001284184834960','3.3355450258693695','3.335545025869370','test'),('2019-06-26 23:59:59','2019-06-27 11:59:59','QTUMBTC','4h','0.000399000000000','0.000397000000000','0.001480981991486','0.001473558522857','3.7117343145012534','3.711734314501253','test'),('2019-06-28 15:59:59','2019-07-03 15:59:59','QTUMBTC','4h','0.000423000000000','0.000447000000000','0.001480981991486','0.001565009338521','3.501139459777778','3.501139459777778','test'),('2019-07-26 11:59:59','2019-07-27 11:59:59','QTUMBTC','4h','0.000317000000000','0.000305000000000','0.001480981991486','0.001424919581714','4.671867481028391','4.671867481028391','test'),('2019-07-27 15:59:59','2019-07-27 19:59:59','QTUMBTC','4h','0.000306000000000','0.000304000000000','0.001480981991486','0.001471302370627','4.83981042969281','4.839810429692810','test'),('2019-08-19 03:59:59','2019-08-19 19:59:59','QTUMBTC','4h','0.000263000000000','0.000242000000000','0.001480981991486','0.001362728676576','5.631110233787072','5.631110233787072','test'),('2019-08-19 23:59:59','2019-08-20 07:59:59','QTUMBTC','4h','0.000247000000000','0.000244000000000','0.001480981991486','0.001462994355962','5.995878508040486','5.995878508040486','test'),('2019-08-21 19:59:59','2019-08-26 03:59:59','QTUMBTC','4h','0.000246000000000','0.000250000000000','0.001480981991486','0.001505062999478','6.020251997910568','6.020251997910568','test'),('2019-09-17 15:59:59','2019-09-22 03:59:59','QTUMBTC','4h','0.000206400000000','0.000212000000000','0.001480981991486','0.001521163673426','7.175300346346899','7.175300346346899','test'),('2019-09-30 19:59:59','2019-10-02 03:59:59','QTUMBTC','4h','0.000205200000000','0.000203400000000','0.001480981991486','0.001467990921385','7.21726116708577','7.217261167085770','test'),('2019-10-02 11:59:59','2019-10-02 15:59:59','QTUMBTC','4h','0.000204800000000','0.000202300000000','0.001480981991486','0.001462903598035','7.231357380302734','7.231357380302734','test'),('2019-10-02 19:59:59','2019-10-09 15:59:59','QTUMBTC','4h','0.000204000000000','0.000215500000000','0.001480981991486','0.001564468721398','7.259715644539216','7.259715644539216','test'),('2019-10-09 19:59:59','2019-10-10 03:59:59','QTUMBTC','4h','0.000219000000000','0.000215000000000','0.001480981991486','0.001453932092098','6.762474846968036','6.762474846968036','test'),('2019-10-14 07:59:59','2019-10-15 11:59:59','QTUMBTC','4h','0.000215900000000','0.000216500000000','0.001480981991486','0.001485097735788','6.859573837359889','6.859573837359889','test'),('2019-10-27 23:59:59','2019-10-30 19:59:59','QTUMBTC','4h','0.000241900000000','0.000236800000000','0.001480981991486','0.001449758311632','6.12229016736668','6.122290167366680','test'),('2019-11-02 19:59:59','2019-11-03 03:59:59','QTUMBTC','4h','0.000236300000000','0.000232000000000','0.001480981991486','0.001454032255712','6.267380412551841','6.267380412551841','test'),('2019-11-04 19:59:59','2019-11-07 15:59:59','QTUMBTC','4h','0.000243500000000','0.000236400000000','0.001480981991486','0.001437799354363','6.082061566677618','6.082061566677618','test'),('2019-11-08 23:59:59','2019-11-10 19:59:59','QTUMBTC','4h','0.000245300000000','0.000240900000000','0.001480981991486','0.001454417292087','6.037431681557277','6.037431681557277','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','QTUMBTC','4h','0.000241700000000','0.000239100000000','0.001480981991486','0.001465050865388','6.127356191501862','6.127356191501862','test'),('2019-11-11 15:59:59','2019-11-12 03:59:59','QTUMBTC','4h','0.000245100000000','0.000243100000000','0.001480981991486','0.001468897275113','6.042358186397389','6.042358186397389','test'),('2019-11-12 07:59:59','2019-11-15 15:59:59','QTUMBTC','4h','0.000243300000000','0.000255000000000','0.001480981991486','0.001552200607599','6.087061206272092','6.087061206272092','test'),('2019-11-29 03:59:59','2019-11-30 11:59:59','QTUMBTC','4h','0.000245000000000','0.000236700000000','0.001480981991486','0.001430809948509','6.044824455044898','6.044824455044898','test'),('2019-12-01 23:59:59','2019-12-02 07:59:59','QTUMBTC','4h','0.000241200000000','0.000238200000000','0.001480981991486','0.001462561817463','6.140058007819237','6.140058007819237','test'),('2019-12-02 11:59:59','2019-12-02 19:59:59','QTUMBTC','4h','0.000240600000000','0.000240100000000','0.001480981991486','0.001477904306549','6.155369873175395','6.155369873175395','test'),('2019-12-03 03:59:59','2019-12-03 07:59:59','QTUMBTC','4h','0.000240100000000','0.000239000000000','0.001480981991486','0.001474196984445','6.168188219433569','6.168188219433569','test'),('2019-12-11 07:59:59','2019-12-15 03:59:59','QTUMBTC','4h','0.000240900000000','0.000243100000000','0.001480981991486','0.001494506941180','6.1477044063345785','6.147704406334578','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:18:25
