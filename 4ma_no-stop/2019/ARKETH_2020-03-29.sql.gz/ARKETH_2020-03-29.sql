-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 23:59:59','2019-01-08 19:59:59','ARKETH','4h','0.002978000000000','0.003006000000000','0.072144500000000','0.072822823035594','24.22582269979852','24.225822699798520','test'),('2019-01-09 03:59:59','2019-01-11 23:59:59','ARKETH','4h','0.003012000000000','0.003093000000000','0.072314080758899','0.074258782133889','24.008658950497512','24.008658950497512','test'),('2019-01-13 19:59:59','2019-01-14 07:59:59','ARKETH','4h','0.003259000000000','0.003113000000000','0.072800256102646','0.069538876111549','22.338219117105243','22.338219117105243','test'),('2019-01-16 15:59:59','2019-01-21 11:59:59','ARKETH','4h','0.003180000000000','0.003363000000000','0.072800256102646','0.076989704802893','22.89316229642956','22.893162296429558','test'),('2019-01-21 19:59:59','2019-01-23 03:59:59','ARKETH','4h','0.003448000000000','0.003395000000000','0.073032273279934','0.071909677431954','21.181053735479555','21.181053735479555','test'),('2019-01-23 15:59:59','2019-01-23 23:59:59','ARKETH','4h','0.003461000000000','0.003386000000000','0.073032273279934','0.071449661174764','21.101494735606472','21.101494735606472','test'),('2019-01-24 19:59:59','2019-01-26 15:59:59','ARKETH','4h','0.003499000000000','0.003447000000000','0.073032273279934','0.071946912259483','20.872327316357246','20.872327316357246','test'),('2019-01-27 07:59:59','2019-01-31 11:59:59','ARKETH','4h','0.003570000000000','0.003561000000000','0.073032273279934','0.072848158305279','20.457219406143977','20.457219406143977','test'),('2019-02-03 11:59:59','2019-02-04 07:59:59','ARKETH','4h','0.003682000000000','0.003617000000000','0.073032273279934','0.071743001752722','19.834946572497014','19.834946572497014','test'),('2019-02-10 11:59:59','2019-02-12 19:59:59','ARKETH','4h','0.004389000000000','0.003925000000000','0.073032273279934','0.065311385879185','16.639843536097974','16.639843536097974','test'),('2019-02-13 07:59:59','2019-02-14 11:59:59','ARKETH','4h','0.004341000000000','0.004038000000000','0.073032273279934','0.067934650887900','16.823836277340245','16.823836277340245','test'),('2019-02-17 15:59:59','2019-02-17 23:59:59','ARKETH','4h','0.006457000000000','0.004659000000000','0.073032273279934','0.052695889919655','11.310558042424345','11.310558042424345','test'),('2019-02-18 07:59:59','2019-02-19 03:59:59','ARKETH','4h','0.004963000000000','0.004216000000000','0.073032273279934','0.062039908149950','14.715348232910335','14.715348232910335','test'),('2019-02-20 07:59:59','2019-02-20 15:59:59','ARKETH','4h','0.004676000000000','0.004419000000000','0.073032273279934','0.069018309585977','15.618535774151841','15.618535774151841','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','ARKETH','4h','0.004383000000000','0.004111000000000','0.073032273279934','0.068500040030529','16.662622240459505','16.662622240459505','test'),('2019-03-01 07:59:59','2019-03-01 15:59:59','ARKETH','4h','0.004283000000000','0.004190000000000','0.073032273279934','0.071446468606800','17.051663151980854','17.051663151980854','test'),('2019-03-01 23:59:59','2019-03-02 03:59:59','ARKETH','4h','0.004232000000000','0.004220000000000','0.073032273279934','0.072825187438876','17.2571534215345','17.257153421534500','test'),('2019-03-02 07:59:59','2019-03-02 15:59:59','ARKETH','4h','0.004256000000000','0.004209000000000','0.073032273279934','0.072225760863544','17.159838646601035','17.159838646601035','test'),('2019-03-02 19:59:59','2019-03-04 07:59:59','ARKETH','4h','0.004265000000000','0.004200000000000','0.073032273279934','0.071919237462069','17.123627967159205','17.123627967159205','test'),('2019-03-10 15:59:59','2019-03-11 07:59:59','ARKETH','4h','0.004448000000000','0.004257000000000','0.073032273279934','0.069896220178210','16.419126187035523','16.419126187035523','test'),('2019-03-11 15:59:59','2019-03-16 03:59:59','ARKETH','4h','0.004691000000000','0.004700000000000','0.073032273279934','0.073172390623681','15.568593749719463','15.568593749719463','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','ARKETH','4h','0.004624000000000','0.004648000000000','0.073032273279934','0.073411333521871','15.794176747390573','15.794176747390573','test'),('2019-03-23 11:59:59','2019-03-23 15:59:59','ARKETH','4h','0.004567000000000','0.004575000000000','0.073032273279934','0.073160203690759','15.991301353171448','15.991301353171448','test'),('2019-03-24 03:59:59','2019-03-24 07:59:59','ARKETH','4h','0.004604000000000','0.004589000000000','0.073032273279934','0.072794331468640','15.862787419620766','15.862787419620766','test'),('2019-03-24 11:59:59','2019-03-24 23:59:59','ARKETH','4h','0.004609000000000','0.004644000000000','0.073032273279934','0.073586868542420','15.845578928169667','15.845578928169667','test'),('2019-03-26 23:59:59','2019-03-29 15:59:59','ARKETH','4h','0.004711000000000','0.004800000000000','0.073032273279934','0.074411995700209','15.502499104210147','15.502499104210147','test'),('2019-03-30 23:59:59','2019-04-02 07:59:59','ARKETH','4h','0.004892000000000','0.004775000000000','0.073032273279934','0.071285589720295','14.92891931315086','14.928919313150860','test'),('2019-05-24 23:59:59','2019-05-26 11:59:59','ARKETH','4h','0.002638000000000','0.002505000000000','0.073032273279934','0.069350206431476','27.684713146297952','27.684713146297952','test'),('2019-05-26 15:59:59','2019-05-26 19:59:59','ARKETH','4h','0.002555000000000','0.002437000000000','0.073032273279934','0.069659354200861','28.58405999214638','28.584059992146379','test'),('2019-06-07 23:59:59','2019-06-11 07:59:59','ARKETH','4h','0.002420000000000','0.002465000000000','0.073032273279934','0.074390311419437','30.17862532228678','30.178625322286781','test'),('2019-06-11 19:59:59','2019-06-12 11:59:59','ARKETH','4h','0.002552000000000','0.002455000000000','0.073032273279934','0.070256360071410','28.617661943547805','28.617661943547805','test'),('2019-07-22 15:59:59','2019-07-27 23:59:59','ARKETH','4h','0.001474000000000','0.001799000000000','0.073032273279934','0.089135047239214','49.54699679778426','49.546996797784260','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','ARKETH','4h','0.001840000000000','0.001803000000000','0.073032273279934','0.071563689523761','39.69145286952935','39.691452869529350','test'),('2019-07-28 15:59:59','2019-07-30 11:59:59','ARKETH','4h','0.001860000000000','0.001755000000000','0.073032273279934','0.068909483659293','39.26466305372796','39.264663053727958','test'),('2019-08-23 11:59:59','2019-08-26 03:59:59','ARKETH','4h','0.001205000000000','0.001190000000000','0.073032273279934','0.072123157844914','60.607695667995024','60.607695667995024','test'),('2019-08-31 07:59:59','2019-08-31 23:59:59','ARKETH','4h','0.001298000000000','0.001231000000000','0.073032273279934','0.069262502625269','56.26523365172112','56.265233651721118','test'),('2019-09-01 07:59:59','2019-09-01 19:59:59','ARKETH','4h','0.001262000000000','0.001219000000000','0.073032273279934','0.070543851924120','57.87026408869572','57.870264088695720','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','ARKETH','4h','0.001235000000000','0.001212000000000','0.073032273279934','0.071672158069053','59.13544395136356','59.135443951363563','test'),('2019-09-04 23:59:59','2019-09-06 07:59:59','ARKETH','4h','0.001260000000000','0.001225000000000','0.073032273279934','0.071003599022158','57.96212165074127','57.962121650741267','test'),('2019-09-06 15:59:59','2019-09-07 03:59:59','ARKETH','4h','0.001259000000000','0.001234000000000','0.073032273279934','0.071582069283112','58.00815987286259','58.008159872862592','test'),('2019-09-07 07:59:59','2019-09-07 11:59:59','ARKETH','4h','0.001253000000000','0.001238000000000','0.048688182186623','0.048105322862761','38.85728825748018','38.857288257480178','test'),('2019-09-07 15:59:59','2019-09-07 19:59:59','ARKETH','4h','0.001249000000000','0.001224000000000','0.054342342556775','0.053254625532020','43.50868099021178','43.508680990211779','test'),('2019-09-07 23:59:59','2019-09-08 03:59:59','ARKETH','4h','0.001266000000000','0.001225000000000','0.054342342556775','0.052582440467654','42.92444119808452','42.924441198084523','test'),('2019-09-09 19:59:59','2019-09-10 07:59:59','ARKETH','4h','0.001309000000000','0.001351000000000','0.054342342556775','0.056085947130789','41.51439461938503','41.514394619385030','test'),('2019-09-10 19:59:59','2019-09-11 03:59:59','ARKETH','4h','0.001289000000000','0.001246000000000','0.054342342556775','0.052529525853950','42.158527972672616','42.158527972672616','test'),('2019-09-12 19:59:59','2019-09-13 03:59:59','ARKETH','4h','0.001323000000000','0.001258000000000','0.054342342556775','0.051672461781121','41.07508885621694','41.075088856216937','test'),('2019-09-13 07:59:59','2019-09-14 15:59:59','ARKETH','4h','0.001260000000000','0.001239000000000','0.054342342556775','0.053436636847495','43.12884329902778','43.128843299027778','test'),('2019-10-05 03:59:59','2019-10-05 07:59:59','ARKETH','4h','0.001029000000000','0.001025000000000','0.054342342556775','0.054131099242657','52.81082852942178','52.810828529421777','test'),('2019-10-05 11:59:59','2019-10-06 07:59:59','ARKETH','4h','0.001029000000000','0.001019000000000','0.054342342556775','0.053814234271481','52.81082852942178','52.810828529421777','test'),('2019-10-06 11:59:59','2019-10-06 15:59:59','ARKETH','4h','0.001025000000000','0.001045000000000','0.054342342556775','0.055402680948127','53.01691956758536','53.016919567585362','test'),('2019-10-06 23:59:59','2019-10-07 11:59:59','ARKETH','4h','0.001053000000000','0.001032000000000','0.054342342556775','0.053258592135415','51.60716292191359','51.607162921913591','test'),('2019-10-07 15:59:59','2019-10-07 19:59:59','ARKETH','4h','0.001040000000000','0.001043000000000','0.054342342556775','0.054499099314150','52.25225245843751','52.252252458437511','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','ARKETH','4h','0.001065000000000','0.000967000000000','0.054342342556775','0.049341826528076','51.02567376223005','51.025673762230049','test'),('2019-10-12 11:59:59','2019-10-15 11:59:59','ARKETH','4h','0.001124000000000','0.001120000000000','0.054342342556775','0.054148953437356','48.34727985478203','48.347279854782030','test'),('2019-10-17 11:59:59','2019-10-19 23:59:59','ARKETH','4h','0.001160000000000','0.001122000000000','0.054342342556775','0.052562162369570','46.84684703170259','46.846847031702588','test'),('2019-10-25 11:59:59','2019-10-25 19:59:59','ARKETH','4h','0.001159000000000','0.001107000000000','0.054342342556775','0.051904204668119','46.88726708953839','46.887267089538391','test'),('2019-10-28 15:59:59','2019-10-29 23:59:59','ARKETH','4h','0.001232000000000','0.001076000000000','0.054342342556775','0.047461331648612','44.109044283096594','44.109044283096594','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','ARKETH','4h','0.001134000000000','0.001100000000000','0.054342342556775','0.052713030698812','47.92093699891976','47.920936998919757','test'),('2019-11-02 19:59:59','2019-11-04 19:59:59','ARKETH','4h','0.001101000000000','0.001128000000000','0.054342342556775','0.055674988559530','49.3572593612852','49.357259361285202','test'),('2019-11-06 03:59:59','2019-11-07 03:59:59','ARKETH','4h','0.001177000000000','0.001136000000000','0.054342342556775','0.052449363759130','46.17021457669924','46.170214576699237','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','ARKETH','4h','0.001150000000000','0.001131000000000','0.054342342556775','0.053444512549315','47.25421091893479','47.254210918934788','test'),('2019-11-07 19:59:59','2019-11-08 03:59:59','ARKETH','4h','0.001170000000000','0.001153000000000','0.054342342556775','0.053552752964070','46.446446629722224','46.446446629722224','test'),('2019-11-09 07:59:59','2019-11-10 07:59:59','ARKETH','4h','0.001181000000000','0.001156000000000','0.054342342556775','0.053191996609341','46.01383789735394','46.013837897353937','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','ARKETH','4h','0.001177000000000','0.001158000000000','0.054342342556775','0.053465108479818','46.17021457669924','46.170214576699237','test'),('2019-11-12 19:59:59','2019-11-13 01:59:59','ARKETH','4h','0.001169000000000','0.001161000000000','0.054342342556775','0.053970453129526','46.48617840613773','46.486178406137732','test'),('2019-11-13 07:59:59','2019-11-13 11:59:59','ARKETH','4h','0.001167000000000','0.001165000000000','0.054342342556775','0.054249210864304','46.56584623545415','46.565846235454153','test'),('2019-11-13 15:59:59','2019-11-14 11:59:59','ARKETH','4h','0.001199000000000','0.001140000000000','0.054342342556775','0.051668282330879','45.323054676209345','45.323054676209345','test'),('2019-11-27 07:59:59','2019-11-30 15:59:59','ARKETH','4h','0.001137000000000','0.001162000000000','0.054342342556775','0.055537204970073','47.79449653190414','47.794496531904137','test'),('2019-11-30 19:59:59','2019-12-05 07:59:59','ARKETH','4h','0.001229000000000','0.001226000000000','0.054342342556775','0.054209692412210','44.21671485498373','44.216714854983728','test'),('2019-12-06 23:59:59','2019-12-09 23:59:59','ARKETH','4h','0.001259000000000','0.001249000000000','0.054342342556775','0.053910711559501','43.16309972738285','43.163099727382850','test'),('2019-12-20 11:59:59','2019-12-21 15:59:59','ARKETH','4h','0.001230000000000','0.001196000000000','0.054342342556775','0.052840196502360','44.18076630632114','44.180766306321139','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  4:49:39
