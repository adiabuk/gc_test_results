-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 11:59:59','2019-01-13 19:59:59','ASTETH','4h','0.000201900000000','0.000204000000000','0.072144500000000','0.072894888558692','357.3278850916295','357.327885091629526','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','ASTETH','4h','0.000201400000000','0.000194800000000','0.072332097139673','0.069961730500538','359.14646047503976','359.146460475039760','test'),('2019-01-15 23:59:59','2019-01-20 19:59:59','ASTETH','4h','0.000213200000000','0.000232000000000','0.072332097139673','0.078710349607899','339.26874830991085','339.268748309910848','test'),('2019-01-21 07:59:59','2019-01-27 07:59:59','ASTETH','4h','0.000255100000000','0.000253100000000','0.073334068596946','0.072759124899596','287.47184867481667','287.471848674816670','test'),('2019-02-07 23:59:59','2019-02-08 15:59:59','ASTETH','4h','0.000262500000000','0.000236400000000','0.073334068596946','0.066042566919307','279.3678803693181','279.367880369318073','test'),('2019-02-22 15:59:59','2019-02-23 03:59:59','ASTETH','4h','0.000237300000000','0.000221200000000','0.073334068596946','0.068358600816032','309.03526589526336','309.035265895263365','test'),('2019-02-23 07:59:59','2019-02-23 15:59:59','ASTETH','4h','0.000223900000000','0.000219600000000','0.073334068596946','0.071925687645776','327.53045376036624','327.530453760366242','test'),('2019-02-23 19:59:59','2019-02-23 23:59:59','ASTETH','4h','0.000219800000000','0.000220100000000','0.073334068596946','0.073434160592301','333.6399845174977','333.639984517497680','test'),('2019-02-24 03:59:59','2019-02-24 15:59:59','ASTETH','4h','0.000223400000000','0.000218100000000','0.073334068596946','0.071594271982963','328.2635120722739','328.263512072273898','test'),('2019-02-25 11:59:59','2019-02-25 15:59:59','ASTETH','4h','0.000226000000000','0.000224200000000','0.073334068596946','0.072749991944404','324.48702919002653','324.487029190026533','test'),('2019-02-25 19:59:59','2019-02-27 11:59:59','ASTETH','4h','0.000228400000000','0.000242500000000','0.073334068596946','0.077861259346582','321.0773581302364','321.077358130236405','test'),('2019-02-27 19:59:59','2019-03-04 11:59:59','ASTETH','4h','0.000237100000000','0.000277900000000','0.073334068596946','0.085953343159390','309.2959451579334','309.295945157933375','test'),('2019-03-08 19:59:59','2019-03-11 07:59:59','ASTETH','4h','0.000275600000000','0.000274100000000','0.073502166080405','0.073102118006673','266.69871582149864','266.698715821498638','test'),('2019-03-12 15:59:59','2019-03-16 07:59:59','ASTETH','4h','0.000289300000000','0.000287600000000','0.073502166080405','0.073070248754665','254.069015141393','254.069015141393010','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','ASTETH','4h','0.000289800000000','0.000286800000000','0.073502166080405','0.072741274091995','253.63066280332987','253.630662803329869','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','ASTETH','4h','0.000290000000000','0.000289800000000','0.073502166080405','0.073451474931384','253.45574510484482','253.455745104844823','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','ASTETH','4h','0.000290800000000','0.000289300000000','0.073502166080405','0.073123028359908','252.75848033151647','252.758480331516466','test'),('2019-03-23 07:59:59','2019-03-24 11:59:59','ASTETH','4h','0.000292100000000','0.000291100000000','0.073502166080405','0.073250532509435','251.6335709702328','251.633570970232796','test'),('2019-03-24 15:59:59','2019-03-25 07:59:59','ASTETH','4h','0.000294100000000','0.000290800000000','0.073502166080405','0.072677422292356','249.9223600149779','249.922360014977897','test'),('2019-03-25 19:59:59','2019-03-25 23:59:59','ASTETH','4h','0.000302300000000','0.000295700000000','0.073502166080405','0.071897421468659','243.14312299174662','243.143122991746623','test'),('2019-03-26 03:59:59','2019-03-26 15:59:59','ASTETH','4h','0.000301200000000','0.000302300000000','0.073502166080405','0.073770600285878','244.03109588447873','244.031095884478731','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','ASTETH','4h','0.000311300000000','0.000311400000000','0.073502166080405','0.073525777441176','236.11360771090588','236.113607710905882','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','ASTETH','4h','0.000344000000000','0.000317100000000','0.073502166080405','0.067754467628187','213.66908744303777','213.669087443037768','test'),('2019-04-20 03:59:59','2019-04-21 11:59:59','ASTETH','4h','0.000278500000000','0.000269900000000','0.073502166080405','0.071232440305570','263.9216017249731','263.921601724973073','test'),('2019-04-21 15:59:59','2019-04-23 23:59:59','ASTETH','4h','0.000285700000000','0.000282500000000','0.073502166080405','0.072678900657033','257.27044480365765','257.270444803657654','test'),('2019-05-22 15:59:59','2019-05-25 03:59:59','ASTETH','4h','0.000191100000000','0.000218900000000','0.073502166080405','0.084194788880171','384.62671941603867','384.626719416038668','test'),('2019-05-28 19:59:59','2019-05-29 07:59:59','ASTETH','4h','0.000225100000000','0.000205200000000','0.073502166080405','0.067004195822741','326.5311687268103','326.531168726810279','test'),('2019-05-29 15:59:59','2019-05-29 19:59:59','ASTETH','4h','0.000204700000000','0.000201300000000','0.073502166080405','0.072281319159675','359.0726237440401','359.072623744040072','test'),('2019-06-08 15:59:59','2019-06-09 15:59:59','ASTETH','4h','0.000210000000000','0.000196500000000','0.073502166080405','0.068777026832379','350.0103146685952','350.010314668595186','test'),('2019-06-11 15:59:59','2019-06-12 15:59:59','ASTETH','4h','0.000198800000000','0.000197700000000','0.073502166080405','0.073095463954206','369.72920563584','369.729205635840003','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','ASTETH','4h','0.000211300000000','0.000193800000000','0.073502166080405','0.067414670072799','347.85691472032653','347.856914720326529','test'),('2019-06-19 19:59:59','2019-06-19 23:59:59','ASTETH','4h','0.000284400000000','0.000220800000000','0.073502166080405','0.057064972821918','258.44643488187415','258.446434881874154','test'),('2019-06-20 03:59:59','2019-06-21 03:59:59','ASTETH','4h','0.000229900000000','0.000213100000000','0.073502166080405','0.068130976910545','319.7136410630926','319.713641063092609','test'),('2019-06-21 07:59:59','2019-06-21 23:59:59','ASTETH','4h','0.000240600000000','0.000201700000000','0.073502166080405','0.061618399411545','305.49528711722775','305.495287117227747','test'),('2019-06-22 07:59:59','2019-06-23 07:59:59','ASTETH','4h','0.000216000000000','0.000211200000000','0.073502166080405','0.071868784611952','340.28780592780095','340.287805927800946','test'),('2019-06-23 11:59:59','2019-06-23 19:59:59','ASTETH','4h','0.000218300000000','0.000208500000000','0.073502166080405','0.070202481116649','336.7025473220568','336.702547322056773','test'),('2019-07-02 07:59:59','2019-07-04 11:59:59','ASTETH','4h','0.000201900000000','0.000213700000000','0.073502166080405','0.077797983612593','364.05233323628033','364.052333236280333','test'),('2019-07-04 15:59:59','2019-07-04 23:59:59','ASTETH','4h','0.000218500000000','0.000217000000000','0.073502166080405','0.072997574551249','336.39435277073227','336.394352770732269','test'),('2019-07-15 11:59:59','2019-07-15 19:59:59','ASTETH','4h','0.000204300000000','0.000191800000000','0.073502166080405','0.069004970407350','359.775653844371','359.775653844370993','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','ASTETH','4h','0.000192300000000','0.000191500000000','0.073502166080405','0.073196384838261','382.22655268021316','382.226552680213160','test'),('2019-07-16 07:59:59','2019-07-17 07:59:59','ASTETH','4h','0.000194000000000','0.000193400000000','0.073502166080405','0.073274839793558','378.87714474435563','378.877144744355633','test'),('2019-07-17 11:59:59','2019-07-17 15:59:59','ASTETH','4h','0.000201800000000','0.000193900000000','0.073502166080405','0.070624727467743','364.23273578000493','364.232735780004930','test'),('2019-07-17 19:59:59','2019-07-18 03:59:59','ASTETH','4h','0.000196300000000','0.000192900000000','0.073502166080405','0.072229077111106','374.4379321467397','374.437932146739684','test'),('2019-07-22 15:59:59','2019-07-24 23:59:59','ASTETH','4h','0.000201800000000','0.000202500000000','0.073502166080405','0.073757128995451','364.23273578000493','364.232735780004930','test'),('2019-07-28 03:59:59','2019-07-28 15:59:59','ASTETH','4h','0.000204200000000','0.000198500000000','0.073502166080405','0.071450440582568','359.95184172578354','359.951841725783538','test'),('2019-07-28 19:59:59','2019-07-28 23:59:59','ASTETH','4h','0.000200800000000','0.000199300000000','0.073502166080405','0.072953096114665','366.0466438267181','366.046643826718082','test'),('2019-07-29 03:59:59','2019-07-29 11:59:59','ASTETH','4h','0.000205600000000','0.000202900000000','0.073502166080405','0.072536913899388','357.50080778407096','357.500807784070957','test'),('2019-08-21 15:59:59','2019-08-23 15:59:59','ASTETH','4h','0.000148900000000','0.000148900000000','0.073502166080405','0.073502166080405','493.6344263291135','493.634426329113523','test'),('2019-08-23 19:59:59','2019-08-26 03:59:59','ASTETH','4h','0.000150300000000','0.000154300000000','0.073502166080405','0.075458311551607','489.03636780043246','489.036367800432458','test'),('2019-08-26 07:59:59','2019-08-28 07:59:59','ASTETH','4h','0.000162800000000','0.000158200000000','0.073502166080405','0.071425323549878','451.4875066363943','451.487506636394301','test'),('2019-09-10 23:59:59','2019-09-11 19:59:59','ASTETH','4h','0.000157200000000','0.000137800000000','0.073502166080405','0.064431288078116','467.5710310458333','467.571031045833308','test'),('2019-09-16 07:59:59','2019-09-16 11:59:59','ASTETH','4h','0.000144300000000','0.000129300000000','0.049001444053603','0.043907738850526','339.58034687181794','339.580346871817937','test'),('2019-09-19 11:59:59','2019-09-19 15:59:59','ASTETH','4h','0.000145200000000','0.000131600000000','0.052724873736046','0.047786455810356','363.11896512428586','363.118965124285864','test'),('2019-09-22 19:59:59','2019-09-23 23:59:59','ASTETH','4h','0.000148000000000','0.000141400000000','0.052724873736046','0.050373629366736','356.2491468651757','356.249146865175703','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','ASTETH','4h','0.000143400000000','0.000137200000000','0.052724873736046','0.050445276684697','367.67694376601116','367.676943766011163','test'),('2019-09-28 15:59:59','2019-09-29 15:59:59','ASTETH','4h','0.000143000000000','0.000135300000000','0.052724873736046','0.049885842073336','368.7054107415804','368.705410741580408','test'),('2019-09-29 19:59:59','2019-09-29 23:59:59','ASTETH','4h','0.000136400000000','0.000136300000000','0.052724873736046','0.052686219136533','386.54599513230204','386.545995132302039','test'),('2019-09-30 19:59:59','2019-10-01 03:59:59','ASTETH','4h','0.000141900000000','0.000140500000000','0.052724873736046','0.052204684706938','371.5635922201973','371.563592220197279','test'),('2019-10-01 11:59:59','2019-10-01 15:59:59','ASTETH','4h','0.000139400000000','0.000136400000000','0.052724873736046','0.051590192091798','378.22721474925396','378.227214749253960','test'),('2019-10-02 07:59:59','2019-10-04 07:59:59','ASTETH','4h','0.000141500000000','0.000146700000000','0.052724873736046','0.054662466269102','372.61394866463604','372.613948664636041','test'),('2019-10-04 11:59:59','2019-10-08 07:59:59','ASTETH','4h','0.000152500000000','0.000150000000000','0.052724873736046','0.051860531543652','345.7368769576787','345.736876957678703','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','ASTETH','4h','0.000161200000000','0.000146300000000','0.052724873736046','0.047851420766647','327.0773804965633','327.077380496563308','test'),('2019-10-15 23:59:59','2019-10-16 15:59:59','ASTETH','4h','0.000157000000000','0.000145200000000','0.052724873736046','0.048762112525311','335.82722124870065','335.827221248700653','test'),('2019-10-17 11:59:59','2019-10-17 15:59:59','ASTETH','4h','0.000153800000000','0.000151800000000','0.052724873736046','0.052039244688763','342.8145236413914','342.814523641391418','test'),('2019-10-20 23:59:59','2019-10-21 03:59:59','ASTETH','4h','0.000151000000000','0.000150700000000','0.052724873736046','0.052620122331272','349.17134924533775','349.171349245337751','test'),('2019-10-21 07:59:59','2019-10-21 11:59:59','ASTETH','4h','0.000152100000000','0.000149000000000','0.052724873736046','0.051650270786791','346.6461126630243','346.646112663024326','test'),('2019-10-21 15:59:59','2019-10-23 03:59:59','ASTETH','4h','0.000151400000000','0.000153400000000','0.052724873736046','0.053421371407592','348.2488357730912','348.248835773091173','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','ASTETH','4h','0.000157000000000','0.000150100000000','0.052724873736046','0.050407665909430','335.82722124870065','335.827221248700653','test'),('2019-11-19 11:59:59','2019-11-21 07:59:59','ASTETH','4h','0.000134400000000','0.000132000000000','0.052724873736046','0.051783358133617','392.2981676789137','392.298167678913728','test'),('2019-11-24 07:59:59','2019-11-24 15:59:59','ASTETH','4h','0.000137700000000','0.000131800000000','0.052724873736046','0.050465783285482','382.8966865362817','382.896686536281720','test'),('2019-11-24 19:59:59','2019-11-25 03:59:59','ASTETH','4h','0.000134800000000','0.000131000000000','0.052724873736046','0.051238564239036','391.13407816057867','391.134078160578667','test'),('2019-11-25 07:59:59','2019-12-02 23:59:59','ASTETH','4h','0.000141800000000','0.000148300000000','0.052724873736046','0.055141740303636','371.82562578311706','371.825625783117061','test'),('2019-12-04 23:59:59','2019-12-09 15:59:59','ASTETH','4h','0.000155800000000','0.000160700000000','0.052724873736046','0.054383101472289','338.4138237230167','338.413823723016719','test'),('2019-12-10 03:59:59','2019-12-10 07:59:59','ASTETH','4h','0.000163400000000','0.000157800000000','0.052724873736046','0.050917901319144','322.67364587543454','322.673645875434545','test'),('2019-12-20 19:59:59','2019-12-22 15:59:59','ASTETH','4h','0.000151700000000','0.000147800000000','0.052724873736046','0.051369389177242','347.5601432830982','347.560143283098228','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:40:11
