-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 15:59:59','2019-01-10 19:59:59','POAETH','4h','0.000205790000000','0.000199510000000','0.072144500000000','0.069942899047573','350.57340006803054','350.573400068030537','test'),('2019-01-10 23:59:59','2019-01-11 03:59:59','POAETH','4h','0.000199910000000','0.000198780000000','0.072144500000000','0.071736700065029','360.88489820419187','360.884898204191870','test'),('2019-01-11 07:59:59','2019-01-14 19:59:59','POAETH','4h','0.000201320000000','0.000202630000000','0.072144500000000','0.072613948117425','358.35734154579774','358.357341545797738','test'),('2019-01-15 23:59:59','2019-01-24 11:59:59','POAETH','4h','0.000216060000000','0.000248130000000','0.072144500000000','0.082852979658428','333.90956215865964','333.909562158659639','test'),('2019-01-26 07:59:59','2019-01-28 03:59:59','POAETH','4h','0.000253500000000','0.000253200000000','0.074286631722114','0.074198718548478','293.0439121187919','293.043912118791923','test'),('2019-01-30 11:59:59','2019-01-31 11:59:59','POAETH','4h','0.000269010000000','0.000248500000000','0.074286631722114','0.068622831801589','276.1482165053864','276.148216505386415','test'),('2019-02-04 11:59:59','2019-02-04 15:59:59','POAETH','4h','0.000254900000000','0.000250000000000','0.074286631722114','0.072858603101328','291.4344124053119','291.434412405311889','test'),('2019-02-27 11:59:59','2019-02-28 03:59:59','POAETH','4h','0.000204670000000','0.000200010000000','0.074286631722114','0.072595247035423','362.95808727275124','362.958087272751243','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','POAETH','4h','0.000201250000000','0.000201340000000','0.074286631722114','0.074319853072946','369.1261203583304','369.126120358330411','test'),('2019-02-28 23:59:59','2019-03-05 23:59:59','POAETH','4h','0.000203560000000','0.000210580000000','0.074286631722114','0.076848491393411','364.9372751135488','364.937275113548822','test'),('2019-03-07 03:59:59','2019-03-11 15:59:59','POAETH','4h','0.000225190000000','0.000228250000000','0.074286631722114','0.075296077492662','329.8842387411253','329.884238741125273','test'),('2019-03-11 19:59:59','2019-03-16 07:59:59','POAETH','4h','0.000230090000000','0.000237990000000','0.074286631722114','0.076837217973601','322.85901917560085','322.859019175600849','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','POAETH','4h','0.000238980000000','0.000232620000000','0.074286631722114','0.072309633740054','310.8487393175747','310.848739317574712','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','POAETH','4h','0.000235300000000','0.000234770000000','0.074286631722114','0.074119305267321','315.71029206168294','315.710292061682935','test'),('2019-03-22 03:59:59','2019-03-22 07:59:59','POAETH','4h','0.000235300000000','0.000231000000000','0.074286631722114','0.072929077466249','315.71029206168294','315.710292061682935','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','POAETH','4h','0.000234910000000','0.000240500000000','0.074286631722114','0.076054382227953','316.2344375382657','316.234437538265695','test'),('2019-03-23 07:59:59','2019-03-23 15:59:59','POAETH','4h','0.000241660000000','0.000239790000000','0.074286631722114','0.073711791031390','307.40143888982044','307.401438889820440','test'),('2019-03-23 19:59:59','2019-03-30 19:59:59','POAETH','4h','0.000242730000000','0.000267000000000','0.074286631722114','0.081714376755261','306.046354888617','306.046354888616975','test'),('2019-03-31 03:59:59','2019-04-02 03:59:59','POAETH','4h','0.000274240000000','0.000272410000000','0.074887322421631','0.074387600280326','273.07220836359124','273.072208363591244','test'),('2019-04-14 07:59:59','2019-04-16 15:59:59','POAETH','4h','0.000250990000000','0.000246180000000','0.074887322421631','0.073452173527858','298.36775338312685','298.367753383126853','test'),('2019-04-17 11:59:59','2019-04-18 03:59:59','POAETH','4h','0.000260000000000','0.000247160000000','0.074887322421631','0.071189040806655','288.0281631601193','288.028163160119277','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','POAETH','4h','0.000144130000000','0.000131460000000','0.074887322421631','0.068304221227695','519.5817832625478','519.581783262547788','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','POAETH','4h','0.000133240000000','0.000130560000000','0.074887322421631','0.073381032838248','562.0483520086386','562.048352008638631','test'),('2019-05-26 07:59:59','2019-05-26 19:59:59','POAETH','4h','0.000138000000000','0.000127760000000','0.074887322421631','0.069330466033243','542.6617566784855','542.661756678485517','test'),('2019-05-26 23:59:59','2019-05-29 11:59:59','POAETH','4h','0.000154040000000','0.000159640000000','0.074887322421631','0.077609790647813','486.15504038971045','486.155040389710450','test'),('2019-06-11 03:59:59','2019-06-11 07:59:59','POAETH','4h','0.000141720000000','0.000141260000000','0.074887322421631','0.074644250390062','528.4174599324796','528.417459932479574','test'),('2019-06-11 19:59:59','2019-06-12 03:59:59','POAETH','4h','0.000141590000000','0.000138000000000','0.074887322421631','0.072988562004273','528.9026232193728','528.902623219372799','test'),('2019-06-12 19:59:59','2019-06-13 19:59:59','POAETH','4h','0.000157260000000','0.000140000000000','0.074887322421631','0.066668098302355','476.20070215967826','476.200702159678258','test'),('2019-06-13 23:59:59','2019-06-14 03:59:59','POAETH','4h','0.000140780000000','0.000141230000000','0.074887322421631','0.075126698008289','531.9457481292159','531.945748129215872','test'),('2019-07-23 03:59:59','2019-07-24 23:59:59','POAETH','4h','0.000101370000000','0.000096470000000','0.074887322421631','0.071267436066043','738.752317467012','738.752317467011949','test'),('2019-07-25 07:59:59','2019-07-25 11:59:59','POAETH','4h','0.000097630000000','0.000097280000000','0.074887322421631','0.074618854093785','767.0523652732869','767.052365273286910','test'),('2019-07-25 15:59:59','2019-07-25 19:59:59','POAETH','4h','0.000098780000000','0.000095520000000','0.074887322421631','0.072415843669915','758.1223164773335','758.122316477333470','test'),('2019-07-29 11:59:59','2019-07-30 15:59:59','POAETH','4h','0.000097630000000','0.000097150000000','0.074887322421631','0.074519137286300','767.0523652732869','767.052365273286910','test'),('2019-07-31 03:59:59','2019-07-31 07:59:59','POAETH','4h','0.000096700000000','0.000095810000000','0.074887322421631','0.074198080260770','774.42939422576','774.429394225760007','test'),('2019-08-21 23:59:59','2019-08-22 07:59:59','POAETH','4h','0.000075080000000','0.000073540000000','0.074887322421631','0.073351274519003','997.4337030052077','997.433703005207690','test'),('2019-08-22 11:59:59','2019-08-22 19:59:59','POAETH','4h','0.000073890000000','0.000075660000000','0.074887322421631','0.076681212808507','1013.4973937154012','1013.497393715401245','test'),('2019-08-22 23:59:59','2019-08-28 07:59:59','POAETH','4h','0.000076030000000','0.000081000000000','0.074887322421631','0.079782626807209','984.9707013235696','984.970701323569642','test'),('2019-08-29 19:59:59','2019-08-31 15:59:59','POAETH','4h','0.000091860000000','0.000082550000000','0.074887322421631','0.067297501261764','815.2332072896908','815.233207289690768','test'),('2019-09-10 23:59:59','2019-09-12 03:59:59','POAETH','4h','0.000082170000000','0.000075670000000','0.074887322421631','0.068963413504257','911.3706026728855','911.370602672885525','test'),('2019-09-13 19:59:59','2019-09-14 23:59:59','POAETH','4h','0.000082170000000','0.000078470000000','0.074887322421631','0.071515251191741','911.3706026728855','911.370602672885525','test'),('2019-09-15 03:59:59','2019-09-15 15:59:59','POAETH','4h','0.000080020000000','0.000077740000000','0.074887322421631','0.072753567171427','935.8575658789179','935.857565878917853','test'),('2019-09-16 23:59:59','2019-09-19 03:59:59','POAETH','4h','0.000084910000000','0.000081760000000','0.074887322421631','0.072109144755536','881.9611638397245','881.961163839724463','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','POAETH','4h','0.000081890000000','0.000080640000000','0.074887322421631','0.073744213946518','914.4867800907437','914.486780090743650','test'),('2019-09-26 23:59:59','2019-10-06 07:59:59','POAETH','4h','0.000087730000000','0.000101190000000','0.074887322421631','0.086376930991050','853.6113350237205','853.611335023720471','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','POAETH','4h','0.000106580000000','0.000096700000000','0.074887322421631','0.067945243743401','702.6395423309345','702.639542330934546','test'),('2019-10-15 07:59:59','2019-10-15 23:59:59','POAETH','4h','0.000101370000000','0.000098990000000','0.074887322421631','0.073129091906060','738.752317467012','738.752317467011949','test'),('2019-10-17 11:59:59','2019-10-18 07:59:59','POAETH','4h','0.000101010000000','0.000094780000000','0.074887322421631','0.070268492417802','741.3852333593803','741.385233359380322','test'),('2019-10-19 15:59:59','2019-10-21 07:59:59','POAETH','4h','0.000100220000000','0.000101120000000','0.074887322421631','0.075559828809373','747.2293197129416','747.229319712941560','test'),('2019-10-21 11:59:59','2019-10-24 03:59:59','POAETH','4h','0.000104730000000','0.000103450000000','0.074887322421631','0.073972056760410','715.0512978289984','715.051297828998372','test'),('2019-11-18 11:59:59','2019-11-18 19:59:59','POAETH','4h','0.000091210000000','0.000087710000000','0.074887322421631','0.072013672290333','821.0428946566276','821.042894656627595','test'),('2019-11-18 23:59:59','2019-11-19 07:59:59','POAETH','4h','0.000088650000000','0.000089410000000','0.074887322421631','0.075529334435624','844.7526499901974','844.752649990197369','test'),('2019-11-19 15:59:59','2019-11-19 19:59:59','POAETH','4h','0.000088580000000','0.000090080000000','0.074887322421631','0.076155452740354','845.4202124817227','845.420212481722729','test'),('2019-11-20 03:59:59','2019-11-20 11:59:59','POAETH','4h','0.000090500000000','0.000088640000000','0.074887322421631','0.073348201761916','827.4842256533811','827.484225653381145','test'),('2019-11-20 15:59:59','2019-11-21 11:59:59','POAETH','4h','0.000092740000000','0.000084050000000','0.074887322421631','0.067870168746367','807.4975460602868','807.497546060286822','test'),('2019-11-25 07:59:59','2019-11-27 19:59:59','POAETH','4h','0.000095190000000','0.000093250000000','0.074887322421631','0.073361096920024','786.714176086049','786.714176086048951','test'),('2019-11-27 23:59:59','2019-12-01 15:59:59','POAETH','4h','0.000095040000000','0.000097000000000','0.074887322421631','0.076431715855410','787.9558335609322','787.955833560932206','test'),('2019-12-04 19:59:59','2019-12-04 23:59:59','POAETH','4h','0.000101150000000','0.000096430000000','0.074887322421631','0.071392827494986','740.359094628087','740.359094628086950','test'),('2019-12-05 03:59:59','2019-12-05 07:59:59','POAETH','4h','0.000096830000000','0.000096840000000','0.074887322421631','0.074895056318401','773.3896769764639','773.389676976463875','test'),('2019-12-06 19:59:59','2019-12-10 03:59:59','POAETH','4h','0.000099910000000','0.000093560000000','0.074887322421631','0.070127693782082','749.5478172518367','749.547817251836705','test'),('2019-12-19 03:59:59','2019-12-19 11:59:59','POAETH','4h','0.000101300000000','0.000096840000000','0.074887322421631','0.071590210299218','739.262807716002','739.262807716002044','test'),('2019-12-19 23:59:59','2019-12-21 19:59:59','POAETH','4h','0.000098880000000','0.000096250000000','0.049924881614421','0.048596984783455','504.90373800991773','504.903738009917731','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:12:25
