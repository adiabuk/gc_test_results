-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-05 19:59:59','2019-01-05 23:59:59','WTCBTC','4h','0.000297500000000','0.000295700000000','0.001467500000000','0.001458621008403','4.932773109243698','4.932773109243698','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','WTCBTC','4h','0.000298400000000','0.000299300000000','0.001467500000000','0.001471926105898','4.917895442359249','4.917895442359249','test'),('2019-01-06 15:59:59','2019-01-08 03:59:59','WTCBTC','4h','0.000306700000000','0.000300700000000','0.001467500000000','0.001438791164004','4.784805999347897','4.784805999347897','test'),('2019-01-08 11:59:59','2019-01-10 07:59:59','WTCBTC','4h','0.000308000000000','0.000305900000000','0.001467500000000','0.001457494318182','4.7646103896103895','4.764610389610390','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','WTCBTC','4h','0.000306700000000','0.000302600000000','0.001467500000000','0.001447882295403','4.784805999347897','4.784805999347897','test'),('2019-01-14 15:59:59','2019-01-18 15:59:59','WTCBTC','4h','0.000303500000000','0.000313200000000','0.001467500000000','0.001514401976936','4.835255354200989','4.835255354200989','test'),('2019-01-19 23:59:59','2019-01-20 11:59:59','WTCBTC','4h','0.000331000000000','0.000313500000000','0.001467500000000','0.001389913141994','4.433534743202417','4.433534743202417','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','WTCBTC','4h','0.000280100000000','0.000276800000000','0.001467500000000','0.001450210639057','5.239200285612282','5.239200285612282','test'),('2019-02-12 23:59:59','2019-02-13 03:59:59','WTCBTC','4h','0.000279100000000','0.000278800000000','0.001467500000000','0.001465922608384','5.257972053027589','5.257972053027589','test'),('2019-02-13 07:59:59','2019-02-13 11:59:59','WTCBTC','4h','0.000279700000000','0.000277900000000','0.001467500000000','0.001458055952807','5.24669288523418','5.246692885234180','test'),('2019-02-13 15:59:59','2019-02-13 19:59:59','WTCBTC','4h','0.000278300000000','0.000278500000000','0.001467500000000','0.001468554617319','5.27308659719727','5.273086597197270','test'),('2019-02-14 03:59:59','2019-02-14 07:59:59','WTCBTC','4h','0.000278900000000','0.000277700000000','0.001467500000000','0.001461185908928','5.261742560057368','5.261742560057368','test'),('2019-02-18 07:59:59','2019-02-19 11:59:59','WTCBTC','4h','0.000292500000000','0.000284000000000','0.001467500000000','0.001424854700855','5.017094017094017','5.017094017094017','test'),('2019-02-20 03:59:59','2019-02-20 07:59:59','WTCBTC','4h','0.000288000000000','0.000281300000000','0.001467500000000','0.001433360243056','5.095486111111112','5.095486111111112','test'),('2019-02-27 19:59:59','2019-02-27 23:59:59','WTCBTC','4h','0.000277700000000','0.000276200000000','0.001467500000000','0.001459573280519','5.2844796543032055','5.284479654303206','test'),('2019-02-28 03:59:59','2019-03-04 07:59:59','WTCBTC','4h','0.000279100000000','0.000287900000000','0.001467500000000','0.001513770154067','5.257972053027589','5.257972053027589','test'),('2019-03-07 03:59:59','2019-03-07 07:59:59','WTCBTC','4h','0.000292100000000','0.000287300000000','0.001467500000000','0.001443384970900','5.023964395754879','5.023964395754879','test'),('2019-03-07 11:59:59','2019-03-08 03:59:59','WTCBTC','4h','0.000290300000000','0.000288300000000','0.001467500000000','0.001457389769204','5.055115397864278','5.055115397864278','test'),('2019-03-08 07:59:59','2019-03-08 23:59:59','WTCBTC','4h','0.000291500000000','0.000284400000000','0.001467500000000','0.001431756432247','5.034305317324185','5.034305317324185','test'),('2019-03-09 11:59:59','2019-03-09 15:59:59','WTCBTC','4h','0.000296000000000','0.000292500000000','0.001467500000000','0.001450147804054','4.957770270270271','4.957770270270271','test'),('2019-03-09 19:59:59','2019-03-12 01:59:59','WTCBTC','4h','0.000293400000000','0.000301500000000','0.001467500000000','0.001508013803681','5.001704158145876','5.001704158145876','test'),('2019-03-12 11:59:59','2019-03-17 19:59:59','WTCBTC','4h','0.000311400000000','0.000328900000000','0.001467500000000','0.001549970295440','4.7125883108542075','4.712588310854207','test'),('2019-03-27 07:59:59','2019-04-02 07:59:59','WTCBTC','4h','0.000334100000000','0.000432600000000','0.001467500000000','0.001900151152350','4.3923974857827','4.392397485782700','test'),('2019-04-02 11:59:59','2019-04-03 19:59:59','WTCBTC','4h','0.000473000000000','0.000412100000000','0.001543208085922','0.001344515966614','3.262596376156448','3.262596376156448','test'),('2019-04-05 15:59:59','2019-04-08 11:59:59','WTCBTC','4h','0.000435900000000','0.000428000000000','0.001543208085922','0.001515239873307','3.540280077820601','3.540280077820601','test'),('2019-04-14 07:59:59','2019-04-15 19:59:59','WTCBTC','4h','0.000418000000000','0.000413000000000','0.001543208085922','0.001524748659057','3.6918853730191388','3.691885373019139','test'),('2019-04-17 11:59:59','2019-04-23 03:59:59','WTCBTC','4h','0.000427300000000','0.000472500000000','0.001543208085922','0.001706449381227','3.6115330819611517','3.611533081961152','test'),('2019-05-30 11:59:59','2019-05-31 07:59:59','WTCBTC','4h','0.000317000000000','0.000281900000000','0.001543208085922','0.001372335518680','4.868164308902209','4.868164308902209','test'),('2019-05-31 15:59:59','2019-05-31 19:59:59','WTCBTC','4h','0.000275600000000','0.000281000000000','0.001543208085922','0.001573445109376','5.599448787815676','5.599448787815676','test'),('2019-06-09 23:59:59','2019-06-12 19:59:59','WTCBTC','4h','0.000271600000000','0.000264200000000','0.001543208085922','0.001501161915687','5.68191489662003','5.681914896620030','test'),('2019-07-02 19:59:59','2019-07-08 11:59:59','WTCBTC','4h','0.000186000000000','0.000200100000000','0.001543208085922','0.001660193215016','8.296817666247312','8.296817666247312','test'),('2019-07-12 03:59:59','2019-07-12 23:59:59','WTCBTC','4h','0.000227400000000','0.000205400000000','0.001543208085922','0.001393909150609','6.786315241521549','6.786315241521549','test'),('2019-07-13 03:59:59','2019-07-13 23:59:59','WTCBTC','4h','0.000206200000000','0.000204400000000','0.001543208085922','0.001529736822320','7.484035334248303','7.484035334248303','test'),('2019-07-25 03:59:59','2019-07-27 11:59:59','WTCBTC','4h','0.000196200000000','0.000187300000000','0.001543208085922','0.001473205272646','7.86548463772681','7.865484637726810','test'),('2019-07-27 19:59:59','2019-07-30 03:59:59','WTCBTC','4h','0.000187100000000','0.000188400000000','0.001543208085922','0.001553930536546','8.248038941325495','8.248038941325495','test'),('2019-07-30 15:59:59','2019-07-31 15:59:59','WTCBTC','4h','0.000196300000000','0.000178800000000','0.001543208085922','0.001405632224976','7.8614777683239945','7.861477768323994','test'),('2019-08-22 11:59:59','2019-08-23 15:59:59','WTCBTC','4h','0.000144500000000','0.000138000000000','0.001543208085922','0.001473790421157','10.679640733024224','10.679640733024224','test'),('2019-08-24 15:59:59','2019-08-25 15:59:59','WTCBTC','4h','0.000142700000000','0.000140900000000','0.001543208085922','0.001523742251622','10.814352389081991','10.814352389081991','test'),('2019-09-21 15:59:59','2019-09-22 11:59:59','WTCBTC','4h','0.000100300000000','0.000097800000000','0.001543208085922','0.001504743278197','15.38592308995015','15.385923089950150','test'),('2019-09-22 15:59:59','2019-09-22 19:59:59','WTCBTC','4h','0.000098200000000','0.000096700000000','0.001543208085922','0.001519635660984','15.714949958472506','15.714949958472506','test'),('2019-10-09 03:59:59','2019-10-09 15:59:59','WTCBTC','4h','0.000091200000000','0.000085800000000','0.001543208085922','0.001451833922940','16.92114129300439','16.921141293004389','test'),('2019-10-12 19:59:59','2019-10-13 15:59:59','WTCBTC','4h','0.000092500000000','0.000088200000000','0.001543208085922','0.001471469764090','16.683330658616217','16.683330658616217','test'),('2019-10-14 03:59:59','2019-10-14 19:59:59','WTCBTC','4h','0.000091300000000','0.000089200000000','0.001543208085922','0.001507712609685','16.902607731894854','16.902607731894854','test'),('2019-10-15 07:59:59','2019-10-16 11:59:59','WTCBTC','4h','0.000091700000000','0.000089600000000','0.001543208085922','0.001507867442733','16.828877709073065','16.828877709073065','test'),('2019-11-03 19:59:59','2019-11-04 11:59:59','WTCBTC','4h','0.000082500000000','0.000082700000000','0.001543208085922','0.001546949196433','18.705552556630305','18.705552556630305','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','WTCBTC','4h','0.000084400000000','0.000081800000000','0.001543208085922','0.001495668500337','18.284455994336493','18.284455994336493','test'),('2019-11-05 07:59:59','2019-11-08 03:59:59','WTCBTC','4h','0.000081500000000','0.000083700000000','0.001543208085922','0.001584865236708','18.935068538920245','18.935068538920245','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','WTCBTC','4h','0.000081200000000','0.000081100000000','0.001543208085922','0.001541307583353','19.005025688694584','19.005025688694584','test'),('2019-11-14 23:59:59','2019-11-15 07:59:59','WTCBTC','4h','0.000082100000000','0.000082300000000','0.001543208085922','0.001546967423525','18.796688013666262','18.796688013666262','test'),('2019-11-15 11:59:59','2019-11-15 15:59:59','WTCBTC','4h','0.000083500000000','0.000081200000000','0.001543208085922','0.001500700557807','18.481533963137725','18.481533963137725','test'),('2019-11-15 19:59:59','2019-11-15 23:59:59','WTCBTC','4h','0.000081800000000','0.000081700000000','0.001543208085922','0.001541321523470','18.86562452227384','18.865624522273841','test'),('2019-11-16 07:59:59','2019-11-17 07:59:59','WTCBTC','4h','0.000081900000000','0.000082700000000','0.001543208085922','0.001558282157579','18.842589571697193','18.842589571697193','test'),('2019-11-17 15:59:59','2019-11-19 03:59:59','WTCBTC','4h','0.000083500000000','0.000085200000000','0.001543208085922','0.001574626693659','18.481533963137725','18.481533963137725','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 19:20:14
