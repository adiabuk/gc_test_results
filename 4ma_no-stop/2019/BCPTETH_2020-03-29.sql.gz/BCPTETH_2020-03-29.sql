-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 11:59:59','2019-01-14 15:59:59','BCPTETH','4h','0.000232560000000','0.000223970000000','0.072144500000000','0.069479719921741','310.21886824905397','310.218868249053969','test'),('2019-01-14 23:59:59','2019-01-15 11:59:59','BCPTETH','4h','0.000239680000000','0.000228800000000','0.072144500000000','0.068869582777036','301.0034212283044','301.003421228304376','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','BCPTETH','4h','0.000230100000000','0.000231830000000','0.072144500000000','0.072686916275532','313.535419382877','313.535419382877024','test'),('2019-01-15 23:59:59','2019-01-16 15:59:59','BCPTETH','4h','0.000232600000000','0.000241050000000','0.072144500000000','0.074765398645744','310.1655202063629','310.165520206362885','test'),('2019-01-17 03:59:59','2019-01-21 07:59:59','BCPTETH','4h','0.000241910000000','0.000281000000000','0.072144500000000','0.083802259104626','298.2286800876359','298.228680087635894','test'),('2019-01-21 19:59:59','2019-01-22 03:59:59','BCPTETH','4h','0.000286390000000','0.000279000000000','0.074364844181170','0.072445935704970','259.6628519891399','259.662851989139881','test'),('2019-01-22 19:59:59','2019-01-23 23:59:59','BCPTETH','4h','0.000292150000000','0.000280000000000','0.074364844181170','0.071272142292410','254.5433653300359','254.543365330035897','test'),('2019-01-25 15:59:59','2019-01-27 15:59:59','BCPTETH','4h','0.000284880000000','0.000280030000000','0.074364844181170','0.073098804114199','261.0391890661682','261.039189066168205','test'),('2019-02-28 07:59:59','2019-03-09 07:59:59','BCPTETH','4h','0.000245000000000','0.000341980000000','0.074364844181170','0.103801181277863','303.52997624967344','303.529976249673439','test'),('2019-03-13 07:59:59','2019-03-14 07:59:59','BCPTETH','4h','0.000363730000000','0.000345000000000','0.080154515847360','0.076027019952545','220.36817377549355','220.368173775493545','test'),('2019-03-27 15:59:59','2019-03-28 07:59:59','BCPTETH','4h','0.000356210000000','0.000329870000000','0.080154515847360','0.074227478573225','225.02039765127313','225.020397651273129','test'),('2019-03-28 11:59:59','2019-03-30 03:59:59','BCPTETH','4h','0.000350100000000','0.000334000000000','0.080154515847360','0.076468461276830','228.94748885278491','228.947488852784915','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','BCPTETH','4h','0.000348410000000','0.000357190000000','0.080154515847360','0.082174425290659','230.05802315478888','230.058023154788884','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','BCPTETH','4h','0.000376200000000','0.000353950000000','0.080154515847360','0.075413851366755','213.06357216204148','213.063572162041481','test'),('2019-04-19 23:59:59','2019-04-21 11:59:59','BCPTETH','4h','0.000366650000000','0.000342230000000','0.080154515847360','0.074815982431316','218.61316200016364','218.613162000163641','test'),('2019-04-22 11:59:59','2019-04-24 07:59:59','BCPTETH','4h','0.000358400000000','0.000347340000000','0.080154515847360','0.077680997584883','223.64541252053573','223.645412520535729','test'),('2019-04-24 11:59:59','2019-04-24 15:59:59','BCPTETH','4h','0.000357630000000','0.000370620000000','0.080154515847360','0.083065924736036','224.12693523295025','224.126935232950245','test'),('2019-05-23 07:59:59','2019-05-27 15:59:59','BCPTETH','4h','0.000235250000000','0.000254170000000','0.080154515847360','0.086600949172895','340.7205774595537','340.720577459553681','test'),('2019-05-28 07:59:59','2019-05-29 15:59:59','BCPTETH','4h','0.000294690000000','0.000279560000000','0.080154515847360','0.076039215617388','271.99604956856354','271.996049568563535','test'),('2019-05-30 11:59:59','2019-05-30 15:59:59','BCPTETH','4h','0.000298660000000','0.000270460000000','0.080154515847360','0.072586186151734','268.3804856604835','268.380485660483487','test'),('2019-05-30 23:59:59','2019-05-31 23:59:59','BCPTETH','4h','0.000286710000000','0.000281260000000','0.080154515847360','0.078630878334305','279.56651615695296','279.566516156952957','test'),('2019-06-02 19:59:59','2019-06-03 15:59:59','BCPTETH','4h','0.000294780000000','0.000277080000000','0.080154515847360','0.075341655644842','271.9130057919804','271.913005791980424','test'),('2019-07-05 03:59:59','2019-07-05 07:59:59','BCPTETH','4h','0.000198340000000','0.000193880000000','0.080154515847360','0.078352110176899','404.1268319419179','404.126831941917885','test'),('2019-07-14 07:59:59','2019-07-17 23:59:59','BCPTETH','4h','0.000186450000000','0.000191790000000','0.080154515847360','0.082450172133897','429.89818099951725','429.898180999517251','test'),('2019-07-18 03:59:59','2019-07-18 07:59:59','BCPTETH','4h','0.000195920000000','0.000192210000000','0.080154515847360','0.078636685846371','409.1185986492446','409.118598649244575','test'),('2019-07-22 03:59:59','2019-07-24 19:59:59','BCPTETH','4h','0.000193220000000','0.000194410000000','0.080154515847360','0.080648170095669','414.83550278107856','414.835502781078560','test'),('2019-07-26 07:59:59','2019-07-26 23:59:59','BCPTETH','4h','0.000197510000000','0.000196040000000','0.080154515847360','0.079557952947782','405.82510175363274','405.825101753632737','test'),('2019-07-27 03:59:59','2019-07-27 11:59:59','BCPTETH','4h','0.000196430000000','0.000192300000000','0.080154515847360','0.078469242974328','408.0563857219366','408.056385721936579','test'),('2019-07-28 11:59:59','2019-07-30 15:59:59','BCPTETH','4h','0.000197780000000','0.000198870000000','0.080154515847360','0.080596261333626','405.27108831712','405.271088317120018','test'),('2019-08-12 15:59:59','2019-08-14 03:59:59','BCPTETH','4h','0.000211050000000','0.000168450000000','0.080154515847360','0.063975494880302','379.78922457882015','379.789224578820154','test'),('2019-08-22 11:59:59','2019-08-23 11:59:59','BCPTETH','4h','0.000172330000000','0.000169950000000','0.080154515847360','0.079047524913009','465.1222413239714','465.122241323971423','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','BCPTETH','4h','0.000168230000000','0.000167650000000','0.080154515847360','0.079878170253878','476.45791979646907','476.457919796469071','test'),('2019-08-26 07:59:59','2019-08-28 15:59:59','BCPTETH','4h','0.000183150000000','0.000176460000000','0.080154515847360','0.077226676857358','437.64409417067975','437.644094170679750','test'),('2019-09-10 15:59:59','2019-09-12 23:59:59','BCPTETH','4h','0.000220960000000','0.000198520000000','0.080154515847360','0.072014276276330','362.75577411006515','362.755774110065147','test'),('2019-09-13 03:59:59','2019-09-13 19:59:59','BCPTETH','4h','0.000205270000000','0.000210970000000','0.080154515847360','0.082380270903286','390.4833431449311','390.483343144931098','test'),('2019-10-03 11:59:59','2019-10-06 07:59:59','BCPTETH','4h','0.000168610000000','0.000170550000000','0.080154515847360','0.081076761032959','475.3841162882391','475.384116288239113','test'),('2019-10-06 11:59:59','2019-10-08 03:59:59','BCPTETH','4h','0.000172770000000','0.000175080000000','0.080154515847360','0.081226211926583','463.93769663344335','463.937696633443352','test'),('2019-10-08 15:59:59','2019-10-09 15:59:59','BCPTETH','4h','0.000186420000000','0.000164490000000','0.080154515847360','0.070725331572429','429.96736319794013','429.967363197940131','test'),('2019-10-21 03:59:59','2019-10-23 03:59:59','BCPTETH','4h','0.000170030000000','0.000174060000000','0.080154515847360','0.082054314111577','471.41396134423337','471.413961344233371','test'),('2019-10-23 07:59:59','2019-10-23 15:59:59','BCPTETH','4h','0.000178970000000','0.000176140000000','0.080154515847360','0.078887056050478','447.8656526085936','447.865652608593621','test'),('2019-10-24 19:59:59','2019-10-25 11:59:59','BCPTETH','4h','0.000178610000000','0.000173310000000','0.080154515847360','0.077776043567023','448.76835478058337','448.768354780583365','test'),('2019-10-31 03:59:59','2019-10-31 15:59:59','BCPTETH','4h','0.000179290000000','0.000168420000000','0.080154515847360','0.075294905231816','447.06629397824753','447.066293978247529','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','BCPTETH','4h','0.000169600000000','0.000166460000000','0.080154515847360','0.078670523042167','472.60917362830185','472.609173628301846','test'),('2019-11-01 07:59:59','2019-11-02 15:59:59','BCPTETH','4h','0.000171740000000','0.000170710000000','0.080154515847360','0.079673794109135','466.7201341991382','466.720134199138215','test'),('2019-11-25 11:59:59','2019-11-30 03:59:59','BCPTETH','4h','0.000175290000000','0.000171860000000','0.080154515847360','0.078586086448327','457.2680463652233','457.268046365223313','test'),('2019-12-06 15:59:59','2019-12-10 03:59:59','BCPTETH','4h','0.000171290000000','0.000174710000000','0.080154515847360','0.081754892075966','467.9462656743534','467.946265674353413','test'),('2019-12-20 15:59:59','2019-12-22 19:59:59','BCPTETH','4h','0.000171840000000','0.000165150000000','0.080154515847360','0.077033975164057','466.4485326312849','466.448532631284877','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','BCPTETH','4h','0.000168430000000','0.000161980000000','0.053436343898240','0.051390007627126','317.26143738193906','317.261437381939061','test'),('2019-12-29 03:59:59','2019-12-29 07:59:59','BCPTETH','4h','0.000165350000000','0.000161660000000','0.059441513744328','0.058114999164851','359.48904592880575','359.489045928805751','test'),('2019-12-29 11:59:59','2019-12-29 15:59:59','BCPTETH','4h','0.000165680000000','0.000160990000000','0.059441513744328','0.057758868286452','358.77301873689044','358.773018736890435','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:20:18
