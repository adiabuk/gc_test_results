-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-01 23:59:59','STORJBTC','4h','0.000038310000000','0.000038090000000','0.001467500000000','0.001459072696424','38.305925345862704','38.305925345862704','test'),('2019-01-02 03:59:59','2019-01-02 15:59:59','STORJBTC','4h','0.000038320000000','0.000037880000000','0.001467500000000','0.001450649791232','38.295929018789145','38.295929018789145','test'),('2019-01-02 19:59:59','2019-01-02 23:59:59','STORJBTC','4h','0.000038350000000','0.000037930000000','0.001467500000000','0.001451428292047','38.26597131681878','38.265971316818778','test'),('2019-01-03 03:59:59','2019-01-03 07:59:59','STORJBTC','4h','0.000038010000000','0.000038360000000','0.001467500000000','0.001481012891344','38.608260983951595','38.608260983951595','test'),('2019-01-03 11:59:59','2019-01-04 11:59:59','STORJBTC','4h','0.000038410000000','0.000038240000000','0.001467500000000','0.001461004946628','38.206196303046084','38.206196303046084','test'),('2019-01-05 23:59:59','2019-01-07 03:59:59','STORJBTC','4h','0.000038510000000','0.000037990000000','0.001467500000000','0.001447684367697','38.1069851986497','38.106985198649703','test'),('2019-01-07 15:59:59','2019-01-08 15:59:59','STORJBTC','4h','0.000038500000000','0.000038120000000','0.001467500000000','0.001453015584416','38.116883116883116','38.116883116883116','test'),('2019-01-08 19:59:59','2019-01-08 23:59:59','STORJBTC','4h','0.000038380000000','0.000038320000000','0.001467500000000','0.001465205836373','38.23606044815008','38.236060448150077','test'),('2019-01-17 07:59:59','2019-01-18 11:59:59','STORJBTC','4h','0.000037450000000','0.000036320000000','0.001467500000000','0.001423220293725','39.18558077436582','39.185580774365818','test'),('2019-01-19 03:59:59','2019-01-22 07:59:59','STORJBTC','4h','0.000037450000000','0.000038530000000','0.001467500000000','0.001509820427236','39.18558077436582','39.185580774365818','test'),('2019-01-22 19:59:59','2019-01-25 11:59:59','STORJBTC','4h','0.000039730000000','0.000039170000000','0.001467500000000','0.001446815378807','36.93682355902341','36.936823559023409','test'),('2019-02-04 15:59:59','2019-02-05 07:59:59','STORJBTC','4h','0.000039270000000','0.000041500000000','0.001467500000000','0.001550833969952','37.369493251846194','37.369493251846194','test'),('2019-02-05 15:59:59','2019-02-06 03:59:59','STORJBTC','4h','0.000041290000000','0.000037960000000','0.001467500000000','0.001349147493340','35.54129329135384','35.541293291353838','test'),('2019-02-07 11:59:59','2019-02-08 11:59:59','STORJBTC','4h','0.000044370000000','0.000040760000000','0.001467500000000','0.001348102321388','33.074149199909854','33.074149199909854','test'),('2019-02-11 19:59:59','2019-02-12 07:59:59','STORJBTC','4h','0.000040180000000','0.000040000000000','0.001467500000000','0.001460925833748','36.52314584370334','36.523145843703340','test'),('2019-02-12 15:59:59','2019-02-12 19:59:59','STORJBTC','4h','0.000039950000000','0.000039180000000','0.001467500000000','0.001439215269086','36.73341677096371','36.733416770963707','test'),('2019-02-16 11:59:59','2019-02-19 03:59:59','STORJBTC','4h','0.000055830000000','0.000055320000000','0.001467500000000','0.001454094572810','26.28515135231954','26.285151352319541','test'),('2019-02-20 03:59:59','2019-02-21 19:59:59','STORJBTC','4h','0.000064110000000','0.000059100000000','0.001467500000000','0.001352819372953','22.890344720012482','22.890344720012482','test'),('2019-02-23 15:59:59','2019-02-23 19:59:59','STORJBTC','4h','0.000062030000000','0.000059220000000','0.001467500000000','0.001401021280026','23.65790746413026','23.657907464130261','test'),('2019-02-27 11:59:59','2019-02-28 03:59:59','STORJBTC','4h','0.000061350000000','0.000058800000000','0.001467500000000','0.001406503667482','23.920130399348004','23.920130399348004','test'),('2019-03-01 23:59:59','2019-03-02 23:59:59','STORJBTC','4h','0.000060170000000','0.000059490000000','0.001467500000000','0.001450915323251','24.389230513544955','24.389230513544955','test'),('2019-03-03 11:59:59','2019-03-03 15:59:59','STORJBTC','4h','0.000058950000000','0.000058640000000','0.001467500000000','0.001459782866836','24.893977947413063','24.893977947413063','test'),('2019-03-10 11:59:59','2019-03-13 15:59:59','STORJBTC','4h','0.000061420000000','0.000063990000000','0.001467500000000','0.001528904672745','23.892868772386844','23.892868772386844','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','STORJBTC','4h','0.000069260000000','0.000064010000000','0.001467500000000','0.001356261550679','21.1882760612186','21.188276061218598','test'),('2019-03-15 07:59:59','2019-03-16 07:59:59','STORJBTC','4h','0.000068260000000','0.000064400000000','0.001467500000000','0.001384515089364','21.498681511866394','21.498681511866394','test'),('2019-03-17 11:59:59','2019-03-18 07:59:59','STORJBTC','4h','0.000066930000000','0.000064770000000','0.001467500000000','0.001420140071717','21.925892723741224','21.925892723741224','test'),('2019-03-19 15:59:59','2019-03-20 11:59:59','STORJBTC','4h','0.000066280000000','0.000065920000000','0.001467500000000','0.001459529269765','22.140917320458662','22.140917320458662','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','STORJBTC','4h','0.000065890000000','0.000065250000000','0.001467500000000','0.001453245940203','22.271968432235546','22.271968432235546','test'),('2019-03-21 23:59:59','2019-03-23 19:59:59','STORJBTC','4h','0.000067710000000','0.000066540000000','0.001467500000000','0.001442142224191','21.673312656919215','21.673312656919215','test'),('2019-03-24 03:59:59','2019-03-25 07:59:59','STORJBTC','4h','0.000067730000000','0.000066730000000','0.001467500000000','0.001445833087258','21.666912741768787','21.666912741768787','test'),('2019-03-26 19:59:59','2019-04-02 07:59:59','STORJBTC','4h','0.000069700000000','0.000070460000000','0.001467500000000','0.001483501434720','21.0545193687231','21.054519368723099','test'),('2019-05-22 19:59:59','2019-05-26 19:59:59','STORJBTC','4h','0.000036040000000','0.000035720000000','0.001467500000000','0.001454470033296','40.718645948945614','40.718645948945614','test'),('2019-06-07 23:59:59','2019-06-13 15:59:59','STORJBTC','4h','0.000034000000000','0.000036680000000','0.001467500000000','0.001583173529412','43.161764705882355','43.161764705882355','test'),('2019-07-06 07:59:59','2019-07-07 07:59:59','STORJBTC','4h','0.000026170000000','0.000024070000000','0.001467500000000','0.001349741115781','56.07565915170043','56.075659151700428','test'),('2019-07-07 11:59:59','2019-07-08 07:59:59','STORJBTC','4h','0.000024220000000','0.000023460000000','0.001467500000000','0.001421451279934','60.590421139554095','60.590421139554095','test'),('2019-07-23 11:59:59','2019-07-24 03:59:59','STORJBTC','4h','0.000018340000000','0.000017540000000','0.001467500000000','0.001403486913850','80.01635768811342','80.016357688113416','test'),('2019-07-24 19:59:59','2019-07-25 03:59:59','STORJBTC','4h','0.000017770000000','0.000017740000000','0.001467500000000','0.001465022509848','82.5830050647158','82.583005064715806','test'),('2019-07-25 19:59:59','2019-07-27 07:59:59','STORJBTC','4h','0.000017930000000','0.000018060000000','0.001467500000000','0.001478139988846','81.84606804238706','81.846068042387060','test'),('2019-07-27 19:59:59','2019-07-27 23:59:59','STORJBTC','4h','0.000018090000000','0.000018060000000','0.001467500000000','0.001465066334992','81.12216694306247','81.122166943062467','test'),('2019-07-29 03:59:59','2019-07-29 11:59:59','STORJBTC','4h','0.000018160000000','0.000020370000000','0.001467500000000','0.001646088931718','80.80947136563877','80.809471365638771','test'),('2019-07-29 19:59:59','2019-07-30 19:59:59','STORJBTC','4h','0.000019180000000','0.000018300000000','0.001467500000000','0.001400169447341','76.51199165797706','76.511991657977063','test'),('2019-07-30 23:59:59','2019-07-31 03:59:59','STORJBTC','4h','0.000018490000000','0.000018400000000','0.001467500000000','0.001460356949703','79.36722552731206','79.367225527312058','test'),('2019-08-18 19:59:59','2019-08-19 07:59:59','STORJBTC','4h','0.000014210000000','0.000013610000000','0.001467500000000','0.001405536593948','103.27234342012667','103.272343420126674','test'),('2019-08-19 11:59:59','2019-08-19 19:59:59','STORJBTC','4h','0.000013870000000','0.000013730000000','0.001467500000000','0.001452687454939','105.80389329488105','105.803893294881050','test'),('2019-08-20 15:59:59','2019-08-26 03:59:59','STORJBTC','4h','0.000013980000000','0.000014970000000','0.001467500000000','0.001571421673820','104.97138769670958','104.971387696709584','test'),('2019-08-30 15:59:59','2019-08-31 11:59:59','STORJBTC','4h','0.000015520000000','0.000014730000000','0.001467500000000','0.001392801224227','94.55541237113403','94.555412371134025','test'),('2019-08-31 15:59:59','2019-08-31 19:59:59','STORJBTC','4h','0.000014740000000','0.000014740000000','0.001467500000000','0.001467500000000','99.55902306648576','99.559023066485764','test'),('2019-08-31 23:59:59','2019-09-01 03:59:59','STORJBTC','4h','0.000014910000000','0.000014870000000','0.001467500000000','0.001463563044936','98.42387659289068','98.423876592890679','test'),('2019-09-01 07:59:59','2019-09-01 15:59:59','STORJBTC','4h','0.000015070000000','0.000015250000000','0.001467500000000','0.001485028201725','97.378898473789','97.378898473788993','test'),('2019-09-01 19:59:59','2019-09-03 07:59:59','STORJBTC','4h','0.000015320000000','0.000014890000000','0.001467500000000','0.001426310378590','95.789817232376','95.789817232375995','test'),('2019-09-04 15:59:59','2019-09-04 19:59:59','STORJBTC','4h','0.000015200000000','0.000014800000000','0.001467500000000','0.001428881578947','96.54605263157895','96.546052631578945','test'),('2019-09-10 23:59:59','2019-09-12 03:59:59','STORJBTC','4h','0.000014890000000','0.000014620000000','0.001467500000000','0.001440889858966','98.556077904634','98.556077904633995','test'),('2019-09-12 07:59:59','2019-09-12 11:59:59','STORJBTC','4h','0.000014690000000','0.000014590000000','0.001467500000000','0.001457510211028','99.89788972089858','99.897889720898576','test'),('2019-09-16 07:59:59','2019-09-22 23:59:59','STORJBTC','4h','0.000014770000000','0.000015460000000','0.001467500000000','0.001536056194990','99.35680433310766','99.356804333107661','test'),('2019-10-04 03:59:59','2019-10-09 15:59:59','STORJBTC','4h','0.000015480000000','0.000015710000000','0.001467500000000','0.001489303940568','94.79974160206719','94.799741602067186','test'),('2019-10-15 23:59:59','2019-10-16 03:59:59','STORJBTC','4h','0.000016160000000','0.000015790000000','0.001467500000000','0.001433900061881','90.81064356435644','90.810643564356440','test'),('2019-10-16 07:59:59','2019-10-16 11:59:59','STORJBTC','4h','0.000015920000000','0.000015110000000','0.001467500000000','0.001392834484925','92.17964824120604','92.179648241206039','test'),('2019-10-25 07:59:59','2019-10-25 15:59:59','STORJBTC','4h','0.000015810000000','0.000014900000000','0.001467500000000','0.001383032890576','92.82099936748894','92.820999367488938','test'),('2019-10-30 03:59:59','2019-10-30 07:59:59','STORJBTC','4h','0.000015010000000','0.000014790000000','0.001467500000000','0.001445991005996','97.76815456362425','97.768154563624250','test'),('2019-10-30 23:59:59','2019-10-31 07:59:59','STORJBTC','4h','0.000015130000000','0.000015070000000','0.001467500000000','0.001461680436219','96.99272967614012','96.992729676140115','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','STORJBTC','4h','0.000015230000000','0.000014970000000','0.001467500000000','0.001442447472095','96.3558765594222','96.355876559422200','test'),('2019-10-31 23:59:59','2019-11-01 03:59:59','STORJBTC','4h','0.000015140000000','0.000015040000000','0.001467500000000','0.001457807133421','96.92866578599735','96.928665785997353','test'),('2019-11-01 07:59:59','2019-11-01 11:59:59','STORJBTC','4h','0.000015100000000','0.000015040000000','0.001467500000000','0.001461668874172','97.18543046357617','97.185430463576168','test'),('2019-11-02 07:59:59','2019-11-02 15:59:59','STORJBTC','4h','0.000015290000000','0.000015090000000','0.001467500000000','0.001448304447351','95.97776324395029','95.977763243950292','test'),('2019-11-02 19:59:59','2019-11-02 23:59:59','STORJBTC','4h','0.000015150000000','0.000015090000000','0.001467500000000','0.001461688118812','96.86468646864687','96.864686468646866','test'),('2019-11-03 03:59:59','2019-11-04 07:59:59','STORJBTC','4h','0.000015460000000','0.000015480000000','0.001467500000000','0.001469398447607','94.92238033635188','94.922380336351878','test'),('2019-11-04 11:59:59','2019-11-04 15:59:59','STORJBTC','4h','0.000015490000000','0.000015450000000','0.001467500000000','0.001463710458360','94.7385409941898','94.738540994189805','test'),('2019-11-04 19:59:59','2019-11-04 23:59:59','STORJBTC','4h','0.000015490000000','0.000015230000000','0.001467500000000','0.001442867979342','94.7385409941898','94.738540994189805','test'),('2019-11-08 23:59:59','2019-11-10 19:59:59','STORJBTC','4h','0.000015490000000','0.000015270000000','0.001467500000000','0.001446657520981','94.7385409941898','94.738540994189805','test'),('2019-11-10 23:59:59','2019-11-12 03:59:59','STORJBTC','4h','0.000015550000000','0.000015520000000','0.001467500000000','0.001464668810289','94.37299035369776','94.372990353697759','test'),('2019-11-12 07:59:59','2019-11-13 01:59:59','STORJBTC','4h','0.000015530000000','0.000015450000000','0.001467500000000','0.001459940437862','94.49452672247264','94.494526722472642','test'),('2019-11-14 15:59:59','2019-11-15 11:59:59','STORJBTC','4h','0.000015700000000','0.000015660000000','0.001467500000000','0.001463761146497','93.47133757961784','93.471337579617838','test'),('2019-11-15 15:59:59','2019-11-15 19:59:59','STORJBTC','4h','0.000015720000000','0.000015820000000','0.001467500000000','0.001476835241730','93.352417302799','93.352417302798997','test'),('2019-11-16 03:59:59','2019-11-22 11:59:59','STORJBTC','4h','0.000015730000000','0.000016870000000','0.001467500000000','0.001573854100445','93.29307056579785','93.293070565797848','test'),('2019-11-24 07:59:59','2019-11-24 19:59:59','STORJBTC','4h','0.000017260000000','0.000017050000000','0.001467500000000','0.001449645133256','85.02317497103128','85.023174971031281','test'),('2019-11-26 15:59:59','2019-11-27 19:59:59','STORJBTC','4h','0.000020170000000','0.000017040000000','0.001467500000000','0.001239771938523','72.75656916212198','72.756569162121977','test'),('2019-11-27 23:59:59','2019-11-28 03:59:59','STORJBTC','4h','0.000017170000000','0.000017040000000','0.001467500000000','0.001456389050670','85.46884100174724','85.468841001747236','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 20:35:34
