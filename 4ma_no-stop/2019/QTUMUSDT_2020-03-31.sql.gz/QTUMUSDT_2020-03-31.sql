-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 07:59:59','2019-01-07 11:59:59','QTUMUSDT','4h','2.294000000000000','2.261000000000000','15.000000000000000','14.784219703574543','6.538796861377507','6.538796861377507','test'),('2019-01-08 11:59:59','2019-01-08 19:59:59','QTUMUSDT','4h','2.283000000000000','2.249000000000000','15.000000000000000','14.776609724047308','6.57030223390276','6.570302233902760','test'),('2019-01-09 03:59:59','2019-01-10 07:59:59','QTUMUSDT','4h','2.295000000000000','2.282000000000000','15.000000000000000','14.915032679738562','6.5359477124183005','6.535947712418301','test'),('2019-02-09 11:59:59','2019-02-12 11:59:59','QTUMUSDT','4h','1.956000000000000','1.898000000000000','15.000000000000000','14.555214723926380','7.668711656441718','7.668711656441718','test'),('2019-02-12 15:59:59','2019-02-14 07:59:59','QTUMUSDT','4h','1.907000000000000','1.897000000000000','15.000000000000000','14.921342422653382','7.865757734661773','7.865757734661773','test'),('2019-02-16 03:59:59','2019-02-21 19:59:59','QTUMUSDT','4h','1.975000000000000','2.066000000000000','15.000000000000000','15.691139240506329','7.594936708860759','7.594936708860759','test'),('2019-02-22 19:59:59','2019-02-24 15:59:59','QTUMUSDT','4h','2.124000000000000','2.037000000000000','15.000000000000000','14.385593220338983','7.062146892655367','7.062146892655367','test'),('2019-03-01 15:59:59','2019-03-02 07:59:59','QTUMUSDT','4h','2.124000000000000','2.070000000000000','15.000000000000000','14.618644067796607','7.062146892655367','7.062146892655367','test'),('2019-03-02 11:59:59','2019-03-02 15:59:59','QTUMUSDT','4h','2.080000000000000','2.074000000000000','15.000000000000000','14.956730769230768','7.211538461538462','7.211538461538462','test'),('2019-03-08 15:59:59','2019-03-08 23:59:59','QTUMUSDT','4h','2.102000000000000','2.097000000000000','15.000000000000000','14.964319695528069','7.136060894386299','7.136060894386299','test'),('2019-03-09 03:59:59','2019-03-11 07:59:59','QTUMUSDT','4h','2.152000000000000','2.090000000000000','15.000000000000000','14.567843866171001','6.970260223048327','6.970260223048327','test'),('2019-03-12 19:59:59','2019-03-13 11:59:59','QTUMUSDT','4h','2.151000000000000','2.123000000000000','15.000000000000000','14.804741980474201','6.973500697350071','6.973500697350071','test'),('2019-03-13 15:59:59','2019-03-14 03:59:59','QTUMUSDT','4h','2.131000000000000','2.120000000000000','15.000000000000000','14.922571562646647','7.0389488503050215','7.038948850305021','test'),('2019-03-14 15:59:59','2019-03-19 03:59:59','QTUMUSDT','4h','2.705000000000000','2.465000000000000','15.000000000000000','13.669131238447319','5.545286506469501','5.545286506469501','test'),('2019-03-19 15:59:59','2019-03-20 03:59:59','QTUMUSDT','4h','2.491000000000000','2.448000000000000','15.000000000000000','14.741067844239261','6.02167804094741','6.021678040947410','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','QTUMUSDT','4h','2.557000000000000','2.431000000000000','15.000000000000000','14.260852561595621','5.866249511145874','5.866249511145874','test'),('2019-03-22 19:59:59','2019-03-25 11:59:59','QTUMUSDT','4h','2.525000000000000','2.528000000000000','15.000000000000000','15.017821782178217','5.9405940594059405','5.940594059405941','test'),('2019-03-27 19:59:59','2019-04-05 03:59:59','QTUMUSDT','4h','2.581000000000000','3.175000000000000','15.000000000000000','18.452150329329719','5.81170089112747','5.811700891127470','test'),('2019-04-05 07:59:59','2019-04-09 03:59:59','QTUMUSDT','4h','3.312000000000000','3.282000000000000','15.000000000000000','14.864130434782609','4.528985507246377','4.528985507246377','test'),('2019-05-03 11:59:59','2019-05-04 11:59:59','QTUMUSDT','4h','2.656000000000000','2.535000000000000','15.000000000000000','14.316641566265060','5.647590361445783','5.647590361445783','test'),('2019-05-12 07:59:59','2019-05-12 11:59:59','QTUMUSDT','4h','2.590000000000000','2.435000000000000','15.000000000000000','14.102316602316604','5.7915057915057915','5.791505791505791','test'),('2019-05-13 11:59:59','2019-05-17 15:59:59','QTUMUSDT','4h','2.474000000000000','2.783000000000000','15.000000000000000','16.873484236054971','6.063055780113176','6.063055780113176','test'),('2019-05-19 07:59:59','2019-05-20 15:59:59','QTUMUSDT','4h','3.031000000000000','3.123000000000000','15.000000000000000','15.455295282085119','4.948861761794787','4.948861761794787','test'),('2019-05-20 23:59:59','2019-05-22 23:59:59','QTUMUSDT','4h','3.090000000000000','2.853000000000000','15.000000000000000','13.849514563106798','4.8543689320388355','4.854368932038835','test'),('2019-05-27 03:59:59','2019-05-29 07:59:59','QTUMUSDT','4h','3.064000000000000','3.089000000000000','15.000000000000000','15.122389033942557','4.895561357702349','4.895561357702349','test'),('2019-05-29 11:59:59','2019-05-30 23:59:59','QTUMUSDT','4h','3.113000000000000','3.114000000000000','15.000000000000000','15.004818503051720','4.8185030517186','4.818503051718600','test'),('2019-06-01 03:59:59','2019-06-03 07:59:59','QTUMUSDT','4h','3.682000000000000','3.337000000000000','15.000000000000000','13.594513851167845','4.073872895165671','4.073872895165671','test'),('2019-06-12 15:59:59','2019-06-13 03:59:59','QTUMUSDT','4h','3.206000000000000','3.169000000000000','15.000000000000000','14.826887086712414','4.678727386150967','4.678727386150967','test'),('2019-06-13 07:59:59','2019-06-18 19:59:59','QTUMUSDT','4h','3.190000000000000','3.544000000000000','15.000000000000000','16.664576802507838','4.702194357366771','4.702194357366771','test'),('2019-06-19 03:59:59','2019-06-20 03:59:59','QTUMUSDT','4h','3.651000000000000','3.570000000000000','15.000000000000000','14.667214461791291','4.108463434675431','4.108463434675431','test'),('2019-06-22 03:59:59','2019-06-27 19:59:59','QTUMUSDT','4h','3.645000000000000','4.373000000000000','15.000000000000000','17.995884773662553','4.11522633744856','4.115226337448560','test'),('2019-06-28 23:59:59','2019-06-30 23:59:59','QTUMUSDT','4h','5.307000000000000','4.934000000000000','15.335673652467573','14.257813039622198','2.889706736850871','2.889706736850871','test'),('2019-07-03 15:59:59','2019-07-04 23:59:59','QTUMUSDT','4h','5.103000000000000','4.840000000000000','15.335673652467573','14.545298937476595','3.0052270531976433','3.005227053197643','test'),('2019-07-08 19:59:59','2019-07-09 07:59:59','QTUMUSDT','4h','5.041000000000000','4.836000000000000','15.335673652467573','14.712024952059748','3.042188782477201','3.042188782477201','test'),('2019-08-03 03:59:59','2019-08-04 03:59:59','QTUMUSDT','4h','3.090000000000000','3.004000000000000','15.335673652467573','14.908855550813136','4.963001182028341','4.963001182028341','test'),('2019-08-05 03:59:59','2019-08-06 07:59:59','QTUMUSDT','4h','3.056000000000000','3.088000000000000','15.335673652467573','15.496256622650478','5.018217818215829','5.018217818215829','test'),('2019-09-17 19:59:59','2019-09-19 03:59:59','QTUMUSDT','4h','2.152000000000000','2.105000000000000','15.335673652467573','15.000740259500111','7.1262424035629985','7.126242403562999','test'),('2019-09-19 07:59:59','2019-09-21 19:59:59','QTUMUSDT','4h','2.131000000000000','2.137000000000000','15.335673652467573','15.378852461437450','7.196468161645976','7.196468161645976','test'),('2019-10-07 19:59:59','2019-10-11 07:59:59','QTUMUSDT','4h','1.786000000000000','1.777000000000000','15.335673652467573','15.258394221968016','8.586603388839627','8.586603388839627','test'),('2019-10-13 19:59:59','2019-10-13 23:59:59','QTUMUSDT','4h','1.807000000000000','1.791000000000000','15.335673652467573','15.199884621787174','8.486814417524943','8.486814417524943','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','QTUMUSDT','4h','1.797000000000000','1.783000000000000','15.335673652467573','15.216197063077175','8.534042099314176','8.534042099314176','test'),('2019-10-14 19:59:59','2019-10-15 07:59:59','QTUMUSDT','4h','1.812000000000000','1.782000000000000','15.335673652467573','15.081771770804203','8.46339605544568','8.463396055445680','test'),('2019-10-15 11:59:59','2019-10-15 15:59:59','QTUMUSDT','4h','1.795000000000000','1.799000000000000','15.335673652467573','15.369847855592850','8.543550781318983','8.543550781318983','test'),('2019-10-26 23:59:59','2019-10-30 15:59:59','QTUMUSDT','4h','1.837000000000000','2.139000000000000','15.335673652467573','17.856835025927133','8.348216468409131','8.348216468409131','test'),('2019-11-02 11:59:59','2019-11-03 11:59:59','QTUMUSDT','4h','2.194000000000000','2.105000000000000','15.335673652467573','14.713579324723904','6.989823907232258','6.989823907232258','test'),('2019-11-04 15:59:59','2019-11-07 15:59:59','QTUMUSDT','4h','2.233000000000000','2.172000000000000','15.335673652467573','14.916741232942039','6.8677445823858365','6.867744582385837','test'),('2019-11-12 19:59:59','2019-11-15 15:59:59','QTUMUSDT','4h','2.210000000000000','2.165000000000000','15.335673652467573','15.023408804340406','6.9392188472703955','6.939218847270396','test'),('2019-11-29 23:59:59','2019-11-30 15:59:59','QTUMUSDT','4h','1.882000000000000','1.781000000000000','15.335673652467573','14.512664598854807','8.148604491215501','8.148604491215501','test'),('2019-12-12 23:59:59','2019-12-14 15:59:59','QTUMUSDT','4h','1.817000000000000','1.764000000000000','15.335673652467573','14.888348003826527','8.440106578132951','8.440106578132951','test'),('2019-12-29 19:59:59','2019-12-30 15:59:59','QTUMUSDT','4h','1.700000000000000','1.619000000000000','15.335673652467573','14.604973907850001','9.020984501451514','9.020984501451514','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31 10:11:13
