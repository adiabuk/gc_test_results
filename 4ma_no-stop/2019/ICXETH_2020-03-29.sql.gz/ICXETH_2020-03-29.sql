-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 07:59:59','2019-01-11 07:59:59','ICXETH','4h','0.001811000000000','0.001862000000000','0.072144500000000','0.074176178354500','39.83683048039757','39.836830480397573','test'),('2019-01-11 11:59:59','2019-01-12 15:59:59','ICXETH','4h','0.001893000000000','0.001877000000000','0.072652419588625','0.072038347368119','38.37951378162969','38.379513781629690','test'),('2019-01-12 23:59:59','2019-01-13 07:59:59','ICXETH','4h','0.001908000000000','0.001888000000000','0.072652419588625','0.071890863827738','38.07778804435273','38.077788044352729','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','ICXETH','4h','0.001906000000000','0.001856000000000','0.072652419588625','0.070746532401095','38.11774375059024','38.117743750590243','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','ICXETH','4h','0.001893000000000','0.001945000000000','0.072652419588625','0.074648154305270','38.37951378162969','38.379513781629690','test'),('2019-01-20 23:59:59','2019-01-22 07:59:59','ICXETH','4h','0.001954000000000','0.001915000000000','0.072652419588625','0.071202345707378','37.18138157043245','37.181381570432450','test'),('2019-01-23 11:59:59','2019-01-23 23:59:59','ICXETH','4h','0.001971000000000','0.001948000000000','0.072652419588625','0.071804623723309','36.860689796359715','36.860689796359715','test'),('2019-01-24 03:59:59','2019-01-25 11:59:59','ICXETH','4h','0.001958000000000','0.001946000000000','0.072652419588625','0.072207154504323','37.10542369184117','37.105423691841168','test'),('2019-01-26 07:59:59','2019-01-26 15:59:59','ICXETH','4h','0.001970000000000','0.001952000000000','0.072652419588625','0.071988590374110','36.87940080640863','36.879400806408633','test'),('2019-02-07 23:59:59','2019-02-08 19:59:59','ICXETH','4h','0.002013000000000','0.001884000000000','0.072652419588625','0.067996601343750','36.0916143013537','36.091614301353701','test'),('2019-02-12 11:59:59','2019-02-12 23:59:59','ICXETH','4h','0.001900000000000','0.001858000000000','0.072652419588625','0.071046418734561','38.23811557296053','38.238115572960531','test'),('2019-02-13 03:59:59','2019-02-13 07:59:59','ICXETH','4h','0.001882000000000','0.001846000000000','0.072652419588625','0.071262681488099','38.60383612573061','38.603836125730609','test'),('2019-02-25 23:59:59','2019-03-04 07:59:59','ICXETH','4h','0.001795000000000','0.002090000000000','0.072652419588625','0.084592510830210','40.4748855646936','40.474885564693601','test'),('2019-03-07 15:59:59','2019-03-11 15:59:59','ICXETH','4h','0.002302000000000','0.002429000000000','0.072652419588625','0.076660611286173','31.560564547621638','31.560564547621638','test'),('2019-03-12 23:59:59','2019-03-14 07:59:59','ICXETH','4h','0.002550000000000','0.002460000000000','0.073553414899127','0.070957412020334','28.844476431030383','28.844476431030383','test'),('2019-03-19 19:59:59','2019-03-20 07:59:59','ICXETH','4h','0.002502000000000','0.002425000000000','0.073553414899127','0.071289780627651','29.3978476815056','29.397847681505599','test'),('2019-03-20 19:59:59','2019-03-20 23:59:59','ICXETH','4h','0.002431000000000','0.002415000000000','0.073553414899127','0.073069311798187','30.256443808772936','30.256443808772936','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','ICXETH','4h','0.002458000000000','0.002363000000000','0.073553414899127','0.070710626284230','29.92409068312734','29.924090683127339','test'),('2019-03-25 07:59:59','2019-03-25 15:59:59','ICXETH','4h','0.002483000000000','0.002389000000000','0.073553414899127','0.070768871604516','29.622801006494967','29.622801006494967','test'),('2019-03-25 23:59:59','2019-03-26 03:59:59','ICXETH','4h','0.002375000000000','0.002335000000000','0.073553414899127','0.072314620542931','30.96985890489558','30.969858904895581','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','ICXETH','4h','0.002457000000000','0.002514000000000','0.073553414899127','0.075259782277739','29.936269800214493','29.936269800214493','test'),('2019-04-03 11:59:59','2019-04-03 23:59:59','ICXETH','4h','0.002599000000000','0.002510000000000','0.073553414899127','0.071034656174224','28.300659830368218','28.300659830368218','test'),('2019-04-04 07:59:59','2019-04-07 23:59:59','ICXETH','4h','0.002643000000000','0.002499000000000','0.073553414899127','0.069545964371138','27.82951755547749','27.829517555477491','test'),('2019-04-23 03:59:59','2019-04-23 23:59:59','ICXETH','4h','0.002410000000000','0.002232000000000','0.073553414899127','0.068120839026909','30.520089169762247','30.520089169762247','test'),('2019-04-24 03:59:59','2019-04-24 07:59:59','ICXETH','4h','0.002236000000000','0.002208000000000','0.073553414899127','0.072632352458530','32.89508716418918','32.895087164189178','test'),('2019-04-24 23:59:59','2019-04-25 23:59:59','ICXETH','4h','0.002353000000000','0.002307000000000','0.073553414899127','0.072115481586182','31.25941984663281','31.259419846632809','test'),('2019-04-26 11:59:59','2019-04-26 19:59:59','ICXETH','4h','0.002337000000000','0.002262000000000','0.073553414899127','0.071192907360644','31.4734338464386','31.473433846438599','test'),('2019-06-03 15:59:59','2019-06-04 03:59:59','ICXETH','4h','0.001556000000000','0.001565000000000','0.073553414899127','0.073978852388903','47.27083219738239','47.270832197382390','test'),('2019-06-04 11:59:59','2019-06-04 15:59:59','ICXETH','4h','0.001536000000000','0.001532000000000','0.073553414899127','0.073361869547827','47.88633782495248','47.886337824952477','test'),('2019-06-08 07:59:59','2019-06-09 23:59:59','ICXETH','4h','0.001544000000000','0.001527000000000','0.073553414899127','0.072743565123683','47.63822208492682','47.638222084926817','test'),('2019-06-10 07:59:59','2019-06-10 11:59:59','ICXETH','4h','0.001568000000000','0.001527000000000','0.073553414899127','0.071630143208525','46.909065624443244','46.909065624443244','test'),('2019-06-10 15:59:59','2019-06-11 03:59:59','ICXETH','4h','0.001545000000000','0.001528000000000','0.073553414899127','0.072744089298295','47.607388284224605','47.607388284224605','test'),('2019-06-11 07:59:59','2019-06-11 11:59:59','ICXETH','4h','0.001551000000000','0.001534000000000','0.073553414899127','0.072747220151683','47.42322043786396','47.423220437863961','test'),('2019-06-11 19:59:59','2019-06-11 23:59:59','ICXETH','4h','0.001539000000000','0.001546000000000','0.073553414899127','0.073887965844087','47.79299213718454','47.792992137184541','test'),('2019-06-12 03:59:59','2019-06-12 23:59:59','ICXETH','4h','0.001557000000000','0.001514000000000','0.073553414899127','0.071522074603262','47.24047199687027','47.240471996870269','test'),('2019-07-07 15:59:59','2019-07-07 19:59:59','ICXETH','4h','0.001106000000000','0.001115000000000','0.073553414899127','0.074151950825069','66.50399177136258','66.503991771362578','test'),('2019-07-07 23:59:59','2019-07-08 19:59:59','ICXETH','4h','0.001163000000000','0.001096000000000','0.073553414899127','0.069316029861946','63.24455279374635','63.244552793746351','test'),('2019-07-11 07:59:59','2019-07-11 15:59:59','ICXETH','4h','0.001122000000000','0.001086000000000','0.073553414899127','0.071193412282043','65.55562825234136','65.555628252341364','test'),('2019-07-11 19:59:59','2019-07-11 23:59:59','ICXETH','4h','0.001099000000000','0.001086000000000','0.073553414899127','0.072683356306144','66.92758407563878','66.927584075638777','test'),('2019-07-12 15:59:59','2019-07-13 23:59:59','ICXETH','4h','0.001129000000000','0.001102000000000','0.073553414899127','0.071794387262035','65.14917174413375','65.149171744133753','test'),('2019-07-14 03:59:59','2019-07-17 07:59:59','ICXETH','4h','0.001129000000000','0.001185000000000','0.073553414899127','0.077201768516798','65.14917174413375','65.149171744133753','test'),('2019-07-17 23:59:59','2019-07-18 15:59:59','ICXETH','4h','0.001225000000000','0.001177000000000','0.073553414899127','0.070671321907161','60.043603999287356','60.043603999287356','test'),('2019-07-22 03:59:59','2019-07-24 23:59:59','ICXETH','4h','0.001221000000000','0.001234000000000','0.073553414899127','0.074336538890682','60.24030704269206','60.240307042692059','test'),('2019-07-25 15:59:59','2019-07-28 11:59:59','ICXETH','4h','0.001258000000000','0.001257000000000','0.073553414899127','0.073494946365821','58.46853330614229','58.468533306142291','test'),('2019-08-16 03:59:59','2019-08-18 19:59:59','ICXETH','4h','0.001071000000000','0.001036000000000','0.073553414899127','0.071149708529874','68.6773248357862','68.677324835786195','test'),('2019-08-22 15:59:59','2019-08-26 03:59:59','ICXETH','4h','0.001262000000000','0.001188000000000','0.073553414899127','0.069240457131666','58.283213073793185','58.283213073793185','test'),('2019-08-26 23:59:59','2019-08-27 15:59:59','ICXETH','4h','0.001275000000000','0.001203000000000','0.073553414899127','0.069399810293059','57.68895286206039','57.688952862060390','test'),('2019-08-29 07:59:59','2019-08-31 15:59:59','ICXETH','4h','0.001274000000000','0.001225000000000','0.073553414899127','0.070724437403007','57.73423461469938','57.734234614699382','test'),('2019-09-02 11:59:59','2019-09-02 19:59:59','ICXETH','4h','0.001268000000000','0.001234000000000','0.073553414899127','0.071581162449150','58.00742499931152','58.007424999311517','test'),('2019-10-05 19:59:59','2019-10-06 07:59:59','ICXETH','4h','0.000976000000000','0.000959000000000','0.073553414899127','0.072272259106827','75.36210542943341','75.362105429433413','test'),('2019-10-06 15:59:59','2019-10-07 03:59:59','ICXETH','4h','0.000975000000000','0.000957000000000','0.073553414899127','0.072195505700989','75.43939989654052','75.439399896540522','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','ICXETH','4h','0.000965000000000','0.000964000000000','0.073553414899127','0.073477193743791','76.22115533588291','76.221155335882912','test'),('2019-10-07 15:59:59','2019-10-07 19:59:59','ICXETH','4h','0.000967000000000','0.000944000000000','0.073553414899127','0.071803954151785','76.06351075400931','76.063510754009314','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','ICXETH','4h','0.000990000000000','0.000922000000000','0.073553414899127','0.068501261148480','74.29637868598688','74.296378685986880','test'),('2019-10-29 11:59:59','2019-10-29 19:59:59','ICXETH','4h','0.000907000000000','0.000882000000000','0.073553414899127','0.071526033011058','81.09527552274201','81.095275522742014','test'),('2019-10-30 07:59:59','2019-10-31 11:59:59','ICXETH','4h','0.000915000000000','0.000897000000000','0.073553414899127','0.072106462474882','80.38624579139564','80.386245791395638','test'),('2019-10-31 15:59:59','2019-10-31 23:59:59','ICXETH','4h','0.000901000000000','0.000890000000000','0.073553414899127','0.072655426481935','81.63531065385905','81.635310653859051','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','ICXETH','4h','0.000913000000000','0.000892000000000','0.073553414899127','0.071861605794109','80.56233833420264','80.562338334202636','test'),('2019-11-03 15:59:59','2019-11-08 11:59:59','ICXETH','4h','0.000915000000000','0.000925000000000','0.073553414899127','0.074357277357041','80.38624579139564','80.386245791395638','test'),('2019-11-19 03:59:59','2019-11-19 07:59:59','ICXETH','4h','0.000885000000000','0.000922000000000','0.073553414899127','0.076628529420333','83.11120327584972','83.111203275849718','test'),('2019-11-19 15:59:59','2019-11-20 11:59:59','ICXETH','4h','0.000909000000000','0.000895000000000','0.073553414899127','0.072420579026093','80.91684807384709','80.916848073847092','test'),('2019-11-20 15:59:59','2019-11-20 19:59:59','ICXETH','4h','0.000903000000000','0.000890000000000','0.073553414899127','0.072494506378985','81.45450154942083','81.454501549420826','test'),('2019-11-22 07:59:59','2019-11-22 11:59:59','ICXETH','4h','0.000908000000000','0.000892000000000','0.073553414899127','0.072257319482402','81.00596354529407','81.005963545294065','test'),('2019-11-24 03:59:59','2019-11-24 07:59:59','ICXETH','4h','0.000900000000000','0.000895000000000','0.073553414899127','0.073144784816354','81.72601655458557','81.726016554585570','test'),('2019-11-28 07:59:59','2019-11-30 11:59:59','ICXETH','4h','0.000904000000000','0.000894000000000','0.073553414899127','0.072739770929004','81.36439701230864','81.364397012308643','test'),('2019-12-03 19:59:59','2019-12-04 03:59:59','ICXETH','4h','0.000905000000000','0.000894000000000','0.073553414899127','0.072659395491513','81.27449160124532','81.274491601245316','test'),('2019-12-04 15:59:59','2019-12-04 19:59:59','ICXETH','4h','0.000907000000000','0.000897000000000','0.073553414899127','0.072742462143900','81.09527552274201','81.095275522742014','test'),('2019-12-05 23:59:59','2019-12-06 03:59:59','ICXETH','4h','0.000898000000000','0.000901000000000','0.049035609932751','0.049199426001569','54.605356272551596','54.605356272551596','test'),('2019-12-06 11:59:59','2019-12-06 19:59:59','ICXETH','4h','0.000901000000000','0.000894000000000','0.055114621748753','0.054686428239051','61.170501385963526','61.170501385963526','test'),('2019-12-06 23:59:59','2019-12-08 19:59:59','ICXETH','4h','0.000902000000000','0.000902000000000','0.055114621748753','0.055114621748753','61.10268486557982','61.102684865579818','test'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ICXETH','4h','0.000917000000000','0.000904000000000','0.055114621748753','0.054333280328105','60.10318620365649','60.103186203656492','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','ICXETH','4h','0.000909000000000','0.000907000000000','0.055114621748753','0.054993357454476','60.632147138342134','60.632147138342134','test'),('2019-12-12 19:59:59','2019-12-14 15:59:59','ICXETH','4h','0.000920000000000','0.000908000000000','0.055114621748753','0.054395735378117','59.907197552992386','59.907197552992386','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ICXETH','4h','0.000916000000000','0.000906000000000','0.055114621748753','0.054512933738395','60.168801035756545','60.168801035756545','test'),('2019-12-19 03:59:59','2019-12-23 03:59:59','ICXETH','4h','0.000917000000000','0.000917000000000','0.055114621748753','0.055114621748753','60.10318620365649','60.103186203656492','test'),('2019-12-24 11:59:59','2019-12-24 19:59:59','ICXETH','4h','0.000940000000000','0.000927000000000','0.055114621748753','0.054352398256483','58.63257632846064','58.632576328460637','test'),('2019-12-25 03:59:59','2019-12-27 03:59:59','ICXETH','4h','0.000943000000000','0.000935000000000','0.055114621748753','0.054647053377608','58.44604639316331','58.446046393163307','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','ICXETH','4h','0.000936000000000','0.000925000000000','0.055114621748753','0.054466907176919','58.883142893966884','58.883142893966884','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 17:45:06
