-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 23:59:59','2019-01-14 03:59:59','IOTXETH','4h','0.000056750000000','0.000055850000000','0.072144500000000','0.071000358149780','1271.2687224669605','1271.268722466960526','test'),('2019-01-14 07:59:59','2019-01-14 15:59:59','IOTXETH','4h','0.000056660000000','0.000054250000000','0.072144500000000','0.069075875838334','1273.2880338863395','1273.288033886339463','test'),('2019-01-16 07:59:59','2019-01-24 11:59:59','IOTXETH','4h','0.000056610000000','0.000064260000000','0.072144500000000','0.081893756756757','1274.4126479420597','1274.412647942059721','test'),('2019-01-28 15:59:59','2019-01-31 11:59:59','IOTXETH','4h','0.000066330000000','0.000062740000000','0.073528622686218','0.069549009307000','1108.5274036818598','1108.527403681859823','test'),('2019-02-26 19:59:59','2019-02-27 19:59:59','IOTXETH','4h','0.000054770000000','0.000053560000000','0.073528622686218','0.071904199946574','1342.4981319375206','1342.498131937520611','test'),('2019-02-27 23:59:59','2019-03-06 23:59:59','IOTXETH','4h','0.000054940000000','0.000061310000000','0.073528622686218','0.082053874351875','1338.3440605427377','1338.344060542737679','test'),('2019-03-07 11:59:59','2019-03-08 11:59:59','IOTXETH','4h','0.000064000000000','0.000061330000000','0.074258926572916','0.071160936979952','1160.2957277018204','1160.295727701820397','test'),('2019-03-10 11:59:59','2019-03-14 11:59:59','IOTXETH','4h','0.000067470000000','0.000066790000000','0.074258926572916','0.073510504013711','1100.6214105960573','1100.621410596057331','test'),('2019-03-18 19:59:59','2019-03-19 03:59:59','IOTXETH','4h','0.000068190000000','0.000066650000000','0.074258926572916','0.072581866198634','1089.0002430402699','1089.000243040269879','test'),('2019-03-19 07:59:59','2019-03-19 11:59:59','IOTXETH','4h','0.000067310000000','0.000067700000000','0.074258926572916','0.074689189258452','1103.2376552208586','1103.237655220858642','test'),('2019-03-20 11:59:59','2019-03-20 15:59:59','IOTXETH','4h','0.000067450000000','0.000067110000000','0.074258926572916','0.073884604333705','1100.9477623857078','1100.947762385707847','test'),('2019-03-20 23:59:59','2019-03-21 03:59:59','IOTXETH','4h','0.000066670000000','0.000066830000000','0.074258926572916','0.074437139086065','1113.8282071833808','1113.828207183380755','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','IOTXETH','4h','0.000067940000000','0.000067050000000','0.074258926572916','0.073286149936915','1093.0074561806887','1093.007456180688678','test'),('2019-03-22 03:59:59','2019-03-23 15:59:59','IOTXETH','4h','0.000067140000000','0.000067650000000','0.074258926572916','0.074823002422666','1106.0310779403635','1106.031077940363502','test'),('2019-03-23 19:59:59','2019-03-23 23:59:59','IOTXETH','4h','0.000067830000000','0.000067570000000','0.074258926572916','0.073974283776086','1094.7799878065161','1094.779987806516147','test'),('2019-03-26 07:59:59','2019-03-28 03:59:59','IOTXETH','4h','0.000068750000000','0.000069110000000','0.074258926572916','0.074647773315698','1080.1298410605962','1080.129841060596164','test'),('2019-03-28 15:59:59','2019-04-01 07:59:59','IOTXETH','4h','0.000069540000000','0.000071800000000','0.074258926572916','0.076672288293577','1067.8591684342248','1067.859168434224785','test'),('2019-04-03 23:59:59','2019-04-08 03:59:59','IOTXETH','4h','0.000079890000000','0.000092330000000','0.074258926572916','0.085822089003346','929.5146648255852','929.514664825585214','test'),('2019-04-15 07:59:59','2019-04-18 07:59:59','IOTXETH','4h','0.000092750000000','0.000089740000000','0.076354603508870','0.073876680527073','823.2302265107305','823.230226510730517','test'),('2019-05-23 19:59:59','2019-05-24 19:59:59','IOTXETH','4h','0.000050120000000','0.000045160000000','0.076354603508870','0.068798361820841','1523.4358241993216','1523.435824199321587','test'),('2019-05-24 23:59:59','2019-05-25 19:59:59','IOTXETH','4h','0.000045730000000','0.000046020000000','0.076354603508870','0.076838811578356','1669.682998225891','1669.682998225890969','test'),('2019-05-26 03:59:59','2019-05-26 11:59:59','IOTXETH','4h','0.000047350000000','0.000046000000000','0.076354603508870','0.074177650716114','1612.5576242633579','1612.557624263357866','test'),('2019-06-08 23:59:59','2019-06-12 11:59:59','IOTXETH','4h','0.000044310000000','0.000044470000000','0.076354603508870','0.076630314106058','1723.1912324276686','1723.191232427668638','test'),('2019-07-11 15:59:59','2019-07-13 03:59:59','IOTXETH','4h','0.000031650000000','0.000031400000000','0.076354603508870','0.075751486577520','2412.467725398736','2412.467725398736093','test'),('2019-07-13 07:59:59','2019-07-14 03:59:59','IOTXETH','4h','0.000032060000000','0.000031150000000','0.076354603508870','0.074187333103596','2381.615829970992','2381.615829970991854','test'),('2019-07-14 23:59:59','2019-07-17 15:59:59','IOTXETH','4h','0.000032180000000','0.000032550000000','0.076354603508870','0.077232515357791','2372.734726813859','2372.734726813859197','test'),('2019-07-19 03:59:59','2019-07-20 23:59:59','IOTXETH','4h','0.000034270000000','0.000033290000000','0.076354603508870','0.074171133668231','2228.0304496314557','2228.030449631455667','test'),('2019-08-16 23:59:59','2019-08-18 15:59:59','IOTXETH','4h','0.000026390000000','0.000025710000000','0.076354603508870','0.074387148776546','2893.3157828294807','2893.315782829480668','test'),('2019-08-25 11:59:59','2019-08-26 03:59:59','IOTXETH','4h','0.000026610000000','0.000025390000000','0.076354603508870','0.072853941491552','2869.395096161969','2869.395096161968922','test'),('2019-08-26 07:59:59','2019-08-26 11:59:59','IOTXETH','4h','0.000026670000000','0.000026260000000','0.076354603508870','0.075180798205584','2862.939764112111','2862.939764112110879','test'),('2019-08-26 15:59:59','2019-08-29 11:59:59','IOTXETH','4h','0.000026320000000','0.000025440000000','0.076354603508870','0.073801714029850','2901.0107716136017','2901.010771613601719','test'),('2019-08-30 23:59:59','2019-09-01 11:59:59','IOTXETH','4h','0.000026150000000','0.000026130000000','0.076354603508870','0.076296206106569','2919.8701150619504','2919.870115061950401','test'),('2019-09-01 15:59:59','2019-09-01 19:59:59','IOTXETH','4h','0.000026430000000','0.000026160000000','0.076354603508870','0.075574590533183','2888.936946987136','2888.936946987135798','test'),('2019-09-01 23:59:59','2019-09-02 03:59:59','IOTXETH','4h','0.000026350000000','0.000026180000000','0.076354603508870','0.075861993163651','2897.7079130500947','2897.707913050094703','test'),('2019-09-12 07:59:59','2019-09-12 15:59:59','IOTXETH','4h','0.000024950000000','0.000023880000000','0.076354603508870','0.073080077426526','3060.304749854509','3060.304749854508827','test'),('2019-09-12 23:59:59','2019-09-13 03:59:59','IOTXETH','4h','0.000023900000000','0.000023300000000','0.076354603508870','0.074437751537936','3194.7532848899577','3194.753284889957740','test'),('2019-09-13 15:59:59','2019-09-13 19:59:59','IOTXETH','4h','0.000025880000000','0.000024810000000','0.076354603508870','0.073197747799655','2950.3324385189335','2950.332438518933486','test'),('2019-09-14 07:59:59','2019-09-14 11:59:59','IOTXETH','4h','0.000024790000000','0.000024430000000','0.076354603508870','0.075245783127136','3080.0566159286','3080.056615928599967','test'),('2019-10-05 19:59:59','2019-10-05 23:59:59','IOTXETH','4h','0.000021140000000','0.000021040000000','0.076354603508870','0.075993418061808','3611.854470618259','3611.854470618258802','test'),('2019-10-06 03:59:59','2019-10-14 07:59:59','IOTXETH','4h','0.000021260000000','0.000032210000000','0.076354603508870','0.115681174930419','3591.46770973048','3591.467709730479783','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','IOTXETH','4h','0.000024110000000','0.000023960000000','0.077218442371584','0.076738029001375','3202.7558013929506','3202.755801392950616','test'),('2019-11-03 07:59:59','2019-11-04 15:59:59','IOTXETH','4h','0.000024210000000','0.000023790000000','0.077218442371584','0.075878841140850','3189.526739842379','3189.526739842378902','test'),('2019-11-06 07:59:59','2019-11-07 23:59:59','IOTXETH','4h','0.000027680000000','0.000027150000000','0.077218442371584','0.075739910057388','2789.6836116901736','2789.683611690173620','test'),('2019-11-08 07:59:59','2019-11-08 11:59:59','IOTXETH','4h','0.000026890000000','0.000026340000000','0.077218442371584','0.075639039496747','2871.641590613016','2871.641590613015978','test'),('2019-11-14 15:59:59','2019-11-17 11:59:59','IOTXETH','4h','0.000025210000000','0.000025240000000','0.077218442371584','0.077310332624307','3063.008424100912','3063.008424100912180','test'),('2019-11-22 23:59:59','2019-11-24 19:59:59','IOTXETH','4h','0.000026130000000','0.000025780000000','0.077218442371584','0.076184134877131','2955.1642698654423','2955.164269865442293','test'),('2019-11-24 23:59:59','2019-11-25 03:59:59','IOTXETH','4h','0.000026080000000','0.000025890000000','0.077218442371584','0.076655884700932','2960.829845536196','2960.829845536195990','test'),('2019-11-25 07:59:59','2019-11-25 15:59:59','IOTXETH','4h','0.000026690000000','0.000026660000000','0.077218442371584','0.077131647569368','2893.160073869764','2893.160073869763892','test'),('2019-11-25 19:59:59','2019-11-30 19:59:59','IOTXETH','4h','0.000026690000000','0.000028410000000','0.077218442371584','0.082194677698640','2893.160073869764','2893.160073869763892','test'),('2019-12-09 07:59:59','2019-12-09 19:59:59','IOTXETH','4h','0.000027340000000','0.000026920000000','0.077218442371584','0.076032204412694','2824.3760925963425','2824.376092596342460','test'),('2019-12-17 19:59:59','2019-12-17 23:59:59','IOTXETH','4h','0.000026250000000','0.000026330000000','0.077218442371584','0.077453774767383','2941.654947488914','2941.654947488913876','test'),('2019-12-18 07:59:59','2019-12-18 15:59:59','IOTXETH','4h','0.000026860000000','0.000026010000000','0.077218442371584','0.074774820777547','2874.8489341617274','2874.848934161727357','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','IOTXETH','4h','0.000026320000000','0.000026270000000','0.077218442371584','0.077071750801729','2933.8313970966565','2933.831397096656474','test'),('2019-12-19 03:59:59','2019-12-21 19:59:59','IOTXETH','4h','0.000026390000000','0.000027330000000','0.077218442371584','0.079968928761477','2926.0493509505113','2926.049350950511325','test'),('2019-12-24 03:59:59','2019-12-26 11:59:59','IOTXETH','4h','0.000027910000000','0.000027630000000','0.077218442371584','0.076443767922854','2766.694459748621','2766.694459748620829','test'),('2019-12-27 07:59:59','2019-12-27 11:59:59','IOTXETH','4h','0.000027920000000','0.000027820000000','0.077218442371584','0.076941872019250','2765.703523337536','2765.703523337535898','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  6:08:38
