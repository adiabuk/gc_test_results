-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 03:59:59','2019-01-12 07:59:59','ONTBNB','4h','0.106450000000000','0.103500000000000','0.711908500000000','0.692179706434946','6.6877266322217','6.687726632221700','test'),('2019-01-12 19:59:59','2019-01-13 03:59:59','ONTBNB','4h','0.104520000000000','0.104160000000000','0.711908500000000','0.709456461538462','6.811217948717949','6.811217948717949','test'),('2019-01-13 11:59:59','2019-01-13 15:59:59','ONTBNB','4h','0.102140000000000','0.100850000000000','0.711908500000000','0.702917292196985','6.969928529469357','6.969928529469357','test'),('2019-02-16 15:59:59','2019-02-18 03:59:59','ONTBNB','4h','0.070850000000000','0.068780000000000','0.711908500000000','0.691108915031757','10.048108680310516','10.048108680310516','test'),('2019-02-18 23:59:59','2019-02-19 15:59:59','ONTBNB','4h','0.070270000000000','0.066440000000000','0.711908500000000','0.673106599402305','10.13104454247901','10.131044542479010','test'),('2019-02-21 19:59:59','2019-02-27 07:59:59','ONTBNB','4h','0.069720000000000','0.092530000000000','0.711908500000000','0.944820618258749','10.21096528973035','10.210965289730350','test'),('2019-03-17 23:59:59','2019-03-18 11:59:59','ONTBNB','4h','0.071730000000000','0.069590000000000','0.747443148215801','0.725143854514674','10.420230701461048','10.420230701461048','test'),('2019-03-18 15:59:59','2019-03-19 11:59:59','ONTBNB','4h','0.070340000000000','0.069100000000000','0.747443148215801','0.734266726495761','10.626146548419122','10.626146548419122','test'),('2019-03-19 15:59:59','2019-03-23 23:59:59','ONTBNB','4h','0.071680000000000','0.083170000000000','0.747443148215801','0.867255114915014','10.42749927756419','10.427499277564189','test'),('2019-03-30 19:59:59','2019-03-31 03:59:59','ONTBNB','4h','0.078350000000000','0.074010000000000','0.768527211035312','0.725956590794173','9.808898673073546','9.808898673073546','test'),('2019-04-01 03:59:59','2019-04-01 07:59:59','ONTBNB','4h','0.078370000000000','0.076280000000000','0.768527211035312','0.748031844554978','9.806395445136047','9.806395445136047','test'),('2019-04-03 19:59:59','2019-04-07 11:59:59','ONTBNB','4h','0.085750000000000','0.081580000000000','0.768527211035312','0.731153934417035','8.962416455222296','8.962416455222296','test'),('2019-04-08 23:59:59','2019-04-09 11:59:59','ONTBNB','4h','0.083590000000000','0.079590000000000','0.768527211035312','0.731751175096309','9.194008984750711','9.194008984750711','test'),('2019-04-10 11:59:59','2019-04-11 03:59:59','ONTBNB','4h','0.082420000000000','0.078860000000000','0.768527211035312','0.735331908059266','9.324523307878088','9.324523307878088','test'),('2019-05-08 11:59:59','2019-05-08 19:59:59','ONTBNB','4h','0.051940000000000','0.049250000000000','0.768527211035312','0.728724781353275','14.796442260980207','14.796442260980207','test'),('2019-05-08 23:59:59','2019-05-13 07:59:59','ONTBNB','4h','0.050820000000000','0.052470000000000','0.768527211035312','0.793479393211783','15.122534652406769','15.122534652406769','test'),('2019-05-14 11:59:59','2019-05-15 15:59:59','ONTBNB','4h','0.056450000000000','0.056260000000000','0.768527211035312','0.765940494115973','13.61429957547054','13.614299575470540','test'),('2019-05-15 19:59:59','2019-05-16 11:59:59','ONTBNB','4h','0.058960000000000','0.055580000000000','0.768527211035312','0.724469850565513','13.034722032484938','13.034722032484938','test'),('2019-05-16 15:59:59','2019-05-16 23:59:59','ONTBNB','4h','0.058600000000000','0.054810000000000','0.768527211035312','0.718822123495656','13.11479882312819','13.114798823128190','test'),('2019-05-30 07:59:59','2019-06-01 07:59:59','ONTBNB','4h','0.046000000000000','0.045180000000000','0.768527211035312','0.754827378142943','16.707113283376348','16.707113283376348','test'),('2019-06-01 11:59:59','2019-06-01 15:59:59','ONTBNB','4h','0.045200000000000','0.044520000000000','0.768527211035312','0.756965297240975','17.002814403436105','17.002814403436105','test'),('2019-06-03 03:59:59','2019-06-03 07:59:59','ONTBNB','4h','0.045880000000000','0.045050000000000','0.768527211035312','0.754624037862703','16.750811051336356','16.750811051336356','test'),('2019-06-10 15:59:59','2019-06-11 07:59:59','ONTBNB','4h','0.045330000000000','0.044010000000000','0.768527211035312','0.746147861408870','16.954052747304477','16.954052747304477','test'),('2019-06-11 11:59:59','2019-06-12 03:59:59','ONTBNB','4h','0.044530000000000','0.042850000000000','0.768527211035312','0.739532696897892','17.258639367512057','17.258639367512057','test'),('2019-06-15 23:59:59','2019-06-17 07:59:59','ONTBNB','4h','0.044000000000000','0.043060000000000','0.768527211035312','0.752108675163194','17.46652752352982','17.466527523529820','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','ONTBNB','4h','0.044570000000000','0.044210000000000','0.768527211035312','0.762319676909830','17.243150348559837','17.243150348559837','test'),('2019-06-17 19:59:59','2019-06-18 03:59:59','ONTBNB','4h','0.044490000000000','0.043650000000000','0.768527211035312','0.754016919795266','17.274156238150415','17.274156238150415','test'),('2019-06-25 03:59:59','2019-06-27 11:59:59','ONTBNB','4h','0.043870000000000','0.046120000000000','0.768527211035312','0.807943354751506','17.518286096086438','17.518286096086438','test'),('2019-06-30 07:59:59','2019-07-01 11:59:59','ONTBNB','4h','0.046680000000000','0.043830000000000','0.768527211035312','0.721605562546652','16.463736311810454','16.463736311810454','test'),('2019-07-25 11:59:59','2019-07-27 23:59:59','ONTBNB','4h','0.035410000000000','0.035140000000000','0.768527211035312','0.762667218180764','21.703677239065577','21.703677239065577','test'),('2019-07-29 11:59:59','2019-07-31 03:59:59','ONTBNB','4h','0.036240000000000','0.035400000000000','0.768527211035312','0.750713666408666','21.206600746007503','21.206600746007503','test'),('2019-07-31 11:59:59','2019-08-01 03:59:59','ONTBNB','4h','0.036200000000000','0.035490000000000','0.768527211035312','0.753453887282962','21.23003345401414','21.230033454014141','test'),('2019-08-04 07:59:59','2019-08-04 11:59:59','ONTBNB','4h','0.035360000000000','0.035140000000000','0.768527211035312','0.763745650333169','21.73436682792172','21.734366827921718','test'),('2019-08-04 15:59:59','2019-08-04 19:59:59','ONTBNB','4h','0.035350000000000','0.035290000000000','0.768527211035312','0.767222780125492','21.74051516365805','21.740515163658049','test'),('2019-08-05 03:59:59','2019-08-05 07:59:59','ONTBNB','4h','0.035290000000000','0.035220000000000','0.768527211035312','0.767002787550685','21.777478351808217','21.777478351808217','test'),('2019-08-05 11:59:59','2019-08-06 03:59:59','ONTBNB','4h','0.035550000000000','0.035410000000000','0.768527211035312','0.765500662243612','21.618205655001745','21.618205655001745','test'),('2019-08-06 15:59:59','2019-08-06 19:59:59','ONTBNB','4h','0.035300000000000','0.035030000000000','0.768527211035312','0.762648957579801','21.77130909448476','21.771309094484760','test'),('2019-08-24 15:59:59','2019-08-26 11:59:59','ONTBNB','4h','0.031090000000000','0.030280000000000','0.768527211035312','0.748504469287528','24.719434256523382','24.719434256523382','test'),('2019-08-26 15:59:59','2019-08-27 11:59:59','ONTBNB','4h','0.031110000000000','0.030380000000000','0.768527211035312','0.750493624919729','24.703542624085888','24.703542624085888','test'),('2019-08-28 23:59:59','2019-09-02 15:59:59','ONTBNB','4h','0.031320000000000','0.032500000000000','0.768527211035312','0.797481939931278','24.537905844039333','24.537905844039333','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','ONTBNB','4h','0.032590000000000','0.032280000000000','0.768527211035312','0.761216887763727','23.581687972854002','23.581687972854002','test'),('2019-09-04 15:59:59','2019-09-05 15:59:59','ONTBNB','4h','0.032990000000000','0.032440000000000','0.768527211035312','0.755714541557609','23.295762686732708','23.295762686732708','test'),('2019-09-08 15:59:59','2019-09-18 11:59:59','ONTBNB','4h','0.034040000000000','0.036060000000000','0.768527211035312','0.814133114862907','22.57718011267074','22.577180112670739','test'),('2019-09-18 15:59:59','2019-09-22 11:59:59','ONTBNB','4h','0.037890000000000','0.037920000000000','0.768527211035312','0.769135704472395','20.283114569419688','20.283114569419688','test'),('2019-09-22 15:59:59','2019-09-24 07:59:59','ONTBNB','4h','0.038720000000000','0.038120000000000','0.768527211035312','0.756618214996542','19.848326731283883','19.848326731283883','test'),('2019-09-25 15:59:59','2019-09-25 19:59:59','ONTBNB','4h','0.039050000000000','0.038640000000000','0.768527211035312','0.760458167334301','19.680594392709654','19.680594392709654','test'),('2019-09-25 23:59:59','2019-09-26 03:59:59','ONTBNB','4h','0.038670000000000','0.038340000000000','0.768527211035312','0.761968794183963','19.87399045863232','19.873990458632321','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','ONTBNB','4h','0.038690000000000','0.038050000000000','0.768527211035312','0.755814432150262','19.863717007891236','19.863717007891236','test'),('2019-09-30 07:59:59','2019-09-30 19:59:59','ONTBNB','4h','0.038730000000000','0.038990000000000','0.768527211035312','0.773686443539035','19.843201937395094','19.843201937395094','test'),('2019-10-02 07:59:59','2019-10-08 11:59:59','ONTBNB','4h','0.038810000000000','0.039350000000000','0.768527211035312','0.779220452312278','19.802298661049008','19.802298661049008','test'),('2019-10-26 19:59:59','2019-10-29 23:59:59','ONTBNB','4h','0.036050000000000','0.041300000000000','0.768527211035312','0.880448649535600','21.318369238150126','21.318369238150126','test'),('2019-10-30 07:59:59','2019-10-31 15:59:59','ONTBNB','4h','0.045200000000000','0.042310000000000','0.768527211035312','0.719389077409382','17.002814403436105','17.002814403436105','test'),('2019-11-01 23:59:59','2019-11-04 07:59:59','ONTBNB','4h','0.043580000000000','0.043550000000000','0.768527211035312','0.767998165226889','17.63486028075521','17.634860280755209','test'),('2019-11-04 19:59:59','2019-11-05 03:59:59','ONTBNB','4h','0.044860000000000','0.043340000000000','0.768527211035312','0.742487055868712','17.13168103065787','17.131681030657870','test'),('2019-11-12 23:59:59','2019-11-13 07:59:59','ONTBNB','4h','0.043860000000000','0.043500000000000','0.768527211035312','0.762219190151301','17.522280233363244','17.522280233363244','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','ONTBNB','4h','0.043560000000000','0.043250000000000','0.768527211035312','0.763057894336025','17.64295709447456','17.642957094474561','test'),('2019-11-13 23:59:59','2019-11-14 03:59:59','ONTBNB','4h','0.043700000000000','0.041860000000000','0.768527211035312','0.736168170570667','17.586435035132997','17.586435035132997','test'),('2019-11-27 19:59:59','2019-11-28 03:59:59','ONTBNB','4h','0.040560000000000','0.039740000000000','0.768527211035312','0.752989925210634','18.94790954229073','18.947909542290731','test'),('2019-11-28 07:59:59','2019-11-28 11:59:59','ONTBNB','4h','0.039920000000000','0.040930000000000','0.768527211035312','0.787971411514913','19.251683643169137','19.251683643169137','test'),('2019-11-28 15:59:59','2019-11-30 23:59:59','ONTBNB','4h','0.041360000000000','0.040480000000000','0.768527211035312','0.752175568247327','18.581412259074273','18.581412259074273','test'),('2019-12-09 07:59:59','2019-12-09 15:59:59','ONTBNB','4h','0.040910000000000','0.039940000000000','0.768527211035312','0.750304981880967','18.785803251902028','18.785803251902028','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','ONTBNB','4h','0.040060000000000','0.039690000000000','0.768527211035312','0.761428981677272','19.184403670377232','19.184403670377232','test'),('2019-12-12 03:59:59','2019-12-12 15:59:59','ONTBNB','4h','0.040310000000000','0.040150000000000','0.768527211035312','0.765476743315995','19.065423245728404','19.065423245728404','test'),('2019-12-12 19:59:59','2019-12-12 23:59:59','ONTBNB','4h','0.040210000000000','0.040290000000000','0.768527211035312','0.770056238065474','19.112837877028397','19.112837877028397','test'),('2019-12-13 03:59:59','2019-12-18 15:59:59','ONTBNB','4h','0.040500000000000','0.041310000000000','0.768527211035312','0.783897755256018','18.97598051939042','18.975980519390419','test'),('2019-12-18 19:59:59','2019-12-18 23:59:59','ONTBNB','4h','0.041400000000000','0.040830000000000','0.768527211035312','0.757946039289174','18.563459203751496','18.563459203751496','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 13:05:38
