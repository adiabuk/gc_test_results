-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-09 15:59:59','2019-01-13 15:59:59','SNTETH','4h','0.000133570000000','0.000153750000000','0.072144500000000','0.083044223066557','540.1250280751665','540.125028075166483','test'),('2019-01-14 07:59:59','2019-01-14 11:59:59','SNTETH','4h','0.000158110000000','0.000155090000000','0.074869430766639','0.073439377759775','473.52748571652177','473.527485716521767','test'),('2019-01-16 07:59:59','2019-01-22 07:59:59','SNTETH','4h','0.000160310000000','0.000187520000000','0.074869430766639','0.087577291855531','467.0290734616618','467.029073461661824','test'),('2019-02-27 19:59:59','2019-02-28 03:59:59','SNTETH','4h','0.000152290000000','0.000149080000000','0.077688882787146','0.076051340507635','510.13778177914674','510.137781779146735','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','SNTETH','4h','0.000148320000000','0.000147810000000','0.077688882787146','0.077421748683711','523.7923596760114','523.792359676011415','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','SNTETH','4h','0.000149040000000','0.000147620000000','0.077688882787146','0.076948690801385','521.2619618031804','521.261961803180384','test'),('2019-03-01 19:59:59','2019-03-05 15:59:59','SNTETH','4h','0.000148470000000','0.000148290000000','0.077688882787146','0.077594695416622','523.2631695773288','523.263169577328767','test'),('2019-03-09 11:59:59','2019-03-15 19:59:59','SNTETH','4h','0.000157730000000','0.000166350000000','0.077688882787146','0.081934607567627','492.543478013986','492.543478013985975','test'),('2019-03-15 23:59:59','2019-03-16 03:59:59','SNTETH','4h','0.000169600000000','0.000165290000000','0.078065550047459','0.076081690845192','460.2921582986954','460.292158298695426','test'),('2019-03-20 15:59:59','2019-03-20 23:59:59','SNTETH','4h','0.000166830000000','0.000165070000000','0.078065550047459','0.077241984932770','467.93472425498413','467.934724254984133','test'),('2019-03-21 03:59:59','2019-03-21 15:59:59','SNTETH','4h','0.000165400000000','0.000158760000000','0.078065550047459','0.074931600517138','471.9803509519891','471.980350951989124','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','SNTETH','4h','0.000167850000000','0.000161710000000','0.078065550047459','0.075209890367439','465.09115309775996','465.091153097759957','test'),('2019-03-22 19:59:59','2019-03-25 15:59:59','SNTETH','4h','0.000164030000000','0.000165490000000','0.078065550047459','0.078760396740560','475.9223925346522','475.922392534652204','test'),('2019-03-28 15:59:59','2019-04-02 07:59:59','SNTETH','4h','0.000172520000000','0.000174590000000','0.078065550047459','0.079002228047681','452.5014493824426','452.501449382442615','test'),('2019-04-03 11:59:59','2019-04-04 07:59:59','SNTETH','4h','0.000182800000000','0.000176960000000','0.078065550047459','0.075571552168481','427.05443133183263','427.054431331832632','test'),('2019-04-04 15:59:59','2019-04-05 07:59:59','SNTETH','4h','0.000177250000000','0.000175120000000','0.078065550047459','0.077127442168186','440.42623440033293','440.426234400332930','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','SNTETH','4h','0.000177800000000','0.000173500000000','0.078065550047459','0.076177575552498','439.0638360374522','439.063836037452177','test'),('2019-05-28 03:59:59','2019-05-29 07:59:59','SNTETH','4h','0.000113110000000','0.000110410000000','0.078065550047459','0.076202080989656','690.1737251123596','690.173725112359648','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','SNTETH','4h','0.000112600000000','0.000106370000000','0.078065550047459','0.073746292704691','693.299733991643','693.299733991643052','test'),('2019-06-07 07:59:59','2019-06-12 15:59:59','SNTETH','4h','0.000123320000000','0.000119100000000','0.078065550047459','0.075394153508371','633.0323552340172','633.032355234017245','test'),('2019-07-16 11:59:59','2019-07-17 15:59:59','SNTETH','4h','0.000092300000000','0.000089410000000','0.078065550047459','0.075621244092560','845.7806072314086','845.780607231408567','test'),('2019-07-17 19:59:59','2019-07-18 03:59:59','SNTETH','4h','0.000091200000000','0.000091840000000','0.078065550047459','0.078613378468845','855.9819084151208','855.981908415120756','test'),('2019-07-18 11:59:59','2019-07-18 15:59:59','SNTETH','4h','0.000091040000000','0.000088530000000','0.078065550047459','0.075913259509024','857.4862702928274','857.486270292827385','test'),('2019-07-19 15:59:59','2019-07-25 15:59:59','SNTETH','4h','0.000091700000000','0.000095890000000','0.078065550047459','0.081632558277545','851.3146133855944','851.314613385594384','test'),('2019-07-28 03:59:59','2019-07-28 07:59:59','SNTETH','4h','0.000097700000000','0.000095990000000','0.078065550047459','0.076699203163312','799.033265582999','799.033265582998979','test'),('2019-07-30 23:59:59','2019-07-31 15:59:59','SNTETH','4h','0.000099810000000','0.000104050000000','0.078065550047459','0.081381830301955','782.1415694565576','782.141569456557590','test'),('2019-08-01 03:59:59','2019-08-02 07:59:59','SNTETH','4h','0.000102290000000','0.000096220000000','0.078065550047459','0.073433055289535','763.1787080600158','763.178708060015765','test'),('2019-08-10 11:59:59','2019-08-11 19:59:59','SNTETH','4h','0.000096410000000','0.000093240000000','0.078065550047459','0.075498723020694','809.7246141215539','809.724614121553941','test'),('2019-08-12 11:59:59','2019-08-13 15:59:59','SNTETH','4h','0.000095990000000','0.000093140000000','0.078065550047459','0.075747737591628','813.2675283619024','813.267528361902350','test'),('2019-08-14 19:59:59','2019-08-16 19:59:59','SNTETH','4h','0.000097600000000','0.000094390000000','0.078065550047459','0.075498025296923','799.8519472075718','799.851947207571811','test'),('2019-08-16 23:59:59','2019-08-17 07:59:59','SNTETH','4h','0.000094700000000','0.000095000000000','0.078065550047459','0.078312853796289','824.3458294346252','824.345829434625216','test'),('2019-08-17 11:59:59','2019-08-18 11:59:59','SNTETH','4h','0.000096350000000','0.000095420000000','0.078065550047459','0.077312037213581','810.228853632164','810.228853632164032','test'),('2019-08-22 19:59:59','2019-08-25 23:59:59','SNTETH','4h','0.000096230000000','0.000097400000000','0.078065550047459','0.079014699933727','811.2392190321002','811.239219032100209','test'),('2019-10-05 23:59:59','2019-10-06 07:59:59','SNTETH','4h','0.000073440000000','0.000073590000000','0.078065550047459','0.078224997657850','1062.9840692736793','1062.984069273679324','test'),('2019-10-06 15:59:59','2019-10-07 15:59:59','SNTETH','4h','0.000073790000000','0.000074480000000','0.078065550047459','0.078795530119728','1057.9421337235265','1057.942133723526467','test'),('2019-10-07 23:59:59','2019-10-08 03:59:59','SNTETH','4h','0.000074480000000','0.000073480000000','0.078065550047459','0.077017408935114','1048.1411123450457','1048.141112345045713','test'),('2019-10-08 07:59:59','2019-10-09 15:59:59','SNTETH','4h','0.000073510000000','0.000072260000000','0.078065550047459','0.076738085245945','1061.9718412115221','1061.971841211522133','test'),('2019-10-18 07:59:59','2019-10-19 07:59:59','SNTETH','4h','0.000071870000000','0.000071870000000','0.078065550047459','0.078065550047459','1086.204954048407','1086.204954048406989','test'),('2019-10-19 11:59:59','2019-10-20 15:59:59','SNTETH','4h','0.000071910000000','0.000071810000000','0.078065550047459','0.077956989972299','1085.6007515986512','1085.600751598651186','test'),('2019-10-23 03:59:59','2019-10-23 11:59:59','SNTETH','4h','0.000072370000000','0.000072350000000','0.078065550047459','0.078043976038879','1078.7004290100733','1078.700429010073321','test'),('2019-10-24 03:59:59','2019-10-25 11:59:59','SNTETH','4h','0.000071850000000','0.000070930000000','0.078065550047459','0.077065963324513','1086.5073075498817','1086.507307549881716','test'),('2019-11-01 03:59:59','2019-11-04 03:59:59','SNTETH','4h','0.000074640000000','0.000073700000000','0.078065550047459','0.077082409411813','1045.8942932403404','1045.894293240340403','test'),('2019-11-23 11:59:59','2019-11-23 15:59:59','SNTETH','4h','0.000069920000000','0.000069490000000','0.078065550047459','0.077585455846652','1116.498141411027','1116.498141411027063','test'),('2019-11-23 19:59:59','2019-11-24 03:59:59','SNTETH','4h','0.000069560000000','0.000069580000000','0.078065550047459','0.078087995576512','1122.276452666173','1122.276452666173100','test'),('2019-11-27 23:59:59','2019-12-01 23:59:59','SNTETH','4h','0.000070800000000','0.000072400000000','0.078065550047459','0.079829743268871','1102.6207633821894','1102.620763382189352','test'),('2019-12-03 23:59:59','2019-12-04 15:59:59','SNTETH','4h','0.000074410000000','0.000072750000000','0.078065550047459','0.076323999004874','1049.1271340876092','1049.127134087609193','test'),('2019-12-07 07:59:59','2019-12-08 11:59:59','SNTETH','4h','0.000073910000000','0.000073770000000','0.078065550047459','0.077917678622663','1056.2244628258559','1056.224462825855881','test'),('2019-12-16 19:59:59','2019-12-17 19:59:59','SNTETH','4h','0.000073560000000','0.000071690000000','0.078065550047459','0.076081012546253','1061.2500006451742','1061.250000645174168','test'),('2019-12-17 23:59:59','2019-12-18 11:59:59','SNTETH','4h','0.000072050000000','0.000072410000000','0.078065550047459','0.078455606924865','1083.4913261271201','1083.491326127120146','test'),('2019-12-19 11:59:59','2019-12-20 11:59:59','SNTETH','4h','0.000072930000000','0.000073550000000','0.078065550047459','0.078729208912527','1070.4175243035652','1070.417524303565187','test'),('2019-12-20 19:59:59','2019-12-22 07:59:59','SNTETH','4h','0.000073480000000','0.000072360000000','0.078065550047459','0.076875655980323','1062.4054170857241','1062.405417085724139','test'),('2019-12-25 03:59:59','2019-12-26 07:59:59','SNTETH','4h','0.000073740000000','0.000073030000000','0.078065550047459','0.077313901816734','1058.6594798950232','1058.659479895023196','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:44:31
