-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 07:59:59','2019-01-12 03:59:59','NXSETH','4h','0.002549000000000','0.002613000000000','0.072144500000000','0.073955895841506','28.30306002353864','28.303060023538642','test'),('2019-01-13 15:59:59','2019-01-13 23:59:59','NXSETH','4h','0.002692000000000','0.002573000000000','0.072597348960377','0.069388179374090','26.967811649471216','26.967811649471216','test'),('2019-01-15 03:59:59','2019-01-15 11:59:59','NXSETH','4h','0.002756000000000','0.002636000000000','0.072597348960377','0.069436361342363','26.341563483445935','26.341563483445935','test'),('2019-01-15 23:59:59','2019-01-25 19:59:59','NXSETH','4h','0.002715000000000','0.003173000000000','0.072597348960377','0.084843973573214','26.739355049862617','26.739355049862617','test'),('2019-01-25 23:59:59','2019-01-26 23:59:59','NXSETH','4h','0.003242000000000','0.003140000000000','0.074066465812511','0.071736182187318','22.845917894050125','22.845917894050125','test'),('2019-01-27 07:59:59','2019-01-27 15:59:59','NXSETH','4h','0.003218000000000','0.003117000000000','0.074066465812511','0.071741819122933','23.016303857212865','23.016303857212865','test'),('2019-01-27 19:59:59','2019-01-28 03:59:59','NXSETH','4h','0.003270000000000','0.003087000000000','0.074066465812511','0.069921461762453','22.650295355507954','22.650295355507954','test'),('2019-01-28 07:59:59','2019-01-28 19:59:59','NXSETH','4h','0.003212000000000','0.003141000000000','0.074066465812511','0.072429255640441','23.059298198166562','23.059298198166562','test'),('2019-01-29 03:59:59','2019-01-30 03:59:59','NXSETH','4h','0.003275000000000','0.003194000000000','0.074066465812511','0.072234592917606','22.615714751911757','22.615714751911757','test'),('2019-01-30 07:59:59','2019-01-30 15:59:59','NXSETH','4h','0.003236000000000','0.003141000000000','0.074066465812511','0.071892079455222','22.88827744515173','22.888277445151729','test'),('2019-03-02 19:59:59','2019-03-05 19:59:59','NXSETH','4h','0.002242000000000','0.002305000000000','0.074066465812511','0.076147726894665','33.03589019291302','33.035890192913023','test'),('2019-03-05 23:59:59','2019-03-07 23:59:59','NXSETH','4h','0.002339000000000','0.002347000000000','0.074066465812511','0.074319792758428','31.665868239637025','31.665868239637025','test'),('2019-03-08 03:59:59','2019-03-14 07:59:59','NXSETH','4h','0.002432000000000','0.002938000000000','0.074066465812511','0.089476676215936','30.454961271591692','30.454961271591692','test'),('2019-03-15 07:59:59','2019-03-16 07:59:59','NXSETH','4h','0.003104000000000','0.002894000000000','0.074891814473111','0.069825035787752','24.127517549327077','24.127517549327077','test'),('2019-03-17 15:59:59','2019-03-19 11:59:59','NXSETH','4h','0.003086000000000','0.002959000000000','0.074891814473111','0.071809746929986','24.268248371066427','24.268248371066427','test'),('2019-03-20 23:59:59','2019-03-21 23:59:59','NXSETH','4h','0.003046000000000','0.003029000000000','0.074891814473111','0.074473836519715','24.586938435033154','24.586938435033154','test'),('2019-03-24 19:59:59','2019-03-25 07:59:59','NXSETH','4h','0.003092000000000','0.002910000000000','0.074891814473111','0.070483564073982','24.221156039169145','24.221156039169145','test'),('2019-05-23 15:59:59','2019-05-24 15:59:59','NXSETH','4h','0.001648000000000','0.001536000000000','0.074891814473111','0.069802079508919','45.4440621802858','45.444062180285798','test'),('2019-05-24 19:59:59','2019-05-24 23:59:59','NXSETH','4h','0.001542000000000','0.001508000000000','0.074891814473111','0.073240503388749','48.56797306946238','48.567973069462383','test'),('2019-06-06 07:59:59','2019-06-07 03:59:59','NXSETH','4h','0.001450000000000','0.001481000000000','0.074891814473111','0.076492949817019','51.649527222835175','51.649527222835175','test'),('2019-06-07 15:59:59','2019-06-11 03:59:59','NXSETH','4h','0.001479000000000','0.001509000000000','0.074891814473111','0.076410918214959','50.63679139493644','50.636791394936438','test'),('2019-07-14 07:59:59','2019-07-15 07:59:59','NXSETH','4h','0.001066000000000','0.001050000000000','0.074891814473111','0.073767734706160','70.25498543443807','70.254985434438069','test'),('2019-07-15 15:59:59','2019-07-15 23:59:59','NXSETH','4h','0.001060000000000','0.001044000000000','0.074891814473111','0.073761371990498','70.65265516331226','70.652655163312261','test'),('2019-07-16 11:59:59','2019-07-17 11:59:59','NXSETH','4h','0.001074000000000','0.001053000000000','0.074891814473111','0.073427449385648','69.73167083157448','69.731670831574476','test'),('2019-07-19 19:59:59','2019-07-20 07:59:59','NXSETH','4h','0.001064000000000','0.001080000000000','0.074891814473111','0.076018007171955','70.38704367773589','70.387043677735889','test'),('2019-07-20 15:59:59','2019-07-22 23:59:59','NXSETH','4h','0.001084000000000','0.001069000000000','0.074891814473111','0.073855488627081','69.08838973534225','69.088389735342247','test'),('2019-07-23 03:59:59','2019-07-23 19:59:59','NXSETH','4h','0.001097000000000','0.001137000000000','0.074891814473111','0.077622600780244','68.26965767831449','68.269657678314488','test'),('2019-07-24 03:59:59','2019-07-27 11:59:59','NXSETH','4h','0.001146000000000','0.001107000000000','0.074891814473111','0.072343140158581','65.35062344948602','65.350623449486022','test'),('2019-07-27 15:59:59','2019-07-30 15:59:59','NXSETH','4h','0.001139000000000','0.001221000000000','0.074891814473111','0.080283499097163','65.75225151282791','65.752251512827911','test'),('2019-08-01 03:59:59','2019-08-02 15:59:59','NXSETH','4h','0.001301000000000','0.001275000000000','0.074891814473111','0.073395129479797','57.56480743513527','57.564807435135272','test'),('2019-08-03 23:59:59','2019-08-04 03:59:59','NXSETH','4h','0.001352000000000','0.001258000000000','0.074891814473111','0.069684839206489','55.39335390023003','55.393353900230032','test'),('2019-08-16 03:59:59','2019-08-19 07:59:59','NXSETH','4h','0.001169000000000','0.001136000000000','0.074891814473111','0.072777674286958','64.06485412584345','64.064854125843453','test'),('2019-08-22 23:59:59','2019-08-25 11:59:59','NXSETH','4h','0.001210000000000','0.001244000000000','0.074891814473111','0.076996212565744','61.89406154802562','61.894061548025618','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','NXSETH','4h','0.001225000000000','0.001217000000000','0.074891814473111','0.074402725072470','61.13617508009061','61.136175080090609','test'),('2019-08-26 07:59:59','2019-08-28 11:59:59','NXSETH','4h','0.001314000000000','0.001261000000000','0.074891814473111','0.071871063965444','56.99529259749695','56.995292597496949','test'),('2019-08-29 03:59:59','2019-09-01 23:59:59','NXSETH','4h','0.001319000000000','0.001321000000000','0.074891814473111','0.075005372948430','56.77923765967475','56.779237659674749','test'),('2019-09-04 07:59:59','2019-09-04 15:59:59','NXSETH','4h','0.001339000000000','0.001305000000000','0.074891814473111','0.072990155255721','55.93115345265945','55.931153452659451','test'),('2019-09-04 23:59:59','2019-09-05 11:59:59','NXSETH','4h','0.001330000000000','0.001267000000000','0.074891814473111','0.071344307471753','56.309634942188715','56.309634942188715','test'),('2019-10-02 07:59:59','2019-10-03 03:59:59','NXSETH','4h','0.001106000000000','0.001080000000000','0.074891814473111','0.073131247405931','67.71411796845479','67.714117968454786','test'),('2019-10-03 07:59:59','2019-10-06 11:59:59','NXSETH','4h','0.001110000000000','0.001110000000000','0.074891814473111','0.074891814473111','67.47010312892881','67.470103128928812','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','NXSETH','4h','0.001195000000000','0.001024000000000','0.074891814473111','0.064175077841394','62.670974454486185','62.670974454486185','test'),('2019-10-17 11:59:59','2019-10-21 11:59:59','NXSETH','4h','0.001166000000000','0.001380000000000','0.074891814473111','0.088636967386701','64.22968651210206','64.229686512102063','test'),('2019-10-22 07:59:59','2019-10-24 07:59:59','NXSETH','4h','0.001472000000000','0.001482000000000','0.074891814473111','0.075400590386651','50.87759135401562','50.877591354015621','test'),('2019-10-24 11:59:59','2019-10-25 19:59:59','NXSETH','4h','0.001548000000000','0.001517000000000','0.074891814473111','0.073392042994644','48.37972511182881','48.379725111828812','test'),('2019-10-25 23:59:59','2019-10-26 03:59:59','NXSETH','4h','0.001537000000000','0.001527000000000','0.074891814473111','0.074404554782330','48.725969078146385','48.725969078146385','test'),('2019-10-26 07:59:59','2019-11-04 11:59:59','NXSETH','4h','0.001558000000000','0.001852000000000','0.074891814473111','0.089024159437870','48.06920056040501','48.069200560405008','test'),('2019-12-02 07:59:59','2019-12-04 03:59:59','NXSETH','4h','0.001561000000000','0.001403000000000','0.074891814473111','0.067311477069683','47.976819009039716','47.976819009039716','test'),('2019-12-08 19:59:59','2019-12-09 15:59:59','NXSETH','4h','0.001459000000000','0.001378000000000','0.074891814473111','0.070734009831355','51.33092150316038','51.330921503160383','test'),('2019-12-09 19:59:59','2019-12-09 23:59:59','NXSETH','4h','0.001409000000000','0.001369000000000','0.074891814473111','0.072765716120432','53.15245881697018','53.152458816970181','test'),('2019-12-11 23:59:59','2019-12-12 11:59:59','NXSETH','4h','0.001459000000000','0.001388000000000','0.074891814473111','0.071247319046387','51.33092150316038','51.330921503160383','test'),('2019-12-16 19:59:59','2019-12-21 23:59:59','NXSETH','4h','0.001385000000000','0.001450000000000','0.074891814473111','0.078406592769683','54.07351225495379','54.073512254953791','test'),('2019-12-25 03:59:59','2019-12-25 19:59:59','NXSETH','4h','0.001456000000000','0.001432000000000','0.074891814473111','0.073657334014763','51.43668576449931','51.436685764499309','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','NXSETH','4h','0.001436000000000','0.001415000000000','0.074891814473111','0.073796599916053','52.15307414562047','52.153074145620472','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 14:30:45
