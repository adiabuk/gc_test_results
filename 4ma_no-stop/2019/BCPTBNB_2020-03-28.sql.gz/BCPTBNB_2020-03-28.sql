-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-19 03:59:59','2019-01-20 07:59:59','BCPTBNB','4h','0.006040000000000','0.005200000000000','0.711908500000000','0.612901357615894','117.86564569536424','117.865645695364236','test'),('2019-01-23 03:59:59','2019-01-23 15:59:59','BCPTBNB','4h','0.005390000000000','0.005110000000000','0.711908500000000','0.674926240259740','132.07949907235624','132.079499072356242','test'),('2019-02-27 11:59:59','2019-02-27 15:59:59','BCPTBNB','4h','0.003460000000000','0.003370000000000','0.711908500000000','0.693390648843931','205.75390173410406','205.753901734104062','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','BCPTBNB','4h','0.003340000000000','0.003250000000000','0.711908500000000','0.692725336826347','213.14625748502996','213.146257485029963','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','BCPTBNB','4h','0.003340000000000','0.003200000000000','0.711908500000000','0.682068023952096','213.14625748502996','213.146257485029963','test'),('2019-03-06 23:59:59','2019-03-07 03:59:59','BCPTBNB','4h','0.003740000000000','0.003310000000000','0.711908500000000','0.630058057486631','190.34986631016045','190.349866310160451','test'),('2019-03-07 07:59:59','2019-03-08 07:59:59','BCPTBNB','4h','0.003330000000000','0.003300000000000','0.711908500000000','0.705494909909910','213.78633633633635','213.786336336336348','test'),('2019-03-08 11:59:59','2019-03-08 23:59:59','BCPTBNB','4h','0.003480000000000','0.003340000000000','0.711908500000000','0.683268502873563','204.57140804597702','204.571408045977023','test'),('2019-03-29 07:59:59','2019-03-30 11:59:59','BCPTBNB','4h','0.002940000000000','0.002940000000000','0.711908500000000','0.711908500000000','242.14574829931976','242.145748299319763','test'),('2019-03-31 15:59:59','2019-04-01 07:59:59','BCPTBNB','4h','0.003380000000000','0.002960000000000','0.711908500000000','0.623446497041420','210.62381656804735','210.623816568047346','test'),('2019-04-03 07:59:59','2019-04-03 19:59:59','BCPTBNB','4h','0.003200000000000','0.003170000000000','0.711908500000000','0.705234357812500','222.47140625','222.471406250000001','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','BCPTBNB','4h','0.002990000000000','0.002870000000000','0.711908500000000','0.683336921404682','238.09648829431438','238.096488294314383','test'),('2019-04-05 23:59:59','2019-04-06 11:59:59','BCPTBNB','4h','0.003040000000000','0.002940000000000','0.711908500000000','0.688490457236842','234.18042763157897','234.180427631578965','test'),('2019-04-06 15:59:59','2019-04-06 19:59:59','BCPTBNB','4h','0.002970000000000','0.003060000000000','0.711908500000000','0.733481484848485','239.69983164983168','239.699831649831680','test'),('2019-04-07 03:59:59','2019-04-11 11:59:59','BCPTBNB','4h','0.003220000000000','0.003150000000000','0.711908500000000','0.696432228260870','221.08959627329193','221.089596273291932','test'),('2019-05-25 23:59:59','2019-05-30 03:59:59','BCPTBNB','4h','0.002080000000000','0.002180000000000','0.711908500000000','0.746134870192308','342.263701923077','342.263701923077008','test'),('2019-05-30 11:59:59','2019-05-31 23:59:59','BCPTBNB','4h','0.002490000000000','0.002280000000000','0.711908500000000','0.651868024096386','285.90702811244984','285.907028112449836','test'),('2019-06-02 19:59:59','2019-06-03 19:59:59','BCPTBNB','4h','0.002360000000000','0.002220000000000','0.711908500000000','0.669676639830509','301.6561440677966','301.656144067796617','test'),('2019-06-27 03:59:59','2019-06-27 11:59:59','BCPTBNB','4h','0.001690000000000','0.001690000000000','0.711908500000000','0.711908500000000','421.2476331360947','421.247633136094692','test'),('2019-06-27 19:59:59','2019-06-27 23:59:59','BCPTBNB','4h','0.001610000000000','0.001570000000000','0.711908500000000','0.694221332298137','442.17919254658386','442.179192546583863','test'),('2019-06-29 15:59:59','2019-06-29 23:59:59','BCPTBNB','4h','0.001710000000000','0.001640000000000','0.711908500000000','0.682766046783626','416.3207602339182','416.320760233918179','test'),('2019-06-30 03:59:59','2019-06-30 19:59:59','BCPTBNB','4h','0.001660000000000','0.001650000000000','0.711908500000000','0.707619894578313','428.8605421686747','428.860542168674726','test'),('2019-07-01 03:59:59','2019-07-02 07:59:59','BCPTBNB','4h','0.001700000000000','0.001670000000000','0.711908500000000','0.699345408823529','418.769705882353','418.769705882352980','test'),('2019-07-02 11:59:59','2019-07-02 19:59:59','BCPTBNB','4h','0.001730000000000','0.001690000000000','0.711908500000000','0.695448187861272','411.5078034682081','411.507803468208124','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','BCPTBNB','4h','0.001710000000000','0.001680000000000','0.711908500000000','0.699418877192983','416.3207602339182','416.320760233918179','test'),('2019-07-03 19:59:59','2019-07-04 11:59:59','BCPTBNB','4h','0.001800000000000','0.001620000000000','0.711908500000000','0.640717650000000','395.50472222222226','395.504722222222256','test'),('2019-07-10 03:59:59','2019-07-10 11:59:59','BCPTBNB','4h','0.001730000000000','0.001640000000000','0.711908500000000','0.674872797687861','411.5078034682081','411.507803468208124','test'),('2019-07-28 11:59:59','2019-07-31 03:59:59','BCPTBNB','4h','0.001489000000000','0.001510000000000','0.474605666666667','0.481299232146855','318.7412133422879','318.741213342287892','test'),('2019-08-22 19:59:59','2019-08-26 03:59:59','BCPTBNB','4h','0.001199000000000','0.001240000000000','0.530989954799505','0.549147242661707','442.8606795658927','442.860679565892724','test'),('2019-08-26 07:59:59','2019-08-28 19:59:59','BCPTBNB','4h','0.001285000000000','0.001234000000000','0.535529276765056','0.514274807414848','416.75430098447936','416.754300984479357','test'),('2019-08-29 19:59:59','2019-08-30 23:59:59','BCPTBNB','4h','0.001361000000000','0.001302000000000','0.535529276765056','0.512313826853860','393.4822018846848','393.482201884684798','test'),('2019-08-31 15:59:59','2019-09-02 15:59:59','BCPTBNB','4h','0.001362000000000','0.001310000000000','0.535529276765056','0.515083225082396','393.1933015896153','393.193301589615317','test'),('2019-09-10 11:59:59','2019-09-13 23:59:59','BCPTBNB','4h','0.001430000000000','0.001705000000000','0.535529276765056','0.638515676142951','374.4959977378014','374.495997737801417','test'),('2019-09-21 11:59:59','2019-09-22 07:59:59','BCPTBNB','4h','0.001655000000000','0.001628000000000','0.545046883873514','0.536154880329958','329.3334645761412','329.333464576141182','test'),('2019-09-22 11:59:59','2019-09-24 03:59:59','BCPTBNB','4h','0.001660000000000','0.001664000000000','0.545046883873514','0.546360249858751','328.34149630934576','328.341496309345757','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','BCPTBNB','4h','0.001685000000000','0.001698000000000','0.545046883873514','0.549251993363339','323.4699607557946','323.469960755794602','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','BCPTBNB','4h','0.001790000000000','0.001697000000000','0.545046883873514','0.516728805549359','304.4954658511251','304.495465851125118','test'),('2019-09-26 19:59:59','2019-09-29 15:59:59','BCPTBNB','4h','0.001740000000000','0.001771000000000','0.545046883873514','0.554757489275858','313.2453355594908','313.245335559490798','test'),('2019-10-01 19:59:59','2019-10-09 07:59:59','BCPTBNB','4h','0.001833000000000','0.001978000000000','0.545046883873514','0.588162976705843','297.35236436089144','297.352364360891443','test'),('2019-10-23 15:59:59','2019-10-23 19:59:59','BCPTBNB','4h','0.001712000000000','0.001673000000000','0.550330656834020','0.537793918740254','321.4548229170676','321.454822917067588','test'),('2019-10-23 23:59:59','2019-10-24 07:59:59','BCPTBNB','4h','0.001688000000000','0.001662000000000','0.550330656834020','0.541853999797477','326.0252706362678','326.025270636267805','test'),('2019-10-24 11:59:59','2019-10-24 19:59:59','BCPTBNB','4h','0.001704000000000','0.001704000000000','0.550330656834020','0.550330656834020','322.9640004894484','322.964000489448381','test'),('2019-11-18 07:59:59','2019-11-18 19:59:59','BCPTBNB','4h','0.001476000000000','0.001437000000000','0.550330656834020','0.535789399641251','372.8527485325339','372.852748532533894','test'),('2019-11-18 23:59:59','2019-11-19 03:59:59','BCPTBNB','4h','0.001445000000000','0.001468000000000','0.550330656834020','0.559090245143489','380.8516656290796','380.851665629079605','test'),('2019-11-19 07:59:59','2019-11-21 11:59:59','BCPTBNB','4h','0.001491000000000','0.001466000000000','0.550330656834020','0.541103113962893','369.1017148450839','369.101714845083904','test'),('2019-11-23 19:59:59','2019-11-23 23:59:59','BCPTBNB','4h','0.001486000000000','0.001450000000000','0.550330656834020','0.536998285605201','370.3436452449664','370.343645244966410','test'),('2019-11-25 07:59:59','2019-11-30 07:59:59','BCPTBNB','4h','0.001597000000000','0.001624000000000','0.550330656834020','0.559634932184376','344.6027907539262','344.602790753926172','test'),('2019-12-07 07:59:59','2019-12-10 07:59:59','BCPTBNB','4h','0.001654000000000','0.001638000000000','0.550330656834020','0.545007022910595','332.7271202140387','332.727120214038678','test'),('2019-12-20 19:59:59','2019-12-21 03:59:59','BCPTBNB','4h','0.001641000000000','0.001609000000000','0.550330656834020','0.539599041344265','335.3629840548568','335.362984054856781','test'),('2019-12-21 11:59:59','2019-12-21 15:59:59','BCPTBNB','4h','0.001602000000000','0.001594000000000','0.550330656834020','0.547582438822364','343.52725145694137','343.527251456941372','test'),('2019-12-21 23:59:59','2019-12-22 19:59:59','BCPTBNB','4h','0.001718000000000','0.001584000000000','0.550330656834020','0.507406146929620','320.33216346566945','320.332163465669453','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','BCPTBNB','4h','0.001616000000000','0.001561000000000','0.550330656834020','0.531600343637318','340.551149030953','340.551149030953013','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 15:49:54
