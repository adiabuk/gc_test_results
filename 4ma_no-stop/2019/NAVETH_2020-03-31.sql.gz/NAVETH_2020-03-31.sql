-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-14 19:59:59','NAVETH','4h','0.001234000000000','0.001230000000000','0.072144500000000','0.071910644246353','58.46393841166937','58.463938411669368','test'),('2019-01-15 15:59:59','2019-01-20 11:59:59','NAVETH','4h','0.001294000000000','0.001336000000000','0.072144500000000','0.074486129829985','55.753091190108194','55.753091190108194','test'),('2019-01-22 03:59:59','2019-01-24 07:59:59','NAVETH','4h','0.001536000000000','0.001413000000000','0.072671443519084','0.066852050581032','47.31213770773731','47.312137707737307','test'),('2019-01-25 11:59:59','2019-01-27 03:59:59','NAVETH','4h','0.001470000000000','0.001430000000000','0.072671443519084','0.070693989273667','49.436356135431296','49.436356135431296','test'),('2019-02-06 23:59:59','2019-02-07 03:59:59','NAVETH','4h','0.001368000000000','0.001364000000000','0.072671443519084','0.072458953918151','53.122400233248534','53.122400233248534','test'),('2019-02-07 07:59:59','2019-02-07 11:59:59','NAVETH','4h','0.001371000000000','0.001349000000000','0.072671443519084','0.071505308028625','53.006158657245805','53.006158657245805','test'),('2019-02-07 23:59:59','2019-02-08 03:59:59','NAVETH','4h','0.001378000000000','0.001379000000000','0.072671443519084','0.072724180415687','52.736896603108846','52.736896603108846','test'),('2019-02-27 23:59:59','2019-02-28 11:59:59','NAVETH','4h','0.001157000000000','0.001132000000000','0.072671443519084','0.071101187608991','62.810236403702675','62.810236403702675','test'),('2019-02-28 15:59:59','2019-03-06 03:59:59','NAVETH','4h','0.001148000000000','0.001195000000000','0.072671443519084','0.075646668123088','63.30265114902788','63.302651149027881','test'),('2019-03-08 11:59:59','2019-03-14 11:59:59','NAVETH','4h','0.001211000000000','0.001360000000000','0.072671443519084','0.081612851516065','60.00944964416515','60.009449644165151','test'),('2019-03-15 03:59:59','2019-03-15 15:59:59','NAVETH','4h','0.001394000000000','0.001363000000000','0.072977353847243','0.071354471516350','52.3510429320251','52.351042932025102','test'),('2019-03-17 19:59:59','2019-03-19 11:59:59','NAVETH','4h','0.001468000000000','0.001382000000000','0.072977353847243','0.068702113771723','49.7120939013917','49.712093901391697','test'),('2019-03-20 15:59:59','2019-03-21 15:59:59','NAVETH','4h','0.001406000000000','0.001399000000000','0.072977353847243','0.072614024205045','51.9042345997461','51.904234599746097','test'),('2019-03-21 23:59:59','2019-03-22 07:59:59','NAVETH','4h','0.001400000000000','0.001382000000000','0.072977353847243','0.072039073583493','52.126681319459294','52.126681319459294','test'),('2019-03-22 11:59:59','2019-03-25 07:59:59','NAVETH','4h','0.001414000000000','0.001398000000000','0.072977353847243','0.072151584638222','51.61057556382109','51.610575563821087','test'),('2019-03-25 19:59:59','2019-03-29 19:59:59','NAVETH','4h','0.001445000000000','0.001504000000000','0.072977353847243','0.075957052032009','50.50335906383599','50.503359063835987','test'),('2019-03-30 23:59:59','2019-04-02 19:59:59','NAVETH','4h','0.001570000000000','0.001544000000000','0.072977353847243','0.071768811681620','46.4823909855051','46.482390985505099','test'),('2019-04-06 11:59:59','2019-04-06 19:59:59','NAVETH','4h','0.001569000000000','0.001495000000000','0.072977353847243','0.069535464628189','46.51201647370491','46.512016473704911','test'),('2019-05-04 11:59:59','2019-05-06 15:59:59','NAVETH','4h','0.001284000000000','0.001211000000000','0.072977353847243','0.068828329835679','56.83594536389642','56.835945363896421','test'),('2019-06-02 03:59:59','2019-06-03 23:59:59','NAVETH','4h','0.000918000000000','0.000861000000000','0.072977353847243','0.068446080242349','79.49602815603814','79.496028156038136','test'),('2019-06-06 03:59:59','2019-06-06 15:59:59','NAVETH','4h','0.000882000000000','0.000875000000000','0.072977353847243','0.072398168499249','82.74076399914173','82.740763999141734','test'),('2019-06-07 11:59:59','2019-06-12 15:59:59','NAVETH','4h','0.000895000000000','0.000903000000000','0.072977353847243','0.073629665390012','81.53894284608158','81.538942846081582','test'),('2019-06-13 15:59:59','2019-06-14 15:59:59','NAVETH','4h','0.000968000000000','0.000874000000000','0.072977353847243','0.065890709981912','75.38982835458988','75.389828354589881','test'),('2019-07-23 03:59:59','2019-07-23 11:59:59','NAVETH','4h','0.000630000000000','0.000609000000000','0.072977353847243','0.070544775385668','115.83706959879842','115.837069598798422','test'),('2019-07-23 15:59:59','2019-07-23 19:59:59','NAVETH','4h','0.000624000000000','0.000617000000000','0.072977353847243','0.072158697634213','116.95088757570994','116.950887575709942','test'),('2019-07-23 23:59:59','2019-07-25 23:59:59','NAVETH','4h','0.000632000000000','0.000626000000000','0.072977353847243','0.072284530867681','115.47049659373894','115.470496593738943','test'),('2019-07-27 03:59:59','2019-07-28 03:59:59','NAVETH','4h','0.000678000000000','0.000636000000000','0.072977353847243','0.068456632812458','107.63621511392773','107.636215113927733','test'),('2019-07-28 15:59:59','2019-07-30 03:59:59','NAVETH','4h','0.000639000000000','0.000632000000000','0.072977353847243','0.072177914916209','114.20556157628013','114.205561576280132','test'),('2019-08-01 19:59:59','2019-08-01 23:59:59','NAVETH','4h','0.000742000000000','0.000751000000000','0.072977353847243','0.073862523907385','98.35222890464017','98.352228904640171','test'),('2019-08-14 11:59:59','2019-08-15 01:59:59','NAVETH','4h','0.000633000000000','0.000584000000000','0.072977353847243','0.067328237988610','115.28807874761928','115.288078747619281','test'),('2019-08-15 11:59:59','2019-08-16 11:59:59','NAVETH','4h','0.000604000000000','0.000562000000000','0.072977353847243','0.067902769639322','120.8234335219255','120.823433521925494','test'),('2019-08-23 07:59:59','2019-08-25 15:59:59','NAVETH','4h','0.000596000000000','0.000567000000000','0.072977353847243','0.069426442334542','122.4452245759111','122.445224575911098','test'),('2019-08-25 19:59:59','2019-08-25 23:59:59','NAVETH','4h','0.000574000000000','0.000566000000000','0.072977353847243','0.071960247870278','127.13824712063243','127.138247120632428','test'),('2019-08-26 23:59:59','2019-08-31 03:59:59','NAVETH','4h','0.000650000000000','0.000609000000000','0.072977353847243','0.068374166912263','112.27285207268156','112.272852072681559','test'),('2019-08-31 07:59:59','2019-09-01 19:59:59','NAVETH','4h','0.000645000000000','0.000612000000000','0.072977353847243','0.069243628766686','113.14318425929149','113.143184259291488','test'),('2019-09-04 23:59:59','2019-09-05 19:59:59','NAVETH','4h','0.000647000000000','0.000625000000000','0.072977353847243','0.070495898229562','112.79343716729986','112.793437167299857','test'),('2019-09-09 23:59:59','2019-09-10 11:59:59','NAVETH','4h','0.000640000000000','0.000606000000000','0.072977353847243','0.069100431924108','114.02711538631719','114.027115386317192','test'),('2019-09-10 15:59:59','2019-09-11 19:59:59','NAVETH','4h','0.000634000000000','0.000616000000000','0.072977353847243','0.070905441592905','115.1062363521183','115.106236352118302','test'),('2019-09-26 03:59:59','2019-09-26 15:59:59','NAVETH','4h','0.000564000000000','0.000541000000000','0.072977353847243','0.070001327005955','129.39247136035993','129.392471360359934','test'),('2019-09-26 19:59:59','2019-09-27 03:59:59','NAVETH','4h','0.000553000000000','0.000541000000000','0.072977353847243','0.071393758465386','131.96628182141592','131.966281821415919','test'),('2019-10-03 07:59:59','2019-10-05 15:59:59','NAVETH','4h','0.000573000000000','0.000543000000000','0.072977353847243','0.069156549980895','127.36012887826004','127.360128878260042','test'),('2019-10-06 15:59:59','2019-10-08 03:59:59','NAVETH','4h','0.000585000000000','0.000555000000000','0.048651569231495','0.046156616963213','83.16507560939374','83.165075609393739','test'),('2019-10-08 07:59:59','2019-10-08 15:59:59','NAVETH','4h','0.000557000000000','0.000561000000000','0.053801505024034','0.054187871307869','96.59157095876785','96.591570958767846','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','NAVETH','4h','0.000580000000000','0.000504000000000','0.053898096594992','0.046835587385993','92.92775274998696','92.927752749986965','test'),('2019-10-23 03:59:59','2019-10-23 07:59:59','NAVETH','4h','0.000491000000000','0.000501000000000','0.053898096594992','0.054995817503240','109.77209082483095','109.772090824830954','test'),('2019-10-23 11:59:59','2019-10-23 15:59:59','NAVETH','4h','0.000504000000000','0.000487000000000','0.053898096594992','0.052080105241589','106.94066784720634','106.940667847206342','test'),('2019-10-24 15:59:59','2019-10-24 19:59:59','NAVETH','4h','0.000507000000000','0.000484000000000','0.053898096594992','0.051453015289894','106.30788283035898','106.307882830358977','test'),('2019-10-27 03:59:59','2019-10-27 15:59:59','NAVETH','4h','0.000581000000000','0.000506000000000','0.053898096594992','0.046940510976017','92.76780825299828','92.767808252998279','test'),('2019-10-27 19:59:59','2019-10-28 03:59:59','NAVETH','4h','0.000519000000000','0.000512000000000','0.053898096594992','0.053171147315291','103.84989710017726','103.849897100177259','test'),('2019-10-28 07:59:59','2019-10-29 23:59:59','NAVETH','4h','0.000515000000000','0.000502000000000','0.053898096594992','0.052537562117837','104.6564982427029','104.656498242702895','test'),('2019-10-30 19:59:59','2019-10-31 11:59:59','NAVETH','4h','0.000557000000000','0.000516000000000','0.053898096594992','0.049930732213673','96.76498491021903','96.764984910219027','test'),('2019-11-01 15:59:59','2019-11-02 15:59:59','NAVETH','4h','0.000526000000000','0.000527000000000','0.053898096594992','0.054000564459241','102.46786424903422','102.467864249034221','test'),('2019-11-02 19:59:59','2019-11-04 19:59:59','NAVETH','4h','0.000531000000000','0.000524000000000','0.053898096594992','0.053187575547600','101.50300677022976','101.503006770229760','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  3:32:05
