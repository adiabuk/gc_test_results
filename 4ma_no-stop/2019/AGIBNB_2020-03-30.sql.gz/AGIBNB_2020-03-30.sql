-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-07 11:59:59','AGIBNB','4h','0.008060000000000','0.008750000000000','0.711908500000000','0.772853520471464','88.32611662531019','88.326116625310192','test'),('2019-01-15 07:59:59','2019-01-15 15:59:59','AGIBNB','4h','0.009010000000000','0.007850000000000','0.727144755117866','0.633527894303579','80.70419035714384','80.704190357143844','test'),('2019-01-15 19:59:59','2019-01-15 23:59:59','AGIBNB','4h','0.007920000000000','0.007890000000000','0.727144755117866','0.724390418924238','91.81120645427602','91.811206454276018','test'),('2019-01-29 19:59:59','2019-01-30 03:59:59','AGIBNB','4h','0.007480000000000','0.007380000000000','0.727144755117866','0.717423568552119','97.21186565746872','97.211865657468721','test'),('2019-01-30 07:59:59','2019-01-30 11:59:59','AGIBNB','4h','0.007470000000000','0.007490000000000','0.727144755117866','0.729091595158342','97.3420020238107','97.342002023810707','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','AGIBNB','4h','0.007440000000000','0.007450000000000','0.727144755117866','0.728122100218831','97.73451009648737','97.734510096487369','test'),('2019-02-26 15:59:59','2019-02-27 23:59:59','AGIBNB','4h','0.004880000000000','0.004710000000000','0.727144755117866','0.701813892746957','149.0050727700545','149.005072770054511','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','AGIBNB','4h','0.004850000000000','0.004570000000000','0.727144755117866','0.685165264100752','149.9267536325497','149.926753632549691','test'),('2019-03-15 03:59:59','2019-03-16 11:59:59','AGIBNB','4h','0.003940000000000','0.003390000000000','0.727144755117866','0.625639776611565','184.5545063750929','184.554506375092899','test'),('2019-03-16 23:59:59','2019-03-18 03:59:59','AGIBNB','4h','0.003590000000000','0.003520000000000','0.727144755117866','0.712966445129495','202.5472855481521','202.547285548152104','test'),('2019-03-20 11:59:59','2019-03-21 07:59:59','AGIBNB','4h','0.003650000000000','0.003620000000000','0.727144755117866','0.721168222884020','199.21774112818247','199.217741128182467','test'),('2019-03-21 23:59:59','2019-03-22 03:59:59','AGIBNB','4h','0.003530000000000','0.003510000000000','0.727144755117866','0.723024954805583','205.99001561412635','205.990015614126349','test'),('2019-03-22 07:59:59','2019-03-22 11:59:59','AGIBNB','4h','0.003570000000000','0.003480000000000','0.727144755117866','0.708813374736743','203.68200423469636','203.682004234696365','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','AGIBNB','4h','0.003600000000000','0.003490000000000','0.727144755117866','0.704926443155931','201.98465419940723','201.984654199407231','test'),('2019-05-07 11:59:59','2019-05-10 03:59:59','AGIBNB','4h','0.001860000000000','0.001990000000000','0.727144755117866','0.777966700368039','390.9380403859495','390.938040385949478','test'),('2019-05-10 11:59:59','2019-05-11 19:59:59','AGIBNB','4h','0.001930000000000','0.001960000000000','0.727144755117866','0.738447523332133','376.75894047557824','376.758940475578243','test'),('2019-05-12 03:59:59','2019-05-12 11:59:59','AGIBNB','4h','0.002000000000000','0.001860000000000','0.727144755117866','0.676244622259615','363.572377558933','363.572377558932999','test'),('2019-06-01 11:59:59','2019-06-01 19:59:59','AGIBNB','4h','0.001610000000000','0.001500000000000','0.727144755117866','0.677464057563229','451.6427050421528','451.642705042152784','test'),('2019-06-01 23:59:59','2019-06-02 23:59:59','AGIBNB','4h','0.001520000000000','0.001590000000000','0.727144755117866','0.760631684629873','478.38470731438554','478.384707314385537','test'),('2019-06-03 03:59:59','2019-06-04 15:59:59','AGIBNB','4h','0.001630000000000','0.001580000000000','0.727144755117866','0.704839701279895','446.10107675942703','446.101076759427031','test'),('2019-06-04 23:59:59','2019-06-06 03:59:59','AGIBNB','4h','0.001570000000000','0.001550000000000','0.727144755117866','0.717881764606810','463.1495255527809','463.149525552780915','test'),('2019-06-07 19:59:59','2019-06-09 15:59:59','AGIBNB','4h','0.001620000000000','0.001560000000000','0.727144755117866','0.700213467891278','448.85478710979385','448.854787109793847','test'),('2019-07-22 03:59:59','2019-07-22 11:59:59','AGIBNB','4h','0.000952000000000','0.000871000000000','0.727144755117866','0.665276346331577','763.8075158801113','763.807515880111282','test'),('2019-07-22 15:59:59','2019-07-25 19:59:59','AGIBNB','4h','0.000945000000000','0.001113000000000','0.727144755117866','0.856414933805487','769.4653493310751','769.465349331075117','test'),('2019-08-03 15:59:59','2019-08-06 23:59:59','AGIBNB','4h','0.001110000000000','0.001100000000000','0.727144755117866','0.720593901468155','655.0853649710505','655.085364971050467','test'),('2019-08-07 03:59:59','2019-08-07 15:59:59','AGIBNB','4h','0.001121000000000','0.001088000000000','0.727144755117866','0.705739066519392','648.6572302567939','648.657230256793923','test'),('2019-08-12 15:59:59','2019-08-14 19:59:59','AGIBNB','4h','0.001147000000000','0.001119000000000','0.727144755117866','0.709394054905747','633.9535790042423','633.953579004242329','test'),('2019-08-15 01:59:59','2019-08-15 11:59:59','AGIBNB','4h','0.001145000000000','0.001083000000000','0.727144755117866','0.687770977984846','635.0609215003196','635.060921500319637','test'),('2019-08-16 03:59:59','2019-08-19 07:59:59','AGIBNB','4h','0.001165000000000','0.001214000000000','0.727144755117866','0.757728525933982','624.1585880840051','624.158588084005146','test'),('2019-08-21 15:59:59','2019-08-23 15:59:59','AGIBNB','4h','0.001267000000000','0.001213000000000','0.727144755117866','0.696153581655858','573.910619666824','573.910619666824005','test'),('2019-08-24 07:59:59','2019-08-28 19:59:59','AGIBNB','4h','0.001284000000000','0.001328000000000','0.727144755117866','0.752062488159288','566.3121145777773','566.312114577777265','test'),('2019-08-29 11:59:59','2019-08-29 19:59:59','AGIBNB','4h','0.001449000000000','0.001360000000000','0.727144755117866','0.682482309841475','501.8252278246142','501.825227824614217','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','AGIBNB','4h','0.001423000000000','0.001372000000000','0.727144755117866','0.701084050612588','510.994205985851','510.994205985851011','test'),('2019-09-05 11:59:59','2019-09-05 19:59:59','AGIBNB','4h','0.001440000000000','0.001292000000000','0.727144755117866','0.652410433064085','504.96163549851804','504.961635498518035','test'),('2019-09-21 03:59:59','2019-09-22 03:59:59','AGIBNB','4h','0.001262000000000','0.001238000000000','0.727144755117866','0.713316328713089','576.184433532382','576.184433532381945','test'),('2019-09-23 15:59:59','2019-09-24 19:59:59','AGIBNB','4h','0.001414000000000','0.001250000000000','0.727144755117866','0.642808305443658','514.2466443549265','514.246644354926502','test'),('2019-09-24 23:59:59','2019-09-26 15:59:59','AGIBNB','4h','0.001328000000000','0.001290000000000','0.727144755117866','0.706337902185276','547.5487613839352','547.548761383935243','test'),('2019-09-27 23:59:59','2019-09-29 15:59:59','AGIBNB','4h','0.001334000000000','0.001339000000000','0.727144755117866','0.729870185234500','545.0860233267362','545.086023326736154','test'),('2019-09-29 19:59:59','2019-09-30 07:59:59','AGIBNB','4h','0.001352000000000','0.001353000000000','0.727144755117866','0.727682584078752','537.8289608859956','537.828960885995571','test'),('2019-10-03 11:59:59','2019-10-03 15:59:59','AGIBNB','4h','0.001352000000000','0.001325000000000','0.727144755117866','0.712623373173944','537.8289608859956','537.828960885995571','test'),('2019-10-04 03:59:59','2019-10-09 07:59:59','AGIBNB','4h','0.001359000000000','0.001402000000000','0.727144755117866','0.750152278642567','535.0586866209463','535.058686620946332','test'),('2019-11-16 03:59:59','2019-11-17 11:59:59','AGIBNB','4h','0.001105000000000','0.001098000000000','0.727144755117866','0.722538408252866','658.0495521428651','658.049552142865082','test'),('2019-11-17 19:59:59','2019-11-21 19:59:59','AGIBNB','4h','0.001084000000000','0.001198000000000','0.727144755117866','0.803615697999265','670.7977445736772','670.797744573677164','test'),('2019-11-23 07:59:59','2019-11-24 07:59:59','AGIBNB','4h','0.001217000000000','0.001175000000000','0.727144755117866','0.702050194957677','597.4895276235546','597.489527623554636','test'),('2019-11-25 11:59:59','2019-11-27 23:59:59','AGIBNB','4h','0.001255000000000','0.001210000000000','0.727144755117866','0.701071835611648','579.3982112492956','579.398211249295628','test'),('2019-11-29 07:59:59','2019-12-05 11:59:59','AGIBNB','4h','0.001260000000000','0.001268000000000','0.727144755117866','0.731761547213852','577.0990119983063','577.099011998306310','test'),('2019-12-05 15:59:59','2019-12-05 19:59:59','AGIBNB','4h','0.001307000000000','0.001281000000000','0.727144755117866','0.712679748512614','556.3464078943122','556.346407894312165','test'),('2019-12-09 19:59:59','2019-12-10 03:59:59','AGIBNB','4h','0.001304000000000','0.001261000000000','0.727144755117866','0.703166822242047','557.6263459492837','557.626345949283746','test'),('2019-12-18 03:59:59','2019-12-20 19:59:59','AGIBNB','4h','0.001303000000000','0.001302000000000','0.727144755117866','0.726586700816164','558.0543017021229','558.054301702122871','test'),('2019-12-20 23:59:59','2019-12-22 23:59:59','AGIBNB','4h','0.001304000000000','0.001289000000000','0.727144755117866','0.718780359928627','557.6263459492837','557.626345949283746','test'),('2019-12-25 03:59:59','2019-12-26 03:59:59','AGIBNB','4h','0.001324000000000','0.001290000000000','0.727144755117866','0.708471853551395','549.2029872491435','549.202987249143462','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  3:14:43
