-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-12 07:59:59','2019-01-12 15:59:59','GRSETH','4h','0.001653810000000','0.001642950000000','0.072144500000000','0.071670751945508','43.62320943760166','43.623209437601659','test'),('2019-01-12 19:59:59','2019-01-14 15:59:59','GRSETH','4h','0.001689250000000','0.001619410000000','0.072144500000000','0.069161772825218','42.708006511765575','42.708006511765575','test'),('2019-01-15 23:59:59','2019-01-20 15:59:59','GRSETH','4h','0.001765050000000','0.001759450000000','0.072144500000000','0.071915606087646','40.87391292031387','40.873912920313870','test'),('2019-01-23 11:59:59','2019-01-26 07:59:59','GRSETH','4h','0.001814800000000','0.001894260000000','0.072144500000000','0.075303306463522','39.753416354419215','39.753416354419215','test'),('2019-01-30 11:59:59','2019-01-30 15:59:59','GRSETH','4h','0.001893380000000','0.001816100000000','0.072144500000000','0.069199857635551','38.103550264606156','38.103550264606156','test'),('2019-02-07 11:59:59','2019-02-08 07:59:59','GRSETH','4h','0.002700000000000','0.002158050000000','0.072144500000000','0.057663495638889','26.720185185185183','26.720185185185183','test'),('2019-02-17 07:59:59','2019-02-17 11:59:59','GRSETH','4h','0.002008620000000','0.001852930000000','0.072144500000000','0.066552512862064','35.917445808565084','35.917445808565084','test'),('2019-02-17 15:59:59','2019-02-18 03:59:59','GRSETH','4h','0.002060000000000','0.001728740000000','0.072144500000000','0.060543244140777','35.02160194174757','35.021601941747569','test'),('2019-02-28 15:59:59','2019-03-05 19:59:59','GRSETH','4h','0.001730000000000','0.001746160000000','0.072144500000000','0.072818404693642','41.702023121387285','41.702023121387285','test'),('2019-03-05 23:59:59','2019-03-06 07:59:59','GRSETH','4h','0.001783870000000','0.001734530000000','0.072144500000000','0.070149057714407','40.442689209415484','40.442689209415484','test'),('2019-03-07 15:59:59','2019-03-08 07:59:59','GRSETH','4h','0.001792000000000','0.001747270000000','0.072144500000000','0.070343705644531','40.259207589285715','40.259207589285715','test'),('2019-03-08 23:59:59','2019-03-11 07:59:59','GRSETH','4h','0.001777490000000','0.001813800000000','0.072144500000000','0.073618244884641','40.58785140844674','40.587851408446738','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','GRSETH','4h','0.001823820000000','0.003136700000000','0.072144500000000','0.124077843838756','39.556809334254474','39.556809334254474','test'),('2019-03-11 19:59:59','2019-03-12 01:59:59','GRSETH','4h','0.005041630000000','0.003899770000000','0.075929326093788','0.058732375842886','15.060471731124258','15.060471731124258','test'),('2019-03-12 11:59:59','2019-03-12 23:59:59','GRSETH','4h','0.004522190000000','0.003581750000000','0.075929326093788','0.060138973315236','16.790388306061445','16.790388306061445','test'),('2019-03-13 07:59:59','2019-03-14 03:59:59','GRSETH','4h','0.003313330000000','0.002929980000000','0.075929326093788','0.067144355336860','22.916318656393415','22.916318656393415','test'),('2019-03-15 15:59:59','2019-03-16 03:59:59','GRSETH','4h','0.003297900000000','0.002963570000000','0.075929326093788','0.068231866621719','23.023538037474758','23.023538037474758','test'),('2019-03-18 11:59:59','2019-03-20 15:59:59','GRSETH','4h','0.003210270000000','0.003105240000000','0.075929326093788','0.073445155877691','23.652006246760553','23.652006246760553','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','GRSETH','4h','0.003247940000000','0.003266410000000','0.075929326093788','0.076361111980520','23.37768742457927','23.377687424579271','test'),('2019-03-21 19:59:59','2019-03-24 03:59:59','GRSETH','4h','0.003359680000000','0.003399750000000','0.075929326093788','0.076834914750023','22.600166115162157','22.600166115162157','test'),('2019-05-24 19:59:59','2019-05-25 11:59:59','GRSETH','4h','0.001794070000000','0.001726960000000','0.075929326093788','0.073089070655508','42.32238769601409','42.322387696014090','test'),('2019-05-25 15:59:59','2019-05-26 19:59:59','GRSETH','4h','0.001836600000000','0.001677100000000','0.075929326093788','0.069335224214250','41.34233153315256','41.342331533152560','test'),('2019-06-07 15:59:59','2019-06-07 23:59:59','GRSETH','4h','0.001663160000000','0.001675540000000','0.075929326093788','0.076494518292399','45.65365093784603','45.653650937846031','test'),('2019-06-08 03:59:59','2019-06-13 03:59:59','GRSETH','4h','0.001692070000000','0.001725980000000','0.075929326093788','0.077450990946803','44.87363176097206','44.873631760972060','test'),('2019-07-19 15:59:59','2019-07-24 23:59:59','GRSETH','4h','0.001166230000000','0.001236440000000','0.075929326093788','0.080500463849672','65.10664799721152','65.106647997211525','test'),('2019-07-26 15:59:59','2019-07-27 15:59:59','GRSETH','4h','0.001293670000000','0.001248710000000','0.075929326093788','0.073290490454733','58.69296350212032','58.692963502120321','test'),('2019-07-29 11:59:59','2019-07-31 11:59:59','GRSETH','4h','0.001735060000000','0.001376880000000','0.075929326093788','0.060254729238191','43.761786966322774','43.761786966322774','test'),('2019-08-23 03:59:59','2019-08-26 03:59:59','GRSETH','4h','0.001189640000000','0.001234260000000','0.075929326093788','0.078777218338757','63.82546492534548','63.825464925345479','test'),('2019-08-26 19:59:59','2019-08-27 03:59:59','GRSETH','4h','0.001278470000000','0.001230000000000','0.075929326093788','0.073050655154489','59.39077654836483','59.390776548364833','test'),('2019-08-30 15:59:59','2019-08-31 19:59:59','GRSETH','4h','0.001278260000000','0.001246800000000','0.075929326093788','0.074060585306381','59.40053361114953','59.400533611149527','test'),('2019-09-05 07:59:59','2019-09-05 19:59:59','GRSETH','4h','0.001267940000000','0.001272440000000','0.075929326093788','0.076198804119106','59.884005626282','59.884005626281997','test'),('2019-09-06 03:59:59','2019-09-06 07:59:59','GRSETH','4h','0.001263560000000','0.001249020000000','0.075929326093788','0.075055594413928','60.09158733561366','60.091587335613660','test'),('2019-09-06 11:59:59','2019-09-06 15:59:59','GRSETH','4h','0.001254300000000','0.001241950000000','0.075929326093788','0.075181716130256','60.535219719196355','60.535219719196355','test'),('2019-09-06 19:59:59','2019-09-07 19:59:59','GRSETH','4h','0.001282040000000','0.001254360000000','0.075929326093788','0.074289967145334','59.22539553663536','59.225395536635361','test'),('2019-09-07 23:59:59','2019-09-08 03:59:59','GRSETH','4h','0.001268770000000','0.001244330000000','0.050619550729192','0.049644478951154','39.896553929547515','39.896553929547515','test'),('2019-10-03 03:59:59','2019-10-06 07:59:59','GRSETH','4h','0.001169720000000','0.001117450000000','0.056536291653077','0.054009916140385','48.33318371326216','48.333183713262159','test'),('2019-10-07 07:59:59','2019-10-07 19:59:59','GRSETH','4h','0.001157220000000','0.001109780000000','0.056536291653077','0.054218597804006','48.855266633031746','48.855266633031746','test'),('2019-10-08 03:59:59','2019-10-08 07:59:59','GRSETH','4h','0.001148710000000','0.001106540000000','0.056536291653077','0.054460802261490','49.21720160273437','49.217201602734370','test'),('2019-10-08 15:59:59','2019-10-09 03:59:59','GRSETH','4h','0.001133250000000','0.001127390000000','0.056536291653077','0.056243944272458','49.88863150503155','49.888631505031547','test'),('2019-10-09 07:59:59','2019-10-09 11:59:59','GRSETH','4h','0.001132050000000','0.001106310000000','0.056536291653077','0.055250797066133','49.94151464429751','49.941514644297513','test'),('2019-10-12 07:59:59','2019-10-15 11:59:59','GRSETH','4h','0.001137220000000','0.001147590000000','0.056536291653077','0.057051830725941','49.71447182873762','49.714471828737622','test'),('2019-10-15 15:59:59','2019-10-18 19:59:59','GRSETH','4h','0.001225210000000','0.001177870000000','0.056536291653077','0.054351826910823','46.14416439065711','46.144164390657110','test'),('2019-10-28 19:59:59','2019-10-29 23:59:59','GRSETH','4h','0.001211880000000','0.001175210000000','0.056536291653077','0.054825572922742','46.6517243069256','46.651724306925601','test'),('2019-10-30 03:59:59','2019-11-02 15:59:59','GRSETH','4h','0.001190000000000','0.001252010000000','0.056536291653077','0.059482355052579','47.509488784098316','47.509488784098316','test'),('2019-11-03 03:59:59','2019-11-04 15:59:59','GRSETH','4h','0.001265050000000','0.001246770000000','0.056536291653077','0.055719341009689','44.69095423349037','44.690954233490373','test'),('2019-11-25 07:59:59','2019-11-29 19:59:59','GRSETH','4h','0.001284760000000','0.001298520000000','0.056536291653077','0.057141805035457','44.005333021791614','44.005333021791614','test'),('2019-11-30 15:59:59','2019-12-01 03:59:59','GRSETH','4h','0.001345890000000','0.001274920000000','0.056536291653077','0.053555081733530','42.00662138293397','42.006621382933972','test'),('2019-12-09 07:59:59','2019-12-10 03:59:59','GRSETH','4h','0.001409690000000','0.001312330000000','0.056536291653077','0.052631622289356','40.10547826336074','40.105478263360737','test'),('2019-12-10 11:59:59','2019-12-10 15:59:59','GRSETH','4h','0.001269950000000','0.001247790000000','0.056536291653077','0.055549761299101','44.51851777871334','44.518517778713338','test'),('2019-12-27 11:59:59','2019-12-27 19:59:59','GRSETH','4h','0.001287600000000','0.001224670000000','0.056536291653077','0.053773144065528','43.9082724860803','43.908272486080300','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  0:36:06
