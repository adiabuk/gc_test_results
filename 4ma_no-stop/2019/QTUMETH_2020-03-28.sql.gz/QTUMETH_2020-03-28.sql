-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 07:59:59','2019-01-14 19:59:59','QTUMETH','4h','0.016867000000000','0.016764000000000','0.072144500000000','0.071703942491255','4.277257366455208','4.277257366455208','test'),('2019-01-16 15:59:59','2019-01-20 11:59:59','QTUMETH','4h','0.017251000000000','0.017189000000000','0.072144500000000','0.071885213060112','4.182047417541012','4.182047417541012','test'),('2019-01-21 07:59:59','2019-01-27 15:59:59','QTUMETH','4h','0.017481000000000','0.017521000000000','0.072144500000000','0.072309580945026','4.127023625650707','4.127023625650707','test'),('2019-02-27 03:59:59','2019-02-27 15:59:59','QTUMETH','4h','0.015193000000000','0.014939000000000','0.072144500000000','0.070938371980517','4.748535509774238','4.748535509774238','test'),('2019-02-27 19:59:59','2019-02-28 15:59:59','QTUMETH','4h','0.015218000000000','0.015150000000000','0.072144500000000','0.071822130043370','4.740734656328033','4.740734656328033','test'),('2019-02-28 23:59:59','2019-03-03 11:59:59','QTUMETH','4h','0.015339000000000','0.015394000000000','0.072144500000000','0.072403183584328','4.703337896864202','4.703337896864202','test'),('2019-03-03 15:59:59','2019-03-04 15:59:59','QTUMETH','4h','0.015542000000000','0.015493000000000','0.072144500000000','0.071917046615622','4.641905803628877','4.641905803628877','test'),('2019-03-09 03:59:59','2019-03-11 11:59:59','QTUMETH','4h','0.015921000000000','0.015570000000000','0.072144500000000','0.070553976823064','4.531405062496074','4.531405062496074','test'),('2019-03-12 15:59:59','2019-03-16 23:59:59','QTUMETH','4h','0.016020000000000','0.017661000000000','0.072144500000000','0.079534582677903','4.503401997503121','4.503401997503121','test'),('2019-03-17 23:59:59','2019-03-19 07:59:59','QTUMETH','4h','0.018041000000000','0.017799000000000','0.073086382055299','0.072106009323334','4.051126991591333','4.051126991591333','test'),('2019-03-19 11:59:59','2019-03-20 07:59:59','QTUMETH','4h','0.018083000000000','0.017809000000000','0.073086382055299','0.071978951392071','4.041717749007301','4.041717749007301','test'),('2019-03-20 15:59:59','2019-03-25 15:59:59','QTUMETH','4h','0.018436000000000','0.018407000000000','0.073086382055299','0.072971416494461','3.9643296840583098','3.964329684058310','test'),('2019-03-28 15:59:59','2019-04-02 23:59:59','QTUMETH','4h','0.019629000000000','0.020000000000000','0.073086382055299','0.074467758984461','3.7233879492230377','3.723387949223038','test'),('2019-04-05 07:59:59','2019-04-06 15:59:59','QTUMETH','4h','0.020383000000000','0.019900000000000','0.073086382055299','0.071354511254499','3.585653831884365','3.585653831884365','test'),('2019-04-07 15:59:59','2019-04-08 03:59:59','QTUMETH','4h','0.020400000000000','0.019291000000000','0.073086382055299','0.069113205697489','3.5826657870244607','3.582665787024461','test'),('2019-05-03 11:59:59','2019-05-03 19:59:59','QTUMETH','4h','0.015850000000000','0.015586000000000','0.073086382055299','0.071869044209078','4.611128205381641','4.611128205381641','test'),('2019-05-04 03:59:59','2019-05-04 07:59:59','QTUMETH','4h','0.015577000000000','0.015391000000000','0.073086382055299','0.072213680825134','4.691942097663158','4.691942097663158','test'),('2019-05-30 15:59:59','2019-06-03 15:59:59','QTUMETH','4h','0.012329000000000','0.012986000000000','0.073086382055299','0.076981081788475','5.9280056821558125','5.928005682155812','test'),('2019-06-08 11:59:59','2019-06-08 15:59:59','QTUMETH','4h','0.012601000000000','0.012417000000000','0.073086382055299','0.072019173556118','5.800046191199033','5.800046191199033','test'),('2019-06-09 19:59:59','2019-06-10 03:59:59','QTUMETH','4h','0.012539000000000','0.012796000000000','0.073086382055299','0.074584364365548','5.8287249426029994','5.828724942602999','test'),('2019-06-10 07:59:59','2019-06-12 11:59:59','QTUMETH','4h','0.013723000000000','0.012828000000000','0.073086382055299','0.068319763098840','5.325831236267507','5.325831236267507','test'),('2019-06-14 03:59:59','2019-06-14 19:59:59','QTUMETH','4h','0.013490000000000','0.012849000000000','0.073086382055299','0.069613559898335','5.417819277635211','5.417819277635211','test'),('2019-06-14 23:59:59','2019-06-16 03:59:59','QTUMETH','4h','0.012956000000000','0.012854000000000','0.073086382055299','0.072510987568602','5.641122418593625','5.641122418593625','test'),('2019-06-16 11:59:59','2019-06-18 03:59:59','QTUMETH','4h','0.013512000000000','0.013141000000000','0.073086382055299','0.071079643767665','5.4089980798770725','5.408998079877072','test'),('2019-06-18 15:59:59','2019-06-20 03:59:59','QTUMETH','4h','0.013394000000000','0.013261000000000','0.073086382055299','0.072360647486585','5.4566508925861585','5.456650892586159','test'),('2019-06-25 11:59:59','2019-06-28 07:59:59','QTUMETH','4h','0.014060000000000','0.014947000000000','0.073086382055299','0.077697165901889','5.198177955568919','5.198177955568919','test'),('2019-06-28 11:59:59','2019-07-01 15:59:59','QTUMETH','4h','0.016314000000000','0.016481000000000','0.073086382055299','0.073834538595892','4.479979284988293','4.479979284988293','test'),('2019-07-02 15:59:59','2019-07-05 03:59:59','QTUMETH','4h','0.017908000000000','0.017055000000000','0.073086382055299','0.069605106430262','4.081214097347499','4.081214097347499','test'),('2019-07-21 11:59:59','2019-07-22 07:59:59','QTUMETH','4h','0.014401000000000','0.014101000000000','0.073086382055299','0.071563854826871','5.075090761426221','5.075090761426221','test'),('2019-07-22 11:59:59','2019-07-22 15:59:59','QTUMETH','4h','0.014209000000000','0.014144000000000','0.073086382055299','0.072752043619547','5.143668242332255','5.143668242332255','test'),('2019-07-26 23:59:59','2019-07-27 07:59:59','QTUMETH','4h','0.014142000000000','0.014102000000000','0.073086382055299','0.072879660567376','5.168037198083652','5.168037198083652','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','QTUMETH','4h','0.013938000000000','0.013818000000000','0.073086382055299','0.072457140711732','5.243677863057756','5.243677863057756','test'),('2019-08-18 11:59:59','2019-08-19 19:59:59','QTUMETH','4h','0.013839000000000','0.013019000000000','0.073086382055299','0.068755806631833','5.281189540812125','5.281189540812125','test'),('2019-08-19 23:59:59','2019-08-20 11:59:59','QTUMETH','4h','0.013330000000000','0.012958000000000','0.073086382055299','0.071046762090965','5.482849366489048','5.482849366489048','test'),('2019-08-21 11:59:59','2019-08-22 03:59:59','QTUMETH','4h','0.013247000000000','0.013230000000000','0.073086382055299','0.072992589612109','5.517202540597796','5.517202540597796','test'),('2019-08-22 07:59:59','2019-08-23 07:59:59','QTUMETH','4h','0.013377000000000','0.013281000000000','0.073086382055299','0.072561877855754','5.463585411923376','5.463585411923376','test'),('2019-08-23 11:59:59','2019-08-23 15:59:59','QTUMETH','4h','0.013421000000000','0.013331000000000','0.073086382055299','0.072596271453632','5.445673351858953','5.445673351858953','test'),('2019-08-23 19:59:59','2019-08-26 11:59:59','QTUMETH','4h','0.013436000000000','0.013320000000000','0.073086382055299','0.072455389176584','5.439593782025827','5.439593782025827','test'),('2019-10-05 19:59:59','2019-10-06 11:59:59','QTUMETH','4h','0.009836000000000','0.009741000000000','0.073086382055299','0.072380484709299','7.430498378944592','7.430498378944592','test'),('2019-10-06 15:59:59','2019-10-09 15:59:59','QTUMETH','4h','0.009842000000000','0.009614000000000','0.073086382055299','0.071393261235485','7.4259685079555995','7.425968507955599','test'),('2019-10-13 07:59:59','2019-10-14 07:59:59','QTUMETH','4h','0.009833000000000','0.009802000000000','0.073086382055299','0.072855966328286','7.4327653875011706','7.432765387501171','test'),('2019-10-14 11:59:59','2019-10-14 15:59:59','QTUMETH','4h','0.009854000000000','0.009840000000000','0.073086382055299','0.072982545100887','7.41692531513081','7.416925315130810','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','QTUMETH','4h','0.009774000000000','0.009761000000000','0.073086382055299','0.072989172830138','7.4776327046551065','7.477632704655107','test'),('2019-10-18 03:59:59','2019-10-18 07:59:59','QTUMETH','4h','0.009846000000000','0.009666000000000','0.073086382055299','0.071750250756299','7.42295166111101','7.422951661111010','test'),('2019-10-19 19:59:59','2019-10-20 07:59:59','QTUMETH','4h','0.009809000000000','0.009783000000000','0.073086382055299','0.072892657319501','7.450951376827303','7.450951376827303','test'),('2019-10-20 15:59:59','2019-10-21 03:59:59','QTUMETH','4h','0.009836000000000','0.009756000000000','0.073086382055299','0.072491942184983','7.430498378944592','7.430498378944592','test'),('2019-10-21 19:59:59','2019-10-22 11:59:59','QTUMETH','4h','0.009795000000000','0.009801000000000','0.073086382055299','0.073131151661458','7.461601026574682','7.461601026574682','test'),('2019-10-22 15:59:59','2019-10-22 23:59:59','QTUMETH','4h','0.009843000000000','0.009757000000000','0.073086382055299','0.072447813645591','7.42521406637194','7.425214066371940','test'),('2019-10-23 03:59:59','2019-10-23 15:59:59','QTUMETH','4h','0.009829000000000','0.009601000000000','0.073086382055299','0.071391021885535','7.435790218262184','7.435790218262184','test'),('2019-10-25 03:59:59','2019-10-25 07:59:59','QTUMETH','4h','0.009886000000000','0.009734000000000','0.073086382055299','0.071962658600676','7.392917464626644','7.392917464626644','test'),('2019-10-26 03:59:59','2019-10-30 07:59:59','QTUMETH','4h','0.009813000000000','0.011777000000000','0.073086382055299','0.087714085546240','7.447914201090288','7.447914201090288','test'),('2019-11-02 03:59:59','2019-11-03 07:59:59','QTUMETH','4h','0.012206000000000','0.011775000000000','0.073086382055299','0.070505665140189','5.987742262436425','5.987742262436425','test'),('2019-11-04 19:59:59','2019-11-07 07:59:59','QTUMETH','4h','0.012121000000000','0.011828000000000','0.073086382055299','0.071319670567616','6.029732039872866','6.029732039872866','test'),('2019-11-13 07:59:59','2019-11-15 15:59:59','QTUMETH','4h','0.012068000000000','0.012026000000000','0.073086382055299','0.072832021096870','6.056213295931306','6.056213295931306','test'),('2019-11-15 23:59:59','2019-11-16 03:59:59','QTUMETH','4h','0.012096000000000','0.011991000000000','0.073086382055299','0.072451951655513','6.042194283672206','6.042194283672206','test'),('2019-11-28 11:59:59','2019-11-30 15:59:59','QTUMETH','4h','0.012022000000000','0.011755000000000','0.073086382055299','0.071463185914161','6.079386296398187','6.079386296398187','test'),('2019-11-30 19:59:59','2019-12-01 03:59:59','QTUMETH','4h','0.011772000000000','0.011798000000000','0.073086382055299','0.073247802878731','6.208493208910891','6.208493208910891','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','QTUMETH','4h','0.011994000000000','0.011789000000000','0.073086382055299','0.071837198436712','6.093578627255212','6.093578627255212','test'),('2019-12-03 19:59:59','2019-12-04 03:59:59','QTUMETH','4h','0.011918000000000','0.011651000000000','0.073086382055299','0.071449021423585','6.132436822898054','6.132436822898054','test'),('2019-12-07 11:59:59','2019-12-08 03:59:59','QTUMETH','4h','0.011871000000000','0.011753000000000','0.073086382055299','0.072359889503490','6.156716540754697','6.156716540754697','test'),('2019-12-08 07:59:59','2019-12-08 15:59:59','QTUMETH','4h','0.011773000000000','0.011677000000000','0.073086382055299','0.072490417332857','6.207965858769983','6.207965858769983','test'),('2019-12-10 15:59:59','2019-12-10 19:59:59','QTUMETH','4h','0.011807000000000','0.011845000000000','0.073086382055299','0.073321605441265','6.190089104370204','6.190089104370204','test'),('2019-12-10 23:59:59','2019-12-14 23:59:59','QTUMETH','4h','0.011969000000000','0.012327000000000','0.073086382055299','0.075272439769043','6.106306462970926','6.106306462970926','test'),('2019-12-16 19:59:59','2019-12-17 03:59:59','QTUMETH','4h','0.012844000000000','0.011825000000000','0.073086382055299','0.067287952958884','5.690313146628699','5.690313146628699','test'),('2019-12-18 03:59:59','2019-12-21 23:59:59','QTUMETH','4h','0.012665000000000','0.012728000000000','0.073086382055299','0.073449938476103','5.770736838160206','5.770736838160206','test'),('2019-12-27 15:59:59','2019-12-28 19:59:59','QTUMETH','4h','0.012799000000000','0.012650000000000','0.073086382055299','0.072235544417496','5.71031971679811','5.710319716798110','test'),('2019-12-28 23:59:59','2019-12-29 15:59:59','QTUMETH','4h','0.012688000000000','0.012676000000000','0.073086382055299','0.073017258743141','5.760276013185609','5.760276013185609','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:40:28
