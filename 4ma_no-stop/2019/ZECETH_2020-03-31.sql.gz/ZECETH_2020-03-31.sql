-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 03:59:59','2019-01-13 19:59:59','ZECETH','4h','0.453750000000000','0.457000000000000','0.072144500000000','0.072661237465565','0.1589961432506887','0.158996143250689','test'),('2019-01-14 07:59:59','2019-01-14 23:59:59','ZECETH','4h','0.452620000000000','0.432620000000000','0.072273684366391','0.069080114291432','0.15967850374793702','0.159678503747937','test'),('2019-01-16 15:59:59','2019-01-16 23:59:59','ZECETH','4h','0.441160000000000','0.430790000000000','0.072273684366391','0.070574803899260','0.16382646741860324','0.163826467418603','test'),('2019-01-17 15:59:59','2019-01-18 11:59:59','ZECETH','4h','0.441230000000000','0.437010000000000','0.072273684366391','0.071582446354410','0.16380047677263787','0.163800476772638','test'),('2019-01-18 19:59:59','2019-01-19 11:59:59','ZECETH','4h','0.439710000000000','0.436050000000000','0.072273684366391','0.071672102221839','0.164366706161768','0.164366706161768','test'),('2019-01-20 19:59:59','2019-01-26 15:59:59','ZECETH','4h','0.444750000000000','0.449110000000000','0.072273684366391','0.072982202104081','0.16250406827743902','0.162504068277439','test'),('2019-01-27 23:59:59','2019-01-30 15:59:59','ZECETH','4h','0.453580000000000','0.455420000000000','0.072273684366391','0.072566870969050','0.15934054492347768','0.159340544923478','test'),('2019-01-30 19:59:59','2019-01-30 23:59:59','ZECETH','4h','0.457730000000000','0.456900000000000','0.072273684366391','0.072142630780163','0.15789588702158697','0.157895887021587','test'),('2019-03-02 15:59:59','2019-03-04 07:59:59','ZECETH','4h','0.386190000000000','0.384550000000000','0.072273684366391','0.071966765900452','0.18714540606020613','0.187145406060206','test'),('2019-03-04 11:59:59','2019-03-04 23:59:59','ZECETH','4h','0.387530000000000','0.384640000000000','0.072273684366391','0.071734704293058','0.18649829527105258','0.186498295271053','test'),('2019-03-12 19:59:59','2019-03-16 07:59:59','ZECETH','4h','0.387000000000000','0.383790000000000','0.072273684366391','0.071674204968933','0.18675370637310337','0.186753706373103','test'),('2019-03-18 15:59:59','2019-03-22 07:59:59','ZECETH','4h','0.391260000000000','0.403890000000000','0.072273684366391','0.074606702394167','0.18472035057606453','0.184720350576065','test'),('2019-03-23 23:59:59','2019-03-25 23:59:59','ZECETH','4h','0.413020000000000','0.412530000000000','0.072273684366391','0.072187940079578','0.174988340434824','0.174988340434824','test'),('2019-03-31 19:59:59','2019-04-04 11:59:59','ZECETH','4h','0.417870000000000','0.418580000000000','0.072273684366391','0.072396484078981','0.17295734167657645','0.172957341676576','test'),('2019-04-05 11:59:59','2019-04-06 19:59:59','ZECETH','4h','0.440510000000000','0.428050000000000','0.072273684366391','0.070229394549576','0.16406820359671972','0.164068203596720','test'),('2019-04-06 23:59:59','2019-04-07 03:59:59','ZECETH','4h','0.430770000000000','0.429300000000000','0.072273684366391','0.072027050858908','0.1677778962471644','0.167777896247164','test'),('2019-04-07 07:59:59','2019-04-07 23:59:59','ZECETH','4h','0.437450000000000','0.425010000000000','0.072273684366391','0.070218398885724','0.16521587465171106','0.165215874651711','test'),('2019-04-12 15:59:59','2019-04-14 07:59:59','ZECETH','4h','0.433060000000000','0.417070000000000','0.072273684366391','0.069605102153722','0.166890694976195','0.166890694976195','test'),('2019-04-14 11:59:59','2019-04-14 15:59:59','ZECETH','4h','0.422220000000000','0.420730000000000','0.072273684366391','0.072018632995764','0.17117541652785517','0.171175416527855','test'),('2019-05-29 11:59:59','2019-05-30 07:59:59','ZECETH','4h','0.307780000000000','0.307560000000000','0.072273684366391','0.072222023405443','0.234822549764088','0.234822549764088','test'),('2019-05-30 11:59:59','2019-06-02 07:59:59','ZECETH','4h','0.334800000000000','0.323770000000000','0.072273684366391','0.069892624812743','0.21587121973235068','0.215871219732351','test'),('2019-06-02 15:59:59','2019-06-03 07:59:59','ZECETH','4h','0.331300000000000','0.325180000000000','0.072273684366391','0.070938595479212','0.21815177895077273','0.218151778950773','test'),('2019-06-03 15:59:59','2019-06-04 19:59:59','ZECETH','4h','0.330450000000000','0.324500000000000','0.072273684366391','0.070972342493248','0.21871291985592678','0.218712919855927','test'),('2019-06-07 15:59:59','2019-06-10 19:59:59','ZECETH','4h','0.332550000000000','0.325240000000000','0.072273684366391','0.070684989034205','0.21733178278872653','0.217331782788727','test'),('2019-06-12 15:59:59','2019-06-16 03:59:59','ZECETH','4h','0.345370000000000','0.339670000000000','0.072273684366391','0.071080876650352','0.20926451158580944','0.209264511585809','test'),('2019-06-16 23:59:59','2019-06-21 07:59:59','ZECETH','4h','0.349260000000000','0.393650000000000','0.072273684366391','0.081459473890024','0.2069337581354607','0.206933758135461','test'),('2019-06-29 15:59:59','2019-06-29 23:59:59','ZECETH','4h','0.368180000000000','0.358250000000000','0.072273684366391','0.070324426705034','0.1962998651920012','0.196299865192001','test'),('2019-06-30 07:59:59','2019-06-30 11:59:59','ZECETH','4h','0.357980000000000','0.358160000000000','0.072273684366391','0.072310025120584','0.20189307884907257','0.201893078849073','test'),('2019-07-15 23:59:59','2019-07-16 15:59:59','ZECETH','4h','0.351880000000000','0.342770000000000','0.072273684366391','0.070402554252211','0.2053929872865494','0.205392987286549','test'),('2019-07-17 19:59:59','2019-07-19 07:59:59','ZECETH','4h','0.354450000000000','0.343400000000000','0.072273684366391','0.070020547923314','0.20390375050470028','0.203903750504700','test'),('2019-08-26 15:59:59','2019-08-27 15:59:59','ZECETH','4h','0.275230000000000','0.268730000000000','0.072273684366391','0.070566824836610','0.2625937738124151','0.262593773812415','test'),('2019-08-27 19:59:59','2019-08-28 03:59:59','ZECETH','4h','0.269540000000000','0.267680000000000','0.072273684366391','0.071774949288401','0.26813713870442607','0.268137138704426','test'),('2019-08-29 03:59:59','2019-08-29 07:59:59','ZECETH','4h','0.270480000000000','0.266300000000000','0.072273684366391','0.071156766292406','0.2672052808577011','0.267205280857701','test'),('2019-09-07 15:59:59','2019-09-07 19:59:59','ZECETH','4h','0.267640000000000','0.262420000000000','0.072273684366391','0.070864072079765','0.2700406679359999','0.270040667936000','test'),('2019-09-07 23:59:59','2019-09-08 03:59:59','ZECETH','4h','0.264450000000000','0.264260000000000','0.072273684366391','0.072221757726082','0.2732981068874683','0.273298106887468','test'),('2019-09-08 07:59:59','2019-09-08 15:59:59','ZECETH','4h','0.265780000000000','0.264520000000000','0.072273684366391','0.071931051954992','0.27193048523738056','0.271930485237381','test'),('2019-09-08 19:59:59','2019-09-09 03:59:59','ZECETH','4h','0.266810000000000','0.263850000000000','0.072273684366391','0.071471877441146','0.2708807179880477','0.270880717988048','test'),('2019-10-17 07:59:59','2019-10-17 23:59:59','ZECETH','4h','0.207020000000000','0.204080000000000','0.072273684366391','0.071247287728205','0.34911450278422856','0.349114502784229','test'),('2019-10-18 03:59:59','2019-10-21 11:59:59','ZECETH','4h','0.207180000000000','0.205960000000000','0.072273684366391','0.071848093600260','0.3488448902712183','0.348844890271218','test'),('2019-10-21 15:59:59','2019-10-23 07:59:59','ZECETH','4h','0.210070000000000','0.209640000000000','0.072273684366391','0.072125744706861','0.34404571983810633','0.344045719838106','test'),('2019-10-28 19:59:59','2019-10-29 03:59:59','ZECETH','4h','0.213060000000000','0.207810000000000','0.072273684366391','0.070492792397352','0.33921751791228294','0.339217517912283','test'),('2019-10-29 07:59:59','2019-10-29 19:59:59','ZECETH','4h','0.209600000000000','0.203870000000000','0.072273684366391','0.070297881830993','0.34481719640453723','0.344817196404537','test'),('2019-10-30 19:59:59','2019-10-31 15:59:59','ZECETH','4h','0.211990000000000','0.207110000000000','0.072273684366391','0.070609947493388','0.3409296870908581','0.340929687090858','test'),('2019-12-05 19:59:59','2019-12-08 19:59:59','ZECETH','4h','0.204670000000000','0.194160000000000','0.072273684366391','0.068562361638630','0.35312299978693024','0.353122999786930','test'),('2019-12-09 11:59:59','2019-12-16 23:59:59','ZECETH','4h','0.206000000000000','0.222270000000000','0.072273684366391','0.077981902058824','0.35084312799218936','0.350843127992189','test'),('2019-12-18 11:59:59','2019-12-19 03:59:59','ZECETH','4h','0.229360000000000','0.225130000000000','0.072273684366391','0.070940768056355','0.3151102387791725','0.315110238779172','test'),('2019-12-19 11:59:59','2019-12-19 23:59:59','ZECETH','4h','0.226540000000000','0.223040000000000','0.072273684366391','0.071157069661340','0.3190327728718593','0.319032772871859','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  4:20:35
