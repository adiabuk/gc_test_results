-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-14 15:59:59','GNTETH','4h','0.000499970000000','0.000494520000000','0.072144500000000','0.071358077764666','144.29765785947157','144.297657859471570','test'),('2019-01-16 03:59:59','2019-01-20 23:59:59','GNTETH','4h','0.000522060000000','0.000544490000000','0.072144500000000','0.075244145893192','138.1919702716163','138.191970271616299','test'),('2019-01-21 03:59:59','2019-01-22 07:59:59','GNTETH','4h','0.000549810000000','0.000545820000000','0.072722805914465','0.072195052698629','132.26897639996454','132.268976399964544','test'),('2019-01-22 11:59:59','2019-01-22 19:59:59','GNTETH','4h','0.000557500000000','0.000546080000000','0.072722805914465','0.071233129782549','130.44449491383855','130.444494913838554','test'),('2019-01-22 23:59:59','2019-01-27 11:59:59','GNTETH','4h','0.000550810000000','0.000564740000000','0.072722805914465','0.074561967669677','132.0288410059095','132.028841005909499','test'),('2019-02-27 19:59:59','2019-02-28 11:59:59','GNTETH','4h','0.000482000000000','0.000468580000000','0.072722805914465','0.070698034015353','150.8771906939108','150.877190693910791','test'),('2019-02-28 15:59:59','2019-02-28 19:59:59','GNTETH','4h','0.000471080000000','0.000468960000000','0.072722805914465','0.072395531675400','154.37464106832172','154.374641068321722','test'),('2019-02-28 23:59:59','2019-03-05 11:59:59','GNTETH','4h','0.000473720000000','0.000494540000000','0.072722805914465','0.075918974155492','153.51432473711264','153.514324737112645','test'),('2019-03-07 15:59:59','2019-03-15 23:59:59','GNTETH','4h','0.000503430000000','0.000559020000000','0.072889269542042','0.080937885027496','144.78531184482847','144.785311844828470','test'),('2019-03-20 11:59:59','2019-03-23 03:59:59','GNTETH','4h','0.000608730000000','0.000570620000000','0.074901423413405','0.070212163402752','123.04539518900907','123.045395189009071','test'),('2019-03-24 23:59:59','2019-03-27 11:59:59','GNTETH','4h','0.000582190000000','0.000591620000000','0.074901423413405','0.076114636321199','128.65460315945825','128.654603159458247','test'),('2019-03-27 15:59:59','2019-03-30 19:59:59','GNTETH','4h','0.000613570000000','0.000613350000000','0.074901423413405','0.074874566961572','122.07478105742621','122.074781057426208','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','GNTETH','4h','0.000635900000000','0.000627640000000','0.074901423413405','0.073928494088991','117.78805380312156','117.788053803121556','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','GNTETH','4h','0.000384410000000','0.000367410000000','0.074901423413405','0.071589011670662','194.84774957312504','194.847749573125043','test'),('2019-05-29 03:59:59','2019-05-30 03:59:59','GNTETH','4h','0.000396980000000','0.000369130000000','0.074901423413405','0.069646738940476','188.678078022583','188.678078022583009','test'),('2019-06-08 07:59:59','2019-06-12 19:59:59','GNTETH','4h','0.000400990000000','0.000392380000000','0.074901423413405','0.073293150749275','186.791250189294','186.791250189294004','test'),('2019-06-13 03:59:59','2019-06-13 19:59:59','GNTETH','4h','0.000420310000000','0.000396090000000','0.074901423413405','0.070585293711345','178.20519001071827','178.205190010718269','test'),('2019-07-04 11:59:59','2019-07-05 07:59:59','GNTETH','4h','0.000320040000000','0.000318460000000','0.074901423413405','0.074531643857746','234.0376934552087','234.037693455208711','test'),('2019-07-06 07:59:59','2019-07-07 11:59:59','GNTETH','4h','0.000323060000000','0.000317980000000','0.074901423413405','0.073723626004440','231.849883654445','231.849883654444994','test'),('2019-07-20 11:59:59','2019-07-20 15:59:59','GNTETH','4h','0.000299990000000','0.000292520000000','0.074901423413405','0.073036315800157','249.6797340358179','249.679734035817887','test'),('2019-07-20 23:59:59','2019-07-23 15:59:59','GNTETH','4h','0.000290890000000','0.000290000000000','0.074901423413405','0.074672256832093','257.4905408003197','257.490540800319707','test'),('2019-07-28 03:59:59','2019-07-29 11:59:59','GNTETH','4h','0.000294940000000','0.000289320000000','0.074901423413405','0.073474197538368','253.95478203500713','253.954782035007128','test'),('2019-07-29 15:59:59','2019-07-29 19:59:59','GNTETH','4h','0.000290060000000','0.000288210000000','0.074901423413405','0.074423702826924','258.22734404400813','258.227344044008134','test'),('2019-07-30 15:59:59','2019-08-01 19:59:59','GNTETH','4h','0.000306810000000','0.000286900000000','0.074901423413405','0.070040801725191','244.12966791631627','244.129667916316265','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','GNTETH','4h','0.000269560000000','0.000267250000000','0.074901423413405','0.074259554114974','277.8654971561248','277.865497156124775','test'),('2019-08-14 19:59:59','2019-08-15 01:59:59','GNTETH','4h','0.000273000000000','0.000269070000000','0.074901423413405','0.073823172153278','274.3641883274908','274.364188327490808','test'),('2019-08-15 15:59:59','2019-08-15 23:59:59','GNTETH','4h','0.000269850000000','0.000268900000000','0.074901423413405','0.074637734874429','277.5668831328701','277.566883132870089','test'),('2019-08-16 03:59:59','2019-08-16 07:59:59','GNTETH','4h','0.000270520000000','0.000269160000000','0.074901423413405','0.074524867388556','276.879430036245','276.879430036245026','test'),('2019-08-17 03:59:59','2019-08-17 23:59:59','GNTETH','4h','0.000280020000000','0.000268560000000','0.074901423413405','0.071836034111506','267.48597747805513','267.485977478055133','test'),('2019-08-18 03:59:59','2019-08-18 07:59:59','GNTETH','4h','0.000269770000000','0.000268070000000','0.074901423413405','0.074429419781412','277.6491952900804','277.649195290080399','test'),('2019-08-18 15:59:59','2019-08-18 19:59:59','GNTETH','4h','0.000277990000000','0.000268210000000','0.074901423413405','0.072266307326556','269.43927268392747','269.439272683927470','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','GNTETH','4h','0.000275930000000','0.000263790000000','0.074901423413405','0.071606010517965','271.45081511037216','271.450815110372162','test'),('2019-08-22 07:59:59','2019-08-22 15:59:59','GNTETH','4h','0.000276310000000','0.000271460000000','0.074901423413405','0.073586697549140','271.0774977865622','271.077497786562219','test'),('2019-08-22 23:59:59','2019-09-01 03:59:59','GNTETH','4h','0.000273920000000','0.000351740000000','0.074901423413405','0.096180734051661','273.4426964566479','273.442696456647923','test'),('2019-09-14 11:59:59','2019-09-14 15:59:59','GNTETH','4h','0.000335200000000','0.000326810000000','0.074901423413405','0.073026653298732','223.4529338108741','223.452933810874100','test'),('2019-10-06 03:59:59','2019-10-09 15:59:59','GNTETH','4h','0.000282080000000','0.000265950000000','0.074901423413405','0.070618383284157','265.53255606000073','265.532556060000729','test'),('2019-10-12 03:59:59','2019-10-13 11:59:59','GNTETH','4h','0.000284310000000','0.000280450000000','0.074901423413405','0.073884507039110','263.44983790019694','263.449837900196940','test'),('2019-10-13 19:59:59','2019-10-14 19:59:59','GNTETH','4h','0.000287460000000','0.000279390000000','0.074901423413405','0.072798680468487','260.5629423690426','260.562942369042617','test'),('2019-10-14 23:59:59','2019-10-15 03:59:59','GNTETH','4h','0.000281000000000','0.000280720000000','0.074901423413405','0.074826788543100','266.553108232758','266.553108232758007','test'),('2019-11-04 03:59:59','2019-11-04 11:59:59','GNTETH','4h','0.000257990000000','0.000251220000000','0.074901423413405','0.072935910655125','290.3268476041901','290.326847604190107','test'),('2019-11-04 15:59:59','2019-11-04 19:59:59','GNTETH','4h','0.000252080000000','0.000250620000000','0.074901423413405','0.074467608441239','297.1335425793597','297.133542579359698','test'),('2019-11-04 23:59:59','2019-11-05 07:59:59','GNTETH','4h','0.000253000000000','0.000251310000000','0.074901423413405','0.074401093747126','296.0530569699802','296.053056969980219','test'),('2019-11-05 11:59:59','2019-11-05 15:59:59','GNTETH','4h','0.000253000000000','0.000247350000000','0.074901423413405','0.073228723641525','296.0530569699802','296.053056969980219','test'),('2019-11-09 15:59:59','2019-11-10 19:59:59','GNTETH','4h','0.000268070000000','0.000251000000000','0.074901423413405','0.070131895686816','279.4099429753609','279.409942975360877','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','GNTETH','4h','0.000251820000000','0.000249920000000','0.074901423413405','0.074336286790081','297.4403280653046','297.440328065304584','test'),('2019-11-22 19:59:59','2019-11-22 23:59:59','GNTETH','4h','0.000244560000000','0.000249270000000','0.074901423413405','0.076343955733805','306.2701317198438','306.270131719843789','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','GNTETH','4h','0.000247080000000','0.000244000000000','0.074901423413405','0.073967732365512','303.1464441209527','303.146444120952708','test'),('2019-11-27 11:59:59','2019-11-27 19:59:59','GNTETH','4h','0.000254080000000','0.000244560000000','0.074901423413405','0.072094978392563','294.7946450464617','294.794645046461710','test'),('2019-11-27 23:59:59','2019-11-29 11:59:59','GNTETH','4h','0.000246260000000','0.000248960000000','0.074901423413405','0.075722644249985','304.1558654000041','304.155865400004075','test'),('2019-11-29 15:59:59','2019-11-30 11:59:59','GNTETH','4h','0.000249550000000','0.000249390000000','0.074901423413405','0.074853400060385','300.1459563750951','300.145956375095125','test'),('2019-11-30 19:59:59','2019-11-30 23:59:59','GNTETH','4h','0.000248040000000','0.000247030000000','0.074901423413405','0.074596430518519','301.9731632535277','301.973163253527673','test'),('2019-12-01 11:59:59','2019-12-03 07:59:59','GNTETH','4h','0.000264600000000','0.000248790000000','0.074901423413405','0.070426020903330','283.07416256010964','283.074162560109642','test'),('2019-12-03 23:59:59','2019-12-04 03:59:59','GNTETH','4h','0.000258010000000','0.000253660000000','0.074901423413405','0.073638599523446','290.3043425193016','290.304342519301599','test'),('2019-12-21 03:59:59','2019-12-22 07:59:59','GNTETH','4h','0.000256070000000','0.000238890000000','0.074901423413405','0.069876209783373','292.5037037271254','292.503703727125412','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 19:58:13
