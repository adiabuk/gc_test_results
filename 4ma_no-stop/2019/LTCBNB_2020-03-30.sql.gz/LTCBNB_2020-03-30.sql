-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 07:59:59','2019-01-04 15:59:59','LTCBNB','4h','5.460000000000000','5.240000000000000','0.711908500000000','0.683223542124542','0.13038617216117218','0.130386172161172','test'),('2019-01-05 03:59:59','2019-01-09 03:59:59','LTCBNB','4h','5.450000000000000','5.950000000000000','0.711908500000000','0.777221206422018','0.1306254128440367','0.130625412844037','test'),('2019-01-30 03:59:59','2019-02-01 03:59:59','LTCBNB','4h','5.100000000000000','5.040000000000000','0.721065437136640','0.712582314346797','0.14138537983071375','0.141385379830714','test'),('2019-02-10 15:59:59','2019-02-11 03:59:59','LTCBNB','4h','4.780000000000000','4.750000000000000','0.721065437136640','0.716539921840803','0.15085050986122173','0.150850509861222','test'),('2019-02-13 03:59:59','2019-02-13 11:59:59','LTCBNB','4h','4.840000000000000','4.700000000000000','0.721065437136640','0.700208172426076','0.14898046221831404','0.148980462218314','test'),('2019-02-14 15:59:59','2019-02-14 19:59:59','LTCBNB','4h','4.840000000000000','4.740000000000000','0.721065437136640','0.706167390914809','0.14898046221831404','0.148980462218314','test'),('2019-02-17 03:59:59','2019-02-17 15:59:59','LTCBNB','4h','4.850000000000000','4.780000000000000','0.721065437136640','0.710658307116111','0.14867328600755464','0.148673286007555','test'),('2019-02-18 11:59:59','2019-02-19 15:59:59','LTCBNB','4h','4.910000000000000','4.650000000000000','0.721065437136640','0.682882745964435','0.14685650450848065','0.146856504508481','test'),('2019-03-21 07:59:59','2019-03-22 15:59:59','LTCBNB','4h','3.970000000000000','3.960000000000000','0.721065437136640','0.719249151400779','0.1816285735860554','0.181628573586055','test'),('2019-03-23 11:59:59','2019-03-24 11:59:59','LTCBNB','4h','4.000000000000000','3.500000000000000','0.721065437136640','0.630932257494560','0.18026635928416','0.180266359284160','test'),('2019-04-03 11:59:59','2019-04-09 23:59:59','LTCBNB','4h','4.250000000000000','4.710000000000000','0.721065437136640','0.799110166803194','0.16966245579685646','0.169662455796856','test'),('2019-04-10 19:59:59','2019-04-11 07:59:59','LTCBNB','4h','4.900000000000000','4.730000000000000','0.721065437136640','0.696048881154348','0.14715621166053874','0.147156211660539','test'),('2019-05-04 23:59:59','2019-05-05 11:59:59','LTCBNB','4h','3.400000000000000','3.310000000000000','0.721065437136640','0.701978410859494','0.21207806974607057','0.212078069746071','test'),('2019-05-05 15:59:59','2019-05-05 19:59:59','LTCBNB','4h','3.320000000000000','3.350000000000000','0.721065437136640','0.727581088677031','0.21718838467971083','0.217188384679711','test'),('2019-05-06 15:59:59','2019-05-13 07:59:59','LTCBNB','4h','3.390000000000000','3.730000000000000','0.721065437136640','0.793384684519076','0.2127036687718702','0.212703668771870','test'),('2019-05-27 19:59:59','2019-05-30 03:59:59','LTCBNB','4h','3.470000000000000','3.370000000000000','0.721065437136640','0.700285453357486','0.20779983779153888','0.207799837791539','test'),('2019-05-30 07:59:59','2019-06-01 15:59:59','LTCBNB','4h','3.440000000000000','3.410000000000000','0.721065437136640','0.714777075766262','0.20961204567925582','0.209612045679256','test'),('2019-06-02 23:59:59','2019-06-04 11:59:59','LTCBNB','4h','3.450000000000000','3.400000000000000','0.721065437136640','0.710615213410022','0.2090044745323594','0.209004474532359','test'),('2019-06-05 07:59:59','2019-06-05 11:59:59','LTCBNB','4h','3.480000000000000','3.430000000000000','0.721065437136640','0.710705301545596','0.20720271182087355','0.207202711820874','test'),('2019-06-07 07:59:59','2019-06-12 23:59:59','LTCBNB','4h','3.610000000000000','3.890000000000000','0.721065437136640','0.776992950266352','0.1997411183203989','0.199741118320399','test'),('2019-06-14 15:59:59','2019-06-17 15:59:59','LTCBNB','4h','4.120000000000000','3.910000000000000','0.721065437136640','0.684312101748607','0.17501588280015531','0.175015882800155','test'),('2019-06-30 15:59:59','2019-07-01 11:59:59','LTCBNB','4h','4.040000000000000','3.670000000000000','0.721065437136640','0.655027265913730','0.17848154384570294','0.178481543845703','test'),('2019-07-01 15:59:59','2019-07-01 19:59:59','LTCBNB','4h','3.690000000000000','3.590000000000000','0.721065437136640','0.701524368379549','0.19541068757090513','0.195410687570905','test'),('2019-07-03 23:59:59','2019-07-04 03:59:59','LTCBNB','4h','3.740000000000000','3.680000000000000','0.721065437136640','0.709497542423218','0.1927982452237005','0.192798245223701','test'),('2019-07-04 07:59:59','2019-07-04 11:59:59','LTCBNB','4h','3.840000000000000','3.610000000000000','0.721065437136640','0.677876621891477','0.18777745758766667','0.187777457587667','test'),('2019-07-29 07:59:59','2019-08-02 19:59:59','LTCBNB','4h','3.299000000000000','3.343000000000000','0.721065437136640','0.730682557243949','0.2185709115297484','0.218570911529748','test'),('2019-08-03 19:59:59','2019-08-03 23:59:59','LTCBNB','4h','3.438000000000000','3.398000000000000','0.721065437136640','0.712676077774957','0.20973398404207094','0.209733984042071','test'),('2019-08-05 11:59:59','2019-08-06 03:59:59','LTCBNB','4h','3.608000000000000','3.421000000000000','0.721065437136640','0.683693143138704','0.199851839561153','0.199851839561153','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','LTCBNB','4h','3.489000000000000','3.445000000000000','0.721065437136640','0.711972035235232','0.2066682250319977','0.206668225031998','test'),('2019-08-25 23:59:59','2019-08-26 03:59:59','LTCBNB','4h','2.766000000000000','2.839000000000000','0.721065437136640','0.740095725246175','0.2606888782128127','0.260688878212813','test'),('2019-08-26 11:59:59','2019-08-28 03:59:59','LTCBNB','4h','2.780000000000000','2.840000000000000','0.721065437136640','0.736628000528078','0.2593760565239712','0.259376056523971','test'),('2019-08-28 07:59:59','2019-08-28 19:59:59','LTCBNB','4h','2.858000000000000','2.808000000000000','0.721065437136640','0.708450576444956','0.2522972138336739','0.252297213833674','test'),('2019-08-28 23:59:59','2019-08-30 11:59:59','LTCBNB','4h','2.858000000000000','2.859000000000000','0.721065437136640','0.721317734350474','0.2522972138336739','0.252297213833674','test'),('2019-08-30 23:59:59','2019-08-31 03:59:59','LTCBNB','4h','2.898000000000000','2.880000000000000','0.721065437136640','0.716586769825232','0.2488148506337612','0.248814850633761','test'),('2019-08-31 11:59:59','2019-09-02 15:59:59','LTCBNB','4h','2.902000000000000','2.959000000000000','0.721065437136640','0.735228335109344','0.24847189425797378','0.248471894257974','test'),('2019-09-02 19:59:59','2019-09-02 23:59:59','LTCBNB','4h','2.974000000000000','2.941000000000000','0.721065437136640','0.713064374787780','0.24245643481393406','0.242456434813934','test'),('2019-09-03 11:59:59','2019-09-05 15:59:59','LTCBNB','4h','3.066000000000000','2.990000000000000','0.721065437136640','0.703191668962346','0.23518116018807567','0.235181160188076','test'),('2019-09-07 19:59:59','2019-09-13 19:59:59','LTCBNB','4h','3.099000000000000','3.297000000000000','0.721065437136640','0.767135445704905','0.23267681095083573','0.232676810950836','test'),('2019-09-13 23:59:59','2019-09-14 03:59:59','LTCBNB','4h','3.318000000000000','3.309000000000000','0.721065437136640','0.719109563437354','0.21731929992062687','0.217319299920627','test'),('2019-09-14 15:59:59','2019-09-18 11:59:59','LTCBNB','4h','3.366000000000000','3.356000000000000','0.721065437136640','0.718923234411932','0.21422027247077835','0.214220272470778','test'),('2019-09-18 19:59:59','2019-09-21 03:59:59','LTCBNB','4h','3.594000000000000','3.492000000000000','0.721065437136640','0.700601142593530','0.200630338657941','0.200630338657941','test'),('2019-09-22 15:59:59','2019-09-23 23:59:59','LTCBNB','4h','3.565000000000000','3.443000000000000','0.721065437136640','0.696389424982174','0.20226239470873492','0.202262394708735','test'),('2019-09-25 15:59:59','2019-09-25 23:59:59','LTCBNB','4h','3.561000000000000','3.583000000000000','0.721065437136640','0.725520208160792','0.2024895920069194','0.202489592006919','test'),('2019-09-26 07:59:59','2019-09-26 11:59:59','LTCBNB','4h','3.576000000000000','3.516000000000000','0.721065437136640','0.708967023761864','0.20164022291293063','0.201640222912931','test'),('2019-09-26 15:59:59','2019-09-26 19:59:59','LTCBNB','4h','3.564000000000000','3.544000000000000','0.721065437136640','0.717019054212192','0.20231914622240177','0.202319146222402','test'),('2019-09-26 23:59:59','2019-09-28 07:59:59','LTCBNB','4h','3.629000000000000','3.525000000000000','0.721065437136640','0.700401120393126','0.1986953533030146','0.198695353303015','test'),('2019-09-30 07:59:59','2019-09-30 15:59:59','LTCBNB','4h','3.601000000000000','3.542000000000000','0.721065437136640','0.709251257522349','0.20024033244560954','0.200240332445610','test'),('2019-09-30 19:59:59','2019-09-30 23:59:59','LTCBNB','4h','3.551000000000000','3.536000000000000','0.721065437136640','0.718019539767716','0.20305982459494223','0.203059824594942','test'),('2019-10-02 19:59:59','2019-10-03 03:59:59','LTCBNB','4h','3.558000000000000','3.540000000000000','0.721065437136640','0.717417551282660','0.2026603252210905','0.202660325221091','test'),('2019-10-03 07:59:59','2019-10-03 11:59:59','LTCBNB','4h','3.548000000000000','3.550000000000000','0.721065437136640','0.721471900178994','0.2032315211771815','0.203231521177181','test'),('2019-10-03 15:59:59','2019-10-06 19:59:59','LTCBNB','4h','3.552000000000000','3.592000000000000','0.721065437136640','0.729185543410701','0.20300265685153152','0.203002656851532','test'),('2019-10-06 23:59:59','2019-10-07 03:59:59','LTCBNB','4h','3.615000000000000','3.623000000000000','0.721065437136640','0.722661155946348','0.19946485121345503','0.199464851213455','test'),('2019-10-07 07:59:59','2019-10-07 11:59:59','LTCBNB','4h','3.624000000000000','3.595000000000000','0.721065437136640','0.715295321883615','0.19896949148362028','0.198969491483620','test'),('2019-10-27 15:59:59','2019-10-28 03:59:59','LTCBNB','4h','3.131000000000000','2.920000000000000','0.721065437136640','0.672472397457358','0.23029876625251997','0.230298766252520','test'),('2019-11-05 07:59:59','2019-11-07 23:59:59','LTCBNB','4h','3.019000000000000','3.009000000000000','0.721065437136640','0.718677012369708','0.23884247669315664','0.238842476693157','test'),('2019-11-08 03:59:59','2019-11-11 15:59:59','LTCBNB','4h','3.055000000000000','3.084000000000000','0.721065437136640','0.727910248160196','0.2360279663295057','0.236027966329506','test'),('2019-11-11 19:59:59','2019-11-11 23:59:59','LTCBNB','4h','3.101000000000000','3.077000000000000','0.721065437136640','0.715484795249739','0.23252674528753303','0.232526745287533','test'),('2019-11-19 23:59:59','2019-11-22 03:59:59','LTCBNB','4h','2.983000000000000','2.959000000000000','0.721065437136640','0.715264039050391','0.24172492026035533','0.241724920260355','test'),('2019-11-22 15:59:59','2019-11-23 15:59:59','LTCBNB','4h','3.079000000000000','2.993000000000000','0.721065437136640','0.700925252793103','0.2341881900411302','0.234188190041130','test'),('2019-11-26 11:59:59','2019-11-27 19:59:59','LTCBNB','4h','3.020000000000000','2.991000000000000','0.721065437136640','0.714141298833010','0.23876338978034436','0.238763389780344','test'),('2019-11-29 03:59:59','2019-11-29 19:59:59','LTCBNB','4h','3.027000000000000','3.035000000000000','0.721065437136640','0.722971127092733','0.23821124451160883','0.238211244511609','test'),('2019-11-30 03:59:59','2019-11-30 07:59:59','LTCBNB','4h','3.011000000000000','3.009000000000000','0.721065437136640','0.720586483010345','0.23947706314733974','0.239477063147340','test'),('2019-11-30 11:59:59','2019-11-30 19:59:59','LTCBNB','4h','3.018000000000000','3.010000000000000','0.721065437136640','0.719154064208511','0.23892161601611664','0.238921616016117','test'),('2019-12-01 03:59:59','2019-12-02 07:59:59','LTCBNB','4h','3.053000000000000','3.022000000000000','0.721065437136640','0.713743776949534','0.2361825866808516','0.236182586680852','test'),('2019-12-12 03:59:59','2019-12-12 15:59:59','LTCBNB','4h','2.979000000000000','2.972000000000000','0.721065437136640','0.719371090691539','0.2420494921573145','0.242049492157314','test'),('2019-12-12 19:59:59','2019-12-13 11:59:59','LTCBNB','4h','2.982000000000000','2.965000000000000','0.721065437136640','0.716954735449409','0.24180598160182426','0.241805981601824','test'),('2019-12-13 15:59:59','2019-12-16 19:59:59','LTCBNB','4h','2.976000000000000','2.964000000000000','0.721065437136640','0.718157915212702','0.24229349366150535','0.242293493661505','test'),('2019-12-17 07:59:59','2019-12-17 19:59:59','LTCBNB','4h','3.040000000000000','3.014000000000000','0.721065437136640','0.714898430108498','0.23719257800547366','0.237192578005474','test'),('2019-12-19 03:59:59','2019-12-19 07:59:59','LTCBNB','4h','3.051000000000000','3.014000000000000','0.721065437136640','0.712320952976018','0.23633740974652243','0.236337409746522','test'),('2019-12-22 07:59:59','2019-12-24 15:59:59','LTCBNB','4h','3.052000000000000','3.004000000000000','0.721065437136640','0.709724958439864','0.23625997284948885','0.236259972849489','test'),('2019-12-25 07:59:59','2019-12-26 03:59:59','LTCBNB','4h','3.046000000000000','3.020000000000000','0.721065437136640','0.714910577857076','0.2367253569063165','0.236725356906316','test'),('2019-12-26 07:59:59','2019-12-26 11:59:59','LTCBNB','4h','3.042000000000000','3.015000000000000','0.721065437136640','0.714665448049628','0.23703663285228138','0.237036632852281','test'),('2019-12-26 19:59:59','2019-12-27 03:59:59','LTCBNB','4h','3.079000000000000','3.059000000000000','0.721065437136640','0.716381673335817','0.2341881900411302','0.234188190041130','test'),('2019-12-27 07:59:59','2019-12-29 15:59:59','LTCBNB','4h','3.079000000000000','3.044000000000000','0.721065437136640','0.712868850485200','0.2341881900411302','0.234188190041130','test'),('2019-12-29 19:59:59','2019-12-29 23:59:59','LTCBNB','4h','3.084000000000000','3.056000000000000','0.721065437136640','0.714518798926580','0.23380850750215304','0.233808507502153','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 10:28:44
