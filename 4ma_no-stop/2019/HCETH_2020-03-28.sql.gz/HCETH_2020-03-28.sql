-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-02-08 07:59:59','2019-02-12 03:59:59','HCETH','4h','0.008732000000000','0.009503000000000','0.072144500000000','0.078514565219881','8.262081997251489','8.262081997251489','test'),('2019-02-28 03:59:59','2019-02-28 11:59:59','HCETH','4h','0.008416000000000','0.008341000000000','0.073737016304970','0.073079901734762','8.761527602776884','8.761527602776884','test'),('2019-02-28 19:59:59','2019-03-04 11:59:59','HCETH','4h','0.008391000000000','0.008472000000000','0.073737016304970','0.074448814460220','8.787631546296032','8.787631546296032','test'),('2019-03-08 11:59:59','2019-03-11 19:59:59','HCETH','4h','0.008718000000000','0.009103000000000','0.073750687201231','0.077007628537830','8.45958788727125','8.459587887271249','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','HCETH','4h','0.009342000000000','0.009660000000000','0.074564922535380','0.077103099089250','7.981687276319899','7.981687276319899','test'),('2019-03-18 07:59:59','2019-03-18 11:59:59','HCETH','4h','0.009696000000000','0.009553000000000','0.075199466673848','0.074090398631938','7.755720572797855','7.755720572797855','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','HCETH','4h','0.009747000000000','0.009500000000000','0.075199466673848','0.073293827167493','7.7151397018413865','7.715139701841387','test'),('2019-03-21 19:59:59','2019-03-22 07:59:59','HCETH','4h','0.009638000000000','0.009529000000000','0.075199466673848','0.074349005803600','7.802393305026769','7.802393305026769','test'),('2019-03-22 11:59:59','2019-03-22 15:59:59','HCETH','4h','0.009570000000000','0.009569000000000','0.075199466673848','0.075191608840340','7.85783350823908','7.857833508239080','test'),('2019-03-22 19:59:59','2019-03-22 23:59:59','HCETH','4h','0.009626000000000','0.009556000000000','0.075199466673848','0.074652618277092','7.8121199536513615','7.812119953651361','test'),('2019-03-23 03:59:59','2019-03-25 19:59:59','HCETH','4h','0.009724000000000','0.010014000000000','0.075199466673848','0.077442149246392','7.7333881811855205','7.733388181185521','test'),('2019-03-31 19:59:59','2019-04-02 07:59:59','HCETH','4h','0.010394000000000','0.009921000000000','0.075199466673848','0.071777362793077','7.234891925519338','7.234891925519338','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','HCETH','4h','0.009974000000000','0.009780000000000','0.075199466673848','0.073736794071610','7.539549496074594','7.539549496074594','test'),('2019-04-05 03:59:59','2019-04-05 07:59:59','HCETH','4h','0.010162000000000','0.009886000000000','0.075199466673848','0.073157048566981','7.400065604590435','7.400065604590435','test'),('2019-04-05 15:59:59','2019-04-05 19:59:59','HCETH','4h','0.009850000000000','0.009918000000000','0.075199466673848','0.075718610200124','7.634463621710457','7.634463621710457','test'),('2019-04-06 03:59:59','2019-04-06 11:59:59','HCETH','4h','0.009986000000000','0.009834000000000','0.075199466673848','0.074054832292271','7.530489352478269','7.530489352478269','test'),('2019-05-30 23:59:59','2019-06-10 19:59:59','HCETH','4h','0.006050000000000','0.009519000000000','0.075199466673848','0.118317970788159','12.429663913032726','12.429663913032726','test'),('2019-06-14 07:59:59','2019-06-21 15:59:59','HCETH','4h','0.010123000000000','0.011235000000000','0.083546623322073','0.092724124570136','8.253148604373532','8.253148604373532','test'),('2019-06-22 19:59:59','2019-06-27 19:59:59','HCETH','4h','0.012409000000000','0.014303000000000','0.085840998634089','0.098943009385396','6.9176403121999375','6.917640312199937','test'),('2019-06-28 15:59:59','2019-06-30 15:59:59','HCETH','4h','0.017401000000000','0.015543000000000','0.089116501321916','0.079601044770217','5.121343676910279','5.121343676910279','test'),('2019-07-04 03:59:59','2019-07-07 19:59:59','HCETH','4h','0.016500000000000','0.015988000000000','0.089116501321916','0.086351189280897','5.401000080116121','5.401000080116121','test'),('2019-07-24 19:59:59','2019-07-25 11:59:59','HCETH','4h','0.014627000000000','0.013972000000000','0.089116501321916','0.085125846480468','6.0926028113704795','6.092602811370480','test'),('2019-07-27 03:59:59','2019-07-27 07:59:59','HCETH','4h','0.014144000000000','0.013982000000000','0.089116501321916','0.088095794788110','6.300657616085689','6.300657616085689','test'),('2019-08-17 19:59:59','2019-08-21 19:59:59','HCETH','4h','0.013163000000000','0.013970000000000','0.089116501321916','0.094580074714515','6.770227252291726','6.770227252291726','test'),('2019-10-27 15:59:59','2019-10-30 11:59:59','HCETH','4h','0.009887000000000','0.009117000000000','0.089116501321916','0.082176104233024','9.013502712846767','9.013502712846767','test'),('2019-10-31 19:59:59','2019-11-06 07:59:59','HCETH','4h','0.009600000000000','0.010274000000000','0.089116501321916','0.095373222352226','9.282968887699584','9.282968887699584','test'),('2019-11-12 07:59:59','2019-11-12 23:59:59','HCETH','4h','0.010207000000000','0.010090000000000','0.089116501321916','0.088094983671807','8.730920086403055','8.730920086403055','test'),('2019-11-13 01:59:59','2019-11-13 07:59:59','HCETH','4h','0.010240000000000','0.010129000000000','0.089116501321916','0.088150492372040','8.702783332218358','8.702783332218358','test'),('2019-11-13 11:59:59','2019-11-13 15:59:59','HCETH','4h','0.010153000000000','0.010012000000000','0.089116501321916','0.087878894044620','8.777356576570076','8.777356576570076','test'),('2019-12-07 19:59:59','2019-12-08 03:59:59','HCETH','4h','0.008407000000000','0.008343000000000','0.089116501321916','0.088438083802634','10.600273738779112','10.600273738779112','test'),('2019-12-08 11:59:59','2019-12-08 15:59:59','HCETH','4h','0.008398000000000','0.008368000000000','0.089116501321916','0.088798152305524','10.611633879723268','10.611633879723268','test'),('2019-12-14 03:59:59','2019-12-14 11:59:59','HCETH','4h','0.008426000000000','0.008168000000000','0.089116501321916','0.086387797626087','10.576370914065512','10.576370914065512','test'),('2019-12-14 19:59:59','2019-12-15 11:59:59','HCETH','4h','0.008227000000000','0.008219000000000','0.089116501321916','0.089029843729771','10.832199018100887','10.832199018100887','test'),('2019-12-16 15:59:59','2019-12-17 03:59:59','HCETH','4h','0.008436000000000','0.008202000000000','0.089116501321916','0.086644564229772','10.5638337271119','10.563833727111900','test'),('2019-12-17 11:59:59','2019-12-17 15:59:59','HCETH','4h','0.008344000000000','0.008321000000000','0.089116501321916','0.088870854206575','10.680309362645731','10.680309362645731','test'),('2019-12-17 19:59:59','2019-12-20 15:59:59','HCETH','4h','0.008528000000000','0.008647000000000','0.089116501321916','0.090360035990925','10.449871168142119','10.449871168142119','test'),('2019-12-21 03:59:59','2019-12-21 11:59:59','HCETH','4h','0.008600000000000','0.008608000000000','0.089116501321916','0.089199400392913','10.362383874641395','10.362383874641395','test'),('2019-12-24 03:59:59','2019-12-24 07:59:59','HCETH','4h','0.008661000000000','0.008653000000000','0.089116501321916','0.089034186114599','10.289400914665281','10.289400914665281','test'),('2019-12-24 11:59:59','2019-12-26 19:59:59','HCETH','4h','0.008670000000000','0.008658000000000','0.089116501321916','0.088993156683408','10.278719875653517','10.278719875653517','test'),('2019-12-26 23:59:59','2019-12-28 19:59:59','HCETH','4h','0.008766000000000','0.008716000000000','0.089116501321916','0.088608193648394','10.166153470444444','10.166153470444444','test'),('2020-01-08 11:59:59','2020-01-08 19:59:59','HCETH','4h','0.008479000000000','0.008432000000000','0.089116501321916','0.088622519064323','10.510260799848567','10.510260799848567','test'),('2020-01-10 23:59:59','2020-01-11 07:59:59','HCETH','4h','0.008516000000000','0.008452000000000','0.089116501321916','0.088446767164494','10.464596209713012','10.464596209713012','test'),('2020-01-11 15:59:59','2020-01-11 19:59:59','HCETH','4h','0.008593000000000','0.008453000000000','0.089116501321916','0.087664585787752','10.370825244026067','10.370825244026067','test'),('2020-01-12 03:59:59','2020-01-12 19:59:59','HCETH','4h','0.008492000000000','0.008494000000000','0.089116501321916','0.089137489664196','10.494171140121997','10.494171140121997','test'),('2020-01-13 03:59:59','2020-01-13 07:59:59','HCETH','4h','0.008486000000000','0.008317000000000','0.089116501321916','0.087341732441006','10.50159101130285','10.501591011302850','test'),('2020-01-15 03:59:59','2020-01-18 15:59:59','HCETH','4h','0.009394000000000','0.008735000000000','0.089116501321916','0.082864875350962','9.486534098564615','9.486534098564615','test'),('2020-01-27 03:59:59','2020-01-28 23:59:59','HCETH','4h','0.008865000000000','0.008835000000000','0.089116501321916','0.088814922637239','10.052622822551156','10.052622822551156','test'),('2020-01-29 07:59:59','2020-01-29 11:59:59','HCETH','4h','0.008889000000000','0.008741000000000','0.089116501321916','0.087632730122046','10.025481080202047','10.025481080202047','test'),('2020-01-29 19:59:59','2020-01-30 15:59:59','HCETH','4h','0.008942000000000','0.008824000000000','0.089116501321916','0.087940506336903','9.966059195025274','9.966059195025274','test'),('2020-01-30 19:59:59','2020-01-30 23:59:59','HCETH','4h','0.008997000000000','0.008965000000000','0.089116501321916','0.088799536995774','9.905135191943536','9.905135191943536','test'),('2020-01-31 03:59:59','2020-02-03 11:59:59','HCETH','4h','0.008997000000000','0.009173000000000','0.089116501321916','0.090859805115698','9.905135191943536','9.905135191943536','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:32:48
