-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 23:59:59','2019-01-06 19:59:59','PIVXBTC','4h','0.000238600000000','0.000225200000000','0.001467500000000','0.001385083822297','6.150461022632021','6.150461022632021','test'),('2019-01-24 07:59:59','2019-01-25 07:59:59','PIVXBTC','4h','0.000232600000000','0.000215200000000','0.001467500000000','0.001357721410146','6.309114359415306','6.309114359415306','test'),('2019-01-25 11:59:59','2019-01-25 15:59:59','PIVXBTC','4h','0.000215300000000','0.000215200000000','0.001467500000000','0.001466818392940','6.816070599163957','6.816070599163957','test'),('2019-02-10 19:59:59','2019-02-12 11:59:59','PIVXBTC','4h','0.000197500000000','0.000199000000000','0.001467500000000','0.001478645569620','7.4303797468354436','7.430379746835444','test'),('2019-02-12 15:59:59','2019-02-14 03:59:59','PIVXBTC','4h','0.000203000000000','0.000200000000000','0.001467500000000','0.001445812807882','7.229064039408867','7.229064039408867','test'),('2019-02-14 11:59:59','2019-02-14 15:59:59','PIVXBTC','4h','0.000199800000000','0.000197900000000','0.001467500000000','0.001453544794795','7.344844844844845','7.344844844844845','test'),('2019-02-17 03:59:59','2019-02-19 03:59:59','PIVXBTC','4h','0.000202800000000','0.000200000000000','0.001467500000000','0.001447238658777','7.236193293885602','7.236193293885602','test'),('2019-02-19 07:59:59','2019-02-20 07:59:59','PIVXBTC','4h','0.000204100000000','0.000202000000000','0.001467500000000','0.001452400783929','7.190102890739833','7.190102890739833','test'),('2019-03-03 23:59:59','2019-03-06 07:59:59','PIVXBTC','4h','0.000200200000000','0.000200000000000','0.001467500000000','0.001466033966034','7.330169830169831','7.330169830169831','test'),('2019-03-10 23:59:59','2019-03-11 07:59:59','PIVXBTC','4h','0.000203800000000','0.000200300000000','0.001467500000000','0.001442297595682','7.200686947988224','7.200686947988224','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','PIVXBTC','4h','0.000200900000000','0.000202700000000','0.001467500000000','0.001480648332504','7.304629168740667','7.304629168740667','test'),('2019-03-11 19:59:59','2019-03-12 01:59:59','PIVXBTC','4h','0.000203900000000','0.000201200000000','0.001467500000000','0.001448067680235','7.197155468366847','7.197155468366847','test'),('2019-03-12 11:59:59','2019-03-16 03:59:59','PIVXBTC','4h','0.000208500000000','0.000211500000000','0.001467500000000','0.001488615107914','7.038369304556356','7.038369304556356','test'),('2019-03-24 11:59:59','2019-03-25 11:59:59','PIVXBTC','4h','0.000216000000000','0.000210200000000','0.001467500000000','0.001428094907407','6.793981481481482','6.793981481481482','test'),('2019-03-26 19:59:59','2019-03-30 07:59:59','PIVXBTC','4h','0.000216000000000','0.000221500000000','0.001467500000000','0.001504866898148','6.793981481481482','6.793981481481482','test'),('2019-03-31 03:59:59','2019-04-02 07:59:59','PIVXBTC','4h','0.000231800000000','0.000212300000000','0.001467500000000','0.001344047670406','6.3308886971527185','6.330888697152719','test'),('2019-05-24 07:59:59','2019-05-24 19:59:59','PIVXBTC','4h','0.000089500000000','0.000087000000000','0.001467500000000','0.001426508379888','16.39664804469274','16.396648044692739','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','PIVXBTC','4h','0.000090500000000','0.000083500000000','0.001467500000000','0.001353991712707','16.215469613259668','16.215469613259668','test'),('2019-06-08 07:59:59','2019-06-10 11:59:59','PIVXBTC','4h','0.000087600000000','0.000086500000000','0.001467500000000','0.001449072488584','16.75228310502283','16.752283105022830','test'),('2019-06-10 15:59:59','2019-06-12 23:59:59','PIVXBTC','4h','0.000087900000000','0.000091200000000','0.001467500000000','0.001522593856655','16.69510807736064','16.695108077360640','test'),('2019-07-23 11:59:59','2019-07-27 23:59:59','PIVXBTC','4h','0.000048300000000','0.000048900000000','0.001467500000000','0.001485729813665','30.383022774327124','30.383022774327124','test'),('2019-07-28 19:59:59','2019-07-30 11:59:59','PIVXBTC','4h','0.000050900000000','0.000049700000000','0.001467500000000','0.001432902750491','28.83104125736739','28.831041257367389','test'),('2019-08-22 07:59:59','2019-08-25 23:59:59','PIVXBTC','4h','0.000033600000000','0.000033700000000','0.001467500000000','0.001471867559524','43.67559523809524','43.675595238095241','test'),('2019-08-31 07:59:59','2019-08-31 19:59:59','PIVXBTC','4h','0.000035100000000','0.000032900000000','0.001467500000000','0.001375519943020','41.80911680911681','41.809116809116809','test'),('2019-09-01 03:59:59','2019-09-01 07:59:59','PIVXBTC','4h','0.000032900000000','0.000032900000000','0.001467500000000','0.001467500000000','44.6048632218845','44.604863221884500','test'),('2019-09-02 15:59:59','2019-09-03 03:59:59','PIVXBTC','4h','0.000034200000000','0.000033500000000','0.001467500000000','0.001437463450292','42.9093567251462','42.909356725146203','test'),('2019-09-03 07:59:59','2019-09-03 11:59:59','PIVXBTC','4h','0.000033600000000','0.000032100000000','0.001467500000000','0.001401986607143','43.67559523809524','43.675595238095241','test'),('2019-09-07 19:59:59','2019-09-08 11:59:59','PIVXBTC','4h','0.000033200000000','0.000032900000000','0.001467500000000','0.001454239457831','44.20180722891566','44.201807228915662','test'),('2019-09-08 15:59:59','2019-09-09 03:59:59','PIVXBTC','4h','0.000033000000000','0.000033100000000','0.001467500000000','0.001471946969697','44.46969696969697','44.469696969696969','test'),('2019-09-09 07:59:59','2019-09-09 11:59:59','PIVXBTC','4h','0.000033400000000','0.000030600000000','0.001467500000000','0.001344476047904','43.937125748503','43.937125748503000','test'),('2019-10-02 15:59:59','2019-10-10 11:59:59','PIVXBTC','4h','0.000028030000000','0.000030560000000','0.001467500000000','0.001599957188726','52.35462004994648','52.354620049946483','test'),('2019-10-12 23:59:59','2019-10-13 15:59:59','PIVXBTC','4h','0.000031720000000','0.000030850000000','0.001467500000000','0.001427250157629','46.264186633039095','46.264186633039095','test'),('2019-10-15 07:59:59','2019-10-16 03:59:59','PIVXBTC','4h','0.000031650000000','0.000031590000000','0.001467500000000','0.001464718009479','46.366508688783576','46.366508688783576','test'),('2019-11-03 23:59:59','2019-11-04 23:59:59','PIVXBTC','4h','0.000027750000000','0.000026620000000','0.001467500000000','0.001407742342342','52.88288288288288','52.882882882882882','test'),('2019-11-09 07:59:59','2019-11-09 15:59:59','PIVXBTC','4h','0.000027090000000','0.000026140000000','0.001467500000000','0.001416037283130','54.171280915466966','54.171280915466966','test'),('2019-11-09 19:59:59','2019-11-09 23:59:59','PIVXBTC','4h','0.000026400000000','0.000026080000000','0.001467500000000','0.001449712121212','55.58712121212121','55.587121212121211','test'),('2019-11-11 19:59:59','2019-11-12 15:59:59','PIVXBTC','4h','0.000027200000000','0.000026300000000','0.001467500000000','0.001418943014706','53.95220588235294','53.952205882352942','test'),('2019-11-12 19:59:59','2019-11-12 23:59:59','PIVXBTC','4h','0.000026410000000','0.000026340000000','0.001467500000000','0.001463610374858','55.566073457023855','55.566073457023855','test'),('2019-11-13 11:59:59','2019-11-17 15:59:59','PIVXBTC','4h','0.000026920000000','0.000027850000000','0.001467500000000','0.001518197436850','54.513372956909365','54.513372956909365','test'),('2019-11-21 03:59:59','2019-11-21 15:59:59','PIVXBTC','4h','0.000028200000000','0.000027260000000','0.001467500000000','0.001418583333333','52.03900709219858','52.039007092198581','test'),('2019-11-26 11:59:59','2019-11-28 19:59:59','PIVXBTC','4h','0.000034450000000','0.000030340000000','0.001467500000000','0.001292422351234','42.59796806966619','42.597968069666187','test'),('2019-11-30 03:59:59','2019-11-30 11:59:59','PIVXBTC','4h','0.000031830000000','0.000029510000000','0.001467500000000','0.001360538014452','46.104304115614205','46.104304115614205','test'),('2019-12-01 19:59:59','2019-12-02 07:59:59','PIVXBTC','4h','0.000030950000000','0.000029750000000','0.001467500000000','0.001410601777060','47.415185783521814','47.415185783521814','test'),('2019-12-09 07:59:59','2019-12-09 11:59:59','PIVXBTC','4h','0.000029760000000','0.000029570000000','0.001467500000000','0.001458130880376','49.311155913978496','49.311155913978496','test'),('2019-12-09 15:59:59','2019-12-10 03:59:59','PIVXBTC','4h','0.000031300000000','0.000029120000000','0.001467500000000','0.001365290734824','46.884984025559106','46.884984025559106','test'),('2019-12-13 19:59:59','2019-12-14 19:59:59','PIVXBTC','4h','0.000030660000000','0.000031210000000','0.001467500000000','0.001493825016308','47.86366601435095','47.863666014350947','test'),('2019-12-15 07:59:59','2019-12-16 07:59:59','PIVXBTC','4h','0.000031180000000','0.000030160000000','0.001467500000000','0.001419493264913','47.06542655548428','47.065426555484279','test'),('2019-12-16 23:59:59','2019-12-17 03:59:59','PIVXBTC','4h','0.000030740000000','0.000030430000000','0.001467500000000','0.001452700878334','47.73910214703969','47.739102147039688','test'),('2019-12-17 07:59:59','2019-12-18 15:59:59','PIVXBTC','4h','0.000032850000000','0.000031500000000','0.001467500000000','0.001407191780822','44.67275494672755','44.672754946727551','test'),('2019-12-20 19:59:59','2019-12-21 11:59:59','PIVXBTC','4h','0.000031470000000','0.000030510000000','0.000978333333333','0.000948489037178','31.087808494862834','31.087808494862834','test'),('2019-12-21 15:59:59','2019-12-22 03:59:59','PIVXBTC','4h','0.000030950000000','0.000030860000000','0.001090834775137','0.001087662719248','35.24506543255249','35.245065432552487','test'),('2019-12-22 11:59:59','2019-12-22 15:59:59','PIVXBTC','4h','0.000030880000000','0.000030650000000','0.001090834775137','0.001082710034260','35.32496033474741','35.324960334747409','test'),('2019-12-26 23:59:59','2019-12-28 03:59:59','PIVXBTC','4h','0.000030900000000','0.000030810000000','0.001090834775137','0.001087657586472','35.30209628275082','35.302096282750817','test'),('2019-12-28 07:59:59','2019-12-28 15:59:59','PIVXBTC','4h','0.000031140000000','0.000031240000000','0.001090834775137','0.001094337776984','35.03001846939628','35.030018469396282','test'),('2019-12-28 23:59:59','2019-12-29 03:59:59','PIVXBTC','4h','0.000031230000000','0.000031060000000','0.001090834775137','0.001084896833678','34.92906740752482','34.929067407524819','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:17:58
