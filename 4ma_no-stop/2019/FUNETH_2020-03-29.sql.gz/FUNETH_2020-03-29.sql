-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-10 11:59:59','2019-01-14 19:59:59','FUNETH','4h','0.000032150000000','0.000032950000000','0.072144500000000','0.073939697511664','2243.996889580093','2243.996889580093011','test'),('2019-01-16 03:59:59','2019-01-23 23:59:59','FUNETH','4h','0.000033870000000','0.000039270000000','0.072593299377916','0.084167076072358','2143.2919804522','2143.291980452199823','test'),('2019-03-02 07:59:59','2019-03-06 11:59:59','FUNETH','4h','0.000028500000000','0.000029390000000','0.075486743551527','0.077844048876469','2648.6576684746137','2648.657668474613729','test'),('2019-03-10 15:59:59','2019-03-16 07:59:59','FUNETH','4h','0.000030090000000','0.000032300000000','0.076076069882762','0.081663577840253','2528.2841436610834','2528.284143661083363','test'),('2019-03-16 11:59:59','2019-03-18 15:59:59','FUNETH','4h','0.000033400000000','0.000032880000000','0.077472946872135','0.076266781232210','2319.5493075489444','2319.549307548944398','test'),('2019-03-20 07:59:59','2019-03-21 15:59:59','FUNETH','4h','0.000033560000000','0.000032670000000','0.077472946872135','0.075418390176181','2308.4906696106978','2308.490669610697751','test'),('2019-03-22 23:59:59','2019-03-23 03:59:59','FUNETH','4h','0.000033400000000','0.000033040000000','0.077472946872135','0.076637909121417','2319.549307548952','2319.549307548952129','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','FUNETH','4h','0.000033230000000','0.000033040000000','0.077472946872135','0.077029977871061','2331.41579512895','2331.415795128949867','test'),('2019-03-25 19:59:59','2019-03-26 15:59:59','FUNETH','4h','0.000033460000000','0.000033140000000','0.077472946872135','0.076732022096311','2315.389924451136','2315.389924451135812','test'),('2019-03-26 19:59:59','2019-03-28 07:59:59','FUNETH','4h','0.000034600000000','0.000033460000000','0.077472946872135','0.074920370009874','2239.102510755347','2239.102510755346884','test'),('2019-03-28 19:59:59','2019-03-29 15:59:59','FUNETH','4h','0.000034960000000','0.000034450000000','0.077472946872135','0.076342763722685','2216.0453910793767','2216.045391079376714','test'),('2019-03-29 19:59:59','2019-03-30 03:59:59','FUNETH','4h','0.000034660000000','0.000033680000000','0.077472946872135','0.075282425004429','2235.2263956184365','2235.226395618436527','test'),('2019-03-30 23:59:59','2019-04-02 15:59:59','FUNETH','4h','0.000035420000000','0.000034940000000','0.077472946872135','0.076423059393348','2187.2655808056184','2187.265580805618356','test'),('2019-04-06 03:59:59','2019-04-06 15:59:59','FUNETH','4h','0.000035780000000','0.000034720000000','0.077472946872135','0.075177772929025','2165.258436895892','2165.258436895891919','test'),('2019-04-06 23:59:59','2019-04-07 03:59:59','FUNETH','4h','0.000034760000000','0.000034890000000','0.077472946872135','0.077762690344327','2228.795939934839','2228.795939934839225','test'),('2019-04-07 07:59:59','2019-04-07 19:59:59','FUNETH','4h','0.000035100000000','0.000034860000000','0.077472946872135','0.076943217320873','2207.20646359359','2207.206463593589888','test'),('2019-04-23 03:59:59','2019-04-25 15:59:59','FUNETH','4h','0.000034500000000','0.000033780000000','0.077472946872135','0.075856120154803','2245.592662960435','2245.592662960435064','test'),('2019-04-25 19:59:59','2019-04-25 23:59:59','FUNETH','4h','0.000034090000000','0.000033510000000','0.077472946872135','0.076154838653131','2272.600377592696','2272.600377592696077','test'),('2019-04-28 07:59:59','2019-04-28 19:59:59','FUNETH','4h','0.000034370000000','0.000032260000000','0.077472946872135','0.072716824733636','2254.0863215634276','2254.086321563427646','test'),('2019-05-01 03:59:59','2019-05-02 07:59:59','FUNETH','4h','0.000034220000000','0.000033680000000','0.077472946872135','0.076250404753171','2263.966886970631','2263.966886970631094','test'),('2019-05-02 15:59:59','2019-05-02 23:59:59','FUNETH','4h','0.000033800000000','0.000034120000000','0.077472946872135','0.078206418558498','2292.0990198856507','2292.099019885650705','test'),('2019-05-03 07:59:59','2019-05-03 11:59:59','FUNETH','4h','0.000034330000000','0.000033530000000','0.077472946872135','0.075667576714905','2256.712696537577','2256.712696537576903','test'),('2019-05-05 03:59:59','2019-05-06 03:59:59','FUNETH','4h','0.000034200000000','0.000034030000000','0.077472946872135','0.077087847428619','2265.290844214474','2265.290844214473964','test'),('2019-05-06 07:59:59','2019-05-06 11:59:59','FUNETH','4h','0.000034080000000','0.000033350000000','0.077472946872135','0.075813461801224','2273.267220426497','2273.267220426496806','test'),('2019-06-07 03:59:59','2019-06-11 19:59:59','FUNETH','4h','0.000025240000000','0.000025990000000','0.077472946872135','0.079775035230063','3069.4511439039225','3069.451143903922457','test'),('2019-07-15 03:59:59','2019-07-15 19:59:59','FUNETH','4h','0.000014190000000','0.000014000000000','0.077472946872135','0.076435606498230','5459.686178445032','5459.686178445032056','test'),('2019-07-16 11:59:59','2019-07-16 15:59:59','FUNETH','4h','0.000014250000000','0.000013710000000','0.077472946872135','0.074537129938033','5436.698026114736','5436.698026114736422','test'),('2019-07-19 03:59:59','2019-07-19 23:59:59','FUNETH','4h','0.000014980000000','0.000014790000000','0.077472946872135','0.076490312699524','5171.758803213284','5171.758803213284409','test'),('2019-07-20 07:59:59','2019-07-22 15:59:59','FUNETH','4h','0.000014670000000','0.000014810000000','0.077472946872135','0.078212293331719','5281.046139886504','5281.046139886503624','test'),('2019-08-16 07:59:59','2019-08-18 19:59:59','FUNETH','4h','0.000012310000000','0.000011910000000','0.077472946872135','0.074955548111058','6293.496902691714','6293.496902691714240','test'),('2019-08-20 03:59:59','2019-08-20 07:59:59','FUNETH','4h','0.000012480000000','0.000011830000000','0.077472946872135','0.073437897555878','6207.768178856971','6207.768178856970735','test'),('2019-08-21 11:59:59','2019-08-22 03:59:59','FUNETH','4h','0.000012110000000','0.000012010000000','0.077472946872135','0.076833203297633','6397.4357450152775','6397.435745015277462','test'),('2019-08-22 11:59:59','2019-08-27 11:59:59','FUNETH','4h','0.000012620000000','0.000016110000000','0.077472946872135','0.098897715856584','6138.902287807845','6138.902287807844914','test'),('2019-09-01 03:59:59','2019-09-01 15:59:59','FUNETH','4h','0.000015690000000','0.000015220000000','0.077472946872135','0.075152214875328','4937.727652781071','4937.727652781070901','test'),('2019-09-10 07:59:59','2019-09-11 19:59:59','FUNETH','4h','0.000016450000000','0.000015100000000','0.077472946872135','0.071114984666823','4709.601633564438','4709.601633564438089','test'),('2019-09-12 19:59:59','2019-09-15 11:59:59','FUNETH','4h','0.000015970000000','0.000015750000000','0.077472946872135','0.076405692751166','4851.155095312148','4851.155095312147751','test'),('2019-09-19 07:59:59','2019-09-20 11:59:59','FUNETH','4h','0.000016330000000','0.000015820000000','0.077472946872135','0.075053399847959','4744.209851324862','4744.209851324862029','test'),('2019-09-20 15:59:59','2019-09-22 23:59:59','FUNETH','4h','0.000015950000000','0.000016060000000','0.077472946872135','0.078007243057460','4857.2380484097175','4857.238048409717521','test'),('2019-09-25 15:59:59','2019-10-05 23:59:59','FUNETH','4h','0.000016780000000','0.000021720000000','0.077472946872135','0.100280834687889','4616.9813392213955','4616.981339221395501','test'),('2019-10-07 23:59:59','2019-10-09 15:59:59','FUNETH','4h','0.000022000000000','0.000021750000000','0.077472946872135','0.076592572475861','3521.497585097046','3521.497585097045885','test'),('2019-10-09 23:59:59','2019-10-10 19:59:59','FUNETH','4h','0.000022290000000','0.000022020000000','0.077472946872135','0.076534512791584','3475.6817798176317','3475.681779817631650','test'),('2019-10-11 19:59:59','2019-10-12 03:59:59','FUNETH','4h','0.000022430000000','0.000022010000000','0.077472946872135','0.076022271986433','3453.9878231000894','3453.987823100089372','test'),('2019-10-12 11:59:59','2019-10-13 03:59:59','FUNETH','4h','0.000022280000000','0.000022530000000','0.077472946872135','0.078342257317289','3477.241780616472','3477.241780616472170','test'),('2019-11-05 19:59:59','2019-11-08 23:59:59','FUNETH','4h','0.000018680000000','0.000019140000000','0.077472946872135','0.079380738925731','4147.374029557548','4147.374029557548056','test'),('2019-11-09 03:59:59','2019-11-10 19:59:59','FUNETH','4h','0.000020400000000','0.000020980000000','0.077472946872135','0.079675609087127','3797.693474124265','3797.693474124264867','test'),('2019-11-10 23:59:59','2019-11-12 23:59:59','FUNETH','4h','0.000021020000000','0.000020290000000','0.077472946872135','0.074782402094939','3685.677776980733','3685.677776980733142','test'),('2019-11-17 07:59:59','2019-11-17 11:59:59','FUNETH','4h','0.000020550000000','0.000020040000000','0.077472946872135','0.075550260599396','3769.9730838021896','3769.973083802189649','test'),('2019-11-19 07:59:59','2019-11-20 07:59:59','FUNETH','4h','0.000020540000000','0.000020240000000','0.077472946872135','0.076341404318014','3771.808513735881','3771.808513735881206','test'),('2019-11-22 15:59:59','2019-11-23 19:59:59','FUNETH','4h','0.000020610000000','0.000020430000000','0.077472946872135','0.076796327248798','3758.997907430131','3758.997907430130908','test'),('2019-11-23 23:59:59','2019-11-24 03:59:59','FUNETH','4h','0.000020520000000','0.000020240000000','0.077472946872135','0.076415811144835','3775.4847403574563','3775.484740357456303','test'),('2019-11-24 07:59:59','2019-11-24 11:59:59','FUNETH','4h','0.000020360000000','0.000020190000000','0.077472946872135','0.076826070596680','3805.1545614997544','3805.154561499754436','test'),('2019-12-04 19:59:59','2019-12-09 07:59:59','FUNETH','4h','0.000021490000000','0.000023160000000','0.077472946872135','0.083493413194911','3605.069654357143','3605.069654357143008','test'),('2019-12-10 23:59:59','2019-12-14 19:59:59','FUNETH','4h','0.000024640000000','0.000024510000000','0.077472946872135','0.077064201616722','3144.1942724080764','3144.194272408076358','test'),('2019-12-19 23:59:59','2019-12-21 19:59:59','FUNETH','4h','0.000025740000000','0.000025390000000','0.077472946872135','0.076419507423602','3009.8269958094406','3009.826995809440632','test'),('2019-12-25 03:59:59','2019-12-25 23:59:59','FUNETH','4h','0.000025990000000','0.000025100000000','0.077472946872135','0.074819967929611','2980.875216319161','2980.875216319161154','test'),('2019-12-26 03:59:59','2019-12-26 07:59:59','FUNETH','4h','0.000025150000000','0.000025090000000','0.077472946872135','0.077288120756337','3080.4352633055664','3080.435263305566423','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','FUNETH','4h','0.000025150000000','0.000024920000000','0.077472946872135','0.076764446761575','3080.4352633055664','3080.435263305566423','test'),('2019-12-27 03:59:59','2019-12-28 11:59:59','FUNETH','4h','0.000025370000000','0.000025120000000','0.077472946872135','0.076709516177691','3053.72277777434','3053.722777774340102','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  7:46:27
