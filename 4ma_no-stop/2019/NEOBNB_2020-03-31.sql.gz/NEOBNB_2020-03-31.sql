-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 03:59:59','2019-01-08 11:59:59','NEOBNB','4h','1.390000000000000','1.384000000000000','0.711908500000000','0.708835513669065','0.5121643884892088','0.512164388489209','test'),('2019-01-08 23:59:59','2019-01-10 07:59:59','NEOBNB','4h','1.383000000000000','1.374000000000000','0.711908500000000','0.707275689804772','0.5147566883586406','0.514756688358641','test'),('2019-02-18 11:59:59','2019-02-18 23:59:59','NEOBNB','4h','0.918000000000000','0.918000000000000','0.711908500000000','0.711908500000000','0.7754994553376907','0.775499455337691','test'),('2019-02-19 07:59:59','2019-02-19 15:59:59','NEOBNB','4h','0.921000000000000','0.882000000000000','0.711908500000000','0.681762537459283','0.7729733984799132','0.772973398479913','test'),('2019-02-24 19:59:59','2019-02-25 11:59:59','NEOBNB','4h','0.947000000000000','0.900000000000000','0.711908500000000','0.676576187961985','0.7517513199577615','0.751751319957761','test'),('2019-02-25 15:59:59','2019-02-27 15:59:59','NEOBNB','4h','0.909000000000000','0.905000000000000','0.711908500000000','0.708775789328933','0.7831776677667767','0.783177667766777','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','NEOBNB','4h','0.617000000000000','0.607000000000000','0.711908500000000','0.700370274716370','1.153822528363047','1.153822528363047','test'),('2019-03-23 11:59:59','2019-03-23 19:59:59','NEOBNB','4h','0.616000000000000','0.613000000000000','0.711908500000000','0.708441413149351','1.155695616883117','1.155695616883117','test'),('2019-03-23 23:59:59','2019-03-24 07:59:59','NEOBNB','4h','0.618000000000000','0.611000000000000','0.711908500000000','0.703844811488673','1.151955501618123','1.151955501618123','test'),('2019-04-03 03:59:59','2019-04-09 15:59:59','NEOBNB','4h','0.640000000000000','0.673000000000000','0.711908500000000','0.748616282031250','1.11235703125','1.112357031250000','test'),('2019-04-10 19:59:59','2019-04-11 03:59:59','NEOBNB','4h','0.689000000000000','0.660000000000000','0.711908500000000','0.681944281567489','1.0332489114658927','1.033248911465893','test'),('2019-05-09 15:59:59','2019-05-12 15:59:59','NEOBNB','4h','0.443000000000000','0.445000000000000','0.711908500000000','0.715122533860045','1.6070169300225734','1.607016930022573','test'),('2019-05-12 19:59:59','2019-05-12 23:59:59','NEOBNB','4h','0.457000000000000','0.446000000000000','0.711908500000000','0.694772846827134','1.5577866520787746','1.557786652078775','test'),('2019-05-14 23:59:59','2019-05-15 02:59:59','NEOBNB','4h','0.468000000000000','0.436000000000000','0.711908500000000','0.663230995726496','1.5211720085470086','1.521172008547009','test'),('2019-05-15 15:59:59','2019-05-17 03:59:59','NEOBNB','4h','0.458000000000000','0.467000000000000','0.711908500000000','0.725897968340611','1.5543853711790394','1.554385371179039','test'),('2019-05-30 03:59:59','2019-06-03 23:59:59','NEOBNB','4h','0.407000000000000','0.404000000000000','0.711908500000000','0.706661017199017','1.749160933660934','1.749160933660934','test'),('2019-06-14 23:59:59','2019-06-17 23:59:59','NEOBNB','4h','0.415000000000000','0.419000000000000','0.711908500000000','0.718770268674699','1.715442168674699','1.715442168674699','test'),('2019-06-22 23:59:59','2019-06-27 23:59:59','NEOBNB','4h','0.461000000000000','0.500000000000000','0.711908500000000','0.772135032537961','1.544270065075922','1.544270065075922','test'),('2019-06-28 11:59:59','2019-06-30 07:59:59','NEOBNB','4h','0.527000000000000','0.520000000000000','0.711908500000000','0.702452409867173','1.3508700189753322','1.350870018975332','test'),('2019-07-02 15:59:59','2019-07-04 15:59:59','NEOBNB','4h','0.552000000000000','0.527000000000000','0.711908500000000','0.679666267210145','1.289689311594203','1.289689311594203','test'),('2019-07-09 03:59:59','2019-07-09 11:59:59','NEOBNB','4h','0.536000000000000','0.526000000000000','0.711908500000000','0.698626625000000','1.3281875','1.328187500000000','test'),('2019-07-09 15:59:59','2019-07-10 15:59:59','NEOBNB','4h','0.529000000000000','0.512000000000000','0.711908500000000','0.689030533081285','1.3457627599243858','1.345762759924386','test'),('2019-07-31 07:59:59','2019-07-31 19:59:59','NEOBNB','4h','0.423900000000000','0.421800000000000','0.711908500000000','0.708381706298655','1.6794255720688842','1.679425572068884','test'),('2019-07-31 23:59:59','2019-08-01 07:59:59','NEOBNB','4h','0.422200000000000','0.414100000000000','0.711908500000000','0.698250378612032','1.6861878256750356','1.686187825675036','test'),('2019-08-02 15:59:59','2019-08-02 19:59:59','NEOBNB','4h','0.423500000000000','0.414600000000000','0.711908500000000','0.696947494923259','1.681011806375443','1.681011806375443','test'),('2019-08-03 03:59:59','2019-08-06 03:59:59','NEOBNB','4h','0.424800000000000','0.422300000000000','0.711908500000000','0.707718831332392','1.6758674670433147','1.675867467043315','test'),('2019-08-06 07:59:59','2019-08-06 11:59:59','NEOBNB','4h','0.434200000000000','0.425300000000000','0.711908500000000','0.697316179295256','1.6395865960386922','1.639586596038692','test'),('2019-08-23 23:59:59','2019-08-26 07:59:59','NEOBNB','4h','0.366600000000000','0.362200000000000','0.711908500000000','0.703364044462630','1.9419217130387345','1.941921713038735','test'),('2019-08-26 15:59:59','2019-08-28 03:59:59','NEOBNB','4h','0.376000000000000','0.378100000000000','0.711908500000000','0.715884584707447','1.8933736702127661','1.893373670212766','test'),('2019-08-28 15:59:59','2019-09-03 07:59:59','NEOBNB','4h','0.375400000000000','0.405200000000000','0.711908500000000','0.768421215237081','1.896399840170485','1.896399840170485','test'),('2019-09-03 11:59:59','2019-09-05 15:59:59','NEOBNB','4h','0.406800000000000','0.404200000000000','0.711908500000000','0.707358445673550','1.750020894788594','1.750020894788594','test'),('2019-09-08 11:59:59','2019-09-09 03:59:59','NEOBNB','4h','0.410300000000000','0.404800000000000','0.711908500000000','0.702365490616622','1.7350926151596395','1.735092615159640','test'),('2019-09-09 07:59:59','2019-09-10 19:59:59','NEOBNB','4h','0.406300000000000','0.405700000000000','0.711908500000000','0.710857195299040','1.7521745015998034','1.752174501599803','test'),('2019-09-11 07:59:59','2019-09-18 11:59:59','NEOBNB','4h','0.411000000000000','0.433700000000000','0.711908500000000','0.751228020559611','1.732137469586375','1.732137469586375','test'),('2019-09-18 15:59:59','2019-09-20 11:59:59','NEOBNB','4h','0.448900000000000','0.446800000000000','0.711908500000000','0.708578119402985','1.5858955223880598','1.585895522388060','test'),('2019-09-21 19:59:59','2019-09-21 23:59:59','NEOBNB','4h','0.452500000000000','0.448400000000000','0.711908500000000','0.705458058342541','1.573278453038674','1.573278453038674','test'),('2019-09-23 15:59:59','2019-09-23 23:59:59','NEOBNB','4h','0.456600000000000','0.446200000000000','0.711908500000000','0.695693326106001','1.5591513359614544','1.559151335961454','test'),('2019-09-24 03:59:59','2019-09-24 15:59:59','NEOBNB','4h','0.450500000000000','0.438500000000000','0.711908500000000','0.692945343507214','1.580263041065483','1.580263041065483','test'),('2019-09-25 03:59:59','2019-10-02 15:59:59','NEOBNB','4h','0.457000000000000','0.473400000000000','0.711908500000000','0.737456201094092','1.5577866520787746','1.557786652078775','test'),('2019-10-02 23:59:59','2019-10-03 11:59:59','NEOBNB','4h','0.480100000000000','0.472400000000000','0.711908500000000','0.700490679858363','1.4828337846282025','1.482833784628202','test'),('2019-10-06 15:59:59','2019-10-06 19:59:59','NEOBNB','4h','0.475000000000000','0.469900000000000','0.711908500000000','0.704264850842105','1.4987547368421055','1.498754736842105','test'),('2019-10-06 23:59:59','2019-10-07 11:59:59','NEOBNB','4h','0.474800000000000','0.471700000000000','0.711908500000000','0.707260403222409','1.499386057287279','1.499386057287279','test'),('2019-10-24 07:59:59','2019-10-25 03:59:59','NEOBNB','4h','0.412500000000000','0.400000000000000','0.711908500000000','0.690335515151515','1.7258387878787882','1.725838787878788','test'),('2019-10-25 23:59:59','2019-10-29 19:59:59','NEOBNB','4h','0.419000000000000','0.516000000000000','0.711908500000000','0.876717866348449','1.699065632458234','1.699065632458234','test'),('2019-10-30 19:59:59','2019-10-31 15:59:59','NEOBNB','4h','0.570200000000000','0.526200000000000','0.711908500000000','0.656973435110488','1.2485242020343739','1.248524202034374','test'),('2019-11-02 03:59:59','2019-11-05 15:59:59','NEOBNB','4h','0.545700000000000','0.539700000000000','0.711908500000000','0.704081028862012','1.3045785229979845','1.304578522997984','test'),('2019-11-08 15:59:59','2019-11-09 15:59:59','NEOBNB','4h','0.542000000000000','0.536000000000000','0.711908500000000','0.704027594095941','1.3134843173431734','1.313484317343173','test'),('2019-11-11 15:59:59','2019-11-15 19:59:59','NEOBNB','4h','0.555100000000000','0.592800000000000','0.711908500000000','0.760258257611241','1.282486939290218','1.282486939290218','test'),('2019-11-16 03:59:59','2019-11-18 03:59:59','NEOBNB','4h','0.593800000000000','0.595000000000000','0.711908500000000','0.713347183395083','1.198902829235433','1.198902829235433','test'),('2019-11-19 15:59:59','2019-11-22 19:59:59','NEOBNB','4h','0.622500000000000','0.623000000000000','0.711908500000000','0.712480314056225','1.1436281124497991','1.143628112449799','test'),('2019-12-13 07:59:59','2019-12-21 03:59:59','NEOBNB','4h','0.591500000000000','0.635300000000000','0.711908500000000','0.764624632375317','1.2035646661031276','1.203564666103128','test'),('2019-12-22 07:59:59','2019-12-24 03:59:59','NEOBNB','4h','0.648000000000000','0.641800000000000','0.712026168975323','0.705213572914139','1.0988058163199423','1.098805816319942','test'),('2019-12-24 15:59:59','2019-12-27 07:59:59','NEOBNB','4h','0.649000000000000','0.648400000000000','0.712026168975323','0.711367901330662','1.0971127411021926','1.097112741102193','test'),('2019-12-27 11:59:59','2019-12-28 11:59:59','NEOBNB','4h','0.655100000000000','0.646200000000000','0.712026168975323','0.702352786432382','1.086896914937144','1.086896914937144','test'),('2019-12-29 07:59:59','2019-12-29 15:59:59','NEOBNB','4h','0.664800000000000','0.655200000000000','0.712026168975323','0.701744202636329','1.0710381603118577','1.071038160311858','test'),('2019-12-29 19:59:59','2019-12-30 03:59:59','NEOBNB','4h','0.662200000000000','0.637900000000000','0.712026168975323','0.685897754740801','1.0752433841367004','1.075243384136700','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-31  9:58:11
