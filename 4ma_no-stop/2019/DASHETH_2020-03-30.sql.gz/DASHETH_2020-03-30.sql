-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 11:59:59','2019-01-14 15:59:59','DASHETH','4h','0.584910000000000','0.556990000000000','0.072144500000000','0.068700766023833','0.1233429074558479','0.123342907455848','test'),('2019-01-16 19:59:59','2019-01-20 15:59:59','DASHETH','4h','0.580370000000000','0.585920000000000','0.072144500000000','0.072834408118959','0.12430776918172888','0.124307769181729','test'),('2019-01-21 07:59:59','2019-01-27 19:59:59','DASHETH','4h','0.587700000000000','0.620830000000000','0.072144500000000','0.076211451310192','0.12275735919686916','0.122757359196869','test'),('2019-01-28 03:59:59','2019-01-28 07:59:59','DASHETH','4h','0.629360000000000','0.624240000000000','0.072472781363246','0.071883197276905','0.11515314186355345','0.115153141863553','test'),('2019-01-28 11:59:59','2019-01-30 19:59:59','DASHETH','4h','0.637850000000000','0.627800000000000','0.072472781363246','0.071330896197924','0.1136204144598981','0.113620414459898','test'),('2019-02-05 15:59:59','2019-02-06 19:59:59','DASHETH','4h','0.638750000000000','0.634100000000000','0.072472781363246','0.071945190860954','0.11346032307357495','0.113460323073575','test'),('2019-02-07 03:59:59','2019-02-08 11:59:59','DASHETH','4h','0.627790000000000','0.630500000000000','0.072472781363246','0.072785626801202','0.11544112101697385','0.115441121016974','test'),('2019-02-11 11:59:59','2019-02-14 03:59:59','DASHETH','4h','0.653980000000000','0.650980000000000','0.072472781363246','0.072140327245246','0.11081803933338329','0.110818039333383','test'),('2019-02-28 23:59:59','2019-03-05 15:59:59','DASHETH','4h','0.602880000000000','0.608220000000000','0.072472781363246','0.073114707870146','0.12021095634827164','0.120210956348272','test'),('2019-03-11 11:59:59','2019-03-11 15:59:59','DASHETH','4h','0.608920000000000','0.608000000000000','0.072472781363246','0.072363284288336','0.11901855968476319','0.119018559684763','test'),('2019-03-11 19:59:59','2019-03-15 19:59:59','DASHETH','4h','0.622010000000000','0.658600000000000','0.072472781363246','0.076736023224440','0.11651385245132073','0.116513852451321','test'),('2019-03-18 03:59:59','2019-03-19 23:59:59','DASHETH','4h','0.671450000000000','0.654430000000000','0.073102032078042','0.071249032471268','0.10887189228988345','0.108871892289883','test'),('2019-03-20 11:59:59','2019-03-22 15:59:59','DASHETH','4h','0.671480000000000','0.661920000000000','0.073102032078042','0.072061263288702','0.10886702817364925','0.108867028173649','test'),('2019-03-23 03:59:59','2019-03-23 07:59:59','DASHETH','4h','0.665230000000000','0.662580000000000','0.073102032078042','0.072810823947009','0.10988986076701593','0.109889860767016','test'),('2019-03-23 11:59:59','2019-03-25 19:59:59','DASHETH','4h','0.664120000000000','0.666780000000000','0.073102032078042','0.073394827665176','0.11007352899783472','0.110073528997835','test'),('2019-03-27 19:59:59','2019-03-30 03:59:59','DASHETH','4h','0.677110000000000','0.671620000000000','0.073102032078042','0.072509321652692','0.10796182611103367','0.107961826111034','test'),('2019-03-30 07:59:59','2019-04-07 19:59:59','DASHETH','4h','0.680630000000000','0.791140000000000','0.073102032078042','0.084971190894057','0.10740348218274541','0.107403482182745','test'),('2019-05-02 03:59:59','2019-05-03 11:59:59','DASHETH','4h','0.728440000000000','0.711290000000000','0.075198098940705','0.073427675300003','0.10323169916630777','0.103231699166308','test'),('2019-05-03 15:59:59','2019-05-06 11:59:59','DASHETH','4h','0.719550000000000','0.717120000000000','0.075198098940705','0.074944146636590','0.10450712103495935','0.104507121034959','test'),('2019-05-21 07:59:59','2019-05-22 11:59:59','DASHETH','4h','0.651580000000000','0.638250000000000','0.075198098940705','0.073659698960841','0.11540885070245403','0.115408850702454','test'),('2019-06-20 07:59:59','2019-06-20 15:59:59','DASHETH','4h','0.603770000000000','0.588730000000000','0.075198098940705','0.073324903173992','0.12454759087186346','0.124547590871863','test'),('2019-06-20 19:59:59','2019-06-20 23:59:59','DASHETH','4h','0.595270000000000','0.595590000000000','0.075198098940705','0.075238523271951','0.12632603514490065','0.126326035144901','test'),('2019-07-14 15:59:59','2019-07-15 15:59:59','DASHETH','4h','0.535240000000000','0.531560000000000','0.075198098940705','0.074681080399300','0.14049416886014685','0.140494168860147','test'),('2019-07-15 23:59:59','2019-07-16 03:59:59','DASHETH','4h','0.530210000000000','0.530370000000000','0.075198098940705','0.075220791262296','0.14182700994078765','0.141827009940788','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','DASHETH','4h','0.531000000000000','0.517210000000000','0.075198098940705','0.073245214224335','0.14161600553805084','0.141616005538051','test'),('2019-07-21 19:59:59','2019-07-23 19:59:59','DASHETH','4h','0.530300000000000','0.514220000000000','0.075198098940705','0.072917907669789','0.14180293973355648','0.141802939733556','test'),('2019-07-25 23:59:59','2019-07-28 23:59:59','DASHETH','4h','0.525500000000000','0.513300000000000','0.075198098940705','0.073452301020483','0.1430981901821218','0.143098190182122','test'),('2019-08-12 11:59:59','2019-08-13 15:59:59','DASHETH','4h','0.487350000000000','0.491180000000000','0.075198098940705','0.075789067893086','0.15429998756685134','0.154299987566851','test'),('2019-08-14 19:59:59','2019-08-17 11:59:59','DASHETH','4h','0.514590000000000','0.498170000000000','0.075198098940705','0.072798610445774','0.14613206424669156','0.146132064246692','test'),('2019-09-08 03:59:59','2019-09-10 03:59:59','DASHETH','4h','0.473500000000000','0.469850000000000','0.075198098940705','0.074618430384985','0.158813302937075','0.158813302937075','test'),('2019-09-13 07:59:59','2019-09-15 03:59:59','DASHETH','4h','0.484230000000000','0.487380000000000','0.075198098940705','0.075687275595731','0.15529417619871758','0.155294176198718','test'),('2019-10-16 11:59:59','2019-10-16 15:59:59','DASHETH','4h','0.397920000000000','0.391360000000000','0.075198098940705','0.073958403702841','0.18897793260128923','0.188977932601289','test'),('2019-10-18 23:59:59','2019-10-19 07:59:59','DASHETH','4h','0.393300000000000','0.388940000000000','0.075198098940705','0.074364476486137','0.19119781068066363','0.191197810680664','test'),('2019-10-19 11:59:59','2019-10-19 15:59:59','DASHETH','4h','0.392140000000000','0.389860000000000','0.075198098940705','0.074760878392980','0.19176339812491713','0.191763398124917','test'),('2019-10-19 19:59:59','2019-10-21 11:59:59','DASHETH','4h','0.394450000000000','0.390670000000000','0.075198098940705','0.074477478294246','0.19064038266118646','0.190640382661186','test'),('2019-10-21 15:59:59','2019-10-22 15:59:59','DASHETH','4h','0.394750000000000','0.393400000000000','0.075198098940705','0.074940930014625','0.19049550079975935','0.190495500799759','test'),('2019-10-23 03:59:59','2019-10-23 15:59:59','DASHETH','4h','0.398670000000000','0.393700000000000','0.075198098940705','0.074260645528772','0.1886224168879148','0.188622416887915','test'),('2019-10-28 11:59:59','2019-10-29 03:59:59','DASHETH','4h','0.397820000000000','0.395340000000000','0.075198098940705','0.074729315859480','0.18902543597784174','0.189025435977842','test'),('2019-10-29 07:59:59','2019-10-29 15:59:59','DASHETH','4h','0.397590000000000','0.392030000000000','0.075198098940705','0.074146509539286','0.18913478442794085','0.189134784427941','test'),('2019-10-30 19:59:59','2019-10-31 03:59:59','DASHETH','4h','0.395720000000000','0.391690000000000','0.075198098940705','0.074432283872649','0.19002855286744416','0.190028552867444','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','DASHETH','4h','0.392900000000000','0.392930000000000','0.075198098940705','0.075203840714612','0.19139246358031306','0.191392463580313','test'),('2019-11-01 03:59:59','2019-11-01 07:59:59','DASHETH','4h','0.396400000000000','0.392780000000000','0.075198098940705','0.074511375635545','0.18970257048613776','0.189702570486138','test'),('2019-11-01 19:59:59','2019-11-01 23:59:59','DASHETH','4h','0.395730000000000','0.392840000000000','0.075198098940705','0.074648930300626','0.19002375089254037','0.190023750892540','test'),('2019-11-02 07:59:59','2019-11-02 15:59:59','DASHETH','4h','0.393510000000000','0.392740000000000','0.075198098940705','0.075050955192937','0.19109577632259664','0.191095776322597','test'),('2019-11-02 23:59:59','2019-11-03 03:59:59','DASHETH','4h','0.394710000000000','0.392420000000000','0.075198098940705','0.074761820035751','0.19051480565657067','0.190514805656571','test'),('2019-11-30 23:59:59','2019-12-01 03:59:59','DASHETH','4h','0.363070000000000','0.357650000000000','0.075198098940705','0.074075522863754','0.20711735737104417','0.207117357371044','test'),('2019-12-01 11:59:59','2019-12-01 15:59:59','DASHETH','4h','0.358660000000000','0.356780000000000','0.075198098940705','0.074803930575098','0.20966402425892214','0.209664024258922','test'),('2019-12-14 07:59:59','2019-12-14 15:59:59','DASHETH','4h','0.354090000000000','0.348180000000000','0.075198098940705','0.073942992146558','0.21237001593014487','0.212370015930145','test'),('2019-12-14 19:59:59','2019-12-14 23:59:59','DASHETH','4h','0.348630000000000','0.349230000000000','0.075198098940705','0.075327516544940','0.2156960070582136','0.215696007058214','test'),('2019-12-15 03:59:59','2019-12-15 11:59:59','DASHETH','4h','0.351370000000000','0.349320000000000','0.075198098940705','0.074759370242101','0.21401399931896578','0.214013999318966','test'),('2019-12-15 19:59:59','2019-12-16 11:59:59','DASHETH','4h','0.355150000000000','0.349070000000000','0.075198098940705','0.073910743058516','0.2117361648337463','0.211736164833746','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 15:32:11
