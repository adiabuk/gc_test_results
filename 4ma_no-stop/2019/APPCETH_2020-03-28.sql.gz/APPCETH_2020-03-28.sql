-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-11 23:59:59','2019-01-12 11:59:59','APPCETH','4h','0.000317200000000','0.000315400000000','0.072144500000000','0.071735104981084','227.44167717528373','227.441677175283729','test'),('2019-01-12 15:59:59','2019-01-14 19:59:59','APPCETH','4h','0.000332400000000','0.000325300000000','0.072144500000000','0.070603507370638','217.04121540312875','217.041215403128746','test'),('2019-01-14 23:59:59','2019-01-22 11:59:59','APPCETH','4h','0.000333300000000','0.000393800000000','0.072144500000000','0.085240036303630','216.45514551455145','216.455145514551447','test'),('2019-01-24 03:59:59','2019-01-27 15:59:59','APPCETH','4h','0.000410600000000','0.000403100000000','0.074930787163838','0.073562104982326','182.49095753491963','182.490957534919630','test'),('2019-02-02 19:59:59','2019-02-03 03:59:59','APPCETH','4h','0.000413900000000','0.000388600000000','0.074930787163838','0.070350577172910','181.03596802086977','181.035968020869774','test'),('2019-02-03 11:59:59','2019-02-03 15:59:59','APPCETH','4h','0.000397900000000','0.000392200000000','0.074930787163838','0.073857388101677','188.31562494053279','188.315624940532786','test'),('2019-02-11 23:59:59','2019-02-17 19:59:59','APPCETH','4h','0.000422300000000','0.000485000000000','0.074930787163838','0.086055959683783','177.4349684201705','177.434968420170492','test'),('2019-02-27 19:59:59','2019-02-28 07:59:59','APPCETH','4h','0.000418900000000','0.000406400000000','0.075956507485174','0.073689960950047','181.32372281015518','181.323722810155175','test'),('2019-03-01 15:59:59','2019-03-06 07:59:59','APPCETH','4h','0.000411800000000','0.000519600000000','0.075956507485174','0.095840216826849','184.4499938930889','184.449993893088902','test'),('2019-03-06 19:59:59','2019-03-09 19:59:59','APPCETH','4h','0.000558300000000','0.000648000000000','0.080360798186811','0.093272070974482','143.9383811334605','143.938381133460496','test'),('2019-03-09 23:59:59','2019-03-11 03:59:59','APPCETH','4h','0.000652300000000','0.000582600000000','0.083588616383729','0.074656949111085','128.14443719719262','128.144437197192616','test'),('2019-03-19 19:59:59','2019-03-19 23:59:59','APPCETH','4h','0.000569100000000','0.000558900000000','0.083588616383729','0.082090454571896','146.87860900321385','146.878609003213853','test'),('2019-03-20 07:59:59','2019-03-20 15:59:59','APPCETH','4h','0.000568200000000','0.000561000000000','0.083588616383729','0.082529415331348','147.1112572751302','147.111257275130214','test'),('2019-03-20 19:59:59','2019-03-21 15:59:59','APPCETH','4h','0.000574500000000','0.000549100000000','0.083588616383729','0.079892966503578','145.49802677759615','145.498026777596152','test'),('2019-03-27 11:59:59','2019-04-01 19:59:59','APPCETH','4h','0.000578600000000','0.000617900000000','0.083588616383729','0.089266170175434','144.46701760063775','144.467017600637746','test'),('2019-04-01 23:59:59','2019-04-02 07:59:59','APPCETH','4h','0.000630800000000','0.000602500000000','0.083588616383729','0.079838524684839','132.5120741657086','132.512074165708611','test'),('2019-05-23 15:59:59','2019-05-25 11:59:59','APPCETH','4h','0.000372500000000','0.000354800000000','0.083588616383729','0.079616754611938','224.39897015766175','224.398970157661751','test'),('2019-05-26 07:59:59','2019-05-26 23:59:59','APPCETH','4h','0.000391700000000','0.000361600000000','0.083588616383729','0.077165288956743','213.399582291879','213.399582291879000','test'),('2019-06-01 23:59:59','2019-06-02 07:59:59','APPCETH','4h','0.000368300000000','0.000359200000000','0.083588616383729','0.081523298954753','226.95795922815367','226.957959228153669','test'),('2019-06-02 11:59:59','2019-06-03 23:59:59','APPCETH','4h','0.000371600000000','0.000366800000000','0.083588616383729','0.082508892598363','224.94245528452367','224.942455284523675','test'),('2019-06-08 03:59:59','2019-06-12 15:59:59','APPCETH','4h','0.000377300000000','0.000389800000000','0.083588616383729','0.086357918543275','221.5441727636602','221.544172763660214','test'),('2019-07-24 03:59:59','2019-07-25 03:59:59','APPCETH','4h','0.000228300000000','0.000228500000000','0.083588616383729','0.083661843380123','366.13498196990366','366.134981969903663','test'),('2019-07-25 19:59:59','2019-07-25 23:59:59','APPCETH','4h','0.000228500000000','0.000224300000000','0.083588616383729','0.082052195426129','365.8145137143501','365.814513714350085','test'),('2019-07-26 11:59:59','2019-07-30 15:59:59','APPCETH','4h','0.000228900000000','0.000238400000000','0.083588616383729','0.087057781327571','365.17525724652245','365.175257246522449','test'),('2019-08-13 07:59:59','2019-08-13 19:59:59','APPCETH','4h','0.000210300000000','0.000194700000000','0.083588616383729','0.077388034283937','397.4732115251023','397.473211525102272','test'),('2019-08-13 23:59:59','2019-08-14 03:59:59','APPCETH','4h','0.000196900000000','0.000198400000000','0.083588616383729','0.084225401170807','424.5231913851143','424.523191385114274','test'),('2019-08-14 07:59:59','2019-08-14 19:59:59','APPCETH','4h','0.000200300000000','0.000192200000000','0.083588616383729','0.080208347823029','417.31710625925615','417.317106259256150','test'),('2019-08-14 23:59:59','2019-08-15 01:59:59','APPCETH','4h','0.000195400000000','0.000191200000000','0.083588616383729','0.081791931691755','427.78206951754856','427.782069517548564','test'),('2019-08-22 19:59:59','2019-08-24 03:59:59','APPCETH','4h','0.000194800000000','0.000195900000000','0.083588616383729','0.084060626024500','429.09967342776696','429.099673427766959','test'),('2019-08-24 07:59:59','2019-08-25 15:59:59','APPCETH','4h','0.000204000000000','0.000202600000000','0.083588616383729','0.083014969016390','409.74811952808335','409.748119528083350','test'),('2019-08-25 19:59:59','2019-08-26 03:59:59','APPCETH','4h','0.000203000000000','0.000196100000000','0.083588616383729','0.080747426959849','411.7665831710788','411.766583171078821','test'),('2019-08-26 07:59:59','2019-08-28 19:59:59','APPCETH','4h','0.000209300000000','0.000209300000000','0.083588616383729','0.083588616383729','399.372271303053','399.372271303053026','test'),('2019-08-28 23:59:59','2019-08-29 07:59:59','APPCETH','4h','0.000211500000000','0.000201300000000','0.083588616383729','0.079557392331180','395.218044367513','395.218044367513016','test'),('2019-08-29 19:59:59','2019-09-02 11:59:59','APPCETH','4h','0.000217100000000','0.000216700000000','0.083588616383729','0.083434606956951','385.0235669448595','385.023566944859510','test'),('2019-09-10 07:59:59','2019-09-11 19:59:59','APPCETH','4h','0.000212400000000','0.000209600000000','0.083588616383729','0.082486694887145','393.5433916371421','393.543391637142122','test'),('2019-09-28 15:59:59','2019-09-28 19:59:59','APPCETH','4h','0.000193300000000','0.000184500000000','0.083588616383729','0.079783237055344','432.42946913465596','432.429469134655960','test'),('2019-09-29 03:59:59','2019-09-29 15:59:59','APPCETH','4h','0.000188800000000','0.000185300000000','0.083588616383729','0.082039039279158','442.73631559178494','442.736315591784944','test'),('2019-09-29 19:59:59','2019-09-30 07:59:59','APPCETH','4h','0.000187300000000','0.000183200000000','0.083588616383729','0.081758860232243','446.28198816726643','446.281988167266434','test'),('2019-10-02 07:59:59','2019-10-07 23:59:59','APPCETH','4h','0.000192000000000','0.000208500000000','0.083588616383729','0.090772013104206','435.3573769985885','435.357376998588506','test'),('2019-10-08 19:59:59','2019-10-09 15:59:59','APPCETH','4h','0.000215100000000','0.000192900000000','0.083588616383729','0.074961618319021','388.6035164283078','388.603516428307785','test'),('2019-10-20 23:59:59','2019-10-25 11:59:59','APPCETH','4h','0.000208700000000','0.000215300000000','0.083588616383729','0.086232051305304','400.5204426628126','400.520442662812627','test'),('2019-11-02 11:59:59','2019-11-02 15:59:59','APPCETH','4h','0.000218600000000','0.000218100000000','0.083588616383729','0.083397425586877','382.38159370415826','382.381593704158263','test'),('2019-11-03 11:59:59','2019-11-03 19:59:59','APPCETH','4h','0.000213200000000','0.000214600000000','0.083588616383729','0.084137509737093','392.0666809743386','392.066680974338624','test'),('2019-11-27 03:59:59','2019-11-27 19:59:59','APPCETH','4h','0.000200400000000','0.000187100000000','0.083588616383729','0.078041068489998','417.10886419026446','417.108864190264455','test'),('2019-11-27 23:59:59','2019-11-30 23:59:59','APPCETH','4h','0.000190600000000','0.000195900000000','0.083588616383729','0.085912958812028','438.55517515072927','438.555175150729269','test'),('2019-12-01 07:59:59','2019-12-03 07:59:59','APPCETH','4h','0.000195600000000','0.000196300000000','0.083588616383729','0.083887757648906','427.34466453849177','427.344664538491770','test'),('2019-12-03 11:59:59','2019-12-03 15:59:59','APPCETH','4h','0.000198700000000','0.000193900000000','0.083588616383729','0.081569364452970','420.6774855748817','420.677485574881700','test'),('2019-12-04 11:59:59','2019-12-04 15:59:59','APPCETH','4h','0.000199900000000','0.000193400000000','0.083588616383729','0.080870627356744','418.15215799764377','418.152157997643769','test'),('2019-12-07 03:59:59','2019-12-09 19:59:59','APPCETH','4h','0.000200900000000','0.000198700000000','0.083588616383729','0.082673260704066','416.0707634829716','416.070763482971586','test'),('2019-12-09 23:59:59','2019-12-10 03:59:59','APPCETH','4h','0.000199900000000','0.000190800000000','0.083588616383729','0.079783431745950','418.15215799764377','418.152157997643769','test'),('2019-12-19 19:59:59','2019-12-21 23:59:59','APPCETH','4h','0.000194300000000','0.000192100000000','0.083588616383729','0.082642167819425','430.2038928653062','430.203892865306216','test'),('2019-12-27 19:59:59','2019-12-29 23:59:59','APPCETH','4h','0.000194200000000','0.000199800000000','0.083588616383729','0.085998998730531','430.425419071725','430.425419071725003','test'),('2019-12-30 03:59:59','2019-12-30 11:59:59','APPCETH','4h','0.000200900000000','0.000197500000000','0.083588616383729','0.082173975787887','416.0707634829716','416.070763482971586','test'),('2019-12-30 15:59:59','2019-12-30 19:59:59','APPCETH','4h','0.000200500000000','0.000195100000000','0.083588616383729','0.081337351902571','416.9008298440349','416.900829844034888','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','APPCETH','4h','0.000206300000000','0.000191300000000','0.083588616383729','0.077510917664602','405.17991460847793','405.179914608477930','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 21:07:20
