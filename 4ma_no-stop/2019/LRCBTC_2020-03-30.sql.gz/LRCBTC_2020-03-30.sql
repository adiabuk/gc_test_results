-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 23:59:59','2019-01-03 19:59:59','LRCBTC','4h','0.000010920000000','0.000010720000000','0.001467500000000','0.001440622710623','134.3864468864469','134.386446886446890','test'),('2019-01-05 15:59:59','2019-01-06 23:59:59','LRCBTC','4h','0.000011360000000','0.000011000000000','0.001467500000000','0.001420994718310','129.18133802816902','129.181338028169023','test'),('2019-01-07 23:59:59','2019-01-08 23:59:59','LRCBTC','4h','0.000011820000000','0.000010900000000','0.001467500000000','0.001353278341794','124.15397631133672','124.153976311336720','test'),('2019-01-09 03:59:59','2019-01-09 19:59:59','LRCBTC','4h','0.000011050000000','0.000011070000000','0.001467500000000','0.001470156108597','132.8054298642534','132.805429864253398','test'),('2019-01-10 03:59:59','2019-01-10 07:59:59','LRCBTC','4h','0.000011130000000','0.000010830000000','0.001467500000000','0.001427944743935','131.85085354896677','131.850853548966768','test'),('2019-01-12 15:59:59','2019-01-12 19:59:59','LRCBTC','4h','0.000011090000000','0.000010980000000','0.001467500000000','0.001452944093778','132.32642019837692','132.326420198376923','test'),('2019-01-12 23:59:59','2019-01-13 03:59:59','LRCBTC','4h','0.000011020000000','0.000011160000000','0.001467500000000','0.001486143375681','133.16696914700546','133.166969147005460','test'),('2019-01-13 11:59:59','2019-01-13 19:59:59','LRCBTC','4h','0.000011200000000','0.000010910000000','0.001467500000000','0.001429502232143','131.02678571428572','131.026785714285722','test'),('2019-01-14 15:59:59','2019-01-15 11:59:59','LRCBTC','4h','0.000011210000000','0.000011030000000','0.001467500000000','0.001443936217663','130.90990187332739','130.909901873327385','test'),('2019-01-15 15:59:59','2019-01-15 19:59:59','LRCBTC','4h','0.000011060000000','0.000011680000000','0.001467500000000','0.001549764918626','132.6853526220615','132.685352622061487','test'),('2019-01-16 03:59:59','2019-01-24 15:59:59','LRCBTC','4h','0.000011550000000','0.000022260000000','0.001467500000000','0.002828272727273','127.05627705627707','127.056277056277068','test'),('2019-02-15 07:59:59','2019-02-15 11:59:59','LRCBTC','4h','0.000015530000000','0.000015130000000','0.001757765047106','0.001712490995667','113.18512859663555','113.185128596635550','test'),('2019-02-27 15:59:59','2019-03-01 03:59:59','LRCBTC','4h','0.000015730000000','0.000014710000000','0.001757765047106','0.001643784096817','111.74602969523204','111.746029695232039','test'),('2019-03-01 07:59:59','2019-03-02 11:59:59','LRCBTC','4h','0.000014870000000','0.000014720000000','0.001757765047106','0.001740033725178','118.20881285178211','118.208812851782113','test'),('2019-03-02 23:59:59','2019-03-04 07:59:59','LRCBTC','4h','0.000014920000000','0.000014820000000','0.001757765047106','0.001745983780034','117.81267071756032','117.812670717560323','test'),('2019-03-08 11:59:59','2019-03-09 03:59:59','LRCBTC','4h','0.000014970000000','0.000015460000000','0.001757765047106','0.001815300442769','117.41917482338009','117.419174823380089','test'),('2019-03-09 07:59:59','2019-03-12 01:59:59','LRCBTC','4h','0.000016390000000','0.000015630000000','0.001757765047106','0.001676257943030','107.24618957327638','107.246189573276382','test'),('2019-03-12 11:59:59','2019-03-13 19:59:59','LRCBTC','4h','0.000016160000000','0.000016010000000','0.001757765047106','0.001741449158674','108.7725895486386','108.772589548638607','test'),('2019-03-14 11:59:59','2019-03-16 07:59:59','LRCBTC','4h','0.000016520000000','0.000016060000000','0.001757765047106','0.001708820015528','106.40224256089587','106.402242560895871','test'),('2019-03-29 15:59:59','2019-03-29 19:59:59','LRCBTC','4h','0.000015500000000','0.000015390000000','0.001757765047106','0.001745290585481','113.40419658748387','113.404196587483867','test'),('2019-03-29 23:59:59','2019-04-02 07:59:59','LRCBTC','4h','0.000015600000000','0.000015410000000','0.001757765047106','0.001736356370250','112.67724660935897','112.677246609358974','test'),('2019-04-04 07:59:59','2019-04-04 19:59:59','LRCBTC','4h','0.000016690000000','0.000016330000000','0.001757765047106','0.001719850402591','105.31845698657878','105.318456986578781','test'),('2019-04-04 23:59:59','2019-04-08 11:59:59','LRCBTC','4h','0.000016460000000','0.000017520000000','0.001757765047106','0.001870962553177','106.79010006719318','106.790100067193180','test'),('2019-04-08 15:59:59','2019-04-08 19:59:59','LRCBTC','4h','0.000018720000000','0.000017900000000','0.001757765047106','0.001680768928590','93.89770550779915','93.897705507799145','test'),('2019-05-23 03:59:59','2019-05-23 11:59:59','LRCBTC','4h','0.000008440000000','0.000008360000000','0.001757765047106','0.001741103767039','208.2660008419431','208.266000841943111','test'),('2019-05-23 15:59:59','2019-05-25 15:59:59','LRCBTC','4h','0.000008900000000','0.000008440000000','0.001757765047106','0.001666914269390','197.50169068606743','197.501690686067434','test'),('2019-06-09 11:59:59','2019-06-11 11:59:59','LRCBTC','4h','0.000008350000000','0.000008130000000','0.001757765047106','0.001711452674607','210.5107840845509','210.510784084550892','test'),('2019-06-11 15:59:59','2019-06-12 03:59:59','LRCBTC','4h','0.000008250000000','0.000008160000000','0.001757765047106','0.001738589428410','213.0624299522424','213.062429952242411','test'),('2019-06-14 03:59:59','2019-06-14 07:59:59','LRCBTC','4h','0.000008290000000','0.000008180000000','0.001757765047106','0.001734441264816','212.03438445186973','212.034384451869727','test'),('2019-07-25 15:59:59','2019-07-28 11:59:59','LRCBTC','4h','0.000004090000000','0.000004430000000','0.001757765047106','0.001903887324861','429.7714051603912','429.771405160391225','test'),('2019-07-29 15:59:59','2019-07-31 15:59:59','LRCBTC','4h','0.000004730000000','0.000004360000000','0.001757765047106','0.001620265455683','371.6205173585624','371.620517358562381','test'),('2019-08-14 11:59:59','2019-08-14 19:59:59','LRCBTC','4h','0.000003870000000','0.000003520000000','0.001757765047106','0.001598794048014','454.20285454935396','454.202854549353958','test'),('2019-08-14 23:59:59','2019-08-15 01:59:59','LRCBTC','4h','0.000003530000000','0.000003570000000','0.001757765047106','0.001777683064637','497.95043827365436','497.950438273654356','test'),('2019-08-15 11:59:59','2019-08-15 23:59:59','LRCBTC','4h','0.000003630000000','0.000003600000000','0.001757765047106','0.001743238063246','484.2327953460055','484.232795346005503','test'),('2019-08-19 03:59:59','2019-08-19 07:59:59','LRCBTC','4h','0.000003560000000','0.000003400000000','0.001757765047106','0.001678764370832','493.75422671516856','493.754226715168556','test'),('2019-08-22 15:59:59','2019-08-23 15:59:59','LRCBTC','4h','0.000003610000000','0.000003600000000','0.001757765047106','0.001752895891851','486.9155255141274','486.915525514127410','test'),('2019-08-23 23:59:59','2019-08-26 03:59:59','LRCBTC','4h','0.000003590000000','0.000003650000000','0.001757765047106','0.001787142735916','489.62814682618387','489.628146826183865','test'),('2019-09-10 11:59:59','2019-09-11 19:59:59','LRCBTC','4h','0.000003480000000','0.000003330000000','0.001757765047106','0.001681999312317','505.1048985936781','505.104898593678115','test'),('2019-09-15 19:59:59','2019-09-16 23:59:59','LRCBTC','4h','0.000003490000000','0.000003380000000','0.001757765047106','0.001702362710378','503.65760662063036','503.657606620630361','test'),('2019-09-17 07:59:59','2019-09-22 07:59:59','LRCBTC','4h','0.000003440000000','0.000003580000000','0.001757765047106','0.001829301996698','510.9782113680232','510.978211368023210','test'),('2019-09-23 15:59:59','2019-09-29 15:59:59','LRCBTC','4h','0.000003670000000','0.000004140000000','0.001757765047106','0.001982873922348','478.95505370735697','478.955053707356967','test'),('2019-10-04 15:59:59','2019-10-05 11:59:59','LRCBTC','4h','0.000004070000000','0.000004100000000','0.001757765047106','0.001770721546225','431.88330395724813','431.883303957248131','test'),('2019-10-05 19:59:59','2019-10-07 19:59:59','LRCBTC','4h','0.000004150000000','0.000004080000000','0.001757765047106','0.001728115998119','423.55784267614456','423.557842676144560','test'),('2019-10-09 07:59:59','2019-10-09 15:59:59','LRCBTC','4h','0.000004130000000','0.000003880000000','0.001757765047106','0.001651362804545','425.6089702435835','425.608970243583485','test'),('2019-10-30 15:59:59','2019-10-31 07:59:59','LRCBTC','4h','0.000003660000000','0.000003620000000','0.001757765047106','0.001738554500143','480.2636740726776','480.263674072677588','test'),('2019-10-31 15:59:59','2019-11-01 07:59:59','LRCBTC','4h','0.000003630000000','0.000003530000000','0.001757765047106','0.001709341767571','484.2327953460055','484.232795346005503','test'),('2019-11-11 07:59:59','2019-11-13 01:59:59','LRCBTC','4h','0.000003700000000','0.000003600000000','0.001757765047106','0.001710257883671','475.0716343529729','475.071634352972922','test'),('2019-11-13 23:59:59','2019-11-14 11:59:59','LRCBTC','4h','0.000003630000000','0.000003620000000','0.001757765047106','0.001752922719153','484.2327953460055','484.232795346005503','test'),('2019-11-14 15:59:59','2019-11-14 19:59:59','LRCBTC','4h','0.000003630000000','0.000003620000000','0.001757765047106','0.001752922719153','484.2327953460055','484.232795346005503','test'),('2019-11-15 03:59:59','2019-11-15 11:59:59','LRCBTC','4h','0.000003650000000','0.000003640000000','0.001757765047106','0.001752949252456','481.5794649605479','481.579464960547909','test'),('2019-11-15 15:59:59','2019-11-15 19:59:59','LRCBTC','4h','0.000003670000000','0.000003610000000','0.001757765047106','0.001729027743884','478.95505370735697','478.955053707356967','test'),('2019-11-30 23:59:59','2019-12-03 11:59:59','LRCBTC','4h','0.000003920000000','0.000003420000000','0.001757765047106','0.001533560321710','448.40945079234695','448.409450792346945','test'),('2019-12-16 15:59:59','2019-12-16 19:59:59','LRCBTC','4h','0.000003310000000','0.000003240000000','0.001757765047106','0.001720591768164','531.0468420259818','531.046842025981846','test'),('2019-12-28 11:59:59','2019-12-28 19:59:59','LRCBTC','4h','0.000003180000000','0.000003020000000','0.001757765047106','0.001669324038447','552.7563041213837','552.756304121383664','test'),('2019-12-30 23:59:59','2019-12-31 07:59:59','LRCBTC','4h','0.000003120000000','0.000003070000000','0.001757765047106','0.001729595735454','563.3862330467948','563.386233046794814','test'),('2019-12-31 19:59:59','2019-12-31 23:59:59','LRCBTC','4h','0.000003020000000','0.000003000000000','0.001757765047106','0.001746124218979','582.0414063264901','582.041406326490119','test'),('2020-01-01 15:59:59','2020-01-01 15:59:59','LRCBTC','4h','0.000003090000000','0.000003090000000','0.001757765047106','0.001757765047106','568.8560022996763','568.856002299676334','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 23:32:28
