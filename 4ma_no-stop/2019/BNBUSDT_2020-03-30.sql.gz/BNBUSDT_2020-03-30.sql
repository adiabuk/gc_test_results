-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-01 19:59:59','2019-01-03 11:59:59','BNBUSDT','4h','5.854000000000000','5.830000000000000','15.000000000000000','14.938503587290741','2.5623505295524427','2.562350529552443','test'),('2019-01-04 19:59:59','2019-01-10 07:59:59','BNBUSDT','4h','5.957600000000000','6.059900000000000','15.000000000000000','15.257570162481537','2.5177923996240095','2.517792399624009','test'),('2019-01-17 15:59:59','2019-01-22 11:59:59','BNBUSDT','4h','6.132900000000000','6.436200000000000','15.049018437443070','15.793261339182292','2.4538176780060117','2.453817678006012','test'),('2019-01-22 15:59:59','2019-01-24 15:59:59','BNBUSDT','4h','6.481700000000000','6.424400000000000','15.235079162877875','15.100396898034871','2.350475826230445','2.350475826230445','test'),('2019-01-25 03:59:59','2019-01-28 07:59:59','BNBUSDT','4h','6.493200000000000','6.739800000000000','15.235079162877875','15.813679933155347','2.346312937053822','2.346312937053822','test'),('2019-01-28 11:59:59','2019-01-28 15:59:59','BNBUSDT','4h','6.799100000000000','6.158900000000000','15.346058789236492','13.901081242668681','2.2570720814867395','2.257072081486740','test'),('2019-02-02 11:59:59','2019-02-13 07:59:59','BNBUSDT','4h','6.728300000000000','9.035700000000000','15.346058789236492','20.608828887223250','2.280822613325282','2.280822613325282','test'),('2019-02-15 23:59:59','2019-02-17 07:59:59','BNBUSDT','4h','9.291100000000000','8.920299999999999','16.300506927091227','15.649967381874252','1.754421642979973','1.754421642979973','test'),('2019-02-17 23:59:59','2019-02-24 15:59:59','BNBUSDT','4h','9.220000000000001','9.786300000000001','16.300506927091227','17.301697498979706','1.7679508597712827','1.767950859771283','test'),('2019-02-28 23:59:59','2019-03-10 11:59:59','BNBUSDT','4h','10.277900000000001','14.194800000000001','16.388169683759106','22.633688888491204','1.5945056561903799','1.594505656190380','test'),('2019-03-12 11:59:59','2019-03-18 19:59:59','BNBUSDT','4h','15.154299999999999','15.415500000000000','17.949549484942128','18.258928494560976','1.1844525636249863','1.184452563624986','test'),('2019-03-19 07:59:59','2019-03-19 15:59:59','BNBUSDT','4h','15.686700000000000','15.414999999999999','18.026894237346841','17.714661124946709','1.1491833360328711','1.149183336032871','test'),('2019-03-24 11:59:59','2019-03-26 15:59:59','BNBUSDT','4h','17.040199999999999','15.904299999999999','18.026894237346841','16.825221183967052','1.0579039117702165','1.057903911770216','test'),('2019-03-26 19:59:59','2019-03-26 23:59:59','BNBUSDT','4h','16.150400000000001','16.199800000000000','18.026894237346841','18.082033959912529','1.1161887159046735','1.116188715904674','test'),('2019-03-27 03:59:59','2019-03-29 23:59:59','BNBUSDT','4h','16.375200000000000','16.475300000000001','18.026894237346841','18.137090883076873','1.1008655917086108','1.100865591708611','test'),('2019-03-30 23:59:59','2019-04-07 15:59:59','BNBUSDT','4h','16.966600000000000','18.961500000000001','18.026894237346841','20.146461582252904','1.0624930296787123','1.062493029678712','test'),('2019-04-14 07:59:59','2019-04-23 19:59:59','BNBUSDT','4h','19.053100000000001','23.119000000000000','18.219643624202305','22.107685413288813','0.9562561275699127','0.956256127569913','test'),('2019-04-26 11:59:59','2019-04-26 19:59:59','BNBUSDT','4h','23.480000000000000','22.763000000000002','19.191654071473934','18.605605691182333','0.8173617577288728','0.817361757728873','test'),('2019-05-02 23:59:59','2019-05-04 11:59:59','BNBUSDT','4h','23.616599999999998','23.076200000000000','19.191654071473934','18.752506613320580','0.8126340824451418','0.812634082445142','test'),('2019-05-04 19:59:59','2019-05-05 03:59:59','BNBUSDT','4h','22.831000000000000','22.966400000000000','19.191654071473934','19.305470810174718','0.8405962976424132','0.840596297642413','test'),('2019-05-13 19:59:59','2019-05-17 03:59:59','BNBUSDT','4h','23.680000000000000','24.115600000000001','19.191654071473934','19.544689735052231','0.8104583645048115','0.810458364504811','test'),('2019-05-17 07:59:59','2019-05-17 15:59:59','BNBUSDT','4h','24.800000000000001','24.301600000000001','19.191654071473934','18.805963733198830','0.7738570190110458','0.773857019011046','test'),('2019-05-17 23:59:59','2019-05-26 19:59:59','BNBUSDT','4h','25.779499999999999','32.845900000000000','19.191654071473934','24.452264414213840','0.744454084504119','0.744454084504119','test'),('2019-05-27 03:59:59','2019-05-28 15:59:59','BNBUSDT','4h','34.226900000000001','33.000900000000001','20.270798213548666','19.544702697746459','0.5922475659071861','0.592247565907186','test'),('2019-05-30 03:59:59','2019-05-30 19:59:59','BNBUSDT','4h','34.572299999999998','32.482100000000003','20.270798213548666','19.045249944386381','0.586330623462965','0.586330623462965','test'),('2019-06-02 11:59:59','2019-06-03 03:59:59','BNBUSDT','4h','33.416899999999998','32.081499999999998','20.270798213548666','19.460740310679970','0.6066031922036056','0.606603192203606','test'),('2019-06-12 03:59:59','2019-06-14 11:59:59','BNBUSDT','4h','33.332200000000000','31.729299999999999','20.270798213548666','19.296003196823182','0.6081446233236529','0.608144623323653','test'),('2019-06-17 15:59:59','2019-06-24 03:59:59','BNBUSDT','4h','33.849800000000002','36.632199999999997','20.270798213548666','21.937025752540855','0.5988454352329604','0.598845435232960','test'),('2019-07-21 19:59:59','2019-07-21 23:59:59','BNBUSDT','4h','29.721599999999999','30.438800000000001','20.270798213548666','20.759944708984886','0.6820224420471531','0.682022442047153','test'),('2019-07-22 03:59:59','2019-07-22 15:59:59','BNBUSDT','4h','30.953099999999999','29.940700000000000','20.270798213548666','19.607790110599474','0.6548874979743117','0.654887497974312','test'),('2019-07-22 19:59:59','2019-07-23 07:59:59','BNBUSDT','4h','30.199999999999999','29.858599999999999','20.270798213548666','20.041644223147824','0.67121848389234','0.671218483892340','test'),('2019-08-07 19:59:59','2019-08-10 07:59:59','BNBUSDT','4h','29.969899999999999','29.295999999999999','20.270798213548666','19.814991189964655','0.6763719002582146','0.676371900258215','test'),('2019-08-11 15:59:59','2019-08-13 15:59:59','BNBUSDT','4h','29.868300000000001','29.267199999999999','20.270798213548666','19.862848085614900','0.678672646703986','0.678672646703986','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','BNBUSDT','4h','22.201799999999999','20.731100000000001','20.270798213548666','18.928012361380553','0.9130249895751096','0.913024989575110','test'),('2019-09-20 11:59:59','2019-09-20 19:59:59','BNBUSDT','4h','21.431100000000001','21.045300000000001','20.270798213548666','19.905885822174120','0.9458589719402488','0.945858971940249','test'),('2019-09-21 03:59:59','2019-09-21 07:59:59','BNBUSDT','4h','21.360499999999998','21.239999999999998','20.270798213548666','20.156445497800785','0.9489851929284739','0.948985192928474','test'),('2019-10-09 11:59:59','2019-10-11 19:59:59','BNBUSDT','4h','17.687000000000001','16.725700000000000','20.270798213548666','19.169067093365236','1.1460845939700721','1.146084593970072','test'),('2019-10-12 15:59:59','2019-10-16 15:59:59','BNBUSDT','4h','17.298600000000000','17.608799999999999','20.270798213548666','20.634295930464642','1.1718172692326931','1.171817269232693','test'),('2019-10-17 15:59:59','2019-10-18 11:59:59','BNBUSDT','4h','18.656099999999999','18.149999999999999','20.270798213548666','19.720894912436592','1.086550683880804','1.086550683880804','test'),('2019-10-18 19:59:59','2019-10-19 03:59:59','BNBUSDT','4h','18.274600000000000','18.136399999999998','20.270798213548666','20.117502146159367','1.1092334832799988','1.109233483279999','test'),('2019-10-20 19:59:59','2019-10-21 15:59:59','BNBUSDT','4h','18.433000000000000','17.996099999999998','20.270798213548666','19.790338617199755','1.0997015251748856','1.099701525174886','test'),('2019-10-21 23:59:59','2019-10-23 03:59:59','BNBUSDT','4h','18.255099999999999','17.800100000000000','20.270798213548666','19.765557859501598','1.110418360543008','1.110418360543008','test'),('2019-10-26 03:59:59','2019-10-30 19:59:59','BNBUSDT','4h','19.294499999999999','19.777999999999999','20.270798213548666','20.778763226181837','1.0505998193033594','1.050599819303359','test'),('2019-11-02 03:59:59','2019-11-07 11:59:59','BNBUSDT','4h','20.074600000000000','20.150900000000000','20.270798213548666','20.347843928217639','1.009773455687718','1.009773455687718','test'),('2019-11-11 03:59:59','2019-11-11 07:59:59','BNBUSDT','4h','20.442100000000000','20.082100000000001','20.270798213548666','19.913814960513140','0.9916201473209048','0.991620147320905','test'),('2019-11-11 15:59:59','2019-11-11 19:59:59','BNBUSDT','4h','20.074800000000000','20.156099999999999','20.270798213548666','20.352891977609154','1.0097633955779717','1.009763395577972','test'),('2019-11-12 03:59:59','2019-11-12 15:59:59','BNBUSDT','4h','20.250000000000000','20.219999999999999','20.270798213548666','20.240767401380445','1.0010270722740082','1.001027072274008','test'),('2019-11-12 19:59:59','2019-11-15 15:59:59','BNBUSDT','4h','20.638600000000000','20.140300000000000','20.270798213548666','19.781378449135804','0.9821789372122463','0.982178937212246','test'),('2019-12-29 15:59:59','2019-12-31 19:59:59','BNBUSDT','4h','14.129500000000000','13.668100000000001','20.270798213548666','19.608853608592273','1.4346437038500064','1.434643703850006','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  1:07:28
