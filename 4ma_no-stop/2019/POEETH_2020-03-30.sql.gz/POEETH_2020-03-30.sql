-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-08 23:59:59','2019-01-12 15:59:59','POEETH','4h','0.000039240000000','0.000039760000000','0.072144500000000','0.073100543323140','1838.5448521916414','1838.544852191641439','test'),('2019-01-12 19:59:59','2019-01-14 19:59:59','POEETH','4h','0.000040520000000','0.000040120000000','0.072383510830785','0.071668964820609','1786.3650254389192','1786.365025438919247','test'),('2019-01-14 23:59:59','2019-01-15 03:59:59','POEETH','4h','0.000040250000000','0.000040060000000','0.072383510830785','0.072041824692702','1798.3480951747824','1798.348095174782429','test'),('2019-01-15 07:59:59','2019-01-20 19:59:59','POEETH','4h','0.000041680000000','0.000044060000000','0.072383510830785','0.076516734337917','1736.6485324084692','1736.648532408469237','test'),('2019-01-21 19:59:59','2019-01-25 15:59:59','POEETH','4h','0.000045830000000','0.000045980000000','0.073152758670503','0.073392185111711','1596.1762747218688','1596.176274721868822','test'),('2019-01-25 19:59:59','2019-01-26 03:59:59','POEETH','4h','0.000046380000000','0.000046000000000','0.073212615280805','0.072612770653666','1578.5384924710058','1578.538492471005839','test'),('2019-01-26 11:59:59','2019-01-26 19:59:59','POEETH','4h','0.000047650000000','0.000046090000000','0.073212615280805','0.070815727980951','1536.466217855299','1536.466217855298964','test'),('2019-01-28 07:59:59','2019-01-29 03:59:59','POEETH','4h','0.000046960000000','0.000046140000000','0.073212615280805','0.071934200789104','1559.0420630495103','1559.042063049510261','test'),('2019-01-30 03:59:59','2019-01-30 15:59:59','POEETH','4h','0.000046770000000','0.000046460000000','0.073212615280805','0.072727348854954','1565.3755672611717','1565.375567261171682','test'),('2019-01-30 19:59:59','2019-01-31 11:59:59','POEETH','4h','0.000047070000000','0.000044570000000','0.073212615280805','0.069324118611971','1555.398667533567','1555.398667533567050','test'),('2019-03-02 19:59:59','2019-03-05 19:59:59','POEETH','4h','0.000035280000000','0.000034420000000','0.073212615280805','0.071427954023960','2075.187507959325','2075.187507959325103','test'),('2019-03-10 03:59:59','2019-03-11 15:59:59','POEETH','4h','0.000035420000000','0.000035620000000','0.073212615280805','0.073626012317964','2066.985185793478','2066.985185793478195','test'),('2019-03-11 19:59:59','2019-03-16 07:59:59','POEETH','4h','0.000035870000000','0.000035880000000','0.073212615280805','0.073233025823119','2041.0542314135766','2041.054231413576645','test'),('2019-03-21 19:59:59','2019-03-21 23:59:59','POEETH','4h','0.000036490000000','0.000036230000000','0.073212615280805','0.072690957841150','2006.3747679036724','2006.374767903672364','test'),('2019-03-22 03:59:59','2019-03-24 03:59:59','POEETH','4h','0.000036410000000','0.000036730000000','0.073212615280805','0.073856065895742','2010.7831716782478','2010.783171678247754','test'),('2019-03-24 23:59:59','2019-03-25 03:59:59','POEETH','4h','0.000037410000000','0.000036650000000','0.073212615280805','0.071725269982398','1957.03328737784','1957.033287377839997','test'),('2019-03-25 23:59:59','2019-03-26 15:59:59','POEETH','4h','0.000038130000000','0.000037940000000','0.073212615280805','0.072847800255802','1920.0790789615787','1920.079078961578716','test'),('2019-03-26 19:59:59','2019-03-30 03:59:59','POEETH','4h','0.000041110000000','0.000039430000000','0.073212615280805','0.070220710788668','1780.8955310339334','1780.895531033933366','test'),('2019-03-31 15:59:59','2019-04-02 07:59:59','POEETH','4h','0.000041010000000','0.000041050000000','0.073212615280805','0.073284024805585','1785.2381195026821','1785.238119502682139','test'),('2019-04-21 07:59:59','2019-04-22 23:59:59','POEETH','4h','0.000037750000000','0.000037140000000','0.073212615280805','0.072029576994148','1939.4070273060925','1939.407027306092459','test'),('2019-05-23 03:59:59','2019-05-24 19:59:59','POEETH','4h','0.000023470000000','0.000024340000000','0.073212615280805','0.075926504300588','3119.4126664169153','3119.412666416915272','test'),('2019-05-24 23:59:59','2019-05-26 19:59:59','POEETH','4h','0.000025190000000','0.000023080000000','0.073212615280805','0.067080077835688','2906.4158507663756','2906.415850766375570','test'),('2019-06-09 19:59:59','2019-06-09 23:59:59','POEETH','4h','0.000021670000000','0.000021240000000','0.073212615280805','0.071759849956820','3378.524009266497','3378.524009266497160','test'),('2019-06-10 11:59:59','2019-06-10 15:59:59','POEETH','4h','0.000021860000000','0.000021640000000','0.073212615280805','0.072475800305426','3349.1589789938243','3349.158978993824348','test'),('2019-06-13 19:59:59','2019-06-13 23:59:59','POEETH','4h','0.000021990000000','0.000021920000000','0.073212615280805','0.072979560116200','3329.3594943522053','3329.359494352205274','test'),('2019-06-14 03:59:59','2019-06-14 15:59:59','POEETH','4h','0.000022480000000','0.000021440000000','0.073212615280805','0.069825554787387','3256.7889359788696','3256.788935978869631','test'),('2019-06-14 19:59:59','2019-06-15 19:59:59','POEETH','4h','0.000022250000000','0.000027010000000','0.073212615280805','0.088875179268968','3290.4546193620226','3290.454619362022640','test'),('2019-06-15 23:59:59','2019-06-17 03:59:59','POEETH','4h','0.000027780000000','0.000023320000000','0.073212615280805','0.061458538097494','2635.443314643808','2635.443314643808208','test'),('2019-07-14 19:59:59','2019-07-14 23:59:59','POEETH','4h','0.000020520000000','0.000018080000000','0.073212615280805','0.064507021650924','3567.8662417546298','3567.866241754629755','test'),('2019-07-15 03:59:59','2019-07-15 19:59:59','POEETH','4h','0.000018730000000','0.000017720000000','0.073212615280805','0.069264684611632','3908.842246706087','3908.842246706086826','test'),('2019-07-16 07:59:59','2019-07-16 11:59:59','POEETH','4h','0.000017440000000','0.000017140000000','0.073212615280805','0.071953223962901','4197.971059679186','4197.971059679185601','test'),('2019-07-21 19:59:59','2019-07-23 15:59:59','POEETH','4h','0.000017840000000','0.000016960000000','0.073212615280805','0.069601230670541','4103.846148027186','4103.846148027186246','test'),('2019-07-23 19:59:59','2019-07-23 23:59:59','POEETH','4h','0.000017050000000','0.000017200000000','0.073212615280805','0.073856714535475','4293.995031132257','4293.995031132257282','test'),('2019-07-24 03:59:59','2019-07-24 11:59:59','POEETH','4h','0.000017340000000','0.000016850000000','0.073212615280805','0.071143746682905','4222.180812041811','4222.180812041810896','test'),('2019-07-26 23:59:59','2019-07-27 11:59:59','POEETH','4h','0.000017180000000','0.000016940000000','0.073212615280805','0.072189854648244','4261.5026356696735','4261.502635669673509','test'),('2019-08-23 07:59:59','2019-08-28 23:59:59','POEETH','4h','0.000012550000000','0.000015490000000','0.073212615280805','0.090363618382444','5833.674524366932','5833.674524366932019','test'),('2019-09-07 15:59:59','2019-09-08 11:59:59','POEETH','4h','0.000015320000000','0.000014350000000','0.073212615280805','0.068577090684044','4778.891336867167','4778.891336867167411','test'),('2019-09-08 15:59:59','2019-09-08 19:59:59','POEETH','4h','0.000014750000000','0.000014640000000','0.073212615280805','0.072666622895660','4963.567137681695','4963.567137681695385','test'),('2019-09-09 03:59:59','2019-09-11 15:59:59','POEETH','4h','0.000014700000000','0.000015320000000','0.073212615280805','0.076300494292648','4980.450019102381','4980.450019102380793','test'),('2019-09-11 19:59:59','2019-09-11 23:59:59','POEETH','4h','0.000016640000000','0.000015850000000','0.073212615280805','0.069736775973603','4399.796591394531','4399.796591394530878','test'),('2019-09-13 15:59:59','2019-09-14 19:59:59','POEETH','4h','0.000016690000000','0.000015580000000','0.073212615280805','0.068343471903831','4386.6156549313955','4386.615654931395511','test'),('2019-09-18 03:59:59','2019-09-18 15:59:59','POEETH','4h','0.000016350000000','0.000015880000000','0.073212615280805','0.071108032456219','4477.835796991131','4477.835796991131247','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','POEETH','4h','0.000016490000000','0.000015870000000','0.073212615280805','0.070459927501903','4439.8189982295335','4439.818998229533463','test'),('2019-09-19 07:59:59','2019-09-19 11:59:59','POEETH','4h','0.000015380000000','0.000015760000000','0.073212615280805','0.075021509546521','4760.248067672627','4760.248067672627258','test'),('2019-09-19 15:59:59','2019-09-19 19:59:59','POEETH','4h','0.000016350000000','0.000016000000000','0.073212615280805','0.071645372751858','4477.835796991131','4477.835796991131247','test'),('2019-09-20 03:59:59','2019-09-20 15:59:59','POEETH','4h','0.000016020000000','0.000015730000000','0.073212615280805','0.071887293281340','4570.075860225032','4570.075860225031647','test'),('2019-09-20 23:59:59','2019-09-24 03:59:59','POEETH','4h','0.000016810000000','0.000015290000000','0.073212615280805','0.066592557266122','4355.301325449434','4355.301325449434444','test'),('2019-10-05 23:59:59','2019-10-07 15:59:59','POEETH','4h','0.000015010000000','0.000014700000000','0.073212615280805','0.071700562600122','4877.5892925253165','4877.589292525316523','test'),('2019-10-07 19:59:59','2019-10-07 23:59:59','POEETH','4h','0.000014740000000','0.000014690000000','0.073212615280805','0.072964268553258','4966.934550936568','4966.934550936567575','test'),('2019-10-08 11:59:59','2019-10-09 15:59:59','POEETH','4h','0.000015610000000','0.000014610000000','0.073212615280805','0.068522505397345','4690.1098834596405','4690.109883459640514','test'),('2019-10-12 19:59:59','2019-10-13 15:59:59','POEETH','4h','0.000015250000000','0.000014530000000','0.073212615280805','0.069756019674105','4800.8272315281965','4800.827231528196535','test'),('2019-11-07 03:59:59','2019-11-08 15:59:59','POEETH','4h','0.000013340000000','0.000012940000000','0.073212615280805','0.071017334462790','5488.202045037856','5488.202045037855896','test'),('2019-11-16 11:59:59','2019-11-18 11:59:59','POEETH','4h','0.000013520000000','0.000013150000000','0.073212615280805','0.071209015602262','5415.134266331731','5415.134266331730942','test'),('2019-11-18 15:59:59','2019-11-18 19:59:59','POEETH','4h','0.000013580000000','0.000013190000000','0.073212615280805','0.071110043855215','5391.208783564432','5391.208783564432451','test'),('2019-11-22 07:59:59','2019-11-25 19:59:59','POEETH','4h','0.000014760000000','0.000015220000000','0.073212615280805','0.075494309252971','4960.204287317412','4960.204287317412309','test'),('2019-11-25 23:59:59','2019-11-28 11:59:59','POEETH','4h','0.000015430000000','0.000014940000000','0.073212615280805','0.070887652125420','4744.822766092353','4744.822766092353049','test'),('2019-12-06 23:59:59','2019-12-08 15:59:59','POEETH','4h','0.000014820000000','0.000014810000000','0.073212615280805','0.073163214055919','4940.1224885833335','4940.122488583333507','test'),('2019-12-21 03:59:59','2019-12-21 19:59:59','POEETH','4h','0.000013740000000','0.000014700000000','0.073212615280805','0.078327907178154','5328.429059738355','5328.429059738355136','test'),('2019-12-22 15:59:59','2019-12-22 19:59:59','POEETH','4h','0.000013830000000','0.000013430000000','0.073212615280805','0.071095113754245','5293.753816399494','5293.753816399494099','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 12:27:56
