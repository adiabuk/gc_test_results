-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-02 03:59:59','2019-01-05 07:59:59','DLTBNB','4h','0.007600000000000','0.007890000000000','0.711908500000000','0.739073429605263','93.67217105263158','93.672171052631583','test'),('2019-01-07 15:59:59','2019-01-10 15:59:59','DLTBNB','4h','0.008680000000000','0.008910000000000','0.718699732401316','0.737743619319784','82.7995083411654','82.799508341165406','test'),('2019-01-11 15:59:59','2019-01-16 23:59:59','DLTBNB','4h','0.009530000000000','0.016530000000000','0.723460704130933','1.254858912831513','75.9140298143686','75.914029814368604','test'),('2019-01-17 15:59:59','2019-01-19 23:59:59','DLTBNB','4h','0.022050000000000','0.016890000000000','0.856310256306078','0.655922005850778','38.83493225877904','38.834932258779041','test'),('2019-01-21 15:59:59','2019-01-24 11:59:59','DLTBNB','4h','0.018770000000000','0.018930000000000','0.856310256306078','0.863609651138735','45.62121770410645','45.621217704106449','test'),('2019-01-24 19:59:59','2019-01-27 11:59:59','DLTBNB','4h','0.021860000000000','0.020060000000000','0.856310256306078','0.785799805192128','39.17247284108316','39.172472841083163','test'),('2019-03-28 23:59:59','2019-03-31 15:59:59','DLTBNB','4h','0.007010000000000','0.007240000000000','0.856310256306078','0.884406027910985','122.1555287169869','122.155528716986893','test'),('2019-04-01 23:59:59','2019-04-02 03:59:59','DLTBNB','4h','0.007250000000000','0.007070000000000','0.856310256306078','0.835050139597789','118.11175949049351','118.111759490493512','test'),('2019-04-08 23:59:59','2019-04-09 07:59:59','DLTBNB','4h','0.007020000000000','0.006750000000000','0.856310256306078','0.823375246448152','121.9815179923188','121.981517992318800','test'),('2019-05-06 07:59:59','2019-05-07 23:59:59','DLTBNB','4h','0.005500000000000','0.004320000000000','0.856310256306078','0.672592783134956','155.69277387383238','155.692773873832380','test'),('2019-05-08 07:59:59','2019-05-08 19:59:59','DLTBNB','4h','0.004250000000000','0.004100000000000','0.856310256306078','0.826087541377628','201.4847661896654','201.484766189665407','test'),('2019-05-10 07:59:59','2019-05-11 15:59:59','DLTBNB','4h','0.005780000000000','0.004360000000000','0.856310256306078','0.645936456313927','148.15056337475397','148.150563374753972','test'),('2019-05-11 19:59:59','2019-05-11 23:59:59','DLTBNB','4h','0.004460000000000','0.004500000000000','0.856310256306078','0.863990168918688','191.99781531526412','191.997815315264120','test'),('2019-05-12 15:59:59','2019-05-13 03:59:59','DLTBNB','4h','0.005040000000000','0.004580000000000','0.856310256306078','0.778154955135285','169.90282863215833','169.902828632158332','test'),('2019-06-09 19:59:59','2019-06-12 03:59:59','DLTBNB','4h','0.003820000000000','0.003650000000000','0.856310256306078','0.818202208250572','224.16498856180053','224.164988561800527','test'),('2019-07-28 23:59:59','2019-07-30 15:59:59','DLTBNB','4h','0.002363000000000','0.002227000000000','0.856310256306078','0.807026212777671','362.3826730029954','362.382673002995375','test'),('2019-07-30 19:59:59','2019-07-30 23:59:59','DLTBNB','4h','0.002281000000000','0.002290000000000','0.570873504204052','0.573125964325857','250.27334686718632','250.273346867186319','test'),('2019-08-02 23:59:59','2019-08-03 23:59:59','DLTBNB','4h','0.002212000000000','0.002210000000000','0.638903338853599','0.638325668565305','288.83514414719656','288.835144147196559','test'),('2019-08-04 07:59:59','2019-08-05 03:59:59','DLTBNB','4h','0.002213000000000','0.002120000000000','0.638903338853599','0.612053808571907','288.7046266848617','288.704626684861694','test'),('2019-08-22 19:59:59','2019-08-23 15:59:59','DLTBNB','4h','0.001864000000000','0.001722000000000','0.638903338853599','0.590231517975267','342.7593019600853','342.759301960085281','test'),('2019-08-24 07:59:59','2019-08-26 11:59:59','DLTBNB','4h','0.001800000000000','0.001805000000000','0.638903338853599','0.640678070350414','354.94629936311054','354.946299363110541','test'),('2019-08-26 15:59:59','2019-08-26 19:59:59','DLTBNB','4h','0.001903000000000','0.001880000000000','0.638903338853599','0.631181438278910','335.73480759516497','335.734807595164966','test'),('2019-08-27 03:59:59','2019-08-28 19:59:59','DLTBNB','4h','0.001928000000000','0.001815000000000','0.638903338853599','0.601457240673901','331.3813998203314','331.381399820331410','test'),('2019-08-31 19:59:59','2019-09-02 15:59:59','DLTBNB','4h','0.001958000000000','0.001825000000000','0.638903338853599','0.595504899595413','326.3040545728289','326.304054572828875','test'),('2019-09-11 15:59:59','2019-09-11 19:59:59','DLTBNB','4h','0.001666000000000','0.001657000000000','0.638903338853599','0.635451880240344','383.4954014727485','383.495401472748483','test'),('2019-09-12 03:59:59','2019-09-12 07:59:59','DLTBNB','4h','0.001624000000000','0.001668000000000','0.638903338853599','0.656213527837317','393.4133859935954','393.413385993595398','test'),('2019-09-12 19:59:59','2019-09-13 03:59:59','DLTBNB','4h','0.001678000000000','0.001635000000000','0.638903338853599','0.622530964854371','380.7528837029791','380.752883702979091','test'),('2019-09-13 07:59:59','2019-09-13 11:59:59','DLTBNB','4h','0.001683000000000','0.001633000000000','0.638903338853599','0.619922253326160','379.6217105487813','379.621710548781323','test'),('2019-09-13 15:59:59','2019-09-13 23:59:59','DLTBNB','4h','0.001684000000000','0.001641000000000','0.638903338853599','0.622589298728477','379.3962819795718','379.396281979571825','test'),('2019-09-14 07:59:59','2019-09-17 11:59:59','DLTBNB','4h','0.001668000000000','0.001991000000000','0.638903338853599','0.762623829530885','383.03557485227753','383.035574852277534','test'),('2019-09-18 03:59:59','2019-09-18 07:59:59','DLTBNB','4h','0.002133000000000','0.001997000000000','0.638903338853599','0.598166885930913','299.5327420785743','299.532742078574302','test'),('2019-09-19 11:59:59','2019-09-22 23:59:59','DLTBNB','4h','0.002146000000000','0.002175000000000','0.638903338853599','0.647537167757026','297.71823804920734','297.718238049207343','test'),('2019-09-23 07:59:59','2019-09-24 19:59:59','DLTBNB','4h','0.002340000000000','0.002139000000000','0.638903338853599','0.584023180259764','273.0356148947004','273.035614894700416','test'),('2019-09-25 15:59:59','2019-09-29 23:59:59','DLTBNB','4h','0.002679000000000','0.002704000000000','0.638903338853599','0.644865482739877','238.4857554511381','238.485755451138090','test'),('2019-09-30 11:59:59','2019-10-06 03:59:59','DLTBNB','4h','0.002933000000000','0.002927000000000','0.638903338853599','0.637596342592732','217.83271014442516','217.832710144425164','test'),('2019-10-08 19:59:59','2019-10-09 11:59:59','DLTBNB','4h','0.003141000000000','0.002858000000000','0.638903338853599','0.581338981994137','203.40762141152464','203.407621411524644','test'),('2019-11-08 03:59:59','2019-11-08 11:59:59','DLTBNB','4h','0.002110000000000','0.002053000000000','0.638903338853599','0.621643864770824','302.7977909258763','302.797790925876313','test'),('2019-11-09 23:59:59','2019-11-10 07:59:59','DLTBNB','4h','0.002109000000000','0.002032000000000','0.638903338853599','0.615576853746094','302.94136503252673','302.941365032526733','test'),('2019-11-11 03:59:59','2019-11-13 07:59:59','DLTBNB','4h','0.002123000000000','0.002156000000000','0.638903338853599','0.648834478835779','300.9436358236453','300.943635823645309','test'),('2019-11-13 15:59:59','2019-11-13 19:59:59','DLTBNB','4h','0.002163000000000','0.002118000000000','0.638903338853599','0.625611313773427','295.3783351149325','295.378335114932497','test'),('2019-11-15 03:59:59','2019-11-20 23:59:59','DLTBNB','4h','0.002199000000000','0.002285000000000','0.638903338853599','0.663890008767837','290.54267342137285','290.542673421372854','test'),('2019-11-22 19:59:59','2019-11-24 07:59:59','DLTBNB','4h','0.002431000000000','0.002360000000000','0.638903338853599','0.620243471696624','262.81503037992553','262.815030379925531','test'),('2019-11-24 11:59:59','2019-11-24 19:59:59','DLTBNB','4h','0.002368000000000','0.002361000000000','0.638903338853599','0.637014688780974','269.80715323209415','269.807153232094151','test'),('2019-11-24 23:59:59','2019-11-25 07:59:59','DLTBNB','4h','0.002397000000000','0.002483000000000','0.638903338853599','0.661826028524608','266.542903151272','266.542903151272014','test'),('2019-11-25 11:59:59','2019-12-02 15:59:59','DLTBNB','4h','0.002584000000000','0.002795000000000','0.638903338853599','0.691073851430267','247.25361410742994','247.253614107429939','test'),('2019-12-07 07:59:59','2019-12-08 03:59:59','DLTBNB','4h','0.002770000000000','0.002683000000000','0.638903338853599','0.618836699691049','230.65102485689494','230.651024856894935','test'),('2019-12-08 07:59:59','2019-12-10 03:59:59','DLTBNB','4h','0.002730000000000','0.002685000000000','0.638903338853599','0.628371965136232','234.03052705260038','234.030527052600377','test'),('2019-12-16 15:59:59','2019-12-17 19:59:59','DLTBNB','4h','0.002727000000000','0.002640000000000','0.638903338853599','0.618520284038688','234.28798637829078','234.287986378290782','test'),('2019-12-21 19:59:59','2019-12-22 03:59:59','DLTBNB','4h','0.002684000000000','0.002634000000000','0.638903338853599','0.627001264731885','238.0414824342768','238.041482434276787','test'),('2019-12-22 07:59:59','2019-12-22 19:59:59','DLTBNB','4h','0.002653000000000','0.002621000000000','0.638903338853599','0.631197003820310','240.82296979027478','240.822969790274783','test'),('2019-12-23 11:59:59','2019-12-23 15:59:59','DLTBNB','4h','0.002667000000000','0.002658000000000','0.638903338853599','0.636747309588626','239.5588072191972','239.558807219197206','test'),('2019-12-23 19:59:59','2019-12-24 03:59:59','DLTBNB','4h','0.002712000000000','0.002669000000000','0.638903338853599','0.628773234292130','235.58382701091406','235.583827010914064','test'),('2019-12-24 11:59:59','2019-12-29 11:59:59','DLTBNB','4h','0.002685000000000','0.002805000000000','0.638903338853599','0.667457678020240','237.95282638867747','237.952826388677465','test'),('2019-12-31 03:59:59','2019-12-31 19:59:59','DLTBNB','4h','0.003029000000000','0.002777000000000','0.638903338853599','0.585749280949635','210.92880120620632','210.928801206206316','test'),('2019-12-31 23:59:59','2020-01-01 03:59:59','DLTBNB','4h','0.002800000000000','0.002777000000000','0.638903338853599','0.633655204284444','228.17976387628534','228.179763876285335','test'),('2020-01-01 07:59:59','2020-01-01 15:59:59','DLTBNB','4h','0.002816000000000','0.002830000000000','0.638903338853599','0.642079704884831','226.88328794517008','226.883287945170082','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  2:08:47
