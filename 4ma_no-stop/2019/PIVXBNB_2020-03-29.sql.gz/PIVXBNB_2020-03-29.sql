-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-03 03:59:59','2019-01-03 07:59:59','PIVXBNB','4h','0.145920000000000','0.141510000000000','0.711908500000000','0.690393173211349','4.878758908991228','4.878758908991228','test'),('2019-01-05 03:59:59','2019-01-06 03:59:59','PIVXBNB','4h','0.166980000000000','0.144240000000000','0.711908500000000','0.614957971254043','4.2634357408072825','4.263435740807282','test'),('2019-01-06 07:59:59','2019-01-06 11:59:59','PIVXBNB','4h','0.144390000000000','0.147170000000000','0.711908500000000','0.725615166874437','4.930455710229241','4.930455710229241','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','PIVXBNB','4h','0.056930000000000','0.050140000000000','0.711908500000000','0.626999687159670','12.504979799754084','12.504979799754084','test'),('2019-03-29 11:59:59','2019-03-30 11:59:59','PIVXBNB','4h','0.058770000000000','0.053910000000000','0.711908500000000','0.653037046707504','12.113467755657648','12.113467755657648','test'),('2019-03-30 19:59:59','2019-03-30 23:59:59','PIVXBNB','4h','0.053920000000000','0.053530000000000','0.711908500000000','0.706759310181751','13.203050816023739','13.203050816023739','test'),('2019-03-31 03:59:59','2019-03-31 07:59:59','PIVXBNB','4h','0.055480000000000','0.052610000000000','0.711908500000000','0.675081221791637','12.83180425378515','12.831804253785149','test'),('2019-03-31 11:59:59','2019-03-31 15:59:59','PIVXBNB','4h','0.056180000000000','0.054770000000000','0.711908500000000','0.694041091936632','12.671920612317551','12.671920612317551','test'),('2019-04-01 07:59:59','2019-04-01 11:59:59','PIVXBNB','4h','0.055010000000000','0.053020000000000','0.711908500000000','0.686155038538448','12.941437920378114','12.941437920378114','test'),('2019-04-02 11:59:59','2019-04-02 15:59:59','PIVXBNB','4h','0.058200000000000','0.053640000000000','0.711908500000000','0.656130102061856','12.232104810996564','12.232104810996564','test'),('2019-04-03 15:59:59','2019-04-03 23:59:59','PIVXBNB','4h','0.055790000000000','0.053260000000000','0.711908500000000','0.679624425703531','12.760503674493638','12.760503674493638','test'),('2019-04-07 07:59:59','2019-04-09 11:59:59','PIVXBNB','4h','0.055230000000000','0.054710000000000','0.711908500000000','0.705205758374072','12.889887742169112','12.889887742169112','test'),('2019-04-09 15:59:59','2019-04-09 23:59:59','PIVXBNB','4h','0.054750000000000','0.054660000000000','0.711908500000000','0.710738239452055','13.002894977168951','13.002894977168951','test'),('2019-04-10 07:59:59','2019-04-10 19:59:59','PIVXBNB','4h','0.056310000000000','0.052980000000000','0.711908500000000','0.669808423548215','12.642665601136567','12.642665601136567','test'),('2019-05-09 15:59:59','2019-05-11 11:59:59','PIVXBNB','4h','0.029910000000000','0.028750000000000','0.711908500000000','0.684298541457707','23.801688398528924','23.801688398528924','test'),('2019-06-03 15:59:59','2019-06-03 19:59:59','PIVXBNB','4h','0.022240000000000','0.022230000000000','0.711908500000000','0.711588397257194','32.010274280575544','32.010274280575544','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','PIVXBNB','4h','0.022190000000000','0.022470000000000','0.711908500000000','0.720891572555205','32.08240198287517','32.082401982875169','test'),('2019-06-04 23:59:59','2019-06-05 11:59:59','PIVXBNB','4h','0.022600000000000','0.021640000000000','0.711908500000000','0.681668138938053','31.500376106194693','31.500376106194693','test'),('2019-06-09 11:59:59','2019-06-10 11:59:59','PIVXBNB','4h','0.022970000000000','0.021780000000000','0.711908500000000','0.675026866782760','30.992969090117548','30.992969090117548','test'),('2019-06-10 15:59:59','2019-06-12 03:59:59','PIVXBNB','4h','0.021830000000000','0.021970000000000','0.711908500000000','0.716474106504810','32.611475034356395','32.611475034356395','test'),('2019-06-12 07:59:59','2019-06-12 11:59:59','PIVXBNB','4h','0.022240000000000','0.021960000000000','0.711908500000000','0.702945623201439','32.010274280575544','32.010274280575544','test'),('2019-06-16 07:59:59','2019-06-17 15:59:59','PIVXBNB','4h','0.022630000000000','0.022070000000000','0.711908500000000','0.694291674547061','31.45861688024746','31.458616880247462','test'),('2019-07-02 15:59:59','2019-07-02 19:59:59','PIVXBNB','4h','0.024430000000000','0.019340000000000','0.711908500000000','0.563582087187884','29.14074907900123','29.140749079001228','test'),('2019-07-02 23:59:59','2019-07-03 07:59:59','PIVXBNB','4h','0.020050000000000','0.019310000000000','0.474605666666667','0.457089048545304','23.671105569409814','23.671105569409814','test'),('2019-07-03 11:59:59','2019-07-03 15:59:59','PIVXBNB','4h','0.019450000000000','0.019370000000000','0.525383886776487','0.523222924774321','27.012025027068752','27.012025027068752','test'),('2019-07-06 03:59:59','2019-07-08 11:59:59','PIVXBNB','4h','0.019950000000000','0.019690000000000','0.525383886776487','0.518536778477646','26.335031918620903','26.335031918620903','test'),('2019-07-26 03:59:59','2019-07-31 11:59:59','PIVXBNB','4h','0.017080000000000','0.017360000000000','0.525383886776487','0.533996737379380','30.76018072461867','30.760180724618671','test'),('2019-08-22 15:59:59','2019-08-26 07:59:59','PIVXBNB','4h','0.012690000000000','0.012630000000000','0.525383886776487','0.522899802205440','41.40140951745366','41.401409517453658','test'),('2019-08-27 07:59:59','2019-08-27 15:59:59','PIVXBNB','4h','0.013520000000000','0.013010000000000','0.525383886776487','0.505565411757551','38.85975493908927','38.859754939089271','test'),('2019-08-27 23:59:59','2019-09-05 19:59:59','PIVXBNB','4h','0.013240000000000','0.014390000000000','0.525383886776487','0.571017683588644','39.681562445354','39.681562445353997','test'),('2019-09-06 03:59:59','2019-09-07 11:59:59','PIVXBNB','4h','0.015720000000000','0.015230000000000','0.531117891157502','0.514562689715570','33.78612539169862','33.786125391698619','test'),('2019-09-08 11:59:59','2019-09-08 15:59:59','PIVXBNB','4h','0.015800000000000','0.015280000000000','0.531117891157502','0.513638061828268','33.61505640237354','33.615056402373540','test'),('2019-10-01 19:59:59','2019-10-05 19:59:59','PIVXBNB','4h','0.015800000000000','0.014670000000000','0.531117891157502','0.493132877422820','33.61505640237354','33.615056402373540','test'),('2019-10-06 19:59:59','2019-10-10 03:59:59','PIVXBNB','4h','0.015160000000000','0.016250000000000','0.531117891157502','0.569305127395080','35.03416168585105','35.034161685851053','test'),('2019-11-03 23:59:59','2019-11-04 03:59:59','PIVXBNB','4h','0.012760000000000','0.011920000000000','0.531117891157502','0.496154017444939','41.62365918162241','41.623659181622408','test'),('2019-11-04 15:59:59','2019-11-04 23:59:59','PIVXBNB','4h','0.012440000000000','0.012000000000000','0.531117891157502','0.512332370891481','42.69436424095675','42.694364240956752','test'),('2019-11-16 15:59:59','2019-11-17 15:59:59','PIVXBNB','4h','0.012160000000000','0.011630000000000','0.531117891157502','0.507968838335670','43.67745815439983','43.677458154399829','test'),('2019-11-17 19:59:59','2019-11-18 15:59:59','PIVXBNB','4h','0.011990000000000','0.011890000000000','0.531117891157502','0.526688217336338','44.29673821163486','44.296738211634860','test'),('2019-11-18 19:59:59','2019-11-19 03:59:59','PIVXBNB','4h','0.011970000000000','0.011720000000000','0.531117891157502','0.520025203372258','44.37075114097761','44.370751140977610','test'),('2019-11-19 23:59:59','2019-11-22 07:59:59','PIVXBNB','4h','0.012100000000000','0.011840000000000','0.531117891157502','0.519705440603704','43.89404059152909','43.894040591529091','test'),('2019-11-22 19:59:59','2019-11-23 19:59:59','PIVXBNB','4h','0.012560000000000','0.012410000000000','0.531117891157502','0.524774922712150','42.28645630234888','42.286456302348881','test'),('2019-11-26 07:59:59','2019-11-29 03:59:59','PIVXBNB','4h','0.014730000000000','0.014370000000000','0.531117891157502','0.518137413165873','36.0568833100816','36.056883310081602','test'),('2019-11-29 19:59:59','2019-11-30 23:59:59','PIVXBNB','4h','0.015250000000000','0.014410000000000','0.531117891157502','0.501862872890466','34.82740269885259','34.827402698852588','test'),('2019-12-01 07:59:59','2019-12-01 15:59:59','PIVXBNB','4h','0.015030000000000','0.014800000000000','0.531117891157502','0.522990338598206','35.33718504041929','35.337185040419293','test'),('2019-12-07 23:59:59','2019-12-09 07:59:59','PIVXBNB','4h','0.014270000000000','0.014310000000000','0.531117891157502','0.532606658897257','37.219193493868396','37.219193493868396','test'),('2019-12-09 15:59:59','2019-12-10 03:59:59','PIVXBNB','4h','0.015030000000000','0.014180000000000','0.531117891157502','0.501081283873146','35.33718504041929','35.337185040419293','test'),('2019-12-10 07:59:59','2019-12-10 11:59:59','PIVXBNB','4h','0.014230000000000','0.014030000000000','0.531117891157502','0.523653128105394','37.32381526054125','37.323815260541252','test'),('2019-12-11 07:59:59','2019-12-11 11:59:59','PIVXBNB','4h','0.014520000000000','0.014360000000000','0.531117891157502','0.525265352411965','36.57836715960757','36.578367159607573','test'),('2019-12-11 19:59:59','2019-12-12 03:59:59','PIVXBNB','4h','0.014450000000000','0.014500000000000','0.531117891157502','0.532955669327597','36.75556340190325','36.755563401903252','test'),('2019-12-12 11:59:59','2019-12-13 03:59:59','PIVXBNB','4h','0.014470000000000','0.014360000000000','0.531117891157502','0.527080367451398','36.70476096458203','36.704760964582029','test'),('2019-12-13 11:59:59','2019-12-13 15:59:59','PIVXBNB','4h','0.014520000000000','0.014860000000000','0.531117891157502','0.543554535991769','36.57836715960757','36.578367159607573','test'),('2019-12-13 19:59:59','2019-12-21 19:59:59','PIVXBNB','4h','0.015050000000000','0.016400000000000','0.531117891157502','0.578759695347710','35.29022532607987','35.290225326079870','test'),('2019-12-22 11:59:59','2019-12-22 15:59:59','PIVXBNB','4h','0.016550000000000','0.016340000000000','0.531117891157502','0.524378630907165','32.091715477794686','32.091715477794686','test'),('2019-12-22 19:59:59','2019-12-23 15:59:59','PIVXBNB','4h','0.016600000000000','0.016400000000000','0.531117891157502','0.524718880420665','31.995053684186864','31.995053684186864','test'),('2019-12-24 11:59:59','2019-12-26 03:59:59','PIVXBNB','4h','0.016710000000000','0.016330000000000','0.531117891157502','0.519039806259845','31.78443394120299','31.784433941202991','test'),('2019-12-26 11:59:59','2019-12-28 19:59:59','PIVXBNB','4h','0.016850000000000','0.016510000000000','0.531117891157502','0.520400972285481','31.52034962359062','31.520349623590619','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 18:47:22
