-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-07 19:59:59','2019-01-07 23:59:59','AIONBNB','4h','0.026660000000000','0.025770000000000','0.711908500000000','0.688142612340585','26.703244561140288','26.703244561140288','test'),('2019-03-14 11:59:59','2019-03-14 15:59:59','AIONBNB','4h','0.009670000000000','0.009260000000000','0.711908500000000','0.681724168562565','73.62032057911065','73.620320579110654','test'),('2019-03-21 07:59:59','2019-03-21 15:59:59','AIONBNB','4h','0.009370000000000','0.009340000000000','0.711908500000000','0.709629177161153','75.97742796157952','75.977427961579522','test'),('2019-03-21 23:59:59','2019-03-22 11:59:59','AIONBNB','4h','0.009640000000000','0.009280000000000','0.711908500000000','0.685322705394191','73.84942946058092','73.849429460580922','test'),('2019-03-23 19:59:59','2019-03-24 11:59:59','AIONBNB','4h','0.009480000000000','0.008420000000000','0.711908500000000','0.632306916666667','75.09583333333333','75.095833333333331','test'),('2019-03-28 23:59:59','2019-04-01 23:59:59','AIONBNB','4h','0.009530000000000','0.009570000000000','0.711908500000000','0.714896573452256','74.70183630640085','74.701836306400850','test'),('2019-04-02 23:59:59','2019-04-08 03:59:59','AIONBNB','4h','0.010350000000000','0.011310000000000','0.711908500000000','0.777940592753623','68.78342995169083','68.783429951690835','test'),('2019-04-08 07:59:59','2019-04-08 11:59:59','AIONBNB','4h','0.011760000000000','0.011310000000000','0.711908500000000','0.684667103316327','60.53643707482994','60.536437074829941','test'),('2019-04-08 15:59:59','2019-04-08 23:59:59','AIONBNB','4h','0.011700000000000','0.011380000000000','0.711908500000000','0.692437498290598','60.84688034188034','60.846880341880343','test'),('2019-05-04 03:59:59','2019-05-06 03:59:59','AIONBNB','4h','0.008600000000000','0.008250000000000','0.711908500000000','0.682935479651163','82.78005813953489','82.780058139534887','test'),('2019-05-06 07:59:59','2019-05-08 07:59:59','AIONBNB','4h','0.008480000000000','0.008640000000000','0.711908500000000','0.725340735849057','83.95147405660379','83.951474056603786','test'),('2019-05-08 11:59:59','2019-05-09 03:59:59','AIONBNB','4h','0.009060000000000','0.008380000000000','0.711908500000000','0.658476073951435','78.57709713024283','78.577097130242834','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','AIONBNB','4h','0.009160000000000','0.008750000000000','0.711908500000000','0.680043599890830','77.71926855895197','77.719268558951967','test'),('2019-05-10 15:59:59','2019-05-13 07:59:59','AIONBNB','4h','0.008960000000000','0.009020000000000','0.711908500000000','0.716675744419643','79.4540736607143','79.454073660714300','test'),('2019-06-01 15:59:59','2019-06-03 23:59:59','AIONBNB','4h','0.006800000000000','0.006640000000000','0.711908500000000','0.695157711764706','104.69242647058825','104.692426470588245','test'),('2019-07-24 23:59:59','2019-07-27 23:59:59','AIONBNB','4h','0.003286000000000','0.003430000000000','0.711908500000000','0.743105951004260','216.6489653073646','216.648965307364591','test'),('2019-07-28 15:59:59','2019-07-31 19:59:59','AIONBNB','4h','0.003738000000000','0.003941000000000','0.711908500000000','0.750570197565543','190.45171214553238','190.451712145532383','test'),('2019-08-23 03:59:59','2019-08-23 15:59:59','AIONBNB','4h','0.003005000000000','0.003496000000000','0.711908500000000','0.828230321464226','236.90798668885193','236.907986688851935','test'),('2019-08-23 19:59:59','2019-08-26 07:59:59','AIONBNB','4h','0.003804000000000','0.003362000000000','0.711908500000000','0.629189373554153','187.14734490010517','187.147344900105168','test'),('2019-08-31 23:59:59','2019-09-02 15:59:59','AIONBNB','4h','0.003395000000000','0.003154000000000','0.711908500000000','0.661372432695140','209.6932253313697','209.693225331369689','test'),('2019-09-04 07:59:59','2019-09-04 23:59:59','AIONBNB','4h','0.003460000000000','0.003313000000000','0.711908500000000','0.681662676445087','205.75390173410406','205.753901734104062','test'),('2019-09-05 03:59:59','2019-09-05 07:59:59','AIONBNB','4h','0.003329000000000','0.003263000000000','0.711908500000000','0.697794363322319','213.8505557224392','213.850555722439196','test'),('2019-09-05 11:59:59','2019-09-05 15:59:59','AIONBNB','4h','0.003304000000000','0.003270000000000','0.711908500000000','0.704582565072639','215.46867433414045','215.468674334140445','test'),('2019-09-09 23:59:59','2019-09-14 19:59:59','AIONBNB','4h','0.003355000000000','0.003437000000000','0.711908500000000','0.729308350074516','212.19329359165428','212.193293591654282','test'),('2019-09-15 23:59:59','2019-09-18 11:59:59','AIONBNB','4h','0.003589000000000','0.003430000000000','0.711908500000000','0.680369505433268','198.35845639453888','198.358456394538877','test'),('2019-09-18 23:59:59','2019-09-19 03:59:59','AIONBNB','4h','0.003601000000000','0.003491000000000','0.711908500000000','0.690161781033046','197.69744515412387','197.697445154123869','test'),('2019-09-19 07:59:59','2019-09-19 19:59:59','AIONBNB','4h','0.003593000000000','0.003506000000000','0.711908500000000','0.694670526301141','198.13762872251604','198.137628722516041','test'),('2019-09-19 23:59:59','2019-09-23 19:59:59','AIONBNB','4h','0.003720000000000','0.003699000000000','0.711908500000000','0.707889661693548','191.37325268817204','191.373252688172045','test'),('2019-09-24 23:59:59','2019-09-29 15:59:59','AIONBNB','4h','0.003856000000000','0.004157000000000','0.711908500000000','0.767480195669087','184.6235736514523','184.623573651452290','test'),('2019-10-02 07:59:59','2019-10-08 07:59:59','AIONBNB','4h','0.004307000000000','0.004629000000000','0.711908500000000','0.765132214186209','165.291037845368','165.291037845368010','test'),('2019-10-08 11:59:59','2019-10-09 11:59:59','AIONBNB','4h','0.004785000000000','0.004398000000000','0.711908500000000','0.654330947335423','148.77920585161965','148.779205851619651','test'),('2019-10-24 03:59:59','2019-10-24 19:59:59','AIONBNB','4h','0.003854000000000','0.003846000000000','0.711908500000000','0.710430744940322','184.71938245978208','184.719382459782082','test'),('2019-10-27 19:59:59','2019-10-27 23:59:59','AIONBNB','4h','0.003880000000000','0.003804000000000','0.711908500000000','0.697963900515464','183.48157216494846','183.481572164948460','test'),('2019-10-30 19:59:59','2019-10-31 03:59:59','AIONBNB','4h','0.003873000000000','0.003821000000000','0.711908500000000','0.702350213916860','183.8131939065324','183.813193906532405','test'),('2019-10-31 07:59:59','2019-10-31 11:59:59','AIONBNB','4h','0.003851000000000','0.003773000000000','0.711908500000000','0.697489163983381','184.86328226434694','184.863282264346935','test'),('2019-10-31 15:59:59','2019-10-31 19:59:59','AIONBNB','4h','0.003808000000000','0.003830000000000','0.711908500000000','0.716021416754202','186.95076155462186','186.950761554621863','test'),('2019-11-01 07:59:59','2019-11-01 15:59:59','AIONBNB','4h','0.003830000000000','0.003846000000000','0.711908500000000','0.714882530287206','185.87689295039166','185.876892950391664','test'),('2019-11-01 19:59:59','2019-11-09 15:59:59','AIONBNB','4h','0.003866000000000','0.004301000000000','0.711908500000000','0.792012017201242','184.14601655457838','184.146016554578381','test'),('2019-11-09 19:59:59','2019-11-09 23:59:59','AIONBNB','4h','0.004346000000000','0.004309000000000','0.711908500000000','0.705847613092499','163.80775425678786','163.807754256787860','test'),('2019-11-18 07:59:59','2019-11-20 23:59:59','AIONBNB','4h','0.004260000000000','0.004136000000000','0.711908500000000','0.691186280751174','167.11467136150236','167.114671361502360','test'),('2019-11-27 15:59:59','2019-11-27 19:59:59','AIONBNB','4h','0.004115000000000','0.004010000000000','0.711908500000000','0.693743155528554','173.00328068043746','173.003280680437456','test'),('2019-11-29 03:59:59','2019-11-30 15:59:59','AIONBNB','4h','0.004199000000000','0.004112000000000','0.711908500000000','0.697158311979043','169.54239104548705','169.542391045487051','test'),('2019-12-01 15:59:59','2019-12-01 23:59:59','AIONBNB','4h','0.004112000000000','0.004111000000000','0.711908500000000','0.711735370500973','173.12949902723736','173.129499027237358','test'),('2019-12-06 11:59:59','2019-12-06 19:59:59','AIONBNB','4h','0.004112000000000','0.004070000000000','0.711908500000000','0.704637061040856','173.12949902723736','173.129499027237358','test'),('2019-12-06 23:59:59','2019-12-07 15:59:59','AIONBNB','4h','0.004116000000000','0.004068000000000','0.711908500000000','0.703606360058309','172.9612487852284','172.961248785228406','test'),('2019-12-07 19:59:59','2019-12-09 15:59:59','AIONBNB','4h','0.004075000000000','0.004112000000000','0.711908500000000','0.718372454478528','174.70147239263807','174.701472392638067','test'),('2019-12-20 19:59:59','2019-12-22 19:59:59','AIONBNB','4h','0.004120000000000','0.004080000000000','0.711908500000000','0.704996766990291','172.79332524271845','172.793325242718453','test'),('2019-12-22 23:59:59','2019-12-23 03:59:59','AIONBNB','4h','0.004134000000000','0.004013000000000','0.711908500000000','0.691071313618771','172.20815191098214','172.208151910982139','test'),('2019-12-25 11:59:59','2019-12-25 19:59:59','AIONBNB','4h','0.004130000000000','0.004050000000000','0.711908500000000','0.698118504842615','172.37493946731237','172.374939467312373','test'),('2019-12-25 23:59:59','2019-12-26 03:59:59','AIONBNB','4h','0.004087000000000','0.004024000000000','0.711908500000000','0.700934622950820','174.18852459016392','174.188524590163922','test'),('2019-12-26 23:59:59','2019-12-28 03:59:59','AIONBNB','4h','0.004130000000000','0.004062000000000','0.711908500000000','0.700187004116223','172.37493946731237','172.374939467312373','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30 17:07:28
