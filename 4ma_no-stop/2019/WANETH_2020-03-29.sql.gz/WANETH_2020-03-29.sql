-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-13 11:59:59','2019-01-13 19:59:59','WANETH','4h','0.002493000000000','0.002479000000000','0.072144500000000','0.071739356397914','28.938828720417167','28.938828720417167','test'),('2019-01-14 03:59:59','2019-01-14 07:59:59','WANETH','4h','0.002470000000000','0.002472000000000','0.072144500000000','0.072202916599190','29.2082995951417','29.208299595141700','test'),('2019-01-16 15:59:59','2019-01-20 15:59:59','WANETH','4h','0.002602000000000','0.002626000000000','0.072144500000000','0.072809937355880','27.72655649500384','27.726556495003841','test'),('2019-01-22 03:59:59','2019-01-23 23:59:59','WANETH','4h','0.002778000000000','0.002709000000000','0.072224177588246','0.070430272529359','25.998624041845208','25.998624041845208','test'),('2019-01-24 03:59:59','2019-01-27 15:59:59','WANETH','4h','0.002756000000000','0.002751000000000','0.072224177588246','0.072093146787106','26.206160227955728','26.206160227955728','test'),('2019-02-27 03:59:59','2019-03-04 19:59:59','WANETH','4h','0.002271000000000','0.002309000000000','0.072224177588246','0.073432684302624','31.802808273115804','31.802808273115804','test'),('2019-03-08 11:59:59','2019-03-15 23:59:59','WANETH','4h','0.002367000000000','0.003156000000000','0.072224177588246','0.096298903450995','30.51296053580312','30.512960535803121','test'),('2019-03-24 07:59:59','2019-03-24 11:59:59','WANETH','4h','0.003052000000000','0.002987000000000','0.078063751767521','0.076401188246915','25.577900317012126','25.577900317012126','test'),('2019-03-24 15:59:59','2019-03-24 23:59:59','WANETH','4h','0.002993000000000','0.002981000000000','0.078063751767521','0.077750766461403','26.082108843140997','26.082108843140997','test'),('2019-03-28 19:59:59','2019-03-29 11:59:59','WANETH','4h','0.003077000000000','0.002955000000000','0.078063751767521','0.074968601388698','25.37008507231752','25.370085072317519','test'),('2019-03-29 15:59:59','2019-03-29 23:59:59','WANETH','4h','0.002999000000000','0.002950000000000','0.078063751767521','0.076788285333173','26.029927231584196','26.029927231584196','test'),('2019-03-31 11:59:59','2019-04-02 07:59:59','WANETH','4h','0.003002000000000','0.003110000000000','0.078063751767521','0.080872174549297','26.003914646076286','26.003914646076286','test'),('2019-05-23 23:59:59','2019-05-24 15:59:59','WANETH','4h','0.001854000000000','0.001713000000000','0.078063751767521','0.072126864497176','42.1055834776273','42.105583477627299','test'),('2019-06-02 15:59:59','2019-06-06 07:59:59','WANETH','4h','0.001911000000000','0.001753000000000','0.078063751767521','0.071609501228919','40.84968695317688','40.849686953176878','test'),('2019-06-07 07:59:59','2019-06-10 11:59:59','WANETH','4h','0.001840000000000','0.001834000000000','0.078063751767521','0.077809196055236','42.425952047565765','42.425952047565765','test'),('2019-06-10 23:59:59','2019-06-11 15:59:59','WANETH','4h','0.001889000000000','0.001845000000000','0.078063751767521','0.076245432509834','41.32543767470673','41.325437674706727','test'),('2019-06-14 03:59:59','2019-06-14 11:59:59','WANETH','4h','0.001945000000000','0.001823000000000','0.078063751767521','0.073167207954854','40.1356050218617','40.135605021861700','test'),('2019-07-21 19:59:59','2019-07-23 19:59:59','WANETH','4h','0.001157000000000','0.001190000000000','0.078063751767521','0.080290289199092','67.47083125974157','67.470831259741573','test'),('2019-07-23 23:59:59','2019-07-28 07:59:59','WANETH','4h','0.001201000000000','0.001330000000000','0.078063751767521','0.086448617694257','64.99896067237385','64.998960672373855','test'),('2019-07-29 11:59:59','2019-07-30 15:59:59','WANETH','4h','0.001375000000000','0.001335000000000','0.078063751767521','0.075792806261557','56.77363764910619','56.773637649106192','test'),('2019-08-13 11:59:59','2019-08-13 15:59:59','WANETH','4h','0.001175000000000','0.001133000000000','0.078063751767521','0.075273387874554','66.43723554682639','66.437235546826386','test'),('2019-08-16 15:59:59','2019-08-16 23:59:59','WANETH','4h','0.001160000000000','0.001153000000000','0.078063751767521','0.077592677403407','67.29633773062156','67.296337730621559','test'),('2019-08-17 07:59:59','2019-08-18 03:59:59','WANETH','4h','0.001167000000000','0.001156000000000','0.078063751767521','0.077327932342120','66.89267503643616','66.892675036436160','test'),('2019-08-18 07:59:59','2019-08-18 11:59:59','WANETH','4h','0.001166000000000','0.001143000000000','0.078063751767521','0.076523900746378','66.95004439753089','66.950044397530888','test'),('2019-08-22 23:59:59','2019-08-27 23:59:59','WANETH','4h','0.001289000000000','0.002167000000000','0.078063751767521','0.131236733964483','60.56148314004733','60.561483140047329','test'),('2019-08-31 11:59:59','2019-08-31 23:59:59','WANETH','4h','0.002321000000000','0.001973000000000','0.086333259741515','0.073388850267130','37.19657894938161','37.196578949381610','test'),('2019-09-01 19:59:59','2019-09-03 11:59:59','WANETH','4h','0.002357000000000','0.002206000000000','0.086333259741515','0.080802363593459','36.62845131163131','36.628451311631309','test'),('2019-10-04 15:59:59','2019-10-04 19:59:59','WANETH','4h','0.001159000000000','0.001145000000000','0.086333259741515','0.085290407596234','74.48943894867557','74.489438948675570','test'),('2019-10-04 23:59:59','2019-10-05 15:59:59','WANETH','4h','0.001151000000000','0.001150000000000','0.086333259741515','0.086258252565371','75.00717614380105','75.007176143801047','test'),('2019-10-09 07:59:59','2019-10-10 11:59:59','WANETH','4h','0.001202000000000','0.001169000000000','0.086333259741515','0.083963045455766','71.82467532571964','71.824675325719639','test'),('2019-10-21 19:59:59','2019-10-23 15:59:59','WANETH','4h','0.001168000000000','0.001109000000000','0.086333259741515','0.081972247477175','73.91546210746147','73.915462107461465','test'),('2019-10-27 07:59:59','2019-10-27 11:59:59','WANETH','4h','0.001143000000000','0.001110000000000','0.086333259741515','0.083840698436642','75.53216075373142','75.532160753731418','test'),('2019-10-27 15:59:59','2019-10-29 03:59:59','WANETH','4h','0.001266000000000','0.001187000000000','0.086333259741515','0.080945955223680','68.19372807386651','68.193728073866509','test'),('2019-10-29 07:59:59','2019-10-29 15:59:59','WANETH','4h','0.001199000000000','0.001189000000000','0.086333259741515','0.085613215873779','72.00438677357381','72.004386773573813','test'),('2019-10-31 07:59:59','2019-11-03 11:59:59','WANETH','4h','0.001225000000000','0.001223000000000','0.086333259741515','0.086192307480713','70.47613040123673','70.476130401236730','test'),('2019-11-05 19:59:59','2019-11-07 07:59:59','WANETH','4h','0.001325000000000','0.001220000000000','0.086333259741515','0.079491756139357','65.15717716340754','65.157177163407539','test'),('2019-11-13 23:59:59','2019-11-14 11:59:59','WANETH','4h','0.001245000000000','0.001211000000000','0.086333259741515','0.083975564294759','69.3439837281245','69.343983728124499','test'),('2019-11-14 19:59:59','2019-11-14 23:59:59','WANETH','4h','0.001217000000000','0.001197000000000','0.086333259741515','0.084914471578138','70.93940816887017','70.939408168870173','test'),('2019-11-16 19:59:59','2019-11-19 11:59:59','WANETH','4h','0.001239000000000','0.001231000000000','0.086333259741515','0.085775821421957','69.67978994472558','69.679789944725584','test'),('2019-11-20 15:59:59','2019-11-21 11:59:59','WANETH','4h','0.001383000000000','0.001267000000000','0.086333259741515','0.079092002959146','62.424627434211864','62.424627434211864','test'),('2019-11-21 15:59:59','2019-11-21 19:59:59','WANETH','4h','0.001302000000000','0.001286000000000','0.086333259741515','0.085272328746228','66.30818720546466','66.308187205464662','test'),('2019-11-22 03:59:59','2019-11-22 11:59:59','WANETH','4h','0.001337000000000','0.001294000000000','0.086333259741515','0.083556647797697','64.57237078647344','64.572370786473442','test'),('2019-11-23 15:59:59','2019-11-24 19:59:59','WANETH','4h','0.001346000000000','0.001326000000000','0.086333259741515','0.085050447561106','64.14060902044206','64.140609020442056','test'),('2019-11-25 07:59:59','2019-11-25 11:59:59','WANETH','4h','0.001321000000000','0.001302000000000','0.086333259741515','0.085091524741448','65.35447368774793','65.354473687747927','test'),('2019-11-26 07:59:59','2019-11-27 11:59:59','WANETH','4h','0.001334000000000','0.001367000000000','0.086333259741515','0.088468940079948','64.71758601312969','64.717586013129690','test'),('2019-11-27 15:59:59','2019-11-30 15:59:59','WANETH','4h','0.001425000000000','0.001369000000000','0.086333259741515','0.082940514095533','60.58474367825614','60.584743678256139','test'),('2019-12-16 15:59:59','2019-12-21 07:59:59','WANETH','4h','0.001330000000000','0.001482000000000','0.086333259741515','0.096199917997688','64.91222536956015','64.912225369560147','test'),('2019-12-26 03:59:59','2019-12-26 11:59:59','WANETH','4h','0.001416000000000','0.001409000000000','0.086333259741515','0.085906471028104','60.969816201634885','60.969816201634885','test'),('2019-12-26 15:59:59','2019-12-26 19:59:59','WANETH','4h','0.001414000000000','0.001368000000000','0.086333259741515','0.083524681277505','61.05605356542787','61.056053565427867','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29 10:09:37
