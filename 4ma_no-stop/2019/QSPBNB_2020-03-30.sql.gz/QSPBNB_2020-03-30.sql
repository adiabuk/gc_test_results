-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-04 11:59:59','2019-01-05 07:59:59','QSPBNB','4h','0.002732000000000','0.002610000000000','0.711908500000000','0.680117564055637','260.5814421669107','260.581442166910676','test'),('2019-01-05 11:59:59','2019-01-05 15:59:59','QSPBNB','4h','0.002650000000000','0.002574000000000','0.711908500000000','0.691491501509434','268.6447169811321','268.644716981132092','test'),('2019-01-05 19:59:59','2019-01-05 23:59:59','QSPBNB','4h','0.002637000000000','0.002614000000000','0.711908500000000','0.705699210845658','269.9690936670459','269.969093667045911','test'),('2019-01-06 15:59:59','2019-01-06 23:59:59','QSPBNB','4h','0.002666000000000','0.002655000000000','0.711908500000000','0.708971143098275','267.03244561140286','267.032445611402864','test'),('2019-01-07 19:59:59','2019-01-07 23:59:59','QSPBNB','4h','0.002748000000000','0.002605000000000','0.711908500000000','0.674862315320233','259.0642285298399','259.064228529839909','test'),('2019-01-19 11:59:59','2019-01-20 11:59:59','QSPBNB','4h','0.002687000000000','0.002529000000000','0.711908500000000','0.670047114439896','264.9454782285076','264.945478228507625','test'),('2019-01-20 15:59:59','2019-01-20 19:59:59','QSPBNB','4h','0.002585000000000','0.002503000000000','0.711908500000000','0.689325715860735','275.39980657640234','275.399806576402341','test'),('2019-01-20 23:59:59','2019-01-21 07:59:59','QSPBNB','4h','0.002609000000000','0.002540000000000','0.711908500000000','0.693080716749712','272.86642391720966','272.866423917209659','test'),('2019-01-21 11:59:59','2019-01-21 15:59:59','QSPBNB','4h','0.002711000000000','0.002640000000000','0.711908500000000','0.693263902618960','262.5999631132424','262.599963113242381','test'),('2019-01-22 23:59:59','2019-01-23 15:59:59','QSPBNB','4h','0.002623000000000','0.002637000000000','0.711908500000000','0.715708240373618','271.41002668699963','271.410026686999629','test'),('2019-02-26 19:59:59','2019-02-28 11:59:59','QSPBNB','4h','0.001688000000000','0.001547000000000','0.711908500000000','0.652442209419431','421.7467417061612','421.746741706161174','test'),('2019-03-16 23:59:59','2019-03-21 15:59:59','QSPBNB','4h','0.001338000000000','0.001399000000000','0.711908500000000','0.744364717115097','532.0691330343797','532.069133034379661','test'),('2019-03-21 23:59:59','2019-03-22 11:59:59','QSPBNB','4h','0.001416000000000','0.001399000000000','0.711908500000000','0.703361575918079','502.76024011299444','502.760240112994438','test'),('2019-03-27 23:59:59','2019-03-31 03:59:59','QSPBNB','4h','0.001399000000000','0.001422000000000','0.711908500000000','0.723612499642602','508.8695496783417','508.869549678341684','test'),('2019-04-03 19:59:59','2019-04-04 03:59:59','QSPBNB','4h','0.001511000000000','0.001435000000000','0.711908500000000','0.676101057246856','471.1505625413634','471.150562541363399','test'),('2019-04-04 07:59:59','2019-04-09 11:59:59','QSPBNB','4h','0.001492000000000','0.001531000000000','0.711908500000000','0.730517368297587','477.1504691689008','477.150469168900827','test'),('2019-05-09 03:59:59','2019-05-09 19:59:59','QSPBNB','4h','0.000999000000000','0.000964000000000','0.711908500000000','0.686966760760761','712.6211211211211','712.621121121121064','test'),('2019-05-09 23:59:59','2019-05-10 03:59:59','QSPBNB','4h','0.000975000000000','0.000971000000000','0.711908500000000','0.708987849743590','730.1625641025641','730.162564102564147','test'),('2019-05-10 07:59:59','2019-05-10 11:59:59','QSPBNB','4h','0.001016000000000','0.000997000000000','0.711908500000000','0.698595250492126','700.6973425196851','700.697342519685094','test'),('2019-05-10 15:59:59','2019-05-12 11:59:59','QSPBNB','4h','0.001026000000000','0.000990000000000','0.711908500000000','0.686929254385965','693.867933723197','693.867933723196984','test'),('2019-05-12 15:59:59','2019-05-12 23:59:59','QSPBNB','4h','0.001005000000000','0.001011000000000','0.711908500000000','0.716158700000000','708.3666666666667','708.366666666666674','test'),('2019-05-29 11:59:59','2019-05-30 03:59:59','QSPBNB','4h','0.000844000000000','0.000833000000000','0.711908500000000','0.702630071682464','843.4934834123223','843.493483412322348','test'),('2019-05-30 11:59:59','2019-05-30 23:59:59','QSPBNB','4h','0.000834000000000','0.000799000000000','0.711908500000000','0.682032244004796','853.6073141486811','853.607314148681098','test'),('2019-06-02 19:59:59','2019-06-03 07:59:59','QSPBNB','4h','0.000840000000000','0.000843000000000','0.711908500000000','0.714451030357143','847.5101190476191','847.510119047619128','test'),('2019-06-03 15:59:59','2019-06-03 23:59:59','QSPBNB','4h','0.000837000000000','0.000813000000000','0.711908500000000','0.691495353046595','850.5477897252092','850.547789725209213','test'),('2019-06-04 03:59:59','2019-06-04 07:59:59','QSPBNB','4h','0.000825000000000','0.000820000000000','0.711908500000000','0.707593903030303','862.919393939394','862.919393939394013','test'),('2019-06-09 07:59:59','2019-06-09 19:59:59','QSPBNB','4h','0.000831000000000','0.000798000000000','0.711908500000000','0.683637765342960','856.6889290012034','856.688929001203405','test'),('2019-06-09 23:59:59','2019-06-10 03:59:59','QSPBNB','4h','0.000810000000000','0.000808000000000','0.711908500000000','0.710150701234568','878.8993827160494','878.899382716049445','test'),('2019-06-10 07:59:59','2019-06-12 03:59:59','QSPBNB','4h','0.000822000000000','0.000795000000000','0.711908500000000','0.688524644160584','866.0687347931873','866.068734793187332','test'),('2019-06-16 15:59:59','2019-06-17 07:59:59','QSPBNB','4h','0.000850000000000','0.000793000000000','0.711908500000000','0.664168753529412','837.539411764706','837.539411764705960','test'),('2019-06-17 11:59:59','2019-06-17 15:59:59','QSPBNB','4h','0.000797000000000','0.000764000000000','0.711908500000000','0.682431736511920','893.2352572145547','893.235257214554736','test'),('2019-07-03 19:59:59','2019-07-04 03:59:59','QSPBNB','4h','0.000666000000000','0.000650000000000','0.711908500000000','0.694805593093093','1068.9316816816818','1068.931681681681766','test'),('2019-07-27 03:59:59','2019-07-30 11:59:59','QSPBNB','4h','0.000546200000000','0.000552300000000','0.711908500000000','0.719859144177957','1303.3842914683266','1303.384291468326637','test'),('2019-08-22 07:59:59','2019-08-28 19:59:59','QSPBNB','4h','0.000494700000000','0.000439900000000','0.711908500000000','0.633047400747928','1439.0711542348897','1439.071154234889718','test'),('2019-08-29 19:59:59','2019-09-02 03:59:59','QSPBNB','4h','0.000555100000000','0.000509000000000','0.711908500000000','0.652785852098721','1282.486939290218','1282.486939290218061','test'),('2019-09-03 15:59:59','2019-09-05 19:59:59','QSPBNB','4h','0.000566200000000','0.000490000000000','0.711908500000000','0.616098843164959','1257.3445778876724','1257.344577887672358','test'),('2019-09-09 11:59:59','2019-09-10 11:59:59','QSPBNB','4h','0.000525600000000','0.000548200000000','0.474605666666667','0.495012987950279','902.9788178589549','902.978817858954926','test'),('2019-09-10 23:59:59','2019-09-12 07:59:59','QSPBNB','4h','0.000528200000000','0.000534400000000','0.533413256340316','0.539674449428748','1009.8698529729576','1009.869852972957574','test'),('2019-09-13 23:59:59','2019-09-15 03:59:59','QSPBNB','4h','0.000549600000000','0.000533000000000','0.534978554612424','0.518820177599021','973.3962056266816','973.396205626681649','test'),('2019-09-15 15:59:59','2019-09-16 07:59:59','QSPBNB','4h','0.000571200000000','0.000536500000000','0.534978554612424','0.502478982054561','936.5871054139077','936.587105413907693','test'),('2019-09-16 15:59:59','2019-09-17 15:59:59','QSPBNB','4h','0.000536800000000','0.000564300000000','0.534978554612424','0.562385242861011','996.6068454031744','996.606845403174361','test'),('2019-09-17 23:59:59','2019-09-18 11:59:59','QSPBNB','4h','0.000554500000000','0.000529500000000','0.534978554612424','0.510858691915741','964.7945078673113','964.794507867311268','test'),('2019-09-18 19:59:59','2019-09-18 23:59:59','QSPBNB','4h','0.000551900000000','0.000544400000000','0.534978554612424','0.527708507213270','969.3396532205545','969.339653220554510','test'),('2019-09-19 11:59:59','2019-09-24 07:59:59','QSPBNB','4h','0.000573300000000','0.000605600000000','0.534978554612424','0.565119505796763','933.1563834160545','933.156383416054496','test'),('2019-09-26 07:59:59','2019-09-26 15:59:59','QSPBNB','4h','0.000624700000000','0.000589800000000','0.534978554612424','0.505091006099580','856.3767482190236','856.376748219023625','test'),('2019-09-27 03:59:59','2019-09-30 07:59:59','QSPBNB','4h','0.000621700000000','0.000629500000000','0.534978554612424','0.541690526183884','860.5091758282516','860.509175828251614','test'),('2019-10-02 15:59:59','2019-10-09 11:59:59','QSPBNB','4h','0.000664700000000','0.000708200000000','0.534978554612424','0.569989186665441','804.842116161312','804.842116161311992','test'),('2019-10-22 15:59:59','2019-10-23 03:59:59','QSPBNB','4h','0.000644000000000','0.000612300000000','0.534978554612424','0.508644982902465','830.7120413236398','830.712041323639824','test'),('2019-11-17 11:59:59','2019-11-21 19:59:59','QSPBNB','4h','0.000585900000000','0.000587600000000','0.534978554612424','0.536530805069569','913.088504202806','913.088504202806007','test'),('2019-11-25 07:59:59','2019-11-30 11:59:59','QSPBNB','4h','0.000622900000000','0.000640000000000','0.534978554612424','0.549664914034277','858.8514281785584','858.851428178558422','test'),('2019-12-01 15:59:59','2019-12-03 11:59:59','QSPBNB','4h','0.000677200000000','0.000650100000000','0.534978554612424','0.513569932595300','789.9860522924159','789.986052292415934','test'),('2019-12-03 15:59:59','2019-12-03 19:59:59','QSPBNB','4h','0.000668100000000','0.000661700000000','0.534978554612424','0.529853778756236','800.7462275294478','800.746227529447765','test'),('2019-12-07 15:59:59','2019-12-10 03:59:59','QSPBNB','4h','0.000669800000000','0.000659200000000','0.534978554612424','0.526512187519424','798.7138766981548','798.713876698154763','test'),('2019-12-11 23:59:59','2019-12-15 11:59:59','QSPBNB','4h','0.000667900000000','0.000724400000000','0.534978554612424','0.580234264053361','800.9860078041983','800.986007804198266','test'),('2019-12-15 15:59:59','2019-12-15 23:59:59','QSPBNB','4h','0.000742800000000','0.000722000000000','0.534978554612424','0.519998002733132','720.2188403505978','720.218840350597816','test'),('2019-12-16 03:59:59','2019-12-17 19:59:59','QSPBNB','4h','0.000751600000000','0.000738200000000','0.534978554612424','0.525440618699962','711.7862621240341','711.786262124034124','test'),('2019-12-22 11:59:59','2019-12-24 03:59:59','QSPBNB','4h','0.000751300000000','0.000752800000000','0.534978554612424','0.536046660338391','712.0704839776707','712.070483977670733','test'),('2019-12-24 07:59:59','2019-12-26 19:59:59','QSPBNB','4h','0.000764800000000','0.000745100000000','0.534978554612424','0.521198380023166','699.5012481857009','699.501248185700888','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-30  6:11:25
