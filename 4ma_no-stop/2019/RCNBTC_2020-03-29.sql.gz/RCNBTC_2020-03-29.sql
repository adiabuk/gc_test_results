-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-15 19:59:59','2019-01-15 23:59:59','RCNBTC','4h','0.000003300000000','0.000003100000000','0.001467500000000','0.001378560606061','444.6969696969697','444.696969696969688','test'),('2019-01-16 03:59:59','2019-01-22 19:59:59','RCNBTC','4h','0.000003200000000','0.000003470000000','0.001467500000000','0.001591320312500','458.59375000000006','458.593750000000057','test'),('2019-02-21 23:59:59','2019-02-24 19:59:59','RCNBTC','4h','0.000004040000000','0.000003880000000','0.001476220229640','0.001417756062130','365.40104694065593','365.401046940655931','test'),('2019-02-25 19:59:59','2019-02-28 11:59:59','RCNBTC','4h','0.000005140000000','0.000004870000000','0.001476220229640','0.001398675587227','287.202379307393','287.202379307393016','test'),('2019-02-28 15:59:59','2019-03-03 15:59:59','RCNBTC','4h','0.000005330000000','0.000005160000000','0.001476220229640','0.001429136282353','276.96439580487805','276.964395804878052','test'),('2019-03-05 03:59:59','2019-03-07 03:59:59','RCNBTC','4h','0.000005670000000','0.000005380000000','0.001476220229640','0.001400716902198','260.3563015238095','260.356301523809520','test'),('2019-03-08 11:59:59','2019-03-11 07:59:59','RCNBTC','4h','0.000006070000000','0.000005600000000','0.001476220229640','0.001361916521579','243.19937885337725','243.199378853377254','test'),('2019-03-12 23:59:59','2019-03-13 03:59:59','RCNBTC','4h','0.000006130000000','0.000005790000000','0.001476220229640','0.001394341782972','240.81896078955955','240.818960789559554','test'),('2019-03-15 15:59:59','2019-03-20 15:59:59','RCNBTC','4h','0.000006180000000','0.000006070000000','0.001476220229640','0.001449944465035','238.87058732038835','238.870587320388353','test'),('2019-03-28 07:59:59','2019-04-01 23:59:59','RCNBTC','4h','0.000006310000000','0.000007330000000','0.001476220229640','0.001714848539344','233.94932323930271','233.949323239302714','test'),('2019-04-16 23:59:59','2019-04-17 11:59:59','RCNBTC','4h','0.000006340000000','0.000006100000000','0.001476220229640','0.001420338075837','232.84230751419557','232.842307514195568','test'),('2019-04-17 15:59:59','2019-04-17 19:59:59','RCNBTC','4h','0.000006110000000','0.000005960000000','0.001476220229640','0.001439979143806','241.60723889361702','241.607238893617023','test'),('2019-04-19 19:59:59','2019-04-20 11:59:59','RCNBTC','4h','0.000006140000000','0.000006310000000','0.001476220229640','0.001517092776715','240.42674749837136','240.426747498371356','test'),('2019-04-21 03:59:59','2019-04-21 07:59:59','RCNBTC','4h','0.000006130000000','0.000006110000000','0.001476220229640','0.001471403850424','240.81896078955955','240.818960789559554','test'),('2019-05-03 15:59:59','2019-05-04 03:59:59','RCNBTC','4h','0.000005150000000','0.000004970000000','0.001476220229640','0.001424624182779','286.64470478446606','286.644704784466057','test'),('2019-05-23 11:59:59','2019-05-23 23:59:59','RCNBTC','4h','0.000004060000000','0.000004020000000','0.001476220229640','0.001461676187969','363.6010417832512','363.601041783251219','test'),('2019-05-24 03:59:59','2019-05-24 15:59:59','RCNBTC','4h','0.000004050000000','0.000003830000000','0.001476220229640','0.001396030488771','364.4988221333333','364.498822133333306','test'),('2019-06-02 19:59:59','2019-06-03 07:59:59','RCNBTC','4h','0.000004180000000','0.000003940000000','0.001476220229640','0.001391461173393','353.1627343636364','353.162734363636389','test'),('2019-06-03 11:59:59','2019-06-03 15:59:59','RCNBTC','4h','0.000003950000000','0.000003910000000','0.001476220229640','0.001461271164023','373.7266404151899','373.726640415189877','test'),('2019-06-07 23:59:59','2019-06-08 19:59:59','RCNBTC','4h','0.000003910000000','0.000003920000000','0.001476220229640','0.001479995728949','377.54993085421995','377.549930854219951','test'),('2019-06-08 23:59:59','2019-06-09 03:59:59','RCNBTC','4h','0.000003950000000','0.000003980000000','0.001476220229640','0.001487432028852','373.7266404151899','373.726640415189877','test'),('2019-06-09 07:59:59','2019-06-09 15:59:59','RCNBTC','4h','0.000004000000000','0.000003900000000','0.001476220229640','0.001439314723899','369.05505741','369.055057410000018','test'),('2019-06-10 07:59:59','2019-06-12 15:59:59','RCNBTC','4h','0.000004010000000','0.000003990000000','0.001476220229640','0.001468857535228','368.13472060847886','368.134720608478858','test'),('2019-06-12 19:59:59','2019-06-12 23:59:59','RCNBTC','4h','0.000004070000000','0.000003980000000','0.001476220229640','0.001443576539058','362.70767313022117','362.707673130221167','test'),('2019-07-25 11:59:59','2019-07-29 07:59:59','RCNBTC','4h','0.000001870000000','0.000001990000000','0.001476220229640','0.001570950939563','789.4225826951871','789.422582695187089','test'),('2019-08-22 03:59:59','2019-08-27 15:59:59','RCNBTC','4h','0.000001530000000','0.000001600000000','0.001476220229640','0.001543759717271','964.8498232941176','964.849823294117641','test'),('2019-09-16 11:59:59','2019-09-28 07:59:59','RCNBTC','4h','0.000001410000000','0.000004560000000','0.001476220229640','0.004774159040538','1046.9647018723404','1046.964701872340356','test'),('2019-10-01 19:59:59','2019-10-06 11:59:59','RCNBTC','4h','0.000004910000000','0.000004830000000','0.002189658654369','0.002153981934950','445.9589927430754','445.958992743075385','test'),('2019-10-08 03:59:59','2019-10-09 15:59:59','RCNBTC','4h','0.000005000000000','0.000004700000000','0.002189658654369','0.002058279135107','437.9317308738','437.931730873800007','test'),('2019-10-09 19:59:59','2019-10-10 03:59:59','RCNBTC','4h','0.000004890000000','0.000004710000000','0.002189658654369','0.002109057722306','447.782955903681','447.782955903681000','test'),('2019-10-22 03:59:59','2019-10-24 23:59:59','RCNBTC','4h','0.000005330000000','0.000005330000000','0.002189658654369','0.002189658654369','410.8177587934334','410.817758793433427','test'),('2019-11-02 19:59:59','2019-11-04 15:59:59','RCNBTC','4h','0.000004800000000','0.000004550000000','0.002189658654369','0.002075613932787','456.17888632687504','456.178886326875045','test'),('2019-11-06 19:59:59','2019-11-15 19:59:59','RCNBTC','4h','0.000005220000000','0.000005370000000','0.002189658654369','0.002252579880069','419.47483800172415','419.474838001724152','test'),('2019-11-16 19:59:59','2019-11-17 23:59:59','RCNBTC','4h','0.000005820000000','0.000005490000000','0.002189658654369','0.002065502751286','376.2300093417526','376.230009341752577','test'),('2019-11-20 07:59:59','2019-11-21 11:59:59','RCNBTC','4h','0.000005600000000','0.000005480000000','0.002189658654369','0.002142737397490','391.01047399446435','391.010473994464348','test'),('2019-11-21 23:59:59','2019-11-22 15:59:59','RCNBTC','4h','0.000005680000000','0.000005640000000','0.002189658654369','0.002174238523000','385.5032842198944','385.503284219894397','test'),('2019-11-22 19:59:59','2019-11-25 07:59:59','RCNBTC','4h','0.000005720000000','0.000005950000000','0.002189658654369','0.002277704369492','382.80745705751747','382.807457057517468','test'),('2019-11-25 15:59:59','2019-11-28 15:59:59','RCNBTC','4h','0.000006150000000','0.000006280000000','0.002189658654369','0.002235944121860','356.0420576209756','356.042057620975584','test'),('2019-11-29 11:59:59','2019-11-29 19:59:59','RCNBTC','4h','0.000006510000000','0.000006270000000','0.002189658654369','0.002108933911351','336.35309590921656','336.353095909216563','test'),('2019-12-01 07:59:59','2019-12-03 15:59:59','RCNBTC','4h','0.000007460000000','0.000006630000000','0.002189658654369','0.001946037115076','293.5199268591153','293.519926859115287','test'),('2019-12-07 19:59:59','2019-12-07 23:59:59','RCNBTC','4h','0.000006640000000','0.000006480000000','0.002189658654369','0.002136895795228','329.76786963388554','329.767869633885539','test'),('2019-12-09 11:59:59','2019-12-09 19:59:59','RCNBTC','4h','0.000006860000000','0.000006640000000','0.002189658654369','0.002119436365162','319.1922236689504','319.192223668950419','test'),('2019-12-21 15:59:59','2019-12-25 15:59:59','RCNBTC','4h','0.000006220000000','0.000006290000000','0.002189658654369','0.002214301115109','352.03515343553056','352.035153435530560','test'),('2020-01-01 07:59:59','2020-01-01 15:59:59','RCNBTC','4h','0.000006320000000','0.000006520000000','0.002189658654369','0.002258951649760','346.4649769571203','346.464976957120314','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-29  0:38:53
