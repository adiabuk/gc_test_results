-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-01-18 03:59:59','2019-01-18 15:59:59','LSKBTC','4h','0.000345500000000','0.000341300000000','0.001467500000000','0.001449660636758','4.247467438494935','4.247467438494935','test'),('2019-01-18 23:59:59','2019-01-22 11:59:59','LSKBTC','4h','0.000343700000000','0.000339900000000','0.001467500000000','0.001451275094559','4.269711958102997','4.269711958102997','test'),('2019-01-22 19:59:59','2019-01-25 11:59:59','LSKBTC','4h','0.000350200000000','0.000345900000000','0.001467500000000','0.001449481010851','4.190462592804112','4.190462592804112','test'),('2019-02-12 07:59:59','2019-02-12 11:59:59','LSKBTC','4h','0.000320700000000','0.000318200000000','0.001467500000000','0.001456060180854','4.575927658247584','4.575927658247584','test'),('2019-02-12 19:59:59','2019-02-13 15:59:59','LSKBTC','4h','0.000320300000000','0.000318400000000','0.001467500000000','0.001458794879800','4.581642210427725','4.581642210427725','test'),('2019-02-16 19:59:59','2019-02-19 03:59:59','LSKBTC','4h','0.000323400000000','0.000321500000000','0.001467500000000','0.001458878324057','4.537724180581324','4.537724180581324','test'),('2019-02-27 15:59:59','2019-02-27 23:59:59','LSKBTC','4h','0.000322800000000','0.000317800000000','0.001467500000000','0.001444769206939','4.546158612143743','4.546158612143743','test'),('2019-02-28 07:59:59','2019-02-28 11:59:59','LSKBTC','4h','0.000318400000000','0.000316900000000','0.001467500000000','0.001460586526382','4.608982412060302','4.608982412060302','test'),('2019-02-28 19:59:59','2019-02-28 23:59:59','LSKBTC','4h','0.000318400000000','0.000318900000000','0.001467500000000','0.001469804491206','4.608982412060302','4.608982412060302','test'),('2019-03-01 03:59:59','2019-03-01 07:59:59','LSKBTC','4h','0.000319100000000','0.000317600000000','0.001467500000000','0.001460601692259','4.598871827013475','4.598871827013475','test'),('2019-03-01 11:59:59','2019-03-01 15:59:59','LSKBTC','4h','0.000318500000000','0.000317900000000','0.001467500000000','0.001464735478807','4.607535321821037','4.607535321821037','test'),('2019-03-01 19:59:59','2019-03-02 03:59:59','LSKBTC','4h','0.000318300000000','0.000319200000000','0.001467500000000','0.001471649387370','4.6104304115614205','4.610430411561421','test'),('2019-03-03 11:59:59','2019-03-03 19:59:59','LSKBTC','4h','0.000320400000000','0.000321600000000','0.001467500000000','0.001472996254682','4.580212234706617','4.580212234706617','test'),('2019-03-04 03:59:59','2019-03-04 07:59:59','LSKBTC','4h','0.000319600000000','0.000318900000000','0.001467500000000','0.001464285826033','4.591677096370463','4.591677096370463','test'),('2019-03-05 07:59:59','2019-03-08 23:59:59','LSKBTC','4h','0.000318900000000','0.000328000000000','0.001467500000000','0.001509375979931','4.601756036375039','4.601756036375039','test'),('2019-03-09 07:59:59','2019-03-09 15:59:59','LSKBTC','4h','0.000329500000000','0.000327900000000','0.001467500000000','0.001460374051593','4.45371775417299','4.453717754172990','test'),('2019-03-12 01:59:59','2019-03-16 15:59:59','LSKBTC','4h','0.000333500000000','0.000373800000000','0.001467500000000','0.001644832083958','4.400299850074963','4.400299850074963','test'),('2019-03-17 15:59:59','2019-03-18 15:59:59','LSKBTC','4h','0.000393700000000','0.000379400000000','0.001492665276510','0.001438448579903','3.7913773850895356','3.791377385089536','test'),('2019-03-21 11:59:59','2019-03-21 15:59:59','LSKBTC','4h','0.000384900000000','0.000369300000000','0.001492665276510','0.001432167541219','3.878059954559626','3.878059954559626','test'),('2019-03-24 15:59:59','2019-04-02 07:59:59','LSKBTC','4h','0.000388900000000','0.000394500000000','0.001492665276510','0.001514159042384','3.8381724775263564','3.838172477526356','test'),('2019-04-04 03:59:59','2019-04-06 15:59:59','LSKBTC','4h','0.000421500000000','0.000415300000000','0.001492665276510','0.001470709108742','3.5413173819928825','3.541317381992882','test'),('2019-06-04 07:59:59','2019-06-06 11:59:59','LSKBTC','4h','0.000250500000000','0.000252000000000','0.001492665276510','0.001501603391938','5.958743618802395','5.958743618802395','test'),('2019-06-06 19:59:59','2019-06-09 15:59:59','LSKBTC','4h','0.000252300000000','0.000251200000000','0.001492665276510','0.001486157421559','5.916231773721759','5.916231773721759','test'),('2019-06-11 03:59:59','2019-06-11 11:59:59','LSKBTC','4h','0.000257200000000','0.000255700000000','0.001492665276510','0.001483959996904','5.8035197375972','5.803519737597200','test'),('2019-06-11 15:59:59','2019-06-12 15:59:59','LSKBTC','4h','0.000257500000000','0.000252700000000','0.001492665276510','0.001464840836404','5.79675835537864','5.796758355378640','test'),('2019-06-12 23:59:59','2019-06-13 07:59:59','LSKBTC','4h','0.000257100000000','0.000254800000000','0.001492665276510','0.001479311989322','5.805777038156359','5.805777038156359','test'),('2019-07-20 23:59:59','2019-07-26 19:59:59','LSKBTC','4h','0.000140100000000','0.000156600000000','0.001492665276510','0.001668460972887','10.654284628907924','10.654284628907924','test'),('2019-08-17 11:59:59','2019-08-19 11:59:59','LSKBTC','4h','0.000119300000000','0.000116600000000','0.001495956805550','0.001462100281032','12.539453525148783','12.539453525148783','test'),('2019-08-21 23:59:59','2019-08-22 03:59:59','LSKBTC','4h','0.000118900000000','0.000117300000000','0.001495956805550','0.001475826184113','12.58163839823381','12.581638398233810','test'),('2019-08-22 11:59:59','2019-08-23 23:59:59','LSKBTC','4h','0.000116700000000','0.000118100000000','0.001495956805550','0.001513903159687','12.818824383461868','12.818824383461868','test'),('2019-08-24 07:59:59','2019-08-24 15:59:59','LSKBTC','4h','0.000119000000000','0.000117400000000','0.001495956805550','0.001475843100601','12.571065592857144','12.571065592857144','test'),('2019-08-25 11:59:59','2019-08-25 15:59:59','LSKBTC','4h','0.000119200000000','0.000117500000000','0.001495956805550','0.001474621851108','12.54997320092282','12.549973200922819','test'),('2019-08-30 03:59:59','2019-08-30 11:59:59','LSKBTC','4h','0.000120200000000','0.000116100000000','0.001495956805550','0.001444929992715','12.445564106073213','12.445564106073213','test'),('2019-09-18 23:59:59','2019-09-19 07:59:59','LSKBTC','4h','0.000102200000000','0.000098300000000','0.001495956805550','0.001438870391248','14.637542128669276','14.637542128669276','test'),('2019-09-19 11:59:59','2019-09-19 23:59:59','LSKBTC','4h','0.000098400000000','0.000096900000000','0.001495956805550','0.001473152585953','15.20281306453252','15.202813064532521','test'),('2019-09-20 03:59:59','2019-09-22 15:59:59','LSKBTC','4h','0.000097200000000','0.000096400000000','0.001495956805550','0.001483644403858','15.390502114711934','15.390502114711934','test'),('2019-09-25 07:59:59','2019-09-26 19:59:59','LSKBTC','4h','0.000100100000000','0.000104700000000','0.001495956805550','0.001564702073338','14.944623432067933','14.944623432067933','test'),('2019-09-27 03:59:59','2019-09-29 11:59:59','LSKBTC','4h','0.000104300000000','0.000101900000000','0.001495956805550','0.001461534021913','14.342826515340365','14.342826515340365','test'),('2019-10-01 11:59:59','2019-10-01 15:59:59','LSKBTC','4h','0.000103800000000','0.000101200000000','0.001495956805550','0.001458485825835','14.41191527504817','14.411915275048170','test'),('2019-10-02 15:59:59','2019-10-05 19:59:59','LSKBTC','4h','0.000104200000000','0.000105100000000','0.001495956805550','0.001508877737652','14.356591224088293','14.356591224088293','test'),('2019-10-05 23:59:59','2019-10-06 19:59:59','LSKBTC','4h','0.000105400000000','0.000105100000000','0.001495956805550','0.001491698863978','14.193138572580645','14.193138572580645','test'),('2019-10-06 23:59:59','2019-10-09 15:59:59','LSKBTC','4h','0.000107700000000','0.000104000000000','0.001495956805550','0.001444563674812','13.890035334726091','13.890035334726091','test'),('2019-11-10 03:59:59','2019-11-10 19:59:59','LSKBTC','4h','0.000087600000000','0.000086300000000','0.001495956805550','0.001473756533322','17.07713248344749','17.077132483447489','test'),('2019-11-10 23:59:59','2019-11-11 03:59:59','LSKBTC','4h','0.000086600000000','0.000086800000000','0.001495956805550','0.001499411671152','17.274328008660508','17.274328008660508','test'),('2019-11-11 11:59:59','2019-11-11 15:59:59','LSKBTC','4h','0.000086800000000','0.000086900000000','0.001495956805550','0.001497680258091','17.234525409562213','17.234525409562213','test'),('2019-11-14 23:59:59','2019-11-20 07:59:59','LSKBTC','4h','0.000089000000000','0.000092500000000','0.001495956805550','0.001554786567566','16.80850343314607','16.808503433146068','test'),('2019-11-23 11:59:59','2019-11-24 15:59:59','LSKBTC','4h','0.000095100000000','0.000092800000000','0.001495956805550','0.001459776987960','15.730355473711883','15.730355473711883','test'),('2019-11-24 19:59:59','2019-11-24 23:59:59','LSKBTC','4h','0.000093000000000','0.000093600000000','0.001495956805550','0.001505608139779','16.085557048924734','16.085557048924734','test'),('2019-12-05 19:59:59','2019-12-06 11:59:59','LSKBTC','4h','0.000094800000000','0.000092000000000','0.001495956805550','0.001451772427327','15.78013507964135','15.780135079641351','test'),('2019-12-26 19:59:59','2019-12-28 11:59:59','LSKBTC','4h','0.000079200000000','0.000078800000000','0.001495956805550','0.001488401468148','18.888343504419193','18.888343504419193','test'),('2019-12-30 11:59:59','2019-12-31 03:59:59','LSKBTC','4h','0.000080500000000','0.000077200000000','0.001495956805550','0.001434631868180','18.583314354658384','18.583314354658384','test'),('2019-12-31 07:59:59','2019-12-31 15:59:59','LSKBTC','4h','0.000079000000000','0.000077500000000','0.001495956805550','0.001467552562407','18.93616209556962','18.936162095569621','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 13:29:59
