-- MySQL dump 10.16  Distrib 10.1.44-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: greencandle
-- ------------------------------------------------------
-- Server version	10.1.24-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `balance`
--

DROP TABLE IF EXISTS `balance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `balance` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ctime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `exchange_id` int(11) unsigned NOT NULL,
  `gbp` varchar(30) DEFAULT NULL,
  `btc` varchar(30) DEFAULT NULL,
  `usd` varchar(30) DEFAULT NULL,
  `count` varchar(30) DEFAULT NULL,
  `coin` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `exchange_id` (`exchange_id`),
  CONSTRAINT `balance_ibfk_2` FOREIGN KEY (`exchange_id`) REFERENCES `exchange` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `balance`
--

LOCK TABLES `balance` WRITE;
/*!40000 ALTER TABLE `balance` DISABLE KEYS */;
/*!40000 ALTER TABLE `balance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coin`
--

DROP TABLE IF EXISTS `coin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coin` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coin`
--

LOCK TABLES `coin` WRITE;
/*!40000 ALTER TABLE `coin` DISABLE KEYS */;
/*!40000 ALTER TABLE `coin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `daily_profit`
--

DROP TABLE IF EXISTS `daily_profit`;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `daily_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `exchange`
--

DROP TABLE IF EXISTS `exchange`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange`
--

LOCK TABLES `exchange` WRITE;
/*!40000 ALTER TABLE `exchange` DISABLE KEYS */;
INSERT INTO `exchange` VALUES (3,'coinbase'),(4,'binance');
/*!40000 ALTER TABLE `exchange` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `hour_balance`
--

DROP TABLE IF EXISTS `hour_balance`;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `hour_balance` (
  `exchange_id` tinyint NOT NULL,
  `usd1` tinyint NOT NULL,
  `coin` tinyint NOT NULL,
  `ctime1` tinyint NOT NULL,
  `ctime2` tinyint NOT NULL,
  `usd2` tinyint NOT NULL,
  `USD_diff` tinyint NOT NULL,
  `GBP_diff` tinyint NOT NULL,
  `COUNT_diff` tinyint NOT NULL,
  `perc_change` tinyint NOT NULL,
  `BTC_diff` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `monthly_profit`
--

DROP TABLE IF EXISTS `monthly_profit`;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `monthly_profit` (
  `date` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `perc` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `open_trades`
--

DROP TABLE IF EXISTS `open_trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `open_trades` (
  `pair` varchar(30) DEFAULT NULL,
  `buy_price` varchar(30) DEFAULT NULL,
  `buy_time` varchar(30) DEFAULT NULL,
  `current_price` varchar(30) DEFAULT NULL,
  `perc` varchar(30) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `open_trades`
--

LOCK TABLES `open_trades` WRITE;
/*!40000 ALTER TABLE `open_trades` DISABLE KEYS */;
/*!40000 ALTER TABLE `open_trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Temporary table structure for view `profit`
--

DROP TABLE IF EXISTS `profit`;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profit` (
  `buy_time` tinyint NOT NULL,
  `interval` tinyint NOT NULL,
  `sell_time` tinyint NOT NULL,
  `pair` tinyint NOT NULL,
  `buy_price` tinyint NOT NULL,
  `sell_price` tinyint NOT NULL,
  `perc` tinyint NOT NULL,
  `base_profit` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Temporary table structure for view `profitable`
--

DROP TABLE IF EXISTS `profitable`;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
/*!50001 CREATE TABLE `profitable` (
  `pair` tinyint NOT NULL,
  `total` tinyint NOT NULL,
  `profit` tinyint NOT NULL,
  `loss` tinyint NOT NULL,
  `perc_profitable` tinyint NOT NULL
) ENGINE=MyISAM */;
SET character_set_client = @saved_cs_client;

--
-- Table structure for table `symbols`
--

DROP TABLE IF EXISTS `symbols`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `symbols` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `symbol` varchar(10) DEFAULT NULL,
  `category` varchar(20) DEFAULT NULL,
  `maximum_leverage` int(11) DEFAULT NULL,
  `maximum_amount` int(11) DEFAULT NULL,
  `overnight_charge_long_percent` float DEFAULT NULL,
  `overnight_charge_short_percent` float DEFAULT NULL,
  `decimals` int(11) DEFAULT NULL,
  `timezone` varchar(80) DEFAULT NULL,
  `timezone_offset` varchar(10) DEFAULT NULL,
  `open_day` varchar(80) DEFAULT NULL,
  `open_time` time DEFAULT NULL,
  `close_day` varchar(80) DEFAULT NULL,
  `close_time` time DEFAULT NULL,
  `daily_break_start` time DEFAULT NULL,
  `daily_break_stop` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `symbol` (`symbol`),
  KEY `category` (`category`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `symbols`
--

LOCK TABLES `symbols` WRITE;
/*!40000 ALTER TABLE `symbols` DISABLE KEYS */;
/*!40000 ALTER TABLE `symbols` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trades`
--

DROP TABLE IF EXISTS `trades`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trades` (
  `buy_time` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `sell_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `pair` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `interval` varchar(3) DEFAULT NULL,
  `buy_price` varchar(60) DEFAULT NULL,
  `sell_price` varchar(30) DEFAULT NULL,
  `base_in` varchar(30) DEFAULT NULL,
  `base_out` varchar(30) DEFAULT NULL,
  `quote_in` varchar(30) DEFAULT NULL,
  `quote_out` varchar(30) DEFAULT NULL,
  `name` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trades`
--

LOCK TABLES `trades` WRITE;
/*!40000 ALTER TABLE `trades` DISABLE KEYS */;
INSERT INTO `trades` VALUES ('2019-03-21 03:59:59','2019-03-21 15:59:59','POLYBNB','4h','0.006920000000000','0.006710000000000','0.711908500000000','0.690304340317919','102.87695086705203','102.876950867052031','test'),('2019-03-21 19:59:59','2019-03-22 11:59:59','POLYBNB','4h','0.006720000000000','0.006680000000000','0.711908500000000','0.707670949404762','105.93876488095239','105.938764880952391','test'),('2019-03-22 15:59:59','2019-03-22 19:59:59','POLYBNB','4h','0.006690000000000','0.006580000000000','0.711908500000000','0.700202979073244','106.41382660687594','106.413826606875944','test'),('2019-03-24 07:59:59','2019-03-26 03:59:59','POLYBNB','4h','0.007250000000000','0.007010000000000','0.711908500000000','0.688341873793103','98.19427586206896','98.194275862068963','test'),('2019-03-26 07:59:59','2019-03-26 15:59:59','POLYBNB','4h','0.007200000000000','0.007000000000000','0.711908500000000','0.692133263888889','98.87618055555556','98.876180555555564','test'),('2019-03-28 03:59:59','2019-03-28 11:59:59','POLYBNB','4h','0.007300000000000','0.007140000000000','0.711908500000000','0.696305026027397','97.52171232876714','97.521712328767137','test'),('2019-03-28 23:59:59','2019-03-29 03:59:59','POLYBNB','4h','0.007270000000000','0.007050000000000','0.711908500000000','0.690365189133425','97.92414030261348','97.924140302613480','test'),('2019-04-08 07:59:59','2019-04-09 15:59:59','POLYBNB','4h','0.006900000000000','0.006760000000000','0.711908500000000','0.697463979710145','103.17514492753624','103.175144927536238','test'),('2019-04-09 19:59:59','2019-04-09 23:59:59','POLYBNB','4h','0.006820000000000','0.006690000000000','0.711908500000000','0.698338396627566','104.38541055718477','104.385410557184770','test'),('2019-04-10 03:59:59','2019-04-10 07:59:59','POLYBNB','4h','0.006830000000000','0.006750000000000','0.711908500000000','0.703569893850659','104.23257686676428','104.232576866764276','test'),('2019-05-09 19:59:59','2019-05-12 19:59:59','POLYBNB','4h','0.003950000000000','0.004080000000000','0.711908500000000','0.735338400000000','180.23','180.229999999999990','test'),('2019-05-30 19:59:59','2019-05-30 23:59:59','POLYBNB','4h','0.003290000000000','0.003110000000000','0.711908500000000','0.672959098784195','216.38556231003042','216.385562310030423','test'),('2019-06-09 03:59:59','2019-06-09 15:59:59','POLYBNB','4h','0.003110000000000','0.003010000000000','0.711908500000000','0.689017551446945','228.90948553054665','228.909485530546647','test'),('2019-06-10 03:59:59','2019-06-10 07:59:59','POLYBNB','4h','0.003100000000000','0.003040000000000','0.711908500000000','0.698129625806452','229.6479032258065','229.647903225806488','test'),('2019-06-10 19:59:59','2019-06-12 03:59:59','POLYBNB','4h','0.003130000000000','0.003070000000000','0.711908500000000','0.698261691693291','227.4468051118211','227.446805111821106','test'),('2019-07-03 19:59:59','2019-07-03 23:59:59','POLYBNB','4h','0.002560000000000','0.002550000000000','0.711908500000000','0.709127607421875','278.0892578125','278.089257812500023','test'),('2019-07-30 03:59:59','2019-07-31 15:59:59','POLYBNB','4h','0.002000000000000','0.001958000000000','0.711908500000000','0.696958421500000','355.95425','355.954250000000002','test'),('2019-08-23 03:59:59','2019-08-26 07:59:59','POLYBNB','4h','0.001591000000000','0.001492000000000','0.711908500000000','0.667609982401006','447.45977372721563','447.459773727215634','test'),('2019-08-27 03:59:59','2019-08-28 07:59:59','POLYBNB','4h','0.001613000000000','0.001543000000000','0.711908500000000','0.681013524798512','441.35678859268444','441.356788592684438','test'),('2019-08-29 19:59:59','2019-09-02 15:59:59','POLYBNB','4h','0.001607000000000','0.001604000000000','0.711908500000000','0.710579485998756','443.0046670815184','443.004667081518392','test'),('2019-09-11 15:59:59','2019-09-12 11:59:59','POLYBNB','4h','0.001607000000000','0.001598000000000','0.711908500000000','0.707921457996266','443.0046670815184','443.004667081518392','test'),('2019-09-12 19:59:59','2019-09-13 03:59:59','POLYBNB','4h','0.001619000000000','0.001587000000000','0.711908500000000','0.697837424027177','439.72112415071035','439.721124150710352','test'),('2019-09-15 19:59:59','2019-09-17 07:59:59','POLYBNB','4h','0.001620000000000','0.001557000000000','0.711908500000000','0.684223169444445','439.4496913580247','439.449691358024722','test'),('2019-09-17 11:59:59','2019-09-17 15:59:59','POLYBNB','4h','0.001612000000000','0.001516000000000','0.711908500000000','0.669511964019851','441.6305831265509','441.630583126550903','test'),('2019-09-20 19:59:59','2019-09-23 23:59:59','POLYBNB','4h','0.001623000000000','0.001621000000000','0.711908500000000','0.711031225200247','438.63739987677144','438.637399876771440','test'),('2019-09-24 07:59:59','2019-09-24 15:59:59','POLYBNB','4h','0.001635000000000','0.001645000000000','0.711908500000000','0.716262680428135','435.4180428134557','435.418042813455713','test'),('2019-09-24 23:59:59','2019-09-25 03:59:59','POLYBNB','4h','0.001679000000000','0.001681000000000','0.711908500000000','0.712756514889815','424.0074449076832','424.007444907683180','test'),('2019-09-25 11:59:59','2019-09-25 15:59:59','POLYBNB','4h','0.001640000000000','0.001671000000000','0.711908500000000','0.725365307012195','434.09054878048784','434.090548780487836','test'),('2019-09-28 15:59:59','2019-09-29 07:59:59','POLYBNB','4h','0.001665000000000','0.001611000000000','0.711908500000000','0.688819575675676','427.5726726726727','427.572672672672695','test'),('2019-09-30 07:59:59','2019-09-30 11:59:59','POLYBNB','4h','0.001660000000000','0.001659000000000','0.711908500000000','0.711479639457831','428.8605421686747','428.860542168674726','test'),('2019-10-02 19:59:59','2019-10-08 07:59:59','POLYBNB','4h','0.001691000000000','0.001715000000000','0.711908500000000','0.722012464518037','420.99852158486107','420.998521584861066','test'),('2019-10-08 19:59:59','2019-10-09 11:59:59','POLYBNB','4h','0.001750000000000','0.001697000000000','0.711908500000000','0.690347842571429','406.80485714285714','406.804857142857145','test'),('2019-11-02 19:59:59','2019-11-04 03:59:59','POLYBNB','4h','0.001373000000000','0.001306000000000','0.711908500000000','0.677168609613984','518.5058266569556','518.505826656955605','test'),('2019-11-04 07:59:59','2019-11-04 11:59:59','POLYBNB','4h','0.001343000000000','0.001341000000000','0.711908500000000','0.710848323529412','530.0882352941177','530.088235294117680','test'),('2019-11-04 23:59:59','2019-11-05 03:59:59','POLYBNB','4h','0.001353000000000','0.001343000000000','0.711908500000000','0.706646796378418','526.1703621581671','526.170362158167109','test'),('2019-11-05 23:59:59','2019-11-06 07:59:59','POLYBNB','4h','0.001364000000000','0.001324000000000','0.711908500000000','0.691031417888563','521.9270527859238','521.927052785923820','test'),('2019-11-06 19:59:59','2019-11-06 23:59:59','POLYBNB','4h','0.001354000000000','0.001332000000000','0.711908500000000','0.700341301329395','525.7817577548007','525.781757754800651','test'),('2019-11-07 07:59:59','2019-11-07 11:59:59','POLYBNB','4h','0.001353000000000','0.001328000000000','0.711908500000000','0.698754240946046','526.1703621581671','526.170362158167109','test'),('2019-11-15 19:59:59','2019-11-18 07:59:59','POLYBNB','4h','0.001370000000000','0.001333000000000','0.711908500000000','0.692681774087591','519.6412408759124','519.641240875912445','test'),('2019-11-18 11:59:59','2019-11-18 23:59:59','POLYBNB','4h','0.001360000000000','0.001337000000000','0.711908500000000','0.699868870955882','523.4621323529411','523.462132352941126','test'),('2019-11-19 15:59:59','2019-11-19 19:59:59','POLYBNB','4h','0.001361000000000','0.001335000000000','0.711908500000000','0.698308484570169','523.0775165319618','523.077516531961805','test'),('2019-11-19 23:59:59','2019-11-21 11:59:59','POLYBNB','4h','0.001361000000000','0.001341000000000','0.711908500000000','0.701446949669361','523.0775165319618','523.077516531961805','test'),('2019-11-21 15:59:59','2019-11-22 03:59:59','POLYBNB','4h','0.001363000000000','0.001341000000000','0.711908500000000','0.700417680484226','522.3099779897285','522.309977989728509','test'),('2019-11-27 07:59:59','2019-11-28 23:59:59','POLYBNB','4h','0.001446000000000','0.001385000000000','0.711908500000000','0.681876398686030','492.32952973720614','492.329529737206144','test'),('2019-11-29 03:59:59','2019-11-29 15:59:59','POLYBNB','4h','0.001400000000000','0.001372000000000','0.711908500000000','0.697670330000000','508.5060714285715','508.506071428571488','test'),('2019-12-01 23:59:59','2019-12-02 11:59:59','POLYBNB','4h','0.001409000000000','0.001393000000000','0.711908500000000','0.703824372249823','505.25798438608945','505.257984386089447','test'),('2019-12-02 19:59:59','2019-12-03 07:59:59','POLYBNB','4h','0.001407000000000','0.001393000000000','0.711908500000000','0.704824833333333','505.9761904761905','505.976190476190482','test'),('2019-12-03 11:59:59','2019-12-03 23:59:59','POLYBNB','4h','0.001408000000000','0.001393000000000','0.711908500000000','0.704324247514205','505.6168323863637','505.616832386363683','test'),('2019-12-04 07:59:59','2019-12-04 15:59:59','POLYBNB','4h','0.001401000000000','0.001380000000000','0.711908500000000','0.701237494646681','508.14311206281235','508.143112062812349','test'),('2019-12-04 19:59:59','2019-12-04 23:59:59','POLYBNB','4h','0.001393000000000','0.001378000000000','0.711908500000000','0.704242579325198','511.06137832017237','511.061378320172366','test'),('2019-12-06 23:59:59','2019-12-07 03:59:59','POLYBNB','4h','0.001393000000000','0.001417000000000','0.711908500000000','0.724173973079684','511.06137832017237','511.061378320172366','test'),('2019-12-07 11:59:59','2019-12-13 15:59:59','POLYBNB','4h','0.001421000000000','0.001597000000000','0.711908500000000','0.800082951794511','500.99120337790293','500.991203377902934','test');
/*!40000 ALTER TABLE `trades` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Final view structure for view `daily_profit`
--

/*!50001 DROP TABLE IF EXISTS `daily_profit`*/;
/*!50001 DROP VIEW IF EXISTS `daily_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `daily_profit` AS select left(`profit`.`sell_time`,10) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,10) order by left(`profit`.`sell_time`,10),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `hour_balance`
--

/*!50001 DROP TABLE IF EXISTS `hour_balance`*/;
/*!50001 DROP VIEW IF EXISTS `hour_balance`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`localhost` SQL SECURITY DEFINER */
/*!50001 VIEW `hour_balance` AS select `tt1`.`exchange_id` AS `exchange_id`,`tt1`.`usd` AS `usd1`,`tt1`.`coin` AS `coin`,`tt1`.`ctime` AS `ctime1`,`tt2`.`ctime` AS `ctime2`,`tt2`.`usd` AS `usd2`,(`tt1`.`usd` - `tt2`.`usd`) AS `USD_diff`,(`tt1`.`gbp` - `tt2`.`gbp`) AS `GBP_diff`,(`tt1`.`count` - `tt2`.`count`) AS `COUNT_diff`,(((`tt1`.`btc` - `tt2`.`btc`) / `tt1`.`btc`) * 100) AS `perc_change`,(`tt1`.`btc` - `tt2`.`btc`) AS `BTC_diff` from (`balance` `tt1` left join `balance` `tt2` on(((`tt1`.`coin` = `tt2`.`coin`) and (`tt1`.`exchange_id` = `tt2`.`exchange_id`)))) where ((`tt1`.`ctime` > (now() - interval 20 minute)) and (`tt2`.`ctime` < (now() - interval 45 minute)) and (`tt2`.`ctime` > (now() - interval 90 minute))) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `monthly_profit`
--

/*!50001 DROP TABLE IF EXISTS `monthly_profit`*/;
/*!50001 DROP VIEW IF EXISTS `monthly_profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `monthly_profit` AS select left(`profit`.`sell_time`,7) AS `date`,`profit`.`interval` AS `interval`,sum(`profit`.`base_profit`) AS `profit`,sum(`profit`.`perc`) AS `perc` from `profit` where (`profit`.`perc` is not null) group by left(`profit`.`sell_time`,7) order by left(`profit`.`sell_time`,7),sum(`profit`.`base_profit`) */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profit`
--

/*!50001 DROP TABLE IF EXISTS `profit`*/;
/*!50001 DROP VIEW IF EXISTS `profit`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8mb4 */;
/*!50001 SET character_set_results     = utf8mb4 */;
/*!50001 SET collation_connection      = utf8mb4_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profit` AS select `trades`.`buy_time` AS `buy_time`,`trades`.`interval` AS `interval`,`trades`.`sell_time` AS `sell_time`,`trades`.`pair` AS `pair`,`trades`.`buy_price` AS `buy_price`,`trades`.`sell_price` AS `sell_price`,(((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) AS `perc`,(`trades`.`base_out` - `trades`.`base_in`) AS `base_profit` from `trades` order by (((`trades`.`sell_price` - `trades`.`buy_price`) / `trades`.`buy_price`) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;

--
-- Final view structure for view `profitable`
--

/*!50001 DROP TABLE IF EXISTS `profitable`*/;
/*!50001 DROP VIEW IF EXISTS `profitable`*/;
/*!50001 SET @saved_cs_client          = @@character_set_client */;
/*!50001 SET @saved_cs_results         = @@character_set_results */;
/*!50001 SET @saved_col_connection     = @@collation_connection */;
/*!50001 SET character_set_client      = utf8 */;
/*!50001 SET character_set_results     = utf8 */;
/*!50001 SET collation_connection      = utf8_general_ci */;
/*!50001 CREATE ALGORITHM=UNDEFINED */
/*!50013 DEFINER=`root`@`%` SQL SECURITY DEFINER */
/*!50001 VIEW `profitable` AS select `profit`.`pair` AS `pair`,count(0) AS `total`,sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) AS `profit`,sum((case when (`profit`.`perc` < 0) then 1 else 0 end)) AS `loss`,((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) AS `perc_profitable` from `profit` group by `profit`.`pair` order by ((sum((case when (`profit`.`perc` > 0) then 1 else 0 end)) / count(0)) * 100) desc */;
/*!50001 SET character_set_client      = @saved_cs_client */;
/*!50001 SET character_set_results     = @saved_cs_results */;
/*!50001 SET collation_connection      = @saved_col_connection */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-03-28 14:09:32
